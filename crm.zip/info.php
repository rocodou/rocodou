<?php
$data=['omer'=> 'Omercik'];

$data +=['kerem'=>'keremcik'];

print_r($data);



?>