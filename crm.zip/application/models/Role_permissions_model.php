<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Role_permissions_model extends MY_Model {

	public $table = 'role_permissions';

	public function __construct()
	{
		parent::__construct();
	}

}

/* End of file Role_permissions_model.php */
/* Location: ./application/models/Role_permissions_model.php */