<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-07-03 08:22:35 --> Config Class Initialized
INFO - 2021-07-03 08:22:35 --> Hooks Class Initialized
DEBUG - 2021-07-03 08:22:35 --> UTF-8 Support Enabled
INFO - 2021-07-03 08:22:35 --> Utf8 Class Initialized
INFO - 2021-07-03 08:22:35 --> URI Class Initialized
DEBUG - 2021-07-03 08:22:35 --> No URI present. Default controller set.
INFO - 2021-07-03 08:22:35 --> Router Class Initialized
INFO - 2021-07-03 08:22:35 --> Output Class Initialized
INFO - 2021-07-03 08:22:35 --> Security Class Initialized
DEBUG - 2021-07-03 08:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 08:22:35 --> Input Class Initialized
INFO - 2021-07-03 08:22:35 --> Language Class Initialized
INFO - 2021-07-03 08:22:35 --> Loader Class Initialized
INFO - 2021-07-03 08:22:35 --> Helper loaded: basic_helper
INFO - 2021-07-03 08:22:35 --> Helper loaded: url_helper
INFO - 2021-07-03 08:22:35 --> Helper loaded: file_helper
INFO - 2021-07-03 08:22:35 --> Helper loaded: form_helper
INFO - 2021-07-03 08:22:35 --> Helper loaded: cookie_helper
INFO - 2021-07-03 08:22:35 --> Helper loaded: security_helper
INFO - 2021-07-03 08:22:35 --> Helper loaded: directory_helper
INFO - 2021-07-03 08:22:35 --> Helper loaded: language_helper
INFO - 2021-07-03 08:22:35 --> Helper loaded: general_helper
INFO - 2021-07-03 08:22:35 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 08:22:35 --> Database Driver Class Initialized
DEBUG - 2021-07-03 08:22:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 08:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 08:22:35 --> Parser Class Initialized
INFO - 2021-07-03 08:22:35 --> Form Validation Class Initialized
INFO - 2021-07-03 08:22:35 --> Upload Class Initialized
INFO - 2021-07-03 08:22:35 --> Email Class Initialized
INFO - 2021-07-03 08:22:35 --> MY_Model class loaded
INFO - 2021-07-03 08:22:35 --> Model "Users_model" initialized
INFO - 2021-07-03 08:22:35 --> Model "Settings_model" initialized
INFO - 2021-07-03 08:22:35 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 08:22:35 --> Model "Permissions_model" initialized
INFO - 2021-07-03 08:22:35 --> Model "Roles_model" initialized
INFO - 2021-07-03 08:22:35 --> Model "Activity_model" initialized
INFO - 2021-07-03 08:22:35 --> Model "Templates_model" initialized
INFO - 2021-07-03 08:22:35 --> Database Driver Class Initialized
INFO - 2021-07-03 08:22:35 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 08:22:35 --> Controller Class Initialized
INFO - 2021-07-03 08:22:36 --> Config Class Initialized
INFO - 2021-07-03 08:22:36 --> Hooks Class Initialized
DEBUG - 2021-07-03 08:22:36 --> UTF-8 Support Enabled
INFO - 2021-07-03 08:22:36 --> Utf8 Class Initialized
INFO - 2021-07-03 08:22:36 --> Config Class Initialized
INFO - 2021-07-03 08:22:36 --> Hooks Class Initialized
INFO - 2021-07-03 08:22:36 --> URI Class Initialized
DEBUG - 2021-07-03 08:22:36 --> UTF-8 Support Enabled
INFO - 2021-07-03 08:22:36 --> Utf8 Class Initialized
INFO - 2021-07-03 08:22:36 --> Router Class Initialized
INFO - 2021-07-03 08:22:36 --> URI Class Initialized
INFO - 2021-07-03 08:22:36 --> Output Class Initialized
INFO - 2021-07-03 08:22:36 --> Router Class Initialized
INFO - 2021-07-03 08:22:36 --> Security Class Initialized
INFO - 2021-07-03 08:22:36 --> Output Class Initialized
DEBUG - 2021-07-03 08:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 08:22:36 --> Security Class Initialized
INFO - 2021-07-03 08:22:36 --> Input Class Initialized
DEBUG - 2021-07-03 08:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 08:22:36 --> Language Class Initialized
INFO - 2021-07-03 08:22:36 --> Input Class Initialized
INFO - 2021-07-03 08:22:36 --> Language Class Initialized
INFO - 2021-07-03 08:22:36 --> Loader Class Initialized
ERROR - 2021-07-03 08:22:36 --> 404 Page Not Found: Faviconico/index
INFO - 2021-07-03 08:22:36 --> Helper loaded: basic_helper
INFO - 2021-07-03 08:22:36 --> Helper loaded: url_helper
INFO - 2021-07-03 08:22:36 --> Helper loaded: file_helper
INFO - 2021-07-03 08:22:36 --> Helper loaded: form_helper
INFO - 2021-07-03 08:22:36 --> Helper loaded: cookie_helper
INFO - 2021-07-03 08:22:36 --> Helper loaded: security_helper
INFO - 2021-07-03 08:22:36 --> Helper loaded: directory_helper
INFO - 2021-07-03 08:22:36 --> Helper loaded: language_helper
INFO - 2021-07-03 08:22:36 --> Helper loaded: general_helper
INFO - 2021-07-03 08:22:36 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 08:22:36 --> Database Driver Class Initialized
DEBUG - 2021-07-03 08:22:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 08:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 08:22:36 --> Parser Class Initialized
INFO - 2021-07-03 08:22:36 --> Form Validation Class Initialized
INFO - 2021-07-03 08:22:36 --> Upload Class Initialized
INFO - 2021-07-03 08:22:36 --> Email Class Initialized
INFO - 2021-07-03 08:22:36 --> MY_Model class loaded
INFO - 2021-07-03 08:22:36 --> Model "Users_model" initialized
INFO - 2021-07-03 08:22:36 --> Model "Settings_model" initialized
INFO - 2021-07-03 08:22:36 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 08:22:36 --> Model "Permissions_model" initialized
INFO - 2021-07-03 08:22:36 --> Model "Roles_model" initialized
INFO - 2021-07-03 08:22:36 --> Model "Activity_model" initialized
INFO - 2021-07-03 08:22:36 --> Model "Templates_model" initialized
INFO - 2021-07-03 08:22:36 --> Database Driver Class Initialized
INFO - 2021-07-03 08:22:36 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 08:22:36 --> Controller Class Initialized
INFO - 2021-07-03 11:22:36 --> File loaded: C:\wamp64\www\crm\application\views\account/login.php
INFO - 2021-07-03 11:22:36 --> Final output sent to browser
DEBUG - 2021-07-03 11:22:36 --> Total execution time: 0.0635
INFO - 2021-07-03 08:22:36 --> Config Class Initialized
INFO - 2021-07-03 08:22:36 --> Hooks Class Initialized
INFO - 2021-07-03 08:22:36 --> Config Class Initialized
INFO - 2021-07-03 08:22:36 --> Hooks Class Initialized
DEBUG - 2021-07-03 08:22:36 --> UTF-8 Support Enabled
INFO - 2021-07-03 08:22:36 --> Utf8 Class Initialized
DEBUG - 2021-07-03 08:22:36 --> UTF-8 Support Enabled
INFO - 2021-07-03 08:22:36 --> Utf8 Class Initialized
INFO - 2021-07-03 08:22:36 --> URI Class Initialized
INFO - 2021-07-03 08:22:36 --> URI Class Initialized
INFO - 2021-07-03 08:22:36 --> Router Class Initialized
INFO - 2021-07-03 08:22:36 --> Router Class Initialized
INFO - 2021-07-03 08:22:36 --> Output Class Initialized
INFO - 2021-07-03 08:22:36 --> Output Class Initialized
INFO - 2021-07-03 08:22:36 --> Security Class Initialized
INFO - 2021-07-03 08:22:36 --> Security Class Initialized
DEBUG - 2021-07-03 08:22:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-03 08:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 08:22:36 --> Input Class Initialized
INFO - 2021-07-03 08:22:36 --> Input Class Initialized
INFO - 2021-07-03 08:22:36 --> Language Class Initialized
INFO - 2021-07-03 08:22:36 --> Language Class Initialized
ERROR - 2021-07-03 08:22:36 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-07-03 08:22:36 --> 404 Page Not Found: Assets/jquery
INFO - 2021-07-03 08:22:36 --> Config Class Initialized
INFO - 2021-07-03 08:22:36 --> Hooks Class Initialized
DEBUG - 2021-07-03 08:22:36 --> UTF-8 Support Enabled
INFO - 2021-07-03 08:22:36 --> Utf8 Class Initialized
INFO - 2021-07-03 08:22:36 --> URI Class Initialized
INFO - 2021-07-03 08:22:36 --> Router Class Initialized
INFO - 2021-07-03 08:22:36 --> Output Class Initialized
INFO - 2021-07-03 08:22:36 --> Security Class Initialized
DEBUG - 2021-07-03 08:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 08:22:36 --> Input Class Initialized
INFO - 2021-07-03 08:22:36 --> Language Class Initialized
ERROR - 2021-07-03 08:22:36 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-03 08:22:57 --> Config Class Initialized
INFO - 2021-07-03 08:22:57 --> Hooks Class Initialized
DEBUG - 2021-07-03 08:22:57 --> UTF-8 Support Enabled
INFO - 2021-07-03 08:22:57 --> Utf8 Class Initialized
INFO - 2021-07-03 08:22:57 --> URI Class Initialized
INFO - 2021-07-03 08:22:57 --> Router Class Initialized
INFO - 2021-07-03 08:22:57 --> Output Class Initialized
INFO - 2021-07-03 08:22:57 --> Security Class Initialized
DEBUG - 2021-07-03 08:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 08:22:57 --> Input Class Initialized
INFO - 2021-07-03 08:22:57 --> Language Class Initialized
INFO - 2021-07-03 08:22:57 --> Loader Class Initialized
INFO - 2021-07-03 08:22:57 --> Helper loaded: basic_helper
INFO - 2021-07-03 08:22:57 --> Helper loaded: url_helper
INFO - 2021-07-03 08:22:57 --> Helper loaded: file_helper
INFO - 2021-07-03 08:22:57 --> Helper loaded: form_helper
INFO - 2021-07-03 08:22:57 --> Helper loaded: cookie_helper
INFO - 2021-07-03 08:22:57 --> Helper loaded: security_helper
INFO - 2021-07-03 08:22:57 --> Helper loaded: directory_helper
INFO - 2021-07-03 08:22:57 --> Helper loaded: language_helper
INFO - 2021-07-03 08:22:57 --> Helper loaded: general_helper
INFO - 2021-07-03 08:22:57 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 08:22:57 --> Database Driver Class Initialized
DEBUG - 2021-07-03 08:22:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 08:22:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 08:22:57 --> Parser Class Initialized
INFO - 2021-07-03 08:22:57 --> Form Validation Class Initialized
INFO - 2021-07-03 08:22:57 --> Upload Class Initialized
INFO - 2021-07-03 08:22:57 --> Email Class Initialized
INFO - 2021-07-03 08:22:57 --> MY_Model class loaded
INFO - 2021-07-03 08:22:57 --> Model "Users_model" initialized
INFO - 2021-07-03 08:22:57 --> Model "Settings_model" initialized
INFO - 2021-07-03 08:22:57 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 08:22:57 --> Model "Permissions_model" initialized
INFO - 2021-07-03 08:22:57 --> Model "Roles_model" initialized
INFO - 2021-07-03 08:22:57 --> Model "Activity_model" initialized
INFO - 2021-07-03 08:22:57 --> Model "Templates_model" initialized
INFO - 2021-07-03 08:22:57 --> Database Driver Class Initialized
INFO - 2021-07-03 08:22:57 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 08:22:57 --> Controller Class Initialized
DEBUG - 2021-07-03 11:22:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-03 11:22:57 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2021-07-03 11:22:57 --> File loaded: C:\wamp64\www\crm\application\views\account/login.php
INFO - 2021-07-03 11:22:57 --> Final output sent to browser
DEBUG - 2021-07-03 11:22:57 --> Total execution time: 0.1429
INFO - 2021-07-03 08:22:57 --> Config Class Initialized
INFO - 2021-07-03 08:22:57 --> Config Class Initialized
INFO - 2021-07-03 08:22:57 --> Hooks Class Initialized
INFO - 2021-07-03 08:22:57 --> Hooks Class Initialized
DEBUG - 2021-07-03 08:22:57 --> UTF-8 Support Enabled
DEBUG - 2021-07-03 08:22:57 --> UTF-8 Support Enabled
INFO - 2021-07-03 08:22:57 --> Utf8 Class Initialized
INFO - 2021-07-03 08:22:57 --> Utf8 Class Initialized
INFO - 2021-07-03 08:22:57 --> URI Class Initialized
INFO - 2021-07-03 08:22:57 --> URI Class Initialized
INFO - 2021-07-03 08:22:57 --> Router Class Initialized
INFO - 2021-07-03 08:22:57 --> Router Class Initialized
INFO - 2021-07-03 08:22:57 --> Output Class Initialized
INFO - 2021-07-03 08:22:57 --> Output Class Initialized
INFO - 2021-07-03 08:22:57 --> Security Class Initialized
INFO - 2021-07-03 08:22:57 --> Security Class Initialized
DEBUG - 2021-07-03 08:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-03 08:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 08:22:57 --> Input Class Initialized
INFO - 2021-07-03 08:22:57 --> Input Class Initialized
INFO - 2021-07-03 08:22:57 --> Language Class Initialized
INFO - 2021-07-03 08:22:57 --> Language Class Initialized
ERROR - 2021-07-03 08:22:57 --> 404 Page Not Found: Assets/jquery
ERROR - 2021-07-03 08:22:57 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-03 08:22:57 --> Config Class Initialized
INFO - 2021-07-03 08:22:57 --> Hooks Class Initialized
DEBUG - 2021-07-03 08:22:57 --> UTF-8 Support Enabled
INFO - 2021-07-03 08:22:57 --> Utf8 Class Initialized
INFO - 2021-07-03 08:22:57 --> URI Class Initialized
INFO - 2021-07-03 08:22:57 --> Router Class Initialized
INFO - 2021-07-03 08:22:57 --> Output Class Initialized
INFO - 2021-07-03 08:22:57 --> Security Class Initialized
DEBUG - 2021-07-03 08:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 08:22:57 --> Input Class Initialized
INFO - 2021-07-03 08:22:57 --> Language Class Initialized
ERROR - 2021-07-03 08:22:57 --> 404 Page Not Found: Assets/jquery
INFO - 2021-07-03 08:22:57 --> Config Class Initialized
INFO - 2021-07-03 08:22:57 --> Hooks Class Initialized
DEBUG - 2021-07-03 08:22:57 --> UTF-8 Support Enabled
INFO - 2021-07-03 08:22:57 --> Utf8 Class Initialized
INFO - 2021-07-03 08:22:57 --> URI Class Initialized
INFO - 2021-07-03 08:22:57 --> Router Class Initialized
INFO - 2021-07-03 08:22:57 --> Output Class Initialized
INFO - 2021-07-03 08:22:57 --> Security Class Initialized
DEBUG - 2021-07-03 08:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 08:22:57 --> Input Class Initialized
INFO - 2021-07-03 08:22:57 --> Language Class Initialized
ERROR - 2021-07-03 08:22:57 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-03 08:23:07 --> Config Class Initialized
INFO - 2021-07-03 08:23:07 --> Hooks Class Initialized
DEBUG - 2021-07-03 08:23:07 --> UTF-8 Support Enabled
INFO - 2021-07-03 08:23:07 --> Utf8 Class Initialized
INFO - 2021-07-03 08:23:07 --> URI Class Initialized
INFO - 2021-07-03 08:23:07 --> Router Class Initialized
INFO - 2021-07-03 08:23:07 --> Output Class Initialized
INFO - 2021-07-03 08:23:07 --> Security Class Initialized
DEBUG - 2021-07-03 08:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 08:23:07 --> Input Class Initialized
INFO - 2021-07-03 08:23:07 --> Language Class Initialized
INFO - 2021-07-03 08:23:07 --> Loader Class Initialized
INFO - 2021-07-03 08:23:07 --> Helper loaded: basic_helper
INFO - 2021-07-03 08:23:07 --> Helper loaded: url_helper
INFO - 2021-07-03 08:23:07 --> Helper loaded: file_helper
INFO - 2021-07-03 08:23:07 --> Helper loaded: form_helper
INFO - 2021-07-03 08:23:07 --> Helper loaded: cookie_helper
INFO - 2021-07-03 08:23:07 --> Helper loaded: security_helper
INFO - 2021-07-03 08:23:07 --> Helper loaded: directory_helper
INFO - 2021-07-03 08:23:07 --> Helper loaded: language_helper
INFO - 2021-07-03 08:23:07 --> Helper loaded: general_helper
INFO - 2021-07-03 08:23:07 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 08:23:07 --> Database Driver Class Initialized
DEBUG - 2021-07-03 08:23:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 08:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 08:23:07 --> Parser Class Initialized
INFO - 2021-07-03 08:23:07 --> Form Validation Class Initialized
INFO - 2021-07-03 08:23:07 --> Upload Class Initialized
INFO - 2021-07-03 08:23:07 --> Email Class Initialized
INFO - 2021-07-03 08:23:07 --> MY_Model class loaded
INFO - 2021-07-03 08:23:07 --> Model "Users_model" initialized
INFO - 2021-07-03 08:23:07 --> Model "Settings_model" initialized
INFO - 2021-07-03 08:23:07 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 08:23:07 --> Model "Permissions_model" initialized
INFO - 2021-07-03 08:23:07 --> Model "Roles_model" initialized
INFO - 2021-07-03 08:23:07 --> Model "Activity_model" initialized
INFO - 2021-07-03 08:23:07 --> Model "Templates_model" initialized
INFO - 2021-07-03 08:23:07 --> Database Driver Class Initialized
INFO - 2021-07-03 08:23:07 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 08:23:07 --> Controller Class Initialized
DEBUG - 2021-07-03 11:23:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-03 11:23:07 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2021-07-03 08:23:07 --> Config Class Initialized
INFO - 2021-07-03 08:23:07 --> Hooks Class Initialized
DEBUG - 2021-07-03 08:23:07 --> UTF-8 Support Enabled
INFO - 2021-07-03 08:23:07 --> Utf8 Class Initialized
INFO - 2021-07-03 08:23:07 --> URI Class Initialized
DEBUG - 2021-07-03 08:23:07 --> No URI present. Default controller set.
INFO - 2021-07-03 08:23:07 --> Router Class Initialized
INFO - 2021-07-03 08:23:07 --> Output Class Initialized
INFO - 2021-07-03 08:23:07 --> Security Class Initialized
DEBUG - 2021-07-03 08:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 08:23:07 --> Input Class Initialized
INFO - 2021-07-03 08:23:07 --> Language Class Initialized
INFO - 2021-07-03 08:23:07 --> Loader Class Initialized
INFO - 2021-07-03 08:23:07 --> Helper loaded: basic_helper
INFO - 2021-07-03 08:23:07 --> Helper loaded: url_helper
INFO - 2021-07-03 08:23:07 --> Helper loaded: file_helper
INFO - 2021-07-03 08:23:07 --> Helper loaded: form_helper
INFO - 2021-07-03 08:23:07 --> Helper loaded: cookie_helper
INFO - 2021-07-03 08:23:07 --> Helper loaded: security_helper
INFO - 2021-07-03 08:23:07 --> Helper loaded: directory_helper
INFO - 2021-07-03 08:23:07 --> Helper loaded: language_helper
INFO - 2021-07-03 08:23:07 --> Helper loaded: general_helper
INFO - 2021-07-03 08:23:07 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 08:23:07 --> Database Driver Class Initialized
DEBUG - 2021-07-03 08:23:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 08:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 08:23:07 --> Parser Class Initialized
INFO - 2021-07-03 08:23:07 --> Form Validation Class Initialized
INFO - 2021-07-03 08:23:07 --> Upload Class Initialized
INFO - 2021-07-03 08:23:07 --> Email Class Initialized
INFO - 2021-07-03 08:23:07 --> MY_Model class loaded
INFO - 2021-07-03 08:23:07 --> Model "Users_model" initialized
INFO - 2021-07-03 08:23:07 --> Model "Settings_model" initialized
INFO - 2021-07-03 08:23:07 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 08:23:07 --> Model "Permissions_model" initialized
INFO - 2021-07-03 08:23:07 --> Model "Roles_model" initialized
INFO - 2021-07-03 08:23:07 --> Model "Activity_model" initialized
INFO - 2021-07-03 08:23:07 --> Model "Templates_model" initialized
INFO - 2021-07-03 08:23:07 --> Database Driver Class Initialized
INFO - 2021-07-03 08:23:07 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 08:23:07 --> Controller Class Initialized
ERROR - 2021-07-03 11:23:07 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 11:23:07 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-03 11:23:07 --> Final output sent to browser
DEBUG - 2021-07-03 11:23:07 --> Total execution time: 0.0728
INFO - 2021-07-03 08:23:15 --> Config Class Initialized
INFO - 2021-07-03 08:23:15 --> Hooks Class Initialized
DEBUG - 2021-07-03 08:23:15 --> UTF-8 Support Enabled
INFO - 2021-07-03 08:23:15 --> Utf8 Class Initialized
INFO - 2021-07-03 08:23:15 --> URI Class Initialized
INFO - 2021-07-03 08:23:15 --> Router Class Initialized
INFO - 2021-07-03 08:23:15 --> Output Class Initialized
INFO - 2021-07-03 08:23:15 --> Security Class Initialized
DEBUG - 2021-07-03 08:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 08:23:15 --> Input Class Initialized
INFO - 2021-07-03 08:23:15 --> Language Class Initialized
INFO - 2021-07-03 08:23:15 --> Loader Class Initialized
INFO - 2021-07-03 08:23:15 --> Helper loaded: basic_helper
INFO - 2021-07-03 08:23:15 --> Helper loaded: url_helper
INFO - 2021-07-03 08:23:15 --> Helper loaded: file_helper
INFO - 2021-07-03 08:23:15 --> Helper loaded: form_helper
INFO - 2021-07-03 08:23:15 --> Helper loaded: cookie_helper
INFO - 2021-07-03 08:23:15 --> Helper loaded: security_helper
INFO - 2021-07-03 08:23:15 --> Helper loaded: directory_helper
INFO - 2021-07-03 08:23:15 --> Helper loaded: language_helper
INFO - 2021-07-03 08:23:15 --> Helper loaded: general_helper
INFO - 2021-07-03 08:23:15 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 08:23:15 --> Database Driver Class Initialized
DEBUG - 2021-07-03 08:23:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 08:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 08:23:15 --> Parser Class Initialized
INFO - 2021-07-03 08:23:15 --> Form Validation Class Initialized
INFO - 2021-07-03 08:23:15 --> Upload Class Initialized
INFO - 2021-07-03 08:23:15 --> Email Class Initialized
INFO - 2021-07-03 08:23:15 --> MY_Model class loaded
INFO - 2021-07-03 08:23:15 --> Model "Users_model" initialized
INFO - 2021-07-03 08:23:15 --> Model "Settings_model" initialized
INFO - 2021-07-03 08:23:15 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 08:23:15 --> Model "Permissions_model" initialized
INFO - 2021-07-03 08:23:15 --> Model "Roles_model" initialized
INFO - 2021-07-03 08:23:15 --> Model "Activity_model" initialized
INFO - 2021-07-03 08:23:15 --> Model "Templates_model" initialized
INFO - 2021-07-03 08:23:15 --> Database Driver Class Initialized
INFO - 2021-07-03 08:23:15 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 08:23:15 --> Controller Class Initialized
ERROR - 2021-07-03 11:23:15 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 11:23:15 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-03 11:23:15 --> Final output sent to browser
DEBUG - 2021-07-03 11:23:15 --> Total execution time: 0.2492
INFO - 2021-07-03 08:23:26 --> Config Class Initialized
INFO - 2021-07-03 08:23:26 --> Hooks Class Initialized
DEBUG - 2021-07-03 08:23:26 --> UTF-8 Support Enabled
INFO - 2021-07-03 08:23:26 --> Utf8 Class Initialized
INFO - 2021-07-03 08:23:26 --> URI Class Initialized
INFO - 2021-07-03 08:23:26 --> Router Class Initialized
INFO - 2021-07-03 08:23:26 --> Output Class Initialized
INFO - 2021-07-03 08:23:26 --> Security Class Initialized
DEBUG - 2021-07-03 08:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 08:23:26 --> Input Class Initialized
INFO - 2021-07-03 08:23:26 --> Language Class Initialized
INFO - 2021-07-03 08:23:26 --> Loader Class Initialized
INFO - 2021-07-03 08:23:26 --> Helper loaded: basic_helper
INFO - 2021-07-03 08:23:26 --> Helper loaded: url_helper
INFO - 2021-07-03 08:23:26 --> Helper loaded: file_helper
INFO - 2021-07-03 08:23:26 --> Helper loaded: form_helper
INFO - 2021-07-03 08:23:26 --> Helper loaded: cookie_helper
INFO - 2021-07-03 08:23:26 --> Helper loaded: security_helper
INFO - 2021-07-03 08:23:26 --> Helper loaded: directory_helper
INFO - 2021-07-03 08:23:26 --> Helper loaded: language_helper
INFO - 2021-07-03 08:23:26 --> Helper loaded: general_helper
INFO - 2021-07-03 08:23:26 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 08:23:26 --> Database Driver Class Initialized
DEBUG - 2021-07-03 08:23:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 08:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 08:23:26 --> Parser Class Initialized
INFO - 2021-07-03 08:23:26 --> Form Validation Class Initialized
INFO - 2021-07-03 08:23:26 --> Upload Class Initialized
INFO - 2021-07-03 08:23:26 --> Email Class Initialized
INFO - 2021-07-03 08:23:26 --> MY_Model class loaded
INFO - 2021-07-03 08:23:26 --> Model "Users_model" initialized
INFO - 2021-07-03 08:23:26 --> Model "Settings_model" initialized
INFO - 2021-07-03 08:23:26 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 08:23:26 --> Model "Permissions_model" initialized
INFO - 2021-07-03 08:23:26 --> Model "Roles_model" initialized
INFO - 2021-07-03 08:23:26 --> Model "Activity_model" initialized
INFO - 2021-07-03 08:23:26 --> Model "Templates_model" initialized
INFO - 2021-07-03 08:23:26 --> Database Driver Class Initialized
INFO - 2021-07-03 08:23:26 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 08:23:26 --> Controller Class Initialized
ERROR - 2021-07-03 11:23:26 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 11:23:26 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-03 11:23:26 --> Final output sent to browser
DEBUG - 2021-07-03 11:23:26 --> Total execution time: 0.1365
INFO - 2021-07-03 08:23:34 --> Config Class Initialized
INFO - 2021-07-03 08:23:34 --> Hooks Class Initialized
DEBUG - 2021-07-03 08:23:34 --> UTF-8 Support Enabled
INFO - 2021-07-03 08:23:34 --> Utf8 Class Initialized
INFO - 2021-07-03 08:23:34 --> URI Class Initialized
INFO - 2021-07-03 08:23:34 --> Router Class Initialized
INFO - 2021-07-03 08:23:34 --> Output Class Initialized
INFO - 2021-07-03 08:23:34 --> Security Class Initialized
DEBUG - 2021-07-03 08:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 08:23:34 --> Input Class Initialized
INFO - 2021-07-03 08:23:34 --> Language Class Initialized
INFO - 2021-07-03 08:23:34 --> Loader Class Initialized
INFO - 2021-07-03 08:23:34 --> Helper loaded: basic_helper
INFO - 2021-07-03 08:23:34 --> Helper loaded: url_helper
INFO - 2021-07-03 08:23:34 --> Helper loaded: file_helper
INFO - 2021-07-03 08:23:34 --> Helper loaded: form_helper
INFO - 2021-07-03 08:23:34 --> Helper loaded: cookie_helper
INFO - 2021-07-03 08:23:34 --> Helper loaded: security_helper
INFO - 2021-07-03 08:23:34 --> Helper loaded: directory_helper
INFO - 2021-07-03 08:23:34 --> Helper loaded: language_helper
INFO - 2021-07-03 08:23:34 --> Helper loaded: general_helper
INFO - 2021-07-03 08:23:34 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 08:23:34 --> Database Driver Class Initialized
DEBUG - 2021-07-03 08:23:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 08:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 08:23:34 --> Parser Class Initialized
INFO - 2021-07-03 08:23:34 --> Form Validation Class Initialized
INFO - 2021-07-03 08:23:34 --> Upload Class Initialized
INFO - 2021-07-03 08:23:34 --> Email Class Initialized
INFO - 2021-07-03 08:23:34 --> MY_Model class loaded
INFO - 2021-07-03 08:23:34 --> Model "Users_model" initialized
INFO - 2021-07-03 08:23:34 --> Model "Settings_model" initialized
INFO - 2021-07-03 08:23:34 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 08:23:34 --> Model "Permissions_model" initialized
INFO - 2021-07-03 08:23:34 --> Model "Roles_model" initialized
INFO - 2021-07-03 08:23:34 --> Model "Activity_model" initialized
INFO - 2021-07-03 08:23:34 --> Model "Templates_model" initialized
INFO - 2021-07-03 08:23:34 --> Database Driver Class Initialized
INFO - 2021-07-03 08:23:34 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 08:23:34 --> Controller Class Initialized
ERROR - 2021-07-03 11:23:34 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 11:23:34 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-03 11:23:34 --> Final output sent to browser
DEBUG - 2021-07-03 11:23:34 --> Total execution time: 0.1321
INFO - 2021-07-03 08:23:36 --> Config Class Initialized
INFO - 2021-07-03 08:23:36 --> Hooks Class Initialized
DEBUG - 2021-07-03 08:23:36 --> UTF-8 Support Enabled
INFO - 2021-07-03 08:23:36 --> Utf8 Class Initialized
INFO - 2021-07-03 08:23:36 --> URI Class Initialized
INFO - 2021-07-03 08:23:36 --> Router Class Initialized
INFO - 2021-07-03 08:23:36 --> Output Class Initialized
INFO - 2021-07-03 08:23:36 --> Security Class Initialized
DEBUG - 2021-07-03 08:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 08:23:36 --> Input Class Initialized
INFO - 2021-07-03 08:23:36 --> Language Class Initialized
INFO - 2021-07-03 08:23:36 --> Loader Class Initialized
INFO - 2021-07-03 08:23:36 --> Helper loaded: basic_helper
INFO - 2021-07-03 08:23:36 --> Helper loaded: url_helper
INFO - 2021-07-03 08:23:36 --> Helper loaded: file_helper
INFO - 2021-07-03 08:23:36 --> Helper loaded: form_helper
INFO - 2021-07-03 08:23:36 --> Helper loaded: cookie_helper
INFO - 2021-07-03 08:23:36 --> Helper loaded: security_helper
INFO - 2021-07-03 08:23:36 --> Helper loaded: directory_helper
INFO - 2021-07-03 08:23:36 --> Helper loaded: language_helper
INFO - 2021-07-03 08:23:36 --> Helper loaded: general_helper
INFO - 2021-07-03 08:23:36 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 08:23:36 --> Database Driver Class Initialized
DEBUG - 2021-07-03 08:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 08:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 08:23:36 --> Parser Class Initialized
INFO - 2021-07-03 08:23:36 --> Form Validation Class Initialized
INFO - 2021-07-03 08:23:36 --> Upload Class Initialized
INFO - 2021-07-03 08:23:36 --> Email Class Initialized
INFO - 2021-07-03 08:23:36 --> MY_Model class loaded
INFO - 2021-07-03 08:23:36 --> Model "Users_model" initialized
INFO - 2021-07-03 08:23:36 --> Model "Settings_model" initialized
INFO - 2021-07-03 08:23:36 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 08:23:36 --> Model "Permissions_model" initialized
INFO - 2021-07-03 08:23:36 --> Model "Roles_model" initialized
INFO - 2021-07-03 08:23:36 --> Model "Activity_model" initialized
INFO - 2021-07-03 08:23:36 --> Model "Templates_model" initialized
INFO - 2021-07-03 08:23:36 --> Database Driver Class Initialized
INFO - 2021-07-03 08:23:36 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 08:23:36 --> Controller Class Initialized
ERROR - 2021-07-03 11:23:36 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 11:23:36 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-03 11:23:36 --> Final output sent to browser
DEBUG - 2021-07-03 11:23:36 --> Total execution time: 0.0989
INFO - 2021-07-03 08:23:39 --> Config Class Initialized
INFO - 2021-07-03 08:23:39 --> Hooks Class Initialized
DEBUG - 2021-07-03 08:23:39 --> UTF-8 Support Enabled
INFO - 2021-07-03 08:23:39 --> Utf8 Class Initialized
INFO - 2021-07-03 08:23:39 --> URI Class Initialized
INFO - 2021-07-03 08:23:39 --> Router Class Initialized
INFO - 2021-07-03 08:23:39 --> Output Class Initialized
INFO - 2021-07-03 08:23:39 --> Security Class Initialized
DEBUG - 2021-07-03 08:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 08:23:39 --> Input Class Initialized
INFO - 2021-07-03 08:23:39 --> Language Class Initialized
INFO - 2021-07-03 08:23:39 --> Loader Class Initialized
INFO - 2021-07-03 08:23:39 --> Helper loaded: basic_helper
INFO - 2021-07-03 08:23:39 --> Helper loaded: url_helper
INFO - 2021-07-03 08:23:39 --> Helper loaded: file_helper
INFO - 2021-07-03 08:23:39 --> Helper loaded: form_helper
INFO - 2021-07-03 08:23:39 --> Helper loaded: cookie_helper
INFO - 2021-07-03 08:23:39 --> Helper loaded: security_helper
INFO - 2021-07-03 08:23:39 --> Helper loaded: directory_helper
INFO - 2021-07-03 08:23:39 --> Helper loaded: language_helper
INFO - 2021-07-03 08:23:39 --> Helper loaded: general_helper
INFO - 2021-07-03 08:23:39 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 08:23:39 --> Database Driver Class Initialized
DEBUG - 2021-07-03 08:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 08:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 08:23:39 --> Parser Class Initialized
INFO - 2021-07-03 08:23:39 --> Form Validation Class Initialized
INFO - 2021-07-03 08:23:39 --> Upload Class Initialized
INFO - 2021-07-03 08:23:39 --> Email Class Initialized
INFO - 2021-07-03 08:23:39 --> MY_Model class loaded
INFO - 2021-07-03 08:23:39 --> Model "Users_model" initialized
INFO - 2021-07-03 08:23:39 --> Model "Settings_model" initialized
INFO - 2021-07-03 08:23:39 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 08:23:39 --> Model "Permissions_model" initialized
INFO - 2021-07-03 08:23:39 --> Model "Roles_model" initialized
INFO - 2021-07-03 08:23:39 --> Model "Activity_model" initialized
INFO - 2021-07-03 08:23:39 --> Model "Templates_model" initialized
INFO - 2021-07-03 08:23:39 --> Database Driver Class Initialized
INFO - 2021-07-03 08:23:39 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 08:23:39 --> Controller Class Initialized
ERROR - 2021-07-03 11:23:39 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 11:23:40 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-03 11:23:40 --> Final output sent to browser
DEBUG - 2021-07-03 11:23:40 --> Total execution time: 0.8647
INFO - 2021-07-03 08:23:42 --> Config Class Initialized
INFO - 2021-07-03 08:23:42 --> Hooks Class Initialized
DEBUG - 2021-07-03 08:23:42 --> UTF-8 Support Enabled
INFO - 2021-07-03 08:23:42 --> Utf8 Class Initialized
INFO - 2021-07-03 08:23:42 --> URI Class Initialized
INFO - 2021-07-03 08:23:42 --> Router Class Initialized
INFO - 2021-07-03 08:23:42 --> Output Class Initialized
INFO - 2021-07-03 08:23:42 --> Security Class Initialized
DEBUG - 2021-07-03 08:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 08:23:42 --> Input Class Initialized
INFO - 2021-07-03 08:23:42 --> Language Class Initialized
INFO - 2021-07-03 08:23:42 --> Loader Class Initialized
INFO - 2021-07-03 08:23:42 --> Helper loaded: basic_helper
INFO - 2021-07-03 08:23:42 --> Helper loaded: url_helper
INFO - 2021-07-03 08:23:42 --> Helper loaded: file_helper
INFO - 2021-07-03 08:23:42 --> Helper loaded: form_helper
INFO - 2021-07-03 08:23:42 --> Helper loaded: cookie_helper
INFO - 2021-07-03 08:23:42 --> Helper loaded: security_helper
INFO - 2021-07-03 08:23:42 --> Helper loaded: directory_helper
INFO - 2021-07-03 08:23:42 --> Helper loaded: language_helper
INFO - 2021-07-03 08:23:42 --> Helper loaded: general_helper
INFO - 2021-07-03 08:23:42 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 08:23:42 --> Database Driver Class Initialized
DEBUG - 2021-07-03 08:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 08:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 08:23:42 --> Parser Class Initialized
INFO - 2021-07-03 08:23:42 --> Form Validation Class Initialized
INFO - 2021-07-03 08:23:42 --> Upload Class Initialized
INFO - 2021-07-03 08:23:42 --> Email Class Initialized
INFO - 2021-07-03 08:23:42 --> MY_Model class loaded
INFO - 2021-07-03 08:23:42 --> Model "Users_model" initialized
INFO - 2021-07-03 08:23:42 --> Model "Settings_model" initialized
INFO - 2021-07-03 08:23:42 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 08:23:42 --> Model "Permissions_model" initialized
INFO - 2021-07-03 08:23:42 --> Model "Roles_model" initialized
INFO - 2021-07-03 08:23:42 --> Model "Activity_model" initialized
INFO - 2021-07-03 08:23:42 --> Model "Templates_model" initialized
INFO - 2021-07-03 08:23:42 --> Database Driver Class Initialized
INFO - 2021-07-03 08:23:42 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 08:23:42 --> Controller Class Initialized
ERROR - 2021-07-03 11:23:42 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 11:23:42 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-03 11:23:42 --> Final output sent to browser
DEBUG - 2021-07-03 11:23:42 --> Total execution time: 0.0716
INFO - 2021-07-03 08:23:43 --> Config Class Initialized
INFO - 2021-07-03 08:23:43 --> Hooks Class Initialized
DEBUG - 2021-07-03 08:23:43 --> UTF-8 Support Enabled
INFO - 2021-07-03 08:23:43 --> Utf8 Class Initialized
INFO - 2021-07-03 08:23:43 --> URI Class Initialized
INFO - 2021-07-03 08:23:43 --> Router Class Initialized
INFO - 2021-07-03 08:23:43 --> Output Class Initialized
INFO - 2021-07-03 08:23:43 --> Security Class Initialized
DEBUG - 2021-07-03 08:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 08:23:43 --> Input Class Initialized
INFO - 2021-07-03 08:23:43 --> Language Class Initialized
INFO - 2021-07-03 08:23:43 --> Loader Class Initialized
INFO - 2021-07-03 08:23:43 --> Helper loaded: basic_helper
INFO - 2021-07-03 08:23:43 --> Helper loaded: url_helper
INFO - 2021-07-03 08:23:43 --> Helper loaded: file_helper
INFO - 2021-07-03 08:23:43 --> Helper loaded: form_helper
INFO - 2021-07-03 08:23:43 --> Helper loaded: cookie_helper
INFO - 2021-07-03 08:23:43 --> Helper loaded: security_helper
INFO - 2021-07-03 08:23:43 --> Helper loaded: directory_helper
INFO - 2021-07-03 08:23:43 --> Helper loaded: language_helper
INFO - 2021-07-03 08:23:43 --> Helper loaded: general_helper
INFO - 2021-07-03 08:23:43 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 08:23:43 --> Database Driver Class Initialized
DEBUG - 2021-07-03 08:23:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 08:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 08:23:43 --> Parser Class Initialized
INFO - 2021-07-03 08:23:43 --> Form Validation Class Initialized
INFO - 2021-07-03 08:23:43 --> Upload Class Initialized
INFO - 2021-07-03 08:23:43 --> Email Class Initialized
INFO - 2021-07-03 08:23:43 --> MY_Model class loaded
INFO - 2021-07-03 08:23:43 --> Model "Users_model" initialized
INFO - 2021-07-03 08:23:43 --> Model "Settings_model" initialized
INFO - 2021-07-03 08:23:43 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 08:23:43 --> Model "Permissions_model" initialized
INFO - 2021-07-03 08:23:43 --> Model "Roles_model" initialized
INFO - 2021-07-03 08:23:43 --> Model "Activity_model" initialized
INFO - 2021-07-03 08:23:43 --> Model "Templates_model" initialized
INFO - 2021-07-03 08:23:43 --> Database Driver Class Initialized
INFO - 2021-07-03 08:23:44 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 08:23:44 --> Controller Class Initialized
ERROR - 2021-07-03 11:23:44 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 11:23:44 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-03 11:23:44 --> Final output sent to browser
DEBUG - 2021-07-03 11:23:44 --> Total execution time: 0.5372
INFO - 2021-07-03 08:23:47 --> Config Class Initialized
INFO - 2021-07-03 08:23:47 --> Hooks Class Initialized
DEBUG - 2021-07-03 08:23:47 --> UTF-8 Support Enabled
INFO - 2021-07-03 08:23:47 --> Utf8 Class Initialized
INFO - 2021-07-03 08:23:47 --> URI Class Initialized
INFO - 2021-07-03 08:23:47 --> Router Class Initialized
INFO - 2021-07-03 08:23:47 --> Output Class Initialized
INFO - 2021-07-03 08:23:47 --> Security Class Initialized
DEBUG - 2021-07-03 08:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 08:23:47 --> Input Class Initialized
INFO - 2021-07-03 08:23:47 --> Language Class Initialized
INFO - 2021-07-03 08:23:47 --> Loader Class Initialized
INFO - 2021-07-03 08:23:47 --> Helper loaded: basic_helper
INFO - 2021-07-03 08:23:47 --> Helper loaded: url_helper
INFO - 2021-07-03 08:23:47 --> Helper loaded: file_helper
INFO - 2021-07-03 08:23:47 --> Helper loaded: form_helper
INFO - 2021-07-03 08:23:47 --> Helper loaded: cookie_helper
INFO - 2021-07-03 08:23:47 --> Helper loaded: security_helper
INFO - 2021-07-03 08:23:47 --> Helper loaded: directory_helper
INFO - 2021-07-03 08:23:47 --> Helper loaded: language_helper
INFO - 2021-07-03 08:23:47 --> Helper loaded: general_helper
INFO - 2021-07-03 08:23:47 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 08:23:47 --> Database Driver Class Initialized
DEBUG - 2021-07-03 08:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 08:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 08:23:47 --> Parser Class Initialized
INFO - 2021-07-03 08:23:47 --> Form Validation Class Initialized
INFO - 2021-07-03 08:23:47 --> Upload Class Initialized
INFO - 2021-07-03 08:23:47 --> Email Class Initialized
INFO - 2021-07-03 08:23:47 --> MY_Model class loaded
INFO - 2021-07-03 08:23:47 --> Model "Users_model" initialized
INFO - 2021-07-03 08:23:47 --> Model "Settings_model" initialized
INFO - 2021-07-03 08:23:47 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 08:23:47 --> Model "Permissions_model" initialized
INFO - 2021-07-03 08:23:47 --> Model "Roles_model" initialized
INFO - 2021-07-03 08:23:47 --> Model "Activity_model" initialized
INFO - 2021-07-03 08:23:47 --> Model "Templates_model" initialized
INFO - 2021-07-03 08:23:47 --> Database Driver Class Initialized
INFO - 2021-07-03 08:23:47 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 08:23:47 --> Controller Class Initialized
ERROR - 2021-07-03 11:23:47 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 11:23:47 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-03 11:23:47 --> Final output sent to browser
DEBUG - 2021-07-03 11:23:47 --> Total execution time: 0.2293
INFO - 2021-07-03 08:24:00 --> Config Class Initialized
INFO - 2021-07-03 08:24:00 --> Hooks Class Initialized
DEBUG - 2021-07-03 08:24:00 --> UTF-8 Support Enabled
INFO - 2021-07-03 08:24:00 --> Utf8 Class Initialized
INFO - 2021-07-03 08:24:00 --> URI Class Initialized
INFO - 2021-07-03 08:24:00 --> Router Class Initialized
INFO - 2021-07-03 08:24:00 --> Output Class Initialized
INFO - 2021-07-03 08:24:00 --> Security Class Initialized
DEBUG - 2021-07-03 08:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 08:24:00 --> Input Class Initialized
INFO - 2021-07-03 08:24:00 --> Language Class Initialized
INFO - 2021-07-03 08:24:00 --> Loader Class Initialized
INFO - 2021-07-03 08:24:00 --> Helper loaded: basic_helper
INFO - 2021-07-03 08:24:00 --> Helper loaded: url_helper
INFO - 2021-07-03 08:24:00 --> Helper loaded: file_helper
INFO - 2021-07-03 08:24:00 --> Helper loaded: form_helper
INFO - 2021-07-03 08:24:00 --> Helper loaded: cookie_helper
INFO - 2021-07-03 08:24:00 --> Helper loaded: security_helper
INFO - 2021-07-03 08:24:00 --> Helper loaded: directory_helper
INFO - 2021-07-03 08:24:00 --> Helper loaded: language_helper
INFO - 2021-07-03 08:24:00 --> Helper loaded: general_helper
INFO - 2021-07-03 08:24:00 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 08:24:00 --> Database Driver Class Initialized
DEBUG - 2021-07-03 08:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 08:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 08:24:00 --> Parser Class Initialized
INFO - 2021-07-03 08:24:00 --> Form Validation Class Initialized
INFO - 2021-07-03 08:24:00 --> Upload Class Initialized
INFO - 2021-07-03 08:24:00 --> Email Class Initialized
INFO - 2021-07-03 08:24:00 --> MY_Model class loaded
INFO - 2021-07-03 08:24:00 --> Model "Users_model" initialized
INFO - 2021-07-03 08:24:00 --> Model "Settings_model" initialized
INFO - 2021-07-03 08:24:00 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 08:24:00 --> Model "Permissions_model" initialized
INFO - 2021-07-03 08:24:00 --> Model "Roles_model" initialized
INFO - 2021-07-03 08:24:00 --> Model "Activity_model" initialized
INFO - 2021-07-03 08:24:00 --> Model "Templates_model" initialized
INFO - 2021-07-03 08:24:00 --> Database Driver Class Initialized
INFO - 2021-07-03 08:24:00 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 08:24:00 --> Controller Class Initialized
ERROR - 2021-07-03 11:24:00 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 11:24:00 --> File loaded: C:\wamp64\www\crm\application\views\activity_logs/list.php
INFO - 2021-07-03 11:24:00 --> Final output sent to browser
DEBUG - 2021-07-03 11:24:00 --> Total execution time: 0.1913
INFO - 2021-07-03 08:28:03 --> Config Class Initialized
INFO - 2021-07-03 08:28:03 --> Hooks Class Initialized
DEBUG - 2021-07-03 08:28:03 --> UTF-8 Support Enabled
INFO - 2021-07-03 08:28:03 --> Utf8 Class Initialized
INFO - 2021-07-03 08:28:03 --> URI Class Initialized
DEBUG - 2021-07-03 08:28:03 --> No URI present. Default controller set.
INFO - 2021-07-03 08:28:03 --> Router Class Initialized
INFO - 2021-07-03 08:28:03 --> Output Class Initialized
INFO - 2021-07-03 08:28:03 --> Security Class Initialized
DEBUG - 2021-07-03 08:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 08:28:03 --> Input Class Initialized
INFO - 2021-07-03 08:28:03 --> Language Class Initialized
INFO - 2021-07-03 08:28:03 --> Loader Class Initialized
INFO - 2021-07-03 08:28:03 --> Helper loaded: basic_helper
INFO - 2021-07-03 08:28:03 --> Helper loaded: url_helper
INFO - 2021-07-03 08:28:03 --> Helper loaded: file_helper
INFO - 2021-07-03 08:28:03 --> Helper loaded: form_helper
INFO - 2021-07-03 08:28:03 --> Helper loaded: cookie_helper
INFO - 2021-07-03 08:28:03 --> Helper loaded: security_helper
INFO - 2021-07-03 08:28:03 --> Helper loaded: directory_helper
INFO - 2021-07-03 08:28:03 --> Helper loaded: language_helper
INFO - 2021-07-03 08:28:03 --> Helper loaded: general_helper
INFO - 2021-07-03 08:28:03 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 08:28:03 --> Database Driver Class Initialized
DEBUG - 2021-07-03 08:28:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 08:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 08:28:03 --> Parser Class Initialized
INFO - 2021-07-03 08:28:03 --> Form Validation Class Initialized
INFO - 2021-07-03 08:28:03 --> Upload Class Initialized
INFO - 2021-07-03 08:28:03 --> Email Class Initialized
INFO - 2021-07-03 08:28:03 --> MY_Model class loaded
INFO - 2021-07-03 08:28:03 --> Model "Users_model" initialized
INFO - 2021-07-03 08:28:03 --> Model "Settings_model" initialized
INFO - 2021-07-03 08:28:03 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 08:28:03 --> Model "Permissions_model" initialized
INFO - 2021-07-03 08:28:03 --> Model "Roles_model" initialized
INFO - 2021-07-03 08:28:03 --> Model "Activity_model" initialized
INFO - 2021-07-03 08:28:03 --> Model "Templates_model" initialized
INFO - 2021-07-03 08:28:03 --> Database Driver Class Initialized
INFO - 2021-07-03 08:28:03 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 08:28:03 --> Controller Class Initialized
INFO - 2021-07-03 08:33:22 --> Config Class Initialized
INFO - 2021-07-03 08:33:22 --> Hooks Class Initialized
DEBUG - 2021-07-03 08:33:22 --> UTF-8 Support Enabled
INFO - 2021-07-03 08:33:22 --> Utf8 Class Initialized
INFO - 2021-07-03 08:33:22 --> URI Class Initialized
INFO - 2021-07-03 08:33:22 --> Router Class Initialized
INFO - 2021-07-03 08:33:22 --> Output Class Initialized
INFO - 2021-07-03 08:33:22 --> Security Class Initialized
DEBUG - 2021-07-03 08:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 08:33:22 --> Input Class Initialized
INFO - 2021-07-03 08:33:22 --> Language Class Initialized
INFO - 2021-07-03 08:33:22 --> Loader Class Initialized
INFO - 2021-07-03 08:33:22 --> Helper loaded: basic_helper
INFO - 2021-07-03 08:33:22 --> Helper loaded: url_helper
INFO - 2021-07-03 08:33:22 --> Helper loaded: file_helper
INFO - 2021-07-03 08:33:22 --> Helper loaded: form_helper
INFO - 2021-07-03 08:33:22 --> Helper loaded: cookie_helper
INFO - 2021-07-03 08:33:22 --> Helper loaded: security_helper
INFO - 2021-07-03 08:33:22 --> Helper loaded: directory_helper
INFO - 2021-07-03 08:33:22 --> Helper loaded: language_helper
INFO - 2021-07-03 08:33:22 --> Helper loaded: general_helper
INFO - 2021-07-03 08:33:22 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 08:33:22 --> Database Driver Class Initialized
DEBUG - 2021-07-03 08:33:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 08:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 08:33:22 --> Parser Class Initialized
INFO - 2021-07-03 08:33:22 --> Form Validation Class Initialized
INFO - 2021-07-03 08:33:22 --> Upload Class Initialized
INFO - 2021-07-03 08:33:22 --> Email Class Initialized
INFO - 2021-07-03 08:33:22 --> MY_Model class loaded
INFO - 2021-07-03 08:33:22 --> Model "Users_model" initialized
INFO - 2021-07-03 08:33:22 --> Model "Settings_model" initialized
INFO - 2021-07-03 08:33:22 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 08:33:22 --> Model "Permissions_model" initialized
INFO - 2021-07-03 08:33:22 --> Model "Roles_model" initialized
INFO - 2021-07-03 08:33:22 --> Model "Activity_model" initialized
INFO - 2021-07-03 08:33:22 --> Model "Templates_model" initialized
INFO - 2021-07-03 08:33:22 --> Database Driver Class Initialized
INFO - 2021-07-03 08:33:22 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 08:33:22 --> Controller Class Initialized
ERROR - 2021-07-03 11:33:22 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 11:33:22 --> File loaded: C:\wamp64\www\crm\application\views\users/list.php
INFO - 2021-07-03 11:33:22 --> Final output sent to browser
DEBUG - 2021-07-03 11:33:22 --> Total execution time: 0.1773
INFO - 2021-07-03 08:33:22 --> Config Class Initialized
INFO - 2021-07-03 08:33:22 --> Hooks Class Initialized
DEBUG - 2021-07-03 08:33:22 --> UTF-8 Support Enabled
INFO - 2021-07-03 08:33:22 --> Utf8 Class Initialized
INFO - 2021-07-03 08:33:22 --> Config Class Initialized
INFO - 2021-07-03 08:33:22 --> URI Class Initialized
INFO - 2021-07-03 08:33:22 --> Hooks Class Initialized
DEBUG - 2021-07-03 08:33:22 --> UTF-8 Support Enabled
INFO - 2021-07-03 08:33:22 --> Router Class Initialized
INFO - 2021-07-03 08:33:22 --> Utf8 Class Initialized
INFO - 2021-07-03 08:33:22 --> URI Class Initialized
INFO - 2021-07-03 08:33:22 --> Output Class Initialized
INFO - 2021-07-03 08:33:22 --> Security Class Initialized
INFO - 2021-07-03 08:33:22 --> Router Class Initialized
DEBUG - 2021-07-03 08:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 08:33:22 --> Output Class Initialized
INFO - 2021-07-03 08:33:22 --> Input Class Initialized
INFO - 2021-07-03 08:33:22 --> Security Class Initialized
INFO - 2021-07-03 08:33:22 --> Language Class Initialized
INFO - 2021-07-03 08:33:22 --> Config Class Initialized
DEBUG - 2021-07-03 08:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 08:33:22 --> Hooks Class Initialized
INFO - 2021-07-03 08:33:22 --> Loader Class Initialized
INFO - 2021-07-03 08:33:22 --> Input Class Initialized
DEBUG - 2021-07-03 08:33:22 --> UTF-8 Support Enabled
INFO - 2021-07-03 08:33:22 --> Language Class Initialized
INFO - 2021-07-03 08:33:22 --> Helper loaded: basic_helper
INFO - 2021-07-03 08:33:22 --> Utf8 Class Initialized
INFO - 2021-07-03 08:33:22 --> Loader Class Initialized
INFO - 2021-07-03 08:33:22 --> Helper loaded: url_helper
INFO - 2021-07-03 08:33:22 --> URI Class Initialized
INFO - 2021-07-03 08:33:22 --> Config Class Initialized
INFO - 2021-07-03 08:33:22 --> Helper loaded: file_helper
INFO - 2021-07-03 08:33:22 --> Helper loaded: basic_helper
INFO - 2021-07-03 08:33:22 --> Hooks Class Initialized
INFO - 2021-07-03 08:33:22 --> Helper loaded: form_helper
INFO - 2021-07-03 08:33:22 --> Helper loaded: url_helper
INFO - 2021-07-03 08:33:22 --> Router Class Initialized
DEBUG - 2021-07-03 08:33:22 --> UTF-8 Support Enabled
INFO - 2021-07-03 08:33:22 --> Helper loaded: cookie_helper
INFO - 2021-07-03 08:33:22 --> Helper loaded: file_helper
INFO - 2021-07-03 08:33:22 --> Utf8 Class Initialized
INFO - 2021-07-03 08:33:22 --> Output Class Initialized
INFO - 2021-07-03 08:33:22 --> Helper loaded: security_helper
INFO - 2021-07-03 08:33:22 --> Helper loaded: form_helper
INFO - 2021-07-03 08:33:22 --> URI Class Initialized
INFO - 2021-07-03 08:33:22 --> Security Class Initialized
INFO - 2021-07-03 08:33:22 --> Helper loaded: directory_helper
INFO - 2021-07-03 08:33:22 --> Helper loaded: cookie_helper
INFO - 2021-07-03 08:33:22 --> Config Class Initialized
DEBUG - 2021-07-03 08:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 08:33:22 --> Hooks Class Initialized
INFO - 2021-07-03 08:33:22 --> Helper loaded: language_helper
INFO - 2021-07-03 08:33:22 --> Router Class Initialized
INFO - 2021-07-03 08:33:22 --> Helper loaded: security_helper
INFO - 2021-07-03 08:33:22 --> Input Class Initialized
INFO - 2021-07-03 08:33:22 --> Helper loaded: general_helper
INFO - 2021-07-03 08:33:22 --> Helper loaded: directory_helper
DEBUG - 2021-07-03 08:33:22 --> UTF-8 Support Enabled
INFO - 2021-07-03 08:33:22 --> Language Class Initialized
INFO - 2021-07-03 08:33:22 --> Output Class Initialized
INFO - 2021-07-03 08:33:22 --> Utf8 Class Initialized
INFO - 2021-07-03 08:33:22 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 08:33:22 --> Helper loaded: language_helper
INFO - 2021-07-03 08:33:22 --> Security Class Initialized
INFO - 2021-07-03 08:33:22 --> Loader Class Initialized
INFO - 2021-07-03 08:33:22 --> URI Class Initialized
INFO - 2021-07-03 08:33:22 --> Helper loaded: general_helper
INFO - 2021-07-03 08:33:22 --> Database Driver Class Initialized
INFO - 2021-07-03 08:33:22 --> Config Class Initialized
DEBUG - 2021-07-03 08:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 08:33:22 --> Helper loaded: basic_helper
INFO - 2021-07-03 08:33:22 --> Hooks Class Initialized
INFO - 2021-07-03 08:33:22 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 08:33:22 --> Input Class Initialized
INFO - 2021-07-03 08:33:22 --> Router Class Initialized
INFO - 2021-07-03 08:33:22 --> Helper loaded: url_helper
DEBUG - 2021-07-03 08:33:22 --> UTF-8 Support Enabled
INFO - 2021-07-03 08:33:22 --> Language Class Initialized
INFO - 2021-07-03 08:33:22 --> Database Driver Class Initialized
INFO - 2021-07-03 08:33:22 --> Output Class Initialized
INFO - 2021-07-03 08:33:22 --> Utf8 Class Initialized
INFO - 2021-07-03 08:33:22 --> Helper loaded: file_helper
INFO - 2021-07-03 08:33:22 --> Loader Class Initialized
DEBUG - 2021-07-03 08:33:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 08:33:22 --> URI Class Initialized
INFO - 2021-07-03 08:33:22 --> Security Class Initialized
INFO - 2021-07-03 08:33:22 --> Helper loaded: form_helper
INFO - 2021-07-03 08:33:22 --> Helper loaded: basic_helper
DEBUG - 2021-07-03 08:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 08:33:22 --> Helper loaded: cookie_helper
INFO - 2021-07-03 08:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 08:33:22 --> Router Class Initialized
INFO - 2021-07-03 08:33:22 --> Input Class Initialized
INFO - 2021-07-03 08:33:22 --> Helper loaded: url_helper
DEBUG - 2021-07-03 08:33:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 08:33:22 --> Helper loaded: security_helper
INFO - 2021-07-03 08:33:22 --> Output Class Initialized
INFO - 2021-07-03 08:33:22 --> Language Class Initialized
INFO - 2021-07-03 08:33:22 --> Parser Class Initialized
INFO - 2021-07-03 08:33:22 --> Helper loaded: file_helper
INFO - 2021-07-03 08:33:22 --> Helper loaded: directory_helper
INFO - 2021-07-03 08:33:22 --> Security Class Initialized
INFO - 2021-07-03 08:33:22 --> Loader Class Initialized
INFO - 2021-07-03 08:33:22 --> Form Validation Class Initialized
INFO - 2021-07-03 08:33:22 --> Helper loaded: form_helper
INFO - 2021-07-03 08:33:22 --> Helper loaded: language_helper
DEBUG - 2021-07-03 08:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 08:33:22 --> Input Class Initialized
INFO - 2021-07-03 08:33:22 --> Helper loaded: cookie_helper
INFO - 2021-07-03 08:33:22 --> Helper loaded: basic_helper
INFO - 2021-07-03 08:33:22 --> Helper loaded: general_helper
INFO - 2021-07-03 08:33:22 --> Upload Class Initialized
INFO - 2021-07-03 08:33:22 --> Language Class Initialized
INFO - 2021-07-03 08:33:22 --> Helper loaded: security_helper
INFO - 2021-07-03 08:33:22 --> Helper loaded: url_helper
INFO - 2021-07-03 08:33:22 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 08:33:22 --> Email Class Initialized
INFO - 2021-07-03 08:33:22 --> Helper loaded: directory_helper
INFO - 2021-07-03 08:33:22 --> Loader Class Initialized
INFO - 2021-07-03 08:33:22 --> Helper loaded: file_helper
INFO - 2021-07-03 08:33:22 --> Database Driver Class Initialized
INFO - 2021-07-03 08:33:22 --> MY_Model class loaded
INFO - 2021-07-03 08:33:22 --> Helper loaded: language_helper
INFO - 2021-07-03 08:33:22 --> Helper loaded: form_helper
INFO - 2021-07-03 08:33:22 --> Helper loaded: basic_helper
INFO - 2021-07-03 08:33:22 --> Model "Users_model" initialized
INFO - 2021-07-03 08:33:22 --> Helper loaded: general_helper
INFO - 2021-07-03 08:33:22 --> Model "Settings_model" initialized
INFO - 2021-07-03 08:33:22 --> Helper loaded: cookie_helper
INFO - 2021-07-03 08:33:22 --> Helper loaded: url_helper
INFO - 2021-07-03 08:33:22 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 08:33:22 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 08:33:22 --> Helper loaded: security_helper
INFO - 2021-07-03 08:33:22 --> Helper loaded: file_helper
INFO - 2021-07-03 08:33:22 --> Model "Permissions_model" initialized
DEBUG - 2021-07-03 08:33:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 08:33:22 --> Database Driver Class Initialized
INFO - 2021-07-03 08:33:22 --> Helper loaded: directory_helper
INFO - 2021-07-03 08:33:22 --> Model "Roles_model" initialized
INFO - 2021-07-03 08:33:22 --> Helper loaded: form_helper
INFO - 2021-07-03 08:33:22 --> Model "Activity_model" initialized
INFO - 2021-07-03 08:33:22 --> Helper loaded: language_helper
INFO - 2021-07-03 08:33:22 --> Helper loaded: cookie_helper
INFO - 2021-07-03 08:33:22 --> Model "Templates_model" initialized
INFO - 2021-07-03 08:33:22 --> Helper loaded: general_helper
INFO - 2021-07-03 08:33:22 --> Helper loaded: security_helper
INFO - 2021-07-03 08:33:22 --> Database Driver Class Initialized
INFO - 2021-07-03 08:33:22 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 08:33:22 --> Helper loaded: directory_helper
DEBUG - 2021-07-03 08:33:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 08:33:22 --> Helper loaded: language_helper
INFO - 2021-07-03 08:33:22 --> Database Driver Class Initialized
INFO - 2021-07-03 08:33:22 --> Helper loaded: general_helper
INFO - 2021-07-03 08:33:22 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 08:33:22 --> Database Driver Class Initialized
DEBUG - 2021-07-03 08:33:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-07-03 08:33:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 08:33:22 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 08:33:22 --> Controller Class Initialized
INFO - 2021-07-03 11:33:22 --> Final output sent to browser
DEBUG - 2021-07-03 11:33:22 --> Total execution time: 0.0612
INFO - 2021-07-03 08:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 08:33:22 --> Parser Class Initialized
INFO - 2021-07-03 08:33:22 --> Form Validation Class Initialized
INFO - 2021-07-03 08:33:22 --> Upload Class Initialized
INFO - 2021-07-03 08:33:22 --> Email Class Initialized
INFO - 2021-07-03 08:33:22 --> MY_Model class loaded
INFO - 2021-07-03 08:33:22 --> Model "Users_model" initialized
INFO - 2021-07-03 08:33:22 --> Model "Settings_model" initialized
INFO - 2021-07-03 08:33:22 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 08:33:22 --> Model "Permissions_model" initialized
INFO - 2021-07-03 08:33:22 --> Model "Roles_model" initialized
INFO - 2021-07-03 08:33:22 --> Model "Activity_model" initialized
INFO - 2021-07-03 08:33:22 --> Model "Templates_model" initialized
INFO - 2021-07-03 08:33:22 --> Database Driver Class Initialized
INFO - 2021-07-03 08:33:22 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 08:33:22 --> Controller Class Initialized
INFO - 2021-07-03 11:33:22 --> Final output sent to browser
DEBUG - 2021-07-03 11:33:22 --> Total execution time: 0.0900
INFO - 2021-07-03 08:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 08:33:22 --> Parser Class Initialized
INFO - 2021-07-03 08:33:22 --> Form Validation Class Initialized
INFO - 2021-07-03 08:33:22 --> Upload Class Initialized
INFO - 2021-07-03 08:33:22 --> Email Class Initialized
INFO - 2021-07-03 08:33:22 --> MY_Model class loaded
INFO - 2021-07-03 08:33:22 --> Model "Users_model" initialized
INFO - 2021-07-03 08:33:22 --> Model "Settings_model" initialized
INFO - 2021-07-03 08:33:22 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 08:33:22 --> Model "Permissions_model" initialized
INFO - 2021-07-03 08:33:22 --> Model "Roles_model" initialized
INFO - 2021-07-03 08:33:22 --> Model "Activity_model" initialized
INFO - 2021-07-03 08:33:22 --> Model "Templates_model" initialized
INFO - 2021-07-03 08:33:22 --> Database Driver Class Initialized
INFO - 2021-07-03 08:33:22 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 08:33:22 --> Controller Class Initialized
INFO - 2021-07-03 11:33:22 --> Final output sent to browser
DEBUG - 2021-07-03 11:33:22 --> Total execution time: 0.1163
INFO - 2021-07-03 08:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 08:33:22 --> Parser Class Initialized
INFO - 2021-07-03 08:33:22 --> Form Validation Class Initialized
INFO - 2021-07-03 08:33:22 --> Upload Class Initialized
INFO - 2021-07-03 08:33:22 --> Email Class Initialized
INFO - 2021-07-03 08:33:22 --> MY_Model class loaded
INFO - 2021-07-03 08:33:22 --> Model "Users_model" initialized
INFO - 2021-07-03 08:33:22 --> Model "Settings_model" initialized
INFO - 2021-07-03 08:33:22 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 08:33:22 --> Model "Permissions_model" initialized
INFO - 2021-07-03 08:33:22 --> Model "Roles_model" initialized
INFO - 2021-07-03 08:33:22 --> Model "Activity_model" initialized
INFO - 2021-07-03 08:33:22 --> Model "Templates_model" initialized
INFO - 2021-07-03 08:33:22 --> Database Driver Class Initialized
INFO - 2021-07-03 08:33:22 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 08:33:22 --> Controller Class Initialized
INFO - 2021-07-03 11:33:22 --> Final output sent to browser
DEBUG - 2021-07-03 11:33:22 --> Total execution time: 0.1432
INFO - 2021-07-03 08:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 08:33:22 --> Parser Class Initialized
INFO - 2021-07-03 08:33:22 --> Form Validation Class Initialized
INFO - 2021-07-03 08:33:22 --> Upload Class Initialized
INFO - 2021-07-03 08:33:22 --> Email Class Initialized
INFO - 2021-07-03 08:33:22 --> MY_Model class loaded
INFO - 2021-07-03 08:33:22 --> Model "Users_model" initialized
INFO - 2021-07-03 08:33:22 --> Model "Settings_model" initialized
INFO - 2021-07-03 08:33:22 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 08:33:22 --> Model "Permissions_model" initialized
INFO - 2021-07-03 08:33:22 --> Model "Roles_model" initialized
INFO - 2021-07-03 08:33:22 --> Model "Activity_model" initialized
INFO - 2021-07-03 08:33:22 --> Model "Templates_model" initialized
INFO - 2021-07-03 08:33:22 --> Database Driver Class Initialized
INFO - 2021-07-03 08:33:22 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 08:33:22 --> Controller Class Initialized
INFO - 2021-07-03 11:33:22 --> Final output sent to browser
DEBUG - 2021-07-03 11:33:22 --> Total execution time: 0.1706
INFO - 2021-07-03 08:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 08:33:22 --> Parser Class Initialized
INFO - 2021-07-03 08:33:22 --> Form Validation Class Initialized
INFO - 2021-07-03 08:33:22 --> Upload Class Initialized
INFO - 2021-07-03 08:33:22 --> Email Class Initialized
INFO - 2021-07-03 08:33:22 --> MY_Model class loaded
INFO - 2021-07-03 08:33:22 --> Model "Users_model" initialized
INFO - 2021-07-03 08:33:22 --> Model "Settings_model" initialized
INFO - 2021-07-03 08:33:22 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 08:33:22 --> Model "Permissions_model" initialized
INFO - 2021-07-03 08:33:22 --> Model "Roles_model" initialized
INFO - 2021-07-03 08:33:22 --> Model "Activity_model" initialized
INFO - 2021-07-03 08:33:22 --> Model "Templates_model" initialized
INFO - 2021-07-03 08:33:22 --> Database Driver Class Initialized
INFO - 2021-07-03 08:33:22 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 08:33:22 --> Controller Class Initialized
INFO - 2021-07-03 11:33:22 --> Final output sent to browser
DEBUG - 2021-07-03 11:33:22 --> Total execution time: 0.1953
INFO - 2021-07-03 09:16:07 --> Config Class Initialized
INFO - 2021-07-03 09:16:07 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:16:07 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:16:07 --> Utf8 Class Initialized
INFO - 2021-07-03 09:16:07 --> URI Class Initialized
INFO - 2021-07-03 09:16:07 --> Router Class Initialized
INFO - 2021-07-03 09:16:07 --> Output Class Initialized
INFO - 2021-07-03 09:16:07 --> Security Class Initialized
DEBUG - 2021-07-03 09:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:16:07 --> Input Class Initialized
INFO - 2021-07-03 09:16:07 --> Language Class Initialized
INFO - 2021-07-03 09:16:07 --> Loader Class Initialized
INFO - 2021-07-03 09:16:07 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:16:07 --> Helper loaded: url_helper
INFO - 2021-07-03 09:16:07 --> Helper loaded: file_helper
INFO - 2021-07-03 09:16:07 --> Helper loaded: form_helper
INFO - 2021-07-03 09:16:07 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:16:07 --> Helper loaded: security_helper
INFO - 2021-07-03 09:16:07 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:16:07 --> Helper loaded: language_helper
INFO - 2021-07-03 09:16:07 --> Helper loaded: general_helper
INFO - 2021-07-03 09:16:07 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:16:07 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:16:07 --> Parser Class Initialized
INFO - 2021-07-03 09:16:07 --> Form Validation Class Initialized
INFO - 2021-07-03 09:16:07 --> Upload Class Initialized
INFO - 2021-07-03 09:16:07 --> Email Class Initialized
INFO - 2021-07-03 09:16:07 --> MY_Model class loaded
INFO - 2021-07-03 09:16:07 --> Model "Users_model" initialized
INFO - 2021-07-03 09:16:07 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:16:07 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:16:07 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:16:07 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:16:07 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:16:07 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:16:07 --> Database Driver Class Initialized
INFO - 2021-07-03 09:16:07 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:16:07 --> Controller Class Initialized
ERROR - 2021-07-03 12:16:07 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 12:16:07 --> File loaded: C:\wamp64\www\crm\application\views\users/add.php
INFO - 2021-07-03 12:16:07 --> Final output sent to browser
DEBUG - 2021-07-03 12:16:07 --> Total execution time: 0.1350
INFO - 2021-07-03 09:16:23 --> Config Class Initialized
INFO - 2021-07-03 09:16:23 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:16:23 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:16:23 --> Utf8 Class Initialized
INFO - 2021-07-03 09:16:23 --> URI Class Initialized
INFO - 2021-07-03 09:16:23 --> Router Class Initialized
INFO - 2021-07-03 09:16:23 --> Output Class Initialized
INFO - 2021-07-03 09:16:23 --> Security Class Initialized
DEBUG - 2021-07-03 09:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:16:23 --> Input Class Initialized
INFO - 2021-07-03 09:16:23 --> Language Class Initialized
INFO - 2021-07-03 09:16:23 --> Loader Class Initialized
INFO - 2021-07-03 09:16:23 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:16:23 --> Helper loaded: url_helper
INFO - 2021-07-03 09:16:23 --> Helper loaded: file_helper
INFO - 2021-07-03 09:16:23 --> Helper loaded: form_helper
INFO - 2021-07-03 09:16:23 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:16:23 --> Helper loaded: security_helper
INFO - 2021-07-03 09:16:23 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:16:23 --> Helper loaded: language_helper
INFO - 2021-07-03 09:16:23 --> Helper loaded: general_helper
INFO - 2021-07-03 09:16:23 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:16:23 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:16:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:16:23 --> Parser Class Initialized
INFO - 2021-07-03 09:16:23 --> Form Validation Class Initialized
INFO - 2021-07-03 09:16:23 --> Upload Class Initialized
INFO - 2021-07-03 09:16:23 --> Email Class Initialized
INFO - 2021-07-03 09:16:23 --> MY_Model class loaded
INFO - 2021-07-03 09:16:23 --> Model "Users_model" initialized
INFO - 2021-07-03 09:16:23 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:16:23 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:16:23 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:16:23 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:16:23 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:16:23 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:16:23 --> Database Driver Class Initialized
INFO - 2021-07-03 09:16:23 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:16:23 --> Controller Class Initialized
INFO - 2021-07-03 12:16:23 --> Final output sent to browser
DEBUG - 2021-07-03 12:16:23 --> Total execution time: 0.1243
INFO - 2021-07-03 09:16:30 --> Config Class Initialized
INFO - 2021-07-03 09:16:30 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:16:30 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:16:30 --> Utf8 Class Initialized
INFO - 2021-07-03 09:16:30 --> URI Class Initialized
INFO - 2021-07-03 09:16:30 --> Router Class Initialized
INFO - 2021-07-03 09:16:30 --> Output Class Initialized
INFO - 2021-07-03 09:16:30 --> Security Class Initialized
DEBUG - 2021-07-03 09:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:16:30 --> Input Class Initialized
INFO - 2021-07-03 09:16:30 --> Language Class Initialized
INFO - 2021-07-03 09:16:30 --> Loader Class Initialized
INFO - 2021-07-03 09:16:30 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:16:30 --> Helper loaded: url_helper
INFO - 2021-07-03 09:16:30 --> Helper loaded: file_helper
INFO - 2021-07-03 09:16:30 --> Helper loaded: form_helper
INFO - 2021-07-03 09:16:30 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:16:30 --> Helper loaded: security_helper
INFO - 2021-07-03 09:16:30 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:16:30 --> Helper loaded: language_helper
INFO - 2021-07-03 09:16:30 --> Helper loaded: general_helper
INFO - 2021-07-03 09:16:30 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:16:30 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:16:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:16:30 --> Parser Class Initialized
INFO - 2021-07-03 09:16:30 --> Form Validation Class Initialized
INFO - 2021-07-03 09:16:30 --> Upload Class Initialized
INFO - 2021-07-03 09:16:30 --> Email Class Initialized
INFO - 2021-07-03 09:16:30 --> MY_Model class loaded
INFO - 2021-07-03 09:16:30 --> Model "Users_model" initialized
INFO - 2021-07-03 09:16:30 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:16:30 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:16:30 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:16:30 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:16:30 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:16:30 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:16:30 --> Database Driver Class Initialized
INFO - 2021-07-03 09:16:30 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:16:30 --> Controller Class Initialized
INFO - 2021-07-03 12:16:30 --> Final output sent to browser
DEBUG - 2021-07-03 12:16:30 --> Total execution time: 0.1577
INFO - 2021-07-03 09:17:00 --> Config Class Initialized
INFO - 2021-07-03 09:17:00 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:17:00 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:17:00 --> Utf8 Class Initialized
INFO - 2021-07-03 09:17:00 --> URI Class Initialized
DEBUG - 2021-07-03 09:17:00 --> No URI present. Default controller set.
INFO - 2021-07-03 09:17:00 --> Router Class Initialized
INFO - 2021-07-03 09:17:00 --> Output Class Initialized
INFO - 2021-07-03 09:17:00 --> Security Class Initialized
DEBUG - 2021-07-03 09:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:17:00 --> Input Class Initialized
INFO - 2021-07-03 09:17:00 --> Language Class Initialized
INFO - 2021-07-03 09:17:00 --> Loader Class Initialized
INFO - 2021-07-03 09:17:00 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:17:00 --> Helper loaded: url_helper
INFO - 2021-07-03 09:17:00 --> Helper loaded: file_helper
INFO - 2021-07-03 09:17:00 --> Helper loaded: form_helper
INFO - 2021-07-03 09:17:00 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:17:00 --> Helper loaded: security_helper
INFO - 2021-07-03 09:17:00 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:17:00 --> Helper loaded: language_helper
INFO - 2021-07-03 09:17:00 --> Helper loaded: general_helper
INFO - 2021-07-03 09:17:00 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:17:00 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:17:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:17:00 --> Parser Class Initialized
INFO - 2021-07-03 09:17:00 --> Form Validation Class Initialized
INFO - 2021-07-03 09:17:00 --> Upload Class Initialized
INFO - 2021-07-03 09:17:00 --> Email Class Initialized
INFO - 2021-07-03 09:17:00 --> MY_Model class loaded
INFO - 2021-07-03 09:17:00 --> Model "Users_model" initialized
INFO - 2021-07-03 09:17:00 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:17:00 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:17:00 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:17:00 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:17:00 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:17:00 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:17:00 --> Database Driver Class Initialized
INFO - 2021-07-03 09:17:00 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:17:00 --> Controller Class Initialized
INFO - 2021-07-03 09:17:00 --> Config Class Initialized
INFO - 2021-07-03 09:17:00 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:17:00 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:17:00 --> Utf8 Class Initialized
INFO - 2021-07-03 09:17:00 --> URI Class Initialized
INFO - 2021-07-03 09:17:00 --> Router Class Initialized
INFO - 2021-07-03 09:17:00 --> Output Class Initialized
INFO - 2021-07-03 09:17:00 --> Security Class Initialized
DEBUG - 2021-07-03 09:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:17:00 --> Input Class Initialized
INFO - 2021-07-03 09:17:00 --> Language Class Initialized
INFO - 2021-07-03 09:17:00 --> Loader Class Initialized
INFO - 2021-07-03 09:17:00 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:17:00 --> Helper loaded: url_helper
INFO - 2021-07-03 09:17:00 --> Helper loaded: file_helper
INFO - 2021-07-03 09:17:00 --> Helper loaded: form_helper
INFO - 2021-07-03 09:17:00 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:17:00 --> Helper loaded: security_helper
INFO - 2021-07-03 09:17:00 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:17:00 --> Helper loaded: language_helper
INFO - 2021-07-03 09:17:00 --> Helper loaded: general_helper
INFO - 2021-07-03 09:17:00 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:17:00 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:17:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:17:00 --> Parser Class Initialized
INFO - 2021-07-03 09:17:00 --> Form Validation Class Initialized
INFO - 2021-07-03 09:17:00 --> Upload Class Initialized
INFO - 2021-07-03 09:17:00 --> Email Class Initialized
INFO - 2021-07-03 09:17:00 --> MY_Model class loaded
INFO - 2021-07-03 09:17:00 --> Model "Users_model" initialized
INFO - 2021-07-03 09:17:00 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:17:00 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:17:00 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:17:00 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:17:00 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:17:00 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:17:00 --> Database Driver Class Initialized
INFO - 2021-07-03 09:17:00 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:17:00 --> Controller Class Initialized
INFO - 2021-07-03 12:17:00 --> File loaded: C:\wamp64\www\crm\application\views\account/login.php
INFO - 2021-07-03 12:17:00 --> Final output sent to browser
DEBUG - 2021-07-03 12:17:00 --> Total execution time: 0.0597
INFO - 2021-07-03 09:17:00 --> Config Class Initialized
INFO - 2021-07-03 09:17:00 --> Config Class Initialized
INFO - 2021-07-03 09:17:00 --> Hooks Class Initialized
INFO - 2021-07-03 09:17:00 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:17:00 --> UTF-8 Support Enabled
DEBUG - 2021-07-03 09:17:00 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:17:00 --> Utf8 Class Initialized
INFO - 2021-07-03 09:17:00 --> Utf8 Class Initialized
INFO - 2021-07-03 09:17:00 --> URI Class Initialized
INFO - 2021-07-03 09:17:00 --> URI Class Initialized
INFO - 2021-07-03 09:17:00 --> Router Class Initialized
INFO - 2021-07-03 09:17:00 --> Router Class Initialized
INFO - 2021-07-03 09:17:00 --> Output Class Initialized
INFO - 2021-07-03 09:17:00 --> Output Class Initialized
INFO - 2021-07-03 09:17:00 --> Security Class Initialized
INFO - 2021-07-03 09:17:00 --> Security Class Initialized
DEBUG - 2021-07-03 09:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:17:00 --> Input Class Initialized
DEBUG - 2021-07-03 09:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:17:00 --> Input Class Initialized
INFO - 2021-07-03 09:17:00 --> Language Class Initialized
INFO - 2021-07-03 09:17:00 --> Language Class Initialized
ERROR - 2021-07-03 09:17:00 --> 404 Page Not Found: Assets/jquery
ERROR - 2021-07-03 09:17:00 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-03 09:17:01 --> Config Class Initialized
INFO - 2021-07-03 09:17:01 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:17:01 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:17:01 --> Utf8 Class Initialized
INFO - 2021-07-03 09:17:01 --> URI Class Initialized
INFO - 2021-07-03 09:17:01 --> Router Class Initialized
INFO - 2021-07-03 09:17:01 --> Output Class Initialized
INFO - 2021-07-03 09:17:01 --> Security Class Initialized
DEBUG - 2021-07-03 09:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:17:01 --> Input Class Initialized
INFO - 2021-07-03 09:17:01 --> Language Class Initialized
ERROR - 2021-07-03 09:17:01 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-03 09:17:26 --> Config Class Initialized
INFO - 2021-07-03 09:17:26 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:17:26 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:17:26 --> Utf8 Class Initialized
INFO - 2021-07-03 09:17:26 --> URI Class Initialized
INFO - 2021-07-03 09:17:26 --> Router Class Initialized
INFO - 2021-07-03 09:17:26 --> Output Class Initialized
INFO - 2021-07-03 09:17:26 --> Security Class Initialized
DEBUG - 2021-07-03 09:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:17:26 --> Input Class Initialized
INFO - 2021-07-03 09:17:26 --> Language Class Initialized
INFO - 2021-07-03 09:17:26 --> Loader Class Initialized
INFO - 2021-07-03 09:17:26 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:17:26 --> Helper loaded: url_helper
INFO - 2021-07-03 09:17:26 --> Helper loaded: file_helper
INFO - 2021-07-03 09:17:26 --> Helper loaded: form_helper
INFO - 2021-07-03 09:17:26 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:17:26 --> Helper loaded: security_helper
INFO - 2021-07-03 09:17:26 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:17:26 --> Helper loaded: language_helper
INFO - 2021-07-03 09:17:26 --> Helper loaded: general_helper
INFO - 2021-07-03 09:17:26 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:17:26 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:17:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:17:26 --> Parser Class Initialized
INFO - 2021-07-03 09:17:26 --> Form Validation Class Initialized
INFO - 2021-07-03 09:17:26 --> Upload Class Initialized
INFO - 2021-07-03 09:17:26 --> Email Class Initialized
INFO - 2021-07-03 09:17:26 --> MY_Model class loaded
INFO - 2021-07-03 09:17:26 --> Model "Users_model" initialized
INFO - 2021-07-03 09:17:26 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:17:26 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:17:26 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:17:26 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:17:26 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:17:26 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:17:26 --> Database Driver Class Initialized
INFO - 2021-07-03 09:17:26 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:17:26 --> Controller Class Initialized
DEBUG - 2021-07-03 12:17:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-03 12:17:26 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2021-07-03 09:17:26 --> Config Class Initialized
INFO - 2021-07-03 09:17:26 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:17:26 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:17:26 --> Utf8 Class Initialized
INFO - 2021-07-03 09:17:26 --> URI Class Initialized
DEBUG - 2021-07-03 09:17:26 --> No URI present. Default controller set.
INFO - 2021-07-03 09:17:26 --> Router Class Initialized
INFO - 2021-07-03 09:17:26 --> Output Class Initialized
INFO - 2021-07-03 09:17:26 --> Security Class Initialized
DEBUG - 2021-07-03 09:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:17:26 --> Input Class Initialized
INFO - 2021-07-03 09:17:26 --> Language Class Initialized
INFO - 2021-07-03 09:17:26 --> Loader Class Initialized
INFO - 2021-07-03 09:17:26 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:17:26 --> Helper loaded: url_helper
INFO - 2021-07-03 09:17:26 --> Helper loaded: file_helper
INFO - 2021-07-03 09:17:26 --> Helper loaded: form_helper
INFO - 2021-07-03 09:17:26 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:17:26 --> Helper loaded: security_helper
INFO - 2021-07-03 09:17:26 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:17:26 --> Helper loaded: language_helper
INFO - 2021-07-03 09:17:26 --> Helper loaded: general_helper
INFO - 2021-07-03 09:17:26 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:17:26 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:17:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:17:26 --> Parser Class Initialized
INFO - 2021-07-03 09:17:26 --> Form Validation Class Initialized
INFO - 2021-07-03 09:17:26 --> Upload Class Initialized
INFO - 2021-07-03 09:17:26 --> Email Class Initialized
INFO - 2021-07-03 09:17:26 --> MY_Model class loaded
INFO - 2021-07-03 09:17:26 --> Model "Users_model" initialized
INFO - 2021-07-03 09:17:26 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:17:26 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:17:26 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:17:26 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:17:26 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:17:26 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:17:26 --> Database Driver Class Initialized
INFO - 2021-07-03 09:17:26 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:17:26 --> Controller Class Initialized
ERROR - 2021-07-03 12:17:26 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 12:17:26 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-03 12:17:26 --> Final output sent to browser
DEBUG - 2021-07-03 12:17:26 --> Total execution time: 0.0647
INFO - 2021-07-03 09:17:28 --> Config Class Initialized
INFO - 2021-07-03 09:17:28 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:17:28 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:17:28 --> Utf8 Class Initialized
INFO - 2021-07-03 09:17:28 --> URI Class Initialized
INFO - 2021-07-03 09:17:28 --> Router Class Initialized
INFO - 2021-07-03 09:17:28 --> Output Class Initialized
INFO - 2021-07-03 09:17:28 --> Security Class Initialized
DEBUG - 2021-07-03 09:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:17:28 --> Input Class Initialized
INFO - 2021-07-03 09:17:28 --> Language Class Initialized
INFO - 2021-07-03 09:17:28 --> Loader Class Initialized
INFO - 2021-07-03 09:17:28 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:17:28 --> Helper loaded: url_helper
INFO - 2021-07-03 09:17:28 --> Helper loaded: file_helper
INFO - 2021-07-03 09:17:28 --> Helper loaded: form_helper
INFO - 2021-07-03 09:17:28 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:17:28 --> Helper loaded: security_helper
INFO - 2021-07-03 09:17:28 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:17:28 --> Helper loaded: language_helper
INFO - 2021-07-03 09:17:28 --> Helper loaded: general_helper
INFO - 2021-07-03 09:17:28 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:17:28 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:17:28 --> Parser Class Initialized
INFO - 2021-07-03 09:17:28 --> Form Validation Class Initialized
INFO - 2021-07-03 09:17:28 --> Upload Class Initialized
INFO - 2021-07-03 09:17:28 --> Email Class Initialized
INFO - 2021-07-03 09:17:28 --> MY_Model class loaded
INFO - 2021-07-03 09:17:28 --> Model "Users_model" initialized
INFO - 2021-07-03 09:17:28 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:17:28 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:17:28 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:17:28 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:17:28 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:17:28 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:17:28 --> Database Driver Class Initialized
INFO - 2021-07-03 09:17:28 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:17:28 --> Controller Class Initialized
ERROR - 2021-07-03 12:17:28 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 12:17:28 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-03 12:17:28 --> Final output sent to browser
DEBUG - 2021-07-03 12:17:28 --> Total execution time: 0.1698
INFO - 2021-07-03 09:17:32 --> Config Class Initialized
INFO - 2021-07-03 09:17:32 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:17:32 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:17:32 --> Utf8 Class Initialized
INFO - 2021-07-03 09:17:32 --> URI Class Initialized
INFO - 2021-07-03 09:17:32 --> Router Class Initialized
INFO - 2021-07-03 09:17:32 --> Output Class Initialized
INFO - 2021-07-03 09:17:32 --> Security Class Initialized
DEBUG - 2021-07-03 09:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:17:32 --> Input Class Initialized
INFO - 2021-07-03 09:17:32 --> Language Class Initialized
INFO - 2021-07-03 09:17:32 --> Loader Class Initialized
INFO - 2021-07-03 09:17:32 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:17:32 --> Helper loaded: url_helper
INFO - 2021-07-03 09:17:32 --> Helper loaded: file_helper
INFO - 2021-07-03 09:17:32 --> Helper loaded: form_helper
INFO - 2021-07-03 09:17:32 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:17:32 --> Helper loaded: security_helper
INFO - 2021-07-03 09:17:32 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:17:32 --> Helper loaded: language_helper
INFO - 2021-07-03 09:17:32 --> Helper loaded: general_helper
INFO - 2021-07-03 09:17:32 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:17:32 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:17:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:17:32 --> Parser Class Initialized
INFO - 2021-07-03 09:17:32 --> Form Validation Class Initialized
INFO - 2021-07-03 09:17:32 --> Upload Class Initialized
INFO - 2021-07-03 09:17:32 --> Email Class Initialized
INFO - 2021-07-03 09:17:32 --> MY_Model class loaded
INFO - 2021-07-03 09:17:32 --> Model "Users_model" initialized
INFO - 2021-07-03 09:17:32 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:17:32 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:17:32 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:17:32 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:17:32 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:17:32 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:17:32 --> Database Driver Class Initialized
INFO - 2021-07-03 09:17:33 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:17:33 --> Controller Class Initialized
ERROR - 2021-07-03 12:17:33 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-03 12:17:33 --> Invalid query: 
INFO - 2021-07-03 12:17:33 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-03 12:17:33 --> Final output sent to browser
DEBUG - 2021-07-03 12:17:33 --> Total execution time: 0.1505
INFO - 2021-07-03 09:17:37 --> Config Class Initialized
INFO - 2021-07-03 09:17:37 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:17:37 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:17:37 --> Utf8 Class Initialized
INFO - 2021-07-03 09:17:37 --> URI Class Initialized
INFO - 2021-07-03 09:17:37 --> Router Class Initialized
INFO - 2021-07-03 09:17:37 --> Output Class Initialized
INFO - 2021-07-03 09:17:37 --> Security Class Initialized
DEBUG - 2021-07-03 09:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:17:37 --> Input Class Initialized
INFO - 2021-07-03 09:17:37 --> Language Class Initialized
INFO - 2021-07-03 09:17:37 --> Loader Class Initialized
INFO - 2021-07-03 09:17:37 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:17:37 --> Helper loaded: url_helper
INFO - 2021-07-03 09:17:37 --> Helper loaded: file_helper
INFO - 2021-07-03 09:17:37 --> Helper loaded: form_helper
INFO - 2021-07-03 09:17:37 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:17:37 --> Helper loaded: security_helper
INFO - 2021-07-03 09:17:37 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:17:37 --> Helper loaded: language_helper
INFO - 2021-07-03 09:17:37 --> Helper loaded: general_helper
INFO - 2021-07-03 09:17:37 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:17:37 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:17:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:17:37 --> Parser Class Initialized
INFO - 2021-07-03 09:17:37 --> Form Validation Class Initialized
INFO - 2021-07-03 09:17:37 --> Upload Class Initialized
INFO - 2021-07-03 09:17:37 --> Email Class Initialized
INFO - 2021-07-03 09:17:37 --> MY_Model class loaded
INFO - 2021-07-03 09:17:37 --> Model "Users_model" initialized
INFO - 2021-07-03 09:17:37 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:17:37 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:17:37 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:17:37 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:17:37 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:17:37 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:17:37 --> Database Driver Class Initialized
INFO - 2021-07-03 09:17:37 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:17:37 --> Controller Class Initialized
ERROR - 2021-07-03 12:17:37 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 12:17:37 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-03 12:17:37 --> Final output sent to browser
DEBUG - 2021-07-03 12:17:37 --> Total execution time: 0.2676
INFO - 2021-07-03 09:17:38 --> Config Class Initialized
INFO - 2021-07-03 09:17:38 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:17:38 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:17:38 --> Utf8 Class Initialized
INFO - 2021-07-03 09:17:38 --> URI Class Initialized
INFO - 2021-07-03 09:17:38 --> Router Class Initialized
INFO - 2021-07-03 09:17:38 --> Output Class Initialized
INFO - 2021-07-03 09:17:38 --> Security Class Initialized
DEBUG - 2021-07-03 09:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:17:38 --> Input Class Initialized
INFO - 2021-07-03 09:17:38 --> Language Class Initialized
INFO - 2021-07-03 09:17:38 --> Loader Class Initialized
INFO - 2021-07-03 09:17:38 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:17:38 --> Helper loaded: url_helper
INFO - 2021-07-03 09:17:38 --> Helper loaded: file_helper
INFO - 2021-07-03 09:17:38 --> Helper loaded: form_helper
INFO - 2021-07-03 09:17:38 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:17:38 --> Helper loaded: security_helper
INFO - 2021-07-03 09:17:38 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:17:38 --> Helper loaded: language_helper
INFO - 2021-07-03 09:17:38 --> Helper loaded: general_helper
INFO - 2021-07-03 09:17:38 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:17:38 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:17:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:17:38 --> Parser Class Initialized
INFO - 2021-07-03 09:17:38 --> Form Validation Class Initialized
INFO - 2021-07-03 09:17:38 --> Upload Class Initialized
INFO - 2021-07-03 09:17:38 --> Email Class Initialized
INFO - 2021-07-03 09:17:38 --> MY_Model class loaded
INFO - 2021-07-03 09:17:38 --> Model "Users_model" initialized
INFO - 2021-07-03 09:17:38 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:17:38 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:17:38 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:17:38 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:17:38 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:17:38 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:17:38 --> Database Driver Class Initialized
INFO - 2021-07-03 09:17:38 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:17:38 --> Controller Class Initialized
ERROR - 2021-07-03 12:17:38 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 12:17:38 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-03 12:17:38 --> Final output sent to browser
DEBUG - 2021-07-03 12:17:38 --> Total execution time: 0.0619
INFO - 2021-07-03 09:17:40 --> Config Class Initialized
INFO - 2021-07-03 09:17:40 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:17:40 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:17:40 --> Utf8 Class Initialized
INFO - 2021-07-03 09:17:40 --> URI Class Initialized
INFO - 2021-07-03 09:17:40 --> Router Class Initialized
INFO - 2021-07-03 09:17:40 --> Output Class Initialized
INFO - 2021-07-03 09:17:40 --> Security Class Initialized
DEBUG - 2021-07-03 09:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:17:40 --> Input Class Initialized
INFO - 2021-07-03 09:17:40 --> Language Class Initialized
INFO - 2021-07-03 09:17:40 --> Loader Class Initialized
INFO - 2021-07-03 09:17:40 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:17:40 --> Helper loaded: url_helper
INFO - 2021-07-03 09:17:40 --> Helper loaded: file_helper
INFO - 2021-07-03 09:17:40 --> Helper loaded: form_helper
INFO - 2021-07-03 09:17:40 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:17:40 --> Helper loaded: security_helper
INFO - 2021-07-03 09:17:40 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:17:40 --> Helper loaded: language_helper
INFO - 2021-07-03 09:17:40 --> Helper loaded: general_helper
INFO - 2021-07-03 09:17:40 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:17:40 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:17:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:17:40 --> Parser Class Initialized
INFO - 2021-07-03 09:17:40 --> Form Validation Class Initialized
INFO - 2021-07-03 09:17:40 --> Upload Class Initialized
INFO - 2021-07-03 09:17:40 --> Email Class Initialized
INFO - 2021-07-03 09:17:40 --> MY_Model class loaded
INFO - 2021-07-03 09:17:40 --> Model "Users_model" initialized
INFO - 2021-07-03 09:17:40 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:17:40 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:17:40 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:17:40 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:17:40 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:17:40 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:17:40 --> Database Driver Class Initialized
INFO - 2021-07-03 09:17:40 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:17:40 --> Controller Class Initialized
ERROR - 2021-07-03 12:17:40 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 12:17:40 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-03 12:17:40 --> Final output sent to browser
DEBUG - 2021-07-03 12:17:40 --> Total execution time: 0.0719
INFO - 2021-07-03 09:17:43 --> Config Class Initialized
INFO - 2021-07-03 09:17:43 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:17:43 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:17:43 --> Utf8 Class Initialized
INFO - 2021-07-03 09:17:43 --> URI Class Initialized
INFO - 2021-07-03 09:17:43 --> Router Class Initialized
INFO - 2021-07-03 09:17:43 --> Output Class Initialized
INFO - 2021-07-03 09:17:43 --> Security Class Initialized
DEBUG - 2021-07-03 09:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:17:43 --> Input Class Initialized
INFO - 2021-07-03 09:17:43 --> Language Class Initialized
INFO - 2021-07-03 09:17:43 --> Loader Class Initialized
INFO - 2021-07-03 09:17:43 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:17:43 --> Helper loaded: url_helper
INFO - 2021-07-03 09:17:43 --> Helper loaded: file_helper
INFO - 2021-07-03 09:17:43 --> Helper loaded: form_helper
INFO - 2021-07-03 09:17:43 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:17:43 --> Helper loaded: security_helper
INFO - 2021-07-03 09:17:43 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:17:43 --> Helper loaded: language_helper
INFO - 2021-07-03 09:17:43 --> Helper loaded: general_helper
INFO - 2021-07-03 09:17:43 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:17:43 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:17:43 --> Parser Class Initialized
INFO - 2021-07-03 09:17:43 --> Form Validation Class Initialized
INFO - 2021-07-03 09:17:43 --> Upload Class Initialized
INFO - 2021-07-03 09:17:43 --> Email Class Initialized
INFO - 2021-07-03 09:17:43 --> MY_Model class loaded
INFO - 2021-07-03 09:17:43 --> Model "Users_model" initialized
INFO - 2021-07-03 09:17:43 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:17:43 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:17:43 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:17:43 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:17:43 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:17:43 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:17:43 --> Database Driver Class Initialized
INFO - 2021-07-03 09:17:43 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:17:43 --> Controller Class Initialized
ERROR - 2021-07-03 12:17:43 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 12:17:43 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-03 12:17:43 --> Final output sent to browser
DEBUG - 2021-07-03 12:17:43 --> Total execution time: 0.1300
INFO - 2021-07-03 09:17:46 --> Config Class Initialized
INFO - 2021-07-03 09:17:46 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:17:46 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:17:46 --> Utf8 Class Initialized
INFO - 2021-07-03 09:17:46 --> URI Class Initialized
INFO - 2021-07-03 09:17:46 --> Router Class Initialized
INFO - 2021-07-03 09:17:46 --> Output Class Initialized
INFO - 2021-07-03 09:17:46 --> Security Class Initialized
DEBUG - 2021-07-03 09:17:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:17:46 --> Input Class Initialized
INFO - 2021-07-03 09:17:46 --> Language Class Initialized
INFO - 2021-07-03 09:17:46 --> Loader Class Initialized
INFO - 2021-07-03 09:17:46 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:17:46 --> Helper loaded: url_helper
INFO - 2021-07-03 09:17:46 --> Helper loaded: file_helper
INFO - 2021-07-03 09:17:46 --> Helper loaded: form_helper
INFO - 2021-07-03 09:17:46 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:17:46 --> Helper loaded: security_helper
INFO - 2021-07-03 09:17:46 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:17:46 --> Helper loaded: language_helper
INFO - 2021-07-03 09:17:46 --> Helper loaded: general_helper
INFO - 2021-07-03 09:17:46 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:17:46 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:17:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:17:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:17:46 --> Parser Class Initialized
INFO - 2021-07-03 09:17:46 --> Form Validation Class Initialized
INFO - 2021-07-03 09:17:46 --> Upload Class Initialized
INFO - 2021-07-03 09:17:46 --> Email Class Initialized
INFO - 2021-07-03 09:17:46 --> MY_Model class loaded
INFO - 2021-07-03 09:17:46 --> Model "Users_model" initialized
INFO - 2021-07-03 09:17:46 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:17:46 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:17:46 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:17:46 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:17:46 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:17:46 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:17:46 --> Database Driver Class Initialized
INFO - 2021-07-03 09:17:46 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:17:46 --> Controller Class Initialized
ERROR - 2021-07-03 12:17:46 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 12:17:46 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-03 12:17:46 --> Final output sent to browser
DEBUG - 2021-07-03 12:17:46 --> Total execution time: 0.0661
INFO - 2021-07-03 09:17:48 --> Config Class Initialized
INFO - 2021-07-03 09:17:48 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:17:48 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:17:48 --> Utf8 Class Initialized
INFO - 2021-07-03 09:17:48 --> URI Class Initialized
INFO - 2021-07-03 09:17:48 --> Router Class Initialized
INFO - 2021-07-03 09:17:48 --> Output Class Initialized
INFO - 2021-07-03 09:17:48 --> Security Class Initialized
DEBUG - 2021-07-03 09:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:17:48 --> Input Class Initialized
INFO - 2021-07-03 09:17:48 --> Language Class Initialized
INFO - 2021-07-03 09:17:48 --> Loader Class Initialized
INFO - 2021-07-03 09:17:48 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:17:48 --> Helper loaded: url_helper
INFO - 2021-07-03 09:17:48 --> Helper loaded: file_helper
INFO - 2021-07-03 09:17:48 --> Helper loaded: form_helper
INFO - 2021-07-03 09:17:48 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:17:48 --> Helper loaded: security_helper
INFO - 2021-07-03 09:17:48 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:17:48 --> Helper loaded: language_helper
INFO - 2021-07-03 09:17:48 --> Helper loaded: general_helper
INFO - 2021-07-03 09:17:48 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:17:48 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:17:48 --> Parser Class Initialized
INFO - 2021-07-03 09:17:48 --> Form Validation Class Initialized
INFO - 2021-07-03 09:17:48 --> Upload Class Initialized
INFO - 2021-07-03 09:17:48 --> Email Class Initialized
INFO - 2021-07-03 09:17:48 --> MY_Model class loaded
INFO - 2021-07-03 09:17:48 --> Model "Users_model" initialized
INFO - 2021-07-03 09:17:48 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:17:48 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:17:48 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:17:48 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:17:48 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:17:48 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:17:48 --> Database Driver Class Initialized
INFO - 2021-07-03 09:17:48 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:17:48 --> Controller Class Initialized
ERROR - 2021-07-03 12:17:48 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 12:17:48 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-03 12:17:48 --> Final output sent to browser
DEBUG - 2021-07-03 12:17:48 --> Total execution time: 0.1350
INFO - 2021-07-03 09:17:50 --> Config Class Initialized
INFO - 2021-07-03 09:17:50 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:17:50 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:17:50 --> Utf8 Class Initialized
INFO - 2021-07-03 09:17:50 --> URI Class Initialized
INFO - 2021-07-03 09:17:50 --> Router Class Initialized
INFO - 2021-07-03 09:17:50 --> Output Class Initialized
INFO - 2021-07-03 09:17:50 --> Security Class Initialized
DEBUG - 2021-07-03 09:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:17:50 --> Input Class Initialized
INFO - 2021-07-03 09:17:50 --> Language Class Initialized
INFO - 2021-07-03 09:17:50 --> Loader Class Initialized
INFO - 2021-07-03 09:17:50 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:17:50 --> Helper loaded: url_helper
INFO - 2021-07-03 09:17:50 --> Helper loaded: file_helper
INFO - 2021-07-03 09:17:50 --> Helper loaded: form_helper
INFO - 2021-07-03 09:17:50 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:17:50 --> Helper loaded: security_helper
INFO - 2021-07-03 09:17:50 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:17:50 --> Helper loaded: language_helper
INFO - 2021-07-03 09:17:50 --> Helper loaded: general_helper
INFO - 2021-07-03 09:17:50 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:17:50 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:17:50 --> Parser Class Initialized
INFO - 2021-07-03 09:17:50 --> Form Validation Class Initialized
INFO - 2021-07-03 09:17:50 --> Upload Class Initialized
INFO - 2021-07-03 09:17:50 --> Email Class Initialized
INFO - 2021-07-03 09:17:50 --> MY_Model class loaded
INFO - 2021-07-03 09:17:50 --> Model "Users_model" initialized
INFO - 2021-07-03 09:17:50 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:17:50 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:17:50 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:17:50 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:17:50 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:17:50 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:17:50 --> Database Driver Class Initialized
INFO - 2021-07-03 09:17:50 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:17:50 --> Controller Class Initialized
ERROR - 2021-07-03 12:17:50 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 12:17:50 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-03 12:17:50 --> Final output sent to browser
DEBUG - 2021-07-03 12:17:50 --> Total execution time: 0.0791
INFO - 2021-07-03 09:17:53 --> Config Class Initialized
INFO - 2021-07-03 09:17:53 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:17:53 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:17:53 --> Utf8 Class Initialized
INFO - 2021-07-03 09:17:53 --> URI Class Initialized
INFO - 2021-07-03 09:17:53 --> Router Class Initialized
INFO - 2021-07-03 09:17:53 --> Output Class Initialized
INFO - 2021-07-03 09:17:53 --> Security Class Initialized
DEBUG - 2021-07-03 09:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:17:53 --> Input Class Initialized
INFO - 2021-07-03 09:17:53 --> Language Class Initialized
INFO - 2021-07-03 09:17:53 --> Loader Class Initialized
INFO - 2021-07-03 09:17:53 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:17:53 --> Helper loaded: url_helper
INFO - 2021-07-03 09:17:53 --> Helper loaded: file_helper
INFO - 2021-07-03 09:17:53 --> Helper loaded: form_helper
INFO - 2021-07-03 09:17:53 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:17:53 --> Helper loaded: security_helper
INFO - 2021-07-03 09:17:53 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:17:53 --> Helper loaded: language_helper
INFO - 2021-07-03 09:17:53 --> Helper loaded: general_helper
INFO - 2021-07-03 09:17:53 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:17:53 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:17:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:17:53 --> Parser Class Initialized
INFO - 2021-07-03 09:17:53 --> Form Validation Class Initialized
INFO - 2021-07-03 09:17:53 --> Upload Class Initialized
INFO - 2021-07-03 09:17:53 --> Email Class Initialized
INFO - 2021-07-03 09:17:53 --> MY_Model class loaded
INFO - 2021-07-03 09:17:53 --> Model "Users_model" initialized
INFO - 2021-07-03 09:17:53 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:17:53 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:17:53 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:17:53 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:17:53 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:17:53 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:17:53 --> Database Driver Class Initialized
INFO - 2021-07-03 09:17:53 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:17:53 --> Controller Class Initialized
ERROR - 2021-07-03 12:17:53 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 12:17:53 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-03 12:17:53 --> Final output sent to browser
DEBUG - 2021-07-03 12:17:53 --> Total execution time: 0.2482
INFO - 2021-07-03 09:17:56 --> Config Class Initialized
INFO - 2021-07-03 09:17:56 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:17:56 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:17:56 --> Utf8 Class Initialized
INFO - 2021-07-03 09:17:56 --> URI Class Initialized
INFO - 2021-07-03 09:17:56 --> Router Class Initialized
INFO - 2021-07-03 09:17:56 --> Output Class Initialized
INFO - 2021-07-03 09:17:56 --> Security Class Initialized
DEBUG - 2021-07-03 09:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:17:56 --> Input Class Initialized
INFO - 2021-07-03 09:17:56 --> Language Class Initialized
INFO - 2021-07-03 09:17:56 --> Loader Class Initialized
INFO - 2021-07-03 09:17:56 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:17:56 --> Helper loaded: url_helper
INFO - 2021-07-03 09:17:56 --> Helper loaded: file_helper
INFO - 2021-07-03 09:17:56 --> Helper loaded: form_helper
INFO - 2021-07-03 09:17:56 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:17:56 --> Helper loaded: security_helper
INFO - 2021-07-03 09:17:56 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:17:56 --> Helper loaded: language_helper
INFO - 2021-07-03 09:17:56 --> Helper loaded: general_helper
INFO - 2021-07-03 09:17:56 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:17:56 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:17:56 --> Parser Class Initialized
INFO - 2021-07-03 09:17:56 --> Form Validation Class Initialized
INFO - 2021-07-03 09:17:56 --> Upload Class Initialized
INFO - 2021-07-03 09:17:56 --> Email Class Initialized
INFO - 2021-07-03 09:17:56 --> MY_Model class loaded
INFO - 2021-07-03 09:17:56 --> Model "Users_model" initialized
INFO - 2021-07-03 09:17:56 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:17:56 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:17:56 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:17:56 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:17:56 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:17:56 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:17:56 --> Database Driver Class Initialized
INFO - 2021-07-03 09:17:56 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:17:56 --> Controller Class Initialized
ERROR - 2021-07-03 12:17:56 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 12:17:56 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-03 12:17:56 --> Final output sent to browser
DEBUG - 2021-07-03 12:17:56 --> Total execution time: 0.0862
INFO - 2021-07-03 09:17:59 --> Config Class Initialized
INFO - 2021-07-03 09:17:59 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:17:59 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:17:59 --> Utf8 Class Initialized
INFO - 2021-07-03 09:17:59 --> URI Class Initialized
INFO - 2021-07-03 09:17:59 --> Router Class Initialized
INFO - 2021-07-03 09:17:59 --> Output Class Initialized
INFO - 2021-07-03 09:17:59 --> Security Class Initialized
DEBUG - 2021-07-03 09:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:17:59 --> Input Class Initialized
INFO - 2021-07-03 09:17:59 --> Language Class Initialized
INFO - 2021-07-03 09:17:59 --> Loader Class Initialized
INFO - 2021-07-03 09:17:59 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:17:59 --> Helper loaded: url_helper
INFO - 2021-07-03 09:17:59 --> Helper loaded: file_helper
INFO - 2021-07-03 09:17:59 --> Helper loaded: form_helper
INFO - 2021-07-03 09:17:59 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:17:59 --> Helper loaded: security_helper
INFO - 2021-07-03 09:17:59 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:17:59 --> Helper loaded: language_helper
INFO - 2021-07-03 09:17:59 --> Helper loaded: general_helper
INFO - 2021-07-03 09:17:59 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:17:59 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:17:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:17:59 --> Parser Class Initialized
INFO - 2021-07-03 09:17:59 --> Form Validation Class Initialized
INFO - 2021-07-03 09:17:59 --> Upload Class Initialized
INFO - 2021-07-03 09:17:59 --> Email Class Initialized
INFO - 2021-07-03 09:17:59 --> MY_Model class loaded
INFO - 2021-07-03 09:17:59 --> Model "Users_model" initialized
INFO - 2021-07-03 09:17:59 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:17:59 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:17:59 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:17:59 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:17:59 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:17:59 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:17:59 --> Database Driver Class Initialized
INFO - 2021-07-03 09:17:59 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:17:59 --> Controller Class Initialized
ERROR - 2021-07-03 12:17:59 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 12:17:59 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-03 12:17:59 --> Final output sent to browser
DEBUG - 2021-07-03 12:17:59 --> Total execution time: 0.1391
INFO - 2021-07-03 09:18:55 --> Config Class Initialized
INFO - 2021-07-03 09:18:55 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:18:55 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:18:55 --> Utf8 Class Initialized
INFO - 2021-07-03 09:18:55 --> URI Class Initialized
INFO - 2021-07-03 09:18:55 --> Router Class Initialized
INFO - 2021-07-03 09:18:55 --> Output Class Initialized
INFO - 2021-07-03 09:18:55 --> Security Class Initialized
DEBUG - 2021-07-03 09:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:18:55 --> Input Class Initialized
INFO - 2021-07-03 09:18:55 --> Language Class Initialized
INFO - 2021-07-03 09:18:55 --> Loader Class Initialized
INFO - 2021-07-03 09:18:55 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:18:55 --> Helper loaded: url_helper
INFO - 2021-07-03 09:18:55 --> Helper loaded: file_helper
INFO - 2021-07-03 09:18:55 --> Helper loaded: form_helper
INFO - 2021-07-03 09:18:55 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:18:55 --> Helper loaded: security_helper
INFO - 2021-07-03 09:18:55 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:18:55 --> Helper loaded: language_helper
INFO - 2021-07-03 09:18:55 --> Helper loaded: general_helper
INFO - 2021-07-03 09:18:55 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:18:55 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:18:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:18:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:18:55 --> Parser Class Initialized
INFO - 2021-07-03 09:18:55 --> Form Validation Class Initialized
INFO - 2021-07-03 09:18:55 --> Upload Class Initialized
INFO - 2021-07-03 09:18:55 --> Email Class Initialized
INFO - 2021-07-03 09:18:55 --> MY_Model class loaded
INFO - 2021-07-03 09:18:55 --> Model "Users_model" initialized
INFO - 2021-07-03 09:18:55 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:18:55 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:18:55 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:18:55 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:18:55 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:18:55 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:18:55 --> Database Driver Class Initialized
INFO - 2021-07-03 09:18:55 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:18:55 --> Controller Class Initialized
ERROR - 2021-07-03 12:18:55 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 12:18:55 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-03 12:18:55 --> Final output sent to browser
DEBUG - 2021-07-03 12:18:55 --> Total execution time: 0.1272
INFO - 2021-07-03 09:18:57 --> Config Class Initialized
INFO - 2021-07-03 09:18:57 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:18:57 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:18:57 --> Utf8 Class Initialized
INFO - 2021-07-03 09:18:57 --> URI Class Initialized
INFO - 2021-07-03 09:18:57 --> Router Class Initialized
INFO - 2021-07-03 09:18:57 --> Output Class Initialized
INFO - 2021-07-03 09:18:57 --> Security Class Initialized
DEBUG - 2021-07-03 09:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:18:57 --> Input Class Initialized
INFO - 2021-07-03 09:18:57 --> Language Class Initialized
INFO - 2021-07-03 09:18:57 --> Loader Class Initialized
INFO - 2021-07-03 09:18:57 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:18:57 --> Helper loaded: url_helper
INFO - 2021-07-03 09:18:57 --> Helper loaded: file_helper
INFO - 2021-07-03 09:18:57 --> Helper loaded: form_helper
INFO - 2021-07-03 09:18:57 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:18:57 --> Helper loaded: security_helper
INFO - 2021-07-03 09:18:57 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:18:57 --> Helper loaded: language_helper
INFO - 2021-07-03 09:18:57 --> Helper loaded: general_helper
INFO - 2021-07-03 09:18:57 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:18:57 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:18:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:18:57 --> Parser Class Initialized
INFO - 2021-07-03 09:18:57 --> Form Validation Class Initialized
INFO - 2021-07-03 09:18:57 --> Upload Class Initialized
INFO - 2021-07-03 09:18:57 --> Email Class Initialized
INFO - 2021-07-03 09:18:57 --> MY_Model class loaded
INFO - 2021-07-03 09:18:57 --> Model "Users_model" initialized
INFO - 2021-07-03 09:18:57 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:18:57 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:18:57 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:18:57 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:18:57 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:18:57 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:18:57 --> Database Driver Class Initialized
INFO - 2021-07-03 09:18:57 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:18:57 --> Controller Class Initialized
ERROR - 2021-07-03 12:18:57 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 12:18:57 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-03 12:18:57 --> Final output sent to browser
DEBUG - 2021-07-03 12:18:57 --> Total execution time: 0.1846
INFO - 2021-07-03 09:20:45 --> Config Class Initialized
INFO - 2021-07-03 09:20:45 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:20:45 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:20:45 --> Utf8 Class Initialized
INFO - 2021-07-03 09:20:45 --> URI Class Initialized
INFO - 2021-07-03 09:20:45 --> Router Class Initialized
INFO - 2021-07-03 09:20:45 --> Output Class Initialized
INFO - 2021-07-03 09:20:45 --> Security Class Initialized
DEBUG - 2021-07-03 09:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:20:45 --> Input Class Initialized
INFO - 2021-07-03 09:20:45 --> Language Class Initialized
INFO - 2021-07-03 09:20:45 --> Loader Class Initialized
INFO - 2021-07-03 09:20:45 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:20:45 --> Helper loaded: url_helper
INFO - 2021-07-03 09:20:45 --> Helper loaded: file_helper
INFO - 2021-07-03 09:20:45 --> Helper loaded: form_helper
INFO - 2021-07-03 09:20:45 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:20:45 --> Helper loaded: security_helper
INFO - 2021-07-03 09:20:45 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:20:45 --> Helper loaded: language_helper
INFO - 2021-07-03 09:20:45 --> Helper loaded: general_helper
INFO - 2021-07-03 09:20:45 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:20:45 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:20:45 --> Parser Class Initialized
INFO - 2021-07-03 09:20:45 --> Form Validation Class Initialized
INFO - 2021-07-03 09:20:45 --> Upload Class Initialized
INFO - 2021-07-03 09:20:45 --> Email Class Initialized
INFO - 2021-07-03 09:20:45 --> MY_Model class loaded
INFO - 2021-07-03 09:20:45 --> Model "Users_model" initialized
INFO - 2021-07-03 09:20:45 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:20:45 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:20:45 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:20:45 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:20:45 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:20:45 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:20:45 --> Database Driver Class Initialized
INFO - 2021-07-03 09:20:45 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:20:45 --> Controller Class Initialized
INFO - 2021-07-03 09:20:45 --> Config Class Initialized
INFO - 2021-07-03 09:20:45 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:20:45 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:20:45 --> Utf8 Class Initialized
INFO - 2021-07-03 09:20:45 --> URI Class Initialized
INFO - 2021-07-03 09:20:45 --> Router Class Initialized
INFO - 2021-07-03 09:20:45 --> Output Class Initialized
INFO - 2021-07-03 09:20:45 --> Security Class Initialized
DEBUG - 2021-07-03 09:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:20:45 --> Input Class Initialized
INFO - 2021-07-03 09:20:45 --> Language Class Initialized
INFO - 2021-07-03 09:20:45 --> Loader Class Initialized
INFO - 2021-07-03 09:20:45 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:20:45 --> Helper loaded: url_helper
INFO - 2021-07-03 09:20:45 --> Helper loaded: file_helper
INFO - 2021-07-03 09:20:45 --> Helper loaded: form_helper
INFO - 2021-07-03 09:20:45 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:20:45 --> Helper loaded: security_helper
INFO - 2021-07-03 09:20:45 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:20:45 --> Helper loaded: language_helper
INFO - 2021-07-03 09:20:45 --> Helper loaded: general_helper
INFO - 2021-07-03 09:20:45 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:20:45 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:20:45 --> Parser Class Initialized
INFO - 2021-07-03 09:20:45 --> Form Validation Class Initialized
INFO - 2021-07-03 09:20:45 --> Upload Class Initialized
INFO - 2021-07-03 09:20:45 --> Email Class Initialized
INFO - 2021-07-03 09:20:45 --> MY_Model class loaded
INFO - 2021-07-03 09:20:45 --> Model "Users_model" initialized
INFO - 2021-07-03 09:20:45 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:20:45 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:20:45 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:20:45 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:20:45 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:20:45 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:20:45 --> Database Driver Class Initialized
INFO - 2021-07-03 09:20:45 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:20:45 --> Controller Class Initialized
ERROR - 2021-07-03 12:20:45 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 12:20:45 --> File loaded: C:\wamp64\www\crm\application\views\users/list.php
INFO - 2021-07-03 12:20:45 --> Final output sent to browser
DEBUG - 2021-07-03 12:20:45 --> Total execution time: 0.1194
INFO - 2021-07-03 09:20:46 --> Config Class Initialized
INFO - 2021-07-03 09:20:46 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:20:46 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:20:46 --> Utf8 Class Initialized
INFO - 2021-07-03 09:20:46 --> URI Class Initialized
INFO - 2021-07-03 09:20:46 --> Router Class Initialized
INFO - 2021-07-03 09:20:46 --> Config Class Initialized
INFO - 2021-07-03 09:20:46 --> Output Class Initialized
INFO - 2021-07-03 09:20:46 --> Hooks Class Initialized
INFO - 2021-07-03 09:20:46 --> Security Class Initialized
DEBUG - 2021-07-03 09:20:46 --> UTF-8 Support Enabled
DEBUG - 2021-07-03 09:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:20:46 --> Utf8 Class Initialized
INFO - 2021-07-03 09:20:46 --> Input Class Initialized
INFO - 2021-07-03 09:20:46 --> Language Class Initialized
INFO - 2021-07-03 09:20:46 --> URI Class Initialized
INFO - 2021-07-03 09:20:46 --> Loader Class Initialized
INFO - 2021-07-03 09:20:46 --> Router Class Initialized
INFO - 2021-07-03 09:20:46 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:20:46 --> Output Class Initialized
INFO - 2021-07-03 09:20:46 --> Helper loaded: url_helper
INFO - 2021-07-03 09:20:46 --> Config Class Initialized
INFO - 2021-07-03 09:20:46 --> Security Class Initialized
INFO - 2021-07-03 09:20:46 --> Helper loaded: file_helper
INFO - 2021-07-03 09:20:46 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:20:46 --> Helper loaded: form_helper
INFO - 2021-07-03 09:20:46 --> Input Class Initialized
DEBUG - 2021-07-03 09:20:46 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:20:46 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:20:46 --> Utf8 Class Initialized
INFO - 2021-07-03 09:20:46 --> Language Class Initialized
INFO - 2021-07-03 09:20:46 --> Helper loaded: security_helper
INFO - 2021-07-03 09:20:46 --> URI Class Initialized
INFO - 2021-07-03 09:20:46 --> Loader Class Initialized
INFO - 2021-07-03 09:20:46 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:20:46 --> Router Class Initialized
INFO - 2021-07-03 09:20:46 --> Helper loaded: language_helper
INFO - 2021-07-03 09:20:46 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:20:46 --> Config Class Initialized
INFO - 2021-07-03 09:20:46 --> Helper loaded: general_helper
INFO - 2021-07-03 09:20:46 --> Output Class Initialized
INFO - 2021-07-03 09:20:46 --> Hooks Class Initialized
INFO - 2021-07-03 09:20:46 --> Helper loaded: url_helper
INFO - 2021-07-03 09:20:46 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:20:46 --> Security Class Initialized
INFO - 2021-07-03 09:20:46 --> Helper loaded: file_helper
DEBUG - 2021-07-03 09:20:46 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:20:46 --> Config Class Initialized
INFO - 2021-07-03 09:20:46 --> Utf8 Class Initialized
INFO - 2021-07-03 09:20:46 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:20:46 --> Helper loaded: form_helper
INFO - 2021-07-03 09:20:46 --> Hooks Class Initialized
INFO - 2021-07-03 09:20:46 --> Input Class Initialized
INFO - 2021-07-03 09:20:46 --> URI Class Initialized
INFO - 2021-07-03 09:20:46 --> Helper loaded: cookie_helper
DEBUG - 2021-07-03 09:20:46 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:20:46 --> Language Class Initialized
INFO - 2021-07-03 09:20:46 --> Helper loaded: security_helper
INFO - 2021-07-03 09:20:46 --> Utf8 Class Initialized
INFO - 2021-07-03 09:20:46 --> Router Class Initialized
INFO - 2021-07-03 09:20:46 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:20:46 --> Loader Class Initialized
INFO - 2021-07-03 09:20:46 --> URI Class Initialized
INFO - 2021-07-03 09:20:46 --> Output Class Initialized
DEBUG - 2021-07-03 09:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:20:46 --> Helper loaded: language_helper
INFO - 2021-07-03 09:20:46 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:20:46 --> Security Class Initialized
INFO - 2021-07-03 09:20:46 --> Router Class Initialized
INFO - 2021-07-03 09:20:46 --> Helper loaded: general_helper
INFO - 2021-07-03 09:20:46 --> Helper loaded: url_helper
INFO - 2021-07-03 09:20:46 --> Config Class Initialized
INFO - 2021-07-03 09:20:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2021-07-03 09:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:20:46 --> Output Class Initialized
INFO - 2021-07-03 09:20:46 --> Hooks Class Initialized
INFO - 2021-07-03 09:20:46 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:20:46 --> Helper loaded: file_helper
INFO - 2021-07-03 09:20:46 --> Input Class Initialized
INFO - 2021-07-03 09:20:46 --> Parser Class Initialized
INFO - 2021-07-03 09:20:46 --> Security Class Initialized
DEBUG - 2021-07-03 09:20:46 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:20:46 --> Language Class Initialized
INFO - 2021-07-03 09:20:46 --> Helper loaded: form_helper
INFO - 2021-07-03 09:20:46 --> Database Driver Class Initialized
INFO - 2021-07-03 09:20:46 --> Utf8 Class Initialized
INFO - 2021-07-03 09:20:46 --> Form Validation Class Initialized
DEBUG - 2021-07-03 09:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:20:46 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:20:46 --> Loader Class Initialized
INFO - 2021-07-03 09:20:46 --> Input Class Initialized
INFO - 2021-07-03 09:20:46 --> URI Class Initialized
INFO - 2021-07-03 09:20:46 --> Helper loaded: security_helper
INFO - 2021-07-03 09:20:46 --> Upload Class Initialized
INFO - 2021-07-03 09:20:46 --> Language Class Initialized
INFO - 2021-07-03 09:20:46 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:20:46 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:20:46 --> Router Class Initialized
INFO - 2021-07-03 09:20:46 --> Email Class Initialized
INFO - 2021-07-03 09:20:46 --> Helper loaded: url_helper
INFO - 2021-07-03 09:20:46 --> Loader Class Initialized
INFO - 2021-07-03 09:20:46 --> Helper loaded: language_helper
INFO - 2021-07-03 09:20:46 --> Output Class Initialized
INFO - 2021-07-03 09:20:46 --> MY_Model class loaded
DEBUG - 2021-07-03 09:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:20:46 --> Helper loaded: file_helper
INFO - 2021-07-03 09:20:46 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:20:46 --> Helper loaded: general_helper
INFO - 2021-07-03 09:20:46 --> Security Class Initialized
INFO - 2021-07-03 09:20:46 --> Model "Users_model" initialized
INFO - 2021-07-03 09:20:46 --> Helper loaded: form_helper
INFO - 2021-07-03 09:20:46 --> Helper loaded: url_helper
INFO - 2021-07-03 09:20:46 --> Model "Settings_model" initialized
DEBUG - 2021-07-03 09:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:20:46 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:20:46 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:20:46 --> Input Class Initialized
INFO - 2021-07-03 09:20:46 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:20:46 --> Helper loaded: file_helper
INFO - 2021-07-03 09:20:46 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:20:46 --> Database Driver Class Initialized
INFO - 2021-07-03 09:20:46 --> Helper loaded: security_helper
INFO - 2021-07-03 09:20:46 --> Language Class Initialized
INFO - 2021-07-03 09:20:46 --> Helper loaded: form_helper
INFO - 2021-07-03 09:20:46 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:20:46 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:20:46 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:20:46 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:20:46 --> Loader Class Initialized
INFO - 2021-07-03 09:20:46 --> Helper loaded: language_helper
INFO - 2021-07-03 09:20:46 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:20:46 --> Helper loaded: security_helper
INFO - 2021-07-03 09:20:46 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:20:46 --> Helper loaded: general_helper
INFO - 2021-07-03 09:20:46 --> Database Driver Class Initialized
INFO - 2021-07-03 09:20:46 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:20:46 --> Helper loaded: url_helper
INFO - 2021-07-03 09:20:46 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:20:46 --> Helper loaded: language_helper
INFO - 2021-07-03 09:20:46 --> Helper loaded: file_helper
INFO - 2021-07-03 09:20:46 --> Helper loaded: general_helper
INFO - 2021-07-03 09:20:46 --> Database Driver Class Initialized
INFO - 2021-07-03 09:20:46 --> Helper loaded: form_helper
INFO - 2021-07-03 09:20:46 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:20:46 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:20:46 --> Database Driver Class Initialized
INFO - 2021-07-03 09:20:46 --> Helper loaded: security_helper
INFO - 2021-07-03 09:20:46 --> Helper loaded: directory_helper
DEBUG - 2021-07-03 09:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:20:46 --> Helper loaded: language_helper
DEBUG - 2021-07-03 09:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:20:46 --> Helper loaded: general_helper
INFO - 2021-07-03 09:20:46 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:20:46 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-07-03 09:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:20:46 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:20:46 --> Controller Class Initialized
INFO - 2021-07-03 12:20:46 --> Final output sent to browser
DEBUG - 2021-07-03 12:20:46 --> Total execution time: 0.0605
INFO - 2021-07-03 09:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:20:46 --> Parser Class Initialized
INFO - 2021-07-03 09:20:46 --> Form Validation Class Initialized
INFO - 2021-07-03 09:20:46 --> Upload Class Initialized
INFO - 2021-07-03 09:20:46 --> Email Class Initialized
INFO - 2021-07-03 09:20:46 --> MY_Model class loaded
INFO - 2021-07-03 09:20:46 --> Model "Users_model" initialized
INFO - 2021-07-03 09:20:46 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:20:46 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:20:46 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:20:46 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:20:46 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:20:46 --> Config Class Initialized
INFO - 2021-07-03 09:20:46 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:20:46 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:20:46 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:20:46 --> Database Driver Class Initialized
INFO - 2021-07-03 09:20:46 --> Utf8 Class Initialized
INFO - 2021-07-03 09:20:46 --> URI Class Initialized
INFO - 2021-07-03 09:20:46 --> Router Class Initialized
INFO - 2021-07-03 09:20:46 --> Output Class Initialized
INFO - 2021-07-03 09:20:46 --> Security Class Initialized
DEBUG - 2021-07-03 09:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:20:46 --> Input Class Initialized
INFO - 2021-07-03 09:20:46 --> Language Class Initialized
INFO - 2021-07-03 09:20:46 --> Loader Class Initialized
INFO - 2021-07-03 09:20:46 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:20:46 --> Helper loaded: url_helper
INFO - 2021-07-03 09:20:46 --> Helper loaded: file_helper
INFO - 2021-07-03 09:20:46 --> Helper loaded: form_helper
INFO - 2021-07-03 09:20:46 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:20:46 --> Helper loaded: security_helper
INFO - 2021-07-03 09:20:46 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:20:46 --> Helper loaded: language_helper
INFO - 2021-07-03 09:20:46 --> Helper loaded: general_helper
INFO - 2021-07-03 09:20:46 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:20:46 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:20:46 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:20:46 --> Controller Class Initialized
INFO - 2021-07-03 12:20:46 --> Final output sent to browser
DEBUG - 2021-07-03 12:20:46 --> Total execution time: 0.0894
INFO - 2021-07-03 09:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:20:46 --> Parser Class Initialized
INFO - 2021-07-03 09:20:46 --> Form Validation Class Initialized
INFO - 2021-07-03 09:20:46 --> Upload Class Initialized
INFO - 2021-07-03 09:20:46 --> Email Class Initialized
INFO - 2021-07-03 09:20:46 --> MY_Model class loaded
INFO - 2021-07-03 09:20:46 --> Model "Users_model" initialized
INFO - 2021-07-03 09:20:46 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:20:46 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:20:46 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:20:46 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:20:46 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:20:46 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:20:46 --> Database Driver Class Initialized
INFO - 2021-07-03 09:20:46 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:20:46 --> Controller Class Initialized
INFO - 2021-07-03 12:20:46 --> Final output sent to browser
DEBUG - 2021-07-03 12:20:46 --> Total execution time: 0.1104
INFO - 2021-07-03 09:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:20:46 --> Parser Class Initialized
INFO - 2021-07-03 09:20:46 --> Form Validation Class Initialized
INFO - 2021-07-03 09:20:46 --> Upload Class Initialized
INFO - 2021-07-03 09:20:46 --> Email Class Initialized
INFO - 2021-07-03 09:20:46 --> MY_Model class loaded
INFO - 2021-07-03 09:20:46 --> Model "Users_model" initialized
INFO - 2021-07-03 09:20:46 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:20:46 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:20:46 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:20:46 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:20:46 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:20:46 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:20:46 --> Database Driver Class Initialized
INFO - 2021-07-03 09:20:46 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:20:46 --> Controller Class Initialized
INFO - 2021-07-03 12:20:46 --> Final output sent to browser
DEBUG - 2021-07-03 12:20:46 --> Total execution time: 0.1385
INFO - 2021-07-03 09:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:20:46 --> Parser Class Initialized
INFO - 2021-07-03 09:20:46 --> Form Validation Class Initialized
INFO - 2021-07-03 09:20:46 --> Upload Class Initialized
INFO - 2021-07-03 09:20:46 --> Email Class Initialized
INFO - 2021-07-03 09:20:46 --> MY_Model class loaded
INFO - 2021-07-03 09:20:46 --> Model "Users_model" initialized
INFO - 2021-07-03 09:20:46 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:20:46 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:20:46 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:20:46 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:20:46 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:20:46 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:20:46 --> Database Driver Class Initialized
INFO - 2021-07-03 09:20:46 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:20:46 --> Controller Class Initialized
INFO - 2021-07-03 12:20:46 --> Final output sent to browser
DEBUG - 2021-07-03 12:20:46 --> Total execution time: 0.1645
INFO - 2021-07-03 09:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:20:46 --> Parser Class Initialized
INFO - 2021-07-03 09:20:46 --> Form Validation Class Initialized
INFO - 2021-07-03 09:20:46 --> Upload Class Initialized
INFO - 2021-07-03 09:20:46 --> Email Class Initialized
INFO - 2021-07-03 09:20:46 --> MY_Model class loaded
INFO - 2021-07-03 09:20:46 --> Model "Users_model" initialized
INFO - 2021-07-03 09:20:46 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:20:46 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:20:46 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:20:46 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:20:46 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:20:46 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:20:46 --> Database Driver Class Initialized
INFO - 2021-07-03 09:20:46 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:20:46 --> Controller Class Initialized
INFO - 2021-07-03 12:20:46 --> Final output sent to browser
DEBUG - 2021-07-03 12:20:46 --> Total execution time: 0.2107
INFO - 2021-07-03 09:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:20:46 --> Parser Class Initialized
INFO - 2021-07-03 09:20:46 --> Form Validation Class Initialized
INFO - 2021-07-03 09:20:46 --> Upload Class Initialized
INFO - 2021-07-03 09:20:46 --> Email Class Initialized
INFO - 2021-07-03 09:20:46 --> MY_Model class loaded
INFO - 2021-07-03 09:20:46 --> Model "Users_model" initialized
INFO - 2021-07-03 09:20:46 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:20:46 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:20:46 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:20:46 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:20:46 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:20:46 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:20:46 --> Database Driver Class Initialized
INFO - 2021-07-03 09:20:46 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:20:46 --> Controller Class Initialized
INFO - 2021-07-03 12:20:46 --> Final output sent to browser
DEBUG - 2021-07-03 12:20:46 --> Total execution time: 0.1836
INFO - 2021-07-03 09:20:49 --> Config Class Initialized
INFO - 2021-07-03 09:20:49 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:20:49 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:20:49 --> Utf8 Class Initialized
INFO - 2021-07-03 09:20:49 --> URI Class Initialized
INFO - 2021-07-03 09:20:49 --> Router Class Initialized
INFO - 2021-07-03 09:20:49 --> Output Class Initialized
INFO - 2021-07-03 09:20:49 --> Security Class Initialized
DEBUG - 2021-07-03 09:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:20:49 --> Input Class Initialized
INFO - 2021-07-03 09:20:49 --> Language Class Initialized
INFO - 2021-07-03 09:20:49 --> Loader Class Initialized
INFO - 2021-07-03 09:20:49 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:20:49 --> Helper loaded: url_helper
INFO - 2021-07-03 09:20:49 --> Helper loaded: file_helper
INFO - 2021-07-03 09:20:49 --> Helper loaded: form_helper
INFO - 2021-07-03 09:20:49 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:20:49 --> Helper loaded: security_helper
INFO - 2021-07-03 09:20:49 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:20:49 --> Helper loaded: language_helper
INFO - 2021-07-03 09:20:49 --> Helper loaded: general_helper
INFO - 2021-07-03 09:20:49 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:20:49 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:20:49 --> Parser Class Initialized
INFO - 2021-07-03 09:20:49 --> Form Validation Class Initialized
INFO - 2021-07-03 09:20:49 --> Upload Class Initialized
INFO - 2021-07-03 09:20:49 --> Email Class Initialized
INFO - 2021-07-03 09:20:49 --> MY_Model class loaded
INFO - 2021-07-03 09:20:49 --> Model "Users_model" initialized
INFO - 2021-07-03 09:20:49 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:20:49 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:20:49 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:20:49 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:20:49 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:20:49 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:20:49 --> Database Driver Class Initialized
INFO - 2021-07-03 09:20:49 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:20:49 --> Controller Class Initialized
ERROR - 2021-07-03 12:20:49 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 12:20:49 --> File loaded: C:\wamp64\www\crm\application\views\users/add.php
INFO - 2021-07-03 12:20:49 --> Final output sent to browser
DEBUG - 2021-07-03 12:20:49 --> Total execution time: 0.0851
INFO - 2021-07-03 09:21:10 --> Config Class Initialized
INFO - 2021-07-03 09:21:10 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:21:10 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:21:10 --> Utf8 Class Initialized
INFO - 2021-07-03 09:21:10 --> URI Class Initialized
INFO - 2021-07-03 09:21:10 --> Router Class Initialized
INFO - 2021-07-03 09:21:10 --> Output Class Initialized
INFO - 2021-07-03 09:21:10 --> Security Class Initialized
DEBUG - 2021-07-03 09:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:21:10 --> Input Class Initialized
INFO - 2021-07-03 09:21:10 --> Language Class Initialized
INFO - 2021-07-03 09:21:10 --> Loader Class Initialized
INFO - 2021-07-03 09:21:10 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:21:10 --> Helper loaded: url_helper
INFO - 2021-07-03 09:21:10 --> Helper loaded: file_helper
INFO - 2021-07-03 09:21:10 --> Helper loaded: form_helper
INFO - 2021-07-03 09:21:10 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:21:10 --> Helper loaded: security_helper
INFO - 2021-07-03 09:21:10 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:21:10 --> Helper loaded: language_helper
INFO - 2021-07-03 09:21:10 --> Helper loaded: general_helper
INFO - 2021-07-03 09:21:10 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:21:10 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:21:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:21:10 --> Parser Class Initialized
INFO - 2021-07-03 09:21:10 --> Form Validation Class Initialized
INFO - 2021-07-03 09:21:10 --> Upload Class Initialized
INFO - 2021-07-03 09:21:10 --> Email Class Initialized
INFO - 2021-07-03 09:21:10 --> MY_Model class loaded
INFO - 2021-07-03 09:21:10 --> Model "Users_model" initialized
INFO - 2021-07-03 09:21:10 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:21:10 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:21:10 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:21:10 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:21:10 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:21:10 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:21:10 --> Database Driver Class Initialized
INFO - 2021-07-03 09:21:10 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:21:10 --> Controller Class Initialized
INFO - 2021-07-03 12:21:10 --> Final output sent to browser
DEBUG - 2021-07-03 12:21:10 --> Total execution time: 0.1117
INFO - 2021-07-03 09:21:13 --> Config Class Initialized
INFO - 2021-07-03 09:21:13 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:21:13 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:21:13 --> Utf8 Class Initialized
INFO - 2021-07-03 09:21:13 --> URI Class Initialized
INFO - 2021-07-03 09:21:13 --> Router Class Initialized
INFO - 2021-07-03 09:21:13 --> Output Class Initialized
INFO - 2021-07-03 09:21:13 --> Security Class Initialized
DEBUG - 2021-07-03 09:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:21:13 --> Input Class Initialized
INFO - 2021-07-03 09:21:13 --> Language Class Initialized
INFO - 2021-07-03 09:21:13 --> Loader Class Initialized
INFO - 2021-07-03 09:21:13 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:21:13 --> Helper loaded: url_helper
INFO - 2021-07-03 09:21:13 --> Helper loaded: file_helper
INFO - 2021-07-03 09:21:13 --> Helper loaded: form_helper
INFO - 2021-07-03 09:21:13 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:21:13 --> Helper loaded: security_helper
INFO - 2021-07-03 09:21:13 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:21:13 --> Helper loaded: language_helper
INFO - 2021-07-03 09:21:13 --> Helper loaded: general_helper
INFO - 2021-07-03 09:21:13 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:21:13 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:21:13 --> Parser Class Initialized
INFO - 2021-07-03 09:21:13 --> Form Validation Class Initialized
INFO - 2021-07-03 09:21:13 --> Upload Class Initialized
INFO - 2021-07-03 09:21:13 --> Email Class Initialized
INFO - 2021-07-03 09:21:13 --> MY_Model class loaded
INFO - 2021-07-03 09:21:13 --> Model "Users_model" initialized
INFO - 2021-07-03 09:21:13 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:21:13 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:21:13 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:21:13 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:21:13 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:21:13 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:21:13 --> Database Driver Class Initialized
INFO - 2021-07-03 09:21:13 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:21:13 --> Controller Class Initialized
INFO - 2021-07-03 12:21:13 --> Final output sent to browser
DEBUG - 2021-07-03 12:21:13 --> Total execution time: 0.0542
INFO - 2021-07-03 09:21:31 --> Config Class Initialized
INFO - 2021-07-03 09:21:31 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:21:31 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:21:31 --> Utf8 Class Initialized
INFO - 2021-07-03 09:21:31 --> URI Class Initialized
INFO - 2021-07-03 09:21:31 --> Router Class Initialized
INFO - 2021-07-03 09:21:31 --> Output Class Initialized
INFO - 2021-07-03 09:21:31 --> Security Class Initialized
DEBUG - 2021-07-03 09:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:21:31 --> Input Class Initialized
INFO - 2021-07-03 09:21:31 --> Language Class Initialized
INFO - 2021-07-03 09:21:31 --> Loader Class Initialized
INFO - 2021-07-03 09:21:31 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:21:31 --> Helper loaded: url_helper
INFO - 2021-07-03 09:21:31 --> Helper loaded: file_helper
INFO - 2021-07-03 09:21:31 --> Helper loaded: form_helper
INFO - 2021-07-03 09:21:31 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:21:31 --> Helper loaded: security_helper
INFO - 2021-07-03 09:21:31 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:21:31 --> Helper loaded: language_helper
INFO - 2021-07-03 09:21:31 --> Helper loaded: general_helper
INFO - 2021-07-03 09:21:31 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:21:31 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:21:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:21:31 --> Parser Class Initialized
INFO - 2021-07-03 09:21:31 --> Form Validation Class Initialized
INFO - 2021-07-03 09:21:31 --> Upload Class Initialized
INFO - 2021-07-03 09:21:31 --> Email Class Initialized
INFO - 2021-07-03 09:21:31 --> MY_Model class loaded
INFO - 2021-07-03 09:21:31 --> Model "Users_model" initialized
INFO - 2021-07-03 09:21:31 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:21:31 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:21:31 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:21:31 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:21:31 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:21:31 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:21:31 --> Database Driver Class Initialized
INFO - 2021-07-03 09:21:31 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:21:31 --> Controller Class Initialized
INFO - 2021-07-03 09:21:31 --> Config Class Initialized
INFO - 2021-07-03 09:21:31 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:21:31 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:21:31 --> Utf8 Class Initialized
INFO - 2021-07-03 09:21:31 --> URI Class Initialized
INFO - 2021-07-03 09:21:31 --> Router Class Initialized
INFO - 2021-07-03 09:21:31 --> Output Class Initialized
INFO - 2021-07-03 09:21:31 --> Security Class Initialized
DEBUG - 2021-07-03 09:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:21:31 --> Input Class Initialized
INFO - 2021-07-03 09:21:31 --> Language Class Initialized
INFO - 2021-07-03 09:21:31 --> Loader Class Initialized
INFO - 2021-07-03 09:21:31 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:21:31 --> Helper loaded: url_helper
INFO - 2021-07-03 09:21:31 --> Helper loaded: file_helper
INFO - 2021-07-03 09:21:31 --> Helper loaded: form_helper
INFO - 2021-07-03 09:21:31 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:21:31 --> Helper loaded: security_helper
INFO - 2021-07-03 09:21:31 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:21:31 --> Helper loaded: language_helper
INFO - 2021-07-03 09:21:31 --> Helper loaded: general_helper
INFO - 2021-07-03 09:21:31 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:21:31 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:21:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:21:31 --> Parser Class Initialized
INFO - 2021-07-03 09:21:31 --> Form Validation Class Initialized
INFO - 2021-07-03 09:21:31 --> Upload Class Initialized
INFO - 2021-07-03 09:21:31 --> Email Class Initialized
INFO - 2021-07-03 09:21:31 --> MY_Model class loaded
INFO - 2021-07-03 09:21:31 --> Model "Users_model" initialized
INFO - 2021-07-03 09:21:31 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:21:31 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:21:31 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:21:31 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:21:31 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:21:31 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:21:31 --> Database Driver Class Initialized
INFO - 2021-07-03 09:21:31 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:21:31 --> Controller Class Initialized
ERROR - 2021-07-03 12:21:31 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 12:21:31 --> File loaded: C:\wamp64\www\crm\application\views\users/list.php
INFO - 2021-07-03 12:21:31 --> Final output sent to browser
DEBUG - 2021-07-03 12:21:31 --> Total execution time: 0.1059
INFO - 2021-07-03 09:21:31 --> Config Class Initialized
INFO - 2021-07-03 09:21:31 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:21:31 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:21:31 --> Utf8 Class Initialized
INFO - 2021-07-03 09:21:31 --> URI Class Initialized
INFO - 2021-07-03 09:21:31 --> Router Class Initialized
INFO - 2021-07-03 09:21:31 --> Config Class Initialized
INFO - 2021-07-03 09:21:31 --> Hooks Class Initialized
INFO - 2021-07-03 09:21:31 --> Output Class Initialized
DEBUG - 2021-07-03 09:21:31 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:21:31 --> Security Class Initialized
INFO - 2021-07-03 09:21:31 --> Utf8 Class Initialized
DEBUG - 2021-07-03 09:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:21:31 --> URI Class Initialized
INFO - 2021-07-03 09:21:31 --> Input Class Initialized
INFO - 2021-07-03 09:21:31 --> Language Class Initialized
INFO - 2021-07-03 09:21:31 --> Router Class Initialized
INFO - 2021-07-03 09:21:31 --> Loader Class Initialized
INFO - 2021-07-03 09:21:31 --> Output Class Initialized
INFO - 2021-07-03 09:21:31 --> Config Class Initialized
INFO - 2021-07-03 09:21:31 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:21:31 --> Security Class Initialized
INFO - 2021-07-03 09:21:31 --> Hooks Class Initialized
INFO - 2021-07-03 09:21:31 --> Helper loaded: url_helper
DEBUG - 2021-07-03 09:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-03 09:21:31 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:21:31 --> Input Class Initialized
INFO - 2021-07-03 09:21:31 --> Helper loaded: file_helper
INFO - 2021-07-03 09:21:31 --> Utf8 Class Initialized
INFO - 2021-07-03 09:21:31 --> Language Class Initialized
INFO - 2021-07-03 09:21:31 --> Helper loaded: form_helper
INFO - 2021-07-03 09:21:31 --> URI Class Initialized
INFO - 2021-07-03 09:21:31 --> Loader Class Initialized
INFO - 2021-07-03 09:21:31 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:21:31 --> Router Class Initialized
INFO - 2021-07-03 09:21:31 --> Config Class Initialized
INFO - 2021-07-03 09:21:31 --> Helper loaded: security_helper
INFO - 2021-07-03 09:21:31 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:21:31 --> Hooks Class Initialized
INFO - 2021-07-03 09:21:31 --> Output Class Initialized
INFO - 2021-07-03 09:21:31 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:21:31 --> Helper loaded: url_helper
DEBUG - 2021-07-03 09:21:31 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:21:31 --> Security Class Initialized
INFO - 2021-07-03 09:21:31 --> Helper loaded: language_helper
INFO - 2021-07-03 09:21:31 --> Utf8 Class Initialized
INFO - 2021-07-03 09:21:31 --> Helper loaded: file_helper
DEBUG - 2021-07-03 09:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:21:31 --> Helper loaded: general_helper
INFO - 2021-07-03 09:21:31 --> URI Class Initialized
INFO - 2021-07-03 09:21:31 --> Input Class Initialized
INFO - 2021-07-03 09:21:31 --> Helper loaded: form_helper
INFO - 2021-07-03 09:21:31 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:21:31 --> Language Class Initialized
INFO - 2021-07-03 09:21:31 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:21:31 --> Router Class Initialized
INFO - 2021-07-03 09:21:31 --> Config Class Initialized
INFO - 2021-07-03 09:21:31 --> Database Driver Class Initialized
INFO - 2021-07-03 09:21:31 --> Loader Class Initialized
INFO - 2021-07-03 09:21:31 --> Helper loaded: security_helper
INFO - 2021-07-03 09:21:31 --> Hooks Class Initialized
INFO - 2021-07-03 09:21:31 --> Output Class Initialized
INFO - 2021-07-03 09:21:31 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:21:31 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:21:31 --> Security Class Initialized
DEBUG - 2021-07-03 09:21:31 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:21:31 --> Helper loaded: language_helper
INFO - 2021-07-03 09:21:31 --> Utf8 Class Initialized
INFO - 2021-07-03 09:21:31 --> Helper loaded: url_helper
DEBUG - 2021-07-03 09:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:21:31 --> Helper loaded: general_helper
DEBUG - 2021-07-03 09:21:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:21:31 --> Helper loaded: file_helper
INFO - 2021-07-03 09:21:31 --> URI Class Initialized
INFO - 2021-07-03 09:21:31 --> Input Class Initialized
INFO - 2021-07-03 09:21:31 --> Config Class Initialized
INFO - 2021-07-03 09:21:31 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:21:31 --> Hooks Class Initialized
INFO - 2021-07-03 09:21:31 --> Helper loaded: form_helper
INFO - 2021-07-03 09:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:21:31 --> Language Class Initialized
INFO - 2021-07-03 09:21:31 --> Router Class Initialized
INFO - 2021-07-03 09:21:31 --> Database Driver Class Initialized
INFO - 2021-07-03 09:21:31 --> Helper loaded: cookie_helper
DEBUG - 2021-07-03 09:21:31 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:21:31 --> Parser Class Initialized
INFO - 2021-07-03 09:21:31 --> Loader Class Initialized
INFO - 2021-07-03 09:21:31 --> Utf8 Class Initialized
INFO - 2021-07-03 09:21:31 --> Output Class Initialized
INFO - 2021-07-03 09:21:31 --> Helper loaded: security_helper
INFO - 2021-07-03 09:21:31 --> Form Validation Class Initialized
INFO - 2021-07-03 09:21:31 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:21:31 --> URI Class Initialized
INFO - 2021-07-03 09:21:31 --> Security Class Initialized
INFO - 2021-07-03 09:21:31 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:21:31 --> Helper loaded: url_helper
INFO - 2021-07-03 09:21:31 --> Upload Class Initialized
DEBUG - 2021-07-03 09:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:21:31 --> Helper loaded: language_helper
DEBUG - 2021-07-03 09:21:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:21:31 --> Router Class Initialized
INFO - 2021-07-03 09:21:31 --> Helper loaded: file_helper
INFO - 2021-07-03 09:21:31 --> Input Class Initialized
INFO - 2021-07-03 09:21:31 --> Helper loaded: general_helper
INFO - 2021-07-03 09:21:31 --> Email Class Initialized
INFO - 2021-07-03 09:21:31 --> Output Class Initialized
INFO - 2021-07-03 09:21:31 --> Helper loaded: form_helper
INFO - 2021-07-03 09:21:31 --> Language Class Initialized
INFO - 2021-07-03 09:21:31 --> MY_Model class loaded
INFO - 2021-07-03 09:21:31 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:21:31 --> Security Class Initialized
INFO - 2021-07-03 09:21:31 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:21:31 --> Model "Users_model" initialized
INFO - 2021-07-03 09:21:31 --> Loader Class Initialized
INFO - 2021-07-03 09:21:31 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:21:31 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:21:31 --> Helper loaded: security_helper
INFO - 2021-07-03 09:21:31 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:21:31 --> Input Class Initialized
INFO - 2021-07-03 09:21:31 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:21:31 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:21:31 --> Language Class Initialized
INFO - 2021-07-03 09:21:31 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:21:31 --> Helper loaded: url_helper
INFO - 2021-07-03 09:21:31 --> Helper loaded: language_helper
INFO - 2021-07-03 09:21:31 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:21:31 --> Loader Class Initialized
INFO - 2021-07-03 09:21:31 --> Helper loaded: file_helper
INFO - 2021-07-03 09:21:31 --> Helper loaded: general_helper
DEBUG - 2021-07-03 09:21:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:21:31 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:21:31 --> Helper loaded: form_helper
INFO - 2021-07-03 09:21:31 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:21:31 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:21:31 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:21:31 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:21:31 --> Helper loaded: url_helper
INFO - 2021-07-03 09:21:31 --> Database Driver Class Initialized
INFO - 2021-07-03 09:21:31 --> Database Driver Class Initialized
INFO - 2021-07-03 09:21:31 --> Helper loaded: security_helper
INFO - 2021-07-03 09:21:31 --> Helper loaded: file_helper
INFO - 2021-07-03 09:21:31 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:21:31 --> Helper loaded: form_helper
INFO - 2021-07-03 09:21:31 --> Helper loaded: language_helper
INFO - 2021-07-03 09:21:31 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:21:31 --> Helper loaded: general_helper
DEBUG - 2021-07-03 09:21:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:21:31 --> Helper loaded: security_helper
INFO - 2021-07-03 09:21:31 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:21:31 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:21:31 --> Database Driver Class Initialized
INFO - 2021-07-03 09:21:31 --> Helper loaded: language_helper
INFO - 2021-07-03 09:21:31 --> Helper loaded: general_helper
INFO - 2021-07-03 09:21:31 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:21:31 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:21:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-07-03 09:21:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:21:31 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:21:31 --> Controller Class Initialized
INFO - 2021-07-03 12:21:31 --> Final output sent to browser
DEBUG - 2021-07-03 12:21:31 --> Total execution time: 0.0606
INFO - 2021-07-03 09:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:21:31 --> Parser Class Initialized
INFO - 2021-07-03 09:21:31 --> Form Validation Class Initialized
INFO - 2021-07-03 09:21:31 --> Upload Class Initialized
INFO - 2021-07-03 09:21:31 --> Email Class Initialized
INFO - 2021-07-03 09:21:31 --> MY_Model class loaded
INFO - 2021-07-03 09:21:31 --> Model "Users_model" initialized
INFO - 2021-07-03 09:21:31 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:21:31 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:21:31 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:21:31 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:21:31 --> Config Class Initialized
INFO - 2021-07-03 09:21:31 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:21:31 --> Hooks Class Initialized
INFO - 2021-07-03 09:21:31 --> Model "Templates_model" initialized
DEBUG - 2021-07-03 09:21:31 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:21:31 --> Utf8 Class Initialized
INFO - 2021-07-03 09:21:31 --> Database Driver Class Initialized
INFO - 2021-07-03 09:21:31 --> URI Class Initialized
INFO - 2021-07-03 09:21:31 --> Router Class Initialized
INFO - 2021-07-03 09:21:31 --> Output Class Initialized
INFO - 2021-07-03 09:21:31 --> Security Class Initialized
DEBUG - 2021-07-03 09:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:21:31 --> Input Class Initialized
INFO - 2021-07-03 09:21:31 --> Language Class Initialized
INFO - 2021-07-03 09:21:31 --> Loader Class Initialized
INFO - 2021-07-03 09:21:31 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:21:31 --> Helper loaded: url_helper
INFO - 2021-07-03 09:21:31 --> Helper loaded: file_helper
INFO - 2021-07-03 09:21:31 --> Helper loaded: form_helper
INFO - 2021-07-03 09:21:31 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:21:31 --> Helper loaded: security_helper
INFO - 2021-07-03 09:21:31 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:21:31 --> Helper loaded: language_helper
INFO - 2021-07-03 09:21:31 --> Helper loaded: general_helper
INFO - 2021-07-03 09:21:31 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:21:31 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:21:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:21:31 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:21:31 --> Controller Class Initialized
INFO - 2021-07-03 12:21:31 --> Final output sent to browser
DEBUG - 2021-07-03 12:21:31 --> Total execution time: 0.0875
INFO - 2021-07-03 09:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:21:31 --> Parser Class Initialized
INFO - 2021-07-03 09:21:31 --> Form Validation Class Initialized
INFO - 2021-07-03 09:21:31 --> Upload Class Initialized
INFO - 2021-07-03 09:21:31 --> Email Class Initialized
INFO - 2021-07-03 09:21:31 --> MY_Model class loaded
INFO - 2021-07-03 09:21:31 --> Model "Users_model" initialized
INFO - 2021-07-03 09:21:31 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:21:31 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:21:31 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:21:31 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:21:31 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:21:31 --> Config Class Initialized
INFO - 2021-07-03 09:21:31 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:21:31 --> Hooks Class Initialized
INFO - 2021-07-03 09:21:31 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:21:31 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:21:31 --> Utf8 Class Initialized
INFO - 2021-07-03 09:21:31 --> URI Class Initialized
INFO - 2021-07-03 09:21:31 --> Router Class Initialized
INFO - 2021-07-03 09:21:31 --> Output Class Initialized
INFO - 2021-07-03 09:21:31 --> Security Class Initialized
DEBUG - 2021-07-03 09:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:21:31 --> Input Class Initialized
INFO - 2021-07-03 09:21:31 --> Language Class Initialized
INFO - 2021-07-03 09:21:31 --> Loader Class Initialized
INFO - 2021-07-03 09:21:31 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:21:31 --> Helper loaded: url_helper
INFO - 2021-07-03 09:21:31 --> Helper loaded: file_helper
INFO - 2021-07-03 09:21:31 --> Helper loaded: form_helper
INFO - 2021-07-03 09:21:31 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:21:31 --> Helper loaded: security_helper
INFO - 2021-07-03 09:21:31 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:21:31 --> Helper loaded: language_helper
INFO - 2021-07-03 09:21:31 --> Helper loaded: general_helper
INFO - 2021-07-03 09:21:31 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:21:31 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:21:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:21:31 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:21:31 --> Controller Class Initialized
INFO - 2021-07-03 12:21:31 --> Final output sent to browser
DEBUG - 2021-07-03 12:21:31 --> Total execution time: 0.1127
INFO - 2021-07-03 09:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:21:31 --> Parser Class Initialized
INFO - 2021-07-03 09:21:31 --> Form Validation Class Initialized
INFO - 2021-07-03 09:21:31 --> Upload Class Initialized
INFO - 2021-07-03 09:21:31 --> Email Class Initialized
INFO - 2021-07-03 09:21:31 --> MY_Model class loaded
INFO - 2021-07-03 09:21:31 --> Model "Users_model" initialized
INFO - 2021-07-03 09:21:31 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:21:31 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:21:31 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:21:31 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:21:31 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:21:31 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:21:31 --> Database Driver Class Initialized
INFO - 2021-07-03 09:21:31 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:21:31 --> Controller Class Initialized
INFO - 2021-07-03 12:21:31 --> Final output sent to browser
DEBUG - 2021-07-03 12:21:31 --> Total execution time: 0.1374
INFO - 2021-07-03 09:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:21:31 --> Parser Class Initialized
INFO - 2021-07-03 09:21:31 --> Form Validation Class Initialized
INFO - 2021-07-03 09:21:31 --> Upload Class Initialized
INFO - 2021-07-03 09:21:31 --> Email Class Initialized
INFO - 2021-07-03 09:21:31 --> MY_Model class loaded
INFO - 2021-07-03 09:21:31 --> Model "Users_model" initialized
INFO - 2021-07-03 09:21:31 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:21:31 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:21:31 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:21:31 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:21:31 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:21:31 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:21:31 --> Database Driver Class Initialized
INFO - 2021-07-03 09:21:32 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:21:32 --> Controller Class Initialized
INFO - 2021-07-03 12:21:32 --> Final output sent to browser
DEBUG - 2021-07-03 12:21:32 --> Total execution time: 0.1629
INFO - 2021-07-03 09:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:21:32 --> Parser Class Initialized
INFO - 2021-07-03 09:21:32 --> Form Validation Class Initialized
INFO - 2021-07-03 09:21:32 --> Upload Class Initialized
INFO - 2021-07-03 09:21:32 --> Email Class Initialized
INFO - 2021-07-03 09:21:32 --> MY_Model class loaded
INFO - 2021-07-03 09:21:32 --> Model "Users_model" initialized
INFO - 2021-07-03 09:21:32 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:21:32 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:21:32 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:21:32 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:21:32 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:21:32 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:21:32 --> Database Driver Class Initialized
INFO - 2021-07-03 09:21:32 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:21:32 --> Controller Class Initialized
INFO - 2021-07-03 12:21:32 --> Final output sent to browser
DEBUG - 2021-07-03 12:21:32 --> Total execution time: 0.1896
INFO - 2021-07-03 09:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:21:32 --> Parser Class Initialized
INFO - 2021-07-03 09:21:32 --> Form Validation Class Initialized
INFO - 2021-07-03 09:21:32 --> Upload Class Initialized
INFO - 2021-07-03 09:21:32 --> Email Class Initialized
INFO - 2021-07-03 09:21:32 --> MY_Model class loaded
INFO - 2021-07-03 09:21:32 --> Model "Users_model" initialized
INFO - 2021-07-03 09:21:32 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:21:32 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:21:32 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:21:32 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:21:32 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:21:32 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:21:32 --> Database Driver Class Initialized
INFO - 2021-07-03 09:21:32 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:21:32 --> Controller Class Initialized
INFO - 2021-07-03 12:21:32 --> Final output sent to browser
DEBUG - 2021-07-03 12:21:32 --> Total execution time: 0.1763
INFO - 2021-07-03 09:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:21:32 --> Parser Class Initialized
INFO - 2021-07-03 09:21:32 --> Form Validation Class Initialized
INFO - 2021-07-03 09:21:32 --> Upload Class Initialized
INFO - 2021-07-03 09:21:32 --> Email Class Initialized
INFO - 2021-07-03 09:21:32 --> MY_Model class loaded
INFO - 2021-07-03 09:21:32 --> Model "Users_model" initialized
INFO - 2021-07-03 09:21:32 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:21:32 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:21:32 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:21:32 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:21:32 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:21:32 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:21:32 --> Database Driver Class Initialized
INFO - 2021-07-03 09:21:32 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:21:32 --> Controller Class Initialized
INFO - 2021-07-03 12:21:32 --> Final output sent to browser
DEBUG - 2021-07-03 12:21:32 --> Total execution time: 0.1761
INFO - 2021-07-03 09:28:04 --> Config Class Initialized
INFO - 2021-07-03 09:28:04 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:28:04 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:28:04 --> Utf8 Class Initialized
INFO - 2021-07-03 09:28:04 --> URI Class Initialized
DEBUG - 2021-07-03 09:28:04 --> No URI present. Default controller set.
INFO - 2021-07-03 09:28:04 --> Router Class Initialized
INFO - 2021-07-03 09:28:04 --> Output Class Initialized
INFO - 2021-07-03 09:28:04 --> Security Class Initialized
DEBUG - 2021-07-03 09:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:28:04 --> Input Class Initialized
INFO - 2021-07-03 09:28:04 --> Language Class Initialized
INFO - 2021-07-03 09:28:04 --> Loader Class Initialized
INFO - 2021-07-03 09:28:04 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:28:04 --> Helper loaded: url_helper
INFO - 2021-07-03 09:28:04 --> Helper loaded: file_helper
INFO - 2021-07-03 09:28:04 --> Helper loaded: form_helper
INFO - 2021-07-03 09:28:04 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:28:04 --> Helper loaded: security_helper
INFO - 2021-07-03 09:28:04 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:28:04 --> Helper loaded: language_helper
INFO - 2021-07-03 09:28:04 --> Helper loaded: general_helper
INFO - 2021-07-03 09:28:04 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:28:04 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:28:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:28:04 --> Parser Class Initialized
INFO - 2021-07-03 09:28:04 --> Form Validation Class Initialized
INFO - 2021-07-03 09:28:04 --> Upload Class Initialized
INFO - 2021-07-03 09:28:04 --> Email Class Initialized
INFO - 2021-07-03 09:28:04 --> MY_Model class loaded
INFO - 2021-07-03 09:28:04 --> Model "Users_model" initialized
INFO - 2021-07-03 09:28:04 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:28:04 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:28:04 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:28:04 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:28:04 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:28:04 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:28:04 --> Database Driver Class Initialized
INFO - 2021-07-03 09:28:04 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:28:04 --> Controller Class Initialized
INFO - 2021-07-03 09:31:22 --> Config Class Initialized
INFO - 2021-07-03 09:31:22 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:31:22 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:31:22 --> Utf8 Class Initialized
INFO - 2021-07-03 09:31:22 --> URI Class Initialized
INFO - 2021-07-03 09:31:22 --> Router Class Initialized
INFO - 2021-07-03 09:31:22 --> Output Class Initialized
INFO - 2021-07-03 09:31:22 --> Security Class Initialized
DEBUG - 2021-07-03 09:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:31:22 --> Input Class Initialized
INFO - 2021-07-03 09:31:22 --> Language Class Initialized
INFO - 2021-07-03 09:31:22 --> Loader Class Initialized
INFO - 2021-07-03 09:31:22 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:31:22 --> Helper loaded: url_helper
INFO - 2021-07-03 09:31:22 --> Helper loaded: file_helper
INFO - 2021-07-03 09:31:22 --> Helper loaded: form_helper
INFO - 2021-07-03 09:31:22 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:31:22 --> Helper loaded: security_helper
INFO - 2021-07-03 09:31:22 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:31:22 --> Helper loaded: language_helper
INFO - 2021-07-03 09:31:22 --> Helper loaded: general_helper
INFO - 2021-07-03 09:31:22 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:31:22 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:31:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:31:22 --> Parser Class Initialized
INFO - 2021-07-03 09:31:22 --> Form Validation Class Initialized
INFO - 2021-07-03 09:31:22 --> Upload Class Initialized
INFO - 2021-07-03 09:31:22 --> Email Class Initialized
INFO - 2021-07-03 09:31:22 --> MY_Model class loaded
INFO - 2021-07-03 09:31:22 --> Model "Users_model" initialized
INFO - 2021-07-03 09:31:22 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:31:22 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:31:22 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:31:22 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:31:22 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:31:22 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:31:22 --> Database Driver Class Initialized
INFO - 2021-07-03 09:31:22 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:31:22 --> Controller Class Initialized
ERROR - 2021-07-03 12:31:22 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 12:31:22 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-03 12:31:22 --> Final output sent to browser
DEBUG - 2021-07-03 12:31:22 --> Total execution time: 0.5416
INFO - 2021-07-03 09:31:24 --> Config Class Initialized
INFO - 2021-07-03 09:31:24 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:31:24 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:31:24 --> Utf8 Class Initialized
INFO - 2021-07-03 09:31:24 --> URI Class Initialized
INFO - 2021-07-03 09:31:24 --> Router Class Initialized
INFO - 2021-07-03 09:31:24 --> Output Class Initialized
INFO - 2021-07-03 09:31:24 --> Security Class Initialized
DEBUG - 2021-07-03 09:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:31:24 --> Input Class Initialized
INFO - 2021-07-03 09:31:24 --> Language Class Initialized
INFO - 2021-07-03 09:31:24 --> Loader Class Initialized
INFO - 2021-07-03 09:31:24 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:31:24 --> Helper loaded: url_helper
INFO - 2021-07-03 09:31:24 --> Helper loaded: file_helper
INFO - 2021-07-03 09:31:24 --> Helper loaded: form_helper
INFO - 2021-07-03 09:31:24 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:31:24 --> Helper loaded: security_helper
INFO - 2021-07-03 09:31:24 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:31:24 --> Helper loaded: language_helper
INFO - 2021-07-03 09:31:24 --> Helper loaded: general_helper
INFO - 2021-07-03 09:31:24 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:31:24 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:31:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:31:24 --> Parser Class Initialized
INFO - 2021-07-03 09:31:24 --> Form Validation Class Initialized
INFO - 2021-07-03 09:31:24 --> Upload Class Initialized
INFO - 2021-07-03 09:31:24 --> Email Class Initialized
INFO - 2021-07-03 09:31:24 --> MY_Model class loaded
INFO - 2021-07-03 09:31:24 --> Model "Users_model" initialized
INFO - 2021-07-03 09:31:24 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:31:24 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:31:24 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:31:24 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:31:24 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:31:24 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:31:24 --> Database Driver Class Initialized
INFO - 2021-07-03 09:31:24 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:31:24 --> Controller Class Initialized
ERROR - 2021-07-03 12:31:24 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 12:31:24 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-03 12:31:24 --> Final output sent to browser
DEBUG - 2021-07-03 12:31:24 --> Total execution time: 0.1780
INFO - 2021-07-03 09:31:26 --> Config Class Initialized
INFO - 2021-07-03 09:31:26 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:31:26 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:31:26 --> Utf8 Class Initialized
INFO - 2021-07-03 09:31:26 --> URI Class Initialized
INFO - 2021-07-03 09:31:26 --> Router Class Initialized
INFO - 2021-07-03 09:31:26 --> Output Class Initialized
INFO - 2021-07-03 09:31:26 --> Security Class Initialized
DEBUG - 2021-07-03 09:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:31:26 --> Input Class Initialized
INFO - 2021-07-03 09:31:26 --> Language Class Initialized
INFO - 2021-07-03 09:31:26 --> Loader Class Initialized
INFO - 2021-07-03 09:31:26 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:31:26 --> Helper loaded: url_helper
INFO - 2021-07-03 09:31:26 --> Helper loaded: file_helper
INFO - 2021-07-03 09:31:26 --> Helper loaded: form_helper
INFO - 2021-07-03 09:31:26 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:31:26 --> Helper loaded: security_helper
INFO - 2021-07-03 09:31:26 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:31:26 --> Helper loaded: language_helper
INFO - 2021-07-03 09:31:26 --> Helper loaded: general_helper
INFO - 2021-07-03 09:31:26 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:31:26 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:31:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:31:26 --> Parser Class Initialized
INFO - 2021-07-03 09:31:26 --> Form Validation Class Initialized
INFO - 2021-07-03 09:31:26 --> Upload Class Initialized
INFO - 2021-07-03 09:31:26 --> Email Class Initialized
INFO - 2021-07-03 09:31:26 --> MY_Model class loaded
INFO - 2021-07-03 09:31:26 --> Model "Users_model" initialized
INFO - 2021-07-03 09:31:26 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:31:26 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:31:26 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:31:26 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:31:26 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:31:26 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:31:26 --> Database Driver Class Initialized
INFO - 2021-07-03 09:31:26 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:31:26 --> Controller Class Initialized
ERROR - 2021-07-03 12:31:26 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 12:31:26 --> File loaded: C:\wamp64\www\crm\application\views\blank_page.php
INFO - 2021-07-03 12:31:26 --> Final output sent to browser
DEBUG - 2021-07-03 12:31:26 --> Total execution time: 0.0648
INFO - 2021-07-03 09:31:30 --> Config Class Initialized
INFO - 2021-07-03 09:31:30 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:31:30 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:31:30 --> Utf8 Class Initialized
INFO - 2021-07-03 09:31:30 --> URI Class Initialized
INFO - 2021-07-03 09:31:30 --> Router Class Initialized
INFO - 2021-07-03 09:31:30 --> Output Class Initialized
INFO - 2021-07-03 09:31:30 --> Security Class Initialized
DEBUG - 2021-07-03 09:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:31:30 --> Input Class Initialized
INFO - 2021-07-03 09:31:30 --> Language Class Initialized
INFO - 2021-07-03 09:31:30 --> Loader Class Initialized
INFO - 2021-07-03 09:31:30 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:31:30 --> Helper loaded: url_helper
INFO - 2021-07-03 09:31:30 --> Helper loaded: file_helper
INFO - 2021-07-03 09:31:30 --> Helper loaded: form_helper
INFO - 2021-07-03 09:31:30 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:31:30 --> Helper loaded: security_helper
INFO - 2021-07-03 09:31:30 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:31:30 --> Helper loaded: language_helper
INFO - 2021-07-03 09:31:30 --> Helper loaded: general_helper
INFO - 2021-07-03 09:31:30 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:31:30 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:31:30 --> Parser Class Initialized
INFO - 2021-07-03 09:31:30 --> Form Validation Class Initialized
INFO - 2021-07-03 09:31:30 --> Upload Class Initialized
INFO - 2021-07-03 09:31:30 --> Email Class Initialized
INFO - 2021-07-03 09:31:30 --> MY_Model class loaded
INFO - 2021-07-03 09:31:30 --> Model "Users_model" initialized
INFO - 2021-07-03 09:31:30 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:31:30 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:31:30 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:31:30 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:31:30 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:31:30 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:31:30 --> Database Driver Class Initialized
INFO - 2021-07-03 09:31:30 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:31:30 --> Controller Class Initialized
ERROR - 2021-07-03 12:31:30 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 12:31:30 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-03 12:31:30 --> Final output sent to browser
DEBUG - 2021-07-03 12:31:30 --> Total execution time: 0.1267
INFO - 2021-07-03 09:31:31 --> Config Class Initialized
INFO - 2021-07-03 09:31:31 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:31:31 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:31:31 --> Utf8 Class Initialized
INFO - 2021-07-03 09:31:31 --> URI Class Initialized
INFO - 2021-07-03 09:31:31 --> Router Class Initialized
INFO - 2021-07-03 09:31:31 --> Output Class Initialized
INFO - 2021-07-03 09:31:31 --> Security Class Initialized
DEBUG - 2021-07-03 09:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:31:31 --> Input Class Initialized
INFO - 2021-07-03 09:31:31 --> Language Class Initialized
INFO - 2021-07-03 09:31:31 --> Loader Class Initialized
INFO - 2021-07-03 09:31:31 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:31:31 --> Helper loaded: url_helper
INFO - 2021-07-03 09:31:31 --> Helper loaded: file_helper
INFO - 2021-07-03 09:31:31 --> Helper loaded: form_helper
INFO - 2021-07-03 09:31:31 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:31:31 --> Helper loaded: security_helper
INFO - 2021-07-03 09:31:31 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:31:31 --> Helper loaded: language_helper
INFO - 2021-07-03 09:31:31 --> Helper loaded: general_helper
INFO - 2021-07-03 09:31:31 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:31:31 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:31:31 --> Parser Class Initialized
INFO - 2021-07-03 09:31:31 --> Form Validation Class Initialized
INFO - 2021-07-03 09:31:31 --> Upload Class Initialized
INFO - 2021-07-03 09:31:31 --> Email Class Initialized
INFO - 2021-07-03 09:31:31 --> MY_Model class loaded
INFO - 2021-07-03 09:31:31 --> Model "Users_model" initialized
INFO - 2021-07-03 09:31:31 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:31:31 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:31:31 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:31:31 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:31:31 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:31:31 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:31:31 --> Database Driver Class Initialized
INFO - 2021-07-03 09:31:31 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:31:31 --> Controller Class Initialized
ERROR - 2021-07-03 12:31:31 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 12:31:31 --> File loaded: C:\wamp64\www\crm\application\views\blank_page.php
INFO - 2021-07-03 12:31:31 --> Final output sent to browser
DEBUG - 2021-07-03 12:31:31 --> Total execution time: 0.0612
INFO - 2021-07-03 09:31:32 --> Config Class Initialized
INFO - 2021-07-03 09:31:32 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:31:32 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:31:32 --> Utf8 Class Initialized
INFO - 2021-07-03 09:31:32 --> URI Class Initialized
INFO - 2021-07-03 09:31:32 --> Router Class Initialized
INFO - 2021-07-03 09:31:32 --> Output Class Initialized
INFO - 2021-07-03 09:31:32 --> Security Class Initialized
DEBUG - 2021-07-03 09:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:31:32 --> Input Class Initialized
INFO - 2021-07-03 09:31:32 --> Language Class Initialized
INFO - 2021-07-03 09:31:32 --> Loader Class Initialized
INFO - 2021-07-03 09:31:32 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:31:32 --> Helper loaded: url_helper
INFO - 2021-07-03 09:31:32 --> Helper loaded: file_helper
INFO - 2021-07-03 09:31:32 --> Helper loaded: form_helper
INFO - 2021-07-03 09:31:32 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:31:32 --> Helper loaded: security_helper
INFO - 2021-07-03 09:31:32 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:31:32 --> Helper loaded: language_helper
INFO - 2021-07-03 09:31:32 --> Helper loaded: general_helper
INFO - 2021-07-03 09:31:32 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:31:32 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:31:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:31:32 --> Parser Class Initialized
INFO - 2021-07-03 09:31:32 --> Form Validation Class Initialized
INFO - 2021-07-03 09:31:32 --> Upload Class Initialized
INFO - 2021-07-03 09:31:32 --> Email Class Initialized
INFO - 2021-07-03 09:31:32 --> MY_Model class loaded
INFO - 2021-07-03 09:31:32 --> Model "Users_model" initialized
INFO - 2021-07-03 09:31:32 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:31:32 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:31:32 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:31:32 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:31:32 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:31:32 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:31:32 --> Database Driver Class Initialized
INFO - 2021-07-03 09:31:32 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:31:32 --> Controller Class Initialized
ERROR - 2021-07-03 12:31:32 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 12:31:32 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-03 12:31:32 --> Final output sent to browser
DEBUG - 2021-07-03 12:31:32 --> Total execution time: 0.0612
INFO - 2021-07-03 09:44:55 --> Config Class Initialized
INFO - 2021-07-03 09:44:55 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:44:55 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:44:55 --> Utf8 Class Initialized
INFO - 2021-07-03 09:44:55 --> URI Class Initialized
DEBUG - 2021-07-03 09:44:55 --> No URI present. Default controller set.
INFO - 2021-07-03 09:44:55 --> Router Class Initialized
INFO - 2021-07-03 09:44:55 --> Output Class Initialized
INFO - 2021-07-03 09:44:55 --> Security Class Initialized
DEBUG - 2021-07-03 09:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:44:55 --> Input Class Initialized
INFO - 2021-07-03 09:44:55 --> Language Class Initialized
INFO - 2021-07-03 09:44:55 --> Loader Class Initialized
INFO - 2021-07-03 09:44:55 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:44:55 --> Helper loaded: url_helper
INFO - 2021-07-03 09:44:55 --> Helper loaded: file_helper
INFO - 2021-07-03 09:44:55 --> Helper loaded: form_helper
INFO - 2021-07-03 09:44:55 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:44:55 --> Helper loaded: security_helper
INFO - 2021-07-03 09:44:55 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:44:55 --> Helper loaded: language_helper
INFO - 2021-07-03 09:44:55 --> Helper loaded: general_helper
INFO - 2021-07-03 09:44:55 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:44:55 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:44:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:44:55 --> Parser Class Initialized
INFO - 2021-07-03 09:44:55 --> Form Validation Class Initialized
INFO - 2021-07-03 09:44:55 --> Upload Class Initialized
INFO - 2021-07-03 09:44:55 --> Email Class Initialized
INFO - 2021-07-03 09:44:55 --> MY_Model class loaded
INFO - 2021-07-03 09:44:55 --> Model "Users_model" initialized
INFO - 2021-07-03 09:44:55 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:44:55 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:44:55 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:44:55 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:44:55 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:44:55 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:44:55 --> Database Driver Class Initialized
INFO - 2021-07-03 09:44:55 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:44:55 --> Controller Class Initialized
INFO - 2021-07-03 09:44:55 --> Config Class Initialized
INFO - 2021-07-03 09:44:55 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:44:55 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:44:55 --> Config Class Initialized
INFO - 2021-07-03 09:44:55 --> Utf8 Class Initialized
INFO - 2021-07-03 09:44:55 --> Hooks Class Initialized
INFO - 2021-07-03 09:44:55 --> URI Class Initialized
DEBUG - 2021-07-03 09:44:55 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:44:55 --> Utf8 Class Initialized
INFO - 2021-07-03 09:44:55 --> Router Class Initialized
INFO - 2021-07-03 09:44:55 --> URI Class Initialized
INFO - 2021-07-03 09:44:55 --> Output Class Initialized
INFO - 2021-07-03 09:44:55 --> Router Class Initialized
INFO - 2021-07-03 09:44:55 --> Security Class Initialized
INFO - 2021-07-03 09:44:55 --> Output Class Initialized
DEBUG - 2021-07-03 09:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:44:55 --> Input Class Initialized
INFO - 2021-07-03 09:44:55 --> Security Class Initialized
INFO - 2021-07-03 09:44:55 --> Language Class Initialized
DEBUG - 2021-07-03 09:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:44:55 --> Input Class Initialized
ERROR - 2021-07-03 09:44:55 --> 404 Page Not Found: Faviconico/index
INFO - 2021-07-03 09:44:55 --> Language Class Initialized
INFO - 2021-07-03 09:44:55 --> Loader Class Initialized
INFO - 2021-07-03 09:44:55 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:44:55 --> Helper loaded: url_helper
INFO - 2021-07-03 09:44:55 --> Helper loaded: file_helper
INFO - 2021-07-03 09:44:55 --> Helper loaded: form_helper
INFO - 2021-07-03 09:44:55 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:44:55 --> Helper loaded: security_helper
INFO - 2021-07-03 09:44:55 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:44:55 --> Helper loaded: language_helper
INFO - 2021-07-03 09:44:55 --> Helper loaded: general_helper
INFO - 2021-07-03 09:44:55 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:44:55 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:44:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:44:55 --> Parser Class Initialized
INFO - 2021-07-03 09:44:55 --> Form Validation Class Initialized
INFO - 2021-07-03 09:44:55 --> Upload Class Initialized
INFO - 2021-07-03 09:44:55 --> Email Class Initialized
INFO - 2021-07-03 09:44:55 --> MY_Model class loaded
INFO - 2021-07-03 09:44:55 --> Model "Users_model" initialized
INFO - 2021-07-03 09:44:55 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:44:55 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:44:55 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:44:55 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:44:55 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:44:55 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:44:55 --> Database Driver Class Initialized
INFO - 2021-07-03 09:44:55 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:44:55 --> Controller Class Initialized
INFO - 2021-07-03 12:44:55 --> File loaded: C:\wamp64\www\crm\application\views\account/login.php
INFO - 2021-07-03 12:44:55 --> Final output sent to browser
DEBUG - 2021-07-03 12:44:55 --> Total execution time: 0.0656
INFO - 2021-07-03 09:44:55 --> Config Class Initialized
INFO - 2021-07-03 09:44:55 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:44:55 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:44:55 --> Utf8 Class Initialized
INFO - 2021-07-03 09:44:55 --> URI Class Initialized
INFO - 2021-07-03 09:44:55 --> Router Class Initialized
INFO - 2021-07-03 09:44:55 --> Config Class Initialized
INFO - 2021-07-03 09:44:55 --> Output Class Initialized
INFO - 2021-07-03 09:44:55 --> Hooks Class Initialized
INFO - 2021-07-03 09:44:55 --> Security Class Initialized
DEBUG - 2021-07-03 09:44:55 --> UTF-8 Support Enabled
DEBUG - 2021-07-03 09:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:44:55 --> Utf8 Class Initialized
INFO - 2021-07-03 09:44:55 --> Input Class Initialized
INFO - 2021-07-03 09:44:55 --> URI Class Initialized
INFO - 2021-07-03 09:44:55 --> Language Class Initialized
INFO - 2021-07-03 09:44:55 --> Router Class Initialized
ERROR - 2021-07-03 09:44:55 --> 404 Page Not Found: Assets/jquery
INFO - 2021-07-03 09:44:55 --> Output Class Initialized
INFO - 2021-07-03 09:44:55 --> Security Class Initialized
DEBUG - 2021-07-03 09:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:44:55 --> Input Class Initialized
INFO - 2021-07-03 09:44:55 --> Language Class Initialized
ERROR - 2021-07-03 09:44:55 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-03 09:44:56 --> Config Class Initialized
INFO - 2021-07-03 09:44:56 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:44:56 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:44:56 --> Utf8 Class Initialized
INFO - 2021-07-03 09:44:56 --> URI Class Initialized
INFO - 2021-07-03 09:44:56 --> Router Class Initialized
INFO - 2021-07-03 09:44:56 --> Output Class Initialized
INFO - 2021-07-03 09:44:56 --> Security Class Initialized
DEBUG - 2021-07-03 09:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:44:56 --> Input Class Initialized
INFO - 2021-07-03 09:44:56 --> Language Class Initialized
ERROR - 2021-07-03 09:44:56 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-03 09:45:24 --> Config Class Initialized
INFO - 2021-07-03 09:45:24 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:45:24 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:45:24 --> Utf8 Class Initialized
INFO - 2021-07-03 09:45:24 --> URI Class Initialized
INFO - 2021-07-03 09:45:24 --> Router Class Initialized
INFO - 2021-07-03 09:45:24 --> Output Class Initialized
INFO - 2021-07-03 09:45:24 --> Security Class Initialized
DEBUG - 2021-07-03 09:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:45:24 --> Input Class Initialized
INFO - 2021-07-03 09:45:24 --> Language Class Initialized
INFO - 2021-07-03 09:45:24 --> Loader Class Initialized
INFO - 2021-07-03 09:45:24 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:45:24 --> Helper loaded: url_helper
INFO - 2021-07-03 09:45:24 --> Helper loaded: file_helper
INFO - 2021-07-03 09:45:24 --> Helper loaded: form_helper
INFO - 2021-07-03 09:45:24 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:45:24 --> Helper loaded: security_helper
INFO - 2021-07-03 09:45:24 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:45:24 --> Helper loaded: language_helper
INFO - 2021-07-03 09:45:24 --> Helper loaded: general_helper
INFO - 2021-07-03 09:45:24 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:45:24 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:45:24 --> Parser Class Initialized
INFO - 2021-07-03 09:45:24 --> Form Validation Class Initialized
INFO - 2021-07-03 09:45:24 --> Upload Class Initialized
INFO - 2021-07-03 09:45:24 --> Email Class Initialized
INFO - 2021-07-03 09:45:24 --> MY_Model class loaded
INFO - 2021-07-03 09:45:24 --> Model "Users_model" initialized
INFO - 2021-07-03 09:45:24 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:45:24 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:45:24 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:45:24 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:45:24 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:45:24 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:45:24 --> Database Driver Class Initialized
INFO - 2021-07-03 09:45:24 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:45:24 --> Controller Class Initialized
DEBUG - 2021-07-03 12:45:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-03 12:45:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2021-07-03 09:45:24 --> Config Class Initialized
INFO - 2021-07-03 09:45:24 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:45:24 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:45:24 --> Utf8 Class Initialized
INFO - 2021-07-03 09:45:24 --> URI Class Initialized
DEBUG - 2021-07-03 09:45:24 --> No URI present. Default controller set.
INFO - 2021-07-03 09:45:24 --> Router Class Initialized
INFO - 2021-07-03 09:45:24 --> Output Class Initialized
INFO - 2021-07-03 09:45:24 --> Security Class Initialized
DEBUG - 2021-07-03 09:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:45:24 --> Input Class Initialized
INFO - 2021-07-03 09:45:24 --> Language Class Initialized
INFO - 2021-07-03 09:45:24 --> Loader Class Initialized
INFO - 2021-07-03 09:45:24 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:45:24 --> Helper loaded: url_helper
INFO - 2021-07-03 09:45:24 --> Helper loaded: file_helper
INFO - 2021-07-03 09:45:24 --> Helper loaded: form_helper
INFO - 2021-07-03 09:45:24 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:45:24 --> Helper loaded: security_helper
INFO - 2021-07-03 09:45:24 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:45:24 --> Helper loaded: language_helper
INFO - 2021-07-03 09:45:24 --> Helper loaded: general_helper
INFO - 2021-07-03 09:45:24 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:45:24 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:45:24 --> Parser Class Initialized
INFO - 2021-07-03 09:45:24 --> Form Validation Class Initialized
INFO - 2021-07-03 09:45:24 --> Upload Class Initialized
INFO - 2021-07-03 09:45:24 --> Email Class Initialized
INFO - 2021-07-03 09:45:24 --> MY_Model class loaded
INFO - 2021-07-03 09:45:24 --> Model "Users_model" initialized
INFO - 2021-07-03 09:45:24 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:45:24 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:45:24 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:45:24 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:45:24 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:45:24 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:45:24 --> Database Driver Class Initialized
INFO - 2021-07-03 09:45:24 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:45:24 --> Controller Class Initialized
ERROR - 2021-07-03 12:45:24 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 12:45:24 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-03 12:45:24 --> Final output sent to browser
DEBUG - 2021-07-03 12:45:24 --> Total execution time: 0.0816
INFO - 2021-07-03 09:45:31 --> Config Class Initialized
INFO - 2021-07-03 09:45:31 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:45:31 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:45:31 --> Utf8 Class Initialized
INFO - 2021-07-03 09:45:31 --> URI Class Initialized
INFO - 2021-07-03 09:45:31 --> Router Class Initialized
INFO - 2021-07-03 09:45:31 --> Output Class Initialized
INFO - 2021-07-03 09:45:31 --> Security Class Initialized
DEBUG - 2021-07-03 09:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:45:31 --> Input Class Initialized
INFO - 2021-07-03 09:45:31 --> Language Class Initialized
INFO - 2021-07-03 09:45:31 --> Loader Class Initialized
INFO - 2021-07-03 09:45:31 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:45:31 --> Helper loaded: url_helper
INFO - 2021-07-03 09:45:31 --> Helper loaded: file_helper
INFO - 2021-07-03 09:45:31 --> Helper loaded: form_helper
INFO - 2021-07-03 09:45:31 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:45:31 --> Helper loaded: security_helper
INFO - 2021-07-03 09:45:31 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:45:31 --> Helper loaded: language_helper
INFO - 2021-07-03 09:45:31 --> Helper loaded: general_helper
INFO - 2021-07-03 09:45:31 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:45:31 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:45:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:45:31 --> Parser Class Initialized
INFO - 2021-07-03 09:45:31 --> Form Validation Class Initialized
INFO - 2021-07-03 09:45:31 --> Upload Class Initialized
INFO - 2021-07-03 09:45:31 --> Email Class Initialized
INFO - 2021-07-03 09:45:31 --> MY_Model class loaded
INFO - 2021-07-03 09:45:31 --> Model "Users_model" initialized
INFO - 2021-07-03 09:45:31 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:45:31 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:45:31 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:45:31 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:45:31 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:45:31 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:45:31 --> Database Driver Class Initialized
INFO - 2021-07-03 09:45:31 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:45:31 --> Controller Class Initialized
ERROR - 2021-07-03 12:45:31 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 12:45:31 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-03 12:45:31 --> Final output sent to browser
DEBUG - 2021-07-03 12:45:31 --> Total execution time: 0.2490
INFO - 2021-07-03 09:45:44 --> Config Class Initialized
INFO - 2021-07-03 09:45:44 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:45:44 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:45:44 --> Utf8 Class Initialized
INFO - 2021-07-03 09:45:44 --> URI Class Initialized
INFO - 2021-07-03 09:45:44 --> Router Class Initialized
INFO - 2021-07-03 09:45:44 --> Output Class Initialized
INFO - 2021-07-03 09:45:44 --> Security Class Initialized
DEBUG - 2021-07-03 09:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:45:44 --> Input Class Initialized
INFO - 2021-07-03 09:45:44 --> Language Class Initialized
INFO - 2021-07-03 09:45:44 --> Loader Class Initialized
INFO - 2021-07-03 09:45:44 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:45:44 --> Helper loaded: url_helper
INFO - 2021-07-03 09:45:44 --> Helper loaded: file_helper
INFO - 2021-07-03 09:45:44 --> Helper loaded: form_helper
INFO - 2021-07-03 09:45:44 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:45:44 --> Helper loaded: security_helper
INFO - 2021-07-03 09:45:44 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:45:44 --> Helper loaded: language_helper
INFO - 2021-07-03 09:45:44 --> Helper loaded: general_helper
INFO - 2021-07-03 09:45:44 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:45:44 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:45:44 --> Parser Class Initialized
INFO - 2021-07-03 09:45:44 --> Form Validation Class Initialized
INFO - 2021-07-03 09:45:44 --> Upload Class Initialized
INFO - 2021-07-03 09:45:44 --> Email Class Initialized
INFO - 2021-07-03 09:45:44 --> MY_Model class loaded
INFO - 2021-07-03 09:45:44 --> Model "Users_model" initialized
INFO - 2021-07-03 09:45:44 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:45:44 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:45:44 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:45:44 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:45:44 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:45:44 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:45:44 --> Database Driver Class Initialized
INFO - 2021-07-03 09:45:44 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:45:44 --> Controller Class Initialized
ERROR - 2021-07-03 12:45:44 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 12:45:44 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-03 12:45:44 --> Final output sent to browser
DEBUG - 2021-07-03 12:45:44 --> Total execution time: 0.1256
INFO - 2021-07-03 09:45:48 --> Config Class Initialized
INFO - 2021-07-03 09:45:48 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:45:48 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:45:48 --> Utf8 Class Initialized
INFO - 2021-07-03 09:45:48 --> URI Class Initialized
INFO - 2021-07-03 09:45:48 --> Router Class Initialized
INFO - 2021-07-03 09:45:48 --> Output Class Initialized
INFO - 2021-07-03 09:45:48 --> Security Class Initialized
DEBUG - 2021-07-03 09:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:45:48 --> Input Class Initialized
INFO - 2021-07-03 09:45:48 --> Language Class Initialized
INFO - 2021-07-03 09:45:48 --> Loader Class Initialized
INFO - 2021-07-03 09:45:48 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:45:48 --> Helper loaded: url_helper
INFO - 2021-07-03 09:45:48 --> Helper loaded: file_helper
INFO - 2021-07-03 09:45:48 --> Helper loaded: form_helper
INFO - 2021-07-03 09:45:48 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:45:48 --> Helper loaded: security_helper
INFO - 2021-07-03 09:45:48 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:45:48 --> Helper loaded: language_helper
INFO - 2021-07-03 09:45:48 --> Helper loaded: general_helper
INFO - 2021-07-03 09:45:48 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:45:48 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:45:48 --> Parser Class Initialized
INFO - 2021-07-03 09:45:48 --> Form Validation Class Initialized
INFO - 2021-07-03 09:45:48 --> Upload Class Initialized
INFO - 2021-07-03 09:45:48 --> Email Class Initialized
INFO - 2021-07-03 09:45:48 --> MY_Model class loaded
INFO - 2021-07-03 09:45:48 --> Model "Users_model" initialized
INFO - 2021-07-03 09:45:48 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:45:48 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:45:48 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:45:48 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:45:48 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:45:48 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:45:48 --> Database Driver Class Initialized
INFO - 2021-07-03 09:45:48 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:45:48 --> Controller Class Initialized
ERROR - 2021-07-03 12:45:48 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 12:45:48 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-03 12:45:48 --> Final output sent to browser
DEBUG - 2021-07-03 12:45:48 --> Total execution time: 0.0638
INFO - 2021-07-03 09:45:51 --> Config Class Initialized
INFO - 2021-07-03 09:45:51 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:45:51 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:45:51 --> Utf8 Class Initialized
INFO - 2021-07-03 09:45:51 --> URI Class Initialized
INFO - 2021-07-03 09:45:51 --> Router Class Initialized
INFO - 2021-07-03 09:45:51 --> Output Class Initialized
INFO - 2021-07-03 09:45:51 --> Security Class Initialized
DEBUG - 2021-07-03 09:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:45:51 --> Input Class Initialized
INFO - 2021-07-03 09:45:51 --> Language Class Initialized
INFO - 2021-07-03 09:45:51 --> Loader Class Initialized
INFO - 2021-07-03 09:45:51 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:45:51 --> Helper loaded: url_helper
INFO - 2021-07-03 09:45:51 --> Helper loaded: file_helper
INFO - 2021-07-03 09:45:51 --> Helper loaded: form_helper
INFO - 2021-07-03 09:45:51 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:45:51 --> Helper loaded: security_helper
INFO - 2021-07-03 09:45:51 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:45:51 --> Helper loaded: language_helper
INFO - 2021-07-03 09:45:51 --> Helper loaded: general_helper
INFO - 2021-07-03 09:45:51 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:45:51 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:45:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:45:51 --> Parser Class Initialized
INFO - 2021-07-03 09:45:51 --> Form Validation Class Initialized
INFO - 2021-07-03 09:45:51 --> Upload Class Initialized
INFO - 2021-07-03 09:45:51 --> Email Class Initialized
INFO - 2021-07-03 09:45:51 --> MY_Model class loaded
INFO - 2021-07-03 09:45:51 --> Model "Users_model" initialized
INFO - 2021-07-03 09:45:51 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:45:51 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:45:51 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:45:51 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:45:51 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:45:51 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:45:51 --> Database Driver Class Initialized
INFO - 2021-07-03 09:45:51 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:45:51 --> Controller Class Initialized
ERROR - 2021-07-03 12:45:51 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 12:45:51 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-03 12:45:51 --> Final output sent to browser
DEBUG - 2021-07-03 12:45:51 --> Total execution time: 0.1299
INFO - 2021-07-03 09:45:53 --> Config Class Initialized
INFO - 2021-07-03 09:45:53 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:45:53 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:45:53 --> Utf8 Class Initialized
INFO - 2021-07-03 09:45:53 --> URI Class Initialized
INFO - 2021-07-03 09:45:53 --> Router Class Initialized
INFO - 2021-07-03 09:45:53 --> Output Class Initialized
INFO - 2021-07-03 09:45:53 --> Security Class Initialized
DEBUG - 2021-07-03 09:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:45:53 --> Input Class Initialized
INFO - 2021-07-03 09:45:53 --> Language Class Initialized
INFO - 2021-07-03 09:45:53 --> Loader Class Initialized
INFO - 2021-07-03 09:45:53 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:45:53 --> Helper loaded: url_helper
INFO - 2021-07-03 09:45:53 --> Helper loaded: file_helper
INFO - 2021-07-03 09:45:53 --> Helper loaded: form_helper
INFO - 2021-07-03 09:45:53 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:45:53 --> Helper loaded: security_helper
INFO - 2021-07-03 09:45:53 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:45:53 --> Helper loaded: language_helper
INFO - 2021-07-03 09:45:53 --> Helper loaded: general_helper
INFO - 2021-07-03 09:45:53 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:45:53 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:45:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:45:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:45:53 --> Parser Class Initialized
INFO - 2021-07-03 09:45:53 --> Form Validation Class Initialized
INFO - 2021-07-03 09:45:53 --> Upload Class Initialized
INFO - 2021-07-03 09:45:53 --> Email Class Initialized
INFO - 2021-07-03 09:45:53 --> MY_Model class loaded
INFO - 2021-07-03 09:45:53 --> Model "Users_model" initialized
INFO - 2021-07-03 09:45:53 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:45:53 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:45:53 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:45:53 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:45:53 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:45:53 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:45:53 --> Database Driver Class Initialized
INFO - 2021-07-03 09:45:53 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:45:53 --> Controller Class Initialized
ERROR - 2021-07-03 12:45:53 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 12:45:53 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-03 12:45:53 --> Final output sent to browser
DEBUG - 2021-07-03 12:45:53 --> Total execution time: 0.0599
INFO - 2021-07-03 09:47:09 --> Config Class Initialized
INFO - 2021-07-03 09:47:09 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:47:09 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:47:09 --> Utf8 Class Initialized
INFO - 2021-07-03 09:47:09 --> URI Class Initialized
INFO - 2021-07-03 09:47:09 --> Router Class Initialized
INFO - 2021-07-03 09:47:09 --> Output Class Initialized
INFO - 2021-07-03 09:47:09 --> Security Class Initialized
DEBUG - 2021-07-03 09:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:47:09 --> Input Class Initialized
INFO - 2021-07-03 09:47:09 --> Language Class Initialized
INFO - 2021-07-03 09:47:09 --> Loader Class Initialized
INFO - 2021-07-03 09:47:09 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:47:09 --> Helper loaded: url_helper
INFO - 2021-07-03 09:47:09 --> Helper loaded: file_helper
INFO - 2021-07-03 09:47:09 --> Helper loaded: form_helper
INFO - 2021-07-03 09:47:09 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:47:09 --> Helper loaded: security_helper
INFO - 2021-07-03 09:47:09 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:47:09 --> Helper loaded: language_helper
INFO - 2021-07-03 09:47:09 --> Helper loaded: general_helper
INFO - 2021-07-03 09:47:09 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:47:09 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:47:09 --> Parser Class Initialized
INFO - 2021-07-03 09:47:09 --> Form Validation Class Initialized
INFO - 2021-07-03 09:47:09 --> Upload Class Initialized
INFO - 2021-07-03 09:47:09 --> Email Class Initialized
INFO - 2021-07-03 09:47:09 --> MY_Model class loaded
INFO - 2021-07-03 09:47:09 --> Model "Users_model" initialized
INFO - 2021-07-03 09:47:09 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:47:09 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:47:09 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:47:09 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:47:09 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:47:09 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:47:09 --> Database Driver Class Initialized
INFO - 2021-07-03 09:47:09 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:47:09 --> Controller Class Initialized
ERROR - 2021-07-03 12:47:09 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 12:47:09 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-03 12:47:09 --> Final output sent to browser
DEBUG - 2021-07-03 12:47:09 --> Total execution time: 0.5432
INFO - 2021-07-03 09:47:11 --> Config Class Initialized
INFO - 2021-07-03 09:47:11 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:47:11 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:47:11 --> Utf8 Class Initialized
INFO - 2021-07-03 09:47:11 --> URI Class Initialized
INFO - 2021-07-03 09:47:11 --> Router Class Initialized
INFO - 2021-07-03 09:47:11 --> Output Class Initialized
INFO - 2021-07-03 09:47:11 --> Security Class Initialized
DEBUG - 2021-07-03 09:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:47:11 --> Input Class Initialized
INFO - 2021-07-03 09:47:11 --> Language Class Initialized
INFO - 2021-07-03 09:47:11 --> Loader Class Initialized
INFO - 2021-07-03 09:47:11 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:47:11 --> Helper loaded: url_helper
INFO - 2021-07-03 09:47:11 --> Helper loaded: file_helper
INFO - 2021-07-03 09:47:11 --> Helper loaded: form_helper
INFO - 2021-07-03 09:47:11 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:47:11 --> Helper loaded: security_helper
INFO - 2021-07-03 09:47:11 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:47:11 --> Helper loaded: language_helper
INFO - 2021-07-03 09:47:11 --> Helper loaded: general_helper
INFO - 2021-07-03 09:47:11 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:47:11 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:47:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:47:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:47:11 --> Parser Class Initialized
INFO - 2021-07-03 09:47:11 --> Form Validation Class Initialized
INFO - 2021-07-03 09:47:11 --> Upload Class Initialized
INFO - 2021-07-03 09:47:11 --> Email Class Initialized
INFO - 2021-07-03 09:47:11 --> MY_Model class loaded
INFO - 2021-07-03 09:47:11 --> Model "Users_model" initialized
INFO - 2021-07-03 09:47:11 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:47:11 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:47:11 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:47:11 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:47:11 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:47:11 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:47:11 --> Database Driver Class Initialized
INFO - 2021-07-03 09:47:11 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:47:11 --> Controller Class Initialized
ERROR - 2021-07-03 12:47:11 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 12:47:12 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-03 12:47:12 --> Final output sent to browser
DEBUG - 2021-07-03 12:47:12 --> Total execution time: 0.1651
INFO - 2021-07-03 09:47:17 --> Config Class Initialized
INFO - 2021-07-03 09:47:17 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:47:17 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:47:17 --> Utf8 Class Initialized
INFO - 2021-07-03 09:47:17 --> URI Class Initialized
INFO - 2021-07-03 09:47:17 --> Router Class Initialized
INFO - 2021-07-03 09:47:17 --> Output Class Initialized
INFO - 2021-07-03 09:47:17 --> Security Class Initialized
DEBUG - 2021-07-03 09:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:47:17 --> Input Class Initialized
INFO - 2021-07-03 09:47:17 --> Language Class Initialized
INFO - 2021-07-03 09:47:17 --> Loader Class Initialized
INFO - 2021-07-03 09:47:17 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:47:17 --> Helper loaded: url_helper
INFO - 2021-07-03 09:47:17 --> Helper loaded: file_helper
INFO - 2021-07-03 09:47:17 --> Helper loaded: form_helper
INFO - 2021-07-03 09:47:17 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:47:17 --> Helper loaded: security_helper
INFO - 2021-07-03 09:47:17 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:47:17 --> Helper loaded: language_helper
INFO - 2021-07-03 09:47:17 --> Helper loaded: general_helper
INFO - 2021-07-03 09:47:17 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:47:17 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:47:17 --> Parser Class Initialized
INFO - 2021-07-03 09:47:17 --> Form Validation Class Initialized
INFO - 2021-07-03 09:47:17 --> Upload Class Initialized
INFO - 2021-07-03 09:47:17 --> Email Class Initialized
INFO - 2021-07-03 09:47:17 --> MY_Model class loaded
INFO - 2021-07-03 09:47:17 --> Model "Users_model" initialized
INFO - 2021-07-03 09:47:17 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:47:17 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:47:17 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:47:17 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:47:17 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:47:17 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:47:17 --> Database Driver Class Initialized
INFO - 2021-07-03 09:47:17 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:47:17 --> Controller Class Initialized
ERROR - 2021-07-03 12:47:17 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 12:47:17 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-03 12:47:17 --> Final output sent to browser
DEBUG - 2021-07-03 12:47:17 --> Total execution time: 0.1355
INFO - 2021-07-03 09:47:51 --> Config Class Initialized
INFO - 2021-07-03 09:47:51 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:47:51 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:47:51 --> Utf8 Class Initialized
INFO - 2021-07-03 09:47:51 --> URI Class Initialized
INFO - 2021-07-03 09:47:51 --> Router Class Initialized
INFO - 2021-07-03 09:47:51 --> Output Class Initialized
INFO - 2021-07-03 09:47:51 --> Security Class Initialized
DEBUG - 2021-07-03 09:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:47:51 --> Input Class Initialized
INFO - 2021-07-03 09:47:51 --> Language Class Initialized
INFO - 2021-07-03 09:47:51 --> Loader Class Initialized
INFO - 2021-07-03 09:47:51 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:47:51 --> Helper loaded: url_helper
INFO - 2021-07-03 09:47:51 --> Helper loaded: file_helper
INFO - 2021-07-03 09:47:51 --> Helper loaded: form_helper
INFO - 2021-07-03 09:47:51 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:47:51 --> Helper loaded: security_helper
INFO - 2021-07-03 09:47:51 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:47:51 --> Helper loaded: language_helper
INFO - 2021-07-03 09:47:51 --> Helper loaded: general_helper
INFO - 2021-07-03 09:47:51 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:47:51 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:47:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:47:51 --> Parser Class Initialized
INFO - 2021-07-03 09:47:51 --> Form Validation Class Initialized
INFO - 2021-07-03 09:47:51 --> Upload Class Initialized
INFO - 2021-07-03 09:47:51 --> Email Class Initialized
INFO - 2021-07-03 09:47:51 --> MY_Model class loaded
INFO - 2021-07-03 09:47:51 --> Model "Users_model" initialized
INFO - 2021-07-03 09:47:51 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:47:51 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:47:51 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:47:51 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:47:51 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:47:51 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:47:51 --> Database Driver Class Initialized
INFO - 2021-07-03 09:47:51 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:47:51 --> Controller Class Initialized
ERROR - 2021-07-03 12:47:51 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 12:47:51 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-03 12:47:51 --> Final output sent to browser
DEBUG - 2021-07-03 12:47:51 --> Total execution time: 0.1248
INFO - 2021-07-03 09:55:57 --> Config Class Initialized
INFO - 2021-07-03 09:55:57 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:55:57 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:55:57 --> Utf8 Class Initialized
INFO - 2021-07-03 09:55:57 --> URI Class Initialized
INFO - 2021-07-03 09:55:57 --> Router Class Initialized
INFO - 2021-07-03 09:55:57 --> Output Class Initialized
INFO - 2021-07-03 09:55:57 --> Security Class Initialized
DEBUG - 2021-07-03 09:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:55:57 --> Input Class Initialized
INFO - 2021-07-03 09:55:57 --> Language Class Initialized
INFO - 2021-07-03 09:55:57 --> Loader Class Initialized
INFO - 2021-07-03 09:55:57 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:55:57 --> Helper loaded: url_helper
INFO - 2021-07-03 09:55:57 --> Helper loaded: file_helper
INFO - 2021-07-03 09:55:57 --> Helper loaded: form_helper
INFO - 2021-07-03 09:55:57 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:55:57 --> Helper loaded: security_helper
INFO - 2021-07-03 09:55:57 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:55:57 --> Helper loaded: language_helper
INFO - 2021-07-03 09:55:57 --> Helper loaded: general_helper
INFO - 2021-07-03 09:55:57 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:55:57 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:55:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:55:57 --> Parser Class Initialized
INFO - 2021-07-03 09:55:57 --> Form Validation Class Initialized
INFO - 2021-07-03 09:55:57 --> Upload Class Initialized
INFO - 2021-07-03 09:55:57 --> Email Class Initialized
INFO - 2021-07-03 09:55:57 --> MY_Model class loaded
INFO - 2021-07-03 09:55:57 --> Model "Users_model" initialized
INFO - 2021-07-03 09:55:57 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:55:57 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:55:57 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:55:57 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:55:57 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:55:57 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:55:57 --> Database Driver Class Initialized
INFO - 2021-07-03 09:55:57 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:55:57 --> Controller Class Initialized
ERROR - 2021-07-03 12:55:57 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 12:55:57 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-03 12:55:57 --> Final output sent to browser
DEBUG - 2021-07-03 12:55:57 --> Total execution time: 0.1279
INFO - 2021-07-03 09:56:17 --> Config Class Initialized
INFO - 2021-07-03 09:56:17 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:56:17 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:56:17 --> Utf8 Class Initialized
INFO - 2021-07-03 09:56:17 --> URI Class Initialized
DEBUG - 2021-07-03 09:56:17 --> No URI present. Default controller set.
INFO - 2021-07-03 09:56:17 --> Router Class Initialized
INFO - 2021-07-03 09:56:17 --> Output Class Initialized
INFO - 2021-07-03 09:56:17 --> Security Class Initialized
DEBUG - 2021-07-03 09:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:56:17 --> Input Class Initialized
INFO - 2021-07-03 09:56:17 --> Language Class Initialized
INFO - 2021-07-03 09:56:17 --> Loader Class Initialized
INFO - 2021-07-03 09:56:17 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:56:17 --> Helper loaded: url_helper
INFO - 2021-07-03 09:56:17 --> Helper loaded: file_helper
INFO - 2021-07-03 09:56:17 --> Helper loaded: form_helper
INFO - 2021-07-03 09:56:17 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:56:17 --> Helper loaded: security_helper
INFO - 2021-07-03 09:56:17 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:56:17 --> Helper loaded: language_helper
INFO - 2021-07-03 09:56:17 --> Helper loaded: general_helper
INFO - 2021-07-03 09:56:17 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:56:17 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:56:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:56:17 --> Parser Class Initialized
INFO - 2021-07-03 09:56:17 --> Form Validation Class Initialized
INFO - 2021-07-03 09:56:17 --> Upload Class Initialized
INFO - 2021-07-03 09:56:17 --> Email Class Initialized
INFO - 2021-07-03 09:56:17 --> MY_Model class loaded
INFO - 2021-07-03 09:56:17 --> Model "Users_model" initialized
INFO - 2021-07-03 09:56:17 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:56:17 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:56:17 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:56:17 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:56:17 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:56:17 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:56:17 --> Database Driver Class Initialized
INFO - 2021-07-03 09:56:17 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:56:17 --> Controller Class Initialized
ERROR - 2021-07-03 12:56:17 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 12:56:18 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-03 12:56:18 --> Final output sent to browser
DEBUG - 2021-07-03 12:56:18 --> Total execution time: 0.1288
INFO - 2021-07-03 09:56:21 --> Config Class Initialized
INFO - 2021-07-03 09:56:21 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:56:21 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:56:21 --> Utf8 Class Initialized
INFO - 2021-07-03 09:56:21 --> URI Class Initialized
INFO - 2021-07-03 09:56:21 --> Router Class Initialized
INFO - 2021-07-03 09:56:21 --> Output Class Initialized
INFO - 2021-07-03 09:56:21 --> Security Class Initialized
DEBUG - 2021-07-03 09:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:56:21 --> Input Class Initialized
INFO - 2021-07-03 09:56:21 --> Language Class Initialized
INFO - 2021-07-03 09:56:21 --> Loader Class Initialized
INFO - 2021-07-03 09:56:21 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:56:21 --> Helper loaded: url_helper
INFO - 2021-07-03 09:56:21 --> Helper loaded: file_helper
INFO - 2021-07-03 09:56:21 --> Helper loaded: form_helper
INFO - 2021-07-03 09:56:21 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:56:21 --> Helper loaded: security_helper
INFO - 2021-07-03 09:56:21 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:56:21 --> Helper loaded: language_helper
INFO - 2021-07-03 09:56:21 --> Helper loaded: general_helper
INFO - 2021-07-03 09:56:21 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:56:21 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:56:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:56:21 --> Parser Class Initialized
INFO - 2021-07-03 09:56:21 --> Form Validation Class Initialized
INFO - 2021-07-03 09:56:21 --> Upload Class Initialized
INFO - 2021-07-03 09:56:21 --> Email Class Initialized
INFO - 2021-07-03 09:56:21 --> MY_Model class loaded
INFO - 2021-07-03 09:56:21 --> Model "Users_model" initialized
INFO - 2021-07-03 09:56:21 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:56:21 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:56:21 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:56:21 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:56:21 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:56:21 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:56:21 --> Database Driver Class Initialized
INFO - 2021-07-03 09:56:21 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:56:21 --> Controller Class Initialized
ERROR - 2021-07-03 12:56:21 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 12:56:21 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-03 12:56:21 --> Final output sent to browser
DEBUG - 2021-07-03 12:56:21 --> Total execution time: 0.1697
INFO - 2021-07-03 09:56:23 --> Config Class Initialized
INFO - 2021-07-03 09:56:23 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:56:23 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:56:23 --> Utf8 Class Initialized
INFO - 2021-07-03 09:56:23 --> URI Class Initialized
INFO - 2021-07-03 09:56:23 --> Router Class Initialized
INFO - 2021-07-03 09:56:23 --> Output Class Initialized
INFO - 2021-07-03 09:56:23 --> Security Class Initialized
DEBUG - 2021-07-03 09:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:56:23 --> Input Class Initialized
INFO - 2021-07-03 09:56:23 --> Language Class Initialized
INFO - 2021-07-03 09:56:23 --> Loader Class Initialized
INFO - 2021-07-03 09:56:23 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:56:23 --> Helper loaded: url_helper
INFO - 2021-07-03 09:56:23 --> Helper loaded: file_helper
INFO - 2021-07-03 09:56:23 --> Helper loaded: form_helper
INFO - 2021-07-03 09:56:23 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:56:23 --> Helper loaded: security_helper
INFO - 2021-07-03 09:56:23 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:56:23 --> Helper loaded: language_helper
INFO - 2021-07-03 09:56:23 --> Helper loaded: general_helper
INFO - 2021-07-03 09:56:23 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:56:23 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:56:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:56:23 --> Parser Class Initialized
INFO - 2021-07-03 09:56:23 --> Form Validation Class Initialized
INFO - 2021-07-03 09:56:23 --> Upload Class Initialized
INFO - 2021-07-03 09:56:23 --> Email Class Initialized
INFO - 2021-07-03 09:56:23 --> MY_Model class loaded
INFO - 2021-07-03 09:56:23 --> Model "Users_model" initialized
INFO - 2021-07-03 09:56:23 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:56:23 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:56:23 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:56:23 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:56:23 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:56:23 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:56:23 --> Database Driver Class Initialized
INFO - 2021-07-03 09:56:23 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:56:23 --> Controller Class Initialized
ERROR - 2021-07-03 12:56:23 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 12:56:23 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-03 12:56:23 --> Final output sent to browser
DEBUG - 2021-07-03 12:56:23 --> Total execution time: 0.1194
INFO - 2021-07-03 09:56:32 --> Config Class Initialized
INFO - 2021-07-03 09:56:32 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:56:32 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:56:32 --> Utf8 Class Initialized
INFO - 2021-07-03 09:56:32 --> URI Class Initialized
INFO - 2021-07-03 09:56:32 --> Router Class Initialized
INFO - 2021-07-03 09:56:32 --> Output Class Initialized
INFO - 2021-07-03 09:56:32 --> Security Class Initialized
DEBUG - 2021-07-03 09:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:56:32 --> Input Class Initialized
INFO - 2021-07-03 09:56:32 --> Language Class Initialized
INFO - 2021-07-03 09:56:32 --> Loader Class Initialized
INFO - 2021-07-03 09:56:32 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:56:32 --> Helper loaded: url_helper
INFO - 2021-07-03 09:56:32 --> Helper loaded: file_helper
INFO - 2021-07-03 09:56:32 --> Helper loaded: form_helper
INFO - 2021-07-03 09:56:32 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:56:32 --> Helper loaded: security_helper
INFO - 2021-07-03 09:56:32 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:56:32 --> Helper loaded: language_helper
INFO - 2021-07-03 09:56:32 --> Helper loaded: general_helper
INFO - 2021-07-03 09:56:32 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:56:32 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:56:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:56:32 --> Parser Class Initialized
INFO - 2021-07-03 09:56:32 --> Form Validation Class Initialized
INFO - 2021-07-03 09:56:32 --> Upload Class Initialized
INFO - 2021-07-03 09:56:32 --> Email Class Initialized
INFO - 2021-07-03 09:56:32 --> MY_Model class loaded
INFO - 2021-07-03 09:56:32 --> Model "Users_model" initialized
INFO - 2021-07-03 09:56:32 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:56:32 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:56:32 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:56:32 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:56:32 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:56:32 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:56:32 --> Database Driver Class Initialized
INFO - 2021-07-03 09:56:32 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:56:32 --> Controller Class Initialized
ERROR - 2021-07-03 12:56:32 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 12:56:32 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-03 12:56:32 --> Final output sent to browser
DEBUG - 2021-07-03 12:56:32 --> Total execution time: 0.1214
INFO - 2021-07-03 09:56:37 --> Config Class Initialized
INFO - 2021-07-03 09:56:37 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:56:37 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:56:37 --> Utf8 Class Initialized
INFO - 2021-07-03 09:56:37 --> URI Class Initialized
INFO - 2021-07-03 09:56:37 --> Router Class Initialized
INFO - 2021-07-03 09:56:37 --> Output Class Initialized
INFO - 2021-07-03 09:56:37 --> Security Class Initialized
DEBUG - 2021-07-03 09:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:56:37 --> Input Class Initialized
INFO - 2021-07-03 09:56:37 --> Language Class Initialized
INFO - 2021-07-03 09:56:37 --> Loader Class Initialized
INFO - 2021-07-03 09:56:37 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:56:37 --> Helper loaded: url_helper
INFO - 2021-07-03 09:56:37 --> Helper loaded: file_helper
INFO - 2021-07-03 09:56:37 --> Helper loaded: form_helper
INFO - 2021-07-03 09:56:37 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:56:37 --> Helper loaded: security_helper
INFO - 2021-07-03 09:56:37 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:56:37 --> Helper loaded: language_helper
INFO - 2021-07-03 09:56:37 --> Helper loaded: general_helper
INFO - 2021-07-03 09:56:37 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:56:37 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:56:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:56:38 --> Parser Class Initialized
INFO - 2021-07-03 09:56:38 --> Form Validation Class Initialized
INFO - 2021-07-03 09:56:38 --> Upload Class Initialized
INFO - 2021-07-03 09:56:38 --> Email Class Initialized
INFO - 2021-07-03 09:56:38 --> MY_Model class loaded
INFO - 2021-07-03 09:56:38 --> Model "Users_model" initialized
INFO - 2021-07-03 09:56:38 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:56:38 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:56:38 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:56:38 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:56:38 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:56:38 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:56:38 --> Database Driver Class Initialized
INFO - 2021-07-03 09:56:38 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:56:38 --> Controller Class Initialized
ERROR - 2021-07-03 12:56:38 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 12:56:38 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-03 12:56:38 --> Final output sent to browser
DEBUG - 2021-07-03 12:56:38 --> Total execution time: 0.1525
INFO - 2021-07-03 09:56:40 --> Config Class Initialized
INFO - 2021-07-03 09:56:40 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:56:40 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:56:40 --> Utf8 Class Initialized
INFO - 2021-07-03 09:56:40 --> URI Class Initialized
INFO - 2021-07-03 09:56:40 --> Router Class Initialized
INFO - 2021-07-03 09:56:40 --> Output Class Initialized
INFO - 2021-07-03 09:56:40 --> Security Class Initialized
DEBUG - 2021-07-03 09:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:56:40 --> Input Class Initialized
INFO - 2021-07-03 09:56:40 --> Language Class Initialized
INFO - 2021-07-03 09:56:40 --> Loader Class Initialized
INFO - 2021-07-03 09:56:40 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:56:40 --> Helper loaded: url_helper
INFO - 2021-07-03 09:56:40 --> Helper loaded: file_helper
INFO - 2021-07-03 09:56:40 --> Helper loaded: form_helper
INFO - 2021-07-03 09:56:40 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:56:40 --> Helper loaded: security_helper
INFO - 2021-07-03 09:56:40 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:56:40 --> Helper loaded: language_helper
INFO - 2021-07-03 09:56:40 --> Helper loaded: general_helper
INFO - 2021-07-03 09:56:40 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:56:40 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:56:40 --> Parser Class Initialized
INFO - 2021-07-03 09:56:40 --> Form Validation Class Initialized
INFO - 2021-07-03 09:56:40 --> Upload Class Initialized
INFO - 2021-07-03 09:56:40 --> Email Class Initialized
INFO - 2021-07-03 09:56:40 --> MY_Model class loaded
INFO - 2021-07-03 09:56:40 --> Model "Users_model" initialized
INFO - 2021-07-03 09:56:40 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:56:40 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:56:40 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:56:40 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:56:40 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:56:40 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:56:40 --> Database Driver Class Initialized
INFO - 2021-07-03 09:56:40 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:56:40 --> Controller Class Initialized
ERROR - 2021-07-03 12:56:40 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 12:56:40 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-03 12:56:40 --> Final output sent to browser
DEBUG - 2021-07-03 12:56:40 --> Total execution time: 0.0899
INFO - 2021-07-03 09:57:35 --> Config Class Initialized
INFO - 2021-07-03 09:57:35 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:57:35 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:57:35 --> Utf8 Class Initialized
INFO - 2021-07-03 09:57:35 --> URI Class Initialized
INFO - 2021-07-03 09:57:35 --> Router Class Initialized
INFO - 2021-07-03 09:57:35 --> Output Class Initialized
INFO - 2021-07-03 09:57:35 --> Security Class Initialized
DEBUG - 2021-07-03 09:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:57:35 --> Input Class Initialized
INFO - 2021-07-03 09:57:35 --> Language Class Initialized
INFO - 2021-07-03 09:57:35 --> Loader Class Initialized
INFO - 2021-07-03 09:57:35 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:57:35 --> Helper loaded: url_helper
INFO - 2021-07-03 09:57:35 --> Helper loaded: file_helper
INFO - 2021-07-03 09:57:35 --> Helper loaded: form_helper
INFO - 2021-07-03 09:57:35 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:57:35 --> Helper loaded: security_helper
INFO - 2021-07-03 09:57:35 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:57:35 --> Helper loaded: language_helper
INFO - 2021-07-03 09:57:35 --> Helper loaded: general_helper
INFO - 2021-07-03 09:57:35 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:57:35 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:57:35 --> Parser Class Initialized
INFO - 2021-07-03 09:57:35 --> Form Validation Class Initialized
INFO - 2021-07-03 09:57:35 --> Upload Class Initialized
INFO - 2021-07-03 09:57:35 --> Email Class Initialized
INFO - 2021-07-03 09:57:35 --> MY_Model class loaded
INFO - 2021-07-03 09:57:35 --> Model "Users_model" initialized
INFO - 2021-07-03 09:57:35 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:57:35 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:57:35 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:57:35 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:57:35 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:57:35 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:57:35 --> Database Driver Class Initialized
INFO - 2021-07-03 09:57:35 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:57:35 --> Controller Class Initialized
ERROR - 2021-07-03 12:57:35 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 12:57:35 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-03 12:57:35 --> Final output sent to browser
DEBUG - 2021-07-03 12:57:35 --> Total execution time: 0.1287
INFO - 2021-07-03 09:57:36 --> Config Class Initialized
INFO - 2021-07-03 09:57:36 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:57:36 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:57:36 --> Utf8 Class Initialized
INFO - 2021-07-03 09:57:36 --> URI Class Initialized
INFO - 2021-07-03 09:57:36 --> Router Class Initialized
INFO - 2021-07-03 09:57:36 --> Output Class Initialized
INFO - 2021-07-03 09:57:36 --> Security Class Initialized
DEBUG - 2021-07-03 09:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:57:36 --> Input Class Initialized
INFO - 2021-07-03 09:57:36 --> Language Class Initialized
INFO - 2021-07-03 09:57:36 --> Loader Class Initialized
INFO - 2021-07-03 09:57:36 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:57:36 --> Helper loaded: url_helper
INFO - 2021-07-03 09:57:36 --> Helper loaded: file_helper
INFO - 2021-07-03 09:57:36 --> Helper loaded: form_helper
INFO - 2021-07-03 09:57:36 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:57:36 --> Helper loaded: security_helper
INFO - 2021-07-03 09:57:36 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:57:36 --> Helper loaded: language_helper
INFO - 2021-07-03 09:57:36 --> Helper loaded: general_helper
INFO - 2021-07-03 09:57:36 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:57:36 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:57:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:57:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:57:36 --> Parser Class Initialized
INFO - 2021-07-03 09:57:36 --> Form Validation Class Initialized
INFO - 2021-07-03 09:57:36 --> Upload Class Initialized
INFO - 2021-07-03 09:57:36 --> Email Class Initialized
INFO - 2021-07-03 09:57:36 --> MY_Model class loaded
INFO - 2021-07-03 09:57:36 --> Model "Users_model" initialized
INFO - 2021-07-03 09:57:36 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:57:36 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:57:36 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:57:36 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:57:36 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:57:36 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:57:36 --> Database Driver Class Initialized
INFO - 2021-07-03 09:57:36 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:57:36 --> Controller Class Initialized
ERROR - 2021-07-03 12:57:36 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 12:57:36 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-03 12:57:36 --> Final output sent to browser
DEBUG - 2021-07-03 12:57:36 --> Total execution time: 0.0594
INFO - 2021-07-03 09:58:35 --> Config Class Initialized
INFO - 2021-07-03 09:58:35 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:58:35 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:58:35 --> Utf8 Class Initialized
INFO - 2021-07-03 09:58:35 --> URI Class Initialized
INFO - 2021-07-03 09:58:35 --> Router Class Initialized
INFO - 2021-07-03 09:58:35 --> Output Class Initialized
INFO - 2021-07-03 09:58:35 --> Security Class Initialized
DEBUG - 2021-07-03 09:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:58:35 --> Input Class Initialized
INFO - 2021-07-03 09:58:35 --> Language Class Initialized
INFO - 2021-07-03 09:58:35 --> Loader Class Initialized
INFO - 2021-07-03 09:58:35 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:58:35 --> Helper loaded: url_helper
INFO - 2021-07-03 09:58:35 --> Helper loaded: file_helper
INFO - 2021-07-03 09:58:35 --> Helper loaded: form_helper
INFO - 2021-07-03 09:58:35 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:58:35 --> Helper loaded: security_helper
INFO - 2021-07-03 09:58:35 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:58:35 --> Helper loaded: language_helper
INFO - 2021-07-03 09:58:35 --> Helper loaded: general_helper
INFO - 2021-07-03 09:58:35 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:58:35 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:58:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:58:35 --> Parser Class Initialized
INFO - 2021-07-03 09:58:35 --> Form Validation Class Initialized
INFO - 2021-07-03 09:58:35 --> Upload Class Initialized
INFO - 2021-07-03 09:58:35 --> Email Class Initialized
INFO - 2021-07-03 09:58:35 --> MY_Model class loaded
INFO - 2021-07-03 09:58:35 --> Model "Users_model" initialized
INFO - 2021-07-03 09:58:35 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:58:35 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:58:35 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:58:35 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:58:35 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:58:35 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:58:35 --> Database Driver Class Initialized
INFO - 2021-07-03 09:58:35 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:58:35 --> Controller Class Initialized
ERROR - 2021-07-03 12:58:35 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 12:58:35 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-03 12:58:35 --> Final output sent to browser
DEBUG - 2021-07-03 12:58:35 --> Total execution time: 0.1383
INFO - 2021-07-03 09:58:37 --> Config Class Initialized
INFO - 2021-07-03 09:58:37 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:58:37 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:58:37 --> Utf8 Class Initialized
INFO - 2021-07-03 09:58:37 --> URI Class Initialized
INFO - 2021-07-03 09:58:37 --> Router Class Initialized
INFO - 2021-07-03 09:58:37 --> Output Class Initialized
INFO - 2021-07-03 09:58:37 --> Security Class Initialized
DEBUG - 2021-07-03 09:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:58:37 --> Input Class Initialized
INFO - 2021-07-03 09:58:37 --> Language Class Initialized
INFO - 2021-07-03 09:58:37 --> Loader Class Initialized
INFO - 2021-07-03 09:58:37 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:58:37 --> Helper loaded: url_helper
INFO - 2021-07-03 09:58:37 --> Helper loaded: file_helper
INFO - 2021-07-03 09:58:37 --> Helper loaded: form_helper
INFO - 2021-07-03 09:58:37 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:58:37 --> Helper loaded: security_helper
INFO - 2021-07-03 09:58:37 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:58:37 --> Helper loaded: language_helper
INFO - 2021-07-03 09:58:37 --> Helper loaded: general_helper
INFO - 2021-07-03 09:58:37 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:58:37 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:58:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:58:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:58:37 --> Parser Class Initialized
INFO - 2021-07-03 09:58:37 --> Form Validation Class Initialized
INFO - 2021-07-03 09:58:37 --> Upload Class Initialized
INFO - 2021-07-03 09:58:37 --> Email Class Initialized
INFO - 2021-07-03 09:58:37 --> MY_Model class loaded
INFO - 2021-07-03 09:58:37 --> Model "Users_model" initialized
INFO - 2021-07-03 09:58:37 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:58:37 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:58:37 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:58:37 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:58:37 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:58:37 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:58:37 --> Database Driver Class Initialized
INFO - 2021-07-03 09:58:37 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:58:37 --> Controller Class Initialized
ERROR - 2021-07-03 12:58:37 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 12:58:37 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-03 12:58:37 --> Final output sent to browser
DEBUG - 2021-07-03 12:58:37 --> Total execution time: 0.0716
INFO - 2021-07-03 09:59:37 --> Config Class Initialized
INFO - 2021-07-03 09:59:37 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:59:37 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:59:37 --> Utf8 Class Initialized
INFO - 2021-07-03 09:59:37 --> URI Class Initialized
INFO - 2021-07-03 09:59:37 --> Router Class Initialized
INFO - 2021-07-03 09:59:37 --> Output Class Initialized
INFO - 2021-07-03 09:59:37 --> Security Class Initialized
DEBUG - 2021-07-03 09:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:59:37 --> Input Class Initialized
INFO - 2021-07-03 09:59:37 --> Language Class Initialized
INFO - 2021-07-03 09:59:37 --> Loader Class Initialized
INFO - 2021-07-03 09:59:37 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:59:37 --> Helper loaded: url_helper
INFO - 2021-07-03 09:59:37 --> Helper loaded: file_helper
INFO - 2021-07-03 09:59:37 --> Helper loaded: form_helper
INFO - 2021-07-03 09:59:37 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:59:37 --> Helper loaded: security_helper
INFO - 2021-07-03 09:59:37 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:59:37 --> Helper loaded: language_helper
INFO - 2021-07-03 09:59:37 --> Helper loaded: general_helper
INFO - 2021-07-03 09:59:37 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:59:37 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:59:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:59:37 --> Parser Class Initialized
INFO - 2021-07-03 09:59:37 --> Form Validation Class Initialized
INFO - 2021-07-03 09:59:37 --> Upload Class Initialized
INFO - 2021-07-03 09:59:37 --> Email Class Initialized
INFO - 2021-07-03 09:59:37 --> MY_Model class loaded
INFO - 2021-07-03 09:59:37 --> Model "Users_model" initialized
INFO - 2021-07-03 09:59:37 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:59:37 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:59:37 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:59:37 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:59:37 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:59:37 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:59:37 --> Database Driver Class Initialized
INFO - 2021-07-03 09:59:37 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:59:37 --> Controller Class Initialized
ERROR - 2021-07-03 12:59:37 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 12:59:37 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-03 12:59:37 --> Final output sent to browser
DEBUG - 2021-07-03 12:59:37 --> Total execution time: 0.1226
INFO - 2021-07-03 09:59:38 --> Config Class Initialized
INFO - 2021-07-03 09:59:38 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:59:38 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:59:38 --> Utf8 Class Initialized
INFO - 2021-07-03 09:59:38 --> URI Class Initialized
INFO - 2021-07-03 09:59:38 --> Router Class Initialized
INFO - 2021-07-03 09:59:38 --> Output Class Initialized
INFO - 2021-07-03 09:59:38 --> Security Class Initialized
DEBUG - 2021-07-03 09:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:59:38 --> Input Class Initialized
INFO - 2021-07-03 09:59:38 --> Language Class Initialized
INFO - 2021-07-03 09:59:38 --> Loader Class Initialized
INFO - 2021-07-03 09:59:38 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:59:38 --> Helper loaded: url_helper
INFO - 2021-07-03 09:59:38 --> Helper loaded: file_helper
INFO - 2021-07-03 09:59:38 --> Helper loaded: form_helper
INFO - 2021-07-03 09:59:38 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:59:38 --> Helper loaded: security_helper
INFO - 2021-07-03 09:59:38 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:59:38 --> Helper loaded: language_helper
INFO - 2021-07-03 09:59:38 --> Helper loaded: general_helper
INFO - 2021-07-03 09:59:38 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:59:38 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:59:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:59:38 --> Parser Class Initialized
INFO - 2021-07-03 09:59:38 --> Form Validation Class Initialized
INFO - 2021-07-03 09:59:38 --> Upload Class Initialized
INFO - 2021-07-03 09:59:38 --> Email Class Initialized
INFO - 2021-07-03 09:59:38 --> MY_Model class loaded
INFO - 2021-07-03 09:59:38 --> Model "Users_model" initialized
INFO - 2021-07-03 09:59:38 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:59:38 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:59:38 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:59:38 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:59:38 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:59:38 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:59:38 --> Database Driver Class Initialized
INFO - 2021-07-03 09:59:38 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:59:38 --> Controller Class Initialized
ERROR - 2021-07-03 12:59:38 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 12:59:38 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-03 12:59:38 --> Final output sent to browser
DEBUG - 2021-07-03 12:59:38 --> Total execution time: 0.0616
INFO - 2021-07-03 09:59:40 --> Config Class Initialized
INFO - 2021-07-03 09:59:40 --> Hooks Class Initialized
DEBUG - 2021-07-03 09:59:40 --> UTF-8 Support Enabled
INFO - 2021-07-03 09:59:40 --> Utf8 Class Initialized
INFO - 2021-07-03 09:59:40 --> URI Class Initialized
INFO - 2021-07-03 09:59:40 --> Router Class Initialized
INFO - 2021-07-03 09:59:40 --> Output Class Initialized
INFO - 2021-07-03 09:59:40 --> Security Class Initialized
DEBUG - 2021-07-03 09:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 09:59:40 --> Input Class Initialized
INFO - 2021-07-03 09:59:40 --> Language Class Initialized
INFO - 2021-07-03 09:59:40 --> Loader Class Initialized
INFO - 2021-07-03 09:59:40 --> Helper loaded: basic_helper
INFO - 2021-07-03 09:59:40 --> Helper loaded: url_helper
INFO - 2021-07-03 09:59:40 --> Helper loaded: file_helper
INFO - 2021-07-03 09:59:40 --> Helper loaded: form_helper
INFO - 2021-07-03 09:59:40 --> Helper loaded: cookie_helper
INFO - 2021-07-03 09:59:40 --> Helper loaded: security_helper
INFO - 2021-07-03 09:59:40 --> Helper loaded: directory_helper
INFO - 2021-07-03 09:59:40 --> Helper loaded: language_helper
INFO - 2021-07-03 09:59:40 --> Helper loaded: general_helper
INFO - 2021-07-03 09:59:40 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 09:59:40 --> Database Driver Class Initialized
DEBUG - 2021-07-03 09:59:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 09:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 09:59:40 --> Parser Class Initialized
INFO - 2021-07-03 09:59:40 --> Form Validation Class Initialized
INFO - 2021-07-03 09:59:40 --> Upload Class Initialized
INFO - 2021-07-03 09:59:40 --> Email Class Initialized
INFO - 2021-07-03 09:59:40 --> MY_Model class loaded
INFO - 2021-07-03 09:59:40 --> Model "Users_model" initialized
INFO - 2021-07-03 09:59:40 --> Model "Settings_model" initialized
INFO - 2021-07-03 09:59:40 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 09:59:40 --> Model "Permissions_model" initialized
INFO - 2021-07-03 09:59:40 --> Model "Roles_model" initialized
INFO - 2021-07-03 09:59:40 --> Model "Activity_model" initialized
INFO - 2021-07-03 09:59:40 --> Model "Templates_model" initialized
INFO - 2021-07-03 09:59:40 --> Database Driver Class Initialized
INFO - 2021-07-03 09:59:40 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 09:59:40 --> Controller Class Initialized
ERROR - 2021-07-03 12:59:40 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 12:59:40 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-03 12:59:40 --> Final output sent to browser
DEBUG - 2021-07-03 12:59:40 --> Total execution time: 0.1848
INFO - 2021-07-03 10:00:03 --> Config Class Initialized
INFO - 2021-07-03 10:00:03 --> Hooks Class Initialized
DEBUG - 2021-07-03 10:00:03 --> UTF-8 Support Enabled
INFO - 2021-07-03 10:00:03 --> Utf8 Class Initialized
INFO - 2021-07-03 10:00:03 --> URI Class Initialized
INFO - 2021-07-03 10:00:03 --> Router Class Initialized
INFO - 2021-07-03 10:00:03 --> Output Class Initialized
INFO - 2021-07-03 10:00:03 --> Security Class Initialized
DEBUG - 2021-07-03 10:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 10:00:03 --> Input Class Initialized
INFO - 2021-07-03 10:00:03 --> Language Class Initialized
INFO - 2021-07-03 10:00:03 --> Loader Class Initialized
INFO - 2021-07-03 10:00:03 --> Helper loaded: basic_helper
INFO - 2021-07-03 10:00:03 --> Helper loaded: url_helper
INFO - 2021-07-03 10:00:03 --> Helper loaded: file_helper
INFO - 2021-07-03 10:00:03 --> Helper loaded: form_helper
INFO - 2021-07-03 10:00:03 --> Helper loaded: cookie_helper
INFO - 2021-07-03 10:00:03 --> Helper loaded: security_helper
INFO - 2021-07-03 10:00:03 --> Helper loaded: directory_helper
INFO - 2021-07-03 10:00:03 --> Helper loaded: language_helper
INFO - 2021-07-03 10:00:03 --> Helper loaded: general_helper
INFO - 2021-07-03 10:00:03 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 10:00:03 --> Database Driver Class Initialized
DEBUG - 2021-07-03 10:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 10:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 10:00:03 --> Parser Class Initialized
INFO - 2021-07-03 10:00:03 --> Form Validation Class Initialized
INFO - 2021-07-03 10:00:03 --> Upload Class Initialized
INFO - 2021-07-03 10:00:03 --> Email Class Initialized
INFO - 2021-07-03 10:00:03 --> MY_Model class loaded
INFO - 2021-07-03 10:00:03 --> Model "Users_model" initialized
INFO - 2021-07-03 10:00:03 --> Model "Settings_model" initialized
INFO - 2021-07-03 10:00:03 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 10:00:03 --> Model "Permissions_model" initialized
INFO - 2021-07-03 10:00:03 --> Model "Roles_model" initialized
INFO - 2021-07-03 10:00:03 --> Model "Activity_model" initialized
INFO - 2021-07-03 10:00:03 --> Model "Templates_model" initialized
INFO - 2021-07-03 10:00:03 --> Database Driver Class Initialized
INFO - 2021-07-03 10:00:03 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 10:00:03 --> Controller Class Initialized
ERROR - 2021-07-03 13:00:03 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 13:00:03 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-03 13:00:03 --> Final output sent to browser
DEBUG - 2021-07-03 13:00:03 --> Total execution time: 0.1371
INFO - 2021-07-03 10:25:08 --> Config Class Initialized
INFO - 2021-07-03 10:25:08 --> Hooks Class Initialized
DEBUG - 2021-07-03 10:25:08 --> UTF-8 Support Enabled
INFO - 2021-07-03 10:25:08 --> Utf8 Class Initialized
INFO - 2021-07-03 10:25:08 --> URI Class Initialized
DEBUG - 2021-07-03 10:25:08 --> No URI present. Default controller set.
INFO - 2021-07-03 10:25:08 --> Router Class Initialized
INFO - 2021-07-03 10:25:08 --> Output Class Initialized
INFO - 2021-07-03 10:25:08 --> Security Class Initialized
DEBUG - 2021-07-03 10:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 10:25:08 --> Input Class Initialized
INFO - 2021-07-03 10:25:08 --> Language Class Initialized
INFO - 2021-07-03 10:25:08 --> Loader Class Initialized
INFO - 2021-07-03 10:25:08 --> Helper loaded: basic_helper
INFO - 2021-07-03 10:25:08 --> Helper loaded: url_helper
INFO - 2021-07-03 10:25:08 --> Helper loaded: file_helper
INFO - 2021-07-03 10:25:08 --> Helper loaded: form_helper
INFO - 2021-07-03 10:25:08 --> Helper loaded: cookie_helper
INFO - 2021-07-03 10:25:08 --> Helper loaded: security_helper
INFO - 2021-07-03 10:25:08 --> Helper loaded: directory_helper
INFO - 2021-07-03 10:25:08 --> Helper loaded: language_helper
INFO - 2021-07-03 10:25:08 --> Helper loaded: general_helper
INFO - 2021-07-03 10:25:08 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 10:25:08 --> Database Driver Class Initialized
DEBUG - 2021-07-03 10:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 10:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 10:25:08 --> Parser Class Initialized
INFO - 2021-07-03 10:25:08 --> Form Validation Class Initialized
INFO - 2021-07-03 10:25:08 --> Upload Class Initialized
INFO - 2021-07-03 10:25:08 --> Email Class Initialized
INFO - 2021-07-03 10:25:08 --> MY_Model class loaded
INFO - 2021-07-03 10:25:08 --> Model "Users_model" initialized
INFO - 2021-07-03 10:25:08 --> Model "Settings_model" initialized
INFO - 2021-07-03 10:25:08 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 10:25:08 --> Model "Permissions_model" initialized
INFO - 2021-07-03 10:25:08 --> Model "Roles_model" initialized
INFO - 2021-07-03 10:25:08 --> Model "Activity_model" initialized
INFO - 2021-07-03 10:25:08 --> Model "Templates_model" initialized
INFO - 2021-07-03 10:25:08 --> Database Driver Class Initialized
INFO - 2021-07-03 10:25:08 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 10:25:08 --> Controller Class Initialized
INFO - 2021-07-03 10:25:08 --> Config Class Initialized
INFO - 2021-07-03 10:25:08 --> Hooks Class Initialized
DEBUG - 2021-07-03 10:25:08 --> UTF-8 Support Enabled
INFO - 2021-07-03 10:25:08 --> Utf8 Class Initialized
INFO - 2021-07-03 10:25:08 --> URI Class Initialized
INFO - 2021-07-03 10:25:08 --> Router Class Initialized
INFO - 2021-07-03 10:25:08 --> Output Class Initialized
INFO - 2021-07-03 10:25:08 --> Security Class Initialized
DEBUG - 2021-07-03 10:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 10:25:08 --> Input Class Initialized
INFO - 2021-07-03 10:25:08 --> Language Class Initialized
INFO - 2021-07-03 10:25:08 --> Loader Class Initialized
INFO - 2021-07-03 10:25:08 --> Helper loaded: basic_helper
INFO - 2021-07-03 10:25:08 --> Helper loaded: url_helper
INFO - 2021-07-03 10:25:08 --> Helper loaded: file_helper
INFO - 2021-07-03 10:25:08 --> Helper loaded: form_helper
INFO - 2021-07-03 10:25:08 --> Helper loaded: cookie_helper
INFO - 2021-07-03 10:25:08 --> Helper loaded: security_helper
INFO - 2021-07-03 10:25:08 --> Helper loaded: directory_helper
INFO - 2021-07-03 10:25:08 --> Helper loaded: language_helper
INFO - 2021-07-03 10:25:08 --> Helper loaded: general_helper
INFO - 2021-07-03 10:25:08 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 10:25:08 --> Database Driver Class Initialized
DEBUG - 2021-07-03 10:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 10:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 10:25:08 --> Config Class Initialized
INFO - 2021-07-03 10:25:08 --> Hooks Class Initialized
INFO - 2021-07-03 10:25:08 --> Parser Class Initialized
DEBUG - 2021-07-03 10:25:08 --> UTF-8 Support Enabled
INFO - 2021-07-03 10:25:08 --> Form Validation Class Initialized
INFO - 2021-07-03 10:25:08 --> Utf8 Class Initialized
INFO - 2021-07-03 10:25:08 --> URI Class Initialized
INFO - 2021-07-03 10:25:08 --> Upload Class Initialized
INFO - 2021-07-03 10:25:08 --> Router Class Initialized
INFO - 2021-07-03 10:25:08 --> Email Class Initialized
INFO - 2021-07-03 10:25:08 --> Output Class Initialized
INFO - 2021-07-03 10:25:08 --> MY_Model class loaded
INFO - 2021-07-03 10:25:08 --> Security Class Initialized
INFO - 2021-07-03 10:25:08 --> Model "Users_model" initialized
INFO - 2021-07-03 10:25:08 --> Model "Settings_model" initialized
DEBUG - 2021-07-03 10:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 10:25:08 --> Input Class Initialized
INFO - 2021-07-03 10:25:08 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 10:25:08 --> Model "Permissions_model" initialized
INFO - 2021-07-03 10:25:08 --> Language Class Initialized
INFO - 2021-07-03 10:25:08 --> Model "Roles_model" initialized
INFO - 2021-07-03 10:25:08 --> Model "Activity_model" initialized
ERROR - 2021-07-03 10:25:08 --> 404 Page Not Found: Faviconico/index
INFO - 2021-07-03 10:25:08 --> Model "Templates_model" initialized
INFO - 2021-07-03 10:25:08 --> Database Driver Class Initialized
INFO - 2021-07-03 10:25:08 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 10:25:08 --> Controller Class Initialized
INFO - 2021-07-03 13:25:08 --> File loaded: C:\wamp64\www\crm\application\views\account/login.php
INFO - 2021-07-03 13:25:08 --> Final output sent to browser
DEBUG - 2021-07-03 13:25:08 --> Total execution time: 0.0478
INFO - 2021-07-03 10:25:08 --> Config Class Initialized
INFO - 2021-07-03 10:25:08 --> Hooks Class Initialized
INFO - 2021-07-03 10:25:08 --> Config Class Initialized
INFO - 2021-07-03 10:25:08 --> Hooks Class Initialized
DEBUG - 2021-07-03 10:25:08 --> UTF-8 Support Enabled
INFO - 2021-07-03 10:25:08 --> Utf8 Class Initialized
DEBUG - 2021-07-03 10:25:08 --> UTF-8 Support Enabled
INFO - 2021-07-03 10:25:08 --> Utf8 Class Initialized
INFO - 2021-07-03 10:25:08 --> URI Class Initialized
INFO - 2021-07-03 10:25:08 --> URI Class Initialized
INFO - 2021-07-03 10:25:08 --> Router Class Initialized
INFO - 2021-07-03 10:25:08 --> Router Class Initialized
INFO - 2021-07-03 10:25:08 --> Output Class Initialized
INFO - 2021-07-03 10:25:08 --> Output Class Initialized
INFO - 2021-07-03 10:25:08 --> Security Class Initialized
INFO - 2021-07-03 10:25:08 --> Security Class Initialized
DEBUG - 2021-07-03 10:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 10:25:08 --> Input Class Initialized
DEBUG - 2021-07-03 10:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 10:25:08 --> Input Class Initialized
INFO - 2021-07-03 10:25:08 --> Language Class Initialized
INFO - 2021-07-03 10:25:08 --> Language Class Initialized
ERROR - 2021-07-03 10:25:08 --> 404 Page Not Found: Assets/jquery
ERROR - 2021-07-03 10:25:08 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-03 10:25:09 --> Config Class Initialized
INFO - 2021-07-03 10:25:09 --> Hooks Class Initialized
DEBUG - 2021-07-03 10:25:09 --> UTF-8 Support Enabled
INFO - 2021-07-03 10:25:09 --> Utf8 Class Initialized
INFO - 2021-07-03 10:25:09 --> URI Class Initialized
INFO - 2021-07-03 10:25:09 --> Router Class Initialized
INFO - 2021-07-03 10:25:09 --> Output Class Initialized
INFO - 2021-07-03 10:25:09 --> Security Class Initialized
DEBUG - 2021-07-03 10:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 10:25:09 --> Input Class Initialized
INFO - 2021-07-03 10:25:09 --> Language Class Initialized
ERROR - 2021-07-03 10:25:09 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-03 10:25:46 --> Config Class Initialized
INFO - 2021-07-03 10:25:46 --> Hooks Class Initialized
DEBUG - 2021-07-03 10:25:46 --> UTF-8 Support Enabled
INFO - 2021-07-03 10:25:46 --> Utf8 Class Initialized
INFO - 2021-07-03 10:25:46 --> URI Class Initialized
INFO - 2021-07-03 10:25:46 --> Router Class Initialized
INFO - 2021-07-03 10:25:46 --> Output Class Initialized
INFO - 2021-07-03 10:25:46 --> Security Class Initialized
DEBUG - 2021-07-03 10:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 10:25:46 --> Input Class Initialized
INFO - 2021-07-03 10:25:46 --> Language Class Initialized
INFO - 2021-07-03 10:25:46 --> Loader Class Initialized
INFO - 2021-07-03 10:25:46 --> Helper loaded: basic_helper
INFO - 2021-07-03 10:25:46 --> Helper loaded: url_helper
INFO - 2021-07-03 10:25:46 --> Helper loaded: file_helper
INFO - 2021-07-03 10:25:46 --> Helper loaded: form_helper
INFO - 2021-07-03 10:25:46 --> Helper loaded: cookie_helper
INFO - 2021-07-03 10:25:46 --> Helper loaded: security_helper
INFO - 2021-07-03 10:25:46 --> Helper loaded: directory_helper
INFO - 2021-07-03 10:25:46 --> Helper loaded: language_helper
INFO - 2021-07-03 10:25:46 --> Helper loaded: general_helper
INFO - 2021-07-03 10:25:46 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 10:25:46 --> Database Driver Class Initialized
DEBUG - 2021-07-03 10:25:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 10:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 10:25:46 --> Parser Class Initialized
INFO - 2021-07-03 10:25:46 --> Form Validation Class Initialized
INFO - 2021-07-03 10:25:46 --> Upload Class Initialized
INFO - 2021-07-03 10:25:46 --> Email Class Initialized
INFO - 2021-07-03 10:25:46 --> MY_Model class loaded
INFO - 2021-07-03 10:25:46 --> Model "Users_model" initialized
INFO - 2021-07-03 10:25:46 --> Model "Settings_model" initialized
INFO - 2021-07-03 10:25:46 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 10:25:46 --> Model "Permissions_model" initialized
INFO - 2021-07-03 10:25:46 --> Model "Roles_model" initialized
INFO - 2021-07-03 10:25:46 --> Model "Activity_model" initialized
INFO - 2021-07-03 10:25:46 --> Model "Templates_model" initialized
INFO - 2021-07-03 10:25:46 --> Database Driver Class Initialized
INFO - 2021-07-03 10:25:46 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 10:25:46 --> Controller Class Initialized
DEBUG - 2021-07-03 13:25:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-03 13:25:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2021-07-03 10:25:47 --> Config Class Initialized
INFO - 2021-07-03 10:25:47 --> Hooks Class Initialized
DEBUG - 2021-07-03 10:25:47 --> UTF-8 Support Enabled
INFO - 2021-07-03 10:25:47 --> Utf8 Class Initialized
INFO - 2021-07-03 10:25:47 --> URI Class Initialized
DEBUG - 2021-07-03 10:25:47 --> No URI present. Default controller set.
INFO - 2021-07-03 10:25:47 --> Router Class Initialized
INFO - 2021-07-03 10:25:47 --> Output Class Initialized
INFO - 2021-07-03 10:25:47 --> Security Class Initialized
DEBUG - 2021-07-03 10:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 10:25:47 --> Input Class Initialized
INFO - 2021-07-03 10:25:47 --> Language Class Initialized
INFO - 2021-07-03 10:25:47 --> Loader Class Initialized
INFO - 2021-07-03 10:25:47 --> Helper loaded: basic_helper
INFO - 2021-07-03 10:25:47 --> Helper loaded: url_helper
INFO - 2021-07-03 10:25:47 --> Helper loaded: file_helper
INFO - 2021-07-03 10:25:47 --> Helper loaded: form_helper
INFO - 2021-07-03 10:25:47 --> Helper loaded: cookie_helper
INFO - 2021-07-03 10:25:47 --> Helper loaded: security_helper
INFO - 2021-07-03 10:25:47 --> Helper loaded: directory_helper
INFO - 2021-07-03 10:25:47 --> Helper loaded: language_helper
INFO - 2021-07-03 10:25:47 --> Helper loaded: general_helper
INFO - 2021-07-03 10:25:47 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 10:25:47 --> Database Driver Class Initialized
DEBUG - 2021-07-03 10:25:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 10:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 10:25:47 --> Parser Class Initialized
INFO - 2021-07-03 10:25:47 --> Form Validation Class Initialized
INFO - 2021-07-03 10:25:47 --> Upload Class Initialized
INFO - 2021-07-03 10:25:47 --> Email Class Initialized
INFO - 2021-07-03 10:25:47 --> MY_Model class loaded
INFO - 2021-07-03 10:25:47 --> Model "Users_model" initialized
INFO - 2021-07-03 10:25:47 --> Model "Settings_model" initialized
INFO - 2021-07-03 10:25:47 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 10:25:47 --> Model "Permissions_model" initialized
INFO - 2021-07-03 10:25:47 --> Model "Roles_model" initialized
INFO - 2021-07-03 10:25:47 --> Model "Activity_model" initialized
INFO - 2021-07-03 10:25:47 --> Model "Templates_model" initialized
INFO - 2021-07-03 10:25:47 --> Database Driver Class Initialized
INFO - 2021-07-03 10:25:47 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 10:25:47 --> Controller Class Initialized
ERROR - 2021-07-03 13:25:47 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 13:25:47 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-03 13:25:47 --> Final output sent to browser
DEBUG - 2021-07-03 13:25:47 --> Total execution time: 0.0577
INFO - 2021-07-03 10:26:09 --> Config Class Initialized
INFO - 2021-07-03 10:26:09 --> Hooks Class Initialized
DEBUG - 2021-07-03 10:26:09 --> UTF-8 Support Enabled
INFO - 2021-07-03 10:26:09 --> Utf8 Class Initialized
INFO - 2021-07-03 10:26:09 --> URI Class Initialized
DEBUG - 2021-07-03 10:26:09 --> No URI present. Default controller set.
INFO - 2021-07-03 10:26:09 --> Router Class Initialized
INFO - 2021-07-03 10:26:09 --> Output Class Initialized
INFO - 2021-07-03 10:26:09 --> Security Class Initialized
DEBUG - 2021-07-03 10:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 10:26:09 --> Input Class Initialized
INFO - 2021-07-03 10:26:09 --> Language Class Initialized
INFO - 2021-07-03 10:26:09 --> Loader Class Initialized
INFO - 2021-07-03 10:26:09 --> Helper loaded: basic_helper
INFO - 2021-07-03 10:26:09 --> Helper loaded: url_helper
INFO - 2021-07-03 10:26:09 --> Helper loaded: file_helper
INFO - 2021-07-03 10:26:09 --> Helper loaded: form_helper
INFO - 2021-07-03 10:26:09 --> Helper loaded: cookie_helper
INFO - 2021-07-03 10:26:09 --> Helper loaded: security_helper
INFO - 2021-07-03 10:26:09 --> Helper loaded: directory_helper
INFO - 2021-07-03 10:26:09 --> Helper loaded: language_helper
INFO - 2021-07-03 10:26:09 --> Helper loaded: general_helper
INFO - 2021-07-03 10:26:09 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 10:26:09 --> Database Driver Class Initialized
DEBUG - 2021-07-03 10:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 10:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 10:26:09 --> Parser Class Initialized
INFO - 2021-07-03 10:26:09 --> Form Validation Class Initialized
INFO - 2021-07-03 10:26:09 --> Upload Class Initialized
INFO - 2021-07-03 10:26:09 --> Email Class Initialized
INFO - 2021-07-03 10:26:09 --> MY_Model class loaded
INFO - 2021-07-03 10:26:09 --> Model "Users_model" initialized
INFO - 2021-07-03 10:26:09 --> Model "Settings_model" initialized
INFO - 2021-07-03 10:26:09 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 10:26:09 --> Model "Permissions_model" initialized
INFO - 2021-07-03 10:26:09 --> Model "Roles_model" initialized
INFO - 2021-07-03 10:26:09 --> Model "Activity_model" initialized
INFO - 2021-07-03 10:26:09 --> Model "Templates_model" initialized
INFO - 2021-07-03 10:26:09 --> Database Driver Class Initialized
INFO - 2021-07-03 10:26:09 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 10:26:09 --> Controller Class Initialized
INFO - 2021-07-03 10:26:09 --> Config Class Initialized
INFO - 2021-07-03 10:26:09 --> Hooks Class Initialized
DEBUG - 2021-07-03 10:26:09 --> UTF-8 Support Enabled
INFO - 2021-07-03 10:26:09 --> Utf8 Class Initialized
INFO - 2021-07-03 10:26:09 --> URI Class Initialized
INFO - 2021-07-03 10:26:09 --> Router Class Initialized
INFO - 2021-07-03 10:26:09 --> Output Class Initialized
INFO - 2021-07-03 10:26:09 --> Security Class Initialized
DEBUG - 2021-07-03 10:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 10:26:09 --> Input Class Initialized
INFO - 2021-07-03 10:26:09 --> Language Class Initialized
INFO - 2021-07-03 10:26:09 --> Loader Class Initialized
INFO - 2021-07-03 10:26:09 --> Helper loaded: basic_helper
INFO - 2021-07-03 10:26:09 --> Helper loaded: url_helper
INFO - 2021-07-03 10:26:09 --> Helper loaded: file_helper
INFO - 2021-07-03 10:26:09 --> Helper loaded: form_helper
INFO - 2021-07-03 10:26:09 --> Helper loaded: cookie_helper
INFO - 2021-07-03 10:26:09 --> Helper loaded: security_helper
INFO - 2021-07-03 10:26:09 --> Helper loaded: directory_helper
INFO - 2021-07-03 10:26:09 --> Helper loaded: language_helper
INFO - 2021-07-03 10:26:09 --> Helper loaded: general_helper
INFO - 2021-07-03 10:26:09 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 10:26:09 --> Database Driver Class Initialized
INFO - 2021-07-03 10:26:09 --> Config Class Initialized
INFO - 2021-07-03 10:26:09 --> Hooks Class Initialized
DEBUG - 2021-07-03 10:26:09 --> UTF-8 Support Enabled
INFO - 2021-07-03 10:26:09 --> Utf8 Class Initialized
INFO - 2021-07-03 10:26:09 --> URI Class Initialized
INFO - 2021-07-03 10:26:09 --> Router Class Initialized
INFO - 2021-07-03 10:26:09 --> Output Class Initialized
INFO - 2021-07-03 10:26:09 --> Security Class Initialized
DEBUG - 2021-07-03 10:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-07-03 10:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 10:26:09 --> Input Class Initialized
INFO - 2021-07-03 10:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 10:26:09 --> Language Class Initialized
INFO - 2021-07-03 10:26:09 --> Parser Class Initialized
ERROR - 2021-07-03 10:26:09 --> 404 Page Not Found: Faviconico/index
INFO - 2021-07-03 10:26:09 --> Form Validation Class Initialized
INFO - 2021-07-03 10:26:09 --> Upload Class Initialized
INFO - 2021-07-03 10:26:09 --> Email Class Initialized
INFO - 2021-07-03 10:26:09 --> MY_Model class loaded
INFO - 2021-07-03 10:26:09 --> Model "Users_model" initialized
INFO - 2021-07-03 10:26:09 --> Model "Settings_model" initialized
INFO - 2021-07-03 10:26:09 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 10:26:09 --> Model "Permissions_model" initialized
INFO - 2021-07-03 10:26:09 --> Model "Roles_model" initialized
INFO - 2021-07-03 10:26:09 --> Model "Activity_model" initialized
INFO - 2021-07-03 10:26:09 --> Model "Templates_model" initialized
INFO - 2021-07-03 10:26:09 --> Database Driver Class Initialized
INFO - 2021-07-03 10:26:09 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 10:26:09 --> Controller Class Initialized
INFO - 2021-07-03 13:26:09 --> File loaded: C:\wamp64\www\crm\application\views\account/login.php
INFO - 2021-07-03 13:26:09 --> Final output sent to browser
DEBUG - 2021-07-03 13:26:09 --> Total execution time: 0.0555
INFO - 2021-07-03 10:26:10 --> Config Class Initialized
INFO - 2021-07-03 10:26:10 --> Hooks Class Initialized
DEBUG - 2021-07-03 10:26:10 --> UTF-8 Support Enabled
INFO - 2021-07-03 10:26:10 --> Utf8 Class Initialized
INFO - 2021-07-03 10:26:10 --> URI Class Initialized
INFO - 2021-07-03 10:26:10 --> Config Class Initialized
INFO - 2021-07-03 10:26:10 --> Router Class Initialized
INFO - 2021-07-03 10:26:10 --> Hooks Class Initialized
INFO - 2021-07-03 10:26:10 --> Output Class Initialized
DEBUG - 2021-07-03 10:26:10 --> UTF-8 Support Enabled
INFO - 2021-07-03 10:26:10 --> Utf8 Class Initialized
INFO - 2021-07-03 10:26:10 --> Security Class Initialized
INFO - 2021-07-03 10:26:10 --> URI Class Initialized
DEBUG - 2021-07-03 10:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 10:26:10 --> Input Class Initialized
INFO - 2021-07-03 10:26:10 --> Router Class Initialized
INFO - 2021-07-03 10:26:10 --> Language Class Initialized
INFO - 2021-07-03 10:26:10 --> Output Class Initialized
ERROR - 2021-07-03 10:26:10 --> 404 Page Not Found: Assets/jquery
INFO - 2021-07-03 10:26:10 --> Security Class Initialized
DEBUG - 2021-07-03 10:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 10:26:10 --> Input Class Initialized
INFO - 2021-07-03 10:26:10 --> Language Class Initialized
ERROR - 2021-07-03 10:26:10 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-03 10:26:11 --> Config Class Initialized
INFO - 2021-07-03 10:26:11 --> Hooks Class Initialized
DEBUG - 2021-07-03 10:26:11 --> UTF-8 Support Enabled
INFO - 2021-07-03 10:26:11 --> Utf8 Class Initialized
INFO - 2021-07-03 10:26:11 --> URI Class Initialized
INFO - 2021-07-03 10:26:11 --> Router Class Initialized
INFO - 2021-07-03 10:26:11 --> Output Class Initialized
INFO - 2021-07-03 10:26:11 --> Security Class Initialized
DEBUG - 2021-07-03 10:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 10:26:11 --> Input Class Initialized
INFO - 2021-07-03 10:26:11 --> Language Class Initialized
ERROR - 2021-07-03 10:26:11 --> 404 Page Not Found: Faviconico/index
INFO - 2021-07-03 10:26:51 --> Config Class Initialized
INFO - 2021-07-03 10:26:51 --> Hooks Class Initialized
DEBUG - 2021-07-03 10:26:51 --> UTF-8 Support Enabled
INFO - 2021-07-03 10:26:51 --> Utf8 Class Initialized
INFO - 2021-07-03 10:26:51 --> URI Class Initialized
DEBUG - 2021-07-03 10:26:51 --> No URI present. Default controller set.
INFO - 2021-07-03 10:26:51 --> Router Class Initialized
INFO - 2021-07-03 10:26:51 --> Output Class Initialized
INFO - 2021-07-03 10:26:51 --> Security Class Initialized
DEBUG - 2021-07-03 10:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 10:26:51 --> Input Class Initialized
INFO - 2021-07-03 10:26:51 --> Language Class Initialized
INFO - 2021-07-03 10:26:51 --> Loader Class Initialized
INFO - 2021-07-03 10:26:51 --> Helper loaded: basic_helper
INFO - 2021-07-03 10:26:51 --> Helper loaded: url_helper
INFO - 2021-07-03 10:26:51 --> Helper loaded: file_helper
INFO - 2021-07-03 10:26:51 --> Helper loaded: form_helper
INFO - 2021-07-03 10:26:51 --> Helper loaded: cookie_helper
INFO - 2021-07-03 10:26:51 --> Helper loaded: security_helper
INFO - 2021-07-03 10:26:51 --> Helper loaded: directory_helper
INFO - 2021-07-03 10:26:51 --> Helper loaded: language_helper
INFO - 2021-07-03 10:26:51 --> Helper loaded: general_helper
INFO - 2021-07-03 10:26:51 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 10:26:51 --> Database Driver Class Initialized
DEBUG - 2021-07-03 10:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 10:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 10:26:51 --> Parser Class Initialized
INFO - 2021-07-03 10:26:51 --> Form Validation Class Initialized
INFO - 2021-07-03 10:26:51 --> Upload Class Initialized
INFO - 2021-07-03 10:26:51 --> Email Class Initialized
INFO - 2021-07-03 10:26:51 --> MY_Model class loaded
INFO - 2021-07-03 10:26:51 --> Model "Users_model" initialized
INFO - 2021-07-03 10:26:51 --> Model "Settings_model" initialized
INFO - 2021-07-03 10:26:51 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 10:26:51 --> Model "Permissions_model" initialized
INFO - 2021-07-03 10:26:51 --> Model "Roles_model" initialized
INFO - 2021-07-03 10:26:51 --> Model "Activity_model" initialized
INFO - 2021-07-03 10:26:51 --> Model "Templates_model" initialized
INFO - 2021-07-03 10:26:51 --> Database Driver Class Initialized
INFO - 2021-07-03 10:26:51 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 10:26:51 --> Controller Class Initialized
ERROR - 2021-07-03 13:26:51 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 13:26:51 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-03 13:26:51 --> Final output sent to browser
DEBUG - 2021-07-03 13:26:51 --> Total execution time: 0.1287
INFO - 2021-07-03 10:27:02 --> Config Class Initialized
INFO - 2021-07-03 10:27:02 --> Hooks Class Initialized
DEBUG - 2021-07-03 10:27:02 --> UTF-8 Support Enabled
INFO - 2021-07-03 10:27:02 --> Utf8 Class Initialized
INFO - 2021-07-03 10:27:02 --> URI Class Initialized
INFO - 2021-07-03 10:27:02 --> Router Class Initialized
INFO - 2021-07-03 10:27:02 --> Output Class Initialized
INFO - 2021-07-03 10:27:02 --> Security Class Initialized
DEBUG - 2021-07-03 10:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 10:27:02 --> Input Class Initialized
INFO - 2021-07-03 10:27:02 --> Language Class Initialized
INFO - 2021-07-03 10:27:02 --> Loader Class Initialized
INFO - 2021-07-03 10:27:02 --> Helper loaded: basic_helper
INFO - 2021-07-03 10:27:02 --> Helper loaded: url_helper
INFO - 2021-07-03 10:27:02 --> Helper loaded: file_helper
INFO - 2021-07-03 10:27:02 --> Helper loaded: form_helper
INFO - 2021-07-03 10:27:02 --> Helper loaded: cookie_helper
INFO - 2021-07-03 10:27:02 --> Helper loaded: security_helper
INFO - 2021-07-03 10:27:02 --> Helper loaded: directory_helper
INFO - 2021-07-03 10:27:02 --> Helper loaded: language_helper
INFO - 2021-07-03 10:27:02 --> Helper loaded: general_helper
INFO - 2021-07-03 10:27:02 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 10:27:02 --> Database Driver Class Initialized
DEBUG - 2021-07-03 10:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 10:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 10:27:02 --> Parser Class Initialized
INFO - 2021-07-03 10:27:02 --> Form Validation Class Initialized
INFO - 2021-07-03 10:27:02 --> Upload Class Initialized
INFO - 2021-07-03 10:27:02 --> Email Class Initialized
INFO - 2021-07-03 10:27:02 --> MY_Model class loaded
INFO - 2021-07-03 10:27:02 --> Model "Users_model" initialized
INFO - 2021-07-03 10:27:02 --> Model "Settings_model" initialized
INFO - 2021-07-03 10:27:02 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 10:27:02 --> Model "Permissions_model" initialized
INFO - 2021-07-03 10:27:02 --> Model "Roles_model" initialized
INFO - 2021-07-03 10:27:02 --> Model "Activity_model" initialized
INFO - 2021-07-03 10:27:02 --> Model "Templates_model" initialized
INFO - 2021-07-03 10:27:02 --> Database Driver Class Initialized
INFO - 2021-07-03 10:27:02 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 10:27:02 --> Controller Class Initialized
ERROR - 2021-07-03 13:27:02 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 13:27:02 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-03 13:27:02 --> Final output sent to browser
DEBUG - 2021-07-03 13:27:02 --> Total execution time: 0.1447
INFO - 2021-07-03 10:27:05 --> Config Class Initialized
INFO - 2021-07-03 10:27:05 --> Hooks Class Initialized
DEBUG - 2021-07-03 10:27:05 --> UTF-8 Support Enabled
INFO - 2021-07-03 10:27:05 --> Utf8 Class Initialized
INFO - 2021-07-03 10:27:05 --> URI Class Initialized
INFO - 2021-07-03 10:27:05 --> Router Class Initialized
INFO - 2021-07-03 10:27:05 --> Output Class Initialized
INFO - 2021-07-03 10:27:05 --> Security Class Initialized
DEBUG - 2021-07-03 10:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 10:27:05 --> Input Class Initialized
INFO - 2021-07-03 10:27:05 --> Language Class Initialized
INFO - 2021-07-03 10:27:05 --> Loader Class Initialized
INFO - 2021-07-03 10:27:05 --> Helper loaded: basic_helper
INFO - 2021-07-03 10:27:05 --> Helper loaded: url_helper
INFO - 2021-07-03 10:27:05 --> Helper loaded: file_helper
INFO - 2021-07-03 10:27:05 --> Helper loaded: form_helper
INFO - 2021-07-03 10:27:05 --> Helper loaded: cookie_helper
INFO - 2021-07-03 10:27:05 --> Helper loaded: security_helper
INFO - 2021-07-03 10:27:05 --> Helper loaded: directory_helper
INFO - 2021-07-03 10:27:05 --> Helper loaded: language_helper
INFO - 2021-07-03 10:27:05 --> Helper loaded: general_helper
INFO - 2021-07-03 10:27:05 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 10:27:05 --> Database Driver Class Initialized
DEBUG - 2021-07-03 10:27:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 10:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 10:27:05 --> Parser Class Initialized
INFO - 2021-07-03 10:27:05 --> Form Validation Class Initialized
INFO - 2021-07-03 10:27:05 --> Upload Class Initialized
INFO - 2021-07-03 10:27:05 --> Email Class Initialized
INFO - 2021-07-03 10:27:05 --> MY_Model class loaded
INFO - 2021-07-03 10:27:05 --> Model "Users_model" initialized
INFO - 2021-07-03 10:27:05 --> Model "Settings_model" initialized
INFO - 2021-07-03 10:27:05 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 10:27:05 --> Model "Permissions_model" initialized
INFO - 2021-07-03 10:27:05 --> Model "Roles_model" initialized
INFO - 2021-07-03 10:27:05 --> Model "Activity_model" initialized
INFO - 2021-07-03 10:27:05 --> Model "Templates_model" initialized
INFO - 2021-07-03 10:27:05 --> Database Driver Class Initialized
INFO - 2021-07-03 10:27:05 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 10:27:05 --> Controller Class Initialized
ERROR - 2021-07-03 13:27:05 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 13:27:06 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-03 13:27:06 --> Final output sent to browser
DEBUG - 2021-07-03 13:27:06 --> Total execution time: 0.5732
INFO - 2021-07-03 10:27:33 --> Config Class Initialized
INFO - 2021-07-03 10:27:33 --> Hooks Class Initialized
DEBUG - 2021-07-03 10:27:33 --> UTF-8 Support Enabled
INFO - 2021-07-03 10:27:33 --> Utf8 Class Initialized
INFO - 2021-07-03 10:27:33 --> URI Class Initialized
DEBUG - 2021-07-03 10:27:33 --> No URI present. Default controller set.
INFO - 2021-07-03 10:27:33 --> Router Class Initialized
INFO - 2021-07-03 10:27:33 --> Output Class Initialized
INFO - 2021-07-03 10:27:33 --> Security Class Initialized
DEBUG - 2021-07-03 10:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 10:27:33 --> Input Class Initialized
INFO - 2021-07-03 10:27:33 --> Language Class Initialized
INFO - 2021-07-03 10:27:33 --> Loader Class Initialized
INFO - 2021-07-03 10:27:33 --> Helper loaded: basic_helper
INFO - 2021-07-03 10:27:33 --> Helper loaded: url_helper
INFO - 2021-07-03 10:27:33 --> Helper loaded: file_helper
INFO - 2021-07-03 10:27:33 --> Helper loaded: form_helper
INFO - 2021-07-03 10:27:33 --> Helper loaded: cookie_helper
INFO - 2021-07-03 10:27:33 --> Helper loaded: security_helper
INFO - 2021-07-03 10:27:33 --> Helper loaded: directory_helper
INFO - 2021-07-03 10:27:33 --> Helper loaded: language_helper
INFO - 2021-07-03 10:27:33 --> Helper loaded: general_helper
INFO - 2021-07-03 10:27:33 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 10:27:33 --> Database Driver Class Initialized
DEBUG - 2021-07-03 10:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 10:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 10:27:33 --> Parser Class Initialized
INFO - 2021-07-03 10:27:33 --> Form Validation Class Initialized
INFO - 2021-07-03 10:27:33 --> Upload Class Initialized
INFO - 2021-07-03 10:27:33 --> Email Class Initialized
INFO - 2021-07-03 10:27:33 --> MY_Model class loaded
INFO - 2021-07-03 10:27:33 --> Model "Users_model" initialized
INFO - 2021-07-03 10:27:33 --> Model "Settings_model" initialized
INFO - 2021-07-03 10:27:33 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 10:27:33 --> Model "Permissions_model" initialized
INFO - 2021-07-03 10:27:33 --> Model "Roles_model" initialized
INFO - 2021-07-03 10:27:33 --> Model "Activity_model" initialized
INFO - 2021-07-03 10:27:33 --> Model "Templates_model" initialized
INFO - 2021-07-03 10:27:33 --> Database Driver Class Initialized
INFO - 2021-07-03 10:27:33 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 10:27:33 --> Controller Class Initialized
ERROR - 2021-07-03 13:27:33 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 13:27:33 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-03 13:27:33 --> Final output sent to browser
DEBUG - 2021-07-03 13:27:33 --> Total execution time: 0.1310
INFO - 2021-07-03 10:27:34 --> Config Class Initialized
INFO - 2021-07-03 10:27:34 --> Hooks Class Initialized
DEBUG - 2021-07-03 10:27:34 --> UTF-8 Support Enabled
INFO - 2021-07-03 10:27:34 --> Utf8 Class Initialized
INFO - 2021-07-03 10:27:34 --> URI Class Initialized
INFO - 2021-07-03 10:27:34 --> Router Class Initialized
INFO - 2021-07-03 10:27:34 --> Output Class Initialized
INFO - 2021-07-03 10:27:34 --> Security Class Initialized
DEBUG - 2021-07-03 10:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 10:27:34 --> Input Class Initialized
INFO - 2021-07-03 10:27:34 --> Language Class Initialized
ERROR - 2021-07-03 10:27:34 --> 404 Page Not Found: Faviconico/index
INFO - 2021-07-03 10:29:13 --> Config Class Initialized
INFO - 2021-07-03 10:29:13 --> Hooks Class Initialized
DEBUG - 2021-07-03 10:29:13 --> UTF-8 Support Enabled
INFO - 2021-07-03 10:29:13 --> Utf8 Class Initialized
INFO - 2021-07-03 10:29:13 --> URI Class Initialized
DEBUG - 2021-07-03 10:29:13 --> No URI present. Default controller set.
INFO - 2021-07-03 10:29:13 --> Router Class Initialized
INFO - 2021-07-03 10:29:13 --> Output Class Initialized
INFO - 2021-07-03 10:29:13 --> Security Class Initialized
DEBUG - 2021-07-03 10:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 10:29:13 --> Input Class Initialized
INFO - 2021-07-03 10:29:13 --> Language Class Initialized
INFO - 2021-07-03 10:29:13 --> Loader Class Initialized
INFO - 2021-07-03 10:29:13 --> Helper loaded: basic_helper
INFO - 2021-07-03 10:29:13 --> Helper loaded: url_helper
INFO - 2021-07-03 10:29:13 --> Helper loaded: file_helper
INFO - 2021-07-03 10:29:13 --> Helper loaded: form_helper
INFO - 2021-07-03 10:29:13 --> Helper loaded: cookie_helper
INFO - 2021-07-03 10:29:13 --> Helper loaded: security_helper
INFO - 2021-07-03 10:29:13 --> Helper loaded: directory_helper
INFO - 2021-07-03 10:29:13 --> Helper loaded: language_helper
INFO - 2021-07-03 10:29:13 --> Helper loaded: general_helper
INFO - 2021-07-03 10:29:13 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 10:29:13 --> Database Driver Class Initialized
DEBUG - 2021-07-03 10:29:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 10:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 10:29:13 --> Parser Class Initialized
INFO - 2021-07-03 10:29:13 --> Form Validation Class Initialized
INFO - 2021-07-03 10:29:13 --> Upload Class Initialized
INFO - 2021-07-03 10:29:13 --> Email Class Initialized
INFO - 2021-07-03 10:29:13 --> MY_Model class loaded
INFO - 2021-07-03 10:29:13 --> Model "Users_model" initialized
INFO - 2021-07-03 10:29:13 --> Model "Settings_model" initialized
INFO - 2021-07-03 10:29:13 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 10:29:13 --> Model "Permissions_model" initialized
INFO - 2021-07-03 10:29:13 --> Model "Roles_model" initialized
INFO - 2021-07-03 10:29:13 --> Model "Activity_model" initialized
INFO - 2021-07-03 10:29:13 --> Model "Templates_model" initialized
INFO - 2021-07-03 10:29:13 --> Database Driver Class Initialized
INFO - 2021-07-03 10:29:13 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 10:29:13 --> Controller Class Initialized
INFO - 2021-07-03 10:29:13 --> Config Class Initialized
INFO - 2021-07-03 10:29:13 --> Hooks Class Initialized
DEBUG - 2021-07-03 10:29:13 --> UTF-8 Support Enabled
INFO - 2021-07-03 10:29:13 --> Utf8 Class Initialized
INFO - 2021-07-03 10:29:13 --> URI Class Initialized
INFO - 2021-07-03 10:29:13 --> Config Class Initialized
INFO - 2021-07-03 10:29:13 --> Hooks Class Initialized
INFO - 2021-07-03 10:29:13 --> Router Class Initialized
DEBUG - 2021-07-03 10:29:13 --> UTF-8 Support Enabled
INFO - 2021-07-03 10:29:13 --> Utf8 Class Initialized
INFO - 2021-07-03 10:29:13 --> Output Class Initialized
INFO - 2021-07-03 10:29:13 --> URI Class Initialized
INFO - 2021-07-03 10:29:13 --> Security Class Initialized
DEBUG - 2021-07-03 10:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 10:29:13 --> Router Class Initialized
INFO - 2021-07-03 10:29:13 --> Input Class Initialized
INFO - 2021-07-03 10:29:13 --> Language Class Initialized
INFO - 2021-07-03 10:29:13 --> Output Class Initialized
INFO - 2021-07-03 10:29:13 --> Security Class Initialized
ERROR - 2021-07-03 10:29:13 --> 404 Page Not Found: Faviconico/index
DEBUG - 2021-07-03 10:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 10:29:13 --> Input Class Initialized
INFO - 2021-07-03 10:29:13 --> Language Class Initialized
INFO - 2021-07-03 10:29:13 --> Loader Class Initialized
INFO - 2021-07-03 10:29:13 --> Helper loaded: basic_helper
INFO - 2021-07-03 10:29:13 --> Helper loaded: url_helper
INFO - 2021-07-03 10:29:13 --> Helper loaded: file_helper
INFO - 2021-07-03 10:29:13 --> Helper loaded: form_helper
INFO - 2021-07-03 10:29:13 --> Helper loaded: cookie_helper
INFO - 2021-07-03 10:29:13 --> Helper loaded: security_helper
INFO - 2021-07-03 10:29:13 --> Helper loaded: directory_helper
INFO - 2021-07-03 10:29:13 --> Helper loaded: language_helper
INFO - 2021-07-03 10:29:13 --> Helper loaded: general_helper
INFO - 2021-07-03 10:29:13 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 10:29:13 --> Database Driver Class Initialized
DEBUG - 2021-07-03 10:29:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 10:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 10:29:13 --> Parser Class Initialized
INFO - 2021-07-03 10:29:13 --> Form Validation Class Initialized
INFO - 2021-07-03 10:29:13 --> Upload Class Initialized
INFO - 2021-07-03 10:29:13 --> Email Class Initialized
INFO - 2021-07-03 10:29:13 --> MY_Model class loaded
INFO - 2021-07-03 10:29:13 --> Model "Users_model" initialized
INFO - 2021-07-03 10:29:13 --> Model "Settings_model" initialized
INFO - 2021-07-03 10:29:13 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 10:29:13 --> Model "Permissions_model" initialized
INFO - 2021-07-03 10:29:13 --> Model "Roles_model" initialized
INFO - 2021-07-03 10:29:13 --> Model "Activity_model" initialized
INFO - 2021-07-03 10:29:13 --> Model "Templates_model" initialized
INFO - 2021-07-03 10:29:13 --> Database Driver Class Initialized
INFO - 2021-07-03 10:29:13 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 10:29:13 --> Controller Class Initialized
INFO - 2021-07-03 13:29:13 --> File loaded: C:\wamp64\www\crm\application\views\account/login.php
INFO - 2021-07-03 13:29:13 --> Final output sent to browser
DEBUG - 2021-07-03 13:29:13 --> Total execution time: 0.0728
INFO - 2021-07-03 10:29:13 --> Config Class Initialized
INFO - 2021-07-03 10:29:13 --> Config Class Initialized
INFO - 2021-07-03 10:29:13 --> Hooks Class Initialized
INFO - 2021-07-03 10:29:13 --> Hooks Class Initialized
DEBUG - 2021-07-03 10:29:13 --> UTF-8 Support Enabled
DEBUG - 2021-07-03 10:29:13 --> UTF-8 Support Enabled
INFO - 2021-07-03 10:29:13 --> Utf8 Class Initialized
INFO - 2021-07-03 10:29:13 --> Utf8 Class Initialized
INFO - 2021-07-03 10:29:13 --> URI Class Initialized
INFO - 2021-07-03 10:29:13 --> URI Class Initialized
INFO - 2021-07-03 10:29:13 --> Router Class Initialized
INFO - 2021-07-03 10:29:13 --> Router Class Initialized
INFO - 2021-07-03 10:29:13 --> Output Class Initialized
INFO - 2021-07-03 10:29:13 --> Output Class Initialized
INFO - 2021-07-03 10:29:13 --> Security Class Initialized
INFO - 2021-07-03 10:29:13 --> Security Class Initialized
DEBUG - 2021-07-03 10:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-03 10:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 10:29:13 --> Input Class Initialized
INFO - 2021-07-03 10:29:13 --> Input Class Initialized
INFO - 2021-07-03 10:29:13 --> Language Class Initialized
INFO - 2021-07-03 10:29:13 --> Language Class Initialized
ERROR - 2021-07-03 10:29:13 --> 404 Page Not Found: Assets/jquery
ERROR - 2021-07-03 10:29:13 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-03 10:29:13 --> Config Class Initialized
INFO - 2021-07-03 10:29:13 --> Hooks Class Initialized
DEBUG - 2021-07-03 10:29:13 --> UTF-8 Support Enabled
INFO - 2021-07-03 10:29:13 --> Utf8 Class Initialized
INFO - 2021-07-03 10:29:13 --> URI Class Initialized
INFO - 2021-07-03 10:29:13 --> Router Class Initialized
INFO - 2021-07-03 10:29:13 --> Output Class Initialized
INFO - 2021-07-03 10:29:13 --> Security Class Initialized
DEBUG - 2021-07-03 10:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 10:29:13 --> Input Class Initialized
INFO - 2021-07-03 10:29:13 --> Language Class Initialized
ERROR - 2021-07-03 10:29:13 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-03 10:29:40 --> Config Class Initialized
INFO - 2021-07-03 10:29:40 --> Hooks Class Initialized
DEBUG - 2021-07-03 10:29:40 --> UTF-8 Support Enabled
INFO - 2021-07-03 10:29:40 --> Utf8 Class Initialized
INFO - 2021-07-03 10:29:40 --> URI Class Initialized
INFO - 2021-07-03 10:29:40 --> Router Class Initialized
INFO - 2021-07-03 10:29:40 --> Output Class Initialized
INFO - 2021-07-03 10:29:40 --> Security Class Initialized
DEBUG - 2021-07-03 10:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 10:29:40 --> Input Class Initialized
INFO - 2021-07-03 10:29:40 --> Language Class Initialized
INFO - 2021-07-03 10:29:40 --> Loader Class Initialized
INFO - 2021-07-03 10:29:40 --> Helper loaded: basic_helper
INFO - 2021-07-03 10:29:40 --> Helper loaded: url_helper
INFO - 2021-07-03 10:29:40 --> Helper loaded: file_helper
INFO - 2021-07-03 10:29:40 --> Helper loaded: form_helper
INFO - 2021-07-03 10:29:40 --> Helper loaded: cookie_helper
INFO - 2021-07-03 10:29:40 --> Helper loaded: security_helper
INFO - 2021-07-03 10:29:40 --> Helper loaded: directory_helper
INFO - 2021-07-03 10:29:40 --> Helper loaded: language_helper
INFO - 2021-07-03 10:29:40 --> Helper loaded: general_helper
INFO - 2021-07-03 10:29:40 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 10:29:40 --> Database Driver Class Initialized
DEBUG - 2021-07-03 10:29:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 10:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 10:29:40 --> Parser Class Initialized
INFO - 2021-07-03 10:29:40 --> Form Validation Class Initialized
INFO - 2021-07-03 10:29:40 --> Upload Class Initialized
INFO - 2021-07-03 10:29:40 --> Email Class Initialized
INFO - 2021-07-03 10:29:40 --> MY_Model class loaded
INFO - 2021-07-03 10:29:40 --> Model "Users_model" initialized
INFO - 2021-07-03 10:29:40 --> Model "Settings_model" initialized
INFO - 2021-07-03 10:29:40 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 10:29:40 --> Model "Permissions_model" initialized
INFO - 2021-07-03 10:29:40 --> Model "Roles_model" initialized
INFO - 2021-07-03 10:29:40 --> Model "Activity_model" initialized
INFO - 2021-07-03 10:29:40 --> Model "Templates_model" initialized
INFO - 2021-07-03 10:29:40 --> Database Driver Class Initialized
INFO - 2021-07-03 10:29:40 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 10:29:40 --> Controller Class Initialized
DEBUG - 2021-07-03 13:29:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-03 13:29:40 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2021-07-03 10:29:40 --> Config Class Initialized
INFO - 2021-07-03 10:29:40 --> Hooks Class Initialized
DEBUG - 2021-07-03 10:29:40 --> UTF-8 Support Enabled
INFO - 2021-07-03 10:29:40 --> Utf8 Class Initialized
INFO - 2021-07-03 10:29:40 --> URI Class Initialized
DEBUG - 2021-07-03 10:29:40 --> No URI present. Default controller set.
INFO - 2021-07-03 10:29:40 --> Router Class Initialized
INFO - 2021-07-03 10:29:40 --> Output Class Initialized
INFO - 2021-07-03 10:29:40 --> Security Class Initialized
DEBUG - 2021-07-03 10:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 10:29:40 --> Input Class Initialized
INFO - 2021-07-03 10:29:40 --> Language Class Initialized
INFO - 2021-07-03 10:29:40 --> Loader Class Initialized
INFO - 2021-07-03 10:29:40 --> Helper loaded: basic_helper
INFO - 2021-07-03 10:29:40 --> Helper loaded: url_helper
INFO - 2021-07-03 10:29:40 --> Helper loaded: file_helper
INFO - 2021-07-03 10:29:40 --> Helper loaded: form_helper
INFO - 2021-07-03 10:29:40 --> Helper loaded: cookie_helper
INFO - 2021-07-03 10:29:40 --> Helper loaded: security_helper
INFO - 2021-07-03 10:29:40 --> Helper loaded: directory_helper
INFO - 2021-07-03 10:29:40 --> Helper loaded: language_helper
INFO - 2021-07-03 10:29:40 --> Helper loaded: general_helper
INFO - 2021-07-03 10:29:40 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 10:29:40 --> Database Driver Class Initialized
DEBUG - 2021-07-03 10:29:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 10:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 10:29:40 --> Parser Class Initialized
INFO - 2021-07-03 10:29:40 --> Form Validation Class Initialized
INFO - 2021-07-03 10:29:40 --> Upload Class Initialized
INFO - 2021-07-03 10:29:40 --> Email Class Initialized
INFO - 2021-07-03 10:29:40 --> MY_Model class loaded
INFO - 2021-07-03 10:29:40 --> Model "Users_model" initialized
INFO - 2021-07-03 10:29:40 --> Model "Settings_model" initialized
INFO - 2021-07-03 10:29:40 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 10:29:40 --> Model "Permissions_model" initialized
INFO - 2021-07-03 10:29:40 --> Model "Roles_model" initialized
INFO - 2021-07-03 10:29:40 --> Model "Activity_model" initialized
INFO - 2021-07-03 10:29:40 --> Model "Templates_model" initialized
INFO - 2021-07-03 10:29:40 --> Database Driver Class Initialized
INFO - 2021-07-03 10:29:40 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 10:29:40 --> Controller Class Initialized
ERROR - 2021-07-03 13:29:40 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 13:29:40 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-03 13:29:40 --> Final output sent to browser
DEBUG - 2021-07-03 13:29:40 --> Total execution time: 0.0605
INFO - 2021-07-03 10:30:06 --> Config Class Initialized
INFO - 2021-07-03 10:30:06 --> Hooks Class Initialized
DEBUG - 2021-07-03 10:30:06 --> UTF-8 Support Enabled
INFO - 2021-07-03 10:30:06 --> Utf8 Class Initialized
INFO - 2021-07-03 10:30:06 --> URI Class Initialized
DEBUG - 2021-07-03 10:30:06 --> No URI present. Default controller set.
INFO - 2021-07-03 10:30:06 --> Router Class Initialized
INFO - 2021-07-03 10:30:06 --> Output Class Initialized
INFO - 2021-07-03 10:30:06 --> Security Class Initialized
DEBUG - 2021-07-03 10:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 10:30:06 --> Input Class Initialized
INFO - 2021-07-03 10:30:06 --> Language Class Initialized
INFO - 2021-07-03 10:30:06 --> Loader Class Initialized
INFO - 2021-07-03 10:30:06 --> Helper loaded: basic_helper
INFO - 2021-07-03 10:30:06 --> Helper loaded: url_helper
INFO - 2021-07-03 10:30:06 --> Helper loaded: file_helper
INFO - 2021-07-03 10:30:06 --> Helper loaded: form_helper
INFO - 2021-07-03 10:30:06 --> Helper loaded: cookie_helper
INFO - 2021-07-03 10:30:06 --> Helper loaded: security_helper
INFO - 2021-07-03 10:30:06 --> Helper loaded: directory_helper
INFO - 2021-07-03 10:30:06 --> Helper loaded: language_helper
INFO - 2021-07-03 10:30:06 --> Helper loaded: general_helper
INFO - 2021-07-03 10:30:06 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 10:30:06 --> Database Driver Class Initialized
DEBUG - 2021-07-03 10:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 10:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 10:30:06 --> Parser Class Initialized
INFO - 2021-07-03 10:30:06 --> Form Validation Class Initialized
INFO - 2021-07-03 10:30:06 --> Upload Class Initialized
INFO - 2021-07-03 10:30:06 --> Email Class Initialized
INFO - 2021-07-03 10:30:06 --> MY_Model class loaded
INFO - 2021-07-03 10:30:06 --> Model "Users_model" initialized
INFO - 2021-07-03 10:30:06 --> Model "Settings_model" initialized
INFO - 2021-07-03 10:30:06 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 10:30:06 --> Model "Permissions_model" initialized
INFO - 2021-07-03 10:30:06 --> Model "Roles_model" initialized
INFO - 2021-07-03 10:30:06 --> Model "Activity_model" initialized
INFO - 2021-07-03 10:30:06 --> Model "Templates_model" initialized
INFO - 2021-07-03 10:30:06 --> Database Driver Class Initialized
INFO - 2021-07-03 10:30:07 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 10:30:07 --> Controller Class Initialized
ERROR - 2021-07-03 13:30:07 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 13:30:07 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-03 13:30:07 --> Final output sent to browser
DEBUG - 2021-07-03 13:30:07 --> Total execution time: 0.1263
INFO - 2021-07-03 10:39:51 --> Config Class Initialized
INFO - 2021-07-03 10:39:51 --> Hooks Class Initialized
DEBUG - 2021-07-03 10:39:51 --> UTF-8 Support Enabled
INFO - 2021-07-03 10:39:51 --> Utf8 Class Initialized
INFO - 2021-07-03 10:39:51 --> URI Class Initialized
DEBUG - 2021-07-03 10:39:51 --> No URI present. Default controller set.
INFO - 2021-07-03 10:39:51 --> Router Class Initialized
INFO - 2021-07-03 10:39:51 --> Output Class Initialized
INFO - 2021-07-03 10:39:51 --> Security Class Initialized
DEBUG - 2021-07-03 10:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 10:39:51 --> Input Class Initialized
INFO - 2021-07-03 10:39:51 --> Language Class Initialized
INFO - 2021-07-03 10:39:51 --> Loader Class Initialized
INFO - 2021-07-03 10:39:51 --> Helper loaded: basic_helper
INFO - 2021-07-03 10:39:51 --> Helper loaded: url_helper
INFO - 2021-07-03 10:39:51 --> Helper loaded: file_helper
INFO - 2021-07-03 10:39:51 --> Helper loaded: form_helper
INFO - 2021-07-03 10:39:51 --> Helper loaded: cookie_helper
INFO - 2021-07-03 10:39:51 --> Helper loaded: security_helper
INFO - 2021-07-03 10:39:51 --> Helper loaded: directory_helper
INFO - 2021-07-03 10:39:51 --> Helper loaded: language_helper
INFO - 2021-07-03 10:39:51 --> Helper loaded: general_helper
INFO - 2021-07-03 10:39:51 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 10:39:51 --> Database Driver Class Initialized
DEBUG - 2021-07-03 10:39:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 10:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 10:39:51 --> Parser Class Initialized
INFO - 2021-07-03 10:39:51 --> Form Validation Class Initialized
INFO - 2021-07-03 10:39:51 --> Upload Class Initialized
INFO - 2021-07-03 10:39:51 --> Email Class Initialized
INFO - 2021-07-03 10:39:51 --> MY_Model class loaded
INFO - 2021-07-03 10:39:51 --> Model "Users_model" initialized
INFO - 2021-07-03 10:39:51 --> Model "Settings_model" initialized
INFO - 2021-07-03 10:39:51 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 10:39:51 --> Model "Permissions_model" initialized
INFO - 2021-07-03 10:39:51 --> Model "Roles_model" initialized
INFO - 2021-07-03 10:39:51 --> Model "Activity_model" initialized
INFO - 2021-07-03 10:39:51 --> Model "Templates_model" initialized
INFO - 2021-07-03 10:39:51 --> Database Driver Class Initialized
INFO - 2021-07-03 10:39:51 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 10:39:51 --> Controller Class Initialized
INFO - 2021-07-03 11:30:24 --> Config Class Initialized
INFO - 2021-07-03 11:30:24 --> Hooks Class Initialized
DEBUG - 2021-07-03 11:30:24 --> UTF-8 Support Enabled
INFO - 2021-07-03 11:30:24 --> Utf8 Class Initialized
INFO - 2021-07-03 11:30:24 --> URI Class Initialized
DEBUG - 2021-07-03 11:30:24 --> No URI present. Default controller set.
INFO - 2021-07-03 11:30:24 --> Router Class Initialized
INFO - 2021-07-03 11:30:24 --> Output Class Initialized
INFO - 2021-07-03 11:30:24 --> Security Class Initialized
DEBUG - 2021-07-03 11:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 11:30:24 --> Input Class Initialized
INFO - 2021-07-03 11:30:24 --> Language Class Initialized
INFO - 2021-07-03 11:30:24 --> Loader Class Initialized
INFO - 2021-07-03 11:30:24 --> Helper loaded: basic_helper
INFO - 2021-07-03 11:30:24 --> Helper loaded: url_helper
INFO - 2021-07-03 11:30:24 --> Helper loaded: file_helper
INFO - 2021-07-03 11:30:24 --> Helper loaded: form_helper
INFO - 2021-07-03 11:30:24 --> Helper loaded: cookie_helper
INFO - 2021-07-03 11:30:24 --> Helper loaded: security_helper
INFO - 2021-07-03 11:30:24 --> Helper loaded: directory_helper
INFO - 2021-07-03 11:30:24 --> Helper loaded: language_helper
INFO - 2021-07-03 11:30:24 --> Helper loaded: general_helper
INFO - 2021-07-03 11:30:24 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 11:30:24 --> Database Driver Class Initialized
DEBUG - 2021-07-03 11:30:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 11:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 11:30:24 --> Parser Class Initialized
INFO - 2021-07-03 11:30:24 --> Form Validation Class Initialized
INFO - 2021-07-03 11:30:24 --> Upload Class Initialized
INFO - 2021-07-03 11:30:24 --> Email Class Initialized
INFO - 2021-07-03 11:30:24 --> MY_Model class loaded
INFO - 2021-07-03 11:30:24 --> Model "Users_model" initialized
INFO - 2021-07-03 11:30:24 --> Model "Settings_model" initialized
INFO - 2021-07-03 11:30:24 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 11:30:24 --> Model "Permissions_model" initialized
INFO - 2021-07-03 11:30:24 --> Model "Roles_model" initialized
INFO - 2021-07-03 11:30:24 --> Model "Activity_model" initialized
INFO - 2021-07-03 11:30:24 --> Model "Templates_model" initialized
INFO - 2021-07-03 11:30:24 --> Database Driver Class Initialized
INFO - 2021-07-03 11:30:24 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 11:30:24 --> Controller Class Initialized
ERROR - 2021-07-03 14:30:24 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 14:30:24 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-03 14:30:24 --> Final output sent to browser
DEBUG - 2021-07-03 14:30:24 --> Total execution time: 0.1420
INFO - 2021-07-03 11:30:33 --> Config Class Initialized
INFO - 2021-07-03 11:30:33 --> Hooks Class Initialized
DEBUG - 2021-07-03 11:30:33 --> UTF-8 Support Enabled
INFO - 2021-07-03 11:30:33 --> Utf8 Class Initialized
INFO - 2021-07-03 11:30:33 --> URI Class Initialized
INFO - 2021-07-03 11:30:33 --> Router Class Initialized
INFO - 2021-07-03 11:30:33 --> Output Class Initialized
INFO - 2021-07-03 11:30:33 --> Security Class Initialized
DEBUG - 2021-07-03 11:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 11:30:33 --> Input Class Initialized
INFO - 2021-07-03 11:30:33 --> Language Class Initialized
INFO - 2021-07-03 11:30:33 --> Loader Class Initialized
INFO - 2021-07-03 11:30:33 --> Helper loaded: basic_helper
INFO - 2021-07-03 11:30:33 --> Helper loaded: url_helper
INFO - 2021-07-03 11:30:33 --> Helper loaded: file_helper
INFO - 2021-07-03 11:30:33 --> Helper loaded: form_helper
INFO - 2021-07-03 11:30:33 --> Helper loaded: cookie_helper
INFO - 2021-07-03 11:30:33 --> Helper loaded: security_helper
INFO - 2021-07-03 11:30:33 --> Helper loaded: directory_helper
INFO - 2021-07-03 11:30:33 --> Helper loaded: language_helper
INFO - 2021-07-03 11:30:33 --> Helper loaded: general_helper
INFO - 2021-07-03 11:30:33 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 11:30:33 --> Database Driver Class Initialized
DEBUG - 2021-07-03 11:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 11:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 11:30:33 --> Parser Class Initialized
INFO - 2021-07-03 11:30:33 --> Form Validation Class Initialized
INFO - 2021-07-03 11:30:33 --> Upload Class Initialized
INFO - 2021-07-03 11:30:33 --> Email Class Initialized
INFO - 2021-07-03 11:30:33 --> MY_Model class loaded
INFO - 2021-07-03 11:30:33 --> Model "Users_model" initialized
INFO - 2021-07-03 11:30:33 --> Model "Settings_model" initialized
INFO - 2021-07-03 11:30:33 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 11:30:33 --> Model "Permissions_model" initialized
INFO - 2021-07-03 11:30:33 --> Model "Roles_model" initialized
INFO - 2021-07-03 11:30:33 --> Model "Activity_model" initialized
INFO - 2021-07-03 11:30:33 --> Model "Templates_model" initialized
INFO - 2021-07-03 11:30:33 --> Database Driver Class Initialized
INFO - 2021-07-03 11:30:33 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 11:30:33 --> Controller Class Initialized
ERROR - 2021-07-03 14:30:33 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-03 14:30:33 --> Could not find the language line "user_username_taken"
ERROR - 2021-07-03 14:30:33 --> Could not find the language line "confirm)new_password"
INFO - 2021-07-03 14:30:33 --> File loaded: C:\wamp64\www\crm\application\views\account/profile.php
INFO - 2021-07-03 14:30:33 --> Final output sent to browser
DEBUG - 2021-07-03 14:30:33 --> Total execution time: 0.1489
INFO - 2021-07-03 11:42:04 --> Config Class Initialized
INFO - 2021-07-03 11:42:04 --> Hooks Class Initialized
DEBUG - 2021-07-03 11:42:04 --> UTF-8 Support Enabled
INFO - 2021-07-03 11:42:04 --> Utf8 Class Initialized
INFO - 2021-07-03 11:42:04 --> URI Class Initialized
DEBUG - 2021-07-03 11:42:04 --> No URI present. Default controller set.
INFO - 2021-07-03 11:42:04 --> Router Class Initialized
INFO - 2021-07-03 11:42:04 --> Output Class Initialized
INFO - 2021-07-03 11:42:04 --> Security Class Initialized
DEBUG - 2021-07-03 11:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 11:42:04 --> Input Class Initialized
INFO - 2021-07-03 11:42:04 --> Language Class Initialized
INFO - 2021-07-03 11:42:04 --> Loader Class Initialized
INFO - 2021-07-03 11:42:04 --> Helper loaded: basic_helper
INFO - 2021-07-03 11:42:04 --> Helper loaded: url_helper
INFO - 2021-07-03 11:42:04 --> Helper loaded: file_helper
INFO - 2021-07-03 11:42:04 --> Helper loaded: form_helper
INFO - 2021-07-03 11:42:04 --> Helper loaded: cookie_helper
INFO - 2021-07-03 11:42:04 --> Helper loaded: security_helper
INFO - 2021-07-03 11:42:04 --> Helper loaded: directory_helper
INFO - 2021-07-03 11:42:04 --> Helper loaded: language_helper
INFO - 2021-07-03 11:42:04 --> Helper loaded: general_helper
INFO - 2021-07-03 11:42:04 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 11:42:04 --> Database Driver Class Initialized
DEBUG - 2021-07-03 11:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 11:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 11:42:04 --> Parser Class Initialized
INFO - 2021-07-03 11:42:04 --> Form Validation Class Initialized
INFO - 2021-07-03 11:42:04 --> Upload Class Initialized
INFO - 2021-07-03 11:42:04 --> Email Class Initialized
INFO - 2021-07-03 11:42:04 --> MY_Model class loaded
INFO - 2021-07-03 11:42:04 --> Model "Users_model" initialized
INFO - 2021-07-03 11:42:04 --> Model "Settings_model" initialized
INFO - 2021-07-03 11:42:04 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 11:42:04 --> Model "Permissions_model" initialized
INFO - 2021-07-03 11:42:04 --> Model "Roles_model" initialized
INFO - 2021-07-03 11:42:04 --> Model "Activity_model" initialized
INFO - 2021-07-03 11:42:04 --> Model "Templates_model" initialized
INFO - 2021-07-03 11:42:04 --> Database Driver Class Initialized
INFO - 2021-07-03 11:42:05 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 11:42:05 --> Controller Class Initialized
INFO - 2021-07-03 11:42:05 --> Config Class Initialized
INFO - 2021-07-03 11:42:05 --> Hooks Class Initialized
DEBUG - 2021-07-03 11:42:05 --> UTF-8 Support Enabled
INFO - 2021-07-03 11:42:05 --> Utf8 Class Initialized
INFO - 2021-07-03 11:42:05 --> URI Class Initialized
INFO - 2021-07-03 11:42:05 --> Router Class Initialized
INFO - 2021-07-03 11:42:05 --> Config Class Initialized
INFO - 2021-07-03 11:42:05 --> Output Class Initialized
INFO - 2021-07-03 11:42:05 --> Hooks Class Initialized
INFO - 2021-07-03 11:42:05 --> Security Class Initialized
DEBUG - 2021-07-03 11:42:05 --> UTF-8 Support Enabled
DEBUG - 2021-07-03 11:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 11:42:05 --> Utf8 Class Initialized
INFO - 2021-07-03 11:42:05 --> Input Class Initialized
INFO - 2021-07-03 11:42:05 --> URI Class Initialized
INFO - 2021-07-03 11:42:05 --> Language Class Initialized
INFO - 2021-07-03 11:42:05 --> Router Class Initialized
ERROR - 2021-07-03 11:42:05 --> 404 Page Not Found: Faviconico/index
INFO - 2021-07-03 11:42:05 --> Output Class Initialized
INFO - 2021-07-03 11:42:05 --> Security Class Initialized
DEBUG - 2021-07-03 11:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 11:42:05 --> Input Class Initialized
INFO - 2021-07-03 11:42:05 --> Language Class Initialized
INFO - 2021-07-03 11:42:05 --> Loader Class Initialized
INFO - 2021-07-03 11:42:05 --> Helper loaded: basic_helper
INFO - 2021-07-03 11:42:05 --> Helper loaded: url_helper
INFO - 2021-07-03 11:42:05 --> Helper loaded: file_helper
INFO - 2021-07-03 11:42:05 --> Helper loaded: form_helper
INFO - 2021-07-03 11:42:05 --> Helper loaded: cookie_helper
INFO - 2021-07-03 11:42:05 --> Helper loaded: security_helper
INFO - 2021-07-03 11:42:05 --> Helper loaded: directory_helper
INFO - 2021-07-03 11:42:05 --> Helper loaded: language_helper
INFO - 2021-07-03 11:42:05 --> Helper loaded: general_helper
INFO - 2021-07-03 11:42:05 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 11:42:05 --> Database Driver Class Initialized
DEBUG - 2021-07-03 11:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 11:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 11:42:05 --> Parser Class Initialized
INFO - 2021-07-03 11:42:05 --> Form Validation Class Initialized
INFO - 2021-07-03 11:42:05 --> Upload Class Initialized
INFO - 2021-07-03 11:42:05 --> Email Class Initialized
INFO - 2021-07-03 11:42:05 --> MY_Model class loaded
INFO - 2021-07-03 11:42:05 --> Model "Users_model" initialized
INFO - 2021-07-03 11:42:05 --> Model "Settings_model" initialized
INFO - 2021-07-03 11:42:05 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 11:42:05 --> Model "Permissions_model" initialized
INFO - 2021-07-03 11:42:05 --> Model "Roles_model" initialized
INFO - 2021-07-03 11:42:05 --> Model "Activity_model" initialized
INFO - 2021-07-03 11:42:05 --> Model "Templates_model" initialized
INFO - 2021-07-03 11:42:05 --> Database Driver Class Initialized
INFO - 2021-07-03 11:42:05 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 11:42:05 --> Controller Class Initialized
INFO - 2021-07-03 14:42:05 --> File loaded: C:\wamp64\www\crm\application\views\account/login.php
INFO - 2021-07-03 14:42:05 --> Final output sent to browser
DEBUG - 2021-07-03 14:42:05 --> Total execution time: 0.0469
INFO - 2021-07-03 11:42:05 --> Config Class Initialized
INFO - 2021-07-03 11:42:05 --> Hooks Class Initialized
INFO - 2021-07-03 11:42:05 --> Config Class Initialized
DEBUG - 2021-07-03 11:42:05 --> UTF-8 Support Enabled
INFO - 2021-07-03 11:42:05 --> Hooks Class Initialized
INFO - 2021-07-03 11:42:05 --> Utf8 Class Initialized
DEBUG - 2021-07-03 11:42:05 --> UTF-8 Support Enabled
INFO - 2021-07-03 11:42:05 --> URI Class Initialized
INFO - 2021-07-03 11:42:05 --> Utf8 Class Initialized
INFO - 2021-07-03 11:42:05 --> Router Class Initialized
INFO - 2021-07-03 11:42:05 --> URI Class Initialized
INFO - 2021-07-03 11:42:05 --> Output Class Initialized
INFO - 2021-07-03 11:42:05 --> Router Class Initialized
INFO - 2021-07-03 11:42:05 --> Security Class Initialized
INFO - 2021-07-03 11:42:05 --> Output Class Initialized
DEBUG - 2021-07-03 11:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 11:42:05 --> Security Class Initialized
INFO - 2021-07-03 11:42:05 --> Input Class Initialized
DEBUG - 2021-07-03 11:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 11:42:05 --> Language Class Initialized
INFO - 2021-07-03 11:42:05 --> Input Class Initialized
ERROR - 2021-07-03 11:42:05 --> 404 Page Not Found: Assets/jquery
INFO - 2021-07-03 11:42:05 --> Language Class Initialized
ERROR - 2021-07-03 11:42:05 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-03 11:42:05 --> Config Class Initialized
INFO - 2021-07-03 11:42:05 --> Hooks Class Initialized
DEBUG - 2021-07-03 11:42:05 --> UTF-8 Support Enabled
INFO - 2021-07-03 11:42:05 --> Utf8 Class Initialized
INFO - 2021-07-03 11:42:05 --> URI Class Initialized
INFO - 2021-07-03 11:42:05 --> Router Class Initialized
INFO - 2021-07-03 11:42:05 --> Output Class Initialized
INFO - 2021-07-03 11:42:05 --> Security Class Initialized
DEBUG - 2021-07-03 11:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 11:42:05 --> Input Class Initialized
INFO - 2021-07-03 11:42:05 --> Language Class Initialized
ERROR - 2021-07-03 11:42:05 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-03 11:42:55 --> Config Class Initialized
INFO - 2021-07-03 11:42:55 --> Hooks Class Initialized
DEBUG - 2021-07-03 11:42:55 --> UTF-8 Support Enabled
INFO - 2021-07-03 11:42:55 --> Utf8 Class Initialized
INFO - 2021-07-03 11:42:55 --> URI Class Initialized
INFO - 2021-07-03 11:42:55 --> Router Class Initialized
INFO - 2021-07-03 11:42:55 --> Output Class Initialized
INFO - 2021-07-03 11:42:55 --> Security Class Initialized
DEBUG - 2021-07-03 11:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 11:42:55 --> Input Class Initialized
INFO - 2021-07-03 11:42:55 --> Language Class Initialized
INFO - 2021-07-03 11:42:55 --> Loader Class Initialized
INFO - 2021-07-03 11:42:55 --> Helper loaded: basic_helper
INFO - 2021-07-03 11:42:55 --> Helper loaded: url_helper
INFO - 2021-07-03 11:42:55 --> Helper loaded: file_helper
INFO - 2021-07-03 11:42:55 --> Helper loaded: form_helper
INFO - 2021-07-03 11:42:55 --> Helper loaded: cookie_helper
INFO - 2021-07-03 11:42:55 --> Helper loaded: security_helper
INFO - 2021-07-03 11:42:55 --> Helper loaded: directory_helper
INFO - 2021-07-03 11:42:55 --> Helper loaded: language_helper
INFO - 2021-07-03 11:42:55 --> Helper loaded: general_helper
INFO - 2021-07-03 11:42:55 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 11:42:55 --> Database Driver Class Initialized
DEBUG - 2021-07-03 11:42:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 11:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 11:42:55 --> Parser Class Initialized
INFO - 2021-07-03 11:42:55 --> Form Validation Class Initialized
INFO - 2021-07-03 11:42:55 --> Upload Class Initialized
INFO - 2021-07-03 11:42:55 --> Email Class Initialized
INFO - 2021-07-03 11:42:55 --> MY_Model class loaded
INFO - 2021-07-03 11:42:55 --> Model "Users_model" initialized
INFO - 2021-07-03 11:42:55 --> Model "Settings_model" initialized
INFO - 2021-07-03 11:42:55 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 11:42:55 --> Model "Permissions_model" initialized
INFO - 2021-07-03 11:42:55 --> Model "Roles_model" initialized
INFO - 2021-07-03 11:42:55 --> Model "Activity_model" initialized
INFO - 2021-07-03 11:42:55 --> Model "Templates_model" initialized
INFO - 2021-07-03 11:42:55 --> Database Driver Class Initialized
INFO - 2021-07-03 11:42:55 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 11:42:55 --> Controller Class Initialized
DEBUG - 2021-07-03 14:42:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-03 14:42:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2021-07-03 11:42:55 --> Config Class Initialized
INFO - 2021-07-03 11:42:55 --> Hooks Class Initialized
DEBUG - 2021-07-03 11:42:55 --> UTF-8 Support Enabled
INFO - 2021-07-03 11:42:55 --> Utf8 Class Initialized
INFO - 2021-07-03 11:42:55 --> URI Class Initialized
DEBUG - 2021-07-03 11:42:55 --> No URI present. Default controller set.
INFO - 2021-07-03 11:42:55 --> Router Class Initialized
INFO - 2021-07-03 11:42:55 --> Output Class Initialized
INFO - 2021-07-03 11:42:55 --> Security Class Initialized
DEBUG - 2021-07-03 11:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 11:42:55 --> Input Class Initialized
INFO - 2021-07-03 11:42:55 --> Language Class Initialized
INFO - 2021-07-03 11:42:55 --> Loader Class Initialized
INFO - 2021-07-03 11:42:55 --> Helper loaded: basic_helper
INFO - 2021-07-03 11:42:55 --> Helper loaded: url_helper
INFO - 2021-07-03 11:42:55 --> Helper loaded: file_helper
INFO - 2021-07-03 11:42:55 --> Helper loaded: form_helper
INFO - 2021-07-03 11:42:55 --> Helper loaded: cookie_helper
INFO - 2021-07-03 11:42:55 --> Helper loaded: security_helper
INFO - 2021-07-03 11:42:55 --> Helper loaded: directory_helper
INFO - 2021-07-03 11:42:55 --> Helper loaded: language_helper
INFO - 2021-07-03 11:42:55 --> Helper loaded: general_helper
INFO - 2021-07-03 11:42:55 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 11:42:55 --> Database Driver Class Initialized
DEBUG - 2021-07-03 11:42:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 11:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 11:42:55 --> Parser Class Initialized
INFO - 2021-07-03 11:42:55 --> Form Validation Class Initialized
INFO - 2021-07-03 11:42:55 --> Upload Class Initialized
INFO - 2021-07-03 11:42:55 --> Email Class Initialized
INFO - 2021-07-03 11:42:55 --> MY_Model class loaded
INFO - 2021-07-03 11:42:55 --> Model "Users_model" initialized
INFO - 2021-07-03 11:42:55 --> Model "Settings_model" initialized
INFO - 2021-07-03 11:42:55 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 11:42:55 --> Model "Permissions_model" initialized
INFO - 2021-07-03 11:42:55 --> Model "Roles_model" initialized
INFO - 2021-07-03 11:42:55 --> Model "Activity_model" initialized
INFO - 2021-07-03 11:42:55 --> Model "Templates_model" initialized
INFO - 2021-07-03 11:42:55 --> Database Driver Class Initialized
INFO - 2021-07-03 11:42:55 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 11:42:55 --> Controller Class Initialized
ERROR - 2021-07-03 14:42:55 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 14:42:55 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-03 14:42:55 --> Final output sent to browser
DEBUG - 2021-07-03 14:42:55 --> Total execution time: 0.0792
INFO - 2021-07-03 11:43:55 --> Config Class Initialized
INFO - 2021-07-03 11:43:55 --> Hooks Class Initialized
DEBUG - 2021-07-03 11:43:55 --> UTF-8 Support Enabled
INFO - 2021-07-03 11:43:55 --> Utf8 Class Initialized
INFO - 2021-07-03 11:43:55 --> URI Class Initialized
DEBUG - 2021-07-03 11:43:55 --> No URI present. Default controller set.
INFO - 2021-07-03 11:43:55 --> Router Class Initialized
INFO - 2021-07-03 11:43:55 --> Output Class Initialized
INFO - 2021-07-03 11:43:55 --> Security Class Initialized
DEBUG - 2021-07-03 11:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 11:43:55 --> Input Class Initialized
INFO - 2021-07-03 11:43:55 --> Language Class Initialized
INFO - 2021-07-03 11:43:55 --> Loader Class Initialized
INFO - 2021-07-03 11:43:55 --> Helper loaded: basic_helper
INFO - 2021-07-03 11:43:55 --> Helper loaded: url_helper
INFO - 2021-07-03 11:43:55 --> Helper loaded: file_helper
INFO - 2021-07-03 11:43:55 --> Helper loaded: form_helper
INFO - 2021-07-03 11:43:55 --> Helper loaded: cookie_helper
INFO - 2021-07-03 11:43:55 --> Helper loaded: security_helper
INFO - 2021-07-03 11:43:55 --> Helper loaded: directory_helper
INFO - 2021-07-03 11:43:55 --> Helper loaded: language_helper
INFO - 2021-07-03 11:43:55 --> Helper loaded: general_helper
INFO - 2021-07-03 11:43:55 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 11:43:55 --> Database Driver Class Initialized
DEBUG - 2021-07-03 11:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 11:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 11:43:55 --> Parser Class Initialized
INFO - 2021-07-03 11:43:55 --> Form Validation Class Initialized
INFO - 2021-07-03 11:43:55 --> Upload Class Initialized
INFO - 2021-07-03 11:43:55 --> Email Class Initialized
INFO - 2021-07-03 11:43:55 --> MY_Model class loaded
INFO - 2021-07-03 11:43:55 --> Model "Users_model" initialized
INFO - 2021-07-03 11:43:55 --> Model "Settings_model" initialized
INFO - 2021-07-03 11:43:55 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 11:43:55 --> Model "Permissions_model" initialized
INFO - 2021-07-03 11:43:55 --> Model "Roles_model" initialized
INFO - 2021-07-03 11:43:55 --> Model "Activity_model" initialized
INFO - 2021-07-03 11:43:55 --> Model "Templates_model" initialized
INFO - 2021-07-03 11:43:55 --> Database Driver Class Initialized
INFO - 2021-07-03 11:43:55 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 11:43:55 --> Controller Class Initialized
ERROR - 2021-07-03 14:43:55 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 14:43:55 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-03 14:43:55 --> Final output sent to browser
DEBUG - 2021-07-03 14:43:55 --> Total execution time: 0.1340
INFO - 2021-07-03 11:45:12 --> Config Class Initialized
INFO - 2021-07-03 11:45:12 --> Hooks Class Initialized
DEBUG - 2021-07-03 11:45:12 --> UTF-8 Support Enabled
INFO - 2021-07-03 11:45:12 --> Utf8 Class Initialized
INFO - 2021-07-03 11:45:12 --> URI Class Initialized
INFO - 2021-07-03 11:45:12 --> Router Class Initialized
INFO - 2021-07-03 11:45:12 --> Output Class Initialized
INFO - 2021-07-03 11:45:12 --> Security Class Initialized
DEBUG - 2021-07-03 11:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 11:45:12 --> Input Class Initialized
INFO - 2021-07-03 11:45:12 --> Language Class Initialized
INFO - 2021-07-03 11:45:12 --> Loader Class Initialized
INFO - 2021-07-03 11:45:12 --> Helper loaded: basic_helper
INFO - 2021-07-03 11:45:12 --> Helper loaded: url_helper
INFO - 2021-07-03 11:45:12 --> Helper loaded: file_helper
INFO - 2021-07-03 11:45:12 --> Helper loaded: form_helper
INFO - 2021-07-03 11:45:12 --> Helper loaded: cookie_helper
INFO - 2021-07-03 11:45:12 --> Helper loaded: security_helper
INFO - 2021-07-03 11:45:12 --> Helper loaded: directory_helper
INFO - 2021-07-03 11:45:12 --> Helper loaded: language_helper
INFO - 2021-07-03 11:45:12 --> Helper loaded: general_helper
INFO - 2021-07-03 11:45:12 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 11:45:12 --> Database Driver Class Initialized
DEBUG - 2021-07-03 11:45:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 11:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 11:45:12 --> Parser Class Initialized
INFO - 2021-07-03 11:45:12 --> Form Validation Class Initialized
INFO - 2021-07-03 11:45:12 --> Upload Class Initialized
INFO - 2021-07-03 11:45:12 --> Email Class Initialized
INFO - 2021-07-03 11:45:12 --> MY_Model class loaded
INFO - 2021-07-03 11:45:12 --> Model "Users_model" initialized
INFO - 2021-07-03 11:45:12 --> Model "Settings_model" initialized
INFO - 2021-07-03 11:45:12 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 11:45:12 --> Model "Permissions_model" initialized
INFO - 2021-07-03 11:45:12 --> Model "Roles_model" initialized
INFO - 2021-07-03 11:45:12 --> Model "Activity_model" initialized
INFO - 2021-07-03 11:45:12 --> Model "Templates_model" initialized
INFO - 2021-07-03 11:45:12 --> Database Driver Class Initialized
INFO - 2021-07-03 11:45:12 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 11:45:12 --> Controller Class Initialized
ERROR - 2021-07-03 14:45:12 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 14:45:12 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-03 14:45:12 --> Final output sent to browser
DEBUG - 2021-07-03 14:45:12 --> Total execution time: 0.6606
INFO - 2021-07-03 11:45:19 --> Config Class Initialized
INFO - 2021-07-03 11:45:19 --> Hooks Class Initialized
DEBUG - 2021-07-03 11:45:19 --> UTF-8 Support Enabled
INFO - 2021-07-03 11:45:19 --> Utf8 Class Initialized
INFO - 2021-07-03 11:45:19 --> URI Class Initialized
INFO - 2021-07-03 11:45:19 --> Router Class Initialized
INFO - 2021-07-03 11:45:19 --> Output Class Initialized
INFO - 2021-07-03 11:45:19 --> Security Class Initialized
DEBUG - 2021-07-03 11:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 11:45:19 --> Input Class Initialized
INFO - 2021-07-03 11:45:19 --> Language Class Initialized
INFO - 2021-07-03 11:45:19 --> Loader Class Initialized
INFO - 2021-07-03 11:45:19 --> Helper loaded: basic_helper
INFO - 2021-07-03 11:45:19 --> Helper loaded: url_helper
INFO - 2021-07-03 11:45:19 --> Helper loaded: file_helper
INFO - 2021-07-03 11:45:19 --> Helper loaded: form_helper
INFO - 2021-07-03 11:45:19 --> Helper loaded: cookie_helper
INFO - 2021-07-03 11:45:19 --> Helper loaded: security_helper
INFO - 2021-07-03 11:45:19 --> Helper loaded: directory_helper
INFO - 2021-07-03 11:45:19 --> Helper loaded: language_helper
INFO - 2021-07-03 11:45:19 --> Helper loaded: general_helper
INFO - 2021-07-03 11:45:19 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 11:45:19 --> Database Driver Class Initialized
DEBUG - 2021-07-03 11:45:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 11:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 11:45:19 --> Parser Class Initialized
INFO - 2021-07-03 11:45:19 --> Form Validation Class Initialized
INFO - 2021-07-03 11:45:19 --> Upload Class Initialized
INFO - 2021-07-03 11:45:19 --> Email Class Initialized
INFO - 2021-07-03 11:45:19 --> MY_Model class loaded
INFO - 2021-07-03 11:45:19 --> Model "Users_model" initialized
INFO - 2021-07-03 11:45:19 --> Model "Settings_model" initialized
INFO - 2021-07-03 11:45:19 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 11:45:19 --> Model "Permissions_model" initialized
INFO - 2021-07-03 11:45:19 --> Model "Roles_model" initialized
INFO - 2021-07-03 11:45:19 --> Model "Activity_model" initialized
INFO - 2021-07-03 11:45:19 --> Model "Templates_model" initialized
INFO - 2021-07-03 11:45:19 --> Database Driver Class Initialized
INFO - 2021-07-03 11:45:19 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 11:45:19 --> Controller Class Initialized
ERROR - 2021-07-03 14:45:19 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 14:45:19 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-03 14:45:19 --> Final output sent to browser
DEBUG - 2021-07-03 14:45:19 --> Total execution time: 0.1450
INFO - 2021-07-03 11:45:25 --> Config Class Initialized
INFO - 2021-07-03 11:45:25 --> Hooks Class Initialized
DEBUG - 2021-07-03 11:45:25 --> UTF-8 Support Enabled
INFO - 2021-07-03 11:45:25 --> Utf8 Class Initialized
INFO - 2021-07-03 11:45:25 --> URI Class Initialized
INFO - 2021-07-03 11:45:25 --> Router Class Initialized
INFO - 2021-07-03 11:45:25 --> Output Class Initialized
INFO - 2021-07-03 11:45:25 --> Security Class Initialized
DEBUG - 2021-07-03 11:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 11:45:25 --> Input Class Initialized
INFO - 2021-07-03 11:45:25 --> Language Class Initialized
INFO - 2021-07-03 11:45:25 --> Loader Class Initialized
INFO - 2021-07-03 11:45:25 --> Helper loaded: basic_helper
INFO - 2021-07-03 11:45:25 --> Helper loaded: url_helper
INFO - 2021-07-03 11:45:25 --> Helper loaded: file_helper
INFO - 2021-07-03 11:45:25 --> Helper loaded: form_helper
INFO - 2021-07-03 11:45:25 --> Helper loaded: cookie_helper
INFO - 2021-07-03 11:45:25 --> Helper loaded: security_helper
INFO - 2021-07-03 11:45:25 --> Helper loaded: directory_helper
INFO - 2021-07-03 11:45:25 --> Helper loaded: language_helper
INFO - 2021-07-03 11:45:25 --> Helper loaded: general_helper
INFO - 2021-07-03 11:45:25 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 11:45:25 --> Database Driver Class Initialized
DEBUG - 2021-07-03 11:45:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 11:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 11:45:25 --> Parser Class Initialized
INFO - 2021-07-03 11:45:25 --> Form Validation Class Initialized
INFO - 2021-07-03 11:45:25 --> Upload Class Initialized
INFO - 2021-07-03 11:45:25 --> Email Class Initialized
INFO - 2021-07-03 11:45:25 --> MY_Model class loaded
INFO - 2021-07-03 11:45:25 --> Model "Users_model" initialized
INFO - 2021-07-03 11:45:25 --> Model "Settings_model" initialized
INFO - 2021-07-03 11:45:25 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 11:45:25 --> Model "Permissions_model" initialized
INFO - 2021-07-03 11:45:25 --> Model "Roles_model" initialized
INFO - 2021-07-03 11:45:25 --> Model "Activity_model" initialized
INFO - 2021-07-03 11:45:25 --> Model "Templates_model" initialized
INFO - 2021-07-03 11:45:25 --> Database Driver Class Initialized
INFO - 2021-07-03 11:45:25 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 11:45:25 --> Controller Class Initialized
ERROR - 2021-07-03 14:45:25 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 14:45:25 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-03 14:45:25 --> Final output sent to browser
DEBUG - 2021-07-03 14:45:25 --> Total execution time: 0.1418
INFO - 2021-07-03 11:45:28 --> Config Class Initialized
INFO - 2021-07-03 11:45:28 --> Hooks Class Initialized
DEBUG - 2021-07-03 11:45:28 --> UTF-8 Support Enabled
INFO - 2021-07-03 11:45:28 --> Utf8 Class Initialized
INFO - 2021-07-03 11:45:28 --> URI Class Initialized
INFO - 2021-07-03 11:45:28 --> Router Class Initialized
INFO - 2021-07-03 11:45:28 --> Output Class Initialized
INFO - 2021-07-03 11:45:28 --> Security Class Initialized
DEBUG - 2021-07-03 11:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 11:45:28 --> Input Class Initialized
INFO - 2021-07-03 11:45:28 --> Language Class Initialized
INFO - 2021-07-03 11:45:28 --> Loader Class Initialized
INFO - 2021-07-03 11:45:28 --> Helper loaded: basic_helper
INFO - 2021-07-03 11:45:28 --> Helper loaded: url_helper
INFO - 2021-07-03 11:45:28 --> Helper loaded: file_helper
INFO - 2021-07-03 11:45:28 --> Helper loaded: form_helper
INFO - 2021-07-03 11:45:28 --> Helper loaded: cookie_helper
INFO - 2021-07-03 11:45:28 --> Helper loaded: security_helper
INFO - 2021-07-03 11:45:28 --> Helper loaded: directory_helper
INFO - 2021-07-03 11:45:28 --> Helper loaded: language_helper
INFO - 2021-07-03 11:45:28 --> Helper loaded: general_helper
INFO - 2021-07-03 11:45:28 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 11:45:28 --> Database Driver Class Initialized
DEBUG - 2021-07-03 11:45:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 11:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 11:45:28 --> Parser Class Initialized
INFO - 2021-07-03 11:45:28 --> Form Validation Class Initialized
INFO - 2021-07-03 11:45:28 --> Upload Class Initialized
INFO - 2021-07-03 11:45:28 --> Email Class Initialized
INFO - 2021-07-03 11:45:28 --> MY_Model class loaded
INFO - 2021-07-03 11:45:28 --> Model "Users_model" initialized
INFO - 2021-07-03 11:45:28 --> Model "Settings_model" initialized
INFO - 2021-07-03 11:45:28 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 11:45:28 --> Model "Permissions_model" initialized
INFO - 2021-07-03 11:45:28 --> Model "Roles_model" initialized
INFO - 2021-07-03 11:45:28 --> Model "Activity_model" initialized
INFO - 2021-07-03 11:45:28 --> Model "Templates_model" initialized
INFO - 2021-07-03 11:45:28 --> Database Driver Class Initialized
INFO - 2021-07-03 11:45:28 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 11:45:28 --> Controller Class Initialized
ERROR - 2021-07-03 14:45:28 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 14:45:28 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-03 14:45:28 --> Final output sent to browser
DEBUG - 2021-07-03 14:45:28 --> Total execution time: 0.0675
INFO - 2021-07-03 11:45:40 --> Config Class Initialized
INFO - 2021-07-03 11:45:40 --> Hooks Class Initialized
DEBUG - 2021-07-03 11:45:40 --> UTF-8 Support Enabled
INFO - 2021-07-03 11:45:40 --> Utf8 Class Initialized
INFO - 2021-07-03 11:45:40 --> URI Class Initialized
INFO - 2021-07-03 11:45:40 --> Router Class Initialized
INFO - 2021-07-03 11:45:40 --> Output Class Initialized
INFO - 2021-07-03 11:45:40 --> Security Class Initialized
DEBUG - 2021-07-03 11:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 11:45:40 --> Input Class Initialized
INFO - 2021-07-03 11:45:40 --> Language Class Initialized
INFO - 2021-07-03 11:45:40 --> Loader Class Initialized
INFO - 2021-07-03 11:45:40 --> Helper loaded: basic_helper
INFO - 2021-07-03 11:45:40 --> Helper loaded: url_helper
INFO - 2021-07-03 11:45:40 --> Helper loaded: file_helper
INFO - 2021-07-03 11:45:40 --> Helper loaded: form_helper
INFO - 2021-07-03 11:45:40 --> Helper loaded: cookie_helper
INFO - 2021-07-03 11:45:40 --> Helper loaded: security_helper
INFO - 2021-07-03 11:45:40 --> Helper loaded: directory_helper
INFO - 2021-07-03 11:45:40 --> Helper loaded: language_helper
INFO - 2021-07-03 11:45:40 --> Helper loaded: general_helper
INFO - 2021-07-03 11:45:40 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 11:45:40 --> Database Driver Class Initialized
DEBUG - 2021-07-03 11:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 11:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 11:45:40 --> Parser Class Initialized
INFO - 2021-07-03 11:45:40 --> Form Validation Class Initialized
INFO - 2021-07-03 11:45:40 --> Upload Class Initialized
INFO - 2021-07-03 11:45:40 --> Email Class Initialized
INFO - 2021-07-03 11:45:40 --> MY_Model class loaded
INFO - 2021-07-03 11:45:40 --> Model "Users_model" initialized
INFO - 2021-07-03 11:45:40 --> Model "Settings_model" initialized
INFO - 2021-07-03 11:45:40 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 11:45:40 --> Model "Permissions_model" initialized
INFO - 2021-07-03 11:45:40 --> Model "Roles_model" initialized
INFO - 2021-07-03 11:45:40 --> Model "Activity_model" initialized
INFO - 2021-07-03 11:45:40 --> Model "Templates_model" initialized
INFO - 2021-07-03 11:45:40 --> Database Driver Class Initialized
INFO - 2021-07-03 11:45:40 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 11:45:40 --> Controller Class Initialized
ERROR - 2021-07-03 14:45:40 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 14:45:40 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-03 14:45:40 --> Final output sent to browser
DEBUG - 2021-07-03 14:45:40 --> Total execution time: 0.1308
INFO - 2021-07-03 11:45:41 --> Config Class Initialized
INFO - 2021-07-03 11:45:41 --> Hooks Class Initialized
DEBUG - 2021-07-03 11:45:41 --> UTF-8 Support Enabled
INFO - 2021-07-03 11:45:41 --> Utf8 Class Initialized
INFO - 2021-07-03 11:45:41 --> URI Class Initialized
INFO - 2021-07-03 11:45:41 --> Router Class Initialized
INFO - 2021-07-03 11:45:41 --> Output Class Initialized
INFO - 2021-07-03 11:45:41 --> Security Class Initialized
DEBUG - 2021-07-03 11:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 11:45:41 --> Input Class Initialized
INFO - 2021-07-03 11:45:41 --> Language Class Initialized
INFO - 2021-07-03 11:45:41 --> Loader Class Initialized
INFO - 2021-07-03 11:45:41 --> Helper loaded: basic_helper
INFO - 2021-07-03 11:45:41 --> Helper loaded: url_helper
INFO - 2021-07-03 11:45:41 --> Helper loaded: file_helper
INFO - 2021-07-03 11:45:41 --> Helper loaded: form_helper
INFO - 2021-07-03 11:45:41 --> Helper loaded: cookie_helper
INFO - 2021-07-03 11:45:41 --> Helper loaded: security_helper
INFO - 2021-07-03 11:45:41 --> Helper loaded: directory_helper
INFO - 2021-07-03 11:45:41 --> Helper loaded: language_helper
INFO - 2021-07-03 11:45:41 --> Helper loaded: general_helper
INFO - 2021-07-03 11:45:41 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 11:45:41 --> Database Driver Class Initialized
DEBUG - 2021-07-03 11:45:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 11:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 11:45:41 --> Parser Class Initialized
INFO - 2021-07-03 11:45:41 --> Form Validation Class Initialized
INFO - 2021-07-03 11:45:41 --> Upload Class Initialized
INFO - 2021-07-03 11:45:41 --> Email Class Initialized
INFO - 2021-07-03 11:45:41 --> MY_Model class loaded
INFO - 2021-07-03 11:45:41 --> Model "Users_model" initialized
INFO - 2021-07-03 11:45:41 --> Model "Settings_model" initialized
INFO - 2021-07-03 11:45:41 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 11:45:41 --> Model "Permissions_model" initialized
INFO - 2021-07-03 11:45:41 --> Model "Roles_model" initialized
INFO - 2021-07-03 11:45:41 --> Model "Activity_model" initialized
INFO - 2021-07-03 11:45:41 --> Model "Templates_model" initialized
INFO - 2021-07-03 11:45:41 --> Database Driver Class Initialized
INFO - 2021-07-03 11:45:41 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 11:45:41 --> Controller Class Initialized
ERROR - 2021-07-03 14:45:41 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 14:45:41 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-03 14:45:41 --> Final output sent to browser
DEBUG - 2021-07-03 14:45:41 --> Total execution time: 0.1376
INFO - 2021-07-03 11:45:54 --> Config Class Initialized
INFO - 2021-07-03 11:45:54 --> Hooks Class Initialized
DEBUG - 2021-07-03 11:45:54 --> UTF-8 Support Enabled
INFO - 2021-07-03 11:45:54 --> Utf8 Class Initialized
INFO - 2021-07-03 11:45:54 --> URI Class Initialized
INFO - 2021-07-03 11:45:54 --> Router Class Initialized
INFO - 2021-07-03 11:45:54 --> Output Class Initialized
INFO - 2021-07-03 11:45:54 --> Security Class Initialized
DEBUG - 2021-07-03 11:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 11:45:54 --> Input Class Initialized
INFO - 2021-07-03 11:45:54 --> Language Class Initialized
INFO - 2021-07-03 11:45:54 --> Loader Class Initialized
INFO - 2021-07-03 11:45:54 --> Helper loaded: basic_helper
INFO - 2021-07-03 11:45:54 --> Helper loaded: url_helper
INFO - 2021-07-03 11:45:54 --> Helper loaded: file_helper
INFO - 2021-07-03 11:45:54 --> Helper loaded: form_helper
INFO - 2021-07-03 11:45:54 --> Helper loaded: cookie_helper
INFO - 2021-07-03 11:45:54 --> Helper loaded: security_helper
INFO - 2021-07-03 11:45:54 --> Helper loaded: directory_helper
INFO - 2021-07-03 11:45:54 --> Helper loaded: language_helper
INFO - 2021-07-03 11:45:54 --> Helper loaded: general_helper
INFO - 2021-07-03 11:45:54 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 11:45:54 --> Database Driver Class Initialized
DEBUG - 2021-07-03 11:45:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 11:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 11:45:54 --> Parser Class Initialized
INFO - 2021-07-03 11:45:54 --> Form Validation Class Initialized
INFO - 2021-07-03 11:45:54 --> Upload Class Initialized
INFO - 2021-07-03 11:45:54 --> Email Class Initialized
INFO - 2021-07-03 11:45:54 --> MY_Model class loaded
INFO - 2021-07-03 11:45:54 --> Model "Users_model" initialized
INFO - 2021-07-03 11:45:54 --> Model "Settings_model" initialized
INFO - 2021-07-03 11:45:54 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 11:45:54 --> Model "Permissions_model" initialized
INFO - 2021-07-03 11:45:54 --> Model "Roles_model" initialized
INFO - 2021-07-03 11:45:54 --> Model "Activity_model" initialized
INFO - 2021-07-03 11:45:54 --> Model "Templates_model" initialized
INFO - 2021-07-03 11:45:54 --> Database Driver Class Initialized
INFO - 2021-07-03 11:45:54 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 11:45:54 --> Controller Class Initialized
ERROR - 2021-07-03 14:45:54 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-03 14:45:54 --> Invalid query: 
INFO - 2021-07-03 14:45:54 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-03 14:45:54 --> Final output sent to browser
DEBUG - 2021-07-03 14:45:54 --> Total execution time: 0.1776
INFO - 2021-07-03 11:45:58 --> Config Class Initialized
INFO - 2021-07-03 11:45:58 --> Hooks Class Initialized
DEBUG - 2021-07-03 11:45:58 --> UTF-8 Support Enabled
INFO - 2021-07-03 11:45:58 --> Utf8 Class Initialized
INFO - 2021-07-03 11:45:58 --> URI Class Initialized
INFO - 2021-07-03 11:45:58 --> Router Class Initialized
INFO - 2021-07-03 11:45:58 --> Output Class Initialized
INFO - 2021-07-03 11:45:58 --> Security Class Initialized
DEBUG - 2021-07-03 11:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 11:45:58 --> Input Class Initialized
INFO - 2021-07-03 11:45:58 --> Language Class Initialized
INFO - 2021-07-03 11:45:58 --> Loader Class Initialized
INFO - 2021-07-03 11:45:58 --> Helper loaded: basic_helper
INFO - 2021-07-03 11:45:58 --> Helper loaded: url_helper
INFO - 2021-07-03 11:45:58 --> Helper loaded: file_helper
INFO - 2021-07-03 11:45:58 --> Helper loaded: form_helper
INFO - 2021-07-03 11:45:58 --> Helper loaded: cookie_helper
INFO - 2021-07-03 11:45:58 --> Helper loaded: security_helper
INFO - 2021-07-03 11:45:58 --> Helper loaded: directory_helper
INFO - 2021-07-03 11:45:58 --> Helper loaded: language_helper
INFO - 2021-07-03 11:45:58 --> Helper loaded: general_helper
INFO - 2021-07-03 11:45:58 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 11:45:58 --> Database Driver Class Initialized
DEBUG - 2021-07-03 11:45:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 11:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 11:45:58 --> Parser Class Initialized
INFO - 2021-07-03 11:45:58 --> Form Validation Class Initialized
INFO - 2021-07-03 11:45:58 --> Upload Class Initialized
INFO - 2021-07-03 11:45:58 --> Email Class Initialized
INFO - 2021-07-03 11:45:58 --> MY_Model class loaded
INFO - 2021-07-03 11:45:58 --> Model "Users_model" initialized
INFO - 2021-07-03 11:45:58 --> Model "Settings_model" initialized
INFO - 2021-07-03 11:45:58 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 11:45:58 --> Model "Permissions_model" initialized
INFO - 2021-07-03 11:45:58 --> Model "Roles_model" initialized
INFO - 2021-07-03 11:45:58 --> Model "Activity_model" initialized
INFO - 2021-07-03 11:45:58 --> Model "Templates_model" initialized
INFO - 2021-07-03 11:45:58 --> Database Driver Class Initialized
INFO - 2021-07-03 11:45:58 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 11:45:58 --> Controller Class Initialized
ERROR - 2021-07-03 14:45:58 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 14:45:58 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-03 14:45:58 --> Final output sent to browser
DEBUG - 2021-07-03 14:45:58 --> Total execution time: 0.1284
INFO - 2021-07-03 11:46:00 --> Config Class Initialized
INFO - 2021-07-03 11:46:00 --> Hooks Class Initialized
DEBUG - 2021-07-03 11:46:00 --> UTF-8 Support Enabled
INFO - 2021-07-03 11:46:00 --> Utf8 Class Initialized
INFO - 2021-07-03 11:46:00 --> URI Class Initialized
INFO - 2021-07-03 11:46:00 --> Router Class Initialized
INFO - 2021-07-03 11:46:00 --> Output Class Initialized
INFO - 2021-07-03 11:46:00 --> Security Class Initialized
DEBUG - 2021-07-03 11:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 11:46:00 --> Input Class Initialized
INFO - 2021-07-03 11:46:00 --> Language Class Initialized
INFO - 2021-07-03 11:46:00 --> Loader Class Initialized
INFO - 2021-07-03 11:46:00 --> Helper loaded: basic_helper
INFO - 2021-07-03 11:46:00 --> Helper loaded: url_helper
INFO - 2021-07-03 11:46:00 --> Helper loaded: file_helper
INFO - 2021-07-03 11:46:00 --> Helper loaded: form_helper
INFO - 2021-07-03 11:46:00 --> Helper loaded: cookie_helper
INFO - 2021-07-03 11:46:00 --> Helper loaded: security_helper
INFO - 2021-07-03 11:46:00 --> Helper loaded: directory_helper
INFO - 2021-07-03 11:46:00 --> Helper loaded: language_helper
INFO - 2021-07-03 11:46:00 --> Helper loaded: general_helper
INFO - 2021-07-03 11:46:00 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 11:46:00 --> Database Driver Class Initialized
DEBUG - 2021-07-03 11:46:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 11:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 11:46:00 --> Parser Class Initialized
INFO - 2021-07-03 11:46:00 --> Form Validation Class Initialized
INFO - 2021-07-03 11:46:00 --> Upload Class Initialized
INFO - 2021-07-03 11:46:00 --> Email Class Initialized
INFO - 2021-07-03 11:46:00 --> MY_Model class loaded
INFO - 2021-07-03 11:46:00 --> Model "Users_model" initialized
INFO - 2021-07-03 11:46:00 --> Model "Settings_model" initialized
INFO - 2021-07-03 11:46:00 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 11:46:00 --> Model "Permissions_model" initialized
INFO - 2021-07-03 11:46:00 --> Model "Roles_model" initialized
INFO - 2021-07-03 11:46:00 --> Model "Activity_model" initialized
INFO - 2021-07-03 11:46:00 --> Model "Templates_model" initialized
INFO - 2021-07-03 11:46:00 --> Database Driver Class Initialized
INFO - 2021-07-03 11:46:00 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 11:46:00 --> Controller Class Initialized
ERROR - 2021-07-03 14:46:00 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 14:46:00 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-03 14:46:00 --> Final output sent to browser
DEBUG - 2021-07-03 14:46:00 --> Total execution time: 0.1400
INFO - 2021-07-03 11:46:36 --> Config Class Initialized
INFO - 2021-07-03 11:46:36 --> Hooks Class Initialized
DEBUG - 2021-07-03 11:46:36 --> UTF-8 Support Enabled
INFO - 2021-07-03 11:46:36 --> Utf8 Class Initialized
INFO - 2021-07-03 11:46:36 --> URI Class Initialized
DEBUG - 2021-07-03 11:46:36 --> No URI present. Default controller set.
INFO - 2021-07-03 11:46:36 --> Router Class Initialized
INFO - 2021-07-03 11:46:36 --> Output Class Initialized
INFO - 2021-07-03 11:46:36 --> Security Class Initialized
DEBUG - 2021-07-03 11:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 11:46:36 --> Input Class Initialized
INFO - 2021-07-03 11:46:36 --> Language Class Initialized
INFO - 2021-07-03 11:46:36 --> Loader Class Initialized
INFO - 2021-07-03 11:46:36 --> Helper loaded: basic_helper
INFO - 2021-07-03 11:46:36 --> Helper loaded: url_helper
INFO - 2021-07-03 11:46:36 --> Helper loaded: file_helper
INFO - 2021-07-03 11:46:36 --> Helper loaded: form_helper
INFO - 2021-07-03 11:46:36 --> Helper loaded: cookie_helper
INFO - 2021-07-03 11:46:36 --> Helper loaded: security_helper
INFO - 2021-07-03 11:46:36 --> Helper loaded: directory_helper
INFO - 2021-07-03 11:46:36 --> Helper loaded: language_helper
INFO - 2021-07-03 11:46:36 --> Helper loaded: general_helper
INFO - 2021-07-03 11:46:36 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 11:46:36 --> Database Driver Class Initialized
DEBUG - 2021-07-03 11:46:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 11:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 11:46:36 --> Parser Class Initialized
INFO - 2021-07-03 11:46:36 --> Form Validation Class Initialized
INFO - 2021-07-03 11:46:36 --> Upload Class Initialized
INFO - 2021-07-03 11:46:36 --> Email Class Initialized
INFO - 2021-07-03 11:46:36 --> MY_Model class loaded
INFO - 2021-07-03 11:46:36 --> Model "Users_model" initialized
INFO - 2021-07-03 11:46:36 --> Model "Settings_model" initialized
INFO - 2021-07-03 11:46:36 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 11:46:36 --> Model "Permissions_model" initialized
INFO - 2021-07-03 11:46:36 --> Model "Roles_model" initialized
INFO - 2021-07-03 11:46:36 --> Model "Activity_model" initialized
INFO - 2021-07-03 11:46:36 --> Model "Templates_model" initialized
INFO - 2021-07-03 11:46:36 --> Database Driver Class Initialized
INFO - 2021-07-03 11:46:36 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 11:46:36 --> Controller Class Initialized
INFO - 2021-07-03 11:46:36 --> Config Class Initialized
INFO - 2021-07-03 11:46:36 --> Hooks Class Initialized
DEBUG - 2021-07-03 11:46:36 --> UTF-8 Support Enabled
INFO - 2021-07-03 11:46:36 --> Utf8 Class Initialized
INFO - 2021-07-03 11:46:36 --> URI Class Initialized
INFO - 2021-07-03 11:46:36 --> Router Class Initialized
INFO - 2021-07-03 11:46:36 --> Output Class Initialized
INFO - 2021-07-03 11:46:36 --> Security Class Initialized
DEBUG - 2021-07-03 11:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 11:46:36 --> Input Class Initialized
INFO - 2021-07-03 11:46:36 --> Language Class Initialized
INFO - 2021-07-03 11:46:36 --> Loader Class Initialized
INFO - 2021-07-03 11:46:36 --> Helper loaded: basic_helper
INFO - 2021-07-03 11:46:36 --> Helper loaded: url_helper
INFO - 2021-07-03 11:46:36 --> Helper loaded: file_helper
INFO - 2021-07-03 11:46:36 --> Helper loaded: form_helper
INFO - 2021-07-03 11:46:36 --> Helper loaded: cookie_helper
INFO - 2021-07-03 11:46:36 --> Helper loaded: security_helper
INFO - 2021-07-03 11:46:36 --> Helper loaded: directory_helper
INFO - 2021-07-03 11:46:36 --> Helper loaded: language_helper
INFO - 2021-07-03 11:46:36 --> Helper loaded: general_helper
INFO - 2021-07-03 11:46:36 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 11:46:36 --> Database Driver Class Initialized
DEBUG - 2021-07-03 11:46:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 11:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 11:46:36 --> Parser Class Initialized
INFO - 2021-07-03 11:46:36 --> Form Validation Class Initialized
INFO - 2021-07-03 11:46:36 --> Upload Class Initialized
INFO - 2021-07-03 11:46:36 --> Email Class Initialized
INFO - 2021-07-03 11:46:36 --> MY_Model class loaded
INFO - 2021-07-03 11:46:36 --> Model "Users_model" initialized
INFO - 2021-07-03 11:46:36 --> Model "Settings_model" initialized
INFO - 2021-07-03 11:46:36 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 11:46:36 --> Model "Permissions_model" initialized
INFO - 2021-07-03 11:46:36 --> Model "Roles_model" initialized
INFO - 2021-07-03 11:46:36 --> Model "Activity_model" initialized
INFO - 2021-07-03 11:46:36 --> Model "Templates_model" initialized
INFO - 2021-07-03 11:46:36 --> Database Driver Class Initialized
INFO - 2021-07-03 11:46:36 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 11:46:36 --> Controller Class Initialized
INFO - 2021-07-03 14:46:36 --> File loaded: C:\wamp64\www\crm\application\views\account/login.php
INFO - 2021-07-03 14:46:36 --> Final output sent to browser
DEBUG - 2021-07-03 14:46:36 --> Total execution time: 0.0450
INFO - 2021-07-03 11:46:36 --> Config Class Initialized
INFO - 2021-07-03 11:46:36 --> Hooks Class Initialized
DEBUG - 2021-07-03 11:46:36 --> UTF-8 Support Enabled
INFO - 2021-07-03 11:46:36 --> Utf8 Class Initialized
INFO - 2021-07-03 11:46:36 --> URI Class Initialized
INFO - 2021-07-03 11:46:36 --> Router Class Initialized
INFO - 2021-07-03 11:46:36 --> Config Class Initialized
INFO - 2021-07-03 11:46:36 --> Hooks Class Initialized
INFO - 2021-07-03 11:46:36 --> Output Class Initialized
DEBUG - 2021-07-03 11:46:36 --> UTF-8 Support Enabled
INFO - 2021-07-03 11:46:36 --> Security Class Initialized
INFO - 2021-07-03 11:46:36 --> Utf8 Class Initialized
DEBUG - 2021-07-03 11:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 11:46:36 --> URI Class Initialized
INFO - 2021-07-03 11:46:36 --> Input Class Initialized
INFO - 2021-07-03 11:46:36 --> Language Class Initialized
INFO - 2021-07-03 11:46:36 --> Router Class Initialized
ERROR - 2021-07-03 11:46:36 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-03 11:46:36 --> Output Class Initialized
INFO - 2021-07-03 11:46:36 --> Security Class Initialized
DEBUG - 2021-07-03 11:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 11:46:36 --> Input Class Initialized
INFO - 2021-07-03 11:46:36 --> Language Class Initialized
ERROR - 2021-07-03 11:46:36 --> 404 Page Not Found: Assets/jquery
INFO - 2021-07-03 11:46:38 --> Config Class Initialized
INFO - 2021-07-03 11:46:38 --> Hooks Class Initialized
DEBUG - 2021-07-03 11:46:38 --> UTF-8 Support Enabled
INFO - 2021-07-03 11:46:38 --> Utf8 Class Initialized
INFO - 2021-07-03 11:46:38 --> URI Class Initialized
INFO - 2021-07-03 11:46:38 --> Router Class Initialized
INFO - 2021-07-03 11:46:38 --> Output Class Initialized
INFO - 2021-07-03 11:46:38 --> Security Class Initialized
DEBUG - 2021-07-03 11:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 11:46:38 --> Input Class Initialized
INFO - 2021-07-03 11:46:38 --> Language Class Initialized
ERROR - 2021-07-03 11:46:38 --> 404 Page Not Found: Faviconico/index
INFO - 2021-07-03 11:47:27 --> Config Class Initialized
INFO - 2021-07-03 11:47:27 --> Hooks Class Initialized
DEBUG - 2021-07-03 11:47:27 --> UTF-8 Support Enabled
INFO - 2021-07-03 11:47:27 --> Utf8 Class Initialized
INFO - 2021-07-03 11:47:27 --> URI Class Initialized
DEBUG - 2021-07-03 11:47:27 --> No URI present. Default controller set.
INFO - 2021-07-03 11:47:27 --> Router Class Initialized
INFO - 2021-07-03 11:47:27 --> Output Class Initialized
INFO - 2021-07-03 11:47:27 --> Security Class Initialized
DEBUG - 2021-07-03 11:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 11:47:27 --> Input Class Initialized
INFO - 2021-07-03 11:47:27 --> Language Class Initialized
INFO - 2021-07-03 11:47:27 --> Loader Class Initialized
INFO - 2021-07-03 11:47:27 --> Helper loaded: basic_helper
INFO - 2021-07-03 11:47:27 --> Helper loaded: url_helper
INFO - 2021-07-03 11:47:27 --> Helper loaded: file_helper
INFO - 2021-07-03 11:47:27 --> Helper loaded: form_helper
INFO - 2021-07-03 11:47:27 --> Helper loaded: cookie_helper
INFO - 2021-07-03 11:47:27 --> Helper loaded: security_helper
INFO - 2021-07-03 11:47:27 --> Helper loaded: directory_helper
INFO - 2021-07-03 11:47:27 --> Helper loaded: language_helper
INFO - 2021-07-03 11:47:27 --> Helper loaded: general_helper
INFO - 2021-07-03 11:47:27 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 11:47:27 --> Database Driver Class Initialized
DEBUG - 2021-07-03 11:47:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 11:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 11:47:27 --> Parser Class Initialized
INFO - 2021-07-03 11:47:27 --> Form Validation Class Initialized
INFO - 2021-07-03 11:47:27 --> Upload Class Initialized
INFO - 2021-07-03 11:47:27 --> Email Class Initialized
INFO - 2021-07-03 11:47:27 --> MY_Model class loaded
INFO - 2021-07-03 11:47:27 --> Model "Users_model" initialized
INFO - 2021-07-03 11:47:27 --> Model "Settings_model" initialized
INFO - 2021-07-03 11:47:27 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 11:47:27 --> Model "Permissions_model" initialized
INFO - 2021-07-03 11:47:27 --> Model "Roles_model" initialized
INFO - 2021-07-03 11:47:27 --> Model "Activity_model" initialized
INFO - 2021-07-03 11:47:27 --> Model "Templates_model" initialized
INFO - 2021-07-03 11:47:27 --> Database Driver Class Initialized
INFO - 2021-07-03 11:47:27 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 11:47:27 --> Controller Class Initialized
INFO - 2021-07-03 11:47:27 --> Config Class Initialized
INFO - 2021-07-03 11:47:27 --> Hooks Class Initialized
DEBUG - 2021-07-03 11:47:27 --> UTF-8 Support Enabled
INFO - 2021-07-03 11:47:27 --> Utf8 Class Initialized
INFO - 2021-07-03 11:47:27 --> URI Class Initialized
INFO - 2021-07-03 11:47:27 --> Router Class Initialized
INFO - 2021-07-03 11:47:27 --> Output Class Initialized
INFO - 2021-07-03 11:47:27 --> Security Class Initialized
DEBUG - 2021-07-03 11:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 11:47:27 --> Input Class Initialized
INFO - 2021-07-03 11:47:27 --> Language Class Initialized
INFO - 2021-07-03 11:47:27 --> Loader Class Initialized
INFO - 2021-07-03 11:47:27 --> Helper loaded: basic_helper
INFO - 2021-07-03 11:47:27 --> Helper loaded: url_helper
INFO - 2021-07-03 11:47:27 --> Helper loaded: file_helper
INFO - 2021-07-03 11:47:27 --> Helper loaded: form_helper
INFO - 2021-07-03 11:47:27 --> Config Class Initialized
INFO - 2021-07-03 11:47:27 --> Helper loaded: cookie_helper
INFO - 2021-07-03 11:47:27 --> Hooks Class Initialized
INFO - 2021-07-03 11:47:27 --> Helper loaded: security_helper
DEBUG - 2021-07-03 11:47:27 --> UTF-8 Support Enabled
INFO - 2021-07-03 11:47:27 --> Helper loaded: directory_helper
INFO - 2021-07-03 11:47:27 --> Utf8 Class Initialized
INFO - 2021-07-03 11:47:27 --> Helper loaded: language_helper
INFO - 2021-07-03 11:47:27 --> URI Class Initialized
INFO - 2021-07-03 11:47:27 --> Helper loaded: general_helper
INFO - 2021-07-03 11:47:27 --> Router Class Initialized
INFO - 2021-07-03 11:47:27 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 11:47:27 --> Output Class Initialized
INFO - 2021-07-03 11:47:27 --> Database Driver Class Initialized
INFO - 2021-07-03 11:47:27 --> Security Class Initialized
DEBUG - 2021-07-03 11:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 11:47:27 --> Input Class Initialized
INFO - 2021-07-03 11:47:27 --> Language Class Initialized
ERROR - 2021-07-03 11:47:27 --> 404 Page Not Found: Faviconico/index
DEBUG - 2021-07-03 11:47:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 11:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 11:47:27 --> Parser Class Initialized
INFO - 2021-07-03 11:47:27 --> Form Validation Class Initialized
INFO - 2021-07-03 11:47:27 --> Upload Class Initialized
INFO - 2021-07-03 11:47:27 --> Email Class Initialized
INFO - 2021-07-03 11:47:27 --> MY_Model class loaded
INFO - 2021-07-03 11:47:27 --> Model "Users_model" initialized
INFO - 2021-07-03 11:47:27 --> Model "Settings_model" initialized
INFO - 2021-07-03 11:47:27 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 11:47:27 --> Model "Permissions_model" initialized
INFO - 2021-07-03 11:47:27 --> Model "Roles_model" initialized
INFO - 2021-07-03 11:47:27 --> Model "Activity_model" initialized
INFO - 2021-07-03 11:47:27 --> Model "Templates_model" initialized
INFO - 2021-07-03 11:47:27 --> Database Driver Class Initialized
INFO - 2021-07-03 11:47:27 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 11:47:27 --> Controller Class Initialized
INFO - 2021-07-03 14:47:27 --> File loaded: C:\wamp64\www\crm\application\views\account/login.php
INFO - 2021-07-03 14:47:27 --> Final output sent to browser
DEBUG - 2021-07-03 14:47:27 --> Total execution time: 0.0465
INFO - 2021-07-03 11:47:27 --> Config Class Initialized
INFO - 2021-07-03 11:47:27 --> Hooks Class Initialized
DEBUG - 2021-07-03 11:47:27 --> UTF-8 Support Enabled
INFO - 2021-07-03 11:47:27 --> Config Class Initialized
INFO - 2021-07-03 11:47:27 --> Utf8 Class Initialized
INFO - 2021-07-03 11:47:27 --> Hooks Class Initialized
INFO - 2021-07-03 11:47:27 --> URI Class Initialized
DEBUG - 2021-07-03 11:47:27 --> UTF-8 Support Enabled
INFO - 2021-07-03 11:47:27 --> Utf8 Class Initialized
INFO - 2021-07-03 11:47:27 --> Router Class Initialized
INFO - 2021-07-03 11:47:27 --> URI Class Initialized
INFO - 2021-07-03 11:47:27 --> Output Class Initialized
INFO - 2021-07-03 11:47:27 --> Router Class Initialized
INFO - 2021-07-03 11:47:27 --> Security Class Initialized
INFO - 2021-07-03 11:47:27 --> Output Class Initialized
DEBUG - 2021-07-03 11:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 11:47:27 --> Input Class Initialized
INFO - 2021-07-03 11:47:27 --> Security Class Initialized
INFO - 2021-07-03 11:47:27 --> Language Class Initialized
DEBUG - 2021-07-03 11:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 11:47:27 --> Input Class Initialized
ERROR - 2021-07-03 11:47:27 --> 404 Page Not Found: Assets/jquery
INFO - 2021-07-03 11:47:27 --> Language Class Initialized
ERROR - 2021-07-03 11:47:27 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-03 11:47:56 --> Config Class Initialized
INFO - 2021-07-03 11:47:56 --> Hooks Class Initialized
DEBUG - 2021-07-03 11:47:56 --> UTF-8 Support Enabled
INFO - 2021-07-03 11:47:56 --> Utf8 Class Initialized
INFO - 2021-07-03 11:47:56 --> URI Class Initialized
DEBUG - 2021-07-03 11:47:56 --> No URI present. Default controller set.
INFO - 2021-07-03 11:47:56 --> Router Class Initialized
INFO - 2021-07-03 11:47:56 --> Output Class Initialized
INFO - 2021-07-03 11:47:56 --> Security Class Initialized
DEBUG - 2021-07-03 11:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 11:47:56 --> Input Class Initialized
INFO - 2021-07-03 11:47:56 --> Language Class Initialized
INFO - 2021-07-03 11:47:56 --> Loader Class Initialized
INFO - 2021-07-03 11:47:56 --> Helper loaded: basic_helper
INFO - 2021-07-03 11:47:56 --> Helper loaded: url_helper
INFO - 2021-07-03 11:47:56 --> Helper loaded: file_helper
INFO - 2021-07-03 11:47:56 --> Helper loaded: form_helper
INFO - 2021-07-03 11:47:56 --> Helper loaded: cookie_helper
INFO - 2021-07-03 11:47:56 --> Helper loaded: security_helper
INFO - 2021-07-03 11:47:56 --> Helper loaded: directory_helper
INFO - 2021-07-03 11:47:56 --> Helper loaded: language_helper
INFO - 2021-07-03 11:47:56 --> Helper loaded: general_helper
INFO - 2021-07-03 11:47:56 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 11:47:56 --> Database Driver Class Initialized
DEBUG - 2021-07-03 11:47:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 11:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 11:47:56 --> Parser Class Initialized
INFO - 2021-07-03 11:47:56 --> Form Validation Class Initialized
INFO - 2021-07-03 11:47:56 --> Upload Class Initialized
INFO - 2021-07-03 11:47:56 --> Email Class Initialized
INFO - 2021-07-03 11:47:56 --> MY_Model class loaded
INFO - 2021-07-03 11:47:56 --> Model "Users_model" initialized
INFO - 2021-07-03 11:47:56 --> Model "Settings_model" initialized
INFO - 2021-07-03 11:47:56 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 11:47:56 --> Model "Permissions_model" initialized
INFO - 2021-07-03 11:47:56 --> Model "Roles_model" initialized
INFO - 2021-07-03 11:47:56 --> Model "Activity_model" initialized
INFO - 2021-07-03 11:47:56 --> Model "Templates_model" initialized
INFO - 2021-07-03 11:47:56 --> Database Driver Class Initialized
INFO - 2021-07-03 11:47:56 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 11:47:56 --> Controller Class Initialized
ERROR - 2021-07-03 14:47:56 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 14:47:56 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-03 14:47:56 --> Final output sent to browser
DEBUG - 2021-07-03 14:47:56 --> Total execution time: 0.1263
INFO - 2021-07-03 11:47:57 --> Config Class Initialized
INFO - 2021-07-03 11:47:57 --> Hooks Class Initialized
DEBUG - 2021-07-03 11:47:57 --> UTF-8 Support Enabled
INFO - 2021-07-03 11:47:57 --> Utf8 Class Initialized
INFO - 2021-07-03 11:47:57 --> URI Class Initialized
INFO - 2021-07-03 11:47:57 --> Router Class Initialized
INFO - 2021-07-03 11:47:57 --> Output Class Initialized
INFO - 2021-07-03 11:47:57 --> Security Class Initialized
DEBUG - 2021-07-03 11:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 11:47:57 --> Input Class Initialized
INFO - 2021-07-03 11:47:57 --> Language Class Initialized
ERROR - 2021-07-03 11:47:57 --> 404 Page Not Found: Faviconico/index
INFO - 2021-07-03 11:48:42 --> Config Class Initialized
INFO - 2021-07-03 11:48:42 --> Hooks Class Initialized
DEBUG - 2021-07-03 11:48:42 --> UTF-8 Support Enabled
INFO - 2021-07-03 11:48:42 --> Utf8 Class Initialized
INFO - 2021-07-03 11:48:42 --> URI Class Initialized
DEBUG - 2021-07-03 11:48:42 --> No URI present. Default controller set.
INFO - 2021-07-03 11:48:42 --> Router Class Initialized
INFO - 2021-07-03 11:48:42 --> Output Class Initialized
INFO - 2021-07-03 11:48:42 --> Security Class Initialized
DEBUG - 2021-07-03 11:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 11:48:42 --> Input Class Initialized
INFO - 2021-07-03 11:48:42 --> Language Class Initialized
INFO - 2021-07-03 11:48:42 --> Loader Class Initialized
INFO - 2021-07-03 11:48:42 --> Helper loaded: basic_helper
INFO - 2021-07-03 11:48:42 --> Helper loaded: url_helper
INFO - 2021-07-03 11:48:42 --> Helper loaded: file_helper
INFO - 2021-07-03 11:48:42 --> Helper loaded: form_helper
INFO - 2021-07-03 11:48:42 --> Helper loaded: cookie_helper
INFO - 2021-07-03 11:48:42 --> Helper loaded: security_helper
INFO - 2021-07-03 11:48:42 --> Helper loaded: directory_helper
INFO - 2021-07-03 11:48:42 --> Helper loaded: language_helper
INFO - 2021-07-03 11:48:42 --> Helper loaded: general_helper
INFO - 2021-07-03 11:48:42 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 11:48:42 --> Database Driver Class Initialized
DEBUG - 2021-07-03 11:48:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 11:48:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 11:48:42 --> Parser Class Initialized
INFO - 2021-07-03 11:48:42 --> Form Validation Class Initialized
INFO - 2021-07-03 11:48:42 --> Upload Class Initialized
INFO - 2021-07-03 11:48:42 --> Email Class Initialized
INFO - 2021-07-03 11:48:42 --> MY_Model class loaded
INFO - 2021-07-03 11:48:42 --> Model "Users_model" initialized
INFO - 2021-07-03 11:48:42 --> Model "Settings_model" initialized
INFO - 2021-07-03 11:48:42 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 11:48:42 --> Model "Permissions_model" initialized
INFO - 2021-07-03 11:48:42 --> Model "Roles_model" initialized
INFO - 2021-07-03 11:48:42 --> Model "Activity_model" initialized
INFO - 2021-07-03 11:48:42 --> Model "Templates_model" initialized
INFO - 2021-07-03 11:48:42 --> Database Driver Class Initialized
INFO - 2021-07-03 11:48:42 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 11:48:42 --> Controller Class Initialized
ERROR - 2021-07-03 14:48:42 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 14:48:42 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-03 14:48:42 --> Final output sent to browser
DEBUG - 2021-07-03 14:48:42 --> Total execution time: 0.1364
INFO - 2021-07-03 11:48:43 --> Config Class Initialized
INFO - 2021-07-03 11:48:43 --> Hooks Class Initialized
DEBUG - 2021-07-03 11:48:43 --> UTF-8 Support Enabled
INFO - 2021-07-03 11:48:43 --> Utf8 Class Initialized
INFO - 2021-07-03 11:48:43 --> URI Class Initialized
INFO - 2021-07-03 11:48:43 --> Router Class Initialized
INFO - 2021-07-03 11:48:43 --> Output Class Initialized
INFO - 2021-07-03 11:48:43 --> Security Class Initialized
DEBUG - 2021-07-03 11:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 11:48:43 --> Input Class Initialized
INFO - 2021-07-03 11:48:43 --> Language Class Initialized
ERROR - 2021-07-03 11:48:43 --> 404 Page Not Found: Faviconico/index
INFO - 2021-07-03 11:48:53 --> Config Class Initialized
INFO - 2021-07-03 11:48:53 --> Hooks Class Initialized
DEBUG - 2021-07-03 11:48:53 --> UTF-8 Support Enabled
INFO - 2021-07-03 11:48:53 --> Utf8 Class Initialized
INFO - 2021-07-03 11:48:53 --> URI Class Initialized
DEBUG - 2021-07-03 11:48:53 --> No URI present. Default controller set.
INFO - 2021-07-03 11:48:53 --> Router Class Initialized
INFO - 2021-07-03 11:48:53 --> Output Class Initialized
INFO - 2021-07-03 11:48:53 --> Security Class Initialized
DEBUG - 2021-07-03 11:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 11:48:53 --> Input Class Initialized
INFO - 2021-07-03 11:48:53 --> Language Class Initialized
INFO - 2021-07-03 11:48:53 --> Loader Class Initialized
INFO - 2021-07-03 11:48:53 --> Helper loaded: basic_helper
INFO - 2021-07-03 11:48:53 --> Helper loaded: url_helper
INFO - 2021-07-03 11:48:53 --> Helper loaded: file_helper
INFO - 2021-07-03 11:48:53 --> Helper loaded: form_helper
INFO - 2021-07-03 11:48:53 --> Helper loaded: cookie_helper
INFO - 2021-07-03 11:48:53 --> Helper loaded: security_helper
INFO - 2021-07-03 11:48:53 --> Helper loaded: directory_helper
INFO - 2021-07-03 11:48:53 --> Helper loaded: language_helper
INFO - 2021-07-03 11:48:53 --> Helper loaded: general_helper
INFO - 2021-07-03 11:48:53 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 11:48:53 --> Database Driver Class Initialized
DEBUG - 2021-07-03 11:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 11:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 11:48:53 --> Parser Class Initialized
INFO - 2021-07-03 11:48:53 --> Form Validation Class Initialized
INFO - 2021-07-03 11:48:53 --> Upload Class Initialized
INFO - 2021-07-03 11:48:53 --> Email Class Initialized
INFO - 2021-07-03 11:48:53 --> MY_Model class loaded
INFO - 2021-07-03 11:48:53 --> Model "Users_model" initialized
INFO - 2021-07-03 11:48:53 --> Model "Settings_model" initialized
INFO - 2021-07-03 11:48:53 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 11:48:53 --> Model "Permissions_model" initialized
INFO - 2021-07-03 11:48:53 --> Model "Roles_model" initialized
INFO - 2021-07-03 11:48:53 --> Model "Activity_model" initialized
INFO - 2021-07-03 11:48:53 --> Model "Templates_model" initialized
INFO - 2021-07-03 11:48:53 --> Database Driver Class Initialized
INFO - 2021-07-03 11:48:54 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 11:48:54 --> Controller Class Initialized
ERROR - 2021-07-03 14:48:54 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 14:48:54 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-03 14:48:54 --> Final output sent to browser
DEBUG - 2021-07-03 14:48:54 --> Total execution time: 0.1339
INFO - 2021-07-03 11:48:55 --> Config Class Initialized
INFO - 2021-07-03 11:48:55 --> Hooks Class Initialized
DEBUG - 2021-07-03 11:48:55 --> UTF-8 Support Enabled
INFO - 2021-07-03 11:48:55 --> Utf8 Class Initialized
INFO - 2021-07-03 11:48:55 --> URI Class Initialized
INFO - 2021-07-03 11:48:55 --> Router Class Initialized
INFO - 2021-07-03 11:48:55 --> Output Class Initialized
INFO - 2021-07-03 11:48:55 --> Security Class Initialized
DEBUG - 2021-07-03 11:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 11:48:55 --> Input Class Initialized
INFO - 2021-07-03 11:48:55 --> Language Class Initialized
ERROR - 2021-07-03 11:48:55 --> 404 Page Not Found: Faviconico/index
INFO - 2021-07-03 11:48:59 --> Config Class Initialized
INFO - 2021-07-03 11:48:59 --> Hooks Class Initialized
DEBUG - 2021-07-03 11:48:59 --> UTF-8 Support Enabled
INFO - 2021-07-03 11:48:59 --> Utf8 Class Initialized
INFO - 2021-07-03 11:48:59 --> URI Class Initialized
INFO - 2021-07-03 11:48:59 --> Router Class Initialized
INFO - 2021-07-03 11:48:59 --> Output Class Initialized
INFO - 2021-07-03 11:48:59 --> Security Class Initialized
DEBUG - 2021-07-03 11:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 11:48:59 --> Input Class Initialized
INFO - 2021-07-03 11:48:59 --> Language Class Initialized
INFO - 2021-07-03 11:48:59 --> Loader Class Initialized
INFO - 2021-07-03 11:48:59 --> Helper loaded: basic_helper
INFO - 2021-07-03 11:48:59 --> Helper loaded: url_helper
INFO - 2021-07-03 11:48:59 --> Helper loaded: file_helper
INFO - 2021-07-03 11:48:59 --> Helper loaded: form_helper
INFO - 2021-07-03 11:48:59 --> Helper loaded: cookie_helper
INFO - 2021-07-03 11:48:59 --> Helper loaded: security_helper
INFO - 2021-07-03 11:48:59 --> Helper loaded: directory_helper
INFO - 2021-07-03 11:48:59 --> Helper loaded: language_helper
INFO - 2021-07-03 11:48:59 --> Helper loaded: general_helper
INFO - 2021-07-03 11:48:59 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 11:48:59 --> Database Driver Class Initialized
DEBUG - 2021-07-03 11:48:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 11:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 11:48:59 --> Parser Class Initialized
INFO - 2021-07-03 11:48:59 --> Form Validation Class Initialized
INFO - 2021-07-03 11:48:59 --> Upload Class Initialized
INFO - 2021-07-03 11:48:59 --> Email Class Initialized
INFO - 2021-07-03 11:48:59 --> MY_Model class loaded
INFO - 2021-07-03 11:48:59 --> Model "Users_model" initialized
INFO - 2021-07-03 11:48:59 --> Model "Settings_model" initialized
INFO - 2021-07-03 11:48:59 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 11:48:59 --> Model "Permissions_model" initialized
INFO - 2021-07-03 11:48:59 --> Model "Roles_model" initialized
INFO - 2021-07-03 11:48:59 --> Model "Activity_model" initialized
INFO - 2021-07-03 11:48:59 --> Model "Templates_model" initialized
INFO - 2021-07-03 11:48:59 --> Database Driver Class Initialized
INFO - 2021-07-03 11:48:59 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 11:48:59 --> Controller Class Initialized
ERROR - 2021-07-03 14:48:59 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 14:48:59 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-03 14:48:59 --> Final output sent to browser
DEBUG - 2021-07-03 14:48:59 --> Total execution time: 0.2374
INFO - 2021-07-03 11:49:02 --> Config Class Initialized
INFO - 2021-07-03 11:49:02 --> Hooks Class Initialized
DEBUG - 2021-07-03 11:49:02 --> UTF-8 Support Enabled
INFO - 2021-07-03 11:49:02 --> Utf8 Class Initialized
INFO - 2021-07-03 11:49:02 --> URI Class Initialized
INFO - 2021-07-03 11:49:02 --> Router Class Initialized
INFO - 2021-07-03 11:49:02 --> Output Class Initialized
INFO - 2021-07-03 11:49:02 --> Security Class Initialized
DEBUG - 2021-07-03 11:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 11:49:02 --> Input Class Initialized
INFO - 2021-07-03 11:49:02 --> Language Class Initialized
INFO - 2021-07-03 11:49:02 --> Loader Class Initialized
INFO - 2021-07-03 11:49:02 --> Helper loaded: basic_helper
INFO - 2021-07-03 11:49:02 --> Helper loaded: url_helper
INFO - 2021-07-03 11:49:02 --> Helper loaded: file_helper
INFO - 2021-07-03 11:49:02 --> Helper loaded: form_helper
INFO - 2021-07-03 11:49:02 --> Helper loaded: cookie_helper
INFO - 2021-07-03 11:49:02 --> Helper loaded: security_helper
INFO - 2021-07-03 11:49:02 --> Helper loaded: directory_helper
INFO - 2021-07-03 11:49:02 --> Helper loaded: language_helper
INFO - 2021-07-03 11:49:02 --> Helper loaded: general_helper
INFO - 2021-07-03 11:49:02 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 11:49:02 --> Database Driver Class Initialized
DEBUG - 2021-07-03 11:49:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 11:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 11:49:02 --> Parser Class Initialized
INFO - 2021-07-03 11:49:02 --> Form Validation Class Initialized
INFO - 2021-07-03 11:49:02 --> Upload Class Initialized
INFO - 2021-07-03 11:49:02 --> Email Class Initialized
INFO - 2021-07-03 11:49:02 --> MY_Model class loaded
INFO - 2021-07-03 11:49:02 --> Model "Users_model" initialized
INFO - 2021-07-03 11:49:02 --> Model "Settings_model" initialized
INFO - 2021-07-03 11:49:02 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 11:49:02 --> Model "Permissions_model" initialized
INFO - 2021-07-03 11:49:02 --> Model "Roles_model" initialized
INFO - 2021-07-03 11:49:02 --> Model "Activity_model" initialized
INFO - 2021-07-03 11:49:02 --> Model "Templates_model" initialized
INFO - 2021-07-03 11:49:02 --> Database Driver Class Initialized
INFO - 2021-07-03 11:49:02 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 11:49:02 --> Controller Class Initialized
ERROR - 2021-07-03 14:49:02 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-03 14:49:02 --> Invalid query: 
INFO - 2021-07-03 14:49:02 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-03 14:49:02 --> Final output sent to browser
DEBUG - 2021-07-03 14:49:02 --> Total execution time: 0.0922
INFO - 2021-07-03 11:49:21 --> Config Class Initialized
INFO - 2021-07-03 11:49:21 --> Hooks Class Initialized
DEBUG - 2021-07-03 11:49:21 --> UTF-8 Support Enabled
INFO - 2021-07-03 11:49:21 --> Utf8 Class Initialized
INFO - 2021-07-03 11:49:21 --> URI Class Initialized
DEBUG - 2021-07-03 11:49:21 --> No URI present. Default controller set.
INFO - 2021-07-03 11:49:21 --> Router Class Initialized
INFO - 2021-07-03 11:49:21 --> Output Class Initialized
INFO - 2021-07-03 11:49:21 --> Security Class Initialized
DEBUG - 2021-07-03 11:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 11:49:21 --> Input Class Initialized
INFO - 2021-07-03 11:49:21 --> Language Class Initialized
INFO - 2021-07-03 11:49:21 --> Loader Class Initialized
INFO - 2021-07-03 11:49:21 --> Helper loaded: basic_helper
INFO - 2021-07-03 11:49:21 --> Helper loaded: url_helper
INFO - 2021-07-03 11:49:21 --> Helper loaded: file_helper
INFO - 2021-07-03 11:49:21 --> Helper loaded: form_helper
INFO - 2021-07-03 11:49:21 --> Helper loaded: cookie_helper
INFO - 2021-07-03 11:49:21 --> Helper loaded: security_helper
INFO - 2021-07-03 11:49:21 --> Helper loaded: directory_helper
INFO - 2021-07-03 11:49:21 --> Helper loaded: language_helper
INFO - 2021-07-03 11:49:21 --> Helper loaded: general_helper
INFO - 2021-07-03 11:49:21 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 11:49:21 --> Database Driver Class Initialized
DEBUG - 2021-07-03 11:49:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 11:49:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 11:49:21 --> Parser Class Initialized
INFO - 2021-07-03 11:49:21 --> Form Validation Class Initialized
INFO - 2021-07-03 11:49:21 --> Upload Class Initialized
INFO - 2021-07-03 11:49:21 --> Email Class Initialized
INFO - 2021-07-03 11:49:21 --> MY_Model class loaded
INFO - 2021-07-03 11:49:21 --> Model "Users_model" initialized
INFO - 2021-07-03 11:49:21 --> Model "Settings_model" initialized
INFO - 2021-07-03 11:49:21 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 11:49:21 --> Model "Permissions_model" initialized
INFO - 2021-07-03 11:49:21 --> Model "Roles_model" initialized
INFO - 2021-07-03 11:49:21 --> Model "Activity_model" initialized
INFO - 2021-07-03 11:49:21 --> Model "Templates_model" initialized
INFO - 2021-07-03 11:49:21 --> Database Driver Class Initialized
INFO - 2021-07-03 11:49:21 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 11:49:21 --> Controller Class Initialized
INFO - 2021-07-03 11:49:21 --> Config Class Initialized
INFO - 2021-07-03 11:49:21 --> Hooks Class Initialized
INFO - 2021-07-03 11:49:21 --> Config Class Initialized
INFO - 2021-07-03 11:49:21 --> Hooks Class Initialized
DEBUG - 2021-07-03 11:49:21 --> UTF-8 Support Enabled
INFO - 2021-07-03 11:49:21 --> Utf8 Class Initialized
DEBUG - 2021-07-03 11:49:21 --> UTF-8 Support Enabled
INFO - 2021-07-03 11:49:21 --> URI Class Initialized
INFO - 2021-07-03 11:49:21 --> Utf8 Class Initialized
INFO - 2021-07-03 11:49:21 --> URI Class Initialized
INFO - 2021-07-03 11:49:21 --> Router Class Initialized
INFO - 2021-07-03 11:49:21 --> Router Class Initialized
INFO - 2021-07-03 11:49:21 --> Output Class Initialized
INFO - 2021-07-03 11:49:21 --> Output Class Initialized
INFO - 2021-07-03 11:49:21 --> Security Class Initialized
INFO - 2021-07-03 11:49:21 --> Security Class Initialized
DEBUG - 2021-07-03 11:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 11:49:21 --> Input Class Initialized
DEBUG - 2021-07-03 11:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 11:49:21 --> Language Class Initialized
INFO - 2021-07-03 11:49:21 --> Input Class Initialized
INFO - 2021-07-03 11:49:21 --> Language Class Initialized
INFO - 2021-07-03 11:49:21 --> Loader Class Initialized
ERROR - 2021-07-03 11:49:21 --> 404 Page Not Found: Faviconico/index
INFO - 2021-07-03 11:49:21 --> Helper loaded: basic_helper
INFO - 2021-07-03 11:49:21 --> Helper loaded: url_helper
INFO - 2021-07-03 11:49:21 --> Helper loaded: file_helper
INFO - 2021-07-03 11:49:21 --> Helper loaded: form_helper
INFO - 2021-07-03 11:49:21 --> Helper loaded: cookie_helper
INFO - 2021-07-03 11:49:21 --> Helper loaded: security_helper
INFO - 2021-07-03 11:49:21 --> Helper loaded: directory_helper
INFO - 2021-07-03 11:49:21 --> Helper loaded: language_helper
INFO - 2021-07-03 11:49:21 --> Helper loaded: general_helper
INFO - 2021-07-03 11:49:21 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 11:49:21 --> Database Driver Class Initialized
DEBUG - 2021-07-03 11:49:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 11:49:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 11:49:21 --> Parser Class Initialized
INFO - 2021-07-03 11:49:21 --> Form Validation Class Initialized
INFO - 2021-07-03 11:49:21 --> Upload Class Initialized
INFO - 2021-07-03 11:49:21 --> Email Class Initialized
INFO - 2021-07-03 11:49:21 --> MY_Model class loaded
INFO - 2021-07-03 11:49:21 --> Model "Users_model" initialized
INFO - 2021-07-03 11:49:21 --> Model "Settings_model" initialized
INFO - 2021-07-03 11:49:21 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 11:49:21 --> Model "Permissions_model" initialized
INFO - 2021-07-03 11:49:21 --> Model "Roles_model" initialized
INFO - 2021-07-03 11:49:21 --> Model "Activity_model" initialized
INFO - 2021-07-03 11:49:21 --> Model "Templates_model" initialized
INFO - 2021-07-03 11:49:21 --> Database Driver Class Initialized
INFO - 2021-07-03 11:49:21 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 11:49:21 --> Controller Class Initialized
INFO - 2021-07-03 14:49:21 --> File loaded: C:\wamp64\www\crm\application\views\account/login.php
INFO - 2021-07-03 14:49:21 --> Final output sent to browser
DEBUG - 2021-07-03 14:49:21 --> Total execution time: 0.0465
INFO - 2021-07-03 11:49:21 --> Config Class Initialized
INFO - 2021-07-03 11:49:21 --> Hooks Class Initialized
INFO - 2021-07-03 11:49:21 --> Config Class Initialized
INFO - 2021-07-03 11:49:21 --> Hooks Class Initialized
DEBUG - 2021-07-03 11:49:21 --> UTF-8 Support Enabled
INFO - 2021-07-03 11:49:21 --> Utf8 Class Initialized
DEBUG - 2021-07-03 11:49:21 --> UTF-8 Support Enabled
INFO - 2021-07-03 11:49:21 --> Utf8 Class Initialized
INFO - 2021-07-03 11:49:21 --> URI Class Initialized
INFO - 2021-07-03 11:49:21 --> Router Class Initialized
INFO - 2021-07-03 11:49:21 --> URI Class Initialized
INFO - 2021-07-03 11:49:21 --> Output Class Initialized
INFO - 2021-07-03 11:49:21 --> Router Class Initialized
INFO - 2021-07-03 11:49:21 --> Security Class Initialized
INFO - 2021-07-03 11:49:21 --> Output Class Initialized
DEBUG - 2021-07-03 11:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 11:49:21 --> Input Class Initialized
INFO - 2021-07-03 11:49:21 --> Security Class Initialized
INFO - 2021-07-03 11:49:21 --> Language Class Initialized
DEBUG - 2021-07-03 11:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 11:49:21 --> Input Class Initialized
ERROR - 2021-07-03 11:49:21 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-03 11:49:21 --> Language Class Initialized
ERROR - 2021-07-03 11:49:21 --> 404 Page Not Found: Assets/jquery
INFO - 2021-07-03 11:49:22 --> Config Class Initialized
INFO - 2021-07-03 11:49:22 --> Hooks Class Initialized
DEBUG - 2021-07-03 11:49:22 --> UTF-8 Support Enabled
INFO - 2021-07-03 11:49:22 --> Utf8 Class Initialized
INFO - 2021-07-03 11:49:22 --> URI Class Initialized
INFO - 2021-07-03 11:49:22 --> Router Class Initialized
INFO - 2021-07-03 11:49:22 --> Output Class Initialized
INFO - 2021-07-03 11:49:22 --> Security Class Initialized
DEBUG - 2021-07-03 11:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 11:49:22 --> Input Class Initialized
INFO - 2021-07-03 11:49:22 --> Language Class Initialized
ERROR - 2021-07-03 11:49:22 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-03 11:49:43 --> Config Class Initialized
INFO - 2021-07-03 11:49:43 --> Hooks Class Initialized
DEBUG - 2021-07-03 11:49:43 --> UTF-8 Support Enabled
INFO - 2021-07-03 11:49:43 --> Utf8 Class Initialized
INFO - 2021-07-03 11:49:43 --> URI Class Initialized
INFO - 2021-07-03 11:49:43 --> Router Class Initialized
INFO - 2021-07-03 11:49:43 --> Output Class Initialized
INFO - 2021-07-03 11:49:43 --> Security Class Initialized
DEBUG - 2021-07-03 11:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 11:49:43 --> Input Class Initialized
INFO - 2021-07-03 11:49:43 --> Language Class Initialized
INFO - 2021-07-03 11:49:43 --> Loader Class Initialized
INFO - 2021-07-03 11:49:43 --> Helper loaded: basic_helper
INFO - 2021-07-03 11:49:43 --> Helper loaded: url_helper
INFO - 2021-07-03 11:49:43 --> Helper loaded: file_helper
INFO - 2021-07-03 11:49:43 --> Helper loaded: form_helper
INFO - 2021-07-03 11:49:43 --> Helper loaded: cookie_helper
INFO - 2021-07-03 11:49:43 --> Helper loaded: security_helper
INFO - 2021-07-03 11:49:43 --> Helper loaded: directory_helper
INFO - 2021-07-03 11:49:43 --> Helper loaded: language_helper
INFO - 2021-07-03 11:49:43 --> Helper loaded: general_helper
INFO - 2021-07-03 11:49:43 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 11:49:43 --> Database Driver Class Initialized
DEBUG - 2021-07-03 11:49:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 11:49:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 11:49:43 --> Parser Class Initialized
INFO - 2021-07-03 11:49:43 --> Form Validation Class Initialized
INFO - 2021-07-03 11:49:43 --> Upload Class Initialized
INFO - 2021-07-03 11:49:43 --> Email Class Initialized
INFO - 2021-07-03 11:49:43 --> MY_Model class loaded
INFO - 2021-07-03 11:49:43 --> Model "Users_model" initialized
INFO - 2021-07-03 11:49:43 --> Model "Settings_model" initialized
INFO - 2021-07-03 11:49:43 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 11:49:43 --> Model "Permissions_model" initialized
INFO - 2021-07-03 11:49:43 --> Model "Roles_model" initialized
INFO - 2021-07-03 11:49:43 --> Model "Activity_model" initialized
INFO - 2021-07-03 11:49:43 --> Model "Templates_model" initialized
INFO - 2021-07-03 11:49:43 --> Database Driver Class Initialized
INFO - 2021-07-03 11:49:43 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 11:49:43 --> Controller Class Initialized
ERROR - 2021-07-03 14:49:43 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 14:49:43 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-03 14:49:43 --> Final output sent to browser
DEBUG - 2021-07-03 14:49:43 --> Total execution time: 0.1946
INFO - 2021-07-03 11:49:48 --> Config Class Initialized
INFO - 2021-07-03 11:49:48 --> Hooks Class Initialized
DEBUG - 2021-07-03 11:49:48 --> UTF-8 Support Enabled
INFO - 2021-07-03 11:49:48 --> Utf8 Class Initialized
INFO - 2021-07-03 11:49:48 --> URI Class Initialized
INFO - 2021-07-03 11:49:48 --> Router Class Initialized
INFO - 2021-07-03 11:49:48 --> Output Class Initialized
INFO - 2021-07-03 11:49:48 --> Security Class Initialized
DEBUG - 2021-07-03 11:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 11:49:48 --> Input Class Initialized
INFO - 2021-07-03 11:49:48 --> Language Class Initialized
INFO - 2021-07-03 11:49:48 --> Loader Class Initialized
INFO - 2021-07-03 11:49:48 --> Helper loaded: basic_helper
INFO - 2021-07-03 11:49:48 --> Helper loaded: url_helper
INFO - 2021-07-03 11:49:48 --> Helper loaded: file_helper
INFO - 2021-07-03 11:49:48 --> Helper loaded: form_helper
INFO - 2021-07-03 11:49:48 --> Helper loaded: cookie_helper
INFO - 2021-07-03 11:49:48 --> Helper loaded: security_helper
INFO - 2021-07-03 11:49:48 --> Helper loaded: directory_helper
INFO - 2021-07-03 11:49:48 --> Helper loaded: language_helper
INFO - 2021-07-03 11:49:48 --> Helper loaded: general_helper
INFO - 2021-07-03 11:49:48 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 11:49:48 --> Database Driver Class Initialized
DEBUG - 2021-07-03 11:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 11:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 11:49:48 --> Parser Class Initialized
INFO - 2021-07-03 11:49:48 --> Form Validation Class Initialized
INFO - 2021-07-03 11:49:48 --> Upload Class Initialized
INFO - 2021-07-03 11:49:48 --> Email Class Initialized
INFO - 2021-07-03 11:49:48 --> MY_Model class loaded
INFO - 2021-07-03 11:49:48 --> Model "Users_model" initialized
INFO - 2021-07-03 11:49:48 --> Model "Settings_model" initialized
INFO - 2021-07-03 11:49:48 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 11:49:48 --> Model "Permissions_model" initialized
INFO - 2021-07-03 11:49:48 --> Model "Roles_model" initialized
INFO - 2021-07-03 11:49:48 --> Model "Activity_model" initialized
INFO - 2021-07-03 11:49:48 --> Model "Templates_model" initialized
INFO - 2021-07-03 11:49:48 --> Database Driver Class Initialized
INFO - 2021-07-03 11:49:48 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 11:49:48 --> Controller Class Initialized
ERROR - 2021-07-03 14:49:48 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 14:49:48 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-03 14:49:48 --> Final output sent to browser
DEBUG - 2021-07-03 14:49:48 --> Total execution time: 0.1431
INFO - 2021-07-03 11:49:50 --> Config Class Initialized
INFO - 2021-07-03 11:49:50 --> Hooks Class Initialized
DEBUG - 2021-07-03 11:49:50 --> UTF-8 Support Enabled
INFO - 2021-07-03 11:49:50 --> Utf8 Class Initialized
INFO - 2021-07-03 11:49:50 --> URI Class Initialized
INFO - 2021-07-03 11:49:50 --> Router Class Initialized
INFO - 2021-07-03 11:49:50 --> Output Class Initialized
INFO - 2021-07-03 11:49:50 --> Security Class Initialized
DEBUG - 2021-07-03 11:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 11:49:50 --> Input Class Initialized
INFO - 2021-07-03 11:49:50 --> Language Class Initialized
INFO - 2021-07-03 11:49:50 --> Loader Class Initialized
INFO - 2021-07-03 11:49:50 --> Helper loaded: basic_helper
INFO - 2021-07-03 11:49:50 --> Helper loaded: url_helper
INFO - 2021-07-03 11:49:50 --> Helper loaded: file_helper
INFO - 2021-07-03 11:49:50 --> Helper loaded: form_helper
INFO - 2021-07-03 11:49:50 --> Helper loaded: cookie_helper
INFO - 2021-07-03 11:49:50 --> Helper loaded: security_helper
INFO - 2021-07-03 11:49:50 --> Helper loaded: directory_helper
INFO - 2021-07-03 11:49:50 --> Helper loaded: language_helper
INFO - 2021-07-03 11:49:50 --> Helper loaded: general_helper
INFO - 2021-07-03 11:49:50 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 11:49:51 --> Database Driver Class Initialized
DEBUG - 2021-07-03 11:49:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 11:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 11:49:51 --> Parser Class Initialized
INFO - 2021-07-03 11:49:51 --> Form Validation Class Initialized
INFO - 2021-07-03 11:49:51 --> Upload Class Initialized
INFO - 2021-07-03 11:49:51 --> Email Class Initialized
INFO - 2021-07-03 11:49:51 --> MY_Model class loaded
INFO - 2021-07-03 11:49:51 --> Model "Users_model" initialized
INFO - 2021-07-03 11:49:51 --> Model "Settings_model" initialized
INFO - 2021-07-03 11:49:51 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 11:49:51 --> Model "Permissions_model" initialized
INFO - 2021-07-03 11:49:51 --> Model "Roles_model" initialized
INFO - 2021-07-03 11:49:51 --> Model "Activity_model" initialized
INFO - 2021-07-03 11:49:51 --> Model "Templates_model" initialized
INFO - 2021-07-03 11:49:51 --> Database Driver Class Initialized
INFO - 2021-07-03 11:49:51 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 11:49:51 --> Controller Class Initialized
ERROR - 2021-07-03 14:49:51 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 14:49:51 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-03 14:49:51 --> Final output sent to browser
DEBUG - 2021-07-03 14:49:51 --> Total execution time: 0.1241
INFO - 2021-07-03 11:49:55 --> Config Class Initialized
INFO - 2021-07-03 11:49:55 --> Hooks Class Initialized
DEBUG - 2021-07-03 11:49:55 --> UTF-8 Support Enabled
INFO - 2021-07-03 11:49:55 --> Utf8 Class Initialized
INFO - 2021-07-03 11:49:55 --> URI Class Initialized
INFO - 2021-07-03 11:49:55 --> Router Class Initialized
INFO - 2021-07-03 11:49:55 --> Output Class Initialized
INFO - 2021-07-03 11:49:55 --> Security Class Initialized
DEBUG - 2021-07-03 11:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 11:49:55 --> Input Class Initialized
INFO - 2021-07-03 11:49:55 --> Language Class Initialized
INFO - 2021-07-03 11:49:55 --> Loader Class Initialized
INFO - 2021-07-03 11:49:55 --> Helper loaded: basic_helper
INFO - 2021-07-03 11:49:55 --> Helper loaded: url_helper
INFO - 2021-07-03 11:49:55 --> Helper loaded: file_helper
INFO - 2021-07-03 11:49:55 --> Helper loaded: form_helper
INFO - 2021-07-03 11:49:55 --> Helper loaded: cookie_helper
INFO - 2021-07-03 11:49:55 --> Helper loaded: security_helper
INFO - 2021-07-03 11:49:55 --> Helper loaded: directory_helper
INFO - 2021-07-03 11:49:55 --> Helper loaded: language_helper
INFO - 2021-07-03 11:49:55 --> Helper loaded: general_helper
INFO - 2021-07-03 11:49:55 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 11:49:55 --> Database Driver Class Initialized
DEBUG - 2021-07-03 11:49:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 11:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 11:49:55 --> Parser Class Initialized
INFO - 2021-07-03 11:49:55 --> Form Validation Class Initialized
INFO - 2021-07-03 11:49:55 --> Upload Class Initialized
INFO - 2021-07-03 11:49:55 --> Email Class Initialized
INFO - 2021-07-03 11:49:55 --> MY_Model class loaded
INFO - 2021-07-03 11:49:55 --> Model "Users_model" initialized
INFO - 2021-07-03 11:49:55 --> Model "Settings_model" initialized
INFO - 2021-07-03 11:49:55 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 11:49:55 --> Model "Permissions_model" initialized
INFO - 2021-07-03 11:49:55 --> Model "Roles_model" initialized
INFO - 2021-07-03 11:49:55 --> Model "Activity_model" initialized
INFO - 2021-07-03 11:49:55 --> Model "Templates_model" initialized
INFO - 2021-07-03 11:49:55 --> Database Driver Class Initialized
INFO - 2021-07-03 11:49:55 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 11:49:55 --> Controller Class Initialized
DEBUG - 2021-07-03 14:49:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-03 14:49:55 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2021-07-03 11:49:56 --> Config Class Initialized
INFO - 2021-07-03 11:49:56 --> Hooks Class Initialized
DEBUG - 2021-07-03 11:49:56 --> UTF-8 Support Enabled
INFO - 2021-07-03 11:49:56 --> Utf8 Class Initialized
INFO - 2021-07-03 11:49:56 --> URI Class Initialized
DEBUG - 2021-07-03 11:49:56 --> No URI present. Default controller set.
INFO - 2021-07-03 11:49:56 --> Router Class Initialized
INFO - 2021-07-03 11:49:56 --> Output Class Initialized
INFO - 2021-07-03 11:49:56 --> Security Class Initialized
DEBUG - 2021-07-03 11:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 11:49:56 --> Input Class Initialized
INFO - 2021-07-03 11:49:56 --> Language Class Initialized
INFO - 2021-07-03 11:49:56 --> Loader Class Initialized
INFO - 2021-07-03 11:49:56 --> Helper loaded: basic_helper
INFO - 2021-07-03 11:49:56 --> Helper loaded: url_helper
INFO - 2021-07-03 11:49:56 --> Helper loaded: file_helper
INFO - 2021-07-03 11:49:56 --> Helper loaded: form_helper
INFO - 2021-07-03 11:49:56 --> Helper loaded: cookie_helper
INFO - 2021-07-03 11:49:56 --> Helper loaded: security_helper
INFO - 2021-07-03 11:49:56 --> Helper loaded: directory_helper
INFO - 2021-07-03 11:49:56 --> Helper loaded: language_helper
INFO - 2021-07-03 11:49:56 --> Helper loaded: general_helper
INFO - 2021-07-03 11:49:56 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 11:49:56 --> Database Driver Class Initialized
DEBUG - 2021-07-03 11:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 11:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 11:49:56 --> Parser Class Initialized
INFO - 2021-07-03 11:49:56 --> Form Validation Class Initialized
INFO - 2021-07-03 11:49:56 --> Upload Class Initialized
INFO - 2021-07-03 11:49:56 --> Email Class Initialized
INFO - 2021-07-03 11:49:56 --> MY_Model class loaded
INFO - 2021-07-03 11:49:56 --> Model "Users_model" initialized
INFO - 2021-07-03 11:49:56 --> Model "Settings_model" initialized
INFO - 2021-07-03 11:49:56 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 11:49:56 --> Model "Permissions_model" initialized
INFO - 2021-07-03 11:49:56 --> Model "Roles_model" initialized
INFO - 2021-07-03 11:49:56 --> Model "Activity_model" initialized
INFO - 2021-07-03 11:49:56 --> Model "Templates_model" initialized
INFO - 2021-07-03 11:49:56 --> Database Driver Class Initialized
INFO - 2021-07-03 11:49:56 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 11:49:56 --> Controller Class Initialized
ERROR - 2021-07-03 14:49:56 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 14:49:56 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-03 14:49:56 --> Final output sent to browser
DEBUG - 2021-07-03 14:49:56 --> Total execution time: 0.0599
INFO - 2021-07-03 11:50:03 --> Config Class Initialized
INFO - 2021-07-03 11:50:03 --> Hooks Class Initialized
DEBUG - 2021-07-03 11:50:03 --> UTF-8 Support Enabled
INFO - 2021-07-03 11:50:03 --> Utf8 Class Initialized
INFO - 2021-07-03 11:50:03 --> URI Class Initialized
INFO - 2021-07-03 11:50:03 --> Router Class Initialized
INFO - 2021-07-03 11:50:03 --> Output Class Initialized
INFO - 2021-07-03 11:50:03 --> Security Class Initialized
DEBUG - 2021-07-03 11:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 11:50:03 --> Input Class Initialized
INFO - 2021-07-03 11:50:03 --> Language Class Initialized
INFO - 2021-07-03 11:50:03 --> Loader Class Initialized
INFO - 2021-07-03 11:50:03 --> Helper loaded: basic_helper
INFO - 2021-07-03 11:50:03 --> Helper loaded: url_helper
INFO - 2021-07-03 11:50:03 --> Helper loaded: file_helper
INFO - 2021-07-03 11:50:03 --> Helper loaded: form_helper
INFO - 2021-07-03 11:50:03 --> Helper loaded: cookie_helper
INFO - 2021-07-03 11:50:03 --> Helper loaded: security_helper
INFO - 2021-07-03 11:50:03 --> Helper loaded: directory_helper
INFO - 2021-07-03 11:50:03 --> Helper loaded: language_helper
INFO - 2021-07-03 11:50:03 --> Helper loaded: general_helper
INFO - 2021-07-03 11:50:03 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 11:50:03 --> Database Driver Class Initialized
DEBUG - 2021-07-03 11:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 11:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 11:50:03 --> Parser Class Initialized
INFO - 2021-07-03 11:50:03 --> Form Validation Class Initialized
INFO - 2021-07-03 11:50:03 --> Upload Class Initialized
INFO - 2021-07-03 11:50:03 --> Email Class Initialized
INFO - 2021-07-03 11:50:03 --> MY_Model class loaded
INFO - 2021-07-03 11:50:03 --> Model "Users_model" initialized
INFO - 2021-07-03 11:50:03 --> Model "Settings_model" initialized
INFO - 2021-07-03 11:50:03 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 11:50:03 --> Model "Permissions_model" initialized
INFO - 2021-07-03 11:50:03 --> Model "Roles_model" initialized
INFO - 2021-07-03 11:50:03 --> Model "Activity_model" initialized
INFO - 2021-07-03 11:50:03 --> Model "Templates_model" initialized
INFO - 2021-07-03 11:50:03 --> Database Driver Class Initialized
INFO - 2021-07-03 11:50:03 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 11:50:03 --> Controller Class Initialized
ERROR - 2021-07-03 14:50:03 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-03 14:50:03 --> Invalid query: 
INFO - 2021-07-03 14:50:03 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-03 14:50:03 --> Final output sent to browser
DEBUG - 2021-07-03 14:50:03 --> Total execution time: 0.1577
INFO - 2021-07-03 11:50:54 --> Config Class Initialized
INFO - 2021-07-03 11:50:54 --> Hooks Class Initialized
DEBUG - 2021-07-03 11:50:54 --> UTF-8 Support Enabled
INFO - 2021-07-03 11:50:54 --> Utf8 Class Initialized
INFO - 2021-07-03 11:50:54 --> URI Class Initialized
DEBUG - 2021-07-03 11:50:54 --> No URI present. Default controller set.
INFO - 2021-07-03 11:50:54 --> Router Class Initialized
INFO - 2021-07-03 11:50:54 --> Output Class Initialized
INFO - 2021-07-03 11:50:54 --> Security Class Initialized
DEBUG - 2021-07-03 11:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 11:50:54 --> Input Class Initialized
INFO - 2021-07-03 11:50:54 --> Language Class Initialized
INFO - 2021-07-03 11:50:54 --> Loader Class Initialized
INFO - 2021-07-03 11:50:54 --> Helper loaded: basic_helper
INFO - 2021-07-03 11:50:54 --> Helper loaded: url_helper
INFO - 2021-07-03 11:50:54 --> Helper loaded: file_helper
INFO - 2021-07-03 11:50:54 --> Helper loaded: form_helper
INFO - 2021-07-03 11:50:54 --> Helper loaded: cookie_helper
INFO - 2021-07-03 11:50:54 --> Helper loaded: security_helper
INFO - 2021-07-03 11:50:54 --> Helper loaded: directory_helper
INFO - 2021-07-03 11:50:54 --> Helper loaded: language_helper
INFO - 2021-07-03 11:50:54 --> Helper loaded: general_helper
INFO - 2021-07-03 11:50:54 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 11:50:54 --> Database Driver Class Initialized
DEBUG - 2021-07-03 11:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 11:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 11:50:54 --> Parser Class Initialized
INFO - 2021-07-03 11:50:54 --> Form Validation Class Initialized
INFO - 2021-07-03 11:50:54 --> Upload Class Initialized
INFO - 2021-07-03 11:50:54 --> Email Class Initialized
INFO - 2021-07-03 11:50:54 --> MY_Model class loaded
INFO - 2021-07-03 11:50:54 --> Model "Users_model" initialized
INFO - 2021-07-03 11:50:54 --> Model "Settings_model" initialized
INFO - 2021-07-03 11:50:54 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 11:50:54 --> Model "Permissions_model" initialized
INFO - 2021-07-03 11:50:54 --> Model "Roles_model" initialized
INFO - 2021-07-03 11:50:54 --> Model "Activity_model" initialized
INFO - 2021-07-03 11:50:54 --> Model "Templates_model" initialized
INFO - 2021-07-03 11:50:54 --> Database Driver Class Initialized
INFO - 2021-07-03 11:50:54 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 11:50:54 --> Controller Class Initialized
ERROR - 2021-07-03 14:50:54 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 14:50:54 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-03 14:50:54 --> Final output sent to browser
DEBUG - 2021-07-03 14:50:54 --> Total execution time: 0.1318
INFO - 2021-07-03 11:53:01 --> Config Class Initialized
INFO - 2021-07-03 11:53:01 --> Hooks Class Initialized
DEBUG - 2021-07-03 11:53:01 --> UTF-8 Support Enabled
INFO - 2021-07-03 11:53:01 --> Utf8 Class Initialized
INFO - 2021-07-03 11:53:01 --> URI Class Initialized
INFO - 2021-07-03 11:53:01 --> Router Class Initialized
INFO - 2021-07-03 11:53:01 --> Output Class Initialized
INFO - 2021-07-03 11:53:01 --> Security Class Initialized
DEBUG - 2021-07-03 11:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 11:53:01 --> Input Class Initialized
INFO - 2021-07-03 11:53:01 --> Language Class Initialized
INFO - 2021-07-03 11:53:01 --> Loader Class Initialized
INFO - 2021-07-03 11:53:01 --> Helper loaded: basic_helper
INFO - 2021-07-03 11:53:01 --> Helper loaded: url_helper
INFO - 2021-07-03 11:53:01 --> Helper loaded: file_helper
INFO - 2021-07-03 11:53:01 --> Helper loaded: form_helper
INFO - 2021-07-03 11:53:01 --> Helper loaded: cookie_helper
INFO - 2021-07-03 11:53:01 --> Helper loaded: security_helper
INFO - 2021-07-03 11:53:01 --> Helper loaded: directory_helper
INFO - 2021-07-03 11:53:01 --> Helper loaded: language_helper
INFO - 2021-07-03 11:53:01 --> Helper loaded: general_helper
INFO - 2021-07-03 11:53:01 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 11:53:01 --> Database Driver Class Initialized
DEBUG - 2021-07-03 11:53:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 11:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 11:53:01 --> Parser Class Initialized
INFO - 2021-07-03 11:53:01 --> Form Validation Class Initialized
INFO - 2021-07-03 11:53:01 --> Upload Class Initialized
INFO - 2021-07-03 11:53:01 --> Email Class Initialized
INFO - 2021-07-03 11:53:01 --> MY_Model class loaded
INFO - 2021-07-03 11:53:01 --> Model "Users_model" initialized
INFO - 2021-07-03 11:53:01 --> Model "Settings_model" initialized
INFO - 2021-07-03 11:53:01 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 11:53:01 --> Model "Permissions_model" initialized
INFO - 2021-07-03 11:53:01 --> Model "Roles_model" initialized
INFO - 2021-07-03 11:53:01 --> Model "Activity_model" initialized
INFO - 2021-07-03 11:53:01 --> Model "Templates_model" initialized
INFO - 2021-07-03 11:53:01 --> Database Driver Class Initialized
INFO - 2021-07-03 11:53:02 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 11:53:02 --> Controller Class Initialized
ERROR - 2021-07-03 14:53:02 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-03 14:53:02 --> Could not find the language line "user_username_taken"
ERROR - 2021-07-03 14:53:02 --> Could not find the language line "confirm)new_password"
INFO - 2021-07-03 14:53:02 --> File loaded: C:\wamp64\www\crm\application\views\account/profile.php
INFO - 2021-07-03 14:53:02 --> Final output sent to browser
DEBUG - 2021-07-03 14:53:02 --> Total execution time: 0.1417
INFO - 2021-07-03 12:16:36 --> Config Class Initialized
INFO - 2021-07-03 12:16:36 --> Hooks Class Initialized
DEBUG - 2021-07-03 12:16:36 --> UTF-8 Support Enabled
INFO - 2021-07-03 12:16:36 --> Utf8 Class Initialized
INFO - 2021-07-03 12:16:36 --> URI Class Initialized
INFO - 2021-07-03 12:16:36 --> Router Class Initialized
INFO - 2021-07-03 12:16:36 --> Output Class Initialized
INFO - 2021-07-03 12:16:36 --> Security Class Initialized
DEBUG - 2021-07-03 12:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 12:16:36 --> Input Class Initialized
INFO - 2021-07-03 12:16:36 --> Language Class Initialized
INFO - 2021-07-03 12:16:36 --> Loader Class Initialized
INFO - 2021-07-03 12:16:36 --> Helper loaded: basic_helper
INFO - 2021-07-03 12:16:36 --> Helper loaded: url_helper
INFO - 2021-07-03 12:16:36 --> Helper loaded: file_helper
INFO - 2021-07-03 12:16:36 --> Helper loaded: form_helper
INFO - 2021-07-03 12:16:36 --> Helper loaded: cookie_helper
INFO - 2021-07-03 12:16:36 --> Helper loaded: security_helper
INFO - 2021-07-03 12:16:36 --> Helper loaded: directory_helper
INFO - 2021-07-03 12:16:36 --> Helper loaded: language_helper
INFO - 2021-07-03 12:16:36 --> Helper loaded: general_helper
INFO - 2021-07-03 12:16:36 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 12:16:36 --> Database Driver Class Initialized
DEBUG - 2021-07-03 12:16:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 12:16:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 12:16:36 --> Parser Class Initialized
INFO - 2021-07-03 12:16:36 --> Form Validation Class Initialized
INFO - 2021-07-03 12:16:36 --> Upload Class Initialized
INFO - 2021-07-03 12:16:36 --> Email Class Initialized
INFO - 2021-07-03 12:16:36 --> MY_Model class loaded
INFO - 2021-07-03 12:16:36 --> Model "Users_model" initialized
INFO - 2021-07-03 12:16:36 --> Model "Settings_model" initialized
INFO - 2021-07-03 12:16:36 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 12:16:36 --> Model "Permissions_model" initialized
INFO - 2021-07-03 12:16:36 --> Model "Roles_model" initialized
INFO - 2021-07-03 12:16:36 --> Model "Activity_model" initialized
INFO - 2021-07-03 12:16:36 --> Model "Templates_model" initialized
INFO - 2021-07-03 12:16:36 --> Database Driver Class Initialized
INFO - 2021-07-03 12:16:36 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 12:16:36 --> Controller Class Initialized
ERROR - 2021-07-03 15:16:36 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-03 15:16:36 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-03 15:16:36 --> Final output sent to browser
DEBUG - 2021-07-03 15:16:36 --> Total execution time: 0.2175
INFO - 2021-07-03 13:06:45 --> Config Class Initialized
INFO - 2021-07-03 13:06:45 --> Hooks Class Initialized
DEBUG - 2021-07-03 13:06:45 --> UTF-8 Support Enabled
INFO - 2021-07-03 13:06:45 --> Utf8 Class Initialized
INFO - 2021-07-03 13:06:45 --> URI Class Initialized
DEBUG - 2021-07-03 13:06:45 --> No URI present. Default controller set.
INFO - 2021-07-03 13:06:45 --> Router Class Initialized
INFO - 2021-07-03 13:06:45 --> Output Class Initialized
INFO - 2021-07-03 13:06:45 --> Security Class Initialized
DEBUG - 2021-07-03 13:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 13:06:45 --> Input Class Initialized
INFO - 2021-07-03 13:06:45 --> Language Class Initialized
INFO - 2021-07-03 13:06:45 --> Loader Class Initialized
INFO - 2021-07-03 13:06:45 --> Helper loaded: basic_helper
INFO - 2021-07-03 13:06:45 --> Helper loaded: url_helper
INFO - 2021-07-03 13:06:45 --> Helper loaded: file_helper
INFO - 2021-07-03 13:06:45 --> Helper loaded: form_helper
INFO - 2021-07-03 13:06:45 --> Helper loaded: cookie_helper
INFO - 2021-07-03 13:06:45 --> Helper loaded: security_helper
INFO - 2021-07-03 13:06:45 --> Helper loaded: directory_helper
INFO - 2021-07-03 13:06:45 --> Helper loaded: language_helper
INFO - 2021-07-03 13:06:45 --> Helper loaded: general_helper
INFO - 2021-07-03 13:06:45 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 13:06:45 --> Database Driver Class Initialized
DEBUG - 2021-07-03 13:06:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 13:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 13:06:45 --> Parser Class Initialized
INFO - 2021-07-03 13:06:45 --> Form Validation Class Initialized
INFO - 2021-07-03 13:06:45 --> Upload Class Initialized
INFO - 2021-07-03 13:06:45 --> Email Class Initialized
INFO - 2021-07-03 13:06:45 --> MY_Model class loaded
INFO - 2021-07-03 13:06:45 --> Model "Users_model" initialized
INFO - 2021-07-03 13:06:45 --> Model "Settings_model" initialized
INFO - 2021-07-03 13:06:45 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 13:06:45 --> Model "Permissions_model" initialized
INFO - 2021-07-03 13:06:45 --> Model "Roles_model" initialized
INFO - 2021-07-03 13:06:45 --> Model "Activity_model" initialized
INFO - 2021-07-03 13:06:45 --> Model "Templates_model" initialized
INFO - 2021-07-03 13:06:45 --> Database Driver Class Initialized
INFO - 2021-07-03 13:06:46 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 13:06:46 --> Controller Class Initialized
INFO - 2021-07-03 14:30:53 --> Config Class Initialized
INFO - 2021-07-03 14:30:53 --> Hooks Class Initialized
DEBUG - 2021-07-03 14:30:53 --> UTF-8 Support Enabled
INFO - 2021-07-03 14:30:53 --> Utf8 Class Initialized
INFO - 2021-07-03 14:30:53 --> URI Class Initialized
DEBUG - 2021-07-03 14:30:53 --> No URI present. Default controller set.
INFO - 2021-07-03 14:30:53 --> Router Class Initialized
INFO - 2021-07-03 14:30:53 --> Output Class Initialized
INFO - 2021-07-03 14:30:53 --> Security Class Initialized
DEBUG - 2021-07-03 14:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-03 14:30:53 --> Input Class Initialized
INFO - 2021-07-03 14:30:53 --> Language Class Initialized
INFO - 2021-07-03 14:30:53 --> Loader Class Initialized
INFO - 2021-07-03 14:30:53 --> Helper loaded: basic_helper
INFO - 2021-07-03 14:30:53 --> Helper loaded: url_helper
INFO - 2021-07-03 14:30:53 --> Helper loaded: file_helper
INFO - 2021-07-03 14:30:53 --> Helper loaded: form_helper
INFO - 2021-07-03 14:30:53 --> Helper loaded: cookie_helper
INFO - 2021-07-03 14:30:53 --> Helper loaded: security_helper
INFO - 2021-07-03 14:30:53 --> Helper loaded: directory_helper
INFO - 2021-07-03 14:30:53 --> Helper loaded: language_helper
INFO - 2021-07-03 14:30:53 --> Helper loaded: general_helper
INFO - 2021-07-03 14:30:53 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-03 14:30:53 --> Database Driver Class Initialized
DEBUG - 2021-07-03 14:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-03 14:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-03 14:30:53 --> Parser Class Initialized
INFO - 2021-07-03 14:30:53 --> Form Validation Class Initialized
INFO - 2021-07-03 14:30:53 --> Upload Class Initialized
INFO - 2021-07-03 14:30:53 --> Email Class Initialized
INFO - 2021-07-03 14:30:53 --> MY_Model class loaded
INFO - 2021-07-03 14:30:53 --> Model "Users_model" initialized
INFO - 2021-07-03 14:30:53 --> Model "Settings_model" initialized
INFO - 2021-07-03 14:30:53 --> Model "Role_permissions_model" initialized
INFO - 2021-07-03 14:30:53 --> Model "Permissions_model" initialized
INFO - 2021-07-03 14:30:53 --> Model "Roles_model" initialized
INFO - 2021-07-03 14:30:53 --> Model "Activity_model" initialized
INFO - 2021-07-03 14:30:53 --> Model "Templates_model" initialized
INFO - 2021-07-03 14:30:53 --> Database Driver Class Initialized
INFO - 2021-07-03 14:30:54 --> Model "Hesaplar_model" initialized
INFO - 2021-07-03 14:30:54 --> Controller Class Initialized
