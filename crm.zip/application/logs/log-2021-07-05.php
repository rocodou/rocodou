<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-07-05 07:48:55 --> Config Class Initialized
INFO - 2021-07-05 07:48:55 --> Hooks Class Initialized
DEBUG - 2021-07-05 07:48:55 --> UTF-8 Support Enabled
INFO - 2021-07-05 07:48:55 --> Utf8 Class Initialized
INFO - 2021-07-05 07:48:55 --> URI Class Initialized
INFO - 2021-07-05 07:48:55 --> Router Class Initialized
INFO - 2021-07-05 07:48:55 --> Output Class Initialized
INFO - 2021-07-05 07:48:55 --> Security Class Initialized
DEBUG - 2021-07-05 07:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 07:48:55 --> Input Class Initialized
INFO - 2021-07-05 07:48:55 --> Language Class Initialized
ERROR - 2021-07-05 07:48:55 --> 404 Page Not Found: DevMgmt/DiscoveryTree.xml
INFO - 2021-07-05 07:50:09 --> Config Class Initialized
INFO - 2021-07-05 07:50:09 --> Hooks Class Initialized
DEBUG - 2021-07-05 07:50:09 --> UTF-8 Support Enabled
INFO - 2021-07-05 07:50:09 --> Utf8 Class Initialized
INFO - 2021-07-05 07:50:09 --> URI Class Initialized
INFO - 2021-07-05 07:50:09 --> Router Class Initialized
INFO - 2021-07-05 07:50:09 --> Output Class Initialized
INFO - 2021-07-05 07:50:09 --> Security Class Initialized
DEBUG - 2021-07-05 07:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 07:50:09 --> Input Class Initialized
INFO - 2021-07-05 07:50:09 --> Language Class Initialized
ERROR - 2021-07-05 07:50:09 --> 404 Page Not Found: DevMgmt/DiscoveryTree.xml
INFO - 2021-07-05 08:21:54 --> Config Class Initialized
INFO - 2021-07-05 08:21:54 --> Hooks Class Initialized
DEBUG - 2021-07-05 08:21:54 --> UTF-8 Support Enabled
INFO - 2021-07-05 08:21:54 --> Utf8 Class Initialized
INFO - 2021-07-05 08:21:54 --> URI Class Initialized
DEBUG - 2021-07-05 08:21:54 --> No URI present. Default controller set.
INFO - 2021-07-05 08:21:54 --> Router Class Initialized
INFO - 2021-07-05 08:21:54 --> Output Class Initialized
INFO - 2021-07-05 08:21:54 --> Security Class Initialized
DEBUG - 2021-07-05 08:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 08:21:54 --> Input Class Initialized
INFO - 2021-07-05 08:21:54 --> Language Class Initialized
INFO - 2021-07-05 08:21:54 --> Loader Class Initialized
INFO - 2021-07-05 08:21:54 --> Helper loaded: basic_helper
INFO - 2021-07-05 08:21:54 --> Helper loaded: url_helper
INFO - 2021-07-05 08:21:54 --> Helper loaded: file_helper
INFO - 2021-07-05 08:21:54 --> Helper loaded: form_helper
INFO - 2021-07-05 08:21:54 --> Helper loaded: cookie_helper
INFO - 2021-07-05 08:21:54 --> Helper loaded: security_helper
INFO - 2021-07-05 08:21:54 --> Helper loaded: directory_helper
INFO - 2021-07-05 08:21:54 --> Helper loaded: language_helper
INFO - 2021-07-05 08:21:54 --> Helper loaded: general_helper
INFO - 2021-07-05 08:21:54 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 08:21:54 --> Database Driver Class Initialized
DEBUG - 2021-07-05 08:21:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 08:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 08:21:54 --> Parser Class Initialized
INFO - 2021-07-05 08:21:54 --> Form Validation Class Initialized
INFO - 2021-07-05 08:21:54 --> Upload Class Initialized
INFO - 2021-07-05 08:21:54 --> Email Class Initialized
INFO - 2021-07-05 08:21:54 --> MY_Model class loaded
INFO - 2021-07-05 08:21:54 --> Model "Users_model" initialized
INFO - 2021-07-05 08:21:54 --> Model "Settings_model" initialized
INFO - 2021-07-05 08:21:54 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 08:21:54 --> Model "Permissions_model" initialized
INFO - 2021-07-05 08:21:54 --> Model "Roles_model" initialized
INFO - 2021-07-05 08:21:54 --> Model "Activity_model" initialized
INFO - 2021-07-05 08:21:54 --> Model "Templates_model" initialized
INFO - 2021-07-05 08:21:54 --> Database Driver Class Initialized
INFO - 2021-07-05 08:21:54 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 08:21:54 --> Controller Class Initialized
INFO - 2021-07-05 09:22:41 --> Config Class Initialized
INFO - 2021-07-05 09:22:41 --> Hooks Class Initialized
DEBUG - 2021-07-05 09:22:41 --> UTF-8 Support Enabled
INFO - 2021-07-05 09:22:41 --> Utf8 Class Initialized
INFO - 2021-07-05 09:22:41 --> URI Class Initialized
INFO - 2021-07-05 09:22:41 --> Router Class Initialized
INFO - 2021-07-05 09:22:41 --> Output Class Initialized
INFO - 2021-07-05 09:22:41 --> Security Class Initialized
DEBUG - 2021-07-05 09:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 09:22:41 --> Input Class Initialized
INFO - 2021-07-05 09:22:41 --> Language Class Initialized
INFO - 2021-07-05 09:22:41 --> Loader Class Initialized
INFO - 2021-07-05 09:22:41 --> Helper loaded: basic_helper
INFO - 2021-07-05 09:22:41 --> Helper loaded: url_helper
INFO - 2021-07-05 09:22:41 --> Helper loaded: file_helper
INFO - 2021-07-05 09:22:41 --> Helper loaded: form_helper
INFO - 2021-07-05 09:22:41 --> Helper loaded: cookie_helper
INFO - 2021-07-05 09:22:41 --> Helper loaded: security_helper
INFO - 2021-07-05 09:22:41 --> Helper loaded: directory_helper
INFO - 2021-07-05 09:22:41 --> Helper loaded: language_helper
INFO - 2021-07-05 09:22:41 --> Helper loaded: general_helper
INFO - 2021-07-05 09:22:41 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 09:22:41 --> Database Driver Class Initialized
DEBUG - 2021-07-05 09:22:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 09:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 09:22:41 --> Parser Class Initialized
INFO - 2021-07-05 09:22:41 --> Form Validation Class Initialized
INFO - 2021-07-05 09:22:41 --> Upload Class Initialized
INFO - 2021-07-05 09:22:41 --> Email Class Initialized
INFO - 2021-07-05 09:22:41 --> MY_Model class loaded
INFO - 2021-07-05 09:22:41 --> Model "Users_model" initialized
INFO - 2021-07-05 09:22:41 --> Model "Settings_model" initialized
INFO - 2021-07-05 09:22:41 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 09:22:41 --> Model "Permissions_model" initialized
INFO - 2021-07-05 09:22:41 --> Model "Roles_model" initialized
INFO - 2021-07-05 09:22:41 --> Model "Activity_model" initialized
INFO - 2021-07-05 09:22:41 --> Model "Templates_model" initialized
INFO - 2021-07-05 09:22:41 --> Database Driver Class Initialized
INFO - 2021-07-05 09:22:41 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 09:22:41 --> Controller Class Initialized
ERROR - 2021-07-05 12:22:41 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 12:22:41 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-05 12:22:41 --> Final output sent to browser
DEBUG - 2021-07-05 12:22:41 --> Total execution time: 0.3077
INFO - 2021-07-05 09:22:55 --> Config Class Initialized
INFO - 2021-07-05 09:22:55 --> Hooks Class Initialized
DEBUG - 2021-07-05 09:22:55 --> UTF-8 Support Enabled
INFO - 2021-07-05 09:22:55 --> Utf8 Class Initialized
INFO - 2021-07-05 09:22:55 --> URI Class Initialized
INFO - 2021-07-05 09:22:55 --> Router Class Initialized
INFO - 2021-07-05 09:22:55 --> Output Class Initialized
INFO - 2021-07-05 09:22:55 --> Security Class Initialized
DEBUG - 2021-07-05 09:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 09:22:55 --> Input Class Initialized
INFO - 2021-07-05 09:22:55 --> Language Class Initialized
INFO - 2021-07-05 09:22:55 --> Loader Class Initialized
INFO - 2021-07-05 09:22:55 --> Helper loaded: basic_helper
INFO - 2021-07-05 09:22:55 --> Helper loaded: url_helper
INFO - 2021-07-05 09:22:55 --> Helper loaded: file_helper
INFO - 2021-07-05 09:22:55 --> Helper loaded: form_helper
INFO - 2021-07-05 09:22:55 --> Helper loaded: cookie_helper
INFO - 2021-07-05 09:22:55 --> Helper loaded: security_helper
INFO - 2021-07-05 09:22:55 --> Helper loaded: directory_helper
INFO - 2021-07-05 09:22:55 --> Helper loaded: language_helper
INFO - 2021-07-05 09:22:55 --> Helper loaded: general_helper
INFO - 2021-07-05 09:22:55 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 09:22:55 --> Database Driver Class Initialized
DEBUG - 2021-07-05 09:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 09:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 09:22:55 --> Parser Class Initialized
INFO - 2021-07-05 09:22:55 --> Form Validation Class Initialized
INFO - 2021-07-05 09:22:55 --> Upload Class Initialized
INFO - 2021-07-05 09:22:55 --> Email Class Initialized
INFO - 2021-07-05 09:22:55 --> MY_Model class loaded
INFO - 2021-07-05 09:22:55 --> Model "Users_model" initialized
INFO - 2021-07-05 09:22:55 --> Model "Settings_model" initialized
INFO - 2021-07-05 09:22:55 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 09:22:55 --> Model "Permissions_model" initialized
INFO - 2021-07-05 09:22:55 --> Model "Roles_model" initialized
INFO - 2021-07-05 09:22:55 --> Model "Activity_model" initialized
INFO - 2021-07-05 09:22:55 --> Model "Templates_model" initialized
INFO - 2021-07-05 09:22:55 --> Database Driver Class Initialized
INFO - 2021-07-05 09:22:56 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 09:22:56 --> Controller Class Initialized
ERROR - 2021-07-05 12:22:56 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 12:22:56 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 12:22:56 --> Final output sent to browser
DEBUG - 2021-07-05 12:22:56 --> Total execution time: 0.1316
INFO - 2021-07-05 09:31:42 --> Config Class Initialized
INFO - 2021-07-05 09:31:42 --> Hooks Class Initialized
DEBUG - 2021-07-05 09:31:42 --> UTF-8 Support Enabled
INFO - 2021-07-05 09:31:42 --> Utf8 Class Initialized
INFO - 2021-07-05 09:31:42 --> URI Class Initialized
DEBUG - 2021-07-05 09:31:42 --> No URI present. Default controller set.
INFO - 2021-07-05 09:31:42 --> Router Class Initialized
INFO - 2021-07-05 09:31:42 --> Output Class Initialized
INFO - 2021-07-05 09:31:42 --> Security Class Initialized
DEBUG - 2021-07-05 09:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 09:31:42 --> Input Class Initialized
INFO - 2021-07-05 09:31:42 --> Language Class Initialized
INFO - 2021-07-05 09:31:42 --> Loader Class Initialized
INFO - 2021-07-05 09:31:42 --> Helper loaded: basic_helper
INFO - 2021-07-05 09:31:42 --> Helper loaded: url_helper
INFO - 2021-07-05 09:31:42 --> Helper loaded: file_helper
INFO - 2021-07-05 09:31:42 --> Helper loaded: form_helper
INFO - 2021-07-05 09:31:42 --> Helper loaded: cookie_helper
INFO - 2021-07-05 09:31:42 --> Helper loaded: security_helper
INFO - 2021-07-05 09:31:42 --> Helper loaded: directory_helper
INFO - 2021-07-05 09:31:42 --> Helper loaded: language_helper
INFO - 2021-07-05 09:31:42 --> Helper loaded: general_helper
INFO - 2021-07-05 09:31:42 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 09:31:42 --> Database Driver Class Initialized
DEBUG - 2021-07-05 09:31:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 09:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 09:31:42 --> Parser Class Initialized
INFO - 2021-07-05 09:31:42 --> Form Validation Class Initialized
INFO - 2021-07-05 09:31:42 --> Upload Class Initialized
INFO - 2021-07-05 09:31:42 --> Email Class Initialized
INFO - 2021-07-05 09:31:42 --> MY_Model class loaded
INFO - 2021-07-05 09:31:42 --> Model "Users_model" initialized
INFO - 2021-07-05 09:31:42 --> Model "Settings_model" initialized
INFO - 2021-07-05 09:31:42 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 09:31:42 --> Model "Permissions_model" initialized
INFO - 2021-07-05 09:31:42 --> Model "Roles_model" initialized
INFO - 2021-07-05 09:31:42 --> Model "Activity_model" initialized
INFO - 2021-07-05 09:31:42 --> Model "Templates_model" initialized
INFO - 2021-07-05 09:31:42 --> Database Driver Class Initialized
INFO - 2021-07-05 09:31:42 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 09:31:42 --> Controller Class Initialized
INFO - 2021-07-05 10:31:43 --> Config Class Initialized
INFO - 2021-07-05 10:31:43 --> Hooks Class Initialized
DEBUG - 2021-07-05 10:31:43 --> UTF-8 Support Enabled
INFO - 2021-07-05 10:31:43 --> Utf8 Class Initialized
INFO - 2021-07-05 10:31:43 --> URI Class Initialized
DEBUG - 2021-07-05 10:31:43 --> No URI present. Default controller set.
INFO - 2021-07-05 10:31:43 --> Router Class Initialized
INFO - 2021-07-05 10:31:43 --> Output Class Initialized
INFO - 2021-07-05 10:31:43 --> Security Class Initialized
DEBUG - 2021-07-05 10:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 10:31:43 --> Input Class Initialized
INFO - 2021-07-05 10:31:43 --> Language Class Initialized
INFO - 2021-07-05 10:31:43 --> Loader Class Initialized
INFO - 2021-07-05 10:31:43 --> Helper loaded: basic_helper
INFO - 2021-07-05 10:31:43 --> Helper loaded: url_helper
INFO - 2021-07-05 10:31:43 --> Helper loaded: file_helper
INFO - 2021-07-05 10:31:43 --> Helper loaded: form_helper
INFO - 2021-07-05 10:31:43 --> Helper loaded: cookie_helper
INFO - 2021-07-05 10:31:43 --> Helper loaded: security_helper
INFO - 2021-07-05 10:31:43 --> Helper loaded: directory_helper
INFO - 2021-07-05 10:31:43 --> Helper loaded: language_helper
INFO - 2021-07-05 10:31:43 --> Helper loaded: general_helper
INFO - 2021-07-05 10:31:43 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 10:31:43 --> Database Driver Class Initialized
DEBUG - 2021-07-05 10:31:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 10:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 10:31:43 --> Parser Class Initialized
INFO - 2021-07-05 10:31:43 --> Form Validation Class Initialized
INFO - 2021-07-05 10:31:43 --> Upload Class Initialized
INFO - 2021-07-05 10:31:43 --> Email Class Initialized
INFO - 2021-07-05 10:31:43 --> MY_Model class loaded
INFO - 2021-07-05 10:31:43 --> Model "Users_model" initialized
INFO - 2021-07-05 10:31:43 --> Model "Settings_model" initialized
INFO - 2021-07-05 10:31:43 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 10:31:43 --> Model "Permissions_model" initialized
INFO - 2021-07-05 10:31:43 --> Model "Roles_model" initialized
INFO - 2021-07-05 10:31:43 --> Model "Activity_model" initialized
INFO - 2021-07-05 10:31:43 --> Model "Templates_model" initialized
INFO - 2021-07-05 10:31:43 --> Database Driver Class Initialized
INFO - 2021-07-05 10:31:43 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 10:31:43 --> Controller Class Initialized
INFO - 2021-07-05 11:43:47 --> Config Class Initialized
INFO - 2021-07-05 11:43:47 --> Hooks Class Initialized
DEBUG - 2021-07-05 11:43:47 --> UTF-8 Support Enabled
INFO - 2021-07-05 11:43:47 --> Utf8 Class Initialized
INFO - 2021-07-05 11:43:47 --> URI Class Initialized
DEBUG - 2021-07-05 11:43:47 --> No URI present. Default controller set.
INFO - 2021-07-05 11:43:47 --> Router Class Initialized
INFO - 2021-07-05 11:43:47 --> Output Class Initialized
INFO - 2021-07-05 11:43:47 --> Security Class Initialized
DEBUG - 2021-07-05 11:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 11:43:47 --> Input Class Initialized
INFO - 2021-07-05 11:43:47 --> Language Class Initialized
INFO - 2021-07-05 11:43:47 --> Loader Class Initialized
INFO - 2021-07-05 11:43:47 --> Helper loaded: basic_helper
INFO - 2021-07-05 11:43:47 --> Helper loaded: url_helper
INFO - 2021-07-05 11:43:47 --> Helper loaded: file_helper
INFO - 2021-07-05 11:43:47 --> Helper loaded: form_helper
INFO - 2021-07-05 11:43:47 --> Helper loaded: cookie_helper
INFO - 2021-07-05 11:43:47 --> Helper loaded: security_helper
INFO - 2021-07-05 11:43:47 --> Helper loaded: directory_helper
INFO - 2021-07-05 11:43:47 --> Helper loaded: language_helper
INFO - 2021-07-05 11:43:47 --> Helper loaded: general_helper
INFO - 2021-07-05 11:43:47 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 11:43:47 --> Database Driver Class Initialized
DEBUG - 2021-07-05 11:43:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 11:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 11:43:47 --> Parser Class Initialized
INFO - 2021-07-05 11:43:47 --> Form Validation Class Initialized
INFO - 2021-07-05 11:43:47 --> Upload Class Initialized
INFO - 2021-07-05 11:43:47 --> Email Class Initialized
INFO - 2021-07-05 11:43:47 --> MY_Model class loaded
INFO - 2021-07-05 11:43:47 --> Model "Users_model" initialized
INFO - 2021-07-05 11:43:47 --> Model "Settings_model" initialized
INFO - 2021-07-05 11:43:47 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 11:43:47 --> Model "Permissions_model" initialized
INFO - 2021-07-05 11:43:47 --> Model "Roles_model" initialized
INFO - 2021-07-05 11:43:47 --> Model "Activity_model" initialized
INFO - 2021-07-05 11:43:47 --> Model "Templates_model" initialized
INFO - 2021-07-05 11:43:47 --> Database Driver Class Initialized
INFO - 2021-07-05 11:43:47 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 11:43:47 --> Controller Class Initialized
INFO - 2021-07-05 12:55:43 --> Config Class Initialized
INFO - 2021-07-05 12:55:43 --> Hooks Class Initialized
DEBUG - 2021-07-05 12:55:43 --> UTF-8 Support Enabled
INFO - 2021-07-05 12:55:43 --> Utf8 Class Initialized
INFO - 2021-07-05 12:55:43 --> URI Class Initialized
DEBUG - 2021-07-05 12:55:43 --> No URI present. Default controller set.
INFO - 2021-07-05 12:55:43 --> Router Class Initialized
INFO - 2021-07-05 12:55:43 --> Output Class Initialized
INFO - 2021-07-05 12:55:43 --> Security Class Initialized
DEBUG - 2021-07-05 12:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 12:55:43 --> Input Class Initialized
INFO - 2021-07-05 12:55:43 --> Language Class Initialized
INFO - 2021-07-05 12:55:43 --> Loader Class Initialized
INFO - 2021-07-05 12:55:43 --> Helper loaded: basic_helper
INFO - 2021-07-05 12:55:43 --> Helper loaded: url_helper
INFO - 2021-07-05 12:55:43 --> Helper loaded: file_helper
INFO - 2021-07-05 12:55:43 --> Helper loaded: form_helper
INFO - 2021-07-05 12:55:43 --> Helper loaded: cookie_helper
INFO - 2021-07-05 12:55:43 --> Helper loaded: security_helper
INFO - 2021-07-05 12:55:43 --> Helper loaded: directory_helper
INFO - 2021-07-05 12:55:43 --> Helper loaded: language_helper
INFO - 2021-07-05 12:55:43 --> Helper loaded: general_helper
INFO - 2021-07-05 12:55:43 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 12:55:43 --> Database Driver Class Initialized
DEBUG - 2021-07-05 12:55:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 12:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 12:55:43 --> Parser Class Initialized
INFO - 2021-07-05 12:55:43 --> Form Validation Class Initialized
INFO - 2021-07-05 12:55:43 --> Upload Class Initialized
INFO - 2021-07-05 12:55:43 --> Email Class Initialized
INFO - 2021-07-05 12:55:43 --> MY_Model class loaded
INFO - 2021-07-05 12:55:43 --> Model "Users_model" initialized
INFO - 2021-07-05 12:55:43 --> Model "Settings_model" initialized
INFO - 2021-07-05 12:55:44 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 12:55:44 --> Model "Permissions_model" initialized
INFO - 2021-07-05 12:55:44 --> Model "Roles_model" initialized
INFO - 2021-07-05 12:55:44 --> Model "Activity_model" initialized
INFO - 2021-07-05 12:55:44 --> Model "Templates_model" initialized
INFO - 2021-07-05 12:55:44 --> Database Driver Class Initialized
INFO - 2021-07-05 12:55:44 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 12:55:44 --> Controller Class Initialized
INFO - 2021-07-05 13:23:52 --> Config Class Initialized
INFO - 2021-07-05 13:23:52 --> Hooks Class Initialized
DEBUG - 2021-07-05 13:23:52 --> UTF-8 Support Enabled
INFO - 2021-07-05 13:23:52 --> Utf8 Class Initialized
INFO - 2021-07-05 13:23:52 --> URI Class Initialized
DEBUG - 2021-07-05 13:23:52 --> No URI present. Default controller set.
INFO - 2021-07-05 13:23:52 --> Router Class Initialized
INFO - 2021-07-05 13:23:52 --> Output Class Initialized
INFO - 2021-07-05 13:23:52 --> Security Class Initialized
DEBUG - 2021-07-05 13:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 13:23:52 --> Input Class Initialized
INFO - 2021-07-05 13:23:52 --> Language Class Initialized
INFO - 2021-07-05 13:23:52 --> Loader Class Initialized
INFO - 2021-07-05 13:23:52 --> Helper loaded: basic_helper
INFO - 2021-07-05 13:23:52 --> Helper loaded: url_helper
INFO - 2021-07-05 13:23:52 --> Helper loaded: file_helper
INFO - 2021-07-05 13:23:52 --> Helper loaded: form_helper
INFO - 2021-07-05 13:23:52 --> Helper loaded: cookie_helper
INFO - 2021-07-05 13:23:52 --> Helper loaded: security_helper
INFO - 2021-07-05 13:23:52 --> Helper loaded: directory_helper
INFO - 2021-07-05 13:23:52 --> Helper loaded: language_helper
INFO - 2021-07-05 13:23:52 --> Helper loaded: general_helper
INFO - 2021-07-05 13:23:52 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 13:23:52 --> Database Driver Class Initialized
DEBUG - 2021-07-05 13:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 13:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 13:23:52 --> Parser Class Initialized
INFO - 2021-07-05 13:23:52 --> Form Validation Class Initialized
INFO - 2021-07-05 13:23:52 --> Upload Class Initialized
INFO - 2021-07-05 13:23:52 --> Email Class Initialized
INFO - 2021-07-05 13:23:52 --> MY_Model class loaded
INFO - 2021-07-05 13:23:52 --> Model "Users_model" initialized
INFO - 2021-07-05 13:23:52 --> Model "Settings_model" initialized
INFO - 2021-07-05 13:23:52 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 13:23:52 --> Model "Permissions_model" initialized
INFO - 2021-07-05 13:23:52 --> Model "Roles_model" initialized
INFO - 2021-07-05 13:23:52 --> Model "Activity_model" initialized
INFO - 2021-07-05 13:23:52 --> Model "Templates_model" initialized
INFO - 2021-07-05 13:23:52 --> Database Driver Class Initialized
INFO - 2021-07-05 13:23:52 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 13:23:52 --> Controller Class Initialized
ERROR - 2021-07-05 16:23:52 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 16:23:52 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-05 16:23:52 --> Final output sent to browser
DEBUG - 2021-07-05 16:23:52 --> Total execution time: 0.1220
INFO - 2021-07-05 13:23:54 --> Config Class Initialized
INFO - 2021-07-05 13:23:54 --> Hooks Class Initialized
DEBUG - 2021-07-05 13:23:54 --> UTF-8 Support Enabled
INFO - 2021-07-05 13:23:54 --> Utf8 Class Initialized
INFO - 2021-07-05 13:23:54 --> URI Class Initialized
INFO - 2021-07-05 13:23:54 --> Router Class Initialized
INFO - 2021-07-05 13:23:54 --> Output Class Initialized
INFO - 2021-07-05 13:23:54 --> Security Class Initialized
DEBUG - 2021-07-05 13:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 13:23:54 --> Input Class Initialized
INFO - 2021-07-05 13:23:54 --> Language Class Initialized
ERROR - 2021-07-05 13:23:54 --> 404 Page Not Found: Faviconico/index
INFO - 2021-07-05 13:23:56 --> Config Class Initialized
INFO - 2021-07-05 13:23:56 --> Hooks Class Initialized
DEBUG - 2021-07-05 13:23:56 --> UTF-8 Support Enabled
INFO - 2021-07-05 13:23:56 --> Utf8 Class Initialized
INFO - 2021-07-05 13:23:56 --> URI Class Initialized
INFO - 2021-07-05 13:23:56 --> Router Class Initialized
INFO - 2021-07-05 13:23:56 --> Output Class Initialized
INFO - 2021-07-05 13:23:56 --> Security Class Initialized
DEBUG - 2021-07-05 13:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 13:23:56 --> Input Class Initialized
INFO - 2021-07-05 13:23:56 --> Language Class Initialized
INFO - 2021-07-05 13:23:56 --> Loader Class Initialized
INFO - 2021-07-05 13:23:56 --> Helper loaded: basic_helper
INFO - 2021-07-05 13:23:56 --> Helper loaded: url_helper
INFO - 2021-07-05 13:23:56 --> Helper loaded: file_helper
INFO - 2021-07-05 13:23:56 --> Helper loaded: form_helper
INFO - 2021-07-05 13:23:56 --> Helper loaded: cookie_helper
INFO - 2021-07-05 13:23:56 --> Helper loaded: security_helper
INFO - 2021-07-05 13:23:56 --> Helper loaded: directory_helper
INFO - 2021-07-05 13:23:56 --> Helper loaded: language_helper
INFO - 2021-07-05 13:23:56 --> Helper loaded: general_helper
INFO - 2021-07-05 13:23:56 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 13:23:56 --> Database Driver Class Initialized
DEBUG - 2021-07-05 13:23:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 13:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 13:23:56 --> Parser Class Initialized
INFO - 2021-07-05 13:23:56 --> Form Validation Class Initialized
INFO - 2021-07-05 13:23:56 --> Upload Class Initialized
INFO - 2021-07-05 13:23:56 --> Email Class Initialized
INFO - 2021-07-05 13:23:56 --> MY_Model class loaded
INFO - 2021-07-05 13:23:56 --> Model "Users_model" initialized
INFO - 2021-07-05 13:23:56 --> Model "Settings_model" initialized
INFO - 2021-07-05 13:23:56 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 13:23:56 --> Model "Permissions_model" initialized
INFO - 2021-07-05 13:23:56 --> Model "Roles_model" initialized
INFO - 2021-07-05 13:23:56 --> Model "Activity_model" initialized
INFO - 2021-07-05 13:23:56 --> Model "Templates_model" initialized
INFO - 2021-07-05 13:23:56 --> Database Driver Class Initialized
INFO - 2021-07-05 13:23:57 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 13:23:57 --> Controller Class Initialized
ERROR - 2021-07-05 16:23:57 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 16:23:57 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-05 16:23:57 --> Final output sent to browser
DEBUG - 2021-07-05 16:23:57 --> Total execution time: 0.3381
INFO - 2021-07-05 13:24:05 --> Config Class Initialized
INFO - 2021-07-05 13:24:05 --> Hooks Class Initialized
DEBUG - 2021-07-05 13:24:05 --> UTF-8 Support Enabled
INFO - 2021-07-05 13:24:05 --> Utf8 Class Initialized
INFO - 2021-07-05 13:24:05 --> URI Class Initialized
INFO - 2021-07-05 13:24:05 --> Router Class Initialized
INFO - 2021-07-05 13:24:05 --> Output Class Initialized
INFO - 2021-07-05 13:24:05 --> Security Class Initialized
DEBUG - 2021-07-05 13:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 13:24:05 --> Input Class Initialized
INFO - 2021-07-05 13:24:05 --> Language Class Initialized
INFO - 2021-07-05 13:24:05 --> Loader Class Initialized
INFO - 2021-07-05 13:24:05 --> Helper loaded: basic_helper
INFO - 2021-07-05 13:24:05 --> Helper loaded: url_helper
INFO - 2021-07-05 13:24:05 --> Helper loaded: file_helper
INFO - 2021-07-05 13:24:05 --> Helper loaded: form_helper
INFO - 2021-07-05 13:24:05 --> Helper loaded: cookie_helper
INFO - 2021-07-05 13:24:05 --> Helper loaded: security_helper
INFO - 2021-07-05 13:24:05 --> Helper loaded: directory_helper
INFO - 2021-07-05 13:24:05 --> Helper loaded: language_helper
INFO - 2021-07-05 13:24:05 --> Helper loaded: general_helper
INFO - 2021-07-05 13:24:05 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 13:24:05 --> Database Driver Class Initialized
DEBUG - 2021-07-05 13:24:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 13:24:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 13:24:05 --> Parser Class Initialized
INFO - 2021-07-05 13:24:05 --> Form Validation Class Initialized
INFO - 2021-07-05 13:24:05 --> Upload Class Initialized
INFO - 2021-07-05 13:24:05 --> Email Class Initialized
INFO - 2021-07-05 13:24:05 --> MY_Model class loaded
INFO - 2021-07-05 13:24:05 --> Model "Users_model" initialized
INFO - 2021-07-05 13:24:05 --> Model "Settings_model" initialized
INFO - 2021-07-05 13:24:05 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 13:24:05 --> Model "Permissions_model" initialized
INFO - 2021-07-05 13:24:05 --> Model "Roles_model" initialized
INFO - 2021-07-05 13:24:05 --> Model "Activity_model" initialized
INFO - 2021-07-05 13:24:05 --> Model "Templates_model" initialized
INFO - 2021-07-05 13:24:05 --> Database Driver Class Initialized
INFO - 2021-07-05 13:24:05 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 13:24:05 --> Controller Class Initialized
ERROR - 2021-07-05 16:24:05 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-05 16:24:05 --> Invalid query: 
INFO - 2021-07-05 16:24:05 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-05 16:24:05 --> Final output sent to browser
DEBUG - 2021-07-05 16:24:05 --> Total execution time: 0.1320
INFO - 2021-07-05 13:24:16 --> Config Class Initialized
INFO - 2021-07-05 13:24:16 --> Hooks Class Initialized
DEBUG - 2021-07-05 13:24:16 --> UTF-8 Support Enabled
INFO - 2021-07-05 13:24:16 --> Utf8 Class Initialized
INFO - 2021-07-05 13:24:16 --> URI Class Initialized
INFO - 2021-07-05 13:24:16 --> Router Class Initialized
INFO - 2021-07-05 13:24:16 --> Output Class Initialized
INFO - 2021-07-05 13:24:16 --> Security Class Initialized
DEBUG - 2021-07-05 13:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 13:24:16 --> Input Class Initialized
INFO - 2021-07-05 13:24:16 --> Language Class Initialized
INFO - 2021-07-05 13:24:16 --> Loader Class Initialized
INFO - 2021-07-05 13:24:16 --> Helper loaded: basic_helper
INFO - 2021-07-05 13:24:16 --> Helper loaded: url_helper
INFO - 2021-07-05 13:24:16 --> Helper loaded: file_helper
INFO - 2021-07-05 13:24:16 --> Helper loaded: form_helper
INFO - 2021-07-05 13:24:16 --> Helper loaded: cookie_helper
INFO - 2021-07-05 13:24:16 --> Helper loaded: security_helper
INFO - 2021-07-05 13:24:16 --> Helper loaded: directory_helper
INFO - 2021-07-05 13:24:16 --> Helper loaded: language_helper
INFO - 2021-07-05 13:24:16 --> Helper loaded: general_helper
INFO - 2021-07-05 13:24:16 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 13:24:16 --> Database Driver Class Initialized
DEBUG - 2021-07-05 13:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 13:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 13:24:16 --> Parser Class Initialized
INFO - 2021-07-05 13:24:16 --> Form Validation Class Initialized
INFO - 2021-07-05 13:24:16 --> Upload Class Initialized
INFO - 2021-07-05 13:24:16 --> Email Class Initialized
INFO - 2021-07-05 13:24:16 --> MY_Model class loaded
INFO - 2021-07-05 13:24:16 --> Model "Users_model" initialized
INFO - 2021-07-05 13:24:16 --> Model "Settings_model" initialized
INFO - 2021-07-05 13:24:16 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 13:24:16 --> Model "Permissions_model" initialized
INFO - 2021-07-05 13:24:16 --> Model "Roles_model" initialized
INFO - 2021-07-05 13:24:16 --> Model "Activity_model" initialized
INFO - 2021-07-05 13:24:16 --> Model "Templates_model" initialized
INFO - 2021-07-05 13:24:16 --> Database Driver Class Initialized
INFO - 2021-07-05 13:24:16 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 13:24:16 --> Controller Class Initialized
ERROR - 2021-07-05 16:24:16 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 16:24:16 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-05 16:24:16 --> Final output sent to browser
DEBUG - 2021-07-05 16:24:16 --> Total execution time: 0.2808
INFO - 2021-07-05 13:24:22 --> Config Class Initialized
INFO - 2021-07-05 13:24:22 --> Hooks Class Initialized
DEBUG - 2021-07-05 13:24:22 --> UTF-8 Support Enabled
INFO - 2021-07-05 13:24:22 --> Utf8 Class Initialized
INFO - 2021-07-05 13:24:22 --> URI Class Initialized
INFO - 2021-07-05 13:24:22 --> Router Class Initialized
INFO - 2021-07-05 13:24:22 --> Output Class Initialized
INFO - 2021-07-05 13:24:22 --> Security Class Initialized
DEBUG - 2021-07-05 13:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 13:24:22 --> Input Class Initialized
INFO - 2021-07-05 13:24:22 --> Language Class Initialized
INFO - 2021-07-05 13:24:22 --> Loader Class Initialized
INFO - 2021-07-05 13:24:22 --> Helper loaded: basic_helper
INFO - 2021-07-05 13:24:22 --> Helper loaded: url_helper
INFO - 2021-07-05 13:24:22 --> Helper loaded: file_helper
INFO - 2021-07-05 13:24:22 --> Helper loaded: form_helper
INFO - 2021-07-05 13:24:22 --> Helper loaded: cookie_helper
INFO - 2021-07-05 13:24:22 --> Helper loaded: security_helper
INFO - 2021-07-05 13:24:22 --> Helper loaded: directory_helper
INFO - 2021-07-05 13:24:22 --> Helper loaded: language_helper
INFO - 2021-07-05 13:24:22 --> Helper loaded: general_helper
INFO - 2021-07-05 13:24:22 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 13:24:22 --> Database Driver Class Initialized
DEBUG - 2021-07-05 13:24:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 13:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 13:24:22 --> Parser Class Initialized
INFO - 2021-07-05 13:24:22 --> Form Validation Class Initialized
INFO - 2021-07-05 13:24:22 --> Upload Class Initialized
INFO - 2021-07-05 13:24:22 --> Email Class Initialized
INFO - 2021-07-05 13:24:22 --> MY_Model class loaded
INFO - 2021-07-05 13:24:22 --> Model "Users_model" initialized
INFO - 2021-07-05 13:24:22 --> Model "Settings_model" initialized
INFO - 2021-07-05 13:24:22 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 13:24:22 --> Model "Permissions_model" initialized
INFO - 2021-07-05 13:24:22 --> Model "Roles_model" initialized
INFO - 2021-07-05 13:24:22 --> Model "Activity_model" initialized
INFO - 2021-07-05 13:24:22 --> Model "Templates_model" initialized
INFO - 2021-07-05 13:24:22 --> Database Driver Class Initialized
INFO - 2021-07-05 13:24:22 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 13:24:22 --> Controller Class Initialized
ERROR - 2021-07-05 16:24:22 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 16:24:22 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 16:24:22 --> Final output sent to browser
DEBUG - 2021-07-05 16:24:22 --> Total execution time: 0.1354
INFO - 2021-07-05 13:24:32 --> Config Class Initialized
INFO - 2021-07-05 13:24:32 --> Hooks Class Initialized
DEBUG - 2021-07-05 13:24:32 --> UTF-8 Support Enabled
INFO - 2021-07-05 13:24:32 --> Utf8 Class Initialized
INFO - 2021-07-05 13:24:32 --> URI Class Initialized
INFO - 2021-07-05 13:24:32 --> Router Class Initialized
INFO - 2021-07-05 13:24:32 --> Output Class Initialized
INFO - 2021-07-05 13:24:32 --> Security Class Initialized
DEBUG - 2021-07-05 13:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 13:24:32 --> Input Class Initialized
INFO - 2021-07-05 13:24:32 --> Language Class Initialized
INFO - 2021-07-05 13:24:32 --> Loader Class Initialized
INFO - 2021-07-05 13:24:32 --> Helper loaded: basic_helper
INFO - 2021-07-05 13:24:32 --> Helper loaded: url_helper
INFO - 2021-07-05 13:24:32 --> Helper loaded: file_helper
INFO - 2021-07-05 13:24:32 --> Helper loaded: form_helper
INFO - 2021-07-05 13:24:32 --> Helper loaded: cookie_helper
INFO - 2021-07-05 13:24:32 --> Helper loaded: security_helper
INFO - 2021-07-05 13:24:32 --> Helper loaded: directory_helper
INFO - 2021-07-05 13:24:32 --> Helper loaded: language_helper
INFO - 2021-07-05 13:24:32 --> Helper loaded: general_helper
INFO - 2021-07-05 13:24:32 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 13:24:32 --> Database Driver Class Initialized
DEBUG - 2021-07-05 13:24:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 13:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 13:24:32 --> Parser Class Initialized
INFO - 2021-07-05 13:24:32 --> Form Validation Class Initialized
INFO - 2021-07-05 13:24:32 --> Upload Class Initialized
INFO - 2021-07-05 13:24:32 --> Email Class Initialized
INFO - 2021-07-05 13:24:32 --> MY_Model class loaded
INFO - 2021-07-05 13:24:32 --> Model "Users_model" initialized
INFO - 2021-07-05 13:24:32 --> Model "Settings_model" initialized
INFO - 2021-07-05 13:24:32 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 13:24:32 --> Model "Permissions_model" initialized
INFO - 2021-07-05 13:24:32 --> Model "Roles_model" initialized
INFO - 2021-07-05 13:24:32 --> Model "Activity_model" initialized
INFO - 2021-07-05 13:24:32 --> Model "Templates_model" initialized
INFO - 2021-07-05 13:24:32 --> Database Driver Class Initialized
INFO - 2021-07-05 13:24:32 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 13:24:32 --> Controller Class Initialized
ERROR - 2021-07-05 16:24:32 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 16:24:33 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-05 16:24:33 --> Final output sent to browser
DEBUG - 2021-07-05 16:24:33 --> Total execution time: 0.2308
INFO - 2021-07-05 13:24:34 --> Config Class Initialized
INFO - 2021-07-05 13:24:34 --> Hooks Class Initialized
DEBUG - 2021-07-05 13:24:34 --> UTF-8 Support Enabled
INFO - 2021-07-05 13:24:34 --> Utf8 Class Initialized
INFO - 2021-07-05 13:24:34 --> URI Class Initialized
INFO - 2021-07-05 13:24:34 --> Router Class Initialized
INFO - 2021-07-05 13:24:34 --> Output Class Initialized
INFO - 2021-07-05 13:24:34 --> Security Class Initialized
DEBUG - 2021-07-05 13:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 13:24:34 --> Input Class Initialized
INFO - 2021-07-05 13:24:34 --> Language Class Initialized
INFO - 2021-07-05 13:24:34 --> Loader Class Initialized
INFO - 2021-07-05 13:24:34 --> Helper loaded: basic_helper
INFO - 2021-07-05 13:24:34 --> Helper loaded: url_helper
INFO - 2021-07-05 13:24:34 --> Helper loaded: file_helper
INFO - 2021-07-05 13:24:34 --> Helper loaded: form_helper
INFO - 2021-07-05 13:24:34 --> Helper loaded: cookie_helper
INFO - 2021-07-05 13:24:34 --> Helper loaded: security_helper
INFO - 2021-07-05 13:24:34 --> Helper loaded: directory_helper
INFO - 2021-07-05 13:24:34 --> Helper loaded: language_helper
INFO - 2021-07-05 13:24:34 --> Helper loaded: general_helper
INFO - 2021-07-05 13:24:34 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 13:24:34 --> Database Driver Class Initialized
DEBUG - 2021-07-05 13:24:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 13:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 13:24:34 --> Parser Class Initialized
INFO - 2021-07-05 13:24:34 --> Form Validation Class Initialized
INFO - 2021-07-05 13:24:34 --> Upload Class Initialized
INFO - 2021-07-05 13:24:34 --> Email Class Initialized
INFO - 2021-07-05 13:24:34 --> MY_Model class loaded
INFO - 2021-07-05 13:24:34 --> Model "Users_model" initialized
INFO - 2021-07-05 13:24:34 --> Model "Settings_model" initialized
INFO - 2021-07-05 13:24:34 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 13:24:34 --> Model "Permissions_model" initialized
INFO - 2021-07-05 13:24:34 --> Model "Roles_model" initialized
INFO - 2021-07-05 13:24:34 --> Model "Activity_model" initialized
INFO - 2021-07-05 13:24:34 --> Model "Templates_model" initialized
INFO - 2021-07-05 13:24:34 --> Database Driver Class Initialized
INFO - 2021-07-05 13:24:34 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 13:24:34 --> Controller Class Initialized
ERROR - 2021-07-05 16:24:34 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-05 16:24:34 --> Invalid query: 
INFO - 2021-07-05 16:24:34 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-05 16:24:34 --> Final output sent to browser
DEBUG - 2021-07-05 16:24:34 --> Total execution time: 0.0658
INFO - 2021-07-05 13:25:08 --> Config Class Initialized
INFO - 2021-07-05 13:25:08 --> Hooks Class Initialized
DEBUG - 2021-07-05 13:25:08 --> UTF-8 Support Enabled
INFO - 2021-07-05 13:25:08 --> Utf8 Class Initialized
INFO - 2021-07-05 13:25:08 --> URI Class Initialized
INFO - 2021-07-05 13:25:08 --> Router Class Initialized
INFO - 2021-07-05 13:25:08 --> Output Class Initialized
INFO - 2021-07-05 13:25:08 --> Security Class Initialized
DEBUG - 2021-07-05 13:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 13:25:08 --> Input Class Initialized
INFO - 2021-07-05 13:25:08 --> Language Class Initialized
INFO - 2021-07-05 13:25:08 --> Loader Class Initialized
INFO - 2021-07-05 13:25:08 --> Helper loaded: basic_helper
INFO - 2021-07-05 13:25:08 --> Helper loaded: url_helper
INFO - 2021-07-05 13:25:08 --> Helper loaded: file_helper
INFO - 2021-07-05 13:25:08 --> Helper loaded: form_helper
INFO - 2021-07-05 13:25:08 --> Helper loaded: cookie_helper
INFO - 2021-07-05 13:25:08 --> Helper loaded: security_helper
INFO - 2021-07-05 13:25:08 --> Helper loaded: directory_helper
INFO - 2021-07-05 13:25:08 --> Helper loaded: language_helper
INFO - 2021-07-05 13:25:08 --> Helper loaded: general_helper
INFO - 2021-07-05 13:25:08 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 13:25:08 --> Database Driver Class Initialized
DEBUG - 2021-07-05 13:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 13:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 13:25:08 --> Parser Class Initialized
INFO - 2021-07-05 13:25:08 --> Form Validation Class Initialized
INFO - 2021-07-05 13:25:08 --> Upload Class Initialized
INFO - 2021-07-05 13:25:08 --> Email Class Initialized
INFO - 2021-07-05 13:25:08 --> MY_Model class loaded
INFO - 2021-07-05 13:25:08 --> Model "Users_model" initialized
INFO - 2021-07-05 13:25:08 --> Model "Settings_model" initialized
INFO - 2021-07-05 13:25:08 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 13:25:08 --> Model "Permissions_model" initialized
INFO - 2021-07-05 13:25:08 --> Model "Roles_model" initialized
INFO - 2021-07-05 13:25:08 --> Model "Activity_model" initialized
INFO - 2021-07-05 13:25:08 --> Model "Templates_model" initialized
INFO - 2021-07-05 13:25:08 --> Database Driver Class Initialized
INFO - 2021-07-05 13:25:08 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 13:25:08 --> Controller Class Initialized
ERROR - 2021-07-05 16:25:08 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 16:25:08 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-05 16:25:08 --> Final output sent to browser
DEBUG - 2021-07-05 16:25:08 --> Total execution time: 0.2342
INFO - 2021-07-05 13:25:17 --> Config Class Initialized
INFO - 2021-07-05 13:25:17 --> Hooks Class Initialized
DEBUG - 2021-07-05 13:25:17 --> UTF-8 Support Enabled
INFO - 2021-07-05 13:25:17 --> Utf8 Class Initialized
INFO - 2021-07-05 13:25:17 --> URI Class Initialized
INFO - 2021-07-05 13:25:17 --> Router Class Initialized
INFO - 2021-07-05 13:25:17 --> Output Class Initialized
INFO - 2021-07-05 13:25:17 --> Security Class Initialized
DEBUG - 2021-07-05 13:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 13:25:17 --> Input Class Initialized
INFO - 2021-07-05 13:25:17 --> Language Class Initialized
INFO - 2021-07-05 13:25:17 --> Loader Class Initialized
INFO - 2021-07-05 13:25:17 --> Helper loaded: basic_helper
INFO - 2021-07-05 13:25:17 --> Helper loaded: url_helper
INFO - 2021-07-05 13:25:17 --> Helper loaded: file_helper
INFO - 2021-07-05 13:25:17 --> Helper loaded: form_helper
INFO - 2021-07-05 13:25:17 --> Helper loaded: cookie_helper
INFO - 2021-07-05 13:25:17 --> Helper loaded: security_helper
INFO - 2021-07-05 13:25:17 --> Helper loaded: directory_helper
INFO - 2021-07-05 13:25:17 --> Helper loaded: language_helper
INFO - 2021-07-05 13:25:17 --> Helper loaded: general_helper
INFO - 2021-07-05 13:25:17 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 13:25:17 --> Database Driver Class Initialized
DEBUG - 2021-07-05 13:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 13:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 13:25:17 --> Parser Class Initialized
INFO - 2021-07-05 13:25:17 --> Form Validation Class Initialized
INFO - 2021-07-05 13:25:17 --> Upload Class Initialized
INFO - 2021-07-05 13:25:17 --> Email Class Initialized
INFO - 2021-07-05 13:25:17 --> MY_Model class loaded
INFO - 2021-07-05 13:25:17 --> Model "Users_model" initialized
INFO - 2021-07-05 13:25:17 --> Model "Settings_model" initialized
INFO - 2021-07-05 13:25:17 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 13:25:17 --> Model "Permissions_model" initialized
INFO - 2021-07-05 13:25:17 --> Model "Roles_model" initialized
INFO - 2021-07-05 13:25:17 --> Model "Activity_model" initialized
INFO - 2021-07-05 13:25:17 --> Model "Templates_model" initialized
INFO - 2021-07-05 13:25:17 --> Database Driver Class Initialized
INFO - 2021-07-05 13:25:17 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 13:25:17 --> Controller Class Initialized
ERROR - 2021-07-05 16:25:17 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 16:25:17 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 16:25:17 --> Final output sent to browser
DEBUG - 2021-07-05 16:25:17 --> Total execution time: 0.1263
INFO - 2021-07-05 13:25:19 --> Config Class Initialized
INFO - 2021-07-05 13:25:19 --> Hooks Class Initialized
DEBUG - 2021-07-05 13:25:19 --> UTF-8 Support Enabled
INFO - 2021-07-05 13:25:19 --> Utf8 Class Initialized
INFO - 2021-07-05 13:25:19 --> URI Class Initialized
INFO - 2021-07-05 13:25:19 --> Router Class Initialized
INFO - 2021-07-05 13:25:19 --> Output Class Initialized
INFO - 2021-07-05 13:25:19 --> Security Class Initialized
DEBUG - 2021-07-05 13:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 13:25:19 --> Input Class Initialized
INFO - 2021-07-05 13:25:19 --> Language Class Initialized
INFO - 2021-07-05 13:25:19 --> Loader Class Initialized
INFO - 2021-07-05 13:25:19 --> Helper loaded: basic_helper
INFO - 2021-07-05 13:25:19 --> Helper loaded: url_helper
INFO - 2021-07-05 13:25:19 --> Helper loaded: file_helper
INFO - 2021-07-05 13:25:19 --> Helper loaded: form_helper
INFO - 2021-07-05 13:25:19 --> Helper loaded: cookie_helper
INFO - 2021-07-05 13:25:19 --> Helper loaded: security_helper
INFO - 2021-07-05 13:25:19 --> Helper loaded: directory_helper
INFO - 2021-07-05 13:25:19 --> Helper loaded: language_helper
INFO - 2021-07-05 13:25:19 --> Helper loaded: general_helper
INFO - 2021-07-05 13:25:19 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 13:25:19 --> Database Driver Class Initialized
DEBUG - 2021-07-05 13:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 13:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 13:25:19 --> Parser Class Initialized
INFO - 2021-07-05 13:25:19 --> Form Validation Class Initialized
INFO - 2021-07-05 13:25:19 --> Upload Class Initialized
INFO - 2021-07-05 13:25:19 --> Email Class Initialized
INFO - 2021-07-05 13:25:19 --> MY_Model class loaded
INFO - 2021-07-05 13:25:19 --> Model "Users_model" initialized
INFO - 2021-07-05 13:25:19 --> Model "Settings_model" initialized
INFO - 2021-07-05 13:25:19 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 13:25:19 --> Model "Permissions_model" initialized
INFO - 2021-07-05 13:25:19 --> Model "Roles_model" initialized
INFO - 2021-07-05 13:25:19 --> Model "Activity_model" initialized
INFO - 2021-07-05 13:25:19 --> Model "Templates_model" initialized
INFO - 2021-07-05 13:25:19 --> Database Driver Class Initialized
INFO - 2021-07-05 13:25:19 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 13:25:19 --> Controller Class Initialized
ERROR - 2021-07-05 16:25:19 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 16:25:19 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-05 16:25:19 --> Final output sent to browser
DEBUG - 2021-07-05 16:25:19 --> Total execution time: 0.1746
INFO - 2021-07-05 13:25:20 --> Config Class Initialized
INFO - 2021-07-05 13:25:20 --> Hooks Class Initialized
DEBUG - 2021-07-05 13:25:20 --> UTF-8 Support Enabled
INFO - 2021-07-05 13:25:20 --> Utf8 Class Initialized
INFO - 2021-07-05 13:25:20 --> URI Class Initialized
INFO - 2021-07-05 13:25:20 --> Router Class Initialized
INFO - 2021-07-05 13:25:20 --> Output Class Initialized
INFO - 2021-07-05 13:25:20 --> Security Class Initialized
DEBUG - 2021-07-05 13:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 13:25:20 --> Input Class Initialized
INFO - 2021-07-05 13:25:20 --> Language Class Initialized
INFO - 2021-07-05 13:25:20 --> Loader Class Initialized
INFO - 2021-07-05 13:25:20 --> Helper loaded: basic_helper
INFO - 2021-07-05 13:25:20 --> Helper loaded: url_helper
INFO - 2021-07-05 13:25:20 --> Helper loaded: file_helper
INFO - 2021-07-05 13:25:20 --> Helper loaded: form_helper
INFO - 2021-07-05 13:25:20 --> Helper loaded: cookie_helper
INFO - 2021-07-05 13:25:20 --> Helper loaded: security_helper
INFO - 2021-07-05 13:25:20 --> Helper loaded: directory_helper
INFO - 2021-07-05 13:25:20 --> Helper loaded: language_helper
INFO - 2021-07-05 13:25:20 --> Helper loaded: general_helper
INFO - 2021-07-05 13:25:20 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 13:25:20 --> Database Driver Class Initialized
DEBUG - 2021-07-05 13:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 13:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 13:25:20 --> Parser Class Initialized
INFO - 2021-07-05 13:25:20 --> Form Validation Class Initialized
INFO - 2021-07-05 13:25:20 --> Upload Class Initialized
INFO - 2021-07-05 13:25:20 --> Email Class Initialized
INFO - 2021-07-05 13:25:20 --> MY_Model class loaded
INFO - 2021-07-05 13:25:20 --> Model "Users_model" initialized
INFO - 2021-07-05 13:25:20 --> Model "Settings_model" initialized
INFO - 2021-07-05 13:25:20 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 13:25:20 --> Model "Permissions_model" initialized
INFO - 2021-07-05 13:25:20 --> Model "Roles_model" initialized
INFO - 2021-07-05 13:25:20 --> Model "Activity_model" initialized
INFO - 2021-07-05 13:25:20 --> Model "Templates_model" initialized
INFO - 2021-07-05 13:25:20 --> Database Driver Class Initialized
INFO - 2021-07-05 13:25:20 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 13:25:20 --> Controller Class Initialized
ERROR - 2021-07-05 16:25:20 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 16:25:20 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 16:25:20 --> Final output sent to browser
DEBUG - 2021-07-05 16:25:20 --> Total execution time: 0.0585
INFO - 2021-07-05 13:25:22 --> Config Class Initialized
INFO - 2021-07-05 13:25:22 --> Hooks Class Initialized
DEBUG - 2021-07-05 13:25:22 --> UTF-8 Support Enabled
INFO - 2021-07-05 13:25:22 --> Utf8 Class Initialized
INFO - 2021-07-05 13:25:22 --> URI Class Initialized
INFO - 2021-07-05 13:25:22 --> Router Class Initialized
INFO - 2021-07-05 13:25:22 --> Output Class Initialized
INFO - 2021-07-05 13:25:22 --> Security Class Initialized
DEBUG - 2021-07-05 13:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 13:25:22 --> Input Class Initialized
INFO - 2021-07-05 13:25:22 --> Language Class Initialized
INFO - 2021-07-05 13:25:22 --> Loader Class Initialized
INFO - 2021-07-05 13:25:22 --> Helper loaded: basic_helper
INFO - 2021-07-05 13:25:22 --> Helper loaded: url_helper
INFO - 2021-07-05 13:25:22 --> Helper loaded: file_helper
INFO - 2021-07-05 13:25:22 --> Helper loaded: form_helper
INFO - 2021-07-05 13:25:22 --> Helper loaded: cookie_helper
INFO - 2021-07-05 13:25:22 --> Helper loaded: security_helper
INFO - 2021-07-05 13:25:22 --> Helper loaded: directory_helper
INFO - 2021-07-05 13:25:22 --> Helper loaded: language_helper
INFO - 2021-07-05 13:25:22 --> Helper loaded: general_helper
INFO - 2021-07-05 13:25:22 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 13:25:22 --> Database Driver Class Initialized
DEBUG - 2021-07-05 13:25:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 13:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 13:25:22 --> Parser Class Initialized
INFO - 2021-07-05 13:25:22 --> Form Validation Class Initialized
INFO - 2021-07-05 13:25:22 --> Upload Class Initialized
INFO - 2021-07-05 13:25:22 --> Email Class Initialized
INFO - 2021-07-05 13:25:22 --> MY_Model class loaded
INFO - 2021-07-05 13:25:22 --> Model "Users_model" initialized
INFO - 2021-07-05 13:25:22 --> Model "Settings_model" initialized
INFO - 2021-07-05 13:25:22 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 13:25:22 --> Model "Permissions_model" initialized
INFO - 2021-07-05 13:25:22 --> Model "Roles_model" initialized
INFO - 2021-07-05 13:25:22 --> Model "Activity_model" initialized
INFO - 2021-07-05 13:25:22 --> Model "Templates_model" initialized
INFO - 2021-07-05 13:25:22 --> Database Driver Class Initialized
INFO - 2021-07-05 13:25:22 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 13:25:22 --> Controller Class Initialized
ERROR - 2021-07-05 16:25:22 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 16:25:22 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-05 16:25:22 --> Final output sent to browser
DEBUG - 2021-07-05 16:25:22 --> Total execution time: 0.2873
INFO - 2021-07-05 13:25:24 --> Config Class Initialized
INFO - 2021-07-05 13:25:24 --> Hooks Class Initialized
DEBUG - 2021-07-05 13:25:24 --> UTF-8 Support Enabled
INFO - 2021-07-05 13:25:24 --> Utf8 Class Initialized
INFO - 2021-07-05 13:25:24 --> URI Class Initialized
INFO - 2021-07-05 13:25:24 --> Router Class Initialized
INFO - 2021-07-05 13:25:24 --> Output Class Initialized
INFO - 2021-07-05 13:25:24 --> Security Class Initialized
DEBUG - 2021-07-05 13:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 13:25:24 --> Input Class Initialized
INFO - 2021-07-05 13:25:24 --> Language Class Initialized
INFO - 2021-07-05 13:25:24 --> Loader Class Initialized
INFO - 2021-07-05 13:25:24 --> Helper loaded: basic_helper
INFO - 2021-07-05 13:25:24 --> Helper loaded: url_helper
INFO - 2021-07-05 13:25:24 --> Helper loaded: file_helper
INFO - 2021-07-05 13:25:24 --> Helper loaded: form_helper
INFO - 2021-07-05 13:25:24 --> Helper loaded: cookie_helper
INFO - 2021-07-05 13:25:24 --> Helper loaded: security_helper
INFO - 2021-07-05 13:25:24 --> Helper loaded: directory_helper
INFO - 2021-07-05 13:25:24 --> Helper loaded: language_helper
INFO - 2021-07-05 13:25:24 --> Helper loaded: general_helper
INFO - 2021-07-05 13:25:24 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 13:25:24 --> Database Driver Class Initialized
DEBUG - 2021-07-05 13:25:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 13:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 13:25:24 --> Parser Class Initialized
INFO - 2021-07-05 13:25:24 --> Form Validation Class Initialized
INFO - 2021-07-05 13:25:24 --> Upload Class Initialized
INFO - 2021-07-05 13:25:24 --> Email Class Initialized
INFO - 2021-07-05 13:25:24 --> MY_Model class loaded
INFO - 2021-07-05 13:25:24 --> Model "Users_model" initialized
INFO - 2021-07-05 13:25:24 --> Model "Settings_model" initialized
INFO - 2021-07-05 13:25:24 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 13:25:24 --> Model "Permissions_model" initialized
INFO - 2021-07-05 13:25:24 --> Model "Roles_model" initialized
INFO - 2021-07-05 13:25:24 --> Model "Activity_model" initialized
INFO - 2021-07-05 13:25:24 --> Model "Templates_model" initialized
INFO - 2021-07-05 13:25:24 --> Database Driver Class Initialized
INFO - 2021-07-05 13:25:24 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 13:25:24 --> Controller Class Initialized
ERROR - 2021-07-05 16:25:24 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 16:25:24 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 16:25:24 --> Final output sent to browser
DEBUG - 2021-07-05 16:25:24 --> Total execution time: 0.0684
INFO - 2021-07-05 13:25:25 --> Config Class Initialized
INFO - 2021-07-05 13:25:25 --> Hooks Class Initialized
DEBUG - 2021-07-05 13:25:25 --> UTF-8 Support Enabled
INFO - 2021-07-05 13:25:25 --> Utf8 Class Initialized
INFO - 2021-07-05 13:25:25 --> URI Class Initialized
INFO - 2021-07-05 13:25:25 --> Router Class Initialized
INFO - 2021-07-05 13:25:25 --> Output Class Initialized
INFO - 2021-07-05 13:25:25 --> Security Class Initialized
DEBUG - 2021-07-05 13:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 13:25:25 --> Input Class Initialized
INFO - 2021-07-05 13:25:25 --> Language Class Initialized
INFO - 2021-07-05 13:25:25 --> Loader Class Initialized
INFO - 2021-07-05 13:25:25 --> Helper loaded: basic_helper
INFO - 2021-07-05 13:25:25 --> Helper loaded: url_helper
INFO - 2021-07-05 13:25:25 --> Helper loaded: file_helper
INFO - 2021-07-05 13:25:25 --> Helper loaded: form_helper
INFO - 2021-07-05 13:25:25 --> Helper loaded: cookie_helper
INFO - 2021-07-05 13:25:25 --> Helper loaded: security_helper
INFO - 2021-07-05 13:25:25 --> Helper loaded: directory_helper
INFO - 2021-07-05 13:25:25 --> Helper loaded: language_helper
INFO - 2021-07-05 13:25:25 --> Helper loaded: general_helper
INFO - 2021-07-05 13:25:25 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 13:25:25 --> Database Driver Class Initialized
DEBUG - 2021-07-05 13:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 13:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 13:25:25 --> Parser Class Initialized
INFO - 2021-07-05 13:25:25 --> Form Validation Class Initialized
INFO - 2021-07-05 13:25:25 --> Upload Class Initialized
INFO - 2021-07-05 13:25:25 --> Email Class Initialized
INFO - 2021-07-05 13:25:25 --> MY_Model class loaded
INFO - 2021-07-05 13:25:25 --> Model "Users_model" initialized
INFO - 2021-07-05 13:25:25 --> Model "Settings_model" initialized
INFO - 2021-07-05 13:25:25 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 13:25:25 --> Model "Permissions_model" initialized
INFO - 2021-07-05 13:25:25 --> Model "Roles_model" initialized
INFO - 2021-07-05 13:25:25 --> Model "Activity_model" initialized
INFO - 2021-07-05 13:25:25 --> Model "Templates_model" initialized
INFO - 2021-07-05 13:25:25 --> Database Driver Class Initialized
INFO - 2021-07-05 13:25:25 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 13:25:25 --> Controller Class Initialized
ERROR - 2021-07-05 16:25:25 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 16:25:25 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-05 16:25:25 --> Final output sent to browser
DEBUG - 2021-07-05 16:25:25 --> Total execution time: 0.1856
INFO - 2021-07-05 13:25:29 --> Config Class Initialized
INFO - 2021-07-05 13:25:29 --> Hooks Class Initialized
DEBUG - 2021-07-05 13:25:29 --> UTF-8 Support Enabled
INFO - 2021-07-05 13:25:29 --> Utf8 Class Initialized
INFO - 2021-07-05 13:25:29 --> URI Class Initialized
INFO - 2021-07-05 13:25:29 --> Router Class Initialized
INFO - 2021-07-05 13:25:29 --> Output Class Initialized
INFO - 2021-07-05 13:25:29 --> Security Class Initialized
DEBUG - 2021-07-05 13:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 13:25:29 --> Input Class Initialized
INFO - 2021-07-05 13:25:29 --> Language Class Initialized
INFO - 2021-07-05 13:25:29 --> Loader Class Initialized
INFO - 2021-07-05 13:25:29 --> Helper loaded: basic_helper
INFO - 2021-07-05 13:25:29 --> Helper loaded: url_helper
INFO - 2021-07-05 13:25:29 --> Helper loaded: file_helper
INFO - 2021-07-05 13:25:29 --> Helper loaded: form_helper
INFO - 2021-07-05 13:25:29 --> Helper loaded: cookie_helper
INFO - 2021-07-05 13:25:29 --> Helper loaded: security_helper
INFO - 2021-07-05 13:25:29 --> Helper loaded: directory_helper
INFO - 2021-07-05 13:25:29 --> Helper loaded: language_helper
INFO - 2021-07-05 13:25:29 --> Helper loaded: general_helper
INFO - 2021-07-05 13:25:29 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 13:25:29 --> Database Driver Class Initialized
DEBUG - 2021-07-05 13:25:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 13:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 13:25:29 --> Parser Class Initialized
INFO - 2021-07-05 13:25:29 --> Form Validation Class Initialized
INFO - 2021-07-05 13:25:29 --> Upload Class Initialized
INFO - 2021-07-05 13:25:29 --> Email Class Initialized
INFO - 2021-07-05 13:25:29 --> MY_Model class loaded
INFO - 2021-07-05 13:25:29 --> Model "Users_model" initialized
INFO - 2021-07-05 13:25:29 --> Model "Settings_model" initialized
INFO - 2021-07-05 13:25:29 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 13:25:29 --> Model "Permissions_model" initialized
INFO - 2021-07-05 13:25:29 --> Model "Roles_model" initialized
INFO - 2021-07-05 13:25:29 --> Model "Activity_model" initialized
INFO - 2021-07-05 13:25:29 --> Model "Templates_model" initialized
INFO - 2021-07-05 13:25:29 --> Database Driver Class Initialized
INFO - 2021-07-05 13:25:29 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 13:25:29 --> Controller Class Initialized
ERROR - 2021-07-05 16:25:29 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 16:25:29 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 16:25:29 --> Final output sent to browser
DEBUG - 2021-07-05 16:25:29 --> Total execution time: 0.1258
INFO - 2021-07-05 13:25:46 --> Config Class Initialized
INFO - 2021-07-05 13:25:46 --> Hooks Class Initialized
DEBUG - 2021-07-05 13:25:46 --> UTF-8 Support Enabled
INFO - 2021-07-05 13:25:46 --> Utf8 Class Initialized
INFO - 2021-07-05 13:25:46 --> URI Class Initialized
INFO - 2021-07-05 13:25:46 --> Router Class Initialized
INFO - 2021-07-05 13:25:46 --> Output Class Initialized
INFO - 2021-07-05 13:25:46 --> Security Class Initialized
DEBUG - 2021-07-05 13:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 13:25:46 --> Input Class Initialized
INFO - 2021-07-05 13:25:46 --> Language Class Initialized
INFO - 2021-07-05 13:25:46 --> Loader Class Initialized
INFO - 2021-07-05 13:25:46 --> Helper loaded: basic_helper
INFO - 2021-07-05 13:25:46 --> Helper loaded: url_helper
INFO - 2021-07-05 13:25:46 --> Helper loaded: file_helper
INFO - 2021-07-05 13:25:46 --> Helper loaded: form_helper
INFO - 2021-07-05 13:25:46 --> Helper loaded: cookie_helper
INFO - 2021-07-05 13:25:46 --> Helper loaded: security_helper
INFO - 2021-07-05 13:25:46 --> Helper loaded: directory_helper
INFO - 2021-07-05 13:25:46 --> Helper loaded: language_helper
INFO - 2021-07-05 13:25:46 --> Helper loaded: general_helper
INFO - 2021-07-05 13:25:46 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 13:25:46 --> Database Driver Class Initialized
DEBUG - 2021-07-05 13:25:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 13:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 13:25:46 --> Parser Class Initialized
INFO - 2021-07-05 13:25:46 --> Form Validation Class Initialized
INFO - 2021-07-05 13:25:46 --> Upload Class Initialized
INFO - 2021-07-05 13:25:46 --> Email Class Initialized
INFO - 2021-07-05 13:25:46 --> MY_Model class loaded
INFO - 2021-07-05 13:25:46 --> Model "Users_model" initialized
INFO - 2021-07-05 13:25:46 --> Model "Settings_model" initialized
INFO - 2021-07-05 13:25:46 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 13:25:46 --> Model "Permissions_model" initialized
INFO - 2021-07-05 13:25:46 --> Model "Roles_model" initialized
INFO - 2021-07-05 13:25:46 --> Model "Activity_model" initialized
INFO - 2021-07-05 13:25:46 --> Model "Templates_model" initialized
INFO - 2021-07-05 13:25:46 --> Database Driver Class Initialized
INFO - 2021-07-05 13:25:46 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 13:25:46 --> Controller Class Initialized
ERROR - 2021-07-05 16:25:46 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 16:25:46 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 16:25:46 --> Final output sent to browser
DEBUG - 2021-07-05 16:25:46 --> Total execution time: 0.1185
INFO - 2021-07-05 13:25:54 --> Config Class Initialized
INFO - 2021-07-05 13:25:54 --> Hooks Class Initialized
DEBUG - 2021-07-05 13:25:54 --> UTF-8 Support Enabled
INFO - 2021-07-05 13:25:54 --> Utf8 Class Initialized
INFO - 2021-07-05 13:25:54 --> URI Class Initialized
INFO - 2021-07-05 13:25:54 --> Router Class Initialized
INFO - 2021-07-05 13:25:54 --> Output Class Initialized
INFO - 2021-07-05 13:25:54 --> Security Class Initialized
DEBUG - 2021-07-05 13:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 13:25:54 --> Input Class Initialized
INFO - 2021-07-05 13:25:54 --> Language Class Initialized
INFO - 2021-07-05 13:25:54 --> Loader Class Initialized
INFO - 2021-07-05 13:25:54 --> Helper loaded: basic_helper
INFO - 2021-07-05 13:25:54 --> Helper loaded: url_helper
INFO - 2021-07-05 13:25:54 --> Helper loaded: file_helper
INFO - 2021-07-05 13:25:54 --> Helper loaded: form_helper
INFO - 2021-07-05 13:25:54 --> Helper loaded: cookie_helper
INFO - 2021-07-05 13:25:54 --> Helper loaded: security_helper
INFO - 2021-07-05 13:25:54 --> Helper loaded: directory_helper
INFO - 2021-07-05 13:25:54 --> Helper loaded: language_helper
INFO - 2021-07-05 13:25:54 --> Helper loaded: general_helper
INFO - 2021-07-05 13:25:54 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 13:25:54 --> Database Driver Class Initialized
DEBUG - 2021-07-05 13:25:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 13:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 13:25:54 --> Parser Class Initialized
INFO - 2021-07-05 13:25:54 --> Form Validation Class Initialized
INFO - 2021-07-05 13:25:54 --> Upload Class Initialized
INFO - 2021-07-05 13:25:54 --> Email Class Initialized
INFO - 2021-07-05 13:25:54 --> MY_Model class loaded
INFO - 2021-07-05 13:25:54 --> Model "Users_model" initialized
INFO - 2021-07-05 13:25:54 --> Model "Settings_model" initialized
INFO - 2021-07-05 13:25:54 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 13:25:54 --> Model "Permissions_model" initialized
INFO - 2021-07-05 13:25:54 --> Model "Roles_model" initialized
INFO - 2021-07-05 13:25:54 --> Model "Activity_model" initialized
INFO - 2021-07-05 13:25:54 --> Model "Templates_model" initialized
INFO - 2021-07-05 13:25:54 --> Database Driver Class Initialized
INFO - 2021-07-05 13:25:54 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 13:25:54 --> Controller Class Initialized
ERROR - 2021-07-05 16:25:54 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 16:25:54 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 16:25:54 --> Final output sent to browser
DEBUG - 2021-07-05 16:25:54 --> Total execution time: 0.1266
INFO - 2021-07-05 14:16:15 --> Config Class Initialized
INFO - 2021-07-05 14:16:15 --> Hooks Class Initialized
DEBUG - 2021-07-05 14:16:15 --> UTF-8 Support Enabled
INFO - 2021-07-05 14:16:15 --> Utf8 Class Initialized
INFO - 2021-07-05 14:16:15 --> URI Class Initialized
DEBUG - 2021-07-05 14:16:15 --> No URI present. Default controller set.
INFO - 2021-07-05 14:16:15 --> Router Class Initialized
INFO - 2021-07-05 14:16:15 --> Output Class Initialized
INFO - 2021-07-05 14:16:15 --> Security Class Initialized
DEBUG - 2021-07-05 14:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 14:16:15 --> Input Class Initialized
INFO - 2021-07-05 14:16:15 --> Language Class Initialized
INFO - 2021-07-05 14:16:15 --> Loader Class Initialized
INFO - 2021-07-05 14:16:15 --> Helper loaded: basic_helper
INFO - 2021-07-05 14:16:15 --> Helper loaded: url_helper
INFO - 2021-07-05 14:16:15 --> Helper loaded: file_helper
INFO - 2021-07-05 14:16:15 --> Helper loaded: form_helper
INFO - 2021-07-05 14:16:15 --> Helper loaded: cookie_helper
INFO - 2021-07-05 14:16:15 --> Helper loaded: security_helper
INFO - 2021-07-05 14:16:15 --> Helper loaded: directory_helper
INFO - 2021-07-05 14:16:15 --> Helper loaded: language_helper
INFO - 2021-07-05 14:16:15 --> Helper loaded: general_helper
INFO - 2021-07-05 14:16:15 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 14:16:15 --> Database Driver Class Initialized
DEBUG - 2021-07-05 14:16:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 14:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 14:16:15 --> Parser Class Initialized
INFO - 2021-07-05 14:16:15 --> Form Validation Class Initialized
INFO - 2021-07-05 14:16:15 --> Upload Class Initialized
INFO - 2021-07-05 14:16:15 --> Email Class Initialized
INFO - 2021-07-05 14:16:15 --> MY_Model class loaded
INFO - 2021-07-05 14:16:15 --> Model "Users_model" initialized
INFO - 2021-07-05 14:16:15 --> Model "Settings_model" initialized
INFO - 2021-07-05 14:16:15 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 14:16:15 --> Model "Permissions_model" initialized
INFO - 2021-07-05 14:16:15 --> Model "Roles_model" initialized
INFO - 2021-07-05 14:16:15 --> Model "Activity_model" initialized
INFO - 2021-07-05 14:16:15 --> Model "Templates_model" initialized
INFO - 2021-07-05 14:16:15 --> Database Driver Class Initialized
INFO - 2021-07-05 14:16:15 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 14:16:15 --> Controller Class Initialized
ERROR - 2021-07-05 17:16:15 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 17:16:15 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-05 17:16:15 --> Final output sent to browser
DEBUG - 2021-07-05 17:16:15 --> Total execution time: 0.1604
INFO - 2021-07-05 14:16:15 --> Config Class Initialized
INFO - 2021-07-05 14:16:15 --> Hooks Class Initialized
DEBUG - 2021-07-05 14:16:15 --> UTF-8 Support Enabled
INFO - 2021-07-05 14:16:15 --> Utf8 Class Initialized
INFO - 2021-07-05 14:16:16 --> URI Class Initialized
INFO - 2021-07-05 14:16:16 --> Router Class Initialized
INFO - 2021-07-05 14:16:16 --> Output Class Initialized
INFO - 2021-07-05 14:16:16 --> Security Class Initialized
DEBUG - 2021-07-05 14:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 14:16:16 --> Input Class Initialized
INFO - 2021-07-05 14:16:16 --> Language Class Initialized
ERROR - 2021-07-05 14:16:16 --> 404 Page Not Found: Faviconico/index
INFO - 2021-07-05 14:16:17 --> Config Class Initialized
INFO - 2021-07-05 14:16:17 --> Hooks Class Initialized
DEBUG - 2021-07-05 14:16:17 --> UTF-8 Support Enabled
INFO - 2021-07-05 14:16:17 --> Utf8 Class Initialized
INFO - 2021-07-05 14:16:17 --> URI Class Initialized
INFO - 2021-07-05 14:16:17 --> Router Class Initialized
INFO - 2021-07-05 14:16:17 --> Output Class Initialized
INFO - 2021-07-05 14:16:17 --> Security Class Initialized
DEBUG - 2021-07-05 14:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 14:16:17 --> Input Class Initialized
INFO - 2021-07-05 14:16:17 --> Language Class Initialized
INFO - 2021-07-05 14:16:17 --> Loader Class Initialized
INFO - 2021-07-05 14:16:17 --> Helper loaded: basic_helper
INFO - 2021-07-05 14:16:17 --> Helper loaded: url_helper
INFO - 2021-07-05 14:16:17 --> Helper loaded: file_helper
INFO - 2021-07-05 14:16:17 --> Helper loaded: form_helper
INFO - 2021-07-05 14:16:17 --> Helper loaded: cookie_helper
INFO - 2021-07-05 14:16:17 --> Helper loaded: security_helper
INFO - 2021-07-05 14:16:17 --> Helper loaded: directory_helper
INFO - 2021-07-05 14:16:17 --> Helper loaded: language_helper
INFO - 2021-07-05 14:16:17 --> Helper loaded: general_helper
INFO - 2021-07-05 14:16:17 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 14:16:17 --> Database Driver Class Initialized
DEBUG - 2021-07-05 14:16:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 14:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 14:16:17 --> Parser Class Initialized
INFO - 2021-07-05 14:16:17 --> Form Validation Class Initialized
INFO - 2021-07-05 14:16:17 --> Upload Class Initialized
INFO - 2021-07-05 14:16:17 --> Email Class Initialized
INFO - 2021-07-05 14:16:17 --> MY_Model class loaded
INFO - 2021-07-05 14:16:17 --> Model "Users_model" initialized
INFO - 2021-07-05 14:16:17 --> Model "Settings_model" initialized
INFO - 2021-07-05 14:16:17 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 14:16:17 --> Model "Permissions_model" initialized
INFO - 2021-07-05 14:16:17 --> Model "Roles_model" initialized
INFO - 2021-07-05 14:16:17 --> Model "Activity_model" initialized
INFO - 2021-07-05 14:16:17 --> Model "Templates_model" initialized
INFO - 2021-07-05 14:16:17 --> Database Driver Class Initialized
INFO - 2021-07-05 14:16:17 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 14:16:17 --> Controller Class Initialized
ERROR - 2021-07-05 17:16:17 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 17:16:18 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-05 17:16:18 --> Final output sent to browser
DEBUG - 2021-07-05 17:16:18 --> Total execution time: 0.2342
INFO - 2021-07-05 14:16:20 --> Config Class Initialized
INFO - 2021-07-05 14:16:20 --> Hooks Class Initialized
DEBUG - 2021-07-05 14:16:20 --> UTF-8 Support Enabled
INFO - 2021-07-05 14:16:20 --> Utf8 Class Initialized
INFO - 2021-07-05 14:16:20 --> URI Class Initialized
INFO - 2021-07-05 14:16:20 --> Router Class Initialized
INFO - 2021-07-05 14:16:20 --> Output Class Initialized
INFO - 2021-07-05 14:16:20 --> Security Class Initialized
DEBUG - 2021-07-05 14:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 14:16:20 --> Input Class Initialized
INFO - 2021-07-05 14:16:20 --> Language Class Initialized
INFO - 2021-07-05 14:16:20 --> Loader Class Initialized
INFO - 2021-07-05 14:16:20 --> Helper loaded: basic_helper
INFO - 2021-07-05 14:16:20 --> Helper loaded: url_helper
INFO - 2021-07-05 14:16:20 --> Helper loaded: file_helper
INFO - 2021-07-05 14:16:20 --> Helper loaded: form_helper
INFO - 2021-07-05 14:16:20 --> Helper loaded: cookie_helper
INFO - 2021-07-05 14:16:20 --> Helper loaded: security_helper
INFO - 2021-07-05 14:16:20 --> Helper loaded: directory_helper
INFO - 2021-07-05 14:16:20 --> Helper loaded: language_helper
INFO - 2021-07-05 14:16:20 --> Helper loaded: general_helper
INFO - 2021-07-05 14:16:20 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 14:16:20 --> Database Driver Class Initialized
DEBUG - 2021-07-05 14:16:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 14:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 14:16:20 --> Parser Class Initialized
INFO - 2021-07-05 14:16:20 --> Form Validation Class Initialized
INFO - 2021-07-05 14:16:20 --> Upload Class Initialized
INFO - 2021-07-05 14:16:20 --> Email Class Initialized
INFO - 2021-07-05 14:16:20 --> MY_Model class loaded
INFO - 2021-07-05 14:16:20 --> Model "Users_model" initialized
INFO - 2021-07-05 14:16:20 --> Model "Settings_model" initialized
INFO - 2021-07-05 14:16:20 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 14:16:20 --> Model "Permissions_model" initialized
INFO - 2021-07-05 14:16:20 --> Model "Roles_model" initialized
INFO - 2021-07-05 14:16:20 --> Model "Activity_model" initialized
INFO - 2021-07-05 14:16:20 --> Model "Templates_model" initialized
INFO - 2021-07-05 14:16:20 --> Database Driver Class Initialized
INFO - 2021-07-05 14:16:20 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 14:16:20 --> Controller Class Initialized
ERROR - 2021-07-05 17:16:20 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 17:16:20 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 17:16:20 --> Final output sent to browser
DEBUG - 2021-07-05 17:16:20 --> Total execution time: 0.1288
INFO - 2021-07-05 14:16:52 --> Config Class Initialized
INFO - 2021-07-05 14:16:52 --> Hooks Class Initialized
DEBUG - 2021-07-05 14:16:52 --> UTF-8 Support Enabled
INFO - 2021-07-05 14:16:52 --> Utf8 Class Initialized
INFO - 2021-07-05 14:16:52 --> URI Class Initialized
INFO - 2021-07-05 14:16:52 --> Router Class Initialized
INFO - 2021-07-05 14:16:52 --> Output Class Initialized
INFO - 2021-07-05 14:16:52 --> Security Class Initialized
DEBUG - 2021-07-05 14:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 14:16:52 --> Input Class Initialized
INFO - 2021-07-05 14:16:52 --> Language Class Initialized
INFO - 2021-07-05 14:16:52 --> Loader Class Initialized
INFO - 2021-07-05 14:16:52 --> Helper loaded: basic_helper
INFO - 2021-07-05 14:16:52 --> Helper loaded: url_helper
INFO - 2021-07-05 14:16:52 --> Helper loaded: file_helper
INFO - 2021-07-05 14:16:52 --> Helper loaded: form_helper
INFO - 2021-07-05 14:16:52 --> Helper loaded: cookie_helper
INFO - 2021-07-05 14:16:52 --> Helper loaded: security_helper
INFO - 2021-07-05 14:16:52 --> Helper loaded: directory_helper
INFO - 2021-07-05 14:16:52 --> Helper loaded: language_helper
INFO - 2021-07-05 14:16:52 --> Helper loaded: general_helper
INFO - 2021-07-05 14:16:52 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 14:16:52 --> Database Driver Class Initialized
DEBUG - 2021-07-05 14:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 14:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 14:16:52 --> Parser Class Initialized
INFO - 2021-07-05 14:16:52 --> Form Validation Class Initialized
INFO - 2021-07-05 14:16:52 --> Upload Class Initialized
INFO - 2021-07-05 14:16:52 --> Email Class Initialized
INFO - 2021-07-05 14:16:52 --> MY_Model class loaded
INFO - 2021-07-05 14:16:52 --> Model "Users_model" initialized
INFO - 2021-07-05 14:16:52 --> Model "Settings_model" initialized
INFO - 2021-07-05 14:16:52 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 14:16:52 --> Model "Permissions_model" initialized
INFO - 2021-07-05 14:16:52 --> Model "Roles_model" initialized
INFO - 2021-07-05 14:16:52 --> Model "Activity_model" initialized
INFO - 2021-07-05 14:16:52 --> Model "Templates_model" initialized
INFO - 2021-07-05 14:16:52 --> Database Driver Class Initialized
INFO - 2021-07-05 14:16:53 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 14:16:53 --> Controller Class Initialized
ERROR - 2021-07-05 17:16:53 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 17:16:53 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 17:16:53 --> Final output sent to browser
DEBUG - 2021-07-05 17:16:53 --> Total execution time: 0.1357
INFO - 2021-07-05 14:16:56 --> Config Class Initialized
INFO - 2021-07-05 14:16:56 --> Hooks Class Initialized
DEBUG - 2021-07-05 14:16:56 --> UTF-8 Support Enabled
INFO - 2021-07-05 14:16:56 --> Utf8 Class Initialized
INFO - 2021-07-05 14:16:56 --> URI Class Initialized
INFO - 2021-07-05 14:16:56 --> Router Class Initialized
INFO - 2021-07-05 14:16:56 --> Output Class Initialized
INFO - 2021-07-05 14:16:56 --> Security Class Initialized
DEBUG - 2021-07-05 14:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 14:16:56 --> Input Class Initialized
INFO - 2021-07-05 14:16:56 --> Language Class Initialized
INFO - 2021-07-05 14:16:56 --> Loader Class Initialized
INFO - 2021-07-05 14:16:56 --> Helper loaded: basic_helper
INFO - 2021-07-05 14:16:56 --> Helper loaded: url_helper
INFO - 2021-07-05 14:16:56 --> Helper loaded: file_helper
INFO - 2021-07-05 14:16:56 --> Helper loaded: form_helper
INFO - 2021-07-05 14:16:56 --> Helper loaded: cookie_helper
INFO - 2021-07-05 14:16:56 --> Helper loaded: security_helper
INFO - 2021-07-05 14:16:56 --> Helper loaded: directory_helper
INFO - 2021-07-05 14:16:56 --> Helper loaded: language_helper
INFO - 2021-07-05 14:16:56 --> Helper loaded: general_helper
INFO - 2021-07-05 14:16:56 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 14:16:56 --> Database Driver Class Initialized
DEBUG - 2021-07-05 14:16:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 14:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 14:16:56 --> Parser Class Initialized
INFO - 2021-07-05 14:16:56 --> Form Validation Class Initialized
INFO - 2021-07-05 14:16:56 --> Upload Class Initialized
INFO - 2021-07-05 14:16:56 --> Email Class Initialized
INFO - 2021-07-05 14:16:56 --> MY_Model class loaded
INFO - 2021-07-05 14:16:56 --> Model "Users_model" initialized
INFO - 2021-07-05 14:16:56 --> Model "Settings_model" initialized
INFO - 2021-07-05 14:16:56 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 14:16:56 --> Model "Permissions_model" initialized
INFO - 2021-07-05 14:16:56 --> Model "Roles_model" initialized
INFO - 2021-07-05 14:16:56 --> Model "Activity_model" initialized
INFO - 2021-07-05 14:16:56 --> Model "Templates_model" initialized
INFO - 2021-07-05 14:16:56 --> Database Driver Class Initialized
INFO - 2021-07-05 14:16:56 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 14:16:56 --> Controller Class Initialized
ERROR - 2021-07-05 17:16:56 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 17:16:56 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-05 17:16:56 --> Final output sent to browser
DEBUG - 2021-07-05 17:16:56 --> Total execution time: 0.1915
INFO - 2021-07-05 14:16:57 --> Config Class Initialized
INFO - 2021-07-05 14:16:57 --> Hooks Class Initialized
DEBUG - 2021-07-05 14:16:57 --> UTF-8 Support Enabled
INFO - 2021-07-05 14:16:57 --> Utf8 Class Initialized
INFO - 2021-07-05 14:16:57 --> URI Class Initialized
INFO - 2021-07-05 14:16:57 --> Router Class Initialized
INFO - 2021-07-05 14:16:57 --> Output Class Initialized
INFO - 2021-07-05 14:16:57 --> Security Class Initialized
DEBUG - 2021-07-05 14:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 14:16:57 --> Input Class Initialized
INFO - 2021-07-05 14:16:57 --> Language Class Initialized
INFO - 2021-07-05 14:16:57 --> Loader Class Initialized
INFO - 2021-07-05 14:16:57 --> Helper loaded: basic_helper
INFO - 2021-07-05 14:16:57 --> Helper loaded: url_helper
INFO - 2021-07-05 14:16:57 --> Helper loaded: file_helper
INFO - 2021-07-05 14:16:57 --> Helper loaded: form_helper
INFO - 2021-07-05 14:16:57 --> Helper loaded: cookie_helper
INFO - 2021-07-05 14:16:57 --> Helper loaded: security_helper
INFO - 2021-07-05 14:16:57 --> Helper loaded: directory_helper
INFO - 2021-07-05 14:16:57 --> Helper loaded: language_helper
INFO - 2021-07-05 14:16:57 --> Helper loaded: general_helper
INFO - 2021-07-05 14:16:57 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 14:16:57 --> Database Driver Class Initialized
DEBUG - 2021-07-05 14:16:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 14:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 14:16:57 --> Parser Class Initialized
INFO - 2021-07-05 14:16:57 --> Form Validation Class Initialized
INFO - 2021-07-05 14:16:57 --> Upload Class Initialized
INFO - 2021-07-05 14:16:57 --> Email Class Initialized
INFO - 2021-07-05 14:16:57 --> MY_Model class loaded
INFO - 2021-07-05 14:16:57 --> Model "Users_model" initialized
INFO - 2021-07-05 14:16:57 --> Model "Settings_model" initialized
INFO - 2021-07-05 14:16:57 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 14:16:57 --> Model "Permissions_model" initialized
INFO - 2021-07-05 14:16:57 --> Model "Roles_model" initialized
INFO - 2021-07-05 14:16:57 --> Model "Activity_model" initialized
INFO - 2021-07-05 14:16:57 --> Model "Templates_model" initialized
INFO - 2021-07-05 14:16:57 --> Database Driver Class Initialized
INFO - 2021-07-05 14:16:57 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 14:16:57 --> Controller Class Initialized
ERROR - 2021-07-05 17:16:57 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 17:16:57 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 17:16:57 --> Final output sent to browser
DEBUG - 2021-07-05 17:16:57 --> Total execution time: 0.0605
INFO - 2021-07-05 14:17:27 --> Config Class Initialized
INFO - 2021-07-05 14:17:27 --> Hooks Class Initialized
DEBUG - 2021-07-05 14:17:27 --> UTF-8 Support Enabled
INFO - 2021-07-05 14:17:27 --> Utf8 Class Initialized
INFO - 2021-07-05 14:17:27 --> URI Class Initialized
DEBUG - 2021-07-05 14:17:27 --> No URI present. Default controller set.
INFO - 2021-07-05 14:17:27 --> Router Class Initialized
INFO - 2021-07-05 14:17:27 --> Output Class Initialized
INFO - 2021-07-05 14:17:27 --> Security Class Initialized
DEBUG - 2021-07-05 14:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 14:17:27 --> Input Class Initialized
INFO - 2021-07-05 14:17:27 --> Language Class Initialized
INFO - 2021-07-05 14:17:27 --> Loader Class Initialized
INFO - 2021-07-05 14:17:27 --> Helper loaded: basic_helper
INFO - 2021-07-05 14:17:27 --> Helper loaded: url_helper
INFO - 2021-07-05 14:17:27 --> Helper loaded: file_helper
INFO - 2021-07-05 14:17:27 --> Helper loaded: form_helper
INFO - 2021-07-05 14:17:27 --> Helper loaded: cookie_helper
INFO - 2021-07-05 14:17:27 --> Helper loaded: security_helper
INFO - 2021-07-05 14:17:27 --> Helper loaded: directory_helper
INFO - 2021-07-05 14:17:27 --> Helper loaded: language_helper
INFO - 2021-07-05 14:17:27 --> Helper loaded: general_helper
INFO - 2021-07-05 14:17:27 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 14:17:27 --> Database Driver Class Initialized
DEBUG - 2021-07-05 14:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 14:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 14:17:27 --> Parser Class Initialized
INFO - 2021-07-05 14:17:27 --> Form Validation Class Initialized
INFO - 2021-07-05 14:17:27 --> Upload Class Initialized
INFO - 2021-07-05 14:17:27 --> Email Class Initialized
INFO - 2021-07-05 14:17:27 --> MY_Model class loaded
INFO - 2021-07-05 14:17:27 --> Model "Users_model" initialized
INFO - 2021-07-05 14:17:27 --> Model "Settings_model" initialized
INFO - 2021-07-05 14:17:27 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 14:17:27 --> Model "Permissions_model" initialized
INFO - 2021-07-05 14:17:27 --> Model "Roles_model" initialized
INFO - 2021-07-05 14:17:27 --> Model "Activity_model" initialized
INFO - 2021-07-05 14:17:27 --> Model "Templates_model" initialized
INFO - 2021-07-05 14:17:27 --> Database Driver Class Initialized
INFO - 2021-07-05 14:17:27 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 14:17:27 --> Controller Class Initialized
INFO - 2021-07-05 14:46:40 --> Config Class Initialized
INFO - 2021-07-05 14:46:40 --> Hooks Class Initialized
DEBUG - 2021-07-05 14:46:40 --> UTF-8 Support Enabled
INFO - 2021-07-05 14:46:40 --> Utf8 Class Initialized
INFO - 2021-07-05 14:46:40 --> URI Class Initialized
INFO - 2021-07-05 14:46:40 --> Router Class Initialized
INFO - 2021-07-05 14:46:40 --> Output Class Initialized
INFO - 2021-07-05 14:46:40 --> Security Class Initialized
DEBUG - 2021-07-05 14:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 14:46:40 --> Input Class Initialized
INFO - 2021-07-05 14:46:40 --> Language Class Initialized
INFO - 2021-07-05 14:46:40 --> Loader Class Initialized
INFO - 2021-07-05 14:46:40 --> Helper loaded: basic_helper
INFO - 2021-07-05 14:46:40 --> Helper loaded: url_helper
INFO - 2021-07-05 14:46:40 --> Helper loaded: file_helper
INFO - 2021-07-05 14:46:40 --> Helper loaded: form_helper
INFO - 2021-07-05 14:46:40 --> Helper loaded: cookie_helper
INFO - 2021-07-05 14:46:40 --> Helper loaded: security_helper
INFO - 2021-07-05 14:46:40 --> Helper loaded: directory_helper
INFO - 2021-07-05 14:46:40 --> Helper loaded: language_helper
INFO - 2021-07-05 14:46:40 --> Helper loaded: general_helper
INFO - 2021-07-05 14:46:40 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 14:46:40 --> Database Driver Class Initialized
DEBUG - 2021-07-05 14:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 14:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 14:46:40 --> Parser Class Initialized
INFO - 2021-07-05 14:46:40 --> Form Validation Class Initialized
INFO - 2021-07-05 14:46:40 --> Upload Class Initialized
INFO - 2021-07-05 14:46:40 --> Email Class Initialized
INFO - 2021-07-05 14:46:40 --> MY_Model class loaded
INFO - 2021-07-05 14:46:40 --> Model "Users_model" initialized
INFO - 2021-07-05 14:46:40 --> Model "Settings_model" initialized
INFO - 2021-07-05 14:46:40 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 14:46:40 --> Model "Permissions_model" initialized
INFO - 2021-07-05 14:46:40 --> Model "Roles_model" initialized
INFO - 2021-07-05 14:46:40 --> Model "Activity_model" initialized
INFO - 2021-07-05 14:46:40 --> Model "Templates_model" initialized
INFO - 2021-07-05 14:46:40 --> Database Driver Class Initialized
INFO - 2021-07-05 14:46:40 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 14:46:40 --> Controller Class Initialized
ERROR - 2021-07-05 17:46:40 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 17:46:40 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-05 17:46:40 --> Final output sent to browser
DEBUG - 2021-07-05 17:46:40 --> Total execution time: 0.3082
INFO - 2021-07-05 14:46:41 --> Config Class Initialized
INFO - 2021-07-05 14:46:41 --> Hooks Class Initialized
DEBUG - 2021-07-05 14:46:41 --> UTF-8 Support Enabled
INFO - 2021-07-05 14:46:41 --> Utf8 Class Initialized
INFO - 2021-07-05 14:46:41 --> URI Class Initialized
INFO - 2021-07-05 14:46:41 --> Router Class Initialized
INFO - 2021-07-05 14:46:41 --> Output Class Initialized
INFO - 2021-07-05 14:46:41 --> Security Class Initialized
DEBUG - 2021-07-05 14:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 14:46:41 --> Input Class Initialized
INFO - 2021-07-05 14:46:41 --> Language Class Initialized
INFO - 2021-07-05 14:46:41 --> Loader Class Initialized
INFO - 2021-07-05 14:46:41 --> Helper loaded: basic_helper
INFO - 2021-07-05 14:46:41 --> Helper loaded: url_helper
INFO - 2021-07-05 14:46:41 --> Helper loaded: file_helper
INFO - 2021-07-05 14:46:41 --> Helper loaded: form_helper
INFO - 2021-07-05 14:46:41 --> Helper loaded: cookie_helper
INFO - 2021-07-05 14:46:41 --> Helper loaded: security_helper
INFO - 2021-07-05 14:46:41 --> Helper loaded: directory_helper
INFO - 2021-07-05 14:46:41 --> Helper loaded: language_helper
INFO - 2021-07-05 14:46:41 --> Helper loaded: general_helper
INFO - 2021-07-05 14:46:41 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 14:46:41 --> Database Driver Class Initialized
DEBUG - 2021-07-05 14:46:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 14:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 14:46:41 --> Parser Class Initialized
INFO - 2021-07-05 14:46:41 --> Form Validation Class Initialized
INFO - 2021-07-05 14:46:41 --> Upload Class Initialized
INFO - 2021-07-05 14:46:41 --> Email Class Initialized
INFO - 2021-07-05 14:46:41 --> MY_Model class loaded
INFO - 2021-07-05 14:46:41 --> Model "Users_model" initialized
INFO - 2021-07-05 14:46:41 --> Model "Settings_model" initialized
INFO - 2021-07-05 14:46:41 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 14:46:41 --> Model "Permissions_model" initialized
INFO - 2021-07-05 14:46:41 --> Model "Roles_model" initialized
INFO - 2021-07-05 14:46:41 --> Model "Activity_model" initialized
INFO - 2021-07-05 14:46:41 --> Model "Templates_model" initialized
INFO - 2021-07-05 14:46:41 --> Database Driver Class Initialized
INFO - 2021-07-05 14:46:41 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 14:46:41 --> Controller Class Initialized
ERROR - 2021-07-05 17:46:41 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 17:46:41 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 17:46:41 --> Final output sent to browser
DEBUG - 2021-07-05 17:46:41 --> Total execution time: 0.0688
INFO - 2021-07-05 14:46:43 --> Config Class Initialized
INFO - 2021-07-05 14:46:43 --> Hooks Class Initialized
DEBUG - 2021-07-05 14:46:43 --> UTF-8 Support Enabled
INFO - 2021-07-05 14:46:43 --> Utf8 Class Initialized
INFO - 2021-07-05 14:46:43 --> URI Class Initialized
INFO - 2021-07-05 14:46:43 --> Router Class Initialized
INFO - 2021-07-05 14:46:43 --> Output Class Initialized
INFO - 2021-07-05 14:46:43 --> Security Class Initialized
DEBUG - 2021-07-05 14:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 14:46:43 --> Input Class Initialized
INFO - 2021-07-05 14:46:43 --> Language Class Initialized
INFO - 2021-07-05 14:46:43 --> Loader Class Initialized
INFO - 2021-07-05 14:46:43 --> Helper loaded: basic_helper
INFO - 2021-07-05 14:46:43 --> Helper loaded: url_helper
INFO - 2021-07-05 14:46:43 --> Helper loaded: file_helper
INFO - 2021-07-05 14:46:43 --> Helper loaded: form_helper
INFO - 2021-07-05 14:46:43 --> Helper loaded: cookie_helper
INFO - 2021-07-05 14:46:43 --> Helper loaded: security_helper
INFO - 2021-07-05 14:46:43 --> Helper loaded: directory_helper
INFO - 2021-07-05 14:46:43 --> Helper loaded: language_helper
INFO - 2021-07-05 14:46:43 --> Helper loaded: general_helper
INFO - 2021-07-05 14:46:43 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 14:46:43 --> Database Driver Class Initialized
DEBUG - 2021-07-05 14:46:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 14:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 14:46:43 --> Parser Class Initialized
INFO - 2021-07-05 14:46:43 --> Form Validation Class Initialized
INFO - 2021-07-05 14:46:43 --> Upload Class Initialized
INFO - 2021-07-05 14:46:43 --> Email Class Initialized
INFO - 2021-07-05 14:46:43 --> MY_Model class loaded
INFO - 2021-07-05 14:46:43 --> Model "Users_model" initialized
INFO - 2021-07-05 14:46:43 --> Model "Settings_model" initialized
INFO - 2021-07-05 14:46:43 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 14:46:43 --> Model "Permissions_model" initialized
INFO - 2021-07-05 14:46:43 --> Model "Roles_model" initialized
INFO - 2021-07-05 14:46:43 --> Model "Activity_model" initialized
INFO - 2021-07-05 14:46:43 --> Model "Templates_model" initialized
INFO - 2021-07-05 14:46:43 --> Database Driver Class Initialized
INFO - 2021-07-05 14:46:43 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 14:46:43 --> Controller Class Initialized
ERROR - 2021-07-05 17:46:43 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 17:46:43 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-05 17:46:43 --> Final output sent to browser
DEBUG - 2021-07-05 17:46:43 --> Total execution time: 0.1931
INFO - 2021-07-05 14:46:44 --> Config Class Initialized
INFO - 2021-07-05 14:46:44 --> Hooks Class Initialized
DEBUG - 2021-07-05 14:46:44 --> UTF-8 Support Enabled
INFO - 2021-07-05 14:46:44 --> Utf8 Class Initialized
INFO - 2021-07-05 14:46:44 --> URI Class Initialized
INFO - 2021-07-05 14:46:44 --> Router Class Initialized
INFO - 2021-07-05 14:46:44 --> Output Class Initialized
INFO - 2021-07-05 14:46:44 --> Security Class Initialized
DEBUG - 2021-07-05 14:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 14:46:44 --> Input Class Initialized
INFO - 2021-07-05 14:46:44 --> Language Class Initialized
INFO - 2021-07-05 14:46:44 --> Loader Class Initialized
INFO - 2021-07-05 14:46:44 --> Helper loaded: basic_helper
INFO - 2021-07-05 14:46:44 --> Helper loaded: url_helper
INFO - 2021-07-05 14:46:44 --> Helper loaded: file_helper
INFO - 2021-07-05 14:46:44 --> Helper loaded: form_helper
INFO - 2021-07-05 14:46:44 --> Helper loaded: cookie_helper
INFO - 2021-07-05 14:46:44 --> Helper loaded: security_helper
INFO - 2021-07-05 14:46:44 --> Helper loaded: directory_helper
INFO - 2021-07-05 14:46:44 --> Helper loaded: language_helper
INFO - 2021-07-05 14:46:44 --> Helper loaded: general_helper
INFO - 2021-07-05 14:46:44 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 14:46:44 --> Database Driver Class Initialized
DEBUG - 2021-07-05 14:46:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 14:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 14:46:44 --> Parser Class Initialized
INFO - 2021-07-05 14:46:44 --> Form Validation Class Initialized
INFO - 2021-07-05 14:46:44 --> Upload Class Initialized
INFO - 2021-07-05 14:46:44 --> Email Class Initialized
INFO - 2021-07-05 14:46:44 --> MY_Model class loaded
INFO - 2021-07-05 14:46:44 --> Model "Users_model" initialized
INFO - 2021-07-05 14:46:44 --> Model "Settings_model" initialized
INFO - 2021-07-05 14:46:44 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 14:46:44 --> Model "Permissions_model" initialized
INFO - 2021-07-05 14:46:44 --> Model "Roles_model" initialized
INFO - 2021-07-05 14:46:44 --> Model "Activity_model" initialized
INFO - 2021-07-05 14:46:44 --> Model "Templates_model" initialized
INFO - 2021-07-05 14:46:44 --> Database Driver Class Initialized
INFO - 2021-07-05 14:46:44 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 14:46:44 --> Controller Class Initialized
ERROR - 2021-07-05 17:46:44 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 17:46:44 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 17:46:44 --> Final output sent to browser
DEBUG - 2021-07-05 17:46:44 --> Total execution time: 0.1318
INFO - 2021-07-05 14:46:46 --> Config Class Initialized
INFO - 2021-07-05 14:46:46 --> Hooks Class Initialized
DEBUG - 2021-07-05 14:46:46 --> UTF-8 Support Enabled
INFO - 2021-07-05 14:46:46 --> Utf8 Class Initialized
INFO - 2021-07-05 14:46:46 --> URI Class Initialized
INFO - 2021-07-05 14:46:46 --> Router Class Initialized
INFO - 2021-07-05 14:46:46 --> Output Class Initialized
INFO - 2021-07-05 14:46:46 --> Security Class Initialized
DEBUG - 2021-07-05 14:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 14:46:46 --> Input Class Initialized
INFO - 2021-07-05 14:46:46 --> Language Class Initialized
INFO - 2021-07-05 14:46:46 --> Loader Class Initialized
INFO - 2021-07-05 14:46:46 --> Helper loaded: basic_helper
INFO - 2021-07-05 14:46:46 --> Helper loaded: url_helper
INFO - 2021-07-05 14:46:46 --> Helper loaded: file_helper
INFO - 2021-07-05 14:46:46 --> Helper loaded: form_helper
INFO - 2021-07-05 14:46:46 --> Helper loaded: cookie_helper
INFO - 2021-07-05 14:46:46 --> Helper loaded: security_helper
INFO - 2021-07-05 14:46:46 --> Helper loaded: directory_helper
INFO - 2021-07-05 14:46:46 --> Helper loaded: language_helper
INFO - 2021-07-05 14:46:46 --> Helper loaded: general_helper
INFO - 2021-07-05 14:46:46 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 14:46:46 --> Database Driver Class Initialized
DEBUG - 2021-07-05 14:46:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 14:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 14:46:46 --> Parser Class Initialized
INFO - 2021-07-05 14:46:46 --> Form Validation Class Initialized
INFO - 2021-07-05 14:46:46 --> Upload Class Initialized
INFO - 2021-07-05 14:46:46 --> Email Class Initialized
INFO - 2021-07-05 14:46:46 --> MY_Model class loaded
INFO - 2021-07-05 14:46:46 --> Model "Users_model" initialized
INFO - 2021-07-05 14:46:46 --> Model "Settings_model" initialized
INFO - 2021-07-05 14:46:46 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 14:46:46 --> Model "Permissions_model" initialized
INFO - 2021-07-05 14:46:46 --> Model "Roles_model" initialized
INFO - 2021-07-05 14:46:46 --> Model "Activity_model" initialized
INFO - 2021-07-05 14:46:46 --> Model "Templates_model" initialized
INFO - 2021-07-05 14:46:46 --> Database Driver Class Initialized
INFO - 2021-07-05 14:46:46 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 14:46:46 --> Controller Class Initialized
ERROR - 2021-07-05 17:46:46 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 17:46:46 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-05 17:46:46 --> Final output sent to browser
DEBUG - 2021-07-05 17:46:46 --> Total execution time: 0.1826
INFO - 2021-07-05 14:46:47 --> Config Class Initialized
INFO - 2021-07-05 14:46:47 --> Hooks Class Initialized
DEBUG - 2021-07-05 14:46:47 --> UTF-8 Support Enabled
INFO - 2021-07-05 14:46:47 --> Utf8 Class Initialized
INFO - 2021-07-05 14:46:47 --> URI Class Initialized
INFO - 2021-07-05 14:46:47 --> Router Class Initialized
INFO - 2021-07-05 14:46:47 --> Output Class Initialized
INFO - 2021-07-05 14:46:47 --> Security Class Initialized
DEBUG - 2021-07-05 14:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 14:46:47 --> Input Class Initialized
INFO - 2021-07-05 14:46:47 --> Language Class Initialized
INFO - 2021-07-05 14:46:47 --> Loader Class Initialized
INFO - 2021-07-05 14:46:47 --> Helper loaded: basic_helper
INFO - 2021-07-05 14:46:47 --> Helper loaded: url_helper
INFO - 2021-07-05 14:46:47 --> Helper loaded: file_helper
INFO - 2021-07-05 14:46:47 --> Helper loaded: form_helper
INFO - 2021-07-05 14:46:47 --> Helper loaded: cookie_helper
INFO - 2021-07-05 14:46:47 --> Helper loaded: security_helper
INFO - 2021-07-05 14:46:47 --> Helper loaded: directory_helper
INFO - 2021-07-05 14:46:47 --> Helper loaded: language_helper
INFO - 2021-07-05 14:46:47 --> Helper loaded: general_helper
INFO - 2021-07-05 14:46:47 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 14:46:47 --> Database Driver Class Initialized
DEBUG - 2021-07-05 14:46:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 14:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 14:46:47 --> Parser Class Initialized
INFO - 2021-07-05 14:46:47 --> Form Validation Class Initialized
INFO - 2021-07-05 14:46:47 --> Upload Class Initialized
INFO - 2021-07-05 14:46:47 --> Email Class Initialized
INFO - 2021-07-05 14:46:47 --> MY_Model class loaded
INFO - 2021-07-05 14:46:47 --> Model "Users_model" initialized
INFO - 2021-07-05 14:46:47 --> Model "Settings_model" initialized
INFO - 2021-07-05 14:46:47 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 14:46:47 --> Model "Permissions_model" initialized
INFO - 2021-07-05 14:46:47 --> Model "Roles_model" initialized
INFO - 2021-07-05 14:46:47 --> Model "Activity_model" initialized
INFO - 2021-07-05 14:46:47 --> Model "Templates_model" initialized
INFO - 2021-07-05 14:46:47 --> Database Driver Class Initialized
INFO - 2021-07-05 14:46:47 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 14:46:47 --> Controller Class Initialized
ERROR - 2021-07-05 17:46:47 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 17:46:47 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 17:46:47 --> Final output sent to browser
DEBUG - 2021-07-05 17:46:47 --> Total execution time: 0.0779
INFO - 2021-07-05 14:50:05 --> Config Class Initialized
INFO - 2021-07-05 14:50:05 --> Hooks Class Initialized
DEBUG - 2021-07-05 14:50:05 --> UTF-8 Support Enabled
INFO - 2021-07-05 14:50:05 --> Utf8 Class Initialized
INFO - 2021-07-05 14:50:05 --> URI Class Initialized
INFO - 2021-07-05 14:50:05 --> Router Class Initialized
INFO - 2021-07-05 14:50:05 --> Output Class Initialized
INFO - 2021-07-05 14:50:05 --> Security Class Initialized
DEBUG - 2021-07-05 14:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 14:50:05 --> Input Class Initialized
INFO - 2021-07-05 14:50:05 --> Language Class Initialized
INFO - 2021-07-05 14:50:05 --> Loader Class Initialized
INFO - 2021-07-05 14:50:05 --> Helper loaded: basic_helper
INFO - 2021-07-05 14:50:05 --> Helper loaded: url_helper
INFO - 2021-07-05 14:50:05 --> Helper loaded: file_helper
INFO - 2021-07-05 14:50:05 --> Helper loaded: form_helper
INFO - 2021-07-05 14:50:05 --> Helper loaded: cookie_helper
INFO - 2021-07-05 14:50:05 --> Helper loaded: security_helper
INFO - 2021-07-05 14:50:05 --> Helper loaded: directory_helper
INFO - 2021-07-05 14:50:05 --> Helper loaded: language_helper
INFO - 2021-07-05 14:50:05 --> Helper loaded: general_helper
INFO - 2021-07-05 14:50:05 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 14:50:05 --> Database Driver Class Initialized
DEBUG - 2021-07-05 14:50:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 14:50:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 14:50:05 --> Parser Class Initialized
INFO - 2021-07-05 14:50:05 --> Form Validation Class Initialized
INFO - 2021-07-05 14:50:05 --> Upload Class Initialized
INFO - 2021-07-05 14:50:05 --> Email Class Initialized
INFO - 2021-07-05 14:50:05 --> MY_Model class loaded
INFO - 2021-07-05 14:50:05 --> Model "Users_model" initialized
INFO - 2021-07-05 14:50:05 --> Model "Settings_model" initialized
INFO - 2021-07-05 14:50:05 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 14:50:05 --> Model "Permissions_model" initialized
INFO - 2021-07-05 14:50:05 --> Model "Roles_model" initialized
INFO - 2021-07-05 14:50:05 --> Model "Activity_model" initialized
INFO - 2021-07-05 14:50:05 --> Model "Templates_model" initialized
INFO - 2021-07-05 14:50:05 --> Database Driver Class Initialized
INFO - 2021-07-05 14:50:05 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 14:50:05 --> Controller Class Initialized
ERROR - 2021-07-05 17:50:05 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 17:50:05 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 17:50:05 --> Final output sent to browser
DEBUG - 2021-07-05 17:50:05 --> Total execution time: 0.1559
INFO - 2021-07-05 14:52:10 --> Config Class Initialized
INFO - 2021-07-05 14:52:10 --> Hooks Class Initialized
DEBUG - 2021-07-05 14:52:10 --> UTF-8 Support Enabled
INFO - 2021-07-05 14:52:10 --> Utf8 Class Initialized
INFO - 2021-07-05 14:52:10 --> URI Class Initialized
INFO - 2021-07-05 14:52:10 --> Router Class Initialized
INFO - 2021-07-05 14:52:10 --> Output Class Initialized
INFO - 2021-07-05 14:52:10 --> Security Class Initialized
DEBUG - 2021-07-05 14:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 14:52:10 --> Input Class Initialized
INFO - 2021-07-05 14:52:10 --> Language Class Initialized
INFO - 2021-07-05 14:52:10 --> Loader Class Initialized
INFO - 2021-07-05 14:52:10 --> Helper loaded: basic_helper
INFO - 2021-07-05 14:52:10 --> Helper loaded: url_helper
INFO - 2021-07-05 14:52:10 --> Helper loaded: file_helper
INFO - 2021-07-05 14:52:10 --> Helper loaded: form_helper
INFO - 2021-07-05 14:52:10 --> Helper loaded: cookie_helper
INFO - 2021-07-05 14:52:10 --> Helper loaded: security_helper
INFO - 2021-07-05 14:52:10 --> Helper loaded: directory_helper
INFO - 2021-07-05 14:52:10 --> Helper loaded: language_helper
INFO - 2021-07-05 14:52:10 --> Helper loaded: general_helper
INFO - 2021-07-05 14:52:10 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 14:52:10 --> Database Driver Class Initialized
DEBUG - 2021-07-05 14:52:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 14:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 14:52:10 --> Parser Class Initialized
INFO - 2021-07-05 14:52:10 --> Form Validation Class Initialized
INFO - 2021-07-05 14:52:10 --> Upload Class Initialized
INFO - 2021-07-05 14:52:10 --> Email Class Initialized
INFO - 2021-07-05 14:52:10 --> MY_Model class loaded
INFO - 2021-07-05 14:52:10 --> Model "Users_model" initialized
INFO - 2021-07-05 14:52:10 --> Model "Settings_model" initialized
INFO - 2021-07-05 14:52:10 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 14:52:10 --> Model "Permissions_model" initialized
INFO - 2021-07-05 14:52:10 --> Model "Roles_model" initialized
INFO - 2021-07-05 14:52:10 --> Model "Activity_model" initialized
INFO - 2021-07-05 14:52:10 --> Model "Templates_model" initialized
INFO - 2021-07-05 14:52:10 --> Database Driver Class Initialized
INFO - 2021-07-05 14:52:10 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 14:52:10 --> Controller Class Initialized
ERROR - 2021-07-05 17:52:10 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 17:52:10 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 17:52:10 --> Final output sent to browser
DEBUG - 2021-07-05 17:52:10 --> Total execution time: 0.1323
INFO - 2021-07-05 14:53:19 --> Config Class Initialized
INFO - 2021-07-05 14:53:19 --> Hooks Class Initialized
DEBUG - 2021-07-05 14:53:19 --> UTF-8 Support Enabled
INFO - 2021-07-05 14:53:19 --> Utf8 Class Initialized
INFO - 2021-07-05 14:53:19 --> URI Class Initialized
INFO - 2021-07-05 14:53:19 --> Router Class Initialized
INFO - 2021-07-05 14:53:19 --> Output Class Initialized
INFO - 2021-07-05 14:53:19 --> Security Class Initialized
DEBUG - 2021-07-05 14:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 14:53:19 --> Input Class Initialized
INFO - 2021-07-05 14:53:19 --> Language Class Initialized
INFO - 2021-07-05 14:53:19 --> Loader Class Initialized
INFO - 2021-07-05 14:53:19 --> Helper loaded: basic_helper
INFO - 2021-07-05 14:53:19 --> Helper loaded: url_helper
INFO - 2021-07-05 14:53:19 --> Helper loaded: file_helper
INFO - 2021-07-05 14:53:19 --> Helper loaded: form_helper
INFO - 2021-07-05 14:53:19 --> Helper loaded: cookie_helper
INFO - 2021-07-05 14:53:19 --> Helper loaded: security_helper
INFO - 2021-07-05 14:53:19 --> Helper loaded: directory_helper
INFO - 2021-07-05 14:53:19 --> Helper loaded: language_helper
INFO - 2021-07-05 14:53:19 --> Helper loaded: general_helper
INFO - 2021-07-05 14:53:19 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 14:53:19 --> Database Driver Class Initialized
DEBUG - 2021-07-05 14:53:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 14:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 14:53:19 --> Parser Class Initialized
INFO - 2021-07-05 14:53:19 --> Form Validation Class Initialized
INFO - 2021-07-05 14:53:19 --> Upload Class Initialized
INFO - 2021-07-05 14:53:19 --> Email Class Initialized
INFO - 2021-07-05 14:53:19 --> MY_Model class loaded
INFO - 2021-07-05 14:53:19 --> Model "Users_model" initialized
INFO - 2021-07-05 14:53:19 --> Model "Settings_model" initialized
INFO - 2021-07-05 14:53:19 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 14:53:19 --> Model "Permissions_model" initialized
INFO - 2021-07-05 14:53:19 --> Model "Roles_model" initialized
INFO - 2021-07-05 14:53:19 --> Model "Activity_model" initialized
INFO - 2021-07-05 14:53:19 --> Model "Templates_model" initialized
INFO - 2021-07-05 14:53:19 --> Database Driver Class Initialized
INFO - 2021-07-05 14:53:19 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 14:53:19 --> Controller Class Initialized
ERROR - 2021-07-05 17:53:19 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 17:53:19 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 17:53:19 --> Final output sent to browser
DEBUG - 2021-07-05 17:53:19 --> Total execution time: 0.1416
INFO - 2021-07-05 14:53:28 --> Config Class Initialized
INFO - 2021-07-05 14:53:28 --> Hooks Class Initialized
DEBUG - 2021-07-05 14:53:28 --> UTF-8 Support Enabled
INFO - 2021-07-05 14:53:28 --> Utf8 Class Initialized
INFO - 2021-07-05 14:53:28 --> URI Class Initialized
INFO - 2021-07-05 14:53:28 --> Router Class Initialized
INFO - 2021-07-05 14:53:28 --> Output Class Initialized
INFO - 2021-07-05 14:53:28 --> Security Class Initialized
DEBUG - 2021-07-05 14:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 14:53:28 --> Input Class Initialized
INFO - 2021-07-05 14:53:28 --> Language Class Initialized
INFO - 2021-07-05 14:53:28 --> Loader Class Initialized
INFO - 2021-07-05 14:53:28 --> Helper loaded: basic_helper
INFO - 2021-07-05 14:53:28 --> Helper loaded: url_helper
INFO - 2021-07-05 14:53:28 --> Helper loaded: file_helper
INFO - 2021-07-05 14:53:28 --> Helper loaded: form_helper
INFO - 2021-07-05 14:53:28 --> Helper loaded: cookie_helper
INFO - 2021-07-05 14:53:28 --> Helper loaded: security_helper
INFO - 2021-07-05 14:53:28 --> Helper loaded: directory_helper
INFO - 2021-07-05 14:53:28 --> Helper loaded: language_helper
INFO - 2021-07-05 14:53:28 --> Helper loaded: general_helper
INFO - 2021-07-05 14:53:28 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 14:53:28 --> Database Driver Class Initialized
DEBUG - 2021-07-05 14:53:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 14:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 14:53:28 --> Parser Class Initialized
INFO - 2021-07-05 14:53:28 --> Form Validation Class Initialized
INFO - 2021-07-05 14:53:28 --> Upload Class Initialized
INFO - 2021-07-05 14:53:28 --> Email Class Initialized
INFO - 2021-07-05 14:53:28 --> MY_Model class loaded
INFO - 2021-07-05 14:53:28 --> Model "Users_model" initialized
INFO - 2021-07-05 14:53:28 --> Model "Settings_model" initialized
INFO - 2021-07-05 14:53:28 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 14:53:28 --> Model "Permissions_model" initialized
INFO - 2021-07-05 14:53:28 --> Model "Roles_model" initialized
INFO - 2021-07-05 14:53:28 --> Model "Activity_model" initialized
INFO - 2021-07-05 14:53:28 --> Model "Templates_model" initialized
INFO - 2021-07-05 14:53:28 --> Database Driver Class Initialized
INFO - 2021-07-05 14:53:28 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 14:53:28 --> Controller Class Initialized
ERROR - 2021-07-05 17:53:28 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 17:53:28 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 17:53:28 --> Final output sent to browser
DEBUG - 2021-07-05 17:53:28 --> Total execution time: 0.1262
INFO - 2021-07-05 14:53:29 --> Config Class Initialized
INFO - 2021-07-05 14:53:29 --> Hooks Class Initialized
DEBUG - 2021-07-05 14:53:29 --> UTF-8 Support Enabled
INFO - 2021-07-05 14:53:29 --> Utf8 Class Initialized
INFO - 2021-07-05 14:53:29 --> URI Class Initialized
INFO - 2021-07-05 14:53:29 --> Router Class Initialized
INFO - 2021-07-05 14:53:29 --> Output Class Initialized
INFO - 2021-07-05 14:53:29 --> Security Class Initialized
DEBUG - 2021-07-05 14:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 14:53:29 --> Input Class Initialized
INFO - 2021-07-05 14:53:29 --> Language Class Initialized
INFO - 2021-07-05 14:53:29 --> Loader Class Initialized
INFO - 2021-07-05 14:53:29 --> Helper loaded: basic_helper
INFO - 2021-07-05 14:53:29 --> Helper loaded: url_helper
INFO - 2021-07-05 14:53:29 --> Helper loaded: file_helper
INFO - 2021-07-05 14:53:29 --> Helper loaded: form_helper
INFO - 2021-07-05 14:53:29 --> Helper loaded: cookie_helper
INFO - 2021-07-05 14:53:29 --> Helper loaded: security_helper
INFO - 2021-07-05 14:53:29 --> Helper loaded: directory_helper
INFO - 2021-07-05 14:53:29 --> Helper loaded: language_helper
INFO - 2021-07-05 14:53:29 --> Helper loaded: general_helper
INFO - 2021-07-05 14:53:29 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 14:53:29 --> Database Driver Class Initialized
DEBUG - 2021-07-05 14:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 14:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 14:53:29 --> Parser Class Initialized
INFO - 2021-07-05 14:53:29 --> Form Validation Class Initialized
INFO - 2021-07-05 14:53:29 --> Upload Class Initialized
INFO - 2021-07-05 14:53:29 --> Email Class Initialized
INFO - 2021-07-05 14:53:29 --> MY_Model class loaded
INFO - 2021-07-05 14:53:29 --> Model "Users_model" initialized
INFO - 2021-07-05 14:53:29 --> Model "Settings_model" initialized
INFO - 2021-07-05 14:53:29 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 14:53:29 --> Model "Permissions_model" initialized
INFO - 2021-07-05 14:53:29 --> Model "Roles_model" initialized
INFO - 2021-07-05 14:53:29 --> Model "Activity_model" initialized
INFO - 2021-07-05 14:53:29 --> Model "Templates_model" initialized
INFO - 2021-07-05 14:53:29 --> Database Driver Class Initialized
INFO - 2021-07-05 14:53:29 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 14:53:29 --> Controller Class Initialized
ERROR - 2021-07-05 17:53:29 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 17:53:29 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 17:53:29 --> Final output sent to browser
DEBUG - 2021-07-05 17:53:29 --> Total execution time: 0.0593
INFO - 2021-07-05 14:53:30 --> Config Class Initialized
INFO - 2021-07-05 14:53:30 --> Hooks Class Initialized
DEBUG - 2021-07-05 14:53:30 --> UTF-8 Support Enabled
INFO - 2021-07-05 14:53:30 --> Utf8 Class Initialized
INFO - 2021-07-05 14:53:30 --> URI Class Initialized
INFO - 2021-07-05 14:53:30 --> Router Class Initialized
INFO - 2021-07-05 14:53:30 --> Output Class Initialized
INFO - 2021-07-05 14:53:30 --> Security Class Initialized
DEBUG - 2021-07-05 14:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 14:53:30 --> Input Class Initialized
INFO - 2021-07-05 14:53:30 --> Language Class Initialized
INFO - 2021-07-05 14:53:30 --> Loader Class Initialized
INFO - 2021-07-05 14:53:30 --> Helper loaded: basic_helper
INFO - 2021-07-05 14:53:30 --> Helper loaded: url_helper
INFO - 2021-07-05 14:53:30 --> Helper loaded: file_helper
INFO - 2021-07-05 14:53:30 --> Helper loaded: form_helper
INFO - 2021-07-05 14:53:30 --> Helper loaded: cookie_helper
INFO - 2021-07-05 14:53:30 --> Helper loaded: security_helper
INFO - 2021-07-05 14:53:30 --> Helper loaded: directory_helper
INFO - 2021-07-05 14:53:30 --> Helper loaded: language_helper
INFO - 2021-07-05 14:53:30 --> Helper loaded: general_helper
INFO - 2021-07-05 14:53:30 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 14:53:30 --> Database Driver Class Initialized
DEBUG - 2021-07-05 14:53:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 14:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 14:53:30 --> Parser Class Initialized
INFO - 2021-07-05 14:53:30 --> Form Validation Class Initialized
INFO - 2021-07-05 14:53:30 --> Upload Class Initialized
INFO - 2021-07-05 14:53:30 --> Email Class Initialized
INFO - 2021-07-05 14:53:30 --> MY_Model class loaded
INFO - 2021-07-05 14:53:30 --> Model "Users_model" initialized
INFO - 2021-07-05 14:53:30 --> Model "Settings_model" initialized
INFO - 2021-07-05 14:53:30 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 14:53:30 --> Model "Permissions_model" initialized
INFO - 2021-07-05 14:53:30 --> Model "Roles_model" initialized
INFO - 2021-07-05 14:53:30 --> Model "Activity_model" initialized
INFO - 2021-07-05 14:53:30 --> Model "Templates_model" initialized
INFO - 2021-07-05 14:53:30 --> Database Driver Class Initialized
INFO - 2021-07-05 14:53:30 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 14:53:30 --> Controller Class Initialized
ERROR - 2021-07-05 17:53:30 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 17:53:30 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 17:53:30 --> Final output sent to browser
DEBUG - 2021-07-05 17:53:30 --> Total execution time: 0.0604
INFO - 2021-07-05 14:53:30 --> Config Class Initialized
INFO - 2021-07-05 14:53:30 --> Hooks Class Initialized
DEBUG - 2021-07-05 14:53:30 --> UTF-8 Support Enabled
INFO - 2021-07-05 14:53:30 --> Utf8 Class Initialized
INFO - 2021-07-05 14:53:30 --> URI Class Initialized
INFO - 2021-07-05 14:53:30 --> Router Class Initialized
INFO - 2021-07-05 14:53:30 --> Output Class Initialized
INFO - 2021-07-05 14:53:30 --> Security Class Initialized
DEBUG - 2021-07-05 14:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 14:53:30 --> Input Class Initialized
INFO - 2021-07-05 14:53:30 --> Language Class Initialized
INFO - 2021-07-05 14:53:30 --> Loader Class Initialized
INFO - 2021-07-05 14:53:30 --> Helper loaded: basic_helper
INFO - 2021-07-05 14:53:30 --> Helper loaded: url_helper
INFO - 2021-07-05 14:53:30 --> Helper loaded: file_helper
INFO - 2021-07-05 14:53:30 --> Helper loaded: form_helper
INFO - 2021-07-05 14:53:30 --> Helper loaded: cookie_helper
INFO - 2021-07-05 14:53:30 --> Helper loaded: security_helper
INFO - 2021-07-05 14:53:30 --> Helper loaded: directory_helper
INFO - 2021-07-05 14:53:30 --> Helper loaded: language_helper
INFO - 2021-07-05 14:53:30 --> Helper loaded: general_helper
INFO - 2021-07-05 14:53:30 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 14:53:30 --> Database Driver Class Initialized
DEBUG - 2021-07-05 14:53:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 14:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 14:53:30 --> Parser Class Initialized
INFO - 2021-07-05 14:53:30 --> Form Validation Class Initialized
INFO - 2021-07-05 14:53:30 --> Upload Class Initialized
INFO - 2021-07-05 14:53:30 --> Email Class Initialized
INFO - 2021-07-05 14:53:30 --> MY_Model class loaded
INFO - 2021-07-05 14:53:30 --> Model "Users_model" initialized
INFO - 2021-07-05 14:53:30 --> Model "Settings_model" initialized
INFO - 2021-07-05 14:53:30 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 14:53:30 --> Model "Permissions_model" initialized
INFO - 2021-07-05 14:53:30 --> Model "Roles_model" initialized
INFO - 2021-07-05 14:53:30 --> Model "Activity_model" initialized
INFO - 2021-07-05 14:53:30 --> Model "Templates_model" initialized
INFO - 2021-07-05 14:53:30 --> Database Driver Class Initialized
INFO - 2021-07-05 14:53:30 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 14:53:30 --> Controller Class Initialized
ERROR - 2021-07-05 17:53:30 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 17:53:30 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 17:53:30 --> Final output sent to browser
DEBUG - 2021-07-05 17:53:30 --> Total execution time: 0.0835
INFO - 2021-07-05 14:53:30 --> Config Class Initialized
INFO - 2021-07-05 14:53:30 --> Hooks Class Initialized
DEBUG - 2021-07-05 14:53:30 --> UTF-8 Support Enabled
INFO - 2021-07-05 14:53:30 --> Utf8 Class Initialized
INFO - 2021-07-05 14:53:30 --> URI Class Initialized
INFO - 2021-07-05 14:53:30 --> Router Class Initialized
INFO - 2021-07-05 14:53:30 --> Output Class Initialized
INFO - 2021-07-05 14:53:30 --> Security Class Initialized
DEBUG - 2021-07-05 14:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 14:53:30 --> Input Class Initialized
INFO - 2021-07-05 14:53:30 --> Language Class Initialized
INFO - 2021-07-05 14:53:30 --> Loader Class Initialized
INFO - 2021-07-05 14:53:30 --> Helper loaded: basic_helper
INFO - 2021-07-05 14:53:30 --> Helper loaded: url_helper
INFO - 2021-07-05 14:53:30 --> Helper loaded: file_helper
INFO - 2021-07-05 14:53:30 --> Helper loaded: form_helper
INFO - 2021-07-05 14:53:30 --> Helper loaded: cookie_helper
INFO - 2021-07-05 14:53:30 --> Helper loaded: security_helper
INFO - 2021-07-05 14:53:30 --> Helper loaded: directory_helper
INFO - 2021-07-05 14:53:30 --> Helper loaded: language_helper
INFO - 2021-07-05 14:53:30 --> Helper loaded: general_helper
INFO - 2021-07-05 14:53:30 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 14:53:30 --> Database Driver Class Initialized
DEBUG - 2021-07-05 14:53:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 14:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 14:53:30 --> Parser Class Initialized
INFO - 2021-07-05 14:53:30 --> Form Validation Class Initialized
INFO - 2021-07-05 14:53:30 --> Upload Class Initialized
INFO - 2021-07-05 14:53:30 --> Email Class Initialized
INFO - 2021-07-05 14:53:30 --> MY_Model class loaded
INFO - 2021-07-05 14:53:30 --> Model "Users_model" initialized
INFO - 2021-07-05 14:53:30 --> Model "Settings_model" initialized
INFO - 2021-07-05 14:53:30 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 14:53:30 --> Model "Permissions_model" initialized
INFO - 2021-07-05 14:53:30 --> Model "Roles_model" initialized
INFO - 2021-07-05 14:53:30 --> Model "Activity_model" initialized
INFO - 2021-07-05 14:53:30 --> Model "Templates_model" initialized
INFO - 2021-07-05 14:53:30 --> Database Driver Class Initialized
INFO - 2021-07-05 14:53:30 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 14:53:30 --> Controller Class Initialized
ERROR - 2021-07-05 17:53:30 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 17:53:30 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 17:53:30 --> Final output sent to browser
DEBUG - 2021-07-05 17:53:30 --> Total execution time: 0.0602
INFO - 2021-07-05 14:53:31 --> Config Class Initialized
INFO - 2021-07-05 14:53:31 --> Hooks Class Initialized
DEBUG - 2021-07-05 14:53:31 --> UTF-8 Support Enabled
INFO - 2021-07-05 14:53:31 --> Utf8 Class Initialized
INFO - 2021-07-05 14:53:31 --> URI Class Initialized
INFO - 2021-07-05 14:53:31 --> Router Class Initialized
INFO - 2021-07-05 14:53:31 --> Output Class Initialized
INFO - 2021-07-05 14:53:31 --> Security Class Initialized
DEBUG - 2021-07-05 14:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 14:53:31 --> Input Class Initialized
INFO - 2021-07-05 14:53:31 --> Language Class Initialized
INFO - 2021-07-05 14:53:31 --> Loader Class Initialized
INFO - 2021-07-05 14:53:31 --> Helper loaded: basic_helper
INFO - 2021-07-05 14:53:31 --> Helper loaded: url_helper
INFO - 2021-07-05 14:53:31 --> Helper loaded: file_helper
INFO - 2021-07-05 14:53:31 --> Helper loaded: form_helper
INFO - 2021-07-05 14:53:31 --> Helper loaded: cookie_helper
INFO - 2021-07-05 14:53:31 --> Helper loaded: security_helper
INFO - 2021-07-05 14:53:31 --> Helper loaded: directory_helper
INFO - 2021-07-05 14:53:31 --> Helper loaded: language_helper
INFO - 2021-07-05 14:53:31 --> Helper loaded: general_helper
INFO - 2021-07-05 14:53:31 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 14:53:31 --> Database Driver Class Initialized
DEBUG - 2021-07-05 14:53:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 14:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 14:53:31 --> Parser Class Initialized
INFO - 2021-07-05 14:53:31 --> Form Validation Class Initialized
INFO - 2021-07-05 14:53:31 --> Upload Class Initialized
INFO - 2021-07-05 14:53:31 --> Email Class Initialized
INFO - 2021-07-05 14:53:31 --> MY_Model class loaded
INFO - 2021-07-05 14:53:31 --> Model "Users_model" initialized
INFO - 2021-07-05 14:53:31 --> Model "Settings_model" initialized
INFO - 2021-07-05 14:53:31 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 14:53:31 --> Model "Permissions_model" initialized
INFO - 2021-07-05 14:53:31 --> Model "Roles_model" initialized
INFO - 2021-07-05 14:53:31 --> Model "Activity_model" initialized
INFO - 2021-07-05 14:53:31 --> Model "Templates_model" initialized
INFO - 2021-07-05 14:53:31 --> Database Driver Class Initialized
INFO - 2021-07-05 14:53:31 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 14:53:31 --> Controller Class Initialized
ERROR - 2021-07-05 17:53:31 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 17:53:31 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 17:53:31 --> Final output sent to browser
DEBUG - 2021-07-05 17:53:31 --> Total execution time: 0.0923
INFO - 2021-07-05 14:53:31 --> Config Class Initialized
INFO - 2021-07-05 14:53:31 --> Hooks Class Initialized
DEBUG - 2021-07-05 14:53:31 --> UTF-8 Support Enabled
INFO - 2021-07-05 14:53:31 --> Utf8 Class Initialized
INFO - 2021-07-05 14:53:31 --> URI Class Initialized
INFO - 2021-07-05 14:53:31 --> Router Class Initialized
INFO - 2021-07-05 14:53:31 --> Output Class Initialized
INFO - 2021-07-05 14:53:31 --> Security Class Initialized
DEBUG - 2021-07-05 14:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 14:53:31 --> Input Class Initialized
INFO - 2021-07-05 14:53:31 --> Language Class Initialized
INFO - 2021-07-05 14:53:31 --> Loader Class Initialized
INFO - 2021-07-05 14:53:31 --> Helper loaded: basic_helper
INFO - 2021-07-05 14:53:31 --> Helper loaded: url_helper
INFO - 2021-07-05 14:53:31 --> Helper loaded: file_helper
INFO - 2021-07-05 14:53:31 --> Helper loaded: form_helper
INFO - 2021-07-05 14:53:31 --> Helper loaded: cookie_helper
INFO - 2021-07-05 14:53:31 --> Helper loaded: security_helper
INFO - 2021-07-05 14:53:31 --> Helper loaded: directory_helper
INFO - 2021-07-05 14:53:31 --> Helper loaded: language_helper
INFO - 2021-07-05 14:53:31 --> Helper loaded: general_helper
INFO - 2021-07-05 14:53:31 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 14:53:31 --> Database Driver Class Initialized
DEBUG - 2021-07-05 14:53:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 14:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 14:53:31 --> Parser Class Initialized
INFO - 2021-07-05 14:53:31 --> Form Validation Class Initialized
INFO - 2021-07-05 14:53:31 --> Upload Class Initialized
INFO - 2021-07-05 14:53:31 --> Email Class Initialized
INFO - 2021-07-05 14:53:31 --> MY_Model class loaded
INFO - 2021-07-05 14:53:31 --> Model "Users_model" initialized
INFO - 2021-07-05 14:53:31 --> Model "Settings_model" initialized
INFO - 2021-07-05 14:53:31 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 14:53:31 --> Model "Permissions_model" initialized
INFO - 2021-07-05 14:53:31 --> Model "Roles_model" initialized
INFO - 2021-07-05 14:53:31 --> Model "Activity_model" initialized
INFO - 2021-07-05 14:53:31 --> Model "Templates_model" initialized
INFO - 2021-07-05 14:53:31 --> Database Driver Class Initialized
INFO - 2021-07-05 14:53:31 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 14:53:31 --> Controller Class Initialized
ERROR - 2021-07-05 17:53:31 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 17:53:31 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 17:53:31 --> Final output sent to browser
DEBUG - 2021-07-05 17:53:31 --> Total execution time: 0.0592
INFO - 2021-07-05 14:54:17 --> Config Class Initialized
INFO - 2021-07-05 14:54:17 --> Hooks Class Initialized
DEBUG - 2021-07-05 14:54:17 --> UTF-8 Support Enabled
INFO - 2021-07-05 14:54:17 --> Utf8 Class Initialized
INFO - 2021-07-05 14:54:17 --> URI Class Initialized
INFO - 2021-07-05 14:54:17 --> Router Class Initialized
INFO - 2021-07-05 14:54:17 --> Output Class Initialized
INFO - 2021-07-05 14:54:17 --> Security Class Initialized
DEBUG - 2021-07-05 14:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 14:54:17 --> Input Class Initialized
INFO - 2021-07-05 14:54:17 --> Language Class Initialized
INFO - 2021-07-05 14:54:17 --> Loader Class Initialized
INFO - 2021-07-05 14:54:17 --> Helper loaded: basic_helper
INFO - 2021-07-05 14:54:17 --> Helper loaded: url_helper
INFO - 2021-07-05 14:54:17 --> Helper loaded: file_helper
INFO - 2021-07-05 14:54:17 --> Helper loaded: form_helper
INFO - 2021-07-05 14:54:17 --> Helper loaded: cookie_helper
INFO - 2021-07-05 14:54:17 --> Helper loaded: security_helper
INFO - 2021-07-05 14:54:17 --> Helper loaded: directory_helper
INFO - 2021-07-05 14:54:17 --> Helper loaded: language_helper
INFO - 2021-07-05 14:54:17 --> Helper loaded: general_helper
INFO - 2021-07-05 14:54:17 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 14:54:17 --> Database Driver Class Initialized
DEBUG - 2021-07-05 14:54:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 14:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 14:54:17 --> Parser Class Initialized
INFO - 2021-07-05 14:54:17 --> Form Validation Class Initialized
INFO - 2021-07-05 14:54:17 --> Upload Class Initialized
INFO - 2021-07-05 14:54:17 --> Email Class Initialized
INFO - 2021-07-05 14:54:17 --> MY_Model class loaded
INFO - 2021-07-05 14:54:17 --> Model "Users_model" initialized
INFO - 2021-07-05 14:54:17 --> Model "Settings_model" initialized
INFO - 2021-07-05 14:54:17 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 14:54:17 --> Model "Permissions_model" initialized
INFO - 2021-07-05 14:54:17 --> Model "Roles_model" initialized
INFO - 2021-07-05 14:54:17 --> Model "Activity_model" initialized
INFO - 2021-07-05 14:54:17 --> Model "Templates_model" initialized
INFO - 2021-07-05 14:54:17 --> Database Driver Class Initialized
INFO - 2021-07-05 14:54:17 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 14:54:17 --> Controller Class Initialized
ERROR - 2021-07-05 17:54:17 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 17:54:17 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 17:54:17 --> Final output sent to browser
DEBUG - 2021-07-05 17:54:17 --> Total execution time: 0.1410
INFO - 2021-07-05 14:54:18 --> Config Class Initialized
INFO - 2021-07-05 14:54:18 --> Hooks Class Initialized
DEBUG - 2021-07-05 14:54:18 --> UTF-8 Support Enabled
INFO - 2021-07-05 14:54:18 --> Utf8 Class Initialized
INFO - 2021-07-05 14:54:18 --> URI Class Initialized
INFO - 2021-07-05 14:54:18 --> Router Class Initialized
INFO - 2021-07-05 14:54:18 --> Output Class Initialized
INFO - 2021-07-05 14:54:18 --> Security Class Initialized
DEBUG - 2021-07-05 14:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 14:54:18 --> Input Class Initialized
INFO - 2021-07-05 14:54:18 --> Language Class Initialized
INFO - 2021-07-05 14:54:18 --> Loader Class Initialized
INFO - 2021-07-05 14:54:18 --> Helper loaded: basic_helper
INFO - 2021-07-05 14:54:18 --> Helper loaded: url_helper
INFO - 2021-07-05 14:54:18 --> Helper loaded: file_helper
INFO - 2021-07-05 14:54:18 --> Helper loaded: form_helper
INFO - 2021-07-05 14:54:18 --> Helper loaded: cookie_helper
INFO - 2021-07-05 14:54:18 --> Helper loaded: security_helper
INFO - 2021-07-05 14:54:18 --> Helper loaded: directory_helper
INFO - 2021-07-05 14:54:18 --> Helper loaded: language_helper
INFO - 2021-07-05 14:54:18 --> Helper loaded: general_helper
INFO - 2021-07-05 14:54:18 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 14:54:18 --> Database Driver Class Initialized
DEBUG - 2021-07-05 14:54:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 14:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 14:54:18 --> Parser Class Initialized
INFO - 2021-07-05 14:54:18 --> Form Validation Class Initialized
INFO - 2021-07-05 14:54:18 --> Upload Class Initialized
INFO - 2021-07-05 14:54:18 --> Email Class Initialized
INFO - 2021-07-05 14:54:18 --> MY_Model class loaded
INFO - 2021-07-05 14:54:18 --> Model "Users_model" initialized
INFO - 2021-07-05 14:54:18 --> Model "Settings_model" initialized
INFO - 2021-07-05 14:54:18 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 14:54:18 --> Model "Permissions_model" initialized
INFO - 2021-07-05 14:54:18 --> Model "Roles_model" initialized
INFO - 2021-07-05 14:54:18 --> Model "Activity_model" initialized
INFO - 2021-07-05 14:54:18 --> Model "Templates_model" initialized
INFO - 2021-07-05 14:54:18 --> Database Driver Class Initialized
INFO - 2021-07-05 14:54:18 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 14:54:18 --> Controller Class Initialized
ERROR - 2021-07-05 17:54:18 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 17:54:18 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 17:54:18 --> Final output sent to browser
DEBUG - 2021-07-05 17:54:18 --> Total execution time: 0.0580
INFO - 2021-07-05 14:54:19 --> Config Class Initialized
INFO - 2021-07-05 14:54:19 --> Hooks Class Initialized
DEBUG - 2021-07-05 14:54:19 --> UTF-8 Support Enabled
INFO - 2021-07-05 14:54:19 --> Utf8 Class Initialized
INFO - 2021-07-05 14:54:19 --> URI Class Initialized
INFO - 2021-07-05 14:54:19 --> Router Class Initialized
INFO - 2021-07-05 14:54:19 --> Output Class Initialized
INFO - 2021-07-05 14:54:19 --> Security Class Initialized
DEBUG - 2021-07-05 14:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 14:54:19 --> Input Class Initialized
INFO - 2021-07-05 14:54:19 --> Language Class Initialized
INFO - 2021-07-05 14:54:19 --> Loader Class Initialized
INFO - 2021-07-05 14:54:19 --> Helper loaded: basic_helper
INFO - 2021-07-05 14:54:19 --> Helper loaded: url_helper
INFO - 2021-07-05 14:54:19 --> Helper loaded: file_helper
INFO - 2021-07-05 14:54:19 --> Helper loaded: form_helper
INFO - 2021-07-05 14:54:19 --> Helper loaded: cookie_helper
INFO - 2021-07-05 14:54:19 --> Helper loaded: security_helper
INFO - 2021-07-05 14:54:19 --> Helper loaded: directory_helper
INFO - 2021-07-05 14:54:19 --> Helper loaded: language_helper
INFO - 2021-07-05 14:54:19 --> Helper loaded: general_helper
INFO - 2021-07-05 14:54:19 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 14:54:19 --> Database Driver Class Initialized
DEBUG - 2021-07-05 14:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 14:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 14:54:19 --> Parser Class Initialized
INFO - 2021-07-05 14:54:19 --> Form Validation Class Initialized
INFO - 2021-07-05 14:54:19 --> Upload Class Initialized
INFO - 2021-07-05 14:54:19 --> Email Class Initialized
INFO - 2021-07-05 14:54:19 --> MY_Model class loaded
INFO - 2021-07-05 14:54:19 --> Model "Users_model" initialized
INFO - 2021-07-05 14:54:19 --> Model "Settings_model" initialized
INFO - 2021-07-05 14:54:19 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 14:54:19 --> Model "Permissions_model" initialized
INFO - 2021-07-05 14:54:19 --> Model "Roles_model" initialized
INFO - 2021-07-05 14:54:19 --> Model "Activity_model" initialized
INFO - 2021-07-05 14:54:19 --> Model "Templates_model" initialized
INFO - 2021-07-05 14:54:19 --> Database Driver Class Initialized
INFO - 2021-07-05 14:54:19 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 14:54:19 --> Controller Class Initialized
ERROR - 2021-07-05 17:54:19 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 17:54:19 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 17:54:19 --> Final output sent to browser
DEBUG - 2021-07-05 17:54:19 --> Total execution time: 0.0600
INFO - 2021-07-05 14:55:03 --> Config Class Initialized
INFO - 2021-07-05 14:55:03 --> Hooks Class Initialized
DEBUG - 2021-07-05 14:55:03 --> UTF-8 Support Enabled
INFO - 2021-07-05 14:55:03 --> Utf8 Class Initialized
INFO - 2021-07-05 14:55:03 --> URI Class Initialized
INFO - 2021-07-05 14:55:03 --> Router Class Initialized
INFO - 2021-07-05 14:55:03 --> Output Class Initialized
INFO - 2021-07-05 14:55:03 --> Security Class Initialized
DEBUG - 2021-07-05 14:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 14:55:03 --> Input Class Initialized
INFO - 2021-07-05 14:55:03 --> Language Class Initialized
INFO - 2021-07-05 14:55:03 --> Loader Class Initialized
INFO - 2021-07-05 14:55:03 --> Helper loaded: basic_helper
INFO - 2021-07-05 14:55:03 --> Helper loaded: url_helper
INFO - 2021-07-05 14:55:03 --> Helper loaded: file_helper
INFO - 2021-07-05 14:55:03 --> Helper loaded: form_helper
INFO - 2021-07-05 14:55:03 --> Helper loaded: cookie_helper
INFO - 2021-07-05 14:55:03 --> Helper loaded: security_helper
INFO - 2021-07-05 14:55:03 --> Helper loaded: directory_helper
INFO - 2021-07-05 14:55:03 --> Helper loaded: language_helper
INFO - 2021-07-05 14:55:03 --> Helper loaded: general_helper
INFO - 2021-07-05 14:55:03 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 14:55:03 --> Database Driver Class Initialized
DEBUG - 2021-07-05 14:55:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 14:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 14:55:03 --> Parser Class Initialized
INFO - 2021-07-05 14:55:03 --> Form Validation Class Initialized
INFO - 2021-07-05 14:55:03 --> Upload Class Initialized
INFO - 2021-07-05 14:55:03 --> Email Class Initialized
INFO - 2021-07-05 14:55:03 --> MY_Model class loaded
INFO - 2021-07-05 14:55:03 --> Model "Users_model" initialized
INFO - 2021-07-05 14:55:03 --> Model "Settings_model" initialized
INFO - 2021-07-05 14:55:03 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 14:55:03 --> Model "Permissions_model" initialized
INFO - 2021-07-05 14:55:03 --> Model "Roles_model" initialized
INFO - 2021-07-05 14:55:03 --> Model "Activity_model" initialized
INFO - 2021-07-05 14:55:03 --> Model "Templates_model" initialized
INFO - 2021-07-05 14:55:03 --> Database Driver Class Initialized
INFO - 2021-07-05 14:55:03 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 14:55:03 --> Controller Class Initialized
ERROR - 2021-07-05 17:55:03 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 17:55:03 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 17:55:03 --> Final output sent to browser
DEBUG - 2021-07-05 17:55:03 --> Total execution time: 0.1287
INFO - 2021-07-05 14:55:03 --> Config Class Initialized
INFO - 2021-07-05 14:55:03 --> Hooks Class Initialized
DEBUG - 2021-07-05 14:55:03 --> UTF-8 Support Enabled
INFO - 2021-07-05 14:55:03 --> Utf8 Class Initialized
INFO - 2021-07-05 14:55:03 --> URI Class Initialized
INFO - 2021-07-05 14:55:03 --> Router Class Initialized
INFO - 2021-07-05 14:55:03 --> Output Class Initialized
INFO - 2021-07-05 14:55:03 --> Security Class Initialized
DEBUG - 2021-07-05 14:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 14:55:03 --> Input Class Initialized
INFO - 2021-07-05 14:55:03 --> Language Class Initialized
INFO - 2021-07-05 14:55:03 --> Loader Class Initialized
INFO - 2021-07-05 14:55:03 --> Helper loaded: basic_helper
INFO - 2021-07-05 14:55:03 --> Helper loaded: url_helper
INFO - 2021-07-05 14:55:03 --> Helper loaded: file_helper
INFO - 2021-07-05 14:55:03 --> Helper loaded: form_helper
INFO - 2021-07-05 14:55:03 --> Helper loaded: cookie_helper
INFO - 2021-07-05 14:55:03 --> Helper loaded: security_helper
INFO - 2021-07-05 14:55:03 --> Helper loaded: directory_helper
INFO - 2021-07-05 14:55:03 --> Helper loaded: language_helper
INFO - 2021-07-05 14:55:03 --> Helper loaded: general_helper
INFO - 2021-07-05 14:55:03 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 14:55:03 --> Database Driver Class Initialized
DEBUG - 2021-07-05 14:55:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 14:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 14:55:03 --> Parser Class Initialized
INFO - 2021-07-05 14:55:03 --> Form Validation Class Initialized
INFO - 2021-07-05 14:55:03 --> Upload Class Initialized
INFO - 2021-07-05 14:55:03 --> Email Class Initialized
INFO - 2021-07-05 14:55:03 --> MY_Model class loaded
INFO - 2021-07-05 14:55:03 --> Model "Users_model" initialized
INFO - 2021-07-05 14:55:03 --> Model "Settings_model" initialized
INFO - 2021-07-05 14:55:03 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 14:55:03 --> Model "Permissions_model" initialized
INFO - 2021-07-05 14:55:03 --> Model "Roles_model" initialized
INFO - 2021-07-05 14:55:03 --> Model "Activity_model" initialized
INFO - 2021-07-05 14:55:03 --> Model "Templates_model" initialized
INFO - 2021-07-05 14:55:03 --> Database Driver Class Initialized
INFO - 2021-07-05 14:55:03 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 14:55:03 --> Controller Class Initialized
ERROR - 2021-07-05 17:55:03 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 17:55:03 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 17:55:03 --> Final output sent to browser
DEBUG - 2021-07-05 17:55:03 --> Total execution time: 0.0597
INFO - 2021-07-05 14:55:04 --> Config Class Initialized
INFO - 2021-07-05 14:55:04 --> Hooks Class Initialized
DEBUG - 2021-07-05 14:55:04 --> UTF-8 Support Enabled
INFO - 2021-07-05 14:55:04 --> Utf8 Class Initialized
INFO - 2021-07-05 14:55:04 --> URI Class Initialized
INFO - 2021-07-05 14:55:04 --> Router Class Initialized
INFO - 2021-07-05 14:55:04 --> Output Class Initialized
INFO - 2021-07-05 14:55:04 --> Security Class Initialized
DEBUG - 2021-07-05 14:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 14:55:04 --> Input Class Initialized
INFO - 2021-07-05 14:55:04 --> Language Class Initialized
INFO - 2021-07-05 14:55:04 --> Loader Class Initialized
INFO - 2021-07-05 14:55:04 --> Helper loaded: basic_helper
INFO - 2021-07-05 14:55:04 --> Helper loaded: url_helper
INFO - 2021-07-05 14:55:04 --> Helper loaded: file_helper
INFO - 2021-07-05 14:55:04 --> Helper loaded: form_helper
INFO - 2021-07-05 14:55:04 --> Helper loaded: cookie_helper
INFO - 2021-07-05 14:55:04 --> Helper loaded: security_helper
INFO - 2021-07-05 14:55:04 --> Helper loaded: directory_helper
INFO - 2021-07-05 14:55:04 --> Helper loaded: language_helper
INFO - 2021-07-05 14:55:04 --> Helper loaded: general_helper
INFO - 2021-07-05 14:55:04 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 14:55:04 --> Database Driver Class Initialized
DEBUG - 2021-07-05 14:55:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 14:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 14:55:04 --> Parser Class Initialized
INFO - 2021-07-05 14:55:04 --> Form Validation Class Initialized
INFO - 2021-07-05 14:55:04 --> Upload Class Initialized
INFO - 2021-07-05 14:55:04 --> Email Class Initialized
INFO - 2021-07-05 14:55:04 --> MY_Model class loaded
INFO - 2021-07-05 14:55:04 --> Model "Users_model" initialized
INFO - 2021-07-05 14:55:04 --> Model "Settings_model" initialized
INFO - 2021-07-05 14:55:04 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 14:55:04 --> Model "Permissions_model" initialized
INFO - 2021-07-05 14:55:04 --> Model "Roles_model" initialized
INFO - 2021-07-05 14:55:04 --> Model "Activity_model" initialized
INFO - 2021-07-05 14:55:04 --> Model "Templates_model" initialized
INFO - 2021-07-05 14:55:04 --> Database Driver Class Initialized
INFO - 2021-07-05 14:55:04 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 14:55:04 --> Controller Class Initialized
ERROR - 2021-07-05 17:55:04 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 17:55:04 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 17:55:04 --> Final output sent to browser
DEBUG - 2021-07-05 17:55:04 --> Total execution time: 0.0605
INFO - 2021-07-05 14:55:53 --> Config Class Initialized
INFO - 2021-07-05 14:55:53 --> Hooks Class Initialized
DEBUG - 2021-07-05 14:55:53 --> UTF-8 Support Enabled
INFO - 2021-07-05 14:55:53 --> Utf8 Class Initialized
INFO - 2021-07-05 14:55:53 --> URI Class Initialized
INFO - 2021-07-05 14:55:53 --> Router Class Initialized
INFO - 2021-07-05 14:55:53 --> Output Class Initialized
INFO - 2021-07-05 14:55:53 --> Security Class Initialized
DEBUG - 2021-07-05 14:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 14:55:53 --> Input Class Initialized
INFO - 2021-07-05 14:55:53 --> Language Class Initialized
INFO - 2021-07-05 14:55:53 --> Loader Class Initialized
INFO - 2021-07-05 14:55:53 --> Helper loaded: basic_helper
INFO - 2021-07-05 14:55:53 --> Helper loaded: url_helper
INFO - 2021-07-05 14:55:53 --> Helper loaded: file_helper
INFO - 2021-07-05 14:55:53 --> Helper loaded: form_helper
INFO - 2021-07-05 14:55:53 --> Helper loaded: cookie_helper
INFO - 2021-07-05 14:55:53 --> Helper loaded: security_helper
INFO - 2021-07-05 14:55:53 --> Helper loaded: directory_helper
INFO - 2021-07-05 14:55:53 --> Helper loaded: language_helper
INFO - 2021-07-05 14:55:53 --> Helper loaded: general_helper
INFO - 2021-07-05 14:55:53 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 14:55:53 --> Database Driver Class Initialized
DEBUG - 2021-07-05 14:55:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 14:55:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 14:55:53 --> Parser Class Initialized
INFO - 2021-07-05 14:55:53 --> Form Validation Class Initialized
INFO - 2021-07-05 14:55:53 --> Upload Class Initialized
INFO - 2021-07-05 14:55:53 --> Email Class Initialized
INFO - 2021-07-05 14:55:53 --> MY_Model class loaded
INFO - 2021-07-05 14:55:53 --> Model "Users_model" initialized
INFO - 2021-07-05 14:55:53 --> Model "Settings_model" initialized
INFO - 2021-07-05 14:55:53 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 14:55:53 --> Model "Permissions_model" initialized
INFO - 2021-07-05 14:55:53 --> Model "Roles_model" initialized
INFO - 2021-07-05 14:55:53 --> Model "Activity_model" initialized
INFO - 2021-07-05 14:55:53 --> Model "Templates_model" initialized
INFO - 2021-07-05 14:55:53 --> Database Driver Class Initialized
INFO - 2021-07-05 14:55:53 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 14:55:53 --> Controller Class Initialized
ERROR - 2021-07-05 17:55:53 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 17:55:53 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 17:55:53 --> Final output sent to browser
DEBUG - 2021-07-05 17:55:53 --> Total execution time: 0.1369
INFO - 2021-07-05 14:57:09 --> Config Class Initialized
INFO - 2021-07-05 14:57:09 --> Hooks Class Initialized
DEBUG - 2021-07-05 14:57:09 --> UTF-8 Support Enabled
INFO - 2021-07-05 14:57:09 --> Utf8 Class Initialized
INFO - 2021-07-05 14:57:09 --> URI Class Initialized
INFO - 2021-07-05 14:57:09 --> Router Class Initialized
INFO - 2021-07-05 14:57:09 --> Output Class Initialized
INFO - 2021-07-05 14:57:09 --> Security Class Initialized
DEBUG - 2021-07-05 14:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 14:57:09 --> Input Class Initialized
INFO - 2021-07-05 14:57:09 --> Language Class Initialized
INFO - 2021-07-05 14:57:09 --> Loader Class Initialized
INFO - 2021-07-05 14:57:09 --> Helper loaded: basic_helper
INFO - 2021-07-05 14:57:09 --> Helper loaded: url_helper
INFO - 2021-07-05 14:57:09 --> Helper loaded: file_helper
INFO - 2021-07-05 14:57:09 --> Helper loaded: form_helper
INFO - 2021-07-05 14:57:09 --> Helper loaded: cookie_helper
INFO - 2021-07-05 14:57:09 --> Helper loaded: security_helper
INFO - 2021-07-05 14:57:09 --> Helper loaded: directory_helper
INFO - 2021-07-05 14:57:09 --> Helper loaded: language_helper
INFO - 2021-07-05 14:57:09 --> Helper loaded: general_helper
INFO - 2021-07-05 14:57:09 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 14:57:09 --> Database Driver Class Initialized
DEBUG - 2021-07-05 14:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 14:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 14:57:09 --> Parser Class Initialized
INFO - 2021-07-05 14:57:09 --> Form Validation Class Initialized
INFO - 2021-07-05 14:57:09 --> Upload Class Initialized
INFO - 2021-07-05 14:57:09 --> Email Class Initialized
INFO - 2021-07-05 14:57:09 --> MY_Model class loaded
INFO - 2021-07-05 14:57:09 --> Model "Users_model" initialized
INFO - 2021-07-05 14:57:09 --> Model "Settings_model" initialized
INFO - 2021-07-05 14:57:09 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 14:57:09 --> Model "Permissions_model" initialized
INFO - 2021-07-05 14:57:09 --> Model "Roles_model" initialized
INFO - 2021-07-05 14:57:09 --> Model "Activity_model" initialized
INFO - 2021-07-05 14:57:09 --> Model "Templates_model" initialized
INFO - 2021-07-05 14:57:09 --> Database Driver Class Initialized
INFO - 2021-07-05 14:57:09 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 14:57:09 --> Controller Class Initialized
ERROR - 2021-07-05 17:57:09 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 17:57:09 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-05 17:57:09 --> Final output sent to browser
DEBUG - 2021-07-05 17:57:09 --> Total execution time: 0.2435
INFO - 2021-07-05 14:57:10 --> Config Class Initialized
INFO - 2021-07-05 14:57:10 --> Hooks Class Initialized
DEBUG - 2021-07-05 14:57:10 --> UTF-8 Support Enabled
INFO - 2021-07-05 14:57:10 --> Utf8 Class Initialized
INFO - 2021-07-05 14:57:10 --> URI Class Initialized
INFO - 2021-07-05 14:57:10 --> Router Class Initialized
INFO - 2021-07-05 14:57:10 --> Output Class Initialized
INFO - 2021-07-05 14:57:10 --> Security Class Initialized
DEBUG - 2021-07-05 14:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 14:57:10 --> Input Class Initialized
INFO - 2021-07-05 14:57:10 --> Language Class Initialized
INFO - 2021-07-05 14:57:10 --> Loader Class Initialized
INFO - 2021-07-05 14:57:10 --> Helper loaded: basic_helper
INFO - 2021-07-05 14:57:10 --> Helper loaded: url_helper
INFO - 2021-07-05 14:57:10 --> Helper loaded: file_helper
INFO - 2021-07-05 14:57:10 --> Helper loaded: form_helper
INFO - 2021-07-05 14:57:10 --> Helper loaded: cookie_helper
INFO - 2021-07-05 14:57:10 --> Helper loaded: security_helper
INFO - 2021-07-05 14:57:10 --> Helper loaded: directory_helper
INFO - 2021-07-05 14:57:10 --> Helper loaded: language_helper
INFO - 2021-07-05 14:57:10 --> Helper loaded: general_helper
INFO - 2021-07-05 14:57:10 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 14:57:10 --> Database Driver Class Initialized
DEBUG - 2021-07-05 14:57:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 14:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 14:57:10 --> Parser Class Initialized
INFO - 2021-07-05 14:57:10 --> Form Validation Class Initialized
INFO - 2021-07-05 14:57:10 --> Upload Class Initialized
INFO - 2021-07-05 14:57:10 --> Email Class Initialized
INFO - 2021-07-05 14:57:10 --> MY_Model class loaded
INFO - 2021-07-05 14:57:10 --> Model "Users_model" initialized
INFO - 2021-07-05 14:57:10 --> Model "Settings_model" initialized
INFO - 2021-07-05 14:57:10 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 14:57:10 --> Model "Permissions_model" initialized
INFO - 2021-07-05 14:57:10 --> Model "Roles_model" initialized
INFO - 2021-07-05 14:57:10 --> Model "Activity_model" initialized
INFO - 2021-07-05 14:57:10 --> Model "Templates_model" initialized
INFO - 2021-07-05 14:57:10 --> Database Driver Class Initialized
INFO - 2021-07-05 14:57:10 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 14:57:10 --> Controller Class Initialized
ERROR - 2021-07-05 17:57:10 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 17:57:11 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 17:57:11 --> Final output sent to browser
DEBUG - 2021-07-05 17:57:11 --> Total execution time: 0.0708
INFO - 2021-07-05 14:58:41 --> Config Class Initialized
INFO - 2021-07-05 14:58:41 --> Hooks Class Initialized
DEBUG - 2021-07-05 14:58:41 --> UTF-8 Support Enabled
INFO - 2021-07-05 14:58:41 --> Utf8 Class Initialized
INFO - 2021-07-05 14:58:41 --> URI Class Initialized
INFO - 2021-07-05 14:58:41 --> Router Class Initialized
INFO - 2021-07-05 14:58:41 --> Output Class Initialized
INFO - 2021-07-05 14:58:41 --> Security Class Initialized
DEBUG - 2021-07-05 14:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 14:58:41 --> Input Class Initialized
INFO - 2021-07-05 14:58:41 --> Language Class Initialized
INFO - 2021-07-05 14:58:41 --> Loader Class Initialized
INFO - 2021-07-05 14:58:41 --> Helper loaded: basic_helper
INFO - 2021-07-05 14:58:41 --> Helper loaded: url_helper
INFO - 2021-07-05 14:58:41 --> Helper loaded: file_helper
INFO - 2021-07-05 14:58:41 --> Helper loaded: form_helper
INFO - 2021-07-05 14:58:41 --> Helper loaded: cookie_helper
INFO - 2021-07-05 14:58:41 --> Helper loaded: security_helper
INFO - 2021-07-05 14:58:41 --> Helper loaded: directory_helper
INFO - 2021-07-05 14:58:41 --> Helper loaded: language_helper
INFO - 2021-07-05 14:58:41 --> Helper loaded: general_helper
INFO - 2021-07-05 14:58:41 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 14:58:41 --> Database Driver Class Initialized
DEBUG - 2021-07-05 14:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 14:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 14:58:41 --> Parser Class Initialized
INFO - 2021-07-05 14:58:41 --> Form Validation Class Initialized
INFO - 2021-07-05 14:58:41 --> Upload Class Initialized
INFO - 2021-07-05 14:58:41 --> Email Class Initialized
INFO - 2021-07-05 14:58:41 --> MY_Model class loaded
INFO - 2021-07-05 14:58:41 --> Model "Users_model" initialized
INFO - 2021-07-05 14:58:41 --> Model "Settings_model" initialized
INFO - 2021-07-05 14:58:41 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 14:58:41 --> Model "Permissions_model" initialized
INFO - 2021-07-05 14:58:41 --> Model "Roles_model" initialized
INFO - 2021-07-05 14:58:41 --> Model "Activity_model" initialized
INFO - 2021-07-05 14:58:41 --> Model "Templates_model" initialized
INFO - 2021-07-05 14:58:41 --> Database Driver Class Initialized
INFO - 2021-07-05 14:58:41 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 14:58:41 --> Controller Class Initialized
ERROR - 2021-07-05 17:58:41 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 17:58:41 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 17:58:41 --> Final output sent to browser
DEBUG - 2021-07-05 17:58:41 --> Total execution time: 0.1422
INFO - 2021-07-05 14:59:27 --> Config Class Initialized
INFO - 2021-07-05 14:59:27 --> Hooks Class Initialized
DEBUG - 2021-07-05 14:59:27 --> UTF-8 Support Enabled
INFO - 2021-07-05 14:59:27 --> Utf8 Class Initialized
INFO - 2021-07-05 14:59:27 --> URI Class Initialized
INFO - 2021-07-05 14:59:27 --> Router Class Initialized
INFO - 2021-07-05 14:59:27 --> Output Class Initialized
INFO - 2021-07-05 14:59:27 --> Security Class Initialized
DEBUG - 2021-07-05 14:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 14:59:27 --> Input Class Initialized
INFO - 2021-07-05 14:59:27 --> Language Class Initialized
INFO - 2021-07-05 14:59:27 --> Loader Class Initialized
INFO - 2021-07-05 14:59:27 --> Helper loaded: basic_helper
INFO - 2021-07-05 14:59:27 --> Helper loaded: url_helper
INFO - 2021-07-05 14:59:27 --> Helper loaded: file_helper
INFO - 2021-07-05 14:59:27 --> Helper loaded: form_helper
INFO - 2021-07-05 14:59:27 --> Helper loaded: cookie_helper
INFO - 2021-07-05 14:59:27 --> Helper loaded: security_helper
INFO - 2021-07-05 14:59:27 --> Helper loaded: directory_helper
INFO - 2021-07-05 14:59:27 --> Helper loaded: language_helper
INFO - 2021-07-05 14:59:27 --> Helper loaded: general_helper
INFO - 2021-07-05 14:59:27 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 14:59:27 --> Database Driver Class Initialized
DEBUG - 2021-07-05 14:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 14:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 14:59:27 --> Parser Class Initialized
INFO - 2021-07-05 14:59:27 --> Form Validation Class Initialized
INFO - 2021-07-05 14:59:27 --> Upload Class Initialized
INFO - 2021-07-05 14:59:27 --> Email Class Initialized
INFO - 2021-07-05 14:59:27 --> MY_Model class loaded
INFO - 2021-07-05 14:59:27 --> Model "Users_model" initialized
INFO - 2021-07-05 14:59:27 --> Model "Settings_model" initialized
INFO - 2021-07-05 14:59:27 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 14:59:27 --> Model "Permissions_model" initialized
INFO - 2021-07-05 14:59:27 --> Model "Roles_model" initialized
INFO - 2021-07-05 14:59:27 --> Model "Activity_model" initialized
INFO - 2021-07-05 14:59:27 --> Model "Templates_model" initialized
INFO - 2021-07-05 14:59:27 --> Database Driver Class Initialized
INFO - 2021-07-05 14:59:28 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 14:59:28 --> Controller Class Initialized
ERROR - 2021-07-05 17:59:28 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 17:59:28 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-05 17:59:28 --> Final output sent to browser
DEBUG - 2021-07-05 17:59:28 --> Total execution time: 0.2525
INFO - 2021-07-05 14:59:29 --> Config Class Initialized
INFO - 2021-07-05 14:59:29 --> Hooks Class Initialized
DEBUG - 2021-07-05 14:59:29 --> UTF-8 Support Enabled
INFO - 2021-07-05 14:59:29 --> Utf8 Class Initialized
INFO - 2021-07-05 14:59:29 --> URI Class Initialized
INFO - 2021-07-05 14:59:29 --> Router Class Initialized
INFO - 2021-07-05 14:59:29 --> Output Class Initialized
INFO - 2021-07-05 14:59:29 --> Security Class Initialized
DEBUG - 2021-07-05 14:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 14:59:29 --> Input Class Initialized
INFO - 2021-07-05 14:59:29 --> Language Class Initialized
INFO - 2021-07-05 14:59:29 --> Loader Class Initialized
INFO - 2021-07-05 14:59:29 --> Helper loaded: basic_helper
INFO - 2021-07-05 14:59:29 --> Helper loaded: url_helper
INFO - 2021-07-05 14:59:29 --> Helper loaded: file_helper
INFO - 2021-07-05 14:59:29 --> Helper loaded: form_helper
INFO - 2021-07-05 14:59:29 --> Helper loaded: cookie_helper
INFO - 2021-07-05 14:59:29 --> Helper loaded: security_helper
INFO - 2021-07-05 14:59:29 --> Helper loaded: directory_helper
INFO - 2021-07-05 14:59:29 --> Helper loaded: language_helper
INFO - 2021-07-05 14:59:29 --> Helper loaded: general_helper
INFO - 2021-07-05 14:59:29 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 14:59:29 --> Database Driver Class Initialized
DEBUG - 2021-07-05 14:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 14:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 14:59:29 --> Parser Class Initialized
INFO - 2021-07-05 14:59:29 --> Form Validation Class Initialized
INFO - 2021-07-05 14:59:29 --> Upload Class Initialized
INFO - 2021-07-05 14:59:29 --> Email Class Initialized
INFO - 2021-07-05 14:59:29 --> MY_Model class loaded
INFO - 2021-07-05 14:59:29 --> Model "Users_model" initialized
INFO - 2021-07-05 14:59:29 --> Model "Settings_model" initialized
INFO - 2021-07-05 14:59:29 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 14:59:29 --> Model "Permissions_model" initialized
INFO - 2021-07-05 14:59:29 --> Model "Roles_model" initialized
INFO - 2021-07-05 14:59:29 --> Model "Activity_model" initialized
INFO - 2021-07-05 14:59:29 --> Model "Templates_model" initialized
INFO - 2021-07-05 14:59:29 --> Database Driver Class Initialized
INFO - 2021-07-05 14:59:29 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 14:59:29 --> Controller Class Initialized
ERROR - 2021-07-05 17:59:29 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 17:59:29 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 17:59:29 --> Final output sent to browser
DEBUG - 2021-07-05 17:59:29 --> Total execution time: 0.0668
INFO - 2021-07-05 14:59:32 --> Config Class Initialized
INFO - 2021-07-05 14:59:32 --> Hooks Class Initialized
DEBUG - 2021-07-05 14:59:32 --> UTF-8 Support Enabled
INFO - 2021-07-05 14:59:32 --> Utf8 Class Initialized
INFO - 2021-07-05 14:59:32 --> URI Class Initialized
INFO - 2021-07-05 14:59:32 --> Router Class Initialized
INFO - 2021-07-05 14:59:32 --> Output Class Initialized
INFO - 2021-07-05 14:59:32 --> Security Class Initialized
DEBUG - 2021-07-05 14:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 14:59:32 --> Input Class Initialized
INFO - 2021-07-05 14:59:32 --> Language Class Initialized
INFO - 2021-07-05 14:59:32 --> Loader Class Initialized
INFO - 2021-07-05 14:59:32 --> Helper loaded: basic_helper
INFO - 2021-07-05 14:59:32 --> Helper loaded: url_helper
INFO - 2021-07-05 14:59:32 --> Helper loaded: file_helper
INFO - 2021-07-05 14:59:32 --> Helper loaded: form_helper
INFO - 2021-07-05 14:59:32 --> Helper loaded: cookie_helper
INFO - 2021-07-05 14:59:32 --> Helper loaded: security_helper
INFO - 2021-07-05 14:59:32 --> Helper loaded: directory_helper
INFO - 2021-07-05 14:59:32 --> Helper loaded: language_helper
INFO - 2021-07-05 14:59:32 --> Helper loaded: general_helper
INFO - 2021-07-05 14:59:32 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 14:59:32 --> Database Driver Class Initialized
DEBUG - 2021-07-05 14:59:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 14:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 14:59:32 --> Parser Class Initialized
INFO - 2021-07-05 14:59:32 --> Form Validation Class Initialized
INFO - 2021-07-05 14:59:32 --> Upload Class Initialized
INFO - 2021-07-05 14:59:32 --> Email Class Initialized
INFO - 2021-07-05 14:59:32 --> MY_Model class loaded
INFO - 2021-07-05 14:59:32 --> Model "Users_model" initialized
INFO - 2021-07-05 14:59:32 --> Model "Settings_model" initialized
INFO - 2021-07-05 14:59:32 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 14:59:32 --> Model "Permissions_model" initialized
INFO - 2021-07-05 14:59:32 --> Model "Roles_model" initialized
INFO - 2021-07-05 14:59:32 --> Model "Activity_model" initialized
INFO - 2021-07-05 14:59:32 --> Model "Templates_model" initialized
INFO - 2021-07-05 14:59:32 --> Database Driver Class Initialized
INFO - 2021-07-05 14:59:32 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 14:59:32 --> Controller Class Initialized
ERROR - 2021-07-05 17:59:32 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 17:59:32 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-05 17:59:32 --> Final output sent to browser
DEBUG - 2021-07-05 17:59:32 --> Total execution time: 0.1648
INFO - 2021-07-05 14:59:33 --> Config Class Initialized
INFO - 2021-07-05 14:59:33 --> Hooks Class Initialized
DEBUG - 2021-07-05 14:59:33 --> UTF-8 Support Enabled
INFO - 2021-07-05 14:59:33 --> Utf8 Class Initialized
INFO - 2021-07-05 14:59:33 --> URI Class Initialized
INFO - 2021-07-05 14:59:33 --> Router Class Initialized
INFO - 2021-07-05 14:59:33 --> Output Class Initialized
INFO - 2021-07-05 14:59:33 --> Security Class Initialized
DEBUG - 2021-07-05 14:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 14:59:33 --> Input Class Initialized
INFO - 2021-07-05 14:59:33 --> Language Class Initialized
INFO - 2021-07-05 14:59:33 --> Loader Class Initialized
INFO - 2021-07-05 14:59:33 --> Helper loaded: basic_helper
INFO - 2021-07-05 14:59:33 --> Helper loaded: url_helper
INFO - 2021-07-05 14:59:33 --> Helper loaded: file_helper
INFO - 2021-07-05 14:59:33 --> Helper loaded: form_helper
INFO - 2021-07-05 14:59:33 --> Helper loaded: cookie_helper
INFO - 2021-07-05 14:59:33 --> Helper loaded: security_helper
INFO - 2021-07-05 14:59:33 --> Helper loaded: directory_helper
INFO - 2021-07-05 14:59:33 --> Helper loaded: language_helper
INFO - 2021-07-05 14:59:33 --> Helper loaded: general_helper
INFO - 2021-07-05 14:59:33 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 14:59:33 --> Database Driver Class Initialized
DEBUG - 2021-07-05 14:59:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 14:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 14:59:33 --> Parser Class Initialized
INFO - 2021-07-05 14:59:33 --> Form Validation Class Initialized
INFO - 2021-07-05 14:59:33 --> Upload Class Initialized
INFO - 2021-07-05 14:59:33 --> Email Class Initialized
INFO - 2021-07-05 14:59:33 --> MY_Model class loaded
INFO - 2021-07-05 14:59:33 --> Model "Users_model" initialized
INFO - 2021-07-05 14:59:33 --> Model "Settings_model" initialized
INFO - 2021-07-05 14:59:33 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 14:59:33 --> Model "Permissions_model" initialized
INFO - 2021-07-05 14:59:33 --> Model "Roles_model" initialized
INFO - 2021-07-05 14:59:33 --> Model "Activity_model" initialized
INFO - 2021-07-05 14:59:33 --> Model "Templates_model" initialized
INFO - 2021-07-05 14:59:33 --> Database Driver Class Initialized
INFO - 2021-07-05 14:59:33 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 14:59:33 --> Controller Class Initialized
ERROR - 2021-07-05 17:59:33 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 17:59:33 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 17:59:33 --> Final output sent to browser
DEBUG - 2021-07-05 17:59:33 --> Total execution time: 0.1278
INFO - 2021-07-05 14:59:35 --> Config Class Initialized
INFO - 2021-07-05 14:59:35 --> Hooks Class Initialized
DEBUG - 2021-07-05 14:59:35 --> UTF-8 Support Enabled
INFO - 2021-07-05 14:59:35 --> Utf8 Class Initialized
INFO - 2021-07-05 14:59:35 --> URI Class Initialized
INFO - 2021-07-05 14:59:35 --> Router Class Initialized
INFO - 2021-07-05 14:59:35 --> Output Class Initialized
INFO - 2021-07-05 14:59:35 --> Security Class Initialized
DEBUG - 2021-07-05 14:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 14:59:35 --> Input Class Initialized
INFO - 2021-07-05 14:59:35 --> Language Class Initialized
INFO - 2021-07-05 14:59:35 --> Loader Class Initialized
INFO - 2021-07-05 14:59:35 --> Helper loaded: basic_helper
INFO - 2021-07-05 14:59:35 --> Helper loaded: url_helper
INFO - 2021-07-05 14:59:35 --> Helper loaded: file_helper
INFO - 2021-07-05 14:59:35 --> Helper loaded: form_helper
INFO - 2021-07-05 14:59:35 --> Helper loaded: cookie_helper
INFO - 2021-07-05 14:59:35 --> Helper loaded: security_helper
INFO - 2021-07-05 14:59:35 --> Helper loaded: directory_helper
INFO - 2021-07-05 14:59:35 --> Helper loaded: language_helper
INFO - 2021-07-05 14:59:35 --> Helper loaded: general_helper
INFO - 2021-07-05 14:59:35 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 14:59:35 --> Database Driver Class Initialized
DEBUG - 2021-07-05 14:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 14:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 14:59:35 --> Parser Class Initialized
INFO - 2021-07-05 14:59:35 --> Form Validation Class Initialized
INFO - 2021-07-05 14:59:35 --> Upload Class Initialized
INFO - 2021-07-05 14:59:35 --> Email Class Initialized
INFO - 2021-07-05 14:59:35 --> MY_Model class loaded
INFO - 2021-07-05 14:59:35 --> Model "Users_model" initialized
INFO - 2021-07-05 14:59:35 --> Model "Settings_model" initialized
INFO - 2021-07-05 14:59:35 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 14:59:35 --> Model "Permissions_model" initialized
INFO - 2021-07-05 14:59:35 --> Model "Roles_model" initialized
INFO - 2021-07-05 14:59:35 --> Model "Activity_model" initialized
INFO - 2021-07-05 14:59:35 --> Model "Templates_model" initialized
INFO - 2021-07-05 14:59:35 --> Database Driver Class Initialized
INFO - 2021-07-05 14:59:35 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 14:59:35 --> Controller Class Initialized
ERROR - 2021-07-05 17:59:35 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 17:59:35 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-05 17:59:35 --> Final output sent to browser
DEBUG - 2021-07-05 17:59:35 --> Total execution time: 0.1811
INFO - 2021-07-05 14:59:37 --> Config Class Initialized
INFO - 2021-07-05 14:59:37 --> Hooks Class Initialized
DEBUG - 2021-07-05 14:59:37 --> UTF-8 Support Enabled
INFO - 2021-07-05 14:59:37 --> Utf8 Class Initialized
INFO - 2021-07-05 14:59:37 --> URI Class Initialized
INFO - 2021-07-05 14:59:37 --> Router Class Initialized
INFO - 2021-07-05 14:59:37 --> Output Class Initialized
INFO - 2021-07-05 14:59:37 --> Security Class Initialized
DEBUG - 2021-07-05 14:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 14:59:37 --> Input Class Initialized
INFO - 2021-07-05 14:59:37 --> Language Class Initialized
INFO - 2021-07-05 14:59:37 --> Loader Class Initialized
INFO - 2021-07-05 14:59:37 --> Helper loaded: basic_helper
INFO - 2021-07-05 14:59:37 --> Helper loaded: url_helper
INFO - 2021-07-05 14:59:37 --> Helper loaded: file_helper
INFO - 2021-07-05 14:59:37 --> Helper loaded: form_helper
INFO - 2021-07-05 14:59:37 --> Helper loaded: cookie_helper
INFO - 2021-07-05 14:59:37 --> Helper loaded: security_helper
INFO - 2021-07-05 14:59:37 --> Helper loaded: directory_helper
INFO - 2021-07-05 14:59:37 --> Helper loaded: language_helper
INFO - 2021-07-05 14:59:37 --> Helper loaded: general_helper
INFO - 2021-07-05 14:59:37 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 14:59:37 --> Database Driver Class Initialized
DEBUG - 2021-07-05 14:59:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 14:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 14:59:37 --> Parser Class Initialized
INFO - 2021-07-05 14:59:37 --> Form Validation Class Initialized
INFO - 2021-07-05 14:59:37 --> Upload Class Initialized
INFO - 2021-07-05 14:59:37 --> Email Class Initialized
INFO - 2021-07-05 14:59:37 --> MY_Model class loaded
INFO - 2021-07-05 14:59:37 --> Model "Users_model" initialized
INFO - 2021-07-05 14:59:37 --> Model "Settings_model" initialized
INFO - 2021-07-05 14:59:37 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 14:59:37 --> Model "Permissions_model" initialized
INFO - 2021-07-05 14:59:37 --> Model "Roles_model" initialized
INFO - 2021-07-05 14:59:37 --> Model "Activity_model" initialized
INFO - 2021-07-05 14:59:37 --> Model "Templates_model" initialized
INFO - 2021-07-05 14:59:37 --> Database Driver Class Initialized
INFO - 2021-07-05 14:59:37 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 14:59:37 --> Controller Class Initialized
ERROR - 2021-07-05 17:59:37 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 17:59:37 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 17:59:37 --> Final output sent to browser
DEBUG - 2021-07-05 17:59:37 --> Total execution time: 0.0668
INFO - 2021-07-05 15:02:10 --> Config Class Initialized
INFO - 2021-07-05 15:02:10 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:02:10 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:02:10 --> Utf8 Class Initialized
INFO - 2021-07-05 15:02:10 --> URI Class Initialized
INFO - 2021-07-05 15:02:10 --> Router Class Initialized
INFO - 2021-07-05 15:02:10 --> Output Class Initialized
INFO - 2021-07-05 15:02:10 --> Security Class Initialized
DEBUG - 2021-07-05 15:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:02:10 --> Input Class Initialized
INFO - 2021-07-05 15:02:10 --> Language Class Initialized
INFO - 2021-07-05 15:02:10 --> Loader Class Initialized
INFO - 2021-07-05 15:02:10 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:02:10 --> Helper loaded: url_helper
INFO - 2021-07-05 15:02:10 --> Helper loaded: file_helper
INFO - 2021-07-05 15:02:10 --> Helper loaded: form_helper
INFO - 2021-07-05 15:02:10 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:02:10 --> Helper loaded: security_helper
INFO - 2021-07-05 15:02:10 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:02:10 --> Helper loaded: language_helper
INFO - 2021-07-05 15:02:10 --> Helper loaded: general_helper
INFO - 2021-07-05 15:02:10 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:02:10 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:02:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:02:10 --> Parser Class Initialized
INFO - 2021-07-05 15:02:10 --> Form Validation Class Initialized
INFO - 2021-07-05 15:02:10 --> Upload Class Initialized
INFO - 2021-07-05 15:02:10 --> Email Class Initialized
INFO - 2021-07-05 15:02:10 --> MY_Model class loaded
INFO - 2021-07-05 15:02:10 --> Model "Users_model" initialized
INFO - 2021-07-05 15:02:10 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:02:10 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:02:10 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:02:10 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:02:10 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:02:10 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:02:10 --> Database Driver Class Initialized
INFO - 2021-07-05 15:02:10 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:02:10 --> Controller Class Initialized
ERROR - 2021-07-05 18:02:10 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 18:02:11 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 18:02:11 --> Final output sent to browser
DEBUG - 2021-07-05 18:02:11 --> Total execution time: 0.1344
INFO - 2021-07-05 15:02:29 --> Config Class Initialized
INFO - 2021-07-05 15:02:29 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:02:29 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:02:29 --> Utf8 Class Initialized
INFO - 2021-07-05 15:02:29 --> URI Class Initialized
INFO - 2021-07-05 15:02:29 --> Router Class Initialized
INFO - 2021-07-05 15:02:29 --> Output Class Initialized
INFO - 2021-07-05 15:02:29 --> Security Class Initialized
DEBUG - 2021-07-05 15:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:02:29 --> Input Class Initialized
INFO - 2021-07-05 15:02:29 --> Language Class Initialized
INFO - 2021-07-05 15:02:29 --> Loader Class Initialized
INFO - 2021-07-05 15:02:29 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:02:29 --> Helper loaded: url_helper
INFO - 2021-07-05 15:02:29 --> Helper loaded: file_helper
INFO - 2021-07-05 15:02:29 --> Helper loaded: form_helper
INFO - 2021-07-05 15:02:29 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:02:29 --> Helper loaded: security_helper
INFO - 2021-07-05 15:02:29 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:02:29 --> Helper loaded: language_helper
INFO - 2021-07-05 15:02:29 --> Helper loaded: general_helper
INFO - 2021-07-05 15:02:29 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:02:29 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:02:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:02:29 --> Parser Class Initialized
INFO - 2021-07-05 15:02:29 --> Form Validation Class Initialized
INFO - 2021-07-05 15:02:29 --> Upload Class Initialized
INFO - 2021-07-05 15:02:29 --> Email Class Initialized
INFO - 2021-07-05 15:02:29 --> MY_Model class loaded
INFO - 2021-07-05 15:02:29 --> Model "Users_model" initialized
INFO - 2021-07-05 15:02:29 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:02:29 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:02:29 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:02:29 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:02:29 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:02:29 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:02:29 --> Database Driver Class Initialized
INFO - 2021-07-05 15:02:29 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:02:29 --> Controller Class Initialized
ERROR - 2021-07-05 18:02:29 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 18:02:29 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 18:02:29 --> Final output sent to browser
DEBUG - 2021-07-05 18:02:29 --> Total execution time: 0.1259
INFO - 2021-07-05 15:03:06 --> Config Class Initialized
INFO - 2021-07-05 15:03:06 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:03:06 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:03:06 --> Utf8 Class Initialized
INFO - 2021-07-05 15:03:06 --> URI Class Initialized
INFO - 2021-07-05 15:03:06 --> Router Class Initialized
INFO - 2021-07-05 15:03:06 --> Output Class Initialized
INFO - 2021-07-05 15:03:06 --> Security Class Initialized
DEBUG - 2021-07-05 15:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:03:06 --> Input Class Initialized
INFO - 2021-07-05 15:03:06 --> Language Class Initialized
INFO - 2021-07-05 15:03:06 --> Loader Class Initialized
INFO - 2021-07-05 15:03:06 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:03:06 --> Helper loaded: url_helper
INFO - 2021-07-05 15:03:06 --> Helper loaded: file_helper
INFO - 2021-07-05 15:03:06 --> Helper loaded: form_helper
INFO - 2021-07-05 15:03:06 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:03:06 --> Helper loaded: security_helper
INFO - 2021-07-05 15:03:06 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:03:06 --> Helper loaded: language_helper
INFO - 2021-07-05 15:03:06 --> Helper loaded: general_helper
INFO - 2021-07-05 15:03:06 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:03:06 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:03:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:03:06 --> Parser Class Initialized
INFO - 2021-07-05 15:03:06 --> Form Validation Class Initialized
INFO - 2021-07-05 15:03:06 --> Upload Class Initialized
INFO - 2021-07-05 15:03:06 --> Email Class Initialized
INFO - 2021-07-05 15:03:06 --> MY_Model class loaded
INFO - 2021-07-05 15:03:06 --> Model "Users_model" initialized
INFO - 2021-07-05 15:03:06 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:03:06 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:03:06 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:03:06 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:03:06 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:03:06 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:03:06 --> Database Driver Class Initialized
INFO - 2021-07-05 15:03:06 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:03:06 --> Controller Class Initialized
ERROR - 2021-07-05 18:03:06 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 18:03:06 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 18:03:06 --> Final output sent to browser
DEBUG - 2021-07-05 18:03:06 --> Total execution time: 0.1364
INFO - 2021-07-05 15:04:11 --> Config Class Initialized
INFO - 2021-07-05 15:04:11 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:04:11 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:04:11 --> Utf8 Class Initialized
INFO - 2021-07-05 15:04:11 --> URI Class Initialized
INFO - 2021-07-05 15:04:11 --> Router Class Initialized
INFO - 2021-07-05 15:04:11 --> Output Class Initialized
INFO - 2021-07-05 15:04:11 --> Security Class Initialized
DEBUG - 2021-07-05 15:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:04:11 --> Input Class Initialized
INFO - 2021-07-05 15:04:11 --> Language Class Initialized
INFO - 2021-07-05 15:04:11 --> Loader Class Initialized
INFO - 2021-07-05 15:04:11 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:04:11 --> Helper loaded: url_helper
INFO - 2021-07-05 15:04:11 --> Helper loaded: file_helper
INFO - 2021-07-05 15:04:11 --> Helper loaded: form_helper
INFO - 2021-07-05 15:04:11 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:04:11 --> Helper loaded: security_helper
INFO - 2021-07-05 15:04:11 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:04:11 --> Helper loaded: language_helper
INFO - 2021-07-05 15:04:11 --> Helper loaded: general_helper
INFO - 2021-07-05 15:04:11 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:04:11 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:04:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:04:11 --> Parser Class Initialized
INFO - 2021-07-05 15:04:11 --> Form Validation Class Initialized
INFO - 2021-07-05 15:04:11 --> Upload Class Initialized
INFO - 2021-07-05 15:04:11 --> Email Class Initialized
INFO - 2021-07-05 15:04:11 --> MY_Model class loaded
INFO - 2021-07-05 15:04:11 --> Model "Users_model" initialized
INFO - 2021-07-05 15:04:11 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:04:11 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:04:11 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:04:11 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:04:11 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:04:11 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:04:11 --> Database Driver Class Initialized
INFO - 2021-07-05 15:04:11 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:04:11 --> Controller Class Initialized
ERROR - 2021-07-05 18:04:11 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 18:04:11 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 18:04:11 --> Final output sent to browser
DEBUG - 2021-07-05 18:04:11 --> Total execution time: 0.1217
INFO - 2021-07-05 15:04:56 --> Config Class Initialized
INFO - 2021-07-05 15:04:56 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:04:56 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:04:56 --> Utf8 Class Initialized
INFO - 2021-07-05 15:04:56 --> URI Class Initialized
INFO - 2021-07-05 15:04:56 --> Router Class Initialized
INFO - 2021-07-05 15:04:56 --> Output Class Initialized
INFO - 2021-07-05 15:04:56 --> Security Class Initialized
DEBUG - 2021-07-05 15:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:04:56 --> Input Class Initialized
INFO - 2021-07-05 15:04:56 --> Language Class Initialized
INFO - 2021-07-05 15:04:56 --> Loader Class Initialized
INFO - 2021-07-05 15:04:56 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:04:56 --> Helper loaded: url_helper
INFO - 2021-07-05 15:04:56 --> Helper loaded: file_helper
INFO - 2021-07-05 15:04:56 --> Helper loaded: form_helper
INFO - 2021-07-05 15:04:56 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:04:56 --> Helper loaded: security_helper
INFO - 2021-07-05 15:04:56 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:04:56 --> Helper loaded: language_helper
INFO - 2021-07-05 15:04:56 --> Helper loaded: general_helper
INFO - 2021-07-05 15:04:56 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:04:56 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:04:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:04:56 --> Parser Class Initialized
INFO - 2021-07-05 15:04:56 --> Form Validation Class Initialized
INFO - 2021-07-05 15:04:56 --> Upload Class Initialized
INFO - 2021-07-05 15:04:56 --> Email Class Initialized
INFO - 2021-07-05 15:04:56 --> MY_Model class loaded
INFO - 2021-07-05 15:04:56 --> Model "Users_model" initialized
INFO - 2021-07-05 15:04:56 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:04:56 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:04:56 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:04:56 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:04:56 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:04:56 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:04:56 --> Database Driver Class Initialized
INFO - 2021-07-05 15:04:56 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:04:56 --> Controller Class Initialized
ERROR - 2021-07-05 18:04:56 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 18:04:56 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 18:04:56 --> Final output sent to browser
DEBUG - 2021-07-05 18:04:56 --> Total execution time: 0.1334
INFO - 2021-07-05 15:05:20 --> Config Class Initialized
INFO - 2021-07-05 15:05:20 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:05:20 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:05:20 --> Utf8 Class Initialized
INFO - 2021-07-05 15:05:20 --> URI Class Initialized
INFO - 2021-07-05 15:05:20 --> Router Class Initialized
INFO - 2021-07-05 15:05:20 --> Output Class Initialized
INFO - 2021-07-05 15:05:20 --> Security Class Initialized
DEBUG - 2021-07-05 15:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:05:20 --> Input Class Initialized
INFO - 2021-07-05 15:05:20 --> Language Class Initialized
INFO - 2021-07-05 15:05:20 --> Loader Class Initialized
INFO - 2021-07-05 15:05:20 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:05:20 --> Helper loaded: url_helper
INFO - 2021-07-05 15:05:20 --> Helper loaded: file_helper
INFO - 2021-07-05 15:05:20 --> Helper loaded: form_helper
INFO - 2021-07-05 15:05:20 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:05:20 --> Helper loaded: security_helper
INFO - 2021-07-05 15:05:20 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:05:20 --> Helper loaded: language_helper
INFO - 2021-07-05 15:05:20 --> Helper loaded: general_helper
INFO - 2021-07-05 15:05:20 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:05:20 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:05:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:05:20 --> Parser Class Initialized
INFO - 2021-07-05 15:05:20 --> Form Validation Class Initialized
INFO - 2021-07-05 15:05:20 --> Upload Class Initialized
INFO - 2021-07-05 15:05:20 --> Email Class Initialized
INFO - 2021-07-05 15:05:20 --> MY_Model class loaded
INFO - 2021-07-05 15:05:20 --> Model "Users_model" initialized
INFO - 2021-07-05 15:05:20 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:05:20 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:05:20 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:05:20 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:05:20 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:05:20 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:05:20 --> Database Driver Class Initialized
INFO - 2021-07-05 15:05:20 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:05:20 --> Controller Class Initialized
ERROR - 2021-07-05 18:05:20 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 18:05:20 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 18:05:20 --> Final output sent to browser
DEBUG - 2021-07-05 18:05:20 --> Total execution time: 0.1314
INFO - 2021-07-05 15:05:43 --> Config Class Initialized
INFO - 2021-07-05 15:05:43 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:05:43 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:05:43 --> Utf8 Class Initialized
INFO - 2021-07-05 15:05:43 --> URI Class Initialized
INFO - 2021-07-05 15:05:43 --> Router Class Initialized
INFO - 2021-07-05 15:05:43 --> Output Class Initialized
INFO - 2021-07-05 15:05:43 --> Security Class Initialized
DEBUG - 2021-07-05 15:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:05:43 --> Input Class Initialized
INFO - 2021-07-05 15:05:43 --> Language Class Initialized
INFO - 2021-07-05 15:05:43 --> Loader Class Initialized
INFO - 2021-07-05 15:05:43 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:05:43 --> Helper loaded: url_helper
INFO - 2021-07-05 15:05:43 --> Helper loaded: file_helper
INFO - 2021-07-05 15:05:43 --> Helper loaded: form_helper
INFO - 2021-07-05 15:05:43 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:05:43 --> Helper loaded: security_helper
INFO - 2021-07-05 15:05:43 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:05:43 --> Helper loaded: language_helper
INFO - 2021-07-05 15:05:43 --> Helper loaded: general_helper
INFO - 2021-07-05 15:05:43 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:05:43 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:05:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:05:43 --> Parser Class Initialized
INFO - 2021-07-05 15:05:43 --> Form Validation Class Initialized
INFO - 2021-07-05 15:05:43 --> Upload Class Initialized
INFO - 2021-07-05 15:05:43 --> Email Class Initialized
INFO - 2021-07-05 15:05:43 --> MY_Model class loaded
INFO - 2021-07-05 15:05:43 --> Model "Users_model" initialized
INFO - 2021-07-05 15:05:43 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:05:43 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:05:43 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:05:43 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:05:43 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:05:43 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:05:43 --> Database Driver Class Initialized
INFO - 2021-07-05 15:05:44 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:05:44 --> Controller Class Initialized
ERROR - 2021-07-05 18:05:44 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 18:05:44 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 18:05:44 --> Final output sent to browser
DEBUG - 2021-07-05 18:05:44 --> Total execution time: 0.1407
INFO - 2021-07-05 15:07:51 --> Config Class Initialized
INFO - 2021-07-05 15:07:51 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:07:51 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:07:51 --> Utf8 Class Initialized
INFO - 2021-07-05 15:07:51 --> URI Class Initialized
INFO - 2021-07-05 15:07:51 --> Router Class Initialized
INFO - 2021-07-05 15:07:51 --> Output Class Initialized
INFO - 2021-07-05 15:07:51 --> Security Class Initialized
DEBUG - 2021-07-05 15:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:07:51 --> Input Class Initialized
INFO - 2021-07-05 15:07:51 --> Language Class Initialized
INFO - 2021-07-05 15:07:51 --> Loader Class Initialized
INFO - 2021-07-05 15:07:51 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:07:51 --> Helper loaded: url_helper
INFO - 2021-07-05 15:07:51 --> Helper loaded: file_helper
INFO - 2021-07-05 15:07:51 --> Helper loaded: form_helper
INFO - 2021-07-05 15:07:51 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:07:51 --> Helper loaded: security_helper
INFO - 2021-07-05 15:07:51 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:07:51 --> Helper loaded: language_helper
INFO - 2021-07-05 15:07:51 --> Helper loaded: general_helper
INFO - 2021-07-05 15:07:51 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:07:51 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:07:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:07:51 --> Parser Class Initialized
INFO - 2021-07-05 15:07:51 --> Form Validation Class Initialized
INFO - 2021-07-05 15:07:51 --> Upload Class Initialized
INFO - 2021-07-05 15:07:51 --> Email Class Initialized
INFO - 2021-07-05 15:07:51 --> MY_Model class loaded
INFO - 2021-07-05 15:07:51 --> Model "Users_model" initialized
INFO - 2021-07-05 15:07:51 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:07:51 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:07:51 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:07:51 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:07:51 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:07:51 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:07:51 --> Database Driver Class Initialized
INFO - 2021-07-05 15:07:51 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:07:51 --> Controller Class Initialized
ERROR - 2021-07-05 18:07:51 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 18:07:51 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 18:07:51 --> Final output sent to browser
DEBUG - 2021-07-05 18:07:51 --> Total execution time: 0.1405
INFO - 2021-07-05 15:08:03 --> Config Class Initialized
INFO - 2021-07-05 15:08:03 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:08:03 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:08:03 --> Utf8 Class Initialized
INFO - 2021-07-05 15:08:03 --> URI Class Initialized
INFO - 2021-07-05 15:08:03 --> Router Class Initialized
INFO - 2021-07-05 15:08:03 --> Output Class Initialized
INFO - 2021-07-05 15:08:03 --> Security Class Initialized
DEBUG - 2021-07-05 15:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:08:03 --> Input Class Initialized
INFO - 2021-07-05 15:08:03 --> Language Class Initialized
INFO - 2021-07-05 15:08:03 --> Loader Class Initialized
INFO - 2021-07-05 15:08:03 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:08:03 --> Helper loaded: url_helper
INFO - 2021-07-05 15:08:03 --> Helper loaded: file_helper
INFO - 2021-07-05 15:08:03 --> Helper loaded: form_helper
INFO - 2021-07-05 15:08:03 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:08:03 --> Helper loaded: security_helper
INFO - 2021-07-05 15:08:03 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:08:03 --> Helper loaded: language_helper
INFO - 2021-07-05 15:08:03 --> Helper loaded: general_helper
INFO - 2021-07-05 15:08:03 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:08:03 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:08:03 --> Parser Class Initialized
INFO - 2021-07-05 15:08:03 --> Form Validation Class Initialized
INFO - 2021-07-05 15:08:03 --> Upload Class Initialized
INFO - 2021-07-05 15:08:03 --> Email Class Initialized
INFO - 2021-07-05 15:08:03 --> MY_Model class loaded
INFO - 2021-07-05 15:08:03 --> Model "Users_model" initialized
INFO - 2021-07-05 15:08:03 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:08:03 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:08:03 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:08:03 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:08:03 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:08:03 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:08:03 --> Database Driver Class Initialized
INFO - 2021-07-05 15:08:03 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:08:03 --> Controller Class Initialized
ERROR - 2021-07-05 18:08:03 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 18:08:03 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 18:08:03 --> Final output sent to browser
DEBUG - 2021-07-05 18:08:03 --> Total execution time: 0.1230
INFO - 2021-07-05 15:08:52 --> Config Class Initialized
INFO - 2021-07-05 15:08:52 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:08:52 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:08:52 --> Utf8 Class Initialized
INFO - 2021-07-05 15:08:52 --> URI Class Initialized
INFO - 2021-07-05 15:08:52 --> Router Class Initialized
INFO - 2021-07-05 15:08:52 --> Output Class Initialized
INFO - 2021-07-05 15:08:52 --> Security Class Initialized
DEBUG - 2021-07-05 15:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:08:52 --> Input Class Initialized
INFO - 2021-07-05 15:08:52 --> Language Class Initialized
INFO - 2021-07-05 15:08:52 --> Loader Class Initialized
INFO - 2021-07-05 15:08:52 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:08:52 --> Helper loaded: url_helper
INFO - 2021-07-05 15:08:52 --> Helper loaded: file_helper
INFO - 2021-07-05 15:08:52 --> Helper loaded: form_helper
INFO - 2021-07-05 15:08:52 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:08:52 --> Helper loaded: security_helper
INFO - 2021-07-05 15:08:52 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:08:52 --> Helper loaded: language_helper
INFO - 2021-07-05 15:08:52 --> Helper loaded: general_helper
INFO - 2021-07-05 15:08:52 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:08:52 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:08:52 --> Parser Class Initialized
INFO - 2021-07-05 15:08:52 --> Form Validation Class Initialized
INFO - 2021-07-05 15:08:52 --> Upload Class Initialized
INFO - 2021-07-05 15:08:52 --> Email Class Initialized
INFO - 2021-07-05 15:08:52 --> MY_Model class loaded
INFO - 2021-07-05 15:08:52 --> Model "Users_model" initialized
INFO - 2021-07-05 15:08:52 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:08:52 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:08:52 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:08:52 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:08:52 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:08:52 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:08:52 --> Database Driver Class Initialized
INFO - 2021-07-05 15:08:52 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:08:52 --> Controller Class Initialized
ERROR - 2021-07-05 18:08:52 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 18:08:52 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-05 18:08:52 --> Final output sent to browser
DEBUG - 2021-07-05 18:08:52 --> Total execution time: 0.2591
INFO - 2021-07-05 15:08:58 --> Config Class Initialized
INFO - 2021-07-05 15:08:58 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:08:58 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:08:58 --> Utf8 Class Initialized
INFO - 2021-07-05 15:08:58 --> URI Class Initialized
INFO - 2021-07-05 15:08:58 --> Router Class Initialized
INFO - 2021-07-05 15:08:58 --> Output Class Initialized
INFO - 2021-07-05 15:08:58 --> Security Class Initialized
DEBUG - 2021-07-05 15:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:08:58 --> Input Class Initialized
INFO - 2021-07-05 15:08:58 --> Language Class Initialized
INFO - 2021-07-05 15:08:58 --> Loader Class Initialized
INFO - 2021-07-05 15:08:58 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:08:58 --> Helper loaded: url_helper
INFO - 2021-07-05 15:08:58 --> Helper loaded: file_helper
INFO - 2021-07-05 15:08:58 --> Helper loaded: form_helper
INFO - 2021-07-05 15:08:58 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:08:58 --> Helper loaded: security_helper
INFO - 2021-07-05 15:08:58 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:08:58 --> Helper loaded: language_helper
INFO - 2021-07-05 15:08:58 --> Helper loaded: general_helper
INFO - 2021-07-05 15:08:58 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:08:58 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:08:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:08:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:08:58 --> Parser Class Initialized
INFO - 2021-07-05 15:08:58 --> Form Validation Class Initialized
INFO - 2021-07-05 15:08:58 --> Upload Class Initialized
INFO - 2021-07-05 15:08:58 --> Email Class Initialized
INFO - 2021-07-05 15:08:58 --> MY_Model class loaded
INFO - 2021-07-05 15:08:58 --> Model "Users_model" initialized
INFO - 2021-07-05 15:08:58 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:08:58 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:08:58 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:08:58 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:08:58 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:08:58 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:08:58 --> Database Driver Class Initialized
INFO - 2021-07-05 15:08:59 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:08:59 --> Controller Class Initialized
ERROR - 2021-07-05 18:08:59 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 18:08:59 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 18:08:59 --> Final output sent to browser
DEBUG - 2021-07-05 18:08:59 --> Total execution time: 0.1312
INFO - 2021-07-05 15:10:58 --> Config Class Initialized
INFO - 2021-07-05 15:10:58 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:10:58 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:10:58 --> Utf8 Class Initialized
INFO - 2021-07-05 15:10:58 --> URI Class Initialized
INFO - 2021-07-05 15:10:58 --> Router Class Initialized
INFO - 2021-07-05 15:10:58 --> Output Class Initialized
INFO - 2021-07-05 15:10:58 --> Security Class Initialized
DEBUG - 2021-07-05 15:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:10:58 --> Input Class Initialized
INFO - 2021-07-05 15:10:58 --> Language Class Initialized
INFO - 2021-07-05 15:10:58 --> Loader Class Initialized
INFO - 2021-07-05 15:10:58 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:10:58 --> Helper loaded: url_helper
INFO - 2021-07-05 15:10:58 --> Helper loaded: file_helper
INFO - 2021-07-05 15:10:58 --> Helper loaded: form_helper
INFO - 2021-07-05 15:10:58 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:10:58 --> Helper loaded: security_helper
INFO - 2021-07-05 15:10:58 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:10:58 --> Helper loaded: language_helper
INFO - 2021-07-05 15:10:58 --> Helper loaded: general_helper
INFO - 2021-07-05 15:10:58 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:10:58 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:10:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:10:58 --> Parser Class Initialized
INFO - 2021-07-05 15:10:58 --> Form Validation Class Initialized
INFO - 2021-07-05 15:10:58 --> Upload Class Initialized
INFO - 2021-07-05 15:10:58 --> Email Class Initialized
INFO - 2021-07-05 15:10:58 --> MY_Model class loaded
INFO - 2021-07-05 15:10:58 --> Model "Users_model" initialized
INFO - 2021-07-05 15:10:58 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:10:58 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:10:58 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:10:58 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:10:58 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:10:58 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:10:58 --> Database Driver Class Initialized
INFO - 2021-07-05 15:10:58 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:10:58 --> Controller Class Initialized
ERROR - 2021-07-05 18:10:58 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 18:10:58 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 18:10:58 --> Final output sent to browser
DEBUG - 2021-07-05 18:10:58 --> Total execution time: 0.1361
INFO - 2021-07-05 15:11:13 --> Config Class Initialized
INFO - 2021-07-05 15:11:13 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:11:13 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:11:13 --> Utf8 Class Initialized
INFO - 2021-07-05 15:11:13 --> URI Class Initialized
INFO - 2021-07-05 15:11:13 --> Router Class Initialized
INFO - 2021-07-05 15:11:13 --> Output Class Initialized
INFO - 2021-07-05 15:11:13 --> Security Class Initialized
DEBUG - 2021-07-05 15:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:11:13 --> Input Class Initialized
INFO - 2021-07-05 15:11:13 --> Language Class Initialized
INFO - 2021-07-05 15:11:13 --> Loader Class Initialized
INFO - 2021-07-05 15:11:13 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:11:13 --> Helper loaded: url_helper
INFO - 2021-07-05 15:11:13 --> Helper loaded: file_helper
INFO - 2021-07-05 15:11:13 --> Helper loaded: form_helper
INFO - 2021-07-05 15:11:13 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:11:13 --> Helper loaded: security_helper
INFO - 2021-07-05 15:11:13 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:11:13 --> Helper loaded: language_helper
INFO - 2021-07-05 15:11:13 --> Helper loaded: general_helper
INFO - 2021-07-05 15:11:13 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:11:13 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:11:13 --> Parser Class Initialized
INFO - 2021-07-05 15:11:13 --> Form Validation Class Initialized
INFO - 2021-07-05 15:11:13 --> Upload Class Initialized
INFO - 2021-07-05 15:11:13 --> Email Class Initialized
INFO - 2021-07-05 15:11:13 --> MY_Model class loaded
INFO - 2021-07-05 15:11:13 --> Model "Users_model" initialized
INFO - 2021-07-05 15:11:13 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:11:13 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:11:13 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:11:13 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:11:13 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:11:13 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:11:13 --> Database Driver Class Initialized
INFO - 2021-07-05 15:11:13 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:11:13 --> Controller Class Initialized
ERROR - 2021-07-05 18:11:13 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 18:11:13 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 18:11:13 --> Final output sent to browser
DEBUG - 2021-07-05 18:11:13 --> Total execution time: 0.1241
INFO - 2021-07-05 15:11:24 --> Config Class Initialized
INFO - 2021-07-05 15:11:24 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:11:24 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:11:24 --> Utf8 Class Initialized
INFO - 2021-07-05 15:11:24 --> URI Class Initialized
INFO - 2021-07-05 15:11:24 --> Router Class Initialized
INFO - 2021-07-05 15:11:24 --> Output Class Initialized
INFO - 2021-07-05 15:11:24 --> Security Class Initialized
DEBUG - 2021-07-05 15:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:11:24 --> Input Class Initialized
INFO - 2021-07-05 15:11:24 --> Language Class Initialized
INFO - 2021-07-05 15:11:24 --> Loader Class Initialized
INFO - 2021-07-05 15:11:24 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:11:24 --> Helper loaded: url_helper
INFO - 2021-07-05 15:11:24 --> Helper loaded: file_helper
INFO - 2021-07-05 15:11:24 --> Helper loaded: form_helper
INFO - 2021-07-05 15:11:24 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:11:24 --> Helper loaded: security_helper
INFO - 2021-07-05 15:11:24 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:11:24 --> Helper loaded: language_helper
INFO - 2021-07-05 15:11:24 --> Helper loaded: general_helper
INFO - 2021-07-05 15:11:24 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:11:24 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:11:24 --> Parser Class Initialized
INFO - 2021-07-05 15:11:24 --> Form Validation Class Initialized
INFO - 2021-07-05 15:11:24 --> Upload Class Initialized
INFO - 2021-07-05 15:11:24 --> Email Class Initialized
INFO - 2021-07-05 15:11:24 --> MY_Model class loaded
INFO - 2021-07-05 15:11:24 --> Model "Users_model" initialized
INFO - 2021-07-05 15:11:24 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:11:24 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:11:24 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:11:24 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:11:24 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:11:24 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:11:24 --> Database Driver Class Initialized
INFO - 2021-07-05 15:11:24 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:11:24 --> Controller Class Initialized
ERROR - 2021-07-05 18:11:24 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 18:11:24 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 18:11:24 --> Final output sent to browser
DEBUG - 2021-07-05 18:11:24 --> Total execution time: 0.1298
INFO - 2021-07-05 15:11:44 --> Config Class Initialized
INFO - 2021-07-05 15:11:44 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:11:44 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:11:44 --> Utf8 Class Initialized
INFO - 2021-07-05 15:11:44 --> URI Class Initialized
INFO - 2021-07-05 15:11:44 --> Router Class Initialized
INFO - 2021-07-05 15:11:44 --> Output Class Initialized
INFO - 2021-07-05 15:11:44 --> Security Class Initialized
DEBUG - 2021-07-05 15:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:11:44 --> Input Class Initialized
INFO - 2021-07-05 15:11:44 --> Language Class Initialized
INFO - 2021-07-05 15:11:44 --> Loader Class Initialized
INFO - 2021-07-05 15:11:44 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:11:44 --> Helper loaded: url_helper
INFO - 2021-07-05 15:11:44 --> Helper loaded: file_helper
INFO - 2021-07-05 15:11:44 --> Helper loaded: form_helper
INFO - 2021-07-05 15:11:44 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:11:44 --> Helper loaded: security_helper
INFO - 2021-07-05 15:11:44 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:11:44 --> Helper loaded: language_helper
INFO - 2021-07-05 15:11:44 --> Helper loaded: general_helper
INFO - 2021-07-05 15:11:44 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:11:44 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:11:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:11:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:11:44 --> Parser Class Initialized
INFO - 2021-07-05 15:11:44 --> Form Validation Class Initialized
INFO - 2021-07-05 15:11:44 --> Upload Class Initialized
INFO - 2021-07-05 15:11:44 --> Email Class Initialized
INFO - 2021-07-05 15:11:44 --> MY_Model class loaded
INFO - 2021-07-05 15:11:44 --> Model "Users_model" initialized
INFO - 2021-07-05 15:11:44 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:11:44 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:11:44 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:11:44 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:11:44 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:11:44 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:11:44 --> Database Driver Class Initialized
INFO - 2021-07-05 15:11:44 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:11:44 --> Controller Class Initialized
ERROR - 2021-07-05 18:11:44 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 18:11:44 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 18:11:44 --> Final output sent to browser
DEBUG - 2021-07-05 18:11:44 --> Total execution time: 0.1211
INFO - 2021-07-05 15:12:13 --> Config Class Initialized
INFO - 2021-07-05 15:12:13 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:12:13 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:12:13 --> Utf8 Class Initialized
INFO - 2021-07-05 15:12:13 --> URI Class Initialized
INFO - 2021-07-05 15:12:13 --> Router Class Initialized
INFO - 2021-07-05 15:12:13 --> Output Class Initialized
INFO - 2021-07-05 15:12:13 --> Security Class Initialized
DEBUG - 2021-07-05 15:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:12:13 --> Input Class Initialized
INFO - 2021-07-05 15:12:13 --> Language Class Initialized
INFO - 2021-07-05 15:12:13 --> Loader Class Initialized
INFO - 2021-07-05 15:12:13 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:12:13 --> Helper loaded: url_helper
INFO - 2021-07-05 15:12:13 --> Helper loaded: file_helper
INFO - 2021-07-05 15:12:13 --> Helper loaded: form_helper
INFO - 2021-07-05 15:12:13 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:12:13 --> Helper loaded: security_helper
INFO - 2021-07-05 15:12:13 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:12:13 --> Helper loaded: language_helper
INFO - 2021-07-05 15:12:13 --> Helper loaded: general_helper
INFO - 2021-07-05 15:12:13 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:12:13 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:12:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:12:13 --> Parser Class Initialized
INFO - 2021-07-05 15:12:13 --> Form Validation Class Initialized
INFO - 2021-07-05 15:12:13 --> Upload Class Initialized
INFO - 2021-07-05 15:12:13 --> Email Class Initialized
INFO - 2021-07-05 15:12:13 --> MY_Model class loaded
INFO - 2021-07-05 15:12:13 --> Model "Users_model" initialized
INFO - 2021-07-05 15:12:13 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:12:13 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:12:13 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:12:13 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:12:13 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:12:13 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:12:13 --> Database Driver Class Initialized
INFO - 2021-07-05 15:12:13 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:12:13 --> Controller Class Initialized
ERROR - 2021-07-05 18:12:13 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 18:12:13 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 18:12:13 --> Final output sent to browser
DEBUG - 2021-07-05 18:12:13 --> Total execution time: 0.1235
INFO - 2021-07-05 15:12:14 --> Config Class Initialized
INFO - 2021-07-05 15:12:14 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:12:14 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:12:14 --> Utf8 Class Initialized
INFO - 2021-07-05 15:12:14 --> URI Class Initialized
INFO - 2021-07-05 15:12:14 --> Router Class Initialized
INFO - 2021-07-05 15:12:14 --> Output Class Initialized
INFO - 2021-07-05 15:12:14 --> Security Class Initialized
DEBUG - 2021-07-05 15:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:12:14 --> Input Class Initialized
INFO - 2021-07-05 15:12:14 --> Language Class Initialized
INFO - 2021-07-05 15:12:14 --> Loader Class Initialized
INFO - 2021-07-05 15:12:14 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:12:14 --> Helper loaded: url_helper
INFO - 2021-07-05 15:12:14 --> Helper loaded: file_helper
INFO - 2021-07-05 15:12:14 --> Helper loaded: form_helper
INFO - 2021-07-05 15:12:14 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:12:14 --> Helper loaded: security_helper
INFO - 2021-07-05 15:12:14 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:12:14 --> Helper loaded: language_helper
INFO - 2021-07-05 15:12:14 --> Helper loaded: general_helper
INFO - 2021-07-05 15:12:14 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:12:14 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:12:14 --> Parser Class Initialized
INFO - 2021-07-05 15:12:14 --> Form Validation Class Initialized
INFO - 2021-07-05 15:12:14 --> Upload Class Initialized
INFO - 2021-07-05 15:12:14 --> Email Class Initialized
INFO - 2021-07-05 15:12:14 --> MY_Model class loaded
INFO - 2021-07-05 15:12:14 --> Model "Users_model" initialized
INFO - 2021-07-05 15:12:14 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:12:14 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:12:14 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:12:14 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:12:14 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:12:14 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:12:14 --> Database Driver Class Initialized
INFO - 2021-07-05 15:12:14 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:12:14 --> Controller Class Initialized
ERROR - 2021-07-05 18:12:14 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 18:12:14 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 18:12:14 --> Final output sent to browser
DEBUG - 2021-07-05 18:12:14 --> Total execution time: 0.0582
INFO - 2021-07-05 15:12:15 --> Config Class Initialized
INFO - 2021-07-05 15:12:15 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:12:15 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:12:15 --> Utf8 Class Initialized
INFO - 2021-07-05 15:12:15 --> URI Class Initialized
INFO - 2021-07-05 15:12:15 --> Router Class Initialized
INFO - 2021-07-05 15:12:15 --> Output Class Initialized
INFO - 2021-07-05 15:12:15 --> Security Class Initialized
DEBUG - 2021-07-05 15:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:12:15 --> Input Class Initialized
INFO - 2021-07-05 15:12:15 --> Language Class Initialized
INFO - 2021-07-05 15:12:15 --> Loader Class Initialized
INFO - 2021-07-05 15:12:15 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:12:15 --> Helper loaded: url_helper
INFO - 2021-07-05 15:12:15 --> Helper loaded: file_helper
INFO - 2021-07-05 15:12:15 --> Helper loaded: form_helper
INFO - 2021-07-05 15:12:15 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:12:15 --> Helper loaded: security_helper
INFO - 2021-07-05 15:12:15 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:12:15 --> Helper loaded: language_helper
INFO - 2021-07-05 15:12:15 --> Helper loaded: general_helper
INFO - 2021-07-05 15:12:15 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:12:15 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:12:15 --> Parser Class Initialized
INFO - 2021-07-05 15:12:15 --> Form Validation Class Initialized
INFO - 2021-07-05 15:12:15 --> Upload Class Initialized
INFO - 2021-07-05 15:12:15 --> Email Class Initialized
INFO - 2021-07-05 15:12:15 --> MY_Model class loaded
INFO - 2021-07-05 15:12:15 --> Model "Users_model" initialized
INFO - 2021-07-05 15:12:15 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:12:15 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:12:15 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:12:15 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:12:15 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:12:15 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:12:15 --> Database Driver Class Initialized
INFO - 2021-07-05 15:12:15 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:12:15 --> Controller Class Initialized
ERROR - 2021-07-05 18:12:15 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 18:12:15 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 18:12:15 --> Final output sent to browser
DEBUG - 2021-07-05 18:12:15 --> Total execution time: 0.0596
INFO - 2021-07-05 15:37:43 --> Config Class Initialized
INFO - 2021-07-05 15:37:43 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:37:43 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:37:43 --> Utf8 Class Initialized
INFO - 2021-07-05 15:37:43 --> URI Class Initialized
INFO - 2021-07-05 15:37:43 --> Router Class Initialized
INFO - 2021-07-05 15:37:43 --> Output Class Initialized
INFO - 2021-07-05 15:37:43 --> Security Class Initialized
DEBUG - 2021-07-05 15:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:37:43 --> Input Class Initialized
INFO - 2021-07-05 15:37:43 --> Language Class Initialized
INFO - 2021-07-05 15:37:43 --> Loader Class Initialized
INFO - 2021-07-05 15:37:43 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:37:43 --> Helper loaded: url_helper
INFO - 2021-07-05 15:37:43 --> Helper loaded: file_helper
INFO - 2021-07-05 15:37:43 --> Helper loaded: form_helper
INFO - 2021-07-05 15:37:43 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:37:43 --> Helper loaded: security_helper
INFO - 2021-07-05 15:37:43 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:37:43 --> Helper loaded: language_helper
INFO - 2021-07-05 15:37:43 --> Helper loaded: general_helper
INFO - 2021-07-05 15:37:43 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:37:43 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:37:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:37:43 --> Parser Class Initialized
INFO - 2021-07-05 15:37:43 --> Form Validation Class Initialized
INFO - 2021-07-05 15:37:43 --> Upload Class Initialized
INFO - 2021-07-05 15:37:43 --> Email Class Initialized
INFO - 2021-07-05 15:37:43 --> MY_Model class loaded
INFO - 2021-07-05 15:37:43 --> Model "Users_model" initialized
INFO - 2021-07-05 15:37:43 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:37:43 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:37:43 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:37:43 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:37:43 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:37:43 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:37:43 --> Database Driver Class Initialized
INFO - 2021-07-05 15:37:43 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:37:43 --> Controller Class Initialized
ERROR - 2021-07-05 18:37:43 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 18:37:43 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 18:37:43 --> Final output sent to browser
DEBUG - 2021-07-05 18:37:43 --> Total execution time: 0.1633
INFO - 2021-07-05 15:38:12 --> Config Class Initialized
INFO - 2021-07-05 15:38:12 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:38:12 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:38:12 --> Utf8 Class Initialized
INFO - 2021-07-05 15:38:12 --> URI Class Initialized
INFO - 2021-07-05 15:38:12 --> Router Class Initialized
INFO - 2021-07-05 15:38:12 --> Output Class Initialized
INFO - 2021-07-05 15:38:12 --> Security Class Initialized
DEBUG - 2021-07-05 15:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:38:12 --> Input Class Initialized
INFO - 2021-07-05 15:38:12 --> Language Class Initialized
INFO - 2021-07-05 15:38:12 --> Loader Class Initialized
INFO - 2021-07-05 15:38:12 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:38:12 --> Helper loaded: url_helper
INFO - 2021-07-05 15:38:12 --> Helper loaded: file_helper
INFO - 2021-07-05 15:38:12 --> Helper loaded: form_helper
INFO - 2021-07-05 15:38:12 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:38:12 --> Helper loaded: security_helper
INFO - 2021-07-05 15:38:12 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:38:12 --> Helper loaded: language_helper
INFO - 2021-07-05 15:38:12 --> Helper loaded: general_helper
INFO - 2021-07-05 15:38:12 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:38:12 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:38:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:38:12 --> Parser Class Initialized
INFO - 2021-07-05 15:38:12 --> Form Validation Class Initialized
INFO - 2021-07-05 15:38:12 --> Upload Class Initialized
INFO - 2021-07-05 15:38:12 --> Email Class Initialized
INFO - 2021-07-05 15:38:12 --> MY_Model class loaded
INFO - 2021-07-05 15:38:12 --> Model "Users_model" initialized
INFO - 2021-07-05 15:38:12 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:38:12 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:38:12 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:38:12 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:38:12 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:38:12 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:38:12 --> Database Driver Class Initialized
INFO - 2021-07-05 15:38:13 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:38:13 --> Controller Class Initialized
ERROR - 2021-07-05 18:38:13 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 18:38:13 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-05 18:38:13 --> Final output sent to browser
DEBUG - 2021-07-05 18:38:13 --> Total execution time: 0.2214
INFO - 2021-07-05 15:38:39 --> Config Class Initialized
INFO - 2021-07-05 15:38:39 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:38:39 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:38:39 --> Utf8 Class Initialized
INFO - 2021-07-05 15:38:39 --> URI Class Initialized
INFO - 2021-07-05 15:38:39 --> Router Class Initialized
INFO - 2021-07-05 15:38:39 --> Output Class Initialized
INFO - 2021-07-05 15:38:39 --> Security Class Initialized
DEBUG - 2021-07-05 15:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:38:39 --> Input Class Initialized
INFO - 2021-07-05 15:38:39 --> Language Class Initialized
INFO - 2021-07-05 15:38:39 --> Loader Class Initialized
INFO - 2021-07-05 15:38:39 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:38:39 --> Helper loaded: url_helper
INFO - 2021-07-05 15:38:39 --> Helper loaded: file_helper
INFO - 2021-07-05 15:38:39 --> Helper loaded: form_helper
INFO - 2021-07-05 15:38:39 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:38:39 --> Helper loaded: security_helper
INFO - 2021-07-05 15:38:39 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:38:39 --> Helper loaded: language_helper
INFO - 2021-07-05 15:38:39 --> Helper loaded: general_helper
INFO - 2021-07-05 15:38:39 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:38:39 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:38:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:38:39 --> Parser Class Initialized
INFO - 2021-07-05 15:38:39 --> Form Validation Class Initialized
INFO - 2021-07-05 15:38:39 --> Upload Class Initialized
INFO - 2021-07-05 15:38:39 --> Email Class Initialized
INFO - 2021-07-05 15:38:39 --> MY_Model class loaded
INFO - 2021-07-05 15:38:39 --> Model "Users_model" initialized
INFO - 2021-07-05 15:38:39 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:38:39 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:38:39 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:38:39 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:38:39 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:38:39 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:38:39 --> Database Driver Class Initialized
INFO - 2021-07-05 15:38:39 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:38:39 --> Controller Class Initialized
ERROR - 2021-07-05 18:38:39 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 18:38:39 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 18:38:39 --> Final output sent to browser
DEBUG - 2021-07-05 18:38:39 --> Total execution time: 0.1229
INFO - 2021-07-05 15:38:42 --> Config Class Initialized
INFO - 2021-07-05 15:38:42 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:38:42 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:38:42 --> Utf8 Class Initialized
INFO - 2021-07-05 15:38:42 --> URI Class Initialized
INFO - 2021-07-05 15:38:42 --> Router Class Initialized
INFO - 2021-07-05 15:38:42 --> Output Class Initialized
INFO - 2021-07-05 15:38:42 --> Security Class Initialized
DEBUG - 2021-07-05 15:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:38:42 --> Input Class Initialized
INFO - 2021-07-05 15:38:42 --> Language Class Initialized
INFO - 2021-07-05 15:38:42 --> Loader Class Initialized
INFO - 2021-07-05 15:38:42 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:38:42 --> Helper loaded: url_helper
INFO - 2021-07-05 15:38:42 --> Helper loaded: file_helper
INFO - 2021-07-05 15:38:42 --> Helper loaded: form_helper
INFO - 2021-07-05 15:38:42 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:38:42 --> Helper loaded: security_helper
INFO - 2021-07-05 15:38:42 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:38:42 --> Helper loaded: language_helper
INFO - 2021-07-05 15:38:42 --> Helper loaded: general_helper
INFO - 2021-07-05 15:38:42 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:38:42 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:38:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:38:42 --> Parser Class Initialized
INFO - 2021-07-05 15:38:42 --> Form Validation Class Initialized
INFO - 2021-07-05 15:38:42 --> Upload Class Initialized
INFO - 2021-07-05 15:38:42 --> Email Class Initialized
INFO - 2021-07-05 15:38:42 --> MY_Model class loaded
INFO - 2021-07-05 15:38:42 --> Model "Users_model" initialized
INFO - 2021-07-05 15:38:42 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:38:42 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:38:42 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:38:42 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:38:42 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:38:42 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:38:42 --> Database Driver Class Initialized
INFO - 2021-07-05 15:38:42 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:38:42 --> Controller Class Initialized
ERROR - 2021-07-05 18:38:42 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 18:38:42 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 18:38:42 --> Final output sent to browser
DEBUG - 2021-07-05 18:38:42 --> Total execution time: 0.0734
INFO - 2021-07-05 15:38:44 --> Config Class Initialized
INFO - 2021-07-05 15:38:44 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:38:44 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:38:44 --> Utf8 Class Initialized
INFO - 2021-07-05 15:38:44 --> URI Class Initialized
INFO - 2021-07-05 15:38:44 --> Router Class Initialized
INFO - 2021-07-05 15:38:44 --> Output Class Initialized
INFO - 2021-07-05 15:38:44 --> Security Class Initialized
DEBUG - 2021-07-05 15:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:38:44 --> Input Class Initialized
INFO - 2021-07-05 15:38:44 --> Language Class Initialized
INFO - 2021-07-05 15:38:44 --> Loader Class Initialized
INFO - 2021-07-05 15:38:44 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:38:44 --> Helper loaded: url_helper
INFO - 2021-07-05 15:38:44 --> Helper loaded: file_helper
INFO - 2021-07-05 15:38:44 --> Helper loaded: form_helper
INFO - 2021-07-05 15:38:44 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:38:44 --> Helper loaded: security_helper
INFO - 2021-07-05 15:38:44 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:38:44 --> Helper loaded: language_helper
INFO - 2021-07-05 15:38:44 --> Helper loaded: general_helper
INFO - 2021-07-05 15:38:44 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:38:44 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:38:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:38:44 --> Parser Class Initialized
INFO - 2021-07-05 15:38:44 --> Form Validation Class Initialized
INFO - 2021-07-05 15:38:44 --> Upload Class Initialized
INFO - 2021-07-05 15:38:44 --> Email Class Initialized
INFO - 2021-07-05 15:38:44 --> MY_Model class loaded
INFO - 2021-07-05 15:38:44 --> Model "Users_model" initialized
INFO - 2021-07-05 15:38:44 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:38:44 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:38:44 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:38:44 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:38:44 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:38:44 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:38:44 --> Database Driver Class Initialized
INFO - 2021-07-05 15:38:44 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:38:44 --> Controller Class Initialized
ERROR - 2021-07-05 18:38:44 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 18:38:44 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-05 18:38:44 --> Final output sent to browser
DEBUG - 2021-07-05 18:38:44 --> Total execution time: 0.1660
INFO - 2021-07-05 15:38:46 --> Config Class Initialized
INFO - 2021-07-05 15:38:46 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:38:46 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:38:46 --> Utf8 Class Initialized
INFO - 2021-07-05 15:38:46 --> URI Class Initialized
INFO - 2021-07-05 15:38:46 --> Router Class Initialized
INFO - 2021-07-05 15:38:46 --> Output Class Initialized
INFO - 2021-07-05 15:38:46 --> Security Class Initialized
DEBUG - 2021-07-05 15:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:38:46 --> Input Class Initialized
INFO - 2021-07-05 15:38:46 --> Language Class Initialized
INFO - 2021-07-05 15:38:46 --> Loader Class Initialized
INFO - 2021-07-05 15:38:46 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:38:46 --> Helper loaded: url_helper
INFO - 2021-07-05 15:38:46 --> Helper loaded: file_helper
INFO - 2021-07-05 15:38:46 --> Helper loaded: form_helper
INFO - 2021-07-05 15:38:46 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:38:46 --> Helper loaded: security_helper
INFO - 2021-07-05 15:38:46 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:38:46 --> Helper loaded: language_helper
INFO - 2021-07-05 15:38:46 --> Helper loaded: general_helper
INFO - 2021-07-05 15:38:46 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:38:46 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:38:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:38:46 --> Parser Class Initialized
INFO - 2021-07-05 15:38:46 --> Form Validation Class Initialized
INFO - 2021-07-05 15:38:46 --> Upload Class Initialized
INFO - 2021-07-05 15:38:46 --> Email Class Initialized
INFO - 2021-07-05 15:38:46 --> MY_Model class loaded
INFO - 2021-07-05 15:38:46 --> Model "Users_model" initialized
INFO - 2021-07-05 15:38:46 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:38:46 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:38:46 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:38:46 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:38:46 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:38:46 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:38:46 --> Database Driver Class Initialized
INFO - 2021-07-05 15:38:46 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:38:46 --> Controller Class Initialized
ERROR - 2021-07-05 18:38:46 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 18:38:46 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 18:38:46 --> Final output sent to browser
DEBUG - 2021-07-05 18:38:46 --> Total execution time: 0.1306
INFO - 2021-07-05 15:41:16 --> Config Class Initialized
INFO - 2021-07-05 15:41:16 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:41:16 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:41:16 --> Utf8 Class Initialized
INFO - 2021-07-05 15:41:16 --> URI Class Initialized
INFO - 2021-07-05 15:41:16 --> Router Class Initialized
INFO - 2021-07-05 15:41:16 --> Output Class Initialized
INFO - 2021-07-05 15:41:16 --> Security Class Initialized
DEBUG - 2021-07-05 15:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:41:16 --> Input Class Initialized
INFO - 2021-07-05 15:41:16 --> Language Class Initialized
INFO - 2021-07-05 15:41:16 --> Loader Class Initialized
INFO - 2021-07-05 15:41:16 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:41:16 --> Helper loaded: url_helper
INFO - 2021-07-05 15:41:16 --> Helper loaded: file_helper
INFO - 2021-07-05 15:41:16 --> Helper loaded: form_helper
INFO - 2021-07-05 15:41:16 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:41:16 --> Helper loaded: security_helper
INFO - 2021-07-05 15:41:16 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:41:16 --> Helper loaded: language_helper
INFO - 2021-07-05 15:41:16 --> Helper loaded: general_helper
INFO - 2021-07-05 15:41:16 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:41:16 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:41:16 --> Parser Class Initialized
INFO - 2021-07-05 15:41:16 --> Form Validation Class Initialized
INFO - 2021-07-05 15:41:16 --> Upload Class Initialized
INFO - 2021-07-05 15:41:16 --> Email Class Initialized
INFO - 2021-07-05 15:41:16 --> MY_Model class loaded
INFO - 2021-07-05 15:41:16 --> Model "Users_model" initialized
INFO - 2021-07-05 15:41:16 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:41:16 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:41:16 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:41:16 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:41:16 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:41:16 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:41:16 --> Database Driver Class Initialized
INFO - 2021-07-05 15:41:16 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:41:16 --> Controller Class Initialized
ERROR - 2021-07-05 18:41:16 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 18:41:16 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 18:41:16 --> Final output sent to browser
DEBUG - 2021-07-05 18:41:16 --> Total execution time: 0.1222
INFO - 2021-07-05 15:41:18 --> Config Class Initialized
INFO - 2021-07-05 15:41:18 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:41:18 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:41:18 --> Utf8 Class Initialized
INFO - 2021-07-05 15:41:18 --> URI Class Initialized
INFO - 2021-07-05 15:41:18 --> Router Class Initialized
INFO - 2021-07-05 15:41:18 --> Output Class Initialized
INFO - 2021-07-05 15:41:18 --> Security Class Initialized
DEBUG - 2021-07-05 15:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:41:18 --> Input Class Initialized
INFO - 2021-07-05 15:41:18 --> Language Class Initialized
INFO - 2021-07-05 15:41:18 --> Loader Class Initialized
INFO - 2021-07-05 15:41:18 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:41:18 --> Helper loaded: url_helper
INFO - 2021-07-05 15:41:18 --> Helper loaded: file_helper
INFO - 2021-07-05 15:41:18 --> Helper loaded: form_helper
INFO - 2021-07-05 15:41:18 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:41:18 --> Helper loaded: security_helper
INFO - 2021-07-05 15:41:18 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:41:18 --> Helper loaded: language_helper
INFO - 2021-07-05 15:41:18 --> Helper loaded: general_helper
INFO - 2021-07-05 15:41:18 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:41:18 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:41:18 --> Parser Class Initialized
INFO - 2021-07-05 15:41:18 --> Form Validation Class Initialized
INFO - 2021-07-05 15:41:18 --> Upload Class Initialized
INFO - 2021-07-05 15:41:18 --> Email Class Initialized
INFO - 2021-07-05 15:41:18 --> MY_Model class loaded
INFO - 2021-07-05 15:41:18 --> Model "Users_model" initialized
INFO - 2021-07-05 15:41:18 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:41:18 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:41:18 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:41:18 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:41:18 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:41:18 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:41:18 --> Database Driver Class Initialized
INFO - 2021-07-05 15:41:18 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:41:18 --> Controller Class Initialized
ERROR - 2021-07-05 18:41:18 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 18:41:18 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 18:41:18 --> Final output sent to browser
DEBUG - 2021-07-05 18:41:18 --> Total execution time: 0.0770
INFO - 2021-07-05 15:41:18 --> Config Class Initialized
INFO - 2021-07-05 15:41:18 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:41:18 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:41:18 --> Utf8 Class Initialized
INFO - 2021-07-05 15:41:18 --> URI Class Initialized
INFO - 2021-07-05 15:41:18 --> Router Class Initialized
INFO - 2021-07-05 15:41:18 --> Output Class Initialized
INFO - 2021-07-05 15:41:18 --> Security Class Initialized
DEBUG - 2021-07-05 15:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:41:18 --> Input Class Initialized
INFO - 2021-07-05 15:41:18 --> Language Class Initialized
INFO - 2021-07-05 15:41:18 --> Loader Class Initialized
INFO - 2021-07-05 15:41:18 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:41:18 --> Helper loaded: url_helper
INFO - 2021-07-05 15:41:18 --> Helper loaded: file_helper
INFO - 2021-07-05 15:41:18 --> Helper loaded: form_helper
INFO - 2021-07-05 15:41:18 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:41:18 --> Helper loaded: security_helper
INFO - 2021-07-05 15:41:18 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:41:18 --> Helper loaded: language_helper
INFO - 2021-07-05 15:41:18 --> Helper loaded: general_helper
INFO - 2021-07-05 15:41:18 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:41:18 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:41:18 --> Parser Class Initialized
INFO - 2021-07-05 15:41:18 --> Form Validation Class Initialized
INFO - 2021-07-05 15:41:18 --> Upload Class Initialized
INFO - 2021-07-05 15:41:18 --> Email Class Initialized
INFO - 2021-07-05 15:41:18 --> MY_Model class loaded
INFO - 2021-07-05 15:41:18 --> Model "Users_model" initialized
INFO - 2021-07-05 15:41:18 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:41:18 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:41:18 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:41:18 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:41:18 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:41:18 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:41:18 --> Database Driver Class Initialized
INFO - 2021-07-05 15:41:18 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:41:18 --> Controller Class Initialized
ERROR - 2021-07-05 18:41:18 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 18:41:18 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 18:41:18 --> Final output sent to browser
DEBUG - 2021-07-05 18:41:18 --> Total execution time: 0.0604
INFO - 2021-07-05 15:42:41 --> Config Class Initialized
INFO - 2021-07-05 15:42:41 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:42:41 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:42:41 --> Utf8 Class Initialized
INFO - 2021-07-05 15:42:41 --> URI Class Initialized
INFO - 2021-07-05 15:42:41 --> Router Class Initialized
INFO - 2021-07-05 15:42:41 --> Output Class Initialized
INFO - 2021-07-05 15:42:41 --> Security Class Initialized
DEBUG - 2021-07-05 15:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:42:41 --> Input Class Initialized
INFO - 2021-07-05 15:42:41 --> Language Class Initialized
INFO - 2021-07-05 15:42:41 --> Loader Class Initialized
INFO - 2021-07-05 15:42:41 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:42:41 --> Helper loaded: url_helper
INFO - 2021-07-05 15:42:41 --> Helper loaded: file_helper
INFO - 2021-07-05 15:42:41 --> Helper loaded: form_helper
INFO - 2021-07-05 15:42:41 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:42:41 --> Helper loaded: security_helper
INFO - 2021-07-05 15:42:41 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:42:41 --> Helper loaded: language_helper
INFO - 2021-07-05 15:42:41 --> Helper loaded: general_helper
INFO - 2021-07-05 15:42:41 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:42:41 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:42:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:42:41 --> Parser Class Initialized
INFO - 2021-07-05 15:42:41 --> Form Validation Class Initialized
INFO - 2021-07-05 15:42:41 --> Upload Class Initialized
INFO - 2021-07-05 15:42:41 --> Email Class Initialized
INFO - 2021-07-05 15:42:41 --> MY_Model class loaded
INFO - 2021-07-05 15:42:41 --> Model "Users_model" initialized
INFO - 2021-07-05 15:42:41 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:42:41 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:42:41 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:42:41 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:42:41 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:42:41 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:42:41 --> Database Driver Class Initialized
INFO - 2021-07-05 15:42:41 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:42:41 --> Controller Class Initialized
ERROR - 2021-07-05 18:42:41 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 18:42:41 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-05 18:42:41 --> Final output sent to browser
DEBUG - 2021-07-05 18:42:41 --> Total execution time: 0.2570
INFO - 2021-07-05 15:42:44 --> Config Class Initialized
INFO - 2021-07-05 15:42:44 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:42:44 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:42:44 --> Utf8 Class Initialized
INFO - 2021-07-05 15:42:44 --> URI Class Initialized
INFO - 2021-07-05 15:42:44 --> Router Class Initialized
INFO - 2021-07-05 15:42:44 --> Output Class Initialized
INFO - 2021-07-05 15:42:44 --> Security Class Initialized
DEBUG - 2021-07-05 15:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:42:44 --> Input Class Initialized
INFO - 2021-07-05 15:42:44 --> Language Class Initialized
INFO - 2021-07-05 15:42:44 --> Loader Class Initialized
INFO - 2021-07-05 15:42:44 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:42:44 --> Helper loaded: url_helper
INFO - 2021-07-05 15:42:44 --> Helper loaded: file_helper
INFO - 2021-07-05 15:42:44 --> Helper loaded: form_helper
INFO - 2021-07-05 15:42:44 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:42:44 --> Helper loaded: security_helper
INFO - 2021-07-05 15:42:44 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:42:44 --> Helper loaded: language_helper
INFO - 2021-07-05 15:42:44 --> Helper loaded: general_helper
INFO - 2021-07-05 15:42:44 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:42:44 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:42:44 --> Parser Class Initialized
INFO - 2021-07-05 15:42:44 --> Form Validation Class Initialized
INFO - 2021-07-05 15:42:44 --> Upload Class Initialized
INFO - 2021-07-05 15:42:44 --> Email Class Initialized
INFO - 2021-07-05 15:42:44 --> MY_Model class loaded
INFO - 2021-07-05 15:42:44 --> Model "Users_model" initialized
INFO - 2021-07-05 15:42:44 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:42:44 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:42:44 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:42:44 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:42:44 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:42:44 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:42:44 --> Database Driver Class Initialized
INFO - 2021-07-05 15:42:44 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:42:44 --> Controller Class Initialized
ERROR - 2021-07-05 18:42:44 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 18:42:44 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 18:42:44 --> Final output sent to browser
DEBUG - 2021-07-05 18:42:44 --> Total execution time: 0.0616
INFO - 2021-07-05 15:44:52 --> Config Class Initialized
INFO - 2021-07-05 15:44:52 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:44:52 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:44:52 --> Utf8 Class Initialized
INFO - 2021-07-05 15:44:52 --> URI Class Initialized
INFO - 2021-07-05 15:44:52 --> Router Class Initialized
INFO - 2021-07-05 15:44:52 --> Output Class Initialized
INFO - 2021-07-05 15:44:52 --> Security Class Initialized
DEBUG - 2021-07-05 15:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:44:52 --> Input Class Initialized
INFO - 2021-07-05 15:44:52 --> Language Class Initialized
INFO - 2021-07-05 15:44:52 --> Loader Class Initialized
INFO - 2021-07-05 15:44:52 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:44:52 --> Helper loaded: url_helper
INFO - 2021-07-05 15:44:52 --> Helper loaded: file_helper
INFO - 2021-07-05 15:44:52 --> Helper loaded: form_helper
INFO - 2021-07-05 15:44:52 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:44:52 --> Helper loaded: security_helper
INFO - 2021-07-05 15:44:52 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:44:52 --> Helper loaded: language_helper
INFO - 2021-07-05 15:44:52 --> Helper loaded: general_helper
INFO - 2021-07-05 15:44:52 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:44:52 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:44:52 --> Parser Class Initialized
INFO - 2021-07-05 15:44:52 --> Form Validation Class Initialized
INFO - 2021-07-05 15:44:52 --> Upload Class Initialized
INFO - 2021-07-05 15:44:52 --> Email Class Initialized
INFO - 2021-07-05 15:44:52 --> MY_Model class loaded
INFO - 2021-07-05 15:44:52 --> Model "Users_model" initialized
INFO - 2021-07-05 15:44:52 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:44:52 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:44:52 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:44:52 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:44:52 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:44:52 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:44:52 --> Database Driver Class Initialized
INFO - 2021-07-05 15:44:52 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:44:52 --> Controller Class Initialized
ERROR - 2021-07-05 18:44:52 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 18:44:52 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 18:44:52 --> Final output sent to browser
DEBUG - 2021-07-05 18:44:52 --> Total execution time: 0.1530
INFO - 2021-07-05 15:45:52 --> Config Class Initialized
INFO - 2021-07-05 15:45:52 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:45:52 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:45:52 --> Utf8 Class Initialized
INFO - 2021-07-05 15:45:52 --> URI Class Initialized
INFO - 2021-07-05 15:45:52 --> Router Class Initialized
INFO - 2021-07-05 15:45:52 --> Output Class Initialized
INFO - 2021-07-05 15:45:52 --> Security Class Initialized
DEBUG - 2021-07-05 15:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:45:52 --> Input Class Initialized
INFO - 2021-07-05 15:45:52 --> Language Class Initialized
INFO - 2021-07-05 15:45:52 --> Loader Class Initialized
INFO - 2021-07-05 15:45:52 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:45:52 --> Helper loaded: url_helper
INFO - 2021-07-05 15:45:52 --> Helper loaded: file_helper
INFO - 2021-07-05 15:45:52 --> Helper loaded: form_helper
INFO - 2021-07-05 15:45:52 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:45:52 --> Helper loaded: security_helper
INFO - 2021-07-05 15:45:52 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:45:52 --> Helper loaded: language_helper
INFO - 2021-07-05 15:45:52 --> Helper loaded: general_helper
INFO - 2021-07-05 15:45:52 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:45:52 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:45:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:45:52 --> Parser Class Initialized
INFO - 2021-07-05 15:45:52 --> Form Validation Class Initialized
INFO - 2021-07-05 15:45:52 --> Upload Class Initialized
INFO - 2021-07-05 15:45:52 --> Email Class Initialized
INFO - 2021-07-05 15:45:52 --> MY_Model class loaded
INFO - 2021-07-05 15:45:52 --> Model "Users_model" initialized
INFO - 2021-07-05 15:45:52 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:45:52 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:45:52 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:45:52 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:45:52 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:45:52 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:45:52 --> Database Driver Class Initialized
INFO - 2021-07-05 15:45:52 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:45:52 --> Controller Class Initialized
ERROR - 2021-07-05 18:45:52 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 18:45:52 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 18:45:52 --> Final output sent to browser
DEBUG - 2021-07-05 18:45:52 --> Total execution time: 0.1503
INFO - 2021-07-05 15:46:24 --> Config Class Initialized
INFO - 2021-07-05 15:46:24 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:46:24 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:46:24 --> Utf8 Class Initialized
INFO - 2021-07-05 15:46:24 --> URI Class Initialized
INFO - 2021-07-05 15:46:24 --> Router Class Initialized
INFO - 2021-07-05 15:46:24 --> Output Class Initialized
INFO - 2021-07-05 15:46:24 --> Security Class Initialized
DEBUG - 2021-07-05 15:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:46:24 --> Input Class Initialized
INFO - 2021-07-05 15:46:24 --> Language Class Initialized
INFO - 2021-07-05 15:46:24 --> Loader Class Initialized
INFO - 2021-07-05 15:46:24 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:46:24 --> Helper loaded: url_helper
INFO - 2021-07-05 15:46:24 --> Helper loaded: file_helper
INFO - 2021-07-05 15:46:24 --> Helper loaded: form_helper
INFO - 2021-07-05 15:46:24 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:46:24 --> Helper loaded: security_helper
INFO - 2021-07-05 15:46:24 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:46:24 --> Helper loaded: language_helper
INFO - 2021-07-05 15:46:24 --> Helper loaded: general_helper
INFO - 2021-07-05 15:46:24 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:46:24 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:46:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:46:24 --> Parser Class Initialized
INFO - 2021-07-05 15:46:24 --> Form Validation Class Initialized
INFO - 2021-07-05 15:46:24 --> Upload Class Initialized
INFO - 2021-07-05 15:46:24 --> Email Class Initialized
INFO - 2021-07-05 15:46:24 --> MY_Model class loaded
INFO - 2021-07-05 15:46:24 --> Model "Users_model" initialized
INFO - 2021-07-05 15:46:24 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:46:24 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:46:24 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:46:24 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:46:24 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:46:24 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:46:24 --> Database Driver Class Initialized
INFO - 2021-07-05 15:46:24 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:46:24 --> Controller Class Initialized
ERROR - 2021-07-05 18:46:24 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 18:46:24 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 18:46:24 --> Final output sent to browser
DEBUG - 2021-07-05 18:46:24 --> Total execution time: 0.1598
INFO - 2021-07-05 15:47:59 --> Config Class Initialized
INFO - 2021-07-05 15:47:59 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:47:59 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:47:59 --> Utf8 Class Initialized
INFO - 2021-07-05 15:47:59 --> URI Class Initialized
INFO - 2021-07-05 15:47:59 --> Router Class Initialized
INFO - 2021-07-05 15:47:59 --> Output Class Initialized
INFO - 2021-07-05 15:47:59 --> Security Class Initialized
DEBUG - 2021-07-05 15:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:47:59 --> Input Class Initialized
INFO - 2021-07-05 15:47:59 --> Language Class Initialized
INFO - 2021-07-05 15:47:59 --> Loader Class Initialized
INFO - 2021-07-05 15:47:59 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:47:59 --> Helper loaded: url_helper
INFO - 2021-07-05 15:47:59 --> Helper loaded: file_helper
INFO - 2021-07-05 15:47:59 --> Helper loaded: form_helper
INFO - 2021-07-05 15:47:59 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:47:59 --> Helper loaded: security_helper
INFO - 2021-07-05 15:47:59 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:47:59 --> Helper loaded: language_helper
INFO - 2021-07-05 15:47:59 --> Helper loaded: general_helper
INFO - 2021-07-05 15:47:59 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:47:59 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:47:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:47:59 --> Parser Class Initialized
INFO - 2021-07-05 15:47:59 --> Form Validation Class Initialized
INFO - 2021-07-05 15:47:59 --> Upload Class Initialized
INFO - 2021-07-05 15:47:59 --> Email Class Initialized
INFO - 2021-07-05 15:47:59 --> MY_Model class loaded
INFO - 2021-07-05 15:47:59 --> Model "Users_model" initialized
INFO - 2021-07-05 15:47:59 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:47:59 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:47:59 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:47:59 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:47:59 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:47:59 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:47:59 --> Database Driver Class Initialized
INFO - 2021-07-05 15:47:59 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:47:59 --> Controller Class Initialized
ERROR - 2021-07-05 18:47:59 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 18:48:00 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-05 18:48:00 --> Final output sent to browser
DEBUG - 2021-07-05 18:48:00 --> Total execution time: 0.2422
INFO - 2021-07-05 15:48:02 --> Config Class Initialized
INFO - 2021-07-05 15:48:02 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:48:02 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:48:02 --> Utf8 Class Initialized
INFO - 2021-07-05 15:48:02 --> URI Class Initialized
INFO - 2021-07-05 15:48:02 --> Router Class Initialized
INFO - 2021-07-05 15:48:02 --> Output Class Initialized
INFO - 2021-07-05 15:48:02 --> Security Class Initialized
DEBUG - 2021-07-05 15:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:48:02 --> Input Class Initialized
INFO - 2021-07-05 15:48:02 --> Language Class Initialized
INFO - 2021-07-05 15:48:02 --> Loader Class Initialized
INFO - 2021-07-05 15:48:02 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:48:02 --> Helper loaded: url_helper
INFO - 2021-07-05 15:48:02 --> Helper loaded: file_helper
INFO - 2021-07-05 15:48:02 --> Helper loaded: form_helper
INFO - 2021-07-05 15:48:02 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:48:02 --> Helper loaded: security_helper
INFO - 2021-07-05 15:48:02 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:48:02 --> Helper loaded: language_helper
INFO - 2021-07-05 15:48:02 --> Helper loaded: general_helper
INFO - 2021-07-05 15:48:02 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:48:02 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:48:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:48:02 --> Parser Class Initialized
INFO - 2021-07-05 15:48:02 --> Form Validation Class Initialized
INFO - 2021-07-05 15:48:02 --> Upload Class Initialized
INFO - 2021-07-05 15:48:02 --> Email Class Initialized
INFO - 2021-07-05 15:48:02 --> MY_Model class loaded
INFO - 2021-07-05 15:48:02 --> Model "Users_model" initialized
INFO - 2021-07-05 15:48:02 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:48:02 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:48:02 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:48:02 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:48:02 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:48:02 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:48:02 --> Database Driver Class Initialized
INFO - 2021-07-05 15:48:02 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:48:02 --> Controller Class Initialized
ERROR - 2021-07-05 18:48:02 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-05 18:48:02 --> Invalid query: 
ERROR - 2021-07-05 18:48:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\crm\application\views\hesaplar\not_ekle_view.php 164
INFO - 2021-07-05 18:48:02 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-05 18:48:02 --> Final output sent to browser
DEBUG - 2021-07-05 18:48:02 --> Total execution time: 0.0625
INFO - 2021-07-05 15:48:38 --> Config Class Initialized
INFO - 2021-07-05 15:48:38 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:48:38 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:48:38 --> Utf8 Class Initialized
INFO - 2021-07-05 15:48:38 --> URI Class Initialized
INFO - 2021-07-05 15:48:38 --> Router Class Initialized
INFO - 2021-07-05 15:48:38 --> Output Class Initialized
INFO - 2021-07-05 15:48:38 --> Security Class Initialized
DEBUG - 2021-07-05 15:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:48:38 --> Input Class Initialized
INFO - 2021-07-05 15:48:38 --> Language Class Initialized
INFO - 2021-07-05 15:48:38 --> Loader Class Initialized
INFO - 2021-07-05 15:48:38 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:48:38 --> Helper loaded: url_helper
INFO - 2021-07-05 15:48:38 --> Helper loaded: file_helper
INFO - 2021-07-05 15:48:38 --> Helper loaded: form_helper
INFO - 2021-07-05 15:48:38 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:48:38 --> Helper loaded: security_helper
INFO - 2021-07-05 15:48:38 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:48:38 --> Helper loaded: language_helper
INFO - 2021-07-05 15:48:38 --> Helper loaded: general_helper
INFO - 2021-07-05 15:48:38 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:48:38 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:48:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:48:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:48:38 --> Parser Class Initialized
INFO - 2021-07-05 15:48:38 --> Form Validation Class Initialized
INFO - 2021-07-05 15:48:38 --> Upload Class Initialized
INFO - 2021-07-05 15:48:38 --> Email Class Initialized
INFO - 2021-07-05 15:48:38 --> MY_Model class loaded
INFO - 2021-07-05 15:48:38 --> Model "Users_model" initialized
INFO - 2021-07-05 15:48:38 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:48:38 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:48:38 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:48:38 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:48:38 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:48:38 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:48:38 --> Database Driver Class Initialized
INFO - 2021-07-05 15:48:38 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:48:38 --> Controller Class Initialized
ERROR - 2021-07-05 18:48:38 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-05 18:48:38 --> Invalid query: 
INFO - 2021-07-05 18:48:38 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-05 18:48:38 --> Final output sent to browser
DEBUG - 2021-07-05 18:48:38 --> Total execution time: 0.1206
INFO - 2021-07-05 15:48:42 --> Config Class Initialized
INFO - 2021-07-05 15:48:42 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:48:42 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:48:42 --> Utf8 Class Initialized
INFO - 2021-07-05 15:48:42 --> URI Class Initialized
INFO - 2021-07-05 15:48:42 --> Router Class Initialized
INFO - 2021-07-05 15:48:42 --> Output Class Initialized
INFO - 2021-07-05 15:48:42 --> Security Class Initialized
DEBUG - 2021-07-05 15:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:48:42 --> Input Class Initialized
INFO - 2021-07-05 15:48:42 --> Language Class Initialized
INFO - 2021-07-05 15:48:42 --> Loader Class Initialized
INFO - 2021-07-05 15:48:42 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:48:42 --> Helper loaded: url_helper
INFO - 2021-07-05 15:48:42 --> Helper loaded: file_helper
INFO - 2021-07-05 15:48:42 --> Helper loaded: form_helper
INFO - 2021-07-05 15:48:42 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:48:42 --> Helper loaded: security_helper
INFO - 2021-07-05 15:48:42 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:48:42 --> Helper loaded: language_helper
INFO - 2021-07-05 15:48:42 --> Helper loaded: general_helper
INFO - 2021-07-05 15:48:42 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:48:42 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:48:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:48:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:48:42 --> Parser Class Initialized
INFO - 2021-07-05 15:48:42 --> Form Validation Class Initialized
INFO - 2021-07-05 15:48:42 --> Upload Class Initialized
INFO - 2021-07-05 15:48:42 --> Email Class Initialized
INFO - 2021-07-05 15:48:42 --> MY_Model class loaded
INFO - 2021-07-05 15:48:42 --> Model "Users_model" initialized
INFO - 2021-07-05 15:48:42 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:48:42 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:48:42 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:48:42 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:48:42 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:48:42 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:48:42 --> Database Driver Class Initialized
INFO - 2021-07-05 15:48:42 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:48:42 --> Controller Class Initialized
ERROR - 2021-07-05 18:48:42 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 18:48:42 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 18:48:42 --> Final output sent to browser
DEBUG - 2021-07-05 18:48:42 --> Total execution time: 0.0810
INFO - 2021-07-05 15:48:46 --> Config Class Initialized
INFO - 2021-07-05 15:48:46 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:48:46 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:48:46 --> Utf8 Class Initialized
INFO - 2021-07-05 15:48:46 --> URI Class Initialized
INFO - 2021-07-05 15:48:46 --> Router Class Initialized
INFO - 2021-07-05 15:48:46 --> Output Class Initialized
INFO - 2021-07-05 15:48:46 --> Security Class Initialized
DEBUG - 2021-07-05 15:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:48:46 --> Input Class Initialized
INFO - 2021-07-05 15:48:46 --> Language Class Initialized
INFO - 2021-07-05 15:48:46 --> Loader Class Initialized
INFO - 2021-07-05 15:48:46 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:48:46 --> Helper loaded: url_helper
INFO - 2021-07-05 15:48:46 --> Helper loaded: file_helper
INFO - 2021-07-05 15:48:46 --> Helper loaded: form_helper
INFO - 2021-07-05 15:48:46 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:48:46 --> Helper loaded: security_helper
INFO - 2021-07-05 15:48:46 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:48:46 --> Helper loaded: language_helper
INFO - 2021-07-05 15:48:46 --> Helper loaded: general_helper
INFO - 2021-07-05 15:48:46 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:48:46 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:48:46 --> Parser Class Initialized
INFO - 2021-07-05 15:48:46 --> Form Validation Class Initialized
INFO - 2021-07-05 15:48:46 --> Upload Class Initialized
INFO - 2021-07-05 15:48:46 --> Email Class Initialized
INFO - 2021-07-05 15:48:46 --> MY_Model class loaded
INFO - 2021-07-05 15:48:46 --> Model "Users_model" initialized
INFO - 2021-07-05 15:48:46 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:48:46 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:48:46 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:48:46 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:48:46 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:48:46 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:48:46 --> Database Driver Class Initialized
INFO - 2021-07-05 15:48:46 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:48:46 --> Controller Class Initialized
ERROR - 2021-07-05 18:48:46 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 18:48:47 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 18:48:47 --> Final output sent to browser
DEBUG - 2021-07-05 18:48:47 --> Total execution time: 0.1538
INFO - 2021-07-05 15:48:54 --> Config Class Initialized
INFO - 2021-07-05 15:48:54 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:48:54 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:48:54 --> Utf8 Class Initialized
INFO - 2021-07-05 15:48:54 --> URI Class Initialized
INFO - 2021-07-05 15:48:54 --> Router Class Initialized
INFO - 2021-07-05 15:48:54 --> Output Class Initialized
INFO - 2021-07-05 15:48:54 --> Security Class Initialized
DEBUG - 2021-07-05 15:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:48:54 --> Input Class Initialized
INFO - 2021-07-05 15:48:54 --> Language Class Initialized
INFO - 2021-07-05 15:48:54 --> Loader Class Initialized
INFO - 2021-07-05 15:48:54 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:48:54 --> Helper loaded: url_helper
INFO - 2021-07-05 15:48:54 --> Helper loaded: file_helper
INFO - 2021-07-05 15:48:54 --> Helper loaded: form_helper
INFO - 2021-07-05 15:48:54 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:48:54 --> Helper loaded: security_helper
INFO - 2021-07-05 15:48:54 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:48:54 --> Helper loaded: language_helper
INFO - 2021-07-05 15:48:54 --> Helper loaded: general_helper
INFO - 2021-07-05 15:48:54 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:48:54 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:48:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:48:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:48:54 --> Parser Class Initialized
INFO - 2021-07-05 15:48:54 --> Form Validation Class Initialized
INFO - 2021-07-05 15:48:54 --> Upload Class Initialized
INFO - 2021-07-05 15:48:54 --> Email Class Initialized
INFO - 2021-07-05 15:48:54 --> MY_Model class loaded
INFO - 2021-07-05 15:48:54 --> Model "Users_model" initialized
INFO - 2021-07-05 15:48:54 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:48:54 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:48:54 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:48:54 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:48:54 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:48:54 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:48:54 --> Database Driver Class Initialized
INFO - 2021-07-05 15:48:54 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:48:54 --> Controller Class Initialized
ERROR - 2021-07-05 18:48:54 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 18:48:54 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 18:48:54 --> Final output sent to browser
DEBUG - 2021-07-05 18:48:54 --> Total execution time: 0.1266
INFO - 2021-07-05 15:48:56 --> Config Class Initialized
INFO - 2021-07-05 15:48:56 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:48:56 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:48:56 --> Utf8 Class Initialized
INFO - 2021-07-05 15:48:56 --> URI Class Initialized
INFO - 2021-07-05 15:48:56 --> Router Class Initialized
INFO - 2021-07-05 15:48:56 --> Output Class Initialized
INFO - 2021-07-05 15:48:56 --> Security Class Initialized
DEBUG - 2021-07-05 15:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:48:56 --> Input Class Initialized
INFO - 2021-07-05 15:48:56 --> Language Class Initialized
INFO - 2021-07-05 15:48:56 --> Loader Class Initialized
INFO - 2021-07-05 15:48:56 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:48:56 --> Helper loaded: url_helper
INFO - 2021-07-05 15:48:56 --> Helper loaded: file_helper
INFO - 2021-07-05 15:48:56 --> Helper loaded: form_helper
INFO - 2021-07-05 15:48:56 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:48:56 --> Helper loaded: security_helper
INFO - 2021-07-05 15:48:56 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:48:56 --> Helper loaded: language_helper
INFO - 2021-07-05 15:48:56 --> Helper loaded: general_helper
INFO - 2021-07-05 15:48:56 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:48:56 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:48:56 --> Parser Class Initialized
INFO - 2021-07-05 15:48:56 --> Form Validation Class Initialized
INFO - 2021-07-05 15:48:56 --> Upload Class Initialized
INFO - 2021-07-05 15:48:56 --> Email Class Initialized
INFO - 2021-07-05 15:48:56 --> MY_Model class loaded
INFO - 2021-07-05 15:48:56 --> Model "Users_model" initialized
INFO - 2021-07-05 15:48:56 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:48:56 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:48:56 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:48:56 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:48:56 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:48:56 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:48:56 --> Database Driver Class Initialized
INFO - 2021-07-05 15:48:56 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:48:56 --> Controller Class Initialized
ERROR - 2021-07-05 18:48:56 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-05 18:48:56 --> Invalid query: 
INFO - 2021-07-05 18:48:56 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-05 18:48:56 --> Final output sent to browser
DEBUG - 2021-07-05 18:48:56 --> Total execution time: 0.0627
INFO - 2021-07-05 15:49:33 --> Config Class Initialized
INFO - 2021-07-05 15:49:33 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:49:33 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:49:33 --> Utf8 Class Initialized
INFO - 2021-07-05 15:49:33 --> URI Class Initialized
INFO - 2021-07-05 15:49:33 --> Router Class Initialized
INFO - 2021-07-05 15:49:33 --> Output Class Initialized
INFO - 2021-07-05 15:49:33 --> Security Class Initialized
DEBUG - 2021-07-05 15:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:49:33 --> Input Class Initialized
INFO - 2021-07-05 15:49:33 --> Language Class Initialized
INFO - 2021-07-05 15:49:33 --> Loader Class Initialized
INFO - 2021-07-05 15:49:33 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:49:33 --> Helper loaded: url_helper
INFO - 2021-07-05 15:49:33 --> Helper loaded: file_helper
INFO - 2021-07-05 15:49:33 --> Helper loaded: form_helper
INFO - 2021-07-05 15:49:33 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:49:33 --> Helper loaded: security_helper
INFO - 2021-07-05 15:49:33 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:49:33 --> Helper loaded: language_helper
INFO - 2021-07-05 15:49:33 --> Helper loaded: general_helper
INFO - 2021-07-05 15:49:33 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:49:33 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:49:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:49:33 --> Parser Class Initialized
INFO - 2021-07-05 15:49:33 --> Form Validation Class Initialized
INFO - 2021-07-05 15:49:33 --> Upload Class Initialized
INFO - 2021-07-05 15:49:33 --> Email Class Initialized
INFO - 2021-07-05 15:49:33 --> MY_Model class loaded
INFO - 2021-07-05 15:49:33 --> Model "Users_model" initialized
INFO - 2021-07-05 15:49:33 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:49:33 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:49:33 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:49:33 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:49:33 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:49:33 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:49:33 --> Database Driver Class Initialized
INFO - 2021-07-05 15:49:33 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:49:33 --> Controller Class Initialized
ERROR - 2021-07-05 18:49:33 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-05 18:49:33 --> Invalid query: 
INFO - 2021-07-05 18:49:33 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-05 18:49:33 --> Final output sent to browser
DEBUG - 2021-07-05 18:49:33 --> Total execution time: 0.2095
INFO - 2021-07-05 15:50:18 --> Config Class Initialized
INFO - 2021-07-05 15:50:18 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:50:18 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:50:18 --> Utf8 Class Initialized
INFO - 2021-07-05 15:50:18 --> URI Class Initialized
INFO - 2021-07-05 15:50:18 --> Router Class Initialized
INFO - 2021-07-05 15:50:18 --> Output Class Initialized
INFO - 2021-07-05 15:50:18 --> Security Class Initialized
DEBUG - 2021-07-05 15:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:50:18 --> Input Class Initialized
INFO - 2021-07-05 15:50:18 --> Language Class Initialized
INFO - 2021-07-05 15:50:18 --> Loader Class Initialized
INFO - 2021-07-05 15:50:18 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:50:18 --> Helper loaded: url_helper
INFO - 2021-07-05 15:50:18 --> Helper loaded: file_helper
INFO - 2021-07-05 15:50:18 --> Helper loaded: form_helper
INFO - 2021-07-05 15:50:18 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:50:18 --> Helper loaded: security_helper
INFO - 2021-07-05 15:50:18 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:50:18 --> Helper loaded: language_helper
INFO - 2021-07-05 15:50:18 --> Helper loaded: general_helper
INFO - 2021-07-05 15:50:18 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:50:18 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:50:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:50:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:50:18 --> Parser Class Initialized
INFO - 2021-07-05 15:50:18 --> Form Validation Class Initialized
INFO - 2021-07-05 15:50:18 --> Upload Class Initialized
INFO - 2021-07-05 15:50:18 --> Email Class Initialized
INFO - 2021-07-05 15:50:18 --> MY_Model class loaded
INFO - 2021-07-05 15:50:18 --> Model "Users_model" initialized
INFO - 2021-07-05 15:50:18 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:50:18 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:50:18 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:50:18 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:50:18 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:50:18 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:50:18 --> Database Driver Class Initialized
INFO - 2021-07-05 15:50:18 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:50:18 --> Controller Class Initialized
ERROR - 2021-07-05 18:50:18 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-05 18:50:18 --> Invalid query: 
INFO - 2021-07-05 18:50:18 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-05 18:50:18 --> Final output sent to browser
DEBUG - 2021-07-05 18:50:18 --> Total execution time: 0.1211
INFO - 2021-07-05 15:50:20 --> Config Class Initialized
INFO - 2021-07-05 15:50:20 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:50:20 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:50:20 --> Utf8 Class Initialized
INFO - 2021-07-05 15:50:20 --> URI Class Initialized
INFO - 2021-07-05 15:50:20 --> Router Class Initialized
INFO - 2021-07-05 15:50:20 --> Output Class Initialized
INFO - 2021-07-05 15:50:20 --> Security Class Initialized
DEBUG - 2021-07-05 15:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:50:20 --> Input Class Initialized
INFO - 2021-07-05 15:50:20 --> Language Class Initialized
INFO - 2021-07-05 15:50:20 --> Loader Class Initialized
INFO - 2021-07-05 15:50:20 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:50:20 --> Helper loaded: url_helper
INFO - 2021-07-05 15:50:20 --> Helper loaded: file_helper
INFO - 2021-07-05 15:50:20 --> Helper loaded: form_helper
INFO - 2021-07-05 15:50:20 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:50:20 --> Helper loaded: security_helper
INFO - 2021-07-05 15:50:20 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:50:20 --> Helper loaded: language_helper
INFO - 2021-07-05 15:50:20 --> Helper loaded: general_helper
INFO - 2021-07-05 15:50:20 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:50:20 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:50:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:50:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:50:20 --> Parser Class Initialized
INFO - 2021-07-05 15:50:20 --> Form Validation Class Initialized
INFO - 2021-07-05 15:50:20 --> Upload Class Initialized
INFO - 2021-07-05 15:50:20 --> Email Class Initialized
INFO - 2021-07-05 15:50:20 --> MY_Model class loaded
INFO - 2021-07-05 15:50:20 --> Model "Users_model" initialized
INFO - 2021-07-05 15:50:20 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:50:20 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:50:20 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:50:20 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:50:20 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:50:20 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:50:20 --> Database Driver Class Initialized
INFO - 2021-07-05 15:50:20 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:50:20 --> Controller Class Initialized
ERROR - 2021-07-05 18:50:20 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-05 18:50:20 --> Invalid query: 
INFO - 2021-07-05 18:50:20 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-05 18:50:20 --> Final output sent to browser
DEBUG - 2021-07-05 18:50:20 --> Total execution time: 0.0926
INFO - 2021-07-05 15:50:23 --> Config Class Initialized
INFO - 2021-07-05 15:50:23 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:50:23 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:50:23 --> Utf8 Class Initialized
INFO - 2021-07-05 15:50:23 --> URI Class Initialized
INFO - 2021-07-05 15:50:23 --> Router Class Initialized
INFO - 2021-07-05 15:50:23 --> Output Class Initialized
INFO - 2021-07-05 15:50:23 --> Security Class Initialized
DEBUG - 2021-07-05 15:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:50:23 --> Input Class Initialized
INFO - 2021-07-05 15:50:23 --> Language Class Initialized
INFO - 2021-07-05 15:50:23 --> Loader Class Initialized
INFO - 2021-07-05 15:50:23 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:50:23 --> Helper loaded: url_helper
INFO - 2021-07-05 15:50:23 --> Helper loaded: file_helper
INFO - 2021-07-05 15:50:23 --> Helper loaded: form_helper
INFO - 2021-07-05 15:50:23 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:50:23 --> Helper loaded: security_helper
INFO - 2021-07-05 15:50:23 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:50:23 --> Helper loaded: language_helper
INFO - 2021-07-05 15:50:23 --> Helper loaded: general_helper
INFO - 2021-07-05 15:50:23 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:50:23 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:50:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:50:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:50:23 --> Parser Class Initialized
INFO - 2021-07-05 15:50:23 --> Form Validation Class Initialized
INFO - 2021-07-05 15:50:23 --> Upload Class Initialized
INFO - 2021-07-05 15:50:23 --> Email Class Initialized
INFO - 2021-07-05 15:50:23 --> MY_Model class loaded
INFO - 2021-07-05 15:50:23 --> Model "Users_model" initialized
INFO - 2021-07-05 15:50:23 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:50:23 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:50:23 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:50:23 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:50:23 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:50:23 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:50:23 --> Database Driver Class Initialized
INFO - 2021-07-05 15:50:23 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:50:23 --> Controller Class Initialized
ERROR - 2021-07-05 18:50:23 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-05 18:50:23 --> Invalid query: 
INFO - 2021-07-05 18:50:23 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-05 18:50:23 --> Final output sent to browser
DEBUG - 2021-07-05 18:50:23 --> Total execution time: 0.1256
INFO - 2021-07-05 15:50:39 --> Config Class Initialized
INFO - 2021-07-05 15:50:39 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:50:39 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:50:39 --> Utf8 Class Initialized
INFO - 2021-07-05 15:50:39 --> URI Class Initialized
INFO - 2021-07-05 15:50:39 --> Router Class Initialized
INFO - 2021-07-05 15:50:39 --> Output Class Initialized
INFO - 2021-07-05 15:50:39 --> Security Class Initialized
DEBUG - 2021-07-05 15:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:50:39 --> Input Class Initialized
INFO - 2021-07-05 15:50:39 --> Language Class Initialized
INFO - 2021-07-05 15:50:39 --> Loader Class Initialized
INFO - 2021-07-05 15:50:39 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:50:39 --> Helper loaded: url_helper
INFO - 2021-07-05 15:50:39 --> Helper loaded: file_helper
INFO - 2021-07-05 15:50:39 --> Helper loaded: form_helper
INFO - 2021-07-05 15:50:39 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:50:39 --> Helper loaded: security_helper
INFO - 2021-07-05 15:50:39 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:50:39 --> Helper loaded: language_helper
INFO - 2021-07-05 15:50:39 --> Helper loaded: general_helper
INFO - 2021-07-05 15:50:39 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:50:39 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:50:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:50:39 --> Parser Class Initialized
INFO - 2021-07-05 15:50:39 --> Form Validation Class Initialized
INFO - 2021-07-05 15:50:39 --> Upload Class Initialized
INFO - 2021-07-05 15:50:39 --> Email Class Initialized
INFO - 2021-07-05 15:50:40 --> MY_Model class loaded
INFO - 2021-07-05 15:50:40 --> Model "Users_model" initialized
INFO - 2021-07-05 15:50:40 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:50:40 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:50:40 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:50:40 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:50:40 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:50:40 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:50:40 --> Database Driver Class Initialized
INFO - 2021-07-05 15:50:40 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:50:40 --> Controller Class Initialized
ERROR - 2021-07-05 18:50:40 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-05 18:50:40 --> Invalid query: 
INFO - 2021-07-05 18:50:40 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-05 18:50:40 --> Final output sent to browser
DEBUG - 2021-07-05 18:50:40 --> Total execution time: 0.1658
INFO - 2021-07-05 15:51:31 --> Config Class Initialized
INFO - 2021-07-05 15:51:31 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:51:31 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:51:31 --> Utf8 Class Initialized
INFO - 2021-07-05 15:51:31 --> URI Class Initialized
INFO - 2021-07-05 15:51:31 --> Router Class Initialized
INFO - 2021-07-05 15:51:31 --> Output Class Initialized
INFO - 2021-07-05 15:51:31 --> Security Class Initialized
DEBUG - 2021-07-05 15:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:51:31 --> Input Class Initialized
INFO - 2021-07-05 15:51:31 --> Language Class Initialized
INFO - 2021-07-05 15:51:31 --> Loader Class Initialized
INFO - 2021-07-05 15:51:31 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:51:31 --> Helper loaded: url_helper
INFO - 2021-07-05 15:51:31 --> Helper loaded: file_helper
INFO - 2021-07-05 15:51:31 --> Helper loaded: form_helper
INFO - 2021-07-05 15:51:31 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:51:31 --> Helper loaded: security_helper
INFO - 2021-07-05 15:51:31 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:51:31 --> Helper loaded: language_helper
INFO - 2021-07-05 15:51:31 --> Helper loaded: general_helper
INFO - 2021-07-05 15:51:31 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:51:31 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:51:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:51:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:51:31 --> Parser Class Initialized
INFO - 2021-07-05 15:51:31 --> Form Validation Class Initialized
INFO - 2021-07-05 15:51:31 --> Upload Class Initialized
INFO - 2021-07-05 15:51:31 --> Email Class Initialized
INFO - 2021-07-05 15:51:31 --> MY_Model class loaded
INFO - 2021-07-05 15:51:31 --> Model "Users_model" initialized
INFO - 2021-07-05 15:51:31 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:51:31 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:51:31 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:51:31 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:51:31 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:51:31 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:51:31 --> Database Driver Class Initialized
INFO - 2021-07-05 15:51:31 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:51:31 --> Controller Class Initialized
ERROR - 2021-07-05 18:51:31 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-05 18:51:31 --> Invalid query: 
INFO - 2021-07-05 18:51:31 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-05 18:51:31 --> Final output sent to browser
DEBUG - 2021-07-05 18:51:31 --> Total execution time: 0.1376
INFO - 2021-07-05 15:52:24 --> Config Class Initialized
INFO - 2021-07-05 15:52:24 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:52:24 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:52:24 --> Utf8 Class Initialized
INFO - 2021-07-05 15:52:24 --> URI Class Initialized
INFO - 2021-07-05 15:52:24 --> Router Class Initialized
INFO - 2021-07-05 15:52:24 --> Output Class Initialized
INFO - 2021-07-05 15:52:24 --> Security Class Initialized
DEBUG - 2021-07-05 15:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:52:24 --> Input Class Initialized
INFO - 2021-07-05 15:52:24 --> Language Class Initialized
INFO - 2021-07-05 15:52:24 --> Loader Class Initialized
INFO - 2021-07-05 15:52:24 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:52:24 --> Helper loaded: url_helper
INFO - 2021-07-05 15:52:24 --> Helper loaded: file_helper
INFO - 2021-07-05 15:52:24 --> Helper loaded: form_helper
INFO - 2021-07-05 15:52:24 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:52:24 --> Helper loaded: security_helper
INFO - 2021-07-05 15:52:24 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:52:24 --> Helper loaded: language_helper
INFO - 2021-07-05 15:52:24 --> Helper loaded: general_helper
INFO - 2021-07-05 15:52:24 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:52:24 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:52:24 --> Parser Class Initialized
INFO - 2021-07-05 15:52:24 --> Form Validation Class Initialized
INFO - 2021-07-05 15:52:24 --> Upload Class Initialized
INFO - 2021-07-05 15:52:24 --> Email Class Initialized
INFO - 2021-07-05 15:52:24 --> MY_Model class loaded
INFO - 2021-07-05 15:52:24 --> Model "Users_model" initialized
INFO - 2021-07-05 15:52:24 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:52:24 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:52:24 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:52:24 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:52:24 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:52:24 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:52:24 --> Database Driver Class Initialized
INFO - 2021-07-05 15:52:25 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:52:25 --> Controller Class Initialized
ERROR - 2021-07-05 18:52:25 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 18:52:25 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-05 18:52:25 --> Final output sent to browser
DEBUG - 2021-07-05 18:52:25 --> Total execution time: 0.2281
INFO - 2021-07-05 15:52:25 --> Config Class Initialized
INFO - 2021-07-05 15:52:25 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:52:25 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:52:25 --> Utf8 Class Initialized
INFO - 2021-07-05 15:52:25 --> URI Class Initialized
INFO - 2021-07-05 15:52:25 --> Router Class Initialized
INFO - 2021-07-05 15:52:25 --> Output Class Initialized
INFO - 2021-07-05 15:52:25 --> Security Class Initialized
DEBUG - 2021-07-05 15:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:52:25 --> Input Class Initialized
INFO - 2021-07-05 15:52:25 --> Language Class Initialized
INFO - 2021-07-05 15:52:25 --> Loader Class Initialized
INFO - 2021-07-05 15:52:25 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:52:25 --> Helper loaded: url_helper
INFO - 2021-07-05 15:52:25 --> Helper loaded: file_helper
INFO - 2021-07-05 15:52:25 --> Helper loaded: form_helper
INFO - 2021-07-05 15:52:25 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:52:25 --> Helper loaded: security_helper
INFO - 2021-07-05 15:52:25 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:52:25 --> Helper loaded: language_helper
INFO - 2021-07-05 15:52:25 --> Helper loaded: general_helper
INFO - 2021-07-05 15:52:25 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:52:25 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:52:25 --> Parser Class Initialized
INFO - 2021-07-05 15:52:25 --> Form Validation Class Initialized
INFO - 2021-07-05 15:52:25 --> Upload Class Initialized
INFO - 2021-07-05 15:52:25 --> Email Class Initialized
INFO - 2021-07-05 15:52:25 --> MY_Model class loaded
INFO - 2021-07-05 15:52:25 --> Model "Users_model" initialized
INFO - 2021-07-05 15:52:25 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:52:25 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:52:25 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:52:25 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:52:25 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:52:25 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:52:25 --> Database Driver Class Initialized
INFO - 2021-07-05 15:52:25 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:52:25 --> Controller Class Initialized
ERROR - 2021-07-05 18:52:25 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 18:52:25 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-05 18:52:25 --> Final output sent to browser
DEBUG - 2021-07-05 18:52:25 --> Total execution time: 0.1918
INFO - 2021-07-05 15:52:28 --> Config Class Initialized
INFO - 2021-07-05 15:52:28 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:52:28 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:52:28 --> Utf8 Class Initialized
INFO - 2021-07-05 15:52:28 --> URI Class Initialized
INFO - 2021-07-05 15:52:28 --> Router Class Initialized
INFO - 2021-07-05 15:52:28 --> Output Class Initialized
INFO - 2021-07-05 15:52:28 --> Security Class Initialized
DEBUG - 2021-07-05 15:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:52:28 --> Input Class Initialized
INFO - 2021-07-05 15:52:28 --> Language Class Initialized
INFO - 2021-07-05 15:52:28 --> Loader Class Initialized
INFO - 2021-07-05 15:52:28 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:52:28 --> Helper loaded: url_helper
INFO - 2021-07-05 15:52:28 --> Helper loaded: file_helper
INFO - 2021-07-05 15:52:28 --> Helper loaded: form_helper
INFO - 2021-07-05 15:52:28 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:52:28 --> Helper loaded: security_helper
INFO - 2021-07-05 15:52:28 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:52:28 --> Helper loaded: language_helper
INFO - 2021-07-05 15:52:28 --> Helper loaded: general_helper
INFO - 2021-07-05 15:52:28 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:52:28 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:52:28 --> Parser Class Initialized
INFO - 2021-07-05 15:52:28 --> Form Validation Class Initialized
INFO - 2021-07-05 15:52:28 --> Upload Class Initialized
INFO - 2021-07-05 15:52:28 --> Email Class Initialized
INFO - 2021-07-05 15:52:28 --> MY_Model class loaded
INFO - 2021-07-05 15:52:28 --> Model "Users_model" initialized
INFO - 2021-07-05 15:52:28 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:52:28 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:52:28 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:52:28 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:52:28 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:52:28 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:52:28 --> Database Driver Class Initialized
INFO - 2021-07-05 15:52:28 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:52:28 --> Controller Class Initialized
ERROR - 2021-07-05 18:52:28 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 18:52:28 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-05 18:52:28 --> Final output sent to browser
DEBUG - 2021-07-05 18:52:28 --> Total execution time: 0.0671
INFO - 2021-07-05 15:52:31 --> Config Class Initialized
INFO - 2021-07-05 15:52:31 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:52:31 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:52:31 --> Utf8 Class Initialized
INFO - 2021-07-05 15:52:31 --> URI Class Initialized
INFO - 2021-07-05 15:52:31 --> Router Class Initialized
INFO - 2021-07-05 15:52:31 --> Output Class Initialized
INFO - 2021-07-05 15:52:31 --> Security Class Initialized
DEBUG - 2021-07-05 15:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:52:31 --> Input Class Initialized
INFO - 2021-07-05 15:52:31 --> Language Class Initialized
INFO - 2021-07-05 15:52:31 --> Loader Class Initialized
INFO - 2021-07-05 15:52:31 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:52:31 --> Helper loaded: url_helper
INFO - 2021-07-05 15:52:31 --> Helper loaded: file_helper
INFO - 2021-07-05 15:52:31 --> Helper loaded: form_helper
INFO - 2021-07-05 15:52:31 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:52:31 --> Helper loaded: security_helper
INFO - 2021-07-05 15:52:31 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:52:31 --> Helper loaded: language_helper
INFO - 2021-07-05 15:52:31 --> Helper loaded: general_helper
INFO - 2021-07-05 15:52:31 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:52:31 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:52:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:52:31 --> Parser Class Initialized
INFO - 2021-07-05 15:52:31 --> Form Validation Class Initialized
INFO - 2021-07-05 15:52:31 --> Upload Class Initialized
INFO - 2021-07-05 15:52:31 --> Email Class Initialized
INFO - 2021-07-05 15:52:31 --> MY_Model class loaded
INFO - 2021-07-05 15:52:31 --> Model "Users_model" initialized
INFO - 2021-07-05 15:52:31 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:52:31 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:52:31 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:52:31 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:52:31 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:52:31 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:52:31 --> Database Driver Class Initialized
INFO - 2021-07-05 15:52:31 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:52:31 --> Controller Class Initialized
ERROR - 2021-07-05 18:52:31 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 18:52:31 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-05 18:52:31 --> Final output sent to browser
DEBUG - 2021-07-05 18:52:31 --> Total execution time: 0.2799
INFO - 2021-07-05 15:52:33 --> Config Class Initialized
INFO - 2021-07-05 15:52:33 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:52:33 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:52:33 --> Utf8 Class Initialized
INFO - 2021-07-05 15:52:33 --> URI Class Initialized
INFO - 2021-07-05 15:52:33 --> Router Class Initialized
INFO - 2021-07-05 15:52:33 --> Output Class Initialized
INFO - 2021-07-05 15:52:33 --> Security Class Initialized
DEBUG - 2021-07-05 15:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:52:33 --> Input Class Initialized
INFO - 2021-07-05 15:52:33 --> Language Class Initialized
INFO - 2021-07-05 15:52:33 --> Loader Class Initialized
INFO - 2021-07-05 15:52:33 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:52:33 --> Helper loaded: url_helper
INFO - 2021-07-05 15:52:33 --> Helper loaded: file_helper
INFO - 2021-07-05 15:52:33 --> Helper loaded: form_helper
INFO - 2021-07-05 15:52:33 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:52:33 --> Helper loaded: security_helper
INFO - 2021-07-05 15:52:33 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:52:33 --> Helper loaded: language_helper
INFO - 2021-07-05 15:52:33 --> Helper loaded: general_helper
INFO - 2021-07-05 15:52:33 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:52:33 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:52:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:52:33 --> Parser Class Initialized
INFO - 2021-07-05 15:52:33 --> Form Validation Class Initialized
INFO - 2021-07-05 15:52:33 --> Upload Class Initialized
INFO - 2021-07-05 15:52:33 --> Email Class Initialized
INFO - 2021-07-05 15:52:33 --> MY_Model class loaded
INFO - 2021-07-05 15:52:33 --> Model "Users_model" initialized
INFO - 2021-07-05 15:52:33 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:52:33 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:52:33 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:52:33 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:52:33 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:52:33 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:52:33 --> Database Driver Class Initialized
INFO - 2021-07-05 15:52:33 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:52:33 --> Controller Class Initialized
ERROR - 2021-07-05 18:52:33 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-05 18:52:33 --> Invalid query: 
INFO - 2021-07-05 18:52:33 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-05 18:52:33 --> Final output sent to browser
DEBUG - 2021-07-05 18:52:33 --> Total execution time: 0.0692
INFO - 2021-07-05 15:52:40 --> Config Class Initialized
INFO - 2021-07-05 15:52:40 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:52:40 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:52:40 --> Utf8 Class Initialized
INFO - 2021-07-05 15:52:40 --> URI Class Initialized
INFO - 2021-07-05 15:52:40 --> Router Class Initialized
INFO - 2021-07-05 15:52:40 --> Output Class Initialized
INFO - 2021-07-05 15:52:40 --> Security Class Initialized
DEBUG - 2021-07-05 15:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:52:40 --> Input Class Initialized
INFO - 2021-07-05 15:52:40 --> Language Class Initialized
INFO - 2021-07-05 15:52:40 --> Loader Class Initialized
INFO - 2021-07-05 15:52:40 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:52:40 --> Helper loaded: url_helper
INFO - 2021-07-05 15:52:40 --> Helper loaded: file_helper
INFO - 2021-07-05 15:52:40 --> Helper loaded: form_helper
INFO - 2021-07-05 15:52:40 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:52:40 --> Helper loaded: security_helper
INFO - 2021-07-05 15:52:40 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:52:40 --> Helper loaded: language_helper
INFO - 2021-07-05 15:52:40 --> Helper loaded: general_helper
INFO - 2021-07-05 15:52:40 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:52:40 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:52:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:52:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:52:40 --> Parser Class Initialized
INFO - 2021-07-05 15:52:40 --> Form Validation Class Initialized
INFO - 2021-07-05 15:52:40 --> Upload Class Initialized
INFO - 2021-07-05 15:52:40 --> Email Class Initialized
INFO - 2021-07-05 15:52:40 --> MY_Model class loaded
INFO - 2021-07-05 15:52:40 --> Model "Users_model" initialized
INFO - 2021-07-05 15:52:40 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:52:40 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:52:40 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:52:40 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:52:40 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:52:40 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:52:40 --> Database Driver Class Initialized
INFO - 2021-07-05 15:52:40 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:52:40 --> Controller Class Initialized
ERROR - 2021-07-05 18:52:40 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-05 18:52:40 --> Invalid query: 
INFO - 2021-07-05 18:52:40 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-05 18:52:40 --> Final output sent to browser
DEBUG - 2021-07-05 18:52:40 --> Total execution time: 0.1440
INFO - 2021-07-05 15:52:43 --> Config Class Initialized
INFO - 2021-07-05 15:52:43 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:52:43 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:52:43 --> Utf8 Class Initialized
INFO - 2021-07-05 15:52:43 --> URI Class Initialized
INFO - 2021-07-05 15:52:43 --> Router Class Initialized
INFO - 2021-07-05 15:52:43 --> Output Class Initialized
INFO - 2021-07-05 15:52:43 --> Security Class Initialized
DEBUG - 2021-07-05 15:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:52:43 --> Input Class Initialized
INFO - 2021-07-05 15:52:43 --> Language Class Initialized
INFO - 2021-07-05 15:52:43 --> Loader Class Initialized
INFO - 2021-07-05 15:52:43 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:52:43 --> Helper loaded: url_helper
INFO - 2021-07-05 15:52:43 --> Helper loaded: file_helper
INFO - 2021-07-05 15:52:43 --> Helper loaded: form_helper
INFO - 2021-07-05 15:52:43 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:52:43 --> Helper loaded: security_helper
INFO - 2021-07-05 15:52:43 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:52:43 --> Helper loaded: language_helper
INFO - 2021-07-05 15:52:43 --> Helper loaded: general_helper
INFO - 2021-07-05 15:52:43 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:52:43 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:52:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:52:43 --> Parser Class Initialized
INFO - 2021-07-05 15:52:43 --> Form Validation Class Initialized
INFO - 2021-07-05 15:52:43 --> Upload Class Initialized
INFO - 2021-07-05 15:52:43 --> Email Class Initialized
INFO - 2021-07-05 15:52:43 --> MY_Model class loaded
INFO - 2021-07-05 15:52:43 --> Model "Users_model" initialized
INFO - 2021-07-05 15:52:43 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:52:43 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:52:43 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:52:43 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:52:43 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:52:43 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:52:43 --> Database Driver Class Initialized
INFO - 2021-07-05 15:52:43 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:52:43 --> Controller Class Initialized
ERROR - 2021-07-05 18:52:43 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-05 18:52:43 --> Invalid query: 
INFO - 2021-07-05 18:52:43 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-05 18:52:43 --> Final output sent to browser
DEBUG - 2021-07-05 18:52:43 --> Total execution time: 0.0619
INFO - 2021-07-05 15:52:53 --> Config Class Initialized
INFO - 2021-07-05 15:52:53 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:52:53 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:52:53 --> Utf8 Class Initialized
INFO - 2021-07-05 15:52:53 --> URI Class Initialized
INFO - 2021-07-05 15:52:53 --> Router Class Initialized
INFO - 2021-07-05 15:52:53 --> Output Class Initialized
INFO - 2021-07-05 15:52:53 --> Security Class Initialized
DEBUG - 2021-07-05 15:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:52:53 --> Input Class Initialized
INFO - 2021-07-05 15:52:53 --> Language Class Initialized
INFO - 2021-07-05 15:52:53 --> Loader Class Initialized
INFO - 2021-07-05 15:52:53 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:52:53 --> Helper loaded: url_helper
INFO - 2021-07-05 15:52:53 --> Helper loaded: file_helper
INFO - 2021-07-05 15:52:53 --> Helper loaded: form_helper
INFO - 2021-07-05 15:52:53 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:52:53 --> Helper loaded: security_helper
INFO - 2021-07-05 15:52:53 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:52:53 --> Helper loaded: language_helper
INFO - 2021-07-05 15:52:53 --> Helper loaded: general_helper
INFO - 2021-07-05 15:52:53 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:52:53 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:52:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:52:53 --> Parser Class Initialized
INFO - 2021-07-05 15:52:53 --> Form Validation Class Initialized
INFO - 2021-07-05 15:52:53 --> Upload Class Initialized
INFO - 2021-07-05 15:52:53 --> Email Class Initialized
INFO - 2021-07-05 15:52:53 --> MY_Model class loaded
INFO - 2021-07-05 15:52:53 --> Model "Users_model" initialized
INFO - 2021-07-05 15:52:53 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:52:53 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:52:53 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:52:53 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:52:53 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:52:53 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:52:53 --> Database Driver Class Initialized
INFO - 2021-07-05 15:52:53 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:52:53 --> Controller Class Initialized
ERROR - 2021-07-05 18:52:53 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-05 18:52:53 --> Invalid query: 
INFO - 2021-07-05 18:52:53 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-05 18:52:53 --> Final output sent to browser
DEBUG - 2021-07-05 18:52:53 --> Total execution time: 0.1209
INFO - 2021-07-05 15:52:57 --> Config Class Initialized
INFO - 2021-07-05 15:52:57 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:52:57 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:52:57 --> Utf8 Class Initialized
INFO - 2021-07-05 15:52:57 --> URI Class Initialized
INFO - 2021-07-05 15:52:57 --> Router Class Initialized
INFO - 2021-07-05 15:52:57 --> Output Class Initialized
INFO - 2021-07-05 15:52:57 --> Security Class Initialized
DEBUG - 2021-07-05 15:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:52:57 --> Input Class Initialized
INFO - 2021-07-05 15:52:57 --> Language Class Initialized
INFO - 2021-07-05 15:52:57 --> Loader Class Initialized
INFO - 2021-07-05 15:52:57 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:52:57 --> Helper loaded: url_helper
INFO - 2021-07-05 15:52:57 --> Helper loaded: file_helper
INFO - 2021-07-05 15:52:57 --> Helper loaded: form_helper
INFO - 2021-07-05 15:52:57 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:52:57 --> Helper loaded: security_helper
INFO - 2021-07-05 15:52:57 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:52:57 --> Helper loaded: language_helper
INFO - 2021-07-05 15:52:57 --> Helper loaded: general_helper
INFO - 2021-07-05 15:52:57 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:52:57 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:52:57 --> Parser Class Initialized
INFO - 2021-07-05 15:52:57 --> Form Validation Class Initialized
INFO - 2021-07-05 15:52:57 --> Upload Class Initialized
INFO - 2021-07-05 15:52:57 --> Email Class Initialized
INFO - 2021-07-05 15:52:57 --> MY_Model class loaded
INFO - 2021-07-05 15:52:57 --> Model "Users_model" initialized
INFO - 2021-07-05 15:52:57 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:52:57 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:52:57 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:52:57 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:52:57 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:52:57 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:52:57 --> Database Driver Class Initialized
INFO - 2021-07-05 15:52:57 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:52:57 --> Controller Class Initialized
ERROR - 2021-07-05 18:52:57 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-05 18:52:57 --> Invalid query: 
INFO - 2021-07-05 18:52:57 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-05 18:52:57 --> Final output sent to browser
DEBUG - 2021-07-05 18:52:57 --> Total execution time: 0.0801
INFO - 2021-07-05 15:52:59 --> Config Class Initialized
INFO - 2021-07-05 15:52:59 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:52:59 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:52:59 --> Utf8 Class Initialized
INFO - 2021-07-05 15:52:59 --> URI Class Initialized
INFO - 2021-07-05 15:52:59 --> Router Class Initialized
INFO - 2021-07-05 15:52:59 --> Output Class Initialized
INFO - 2021-07-05 15:52:59 --> Security Class Initialized
DEBUG - 2021-07-05 15:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:52:59 --> Input Class Initialized
INFO - 2021-07-05 15:52:59 --> Language Class Initialized
INFO - 2021-07-05 15:52:59 --> Loader Class Initialized
INFO - 2021-07-05 15:52:59 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:52:59 --> Helper loaded: url_helper
INFO - 2021-07-05 15:52:59 --> Helper loaded: file_helper
INFO - 2021-07-05 15:52:59 --> Helper loaded: form_helper
INFO - 2021-07-05 15:52:59 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:52:59 --> Helper loaded: security_helper
INFO - 2021-07-05 15:52:59 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:52:59 --> Helper loaded: language_helper
INFO - 2021-07-05 15:52:59 --> Helper loaded: general_helper
INFO - 2021-07-05 15:52:59 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:52:59 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:52:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:52:59 --> Parser Class Initialized
INFO - 2021-07-05 15:52:59 --> Form Validation Class Initialized
INFO - 2021-07-05 15:52:59 --> Upload Class Initialized
INFO - 2021-07-05 15:52:59 --> Email Class Initialized
INFO - 2021-07-05 15:52:59 --> MY_Model class loaded
INFO - 2021-07-05 15:52:59 --> Model "Users_model" initialized
INFO - 2021-07-05 15:52:59 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:52:59 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:52:59 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:52:59 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:52:59 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:52:59 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:52:59 --> Database Driver Class Initialized
INFO - 2021-07-05 15:52:59 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:52:59 --> Controller Class Initialized
ERROR - 2021-07-05 18:52:59 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-05 18:52:59 --> Invalid query: 
INFO - 2021-07-05 18:52:59 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-05 18:52:59 --> Final output sent to browser
DEBUG - 2021-07-05 18:52:59 --> Total execution time: 0.1258
INFO - 2021-07-05 15:53:05 --> Config Class Initialized
INFO - 2021-07-05 15:53:05 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:53:05 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:53:05 --> Utf8 Class Initialized
INFO - 2021-07-05 15:53:05 --> URI Class Initialized
INFO - 2021-07-05 15:53:05 --> Router Class Initialized
INFO - 2021-07-05 15:53:05 --> Output Class Initialized
INFO - 2021-07-05 15:53:05 --> Security Class Initialized
DEBUG - 2021-07-05 15:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:53:05 --> Input Class Initialized
INFO - 2021-07-05 15:53:05 --> Language Class Initialized
INFO - 2021-07-05 15:53:05 --> Loader Class Initialized
INFO - 2021-07-05 15:53:05 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:53:05 --> Helper loaded: url_helper
INFO - 2021-07-05 15:53:05 --> Helper loaded: file_helper
INFO - 2021-07-05 15:53:05 --> Helper loaded: form_helper
INFO - 2021-07-05 15:53:05 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:53:05 --> Helper loaded: security_helper
INFO - 2021-07-05 15:53:05 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:53:05 --> Helper loaded: language_helper
INFO - 2021-07-05 15:53:05 --> Helper loaded: general_helper
INFO - 2021-07-05 15:53:05 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:53:05 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:53:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:53:05 --> Parser Class Initialized
INFO - 2021-07-05 15:53:05 --> Form Validation Class Initialized
INFO - 2021-07-05 15:53:05 --> Upload Class Initialized
INFO - 2021-07-05 15:53:05 --> Email Class Initialized
INFO - 2021-07-05 15:53:05 --> MY_Model class loaded
INFO - 2021-07-05 15:53:05 --> Model "Users_model" initialized
INFO - 2021-07-05 15:53:05 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:53:05 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:53:05 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:53:05 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:53:05 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:53:05 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:53:05 --> Database Driver Class Initialized
INFO - 2021-07-05 15:53:05 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:53:05 --> Controller Class Initialized
ERROR - 2021-07-05 18:53:05 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-05 18:53:05 --> Invalid query: 
INFO - 2021-07-05 18:53:05 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-05 18:53:05 --> Final output sent to browser
DEBUG - 2021-07-05 18:53:05 --> Total execution time: 0.1267
INFO - 2021-07-05 15:53:11 --> Config Class Initialized
INFO - 2021-07-05 15:53:11 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:53:11 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:53:11 --> Utf8 Class Initialized
INFO - 2021-07-05 15:53:11 --> URI Class Initialized
INFO - 2021-07-05 15:53:11 --> Router Class Initialized
INFO - 2021-07-05 15:53:11 --> Output Class Initialized
INFO - 2021-07-05 15:53:11 --> Security Class Initialized
DEBUG - 2021-07-05 15:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:53:11 --> Input Class Initialized
INFO - 2021-07-05 15:53:11 --> Language Class Initialized
INFO - 2021-07-05 15:53:11 --> Loader Class Initialized
INFO - 2021-07-05 15:53:11 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:53:11 --> Helper loaded: url_helper
INFO - 2021-07-05 15:53:11 --> Helper loaded: file_helper
INFO - 2021-07-05 15:53:11 --> Helper loaded: form_helper
INFO - 2021-07-05 15:53:11 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:53:11 --> Helper loaded: security_helper
INFO - 2021-07-05 15:53:11 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:53:11 --> Helper loaded: language_helper
INFO - 2021-07-05 15:53:11 --> Helper loaded: general_helper
INFO - 2021-07-05 15:53:11 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:53:11 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:53:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:53:11 --> Parser Class Initialized
INFO - 2021-07-05 15:53:11 --> Form Validation Class Initialized
INFO - 2021-07-05 15:53:11 --> Upload Class Initialized
INFO - 2021-07-05 15:53:11 --> Email Class Initialized
INFO - 2021-07-05 15:53:11 --> MY_Model class loaded
INFO - 2021-07-05 15:53:11 --> Model "Users_model" initialized
INFO - 2021-07-05 15:53:11 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:53:11 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:53:11 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:53:11 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:53:11 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:53:11 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:53:11 --> Database Driver Class Initialized
INFO - 2021-07-05 15:53:11 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:53:11 --> Controller Class Initialized
ERROR - 2021-07-05 18:53:11 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-05 18:53:11 --> Invalid query: 
INFO - 2021-07-05 18:53:11 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-05 18:53:11 --> Final output sent to browser
DEBUG - 2021-07-05 18:53:11 --> Total execution time: 0.1243
INFO - 2021-07-05 15:53:18 --> Config Class Initialized
INFO - 2021-07-05 15:53:18 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:53:18 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:53:18 --> Utf8 Class Initialized
INFO - 2021-07-05 15:53:18 --> URI Class Initialized
INFO - 2021-07-05 15:53:18 --> Router Class Initialized
INFO - 2021-07-05 15:53:18 --> Output Class Initialized
INFO - 2021-07-05 15:53:18 --> Security Class Initialized
DEBUG - 2021-07-05 15:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:53:18 --> Input Class Initialized
INFO - 2021-07-05 15:53:18 --> Language Class Initialized
INFO - 2021-07-05 15:53:18 --> Loader Class Initialized
INFO - 2021-07-05 15:53:18 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:53:18 --> Helper loaded: url_helper
INFO - 2021-07-05 15:53:18 --> Helper loaded: file_helper
INFO - 2021-07-05 15:53:18 --> Helper loaded: form_helper
INFO - 2021-07-05 15:53:18 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:53:18 --> Helper loaded: security_helper
INFO - 2021-07-05 15:53:18 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:53:18 --> Helper loaded: language_helper
INFO - 2021-07-05 15:53:18 --> Helper loaded: general_helper
INFO - 2021-07-05 15:53:18 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:53:18 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:53:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:53:18 --> Parser Class Initialized
INFO - 2021-07-05 15:53:18 --> Form Validation Class Initialized
INFO - 2021-07-05 15:53:18 --> Upload Class Initialized
INFO - 2021-07-05 15:53:18 --> Email Class Initialized
INFO - 2021-07-05 15:53:18 --> MY_Model class loaded
INFO - 2021-07-05 15:53:18 --> Model "Users_model" initialized
INFO - 2021-07-05 15:53:18 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:53:18 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:53:18 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:53:18 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:53:18 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:53:18 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:53:18 --> Database Driver Class Initialized
INFO - 2021-07-05 15:53:18 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:53:18 --> Controller Class Initialized
ERROR - 2021-07-05 18:53:18 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-05 18:53:18 --> Invalid query: 
INFO - 2021-07-05 18:53:18 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-05 18:53:18 --> Final output sent to browser
DEBUG - 2021-07-05 18:53:18 --> Total execution time: 0.1212
INFO - 2021-07-05 15:55:57 --> Config Class Initialized
INFO - 2021-07-05 15:55:57 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:55:57 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:55:57 --> Utf8 Class Initialized
INFO - 2021-07-05 15:55:57 --> URI Class Initialized
INFO - 2021-07-05 15:55:57 --> Router Class Initialized
INFO - 2021-07-05 15:55:57 --> Output Class Initialized
INFO - 2021-07-05 15:55:57 --> Security Class Initialized
DEBUG - 2021-07-05 15:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:55:57 --> Input Class Initialized
INFO - 2021-07-05 15:55:57 --> Language Class Initialized
INFO - 2021-07-05 15:55:57 --> Loader Class Initialized
INFO - 2021-07-05 15:55:57 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:55:57 --> Helper loaded: url_helper
INFO - 2021-07-05 15:55:57 --> Helper loaded: file_helper
INFO - 2021-07-05 15:55:57 --> Helper loaded: form_helper
INFO - 2021-07-05 15:55:57 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:55:57 --> Helper loaded: security_helper
INFO - 2021-07-05 15:55:57 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:55:57 --> Helper loaded: language_helper
INFO - 2021-07-05 15:55:57 --> Helper loaded: general_helper
INFO - 2021-07-05 15:55:57 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:55:57 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:55:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:55:57 --> Parser Class Initialized
INFO - 2021-07-05 15:55:57 --> Form Validation Class Initialized
INFO - 2021-07-05 15:55:57 --> Upload Class Initialized
INFO - 2021-07-05 15:55:57 --> Email Class Initialized
INFO - 2021-07-05 15:55:57 --> MY_Model class loaded
INFO - 2021-07-05 15:55:57 --> Model "Users_model" initialized
INFO - 2021-07-05 15:55:57 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:55:57 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:55:57 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:55:57 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:55:57 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:55:57 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:55:57 --> Database Driver Class Initialized
INFO - 2021-07-05 15:55:57 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:55:57 --> Controller Class Initialized
ERROR - 2021-07-05 18:55:57 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-05 18:55:57 --> Invalid query: 
INFO - 2021-07-05 18:55:57 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-05 18:55:57 --> Final output sent to browser
DEBUG - 2021-07-05 18:55:57 --> Total execution time: 0.1268
INFO - 2021-07-05 15:56:00 --> Config Class Initialized
INFO - 2021-07-05 15:56:00 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:56:00 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:56:00 --> Utf8 Class Initialized
INFO - 2021-07-05 15:56:00 --> URI Class Initialized
INFO - 2021-07-05 15:56:00 --> Router Class Initialized
INFO - 2021-07-05 15:56:00 --> Output Class Initialized
INFO - 2021-07-05 15:56:00 --> Security Class Initialized
DEBUG - 2021-07-05 15:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:56:00 --> Input Class Initialized
INFO - 2021-07-05 15:56:00 --> Language Class Initialized
INFO - 2021-07-05 15:56:00 --> Loader Class Initialized
INFO - 2021-07-05 15:56:00 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:56:00 --> Helper loaded: url_helper
INFO - 2021-07-05 15:56:00 --> Helper loaded: file_helper
INFO - 2021-07-05 15:56:00 --> Helper loaded: form_helper
INFO - 2021-07-05 15:56:00 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:56:00 --> Helper loaded: security_helper
INFO - 2021-07-05 15:56:00 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:56:00 --> Helper loaded: language_helper
INFO - 2021-07-05 15:56:00 --> Helper loaded: general_helper
INFO - 2021-07-05 15:56:00 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:56:00 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:56:00 --> Parser Class Initialized
INFO - 2021-07-05 15:56:00 --> Form Validation Class Initialized
INFO - 2021-07-05 15:56:00 --> Upload Class Initialized
INFO - 2021-07-05 15:56:00 --> Email Class Initialized
INFO - 2021-07-05 15:56:00 --> MY_Model class loaded
INFO - 2021-07-05 15:56:00 --> Model "Users_model" initialized
INFO - 2021-07-05 15:56:00 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:56:00 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:56:00 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:56:00 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:56:00 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:56:00 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:56:00 --> Database Driver Class Initialized
INFO - 2021-07-05 15:56:00 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:56:00 --> Controller Class Initialized
ERROR - 2021-07-05 18:56:00 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-05 18:56:00 --> Invalid query: 
INFO - 2021-07-05 18:56:00 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-05 18:56:00 --> Final output sent to browser
DEBUG - 2021-07-05 18:56:00 --> Total execution time: 0.2699
INFO - 2021-07-05 15:56:02 --> Config Class Initialized
INFO - 2021-07-05 15:56:02 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:56:02 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:56:02 --> Utf8 Class Initialized
INFO - 2021-07-05 15:56:02 --> URI Class Initialized
INFO - 2021-07-05 15:56:02 --> Router Class Initialized
INFO - 2021-07-05 15:56:02 --> Output Class Initialized
INFO - 2021-07-05 15:56:02 --> Security Class Initialized
DEBUG - 2021-07-05 15:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:56:02 --> Input Class Initialized
INFO - 2021-07-05 15:56:02 --> Language Class Initialized
INFO - 2021-07-05 15:56:02 --> Loader Class Initialized
INFO - 2021-07-05 15:56:02 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:56:02 --> Helper loaded: url_helper
INFO - 2021-07-05 15:56:02 --> Helper loaded: file_helper
INFO - 2021-07-05 15:56:02 --> Helper loaded: form_helper
INFO - 2021-07-05 15:56:02 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:56:02 --> Helper loaded: security_helper
INFO - 2021-07-05 15:56:02 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:56:02 --> Helper loaded: language_helper
INFO - 2021-07-05 15:56:02 --> Helper loaded: general_helper
INFO - 2021-07-05 15:56:02 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:56:02 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:56:02 --> Parser Class Initialized
INFO - 2021-07-05 15:56:02 --> Form Validation Class Initialized
INFO - 2021-07-05 15:56:02 --> Upload Class Initialized
INFO - 2021-07-05 15:56:02 --> Email Class Initialized
INFO - 2021-07-05 15:56:02 --> MY_Model class loaded
INFO - 2021-07-05 15:56:02 --> Model "Users_model" initialized
INFO - 2021-07-05 15:56:02 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:56:02 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:56:02 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:56:02 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:56:02 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:56:02 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:56:02 --> Database Driver Class Initialized
INFO - 2021-07-05 15:56:02 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:56:02 --> Controller Class Initialized
ERROR - 2021-07-05 18:56:02 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-05 18:56:02 --> Invalid query: 
INFO - 2021-07-05 18:56:02 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-05 18:56:02 --> Final output sent to browser
DEBUG - 2021-07-05 18:56:02 --> Total execution time: 0.0585
INFO - 2021-07-05 15:56:06 --> Config Class Initialized
INFO - 2021-07-05 15:56:06 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:56:06 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:56:06 --> Utf8 Class Initialized
INFO - 2021-07-05 15:56:06 --> URI Class Initialized
INFO - 2021-07-05 15:56:06 --> Router Class Initialized
INFO - 2021-07-05 15:56:06 --> Output Class Initialized
INFO - 2021-07-05 15:56:06 --> Security Class Initialized
DEBUG - 2021-07-05 15:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:56:06 --> Input Class Initialized
INFO - 2021-07-05 15:56:06 --> Language Class Initialized
INFO - 2021-07-05 15:56:06 --> Loader Class Initialized
INFO - 2021-07-05 15:56:06 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:56:06 --> Helper loaded: url_helper
INFO - 2021-07-05 15:56:06 --> Helper loaded: file_helper
INFO - 2021-07-05 15:56:06 --> Helper loaded: form_helper
INFO - 2021-07-05 15:56:06 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:56:06 --> Helper loaded: security_helper
INFO - 2021-07-05 15:56:06 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:56:06 --> Helper loaded: language_helper
INFO - 2021-07-05 15:56:06 --> Helper loaded: general_helper
INFO - 2021-07-05 15:56:06 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:56:06 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:56:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:56:06 --> Parser Class Initialized
INFO - 2021-07-05 15:56:06 --> Form Validation Class Initialized
INFO - 2021-07-05 15:56:06 --> Upload Class Initialized
INFO - 2021-07-05 15:56:06 --> Email Class Initialized
INFO - 2021-07-05 15:56:06 --> MY_Model class loaded
INFO - 2021-07-05 15:56:06 --> Model "Users_model" initialized
INFO - 2021-07-05 15:56:06 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:56:06 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:56:06 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:56:06 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:56:06 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:56:06 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:56:06 --> Database Driver Class Initialized
INFO - 2021-07-05 15:56:06 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:56:06 --> Controller Class Initialized
ERROR - 2021-07-05 18:56:06 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-05 18:56:06 --> Invalid query: 
INFO - 2021-07-05 18:56:06 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-05 18:56:06 --> Final output sent to browser
DEBUG - 2021-07-05 18:56:06 --> Total execution time: 0.1222
INFO - 2021-07-05 15:56:36 --> Config Class Initialized
INFO - 2021-07-05 15:56:36 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:56:36 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:56:36 --> Utf8 Class Initialized
INFO - 2021-07-05 15:56:36 --> URI Class Initialized
INFO - 2021-07-05 15:56:36 --> Router Class Initialized
INFO - 2021-07-05 15:56:36 --> Output Class Initialized
INFO - 2021-07-05 15:56:36 --> Security Class Initialized
DEBUG - 2021-07-05 15:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:56:36 --> Input Class Initialized
INFO - 2021-07-05 15:56:36 --> Language Class Initialized
INFO - 2021-07-05 15:56:36 --> Loader Class Initialized
INFO - 2021-07-05 15:56:36 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:56:36 --> Helper loaded: url_helper
INFO - 2021-07-05 15:56:36 --> Helper loaded: file_helper
INFO - 2021-07-05 15:56:36 --> Helper loaded: form_helper
INFO - 2021-07-05 15:56:36 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:56:36 --> Helper loaded: security_helper
INFO - 2021-07-05 15:56:36 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:56:36 --> Helper loaded: language_helper
INFO - 2021-07-05 15:56:36 --> Helper loaded: general_helper
INFO - 2021-07-05 15:56:36 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:56:36 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:56:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:56:36 --> Parser Class Initialized
INFO - 2021-07-05 15:56:36 --> Form Validation Class Initialized
INFO - 2021-07-05 15:56:36 --> Upload Class Initialized
INFO - 2021-07-05 15:56:36 --> Email Class Initialized
INFO - 2021-07-05 15:56:36 --> MY_Model class loaded
INFO - 2021-07-05 15:56:36 --> Model "Users_model" initialized
INFO - 2021-07-05 15:56:36 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:56:36 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:56:36 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:56:36 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:56:36 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:56:36 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:56:36 --> Database Driver Class Initialized
INFO - 2021-07-05 15:56:36 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:56:36 --> Controller Class Initialized
ERROR - 2021-07-05 18:56:36 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-05 18:56:36 --> Invalid query: 
INFO - 2021-07-05 18:56:36 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-05 18:56:36 --> Final output sent to browser
DEBUG - 2021-07-05 18:56:36 --> Total execution time: 0.1216
INFO - 2021-07-05 15:56:39 --> Config Class Initialized
INFO - 2021-07-05 15:56:39 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:56:39 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:56:39 --> Utf8 Class Initialized
INFO - 2021-07-05 15:56:39 --> URI Class Initialized
INFO - 2021-07-05 15:56:39 --> Router Class Initialized
INFO - 2021-07-05 15:56:39 --> Output Class Initialized
INFO - 2021-07-05 15:56:39 --> Security Class Initialized
DEBUG - 2021-07-05 15:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:56:39 --> Input Class Initialized
INFO - 2021-07-05 15:56:39 --> Language Class Initialized
INFO - 2021-07-05 15:56:39 --> Loader Class Initialized
INFO - 2021-07-05 15:56:39 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:56:39 --> Helper loaded: url_helper
INFO - 2021-07-05 15:56:39 --> Helper loaded: file_helper
INFO - 2021-07-05 15:56:39 --> Helper loaded: form_helper
INFO - 2021-07-05 15:56:39 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:56:39 --> Helper loaded: security_helper
INFO - 2021-07-05 15:56:39 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:56:39 --> Helper loaded: language_helper
INFO - 2021-07-05 15:56:39 --> Helper loaded: general_helper
INFO - 2021-07-05 15:56:39 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:56:39 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:56:39 --> Parser Class Initialized
INFO - 2021-07-05 15:56:39 --> Form Validation Class Initialized
INFO - 2021-07-05 15:56:39 --> Upload Class Initialized
INFO - 2021-07-05 15:56:39 --> Email Class Initialized
INFO - 2021-07-05 15:56:39 --> MY_Model class loaded
INFO - 2021-07-05 15:56:39 --> Model "Users_model" initialized
INFO - 2021-07-05 15:56:39 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:56:39 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:56:39 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:56:39 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:56:39 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:56:39 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:56:39 --> Database Driver Class Initialized
INFO - 2021-07-05 15:56:39 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:56:39 --> Controller Class Initialized
ERROR - 2021-07-05 18:56:39 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-05 18:56:39 --> Invalid query: 
INFO - 2021-07-05 18:56:39 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-05 18:56:39 --> Final output sent to browser
DEBUG - 2021-07-05 18:56:39 --> Total execution time: 0.0627
INFO - 2021-07-05 15:56:43 --> Config Class Initialized
INFO - 2021-07-05 15:56:43 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:56:43 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:56:43 --> Utf8 Class Initialized
INFO - 2021-07-05 15:56:43 --> URI Class Initialized
INFO - 2021-07-05 15:56:43 --> Router Class Initialized
INFO - 2021-07-05 15:56:43 --> Output Class Initialized
INFO - 2021-07-05 15:56:43 --> Security Class Initialized
DEBUG - 2021-07-05 15:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:56:43 --> Input Class Initialized
INFO - 2021-07-05 15:56:43 --> Language Class Initialized
INFO - 2021-07-05 15:56:43 --> Loader Class Initialized
INFO - 2021-07-05 15:56:43 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:56:43 --> Helper loaded: url_helper
INFO - 2021-07-05 15:56:43 --> Helper loaded: file_helper
INFO - 2021-07-05 15:56:43 --> Helper loaded: form_helper
INFO - 2021-07-05 15:56:43 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:56:43 --> Helper loaded: security_helper
INFO - 2021-07-05 15:56:43 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:56:43 --> Helper loaded: language_helper
INFO - 2021-07-05 15:56:43 --> Helper loaded: general_helper
INFO - 2021-07-05 15:56:43 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:56:43 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:56:43 --> Parser Class Initialized
INFO - 2021-07-05 15:56:43 --> Form Validation Class Initialized
INFO - 2021-07-05 15:56:43 --> Upload Class Initialized
INFO - 2021-07-05 15:56:43 --> Email Class Initialized
INFO - 2021-07-05 15:56:43 --> MY_Model class loaded
INFO - 2021-07-05 15:56:43 --> Model "Users_model" initialized
INFO - 2021-07-05 15:56:43 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:56:43 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:56:43 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:56:43 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:56:43 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:56:43 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:56:43 --> Database Driver Class Initialized
INFO - 2021-07-05 15:56:43 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:56:43 --> Controller Class Initialized
ERROR - 2021-07-05 18:56:43 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-05 18:56:43 --> Invalid query: 
INFO - 2021-07-05 18:56:43 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-05 18:56:43 --> Final output sent to browser
DEBUG - 2021-07-05 18:56:43 --> Total execution time: 0.1219
INFO - 2021-07-05 15:56:46 --> Config Class Initialized
INFO - 2021-07-05 15:56:46 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:56:46 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:56:46 --> Utf8 Class Initialized
INFO - 2021-07-05 15:56:46 --> URI Class Initialized
INFO - 2021-07-05 15:56:46 --> Router Class Initialized
INFO - 2021-07-05 15:56:46 --> Output Class Initialized
INFO - 2021-07-05 15:56:46 --> Security Class Initialized
DEBUG - 2021-07-05 15:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:56:46 --> Input Class Initialized
INFO - 2021-07-05 15:56:46 --> Language Class Initialized
INFO - 2021-07-05 15:56:46 --> Loader Class Initialized
INFO - 2021-07-05 15:56:46 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:56:46 --> Helper loaded: url_helper
INFO - 2021-07-05 15:56:46 --> Helper loaded: file_helper
INFO - 2021-07-05 15:56:46 --> Helper loaded: form_helper
INFO - 2021-07-05 15:56:46 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:56:46 --> Helper loaded: security_helper
INFO - 2021-07-05 15:56:46 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:56:46 --> Helper loaded: language_helper
INFO - 2021-07-05 15:56:46 --> Helper loaded: general_helper
INFO - 2021-07-05 15:56:46 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:56:46 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:56:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:56:46 --> Parser Class Initialized
INFO - 2021-07-05 15:56:46 --> Form Validation Class Initialized
INFO - 2021-07-05 15:56:46 --> Upload Class Initialized
INFO - 2021-07-05 15:56:46 --> Email Class Initialized
INFO - 2021-07-05 15:56:46 --> MY_Model class loaded
INFO - 2021-07-05 15:56:46 --> Model "Users_model" initialized
INFO - 2021-07-05 15:56:46 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:56:46 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:56:46 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:56:46 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:56:46 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:56:46 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:56:46 --> Database Driver Class Initialized
INFO - 2021-07-05 15:56:46 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:56:46 --> Controller Class Initialized
ERROR - 2021-07-05 18:56:46 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-05 18:56:46 --> Invalid query: 
INFO - 2021-07-05 18:56:46 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-05 18:56:46 --> Final output sent to browser
DEBUG - 2021-07-05 18:56:46 --> Total execution time: 0.0709
INFO - 2021-07-05 15:56:48 --> Config Class Initialized
INFO - 2021-07-05 15:56:48 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:56:48 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:56:48 --> Utf8 Class Initialized
INFO - 2021-07-05 15:56:48 --> URI Class Initialized
INFO - 2021-07-05 15:56:48 --> Router Class Initialized
INFO - 2021-07-05 15:56:48 --> Output Class Initialized
INFO - 2021-07-05 15:56:48 --> Security Class Initialized
DEBUG - 2021-07-05 15:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:56:48 --> Input Class Initialized
INFO - 2021-07-05 15:56:48 --> Language Class Initialized
INFO - 2021-07-05 15:56:48 --> Loader Class Initialized
INFO - 2021-07-05 15:56:48 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:56:48 --> Helper loaded: url_helper
INFO - 2021-07-05 15:56:48 --> Helper loaded: file_helper
INFO - 2021-07-05 15:56:48 --> Helper loaded: form_helper
INFO - 2021-07-05 15:56:48 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:56:48 --> Helper loaded: security_helper
INFO - 2021-07-05 15:56:48 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:56:48 --> Helper loaded: language_helper
INFO - 2021-07-05 15:56:48 --> Helper loaded: general_helper
INFO - 2021-07-05 15:56:48 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:56:48 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:56:48 --> Parser Class Initialized
INFO - 2021-07-05 15:56:48 --> Form Validation Class Initialized
INFO - 2021-07-05 15:56:48 --> Upload Class Initialized
INFO - 2021-07-05 15:56:48 --> Email Class Initialized
INFO - 2021-07-05 15:56:48 --> MY_Model class loaded
INFO - 2021-07-05 15:56:48 --> Model "Users_model" initialized
INFO - 2021-07-05 15:56:48 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:56:48 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:56:48 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:56:48 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:56:48 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:56:48 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:56:48 --> Database Driver Class Initialized
INFO - 2021-07-05 15:56:48 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:56:48 --> Controller Class Initialized
ERROR - 2021-07-05 18:56:48 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-05 18:56:48 --> Invalid query: 
INFO - 2021-07-05 18:56:48 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-05 18:56:48 --> Final output sent to browser
DEBUG - 2021-07-05 18:56:48 --> Total execution time: 0.0600
INFO - 2021-07-05 15:59:00 --> Config Class Initialized
INFO - 2021-07-05 15:59:00 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:59:00 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:59:00 --> Utf8 Class Initialized
INFO - 2021-07-05 15:59:00 --> URI Class Initialized
INFO - 2021-07-05 15:59:00 --> Router Class Initialized
INFO - 2021-07-05 15:59:00 --> Output Class Initialized
INFO - 2021-07-05 15:59:00 --> Security Class Initialized
DEBUG - 2021-07-05 15:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:59:00 --> Input Class Initialized
INFO - 2021-07-05 15:59:00 --> Language Class Initialized
INFO - 2021-07-05 15:59:00 --> Loader Class Initialized
INFO - 2021-07-05 15:59:00 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:59:00 --> Helper loaded: url_helper
INFO - 2021-07-05 15:59:00 --> Helper loaded: file_helper
INFO - 2021-07-05 15:59:00 --> Helper loaded: form_helper
INFO - 2021-07-05 15:59:00 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:59:00 --> Helper loaded: security_helper
INFO - 2021-07-05 15:59:00 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:59:00 --> Helper loaded: language_helper
INFO - 2021-07-05 15:59:00 --> Helper loaded: general_helper
INFO - 2021-07-05 15:59:00 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:59:00 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:59:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:59:00 --> Parser Class Initialized
INFO - 2021-07-05 15:59:00 --> Form Validation Class Initialized
INFO - 2021-07-05 15:59:00 --> Upload Class Initialized
INFO - 2021-07-05 15:59:00 --> Email Class Initialized
INFO - 2021-07-05 15:59:00 --> MY_Model class loaded
INFO - 2021-07-05 15:59:00 --> Model "Users_model" initialized
INFO - 2021-07-05 15:59:00 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:59:00 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:59:00 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:59:00 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:59:00 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:59:00 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:59:00 --> Database Driver Class Initialized
INFO - 2021-07-05 15:59:00 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:59:00 --> Controller Class Initialized
ERROR - 2021-07-05 18:59:00 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 18:59:00 --> File loaded: C:\wamp64\www\crm\application\views\blank_page.php
INFO - 2021-07-05 18:59:00 --> Final output sent to browser
DEBUG - 2021-07-05 18:59:00 --> Total execution time: 0.1372
INFO - 2021-07-05 15:59:05 --> Config Class Initialized
INFO - 2021-07-05 15:59:05 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:59:05 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:59:05 --> Utf8 Class Initialized
INFO - 2021-07-05 15:59:05 --> URI Class Initialized
INFO - 2021-07-05 15:59:05 --> Router Class Initialized
INFO - 2021-07-05 15:59:05 --> Output Class Initialized
INFO - 2021-07-05 15:59:05 --> Security Class Initialized
DEBUG - 2021-07-05 15:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:59:05 --> Input Class Initialized
INFO - 2021-07-05 15:59:05 --> Language Class Initialized
INFO - 2021-07-05 15:59:05 --> Loader Class Initialized
INFO - 2021-07-05 15:59:05 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:59:05 --> Helper loaded: url_helper
INFO - 2021-07-05 15:59:05 --> Helper loaded: file_helper
INFO - 2021-07-05 15:59:05 --> Helper loaded: form_helper
INFO - 2021-07-05 15:59:05 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:59:05 --> Helper loaded: security_helper
INFO - 2021-07-05 15:59:05 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:59:05 --> Helper loaded: language_helper
INFO - 2021-07-05 15:59:05 --> Helper loaded: general_helper
INFO - 2021-07-05 15:59:05 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:59:05 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:59:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:59:05 --> Parser Class Initialized
INFO - 2021-07-05 15:59:05 --> Form Validation Class Initialized
INFO - 2021-07-05 15:59:05 --> Upload Class Initialized
INFO - 2021-07-05 15:59:05 --> Email Class Initialized
INFO - 2021-07-05 15:59:05 --> MY_Model class loaded
INFO - 2021-07-05 15:59:05 --> Model "Users_model" initialized
INFO - 2021-07-05 15:59:05 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:59:05 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:59:05 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:59:05 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:59:05 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:59:05 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:59:05 --> Database Driver Class Initialized
INFO - 2021-07-05 15:59:05 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:59:05 --> Controller Class Initialized
ERROR - 2021-07-05 18:59:05 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 18:59:05 --> File loaded: C:\wamp64\www\crm\application\views\settings/general.php
INFO - 2021-07-05 18:59:05 --> Final output sent to browser
DEBUG - 2021-07-05 18:59:05 --> Total execution time: 0.1831
INFO - 2021-07-05 15:59:07 --> Config Class Initialized
INFO - 2021-07-05 15:59:07 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:59:07 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:59:07 --> Utf8 Class Initialized
INFO - 2021-07-05 15:59:07 --> URI Class Initialized
INFO - 2021-07-05 15:59:07 --> Router Class Initialized
INFO - 2021-07-05 15:59:07 --> Output Class Initialized
INFO - 2021-07-05 15:59:07 --> Security Class Initialized
DEBUG - 2021-07-05 15:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:59:07 --> Input Class Initialized
INFO - 2021-07-05 15:59:07 --> Language Class Initialized
INFO - 2021-07-05 15:59:07 --> Loader Class Initialized
INFO - 2021-07-05 15:59:07 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:59:07 --> Helper loaded: url_helper
INFO - 2021-07-05 15:59:07 --> Helper loaded: file_helper
INFO - 2021-07-05 15:59:07 --> Helper loaded: form_helper
INFO - 2021-07-05 15:59:07 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:59:07 --> Helper loaded: security_helper
INFO - 2021-07-05 15:59:07 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:59:07 --> Helper loaded: language_helper
INFO - 2021-07-05 15:59:07 --> Helper loaded: general_helper
INFO - 2021-07-05 15:59:07 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:59:07 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:59:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:59:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:59:07 --> Parser Class Initialized
INFO - 2021-07-05 15:59:07 --> Form Validation Class Initialized
INFO - 2021-07-05 15:59:07 --> Upload Class Initialized
INFO - 2021-07-05 15:59:07 --> Email Class Initialized
INFO - 2021-07-05 15:59:07 --> MY_Model class loaded
INFO - 2021-07-05 15:59:07 --> Model "Users_model" initialized
INFO - 2021-07-05 15:59:07 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:59:07 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:59:07 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:59:07 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:59:07 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:59:07 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:59:07 --> Database Driver Class Initialized
INFO - 2021-07-05 15:59:07 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:59:07 --> Controller Class Initialized
ERROR - 2021-07-05 18:59:07 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 18:59:07 --> File loaded: C:\wamp64\www\crm\application\views\settings/company.php
INFO - 2021-07-05 18:59:07 --> Final output sent to browser
DEBUG - 2021-07-05 18:59:07 --> Total execution time: 0.1439
INFO - 2021-07-05 15:59:08 --> Config Class Initialized
INFO - 2021-07-05 15:59:08 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:59:08 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:59:08 --> Utf8 Class Initialized
INFO - 2021-07-05 15:59:08 --> URI Class Initialized
INFO - 2021-07-05 15:59:08 --> Router Class Initialized
INFO - 2021-07-05 15:59:08 --> Output Class Initialized
INFO - 2021-07-05 15:59:08 --> Security Class Initialized
DEBUG - 2021-07-05 15:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:59:08 --> Input Class Initialized
INFO - 2021-07-05 15:59:08 --> Language Class Initialized
INFO - 2021-07-05 15:59:08 --> Loader Class Initialized
INFO - 2021-07-05 15:59:08 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:59:08 --> Helper loaded: url_helper
INFO - 2021-07-05 15:59:08 --> Helper loaded: file_helper
INFO - 2021-07-05 15:59:08 --> Helper loaded: form_helper
INFO - 2021-07-05 15:59:08 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:59:08 --> Helper loaded: security_helper
INFO - 2021-07-05 15:59:08 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:59:08 --> Helper loaded: language_helper
INFO - 2021-07-05 15:59:08 --> Helper loaded: general_helper
INFO - 2021-07-05 15:59:08 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:59:08 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:59:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:59:08 --> Parser Class Initialized
INFO - 2021-07-05 15:59:08 --> Form Validation Class Initialized
INFO - 2021-07-05 15:59:08 --> Upload Class Initialized
INFO - 2021-07-05 15:59:08 --> Email Class Initialized
INFO - 2021-07-05 15:59:08 --> MY_Model class loaded
INFO - 2021-07-05 15:59:08 --> Model "Users_model" initialized
INFO - 2021-07-05 15:59:08 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:59:08 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:59:08 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:59:08 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:59:08 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:59:08 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:59:08 --> Database Driver Class Initialized
INFO - 2021-07-05 15:59:08 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:59:08 --> Controller Class Initialized
ERROR - 2021-07-05 18:59:08 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 18:59:08 --> File loaded: C:\wamp64\www\crm\application\views\settings/email_templates/list.php
INFO - 2021-07-05 18:59:08 --> Final output sent to browser
DEBUG - 2021-07-05 18:59:08 --> Total execution time: 0.0964
INFO - 2021-07-05 15:59:10 --> Config Class Initialized
INFO - 2021-07-05 15:59:10 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:59:10 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:59:10 --> Utf8 Class Initialized
INFO - 2021-07-05 15:59:10 --> URI Class Initialized
INFO - 2021-07-05 15:59:10 --> Router Class Initialized
INFO - 2021-07-05 15:59:10 --> Output Class Initialized
INFO - 2021-07-05 15:59:10 --> Security Class Initialized
DEBUG - 2021-07-05 15:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:59:10 --> Input Class Initialized
INFO - 2021-07-05 15:59:10 --> Language Class Initialized
INFO - 2021-07-05 15:59:10 --> Loader Class Initialized
INFO - 2021-07-05 15:59:10 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:59:10 --> Helper loaded: url_helper
INFO - 2021-07-05 15:59:10 --> Helper loaded: file_helper
INFO - 2021-07-05 15:59:10 --> Helper loaded: form_helper
INFO - 2021-07-05 15:59:10 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:59:10 --> Helper loaded: security_helper
INFO - 2021-07-05 15:59:10 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:59:10 --> Helper loaded: language_helper
INFO - 2021-07-05 15:59:10 --> Helper loaded: general_helper
INFO - 2021-07-05 15:59:10 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:59:10 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:59:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:59:10 --> Parser Class Initialized
INFO - 2021-07-05 15:59:10 --> Form Validation Class Initialized
INFO - 2021-07-05 15:59:10 --> Upload Class Initialized
INFO - 2021-07-05 15:59:10 --> Email Class Initialized
INFO - 2021-07-05 15:59:10 --> MY_Model class loaded
INFO - 2021-07-05 15:59:10 --> Model "Users_model" initialized
INFO - 2021-07-05 15:59:10 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:59:10 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:59:10 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:59:10 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:59:10 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:59:10 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:59:10 --> Database Driver Class Initialized
INFO - 2021-07-05 15:59:10 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:59:10 --> Controller Class Initialized
ERROR - 2021-07-05 18:59:10 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 18:59:10 --> File loaded: C:\wamp64\www\crm\application\views\roles/list.php
INFO - 2021-07-05 18:59:10 --> Final output sent to browser
DEBUG - 2021-07-05 18:59:10 --> Total execution time: 0.0840
INFO - 2021-07-05 15:59:11 --> Config Class Initialized
INFO - 2021-07-05 15:59:11 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:59:11 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:59:11 --> Utf8 Class Initialized
INFO - 2021-07-05 15:59:11 --> URI Class Initialized
INFO - 2021-07-05 15:59:11 --> Router Class Initialized
INFO - 2021-07-05 15:59:11 --> Output Class Initialized
INFO - 2021-07-05 15:59:11 --> Security Class Initialized
DEBUG - 2021-07-05 15:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:59:11 --> Input Class Initialized
INFO - 2021-07-05 15:59:11 --> Language Class Initialized
INFO - 2021-07-05 15:59:11 --> Loader Class Initialized
INFO - 2021-07-05 15:59:11 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:59:11 --> Helper loaded: url_helper
INFO - 2021-07-05 15:59:11 --> Helper loaded: file_helper
INFO - 2021-07-05 15:59:11 --> Helper loaded: form_helper
INFO - 2021-07-05 15:59:11 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:59:11 --> Helper loaded: security_helper
INFO - 2021-07-05 15:59:11 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:59:11 --> Helper loaded: language_helper
INFO - 2021-07-05 15:59:11 --> Helper loaded: general_helper
INFO - 2021-07-05 15:59:11 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:59:11 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:59:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:59:11 --> Parser Class Initialized
INFO - 2021-07-05 15:59:11 --> Form Validation Class Initialized
INFO - 2021-07-05 15:59:11 --> Upload Class Initialized
INFO - 2021-07-05 15:59:11 --> Email Class Initialized
INFO - 2021-07-05 15:59:11 --> MY_Model class loaded
INFO - 2021-07-05 15:59:11 --> Model "Users_model" initialized
INFO - 2021-07-05 15:59:11 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:59:11 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:59:11 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:59:11 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:59:11 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:59:11 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:59:11 --> Database Driver Class Initialized
INFO - 2021-07-05 15:59:11 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:59:11 --> Controller Class Initialized
ERROR - 2021-07-05 18:59:11 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 18:59:12 --> File loaded: C:\wamp64\www\crm\application\views\permissions/list.php
INFO - 2021-07-05 18:59:12 --> Final output sent to browser
DEBUG - 2021-07-05 18:59:12 --> Total execution time: 0.1793
INFO - 2021-07-05 15:59:12 --> Config Class Initialized
INFO - 2021-07-05 15:59:12 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:59:12 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:59:12 --> Utf8 Class Initialized
INFO - 2021-07-05 15:59:12 --> URI Class Initialized
INFO - 2021-07-05 15:59:12 --> Router Class Initialized
INFO - 2021-07-05 15:59:12 --> Output Class Initialized
INFO - 2021-07-05 15:59:12 --> Security Class Initialized
DEBUG - 2021-07-05 15:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:59:12 --> Input Class Initialized
INFO - 2021-07-05 15:59:12 --> Language Class Initialized
INFO - 2021-07-05 15:59:12 --> Loader Class Initialized
INFO - 2021-07-05 15:59:12 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:59:12 --> Helper loaded: url_helper
INFO - 2021-07-05 15:59:12 --> Helper loaded: file_helper
INFO - 2021-07-05 15:59:12 --> Helper loaded: form_helper
INFO - 2021-07-05 15:59:12 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:59:12 --> Helper loaded: security_helper
INFO - 2021-07-05 15:59:12 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:59:12 --> Helper loaded: language_helper
INFO - 2021-07-05 15:59:12 --> Helper loaded: general_helper
INFO - 2021-07-05 15:59:12 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:59:12 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:59:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:59:12 --> Parser Class Initialized
INFO - 2021-07-05 15:59:12 --> Form Validation Class Initialized
INFO - 2021-07-05 15:59:12 --> Upload Class Initialized
INFO - 2021-07-05 15:59:12 --> Email Class Initialized
INFO - 2021-07-05 15:59:12 --> MY_Model class loaded
INFO - 2021-07-05 15:59:12 --> Model "Users_model" initialized
INFO - 2021-07-05 15:59:12 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:59:12 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:59:12 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:59:12 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:59:12 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:59:12 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:59:12 --> Database Driver Class Initialized
INFO - 2021-07-05 15:59:12 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:59:12 --> Controller Class Initialized
ERROR - 2021-07-05 18:59:12 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-05 18:59:12 --> File loaded: C:\wamp64\www\crm\application\views\users/list.php
INFO - 2021-07-05 18:59:12 --> Final output sent to browser
DEBUG - 2021-07-05 18:59:12 --> Total execution time: 0.1152
INFO - 2021-07-05 15:59:13 --> Config Class Initialized
INFO - 2021-07-05 15:59:13 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:59:13 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:59:13 --> Utf8 Class Initialized
INFO - 2021-07-05 15:59:13 --> URI Class Initialized
INFO - 2021-07-05 15:59:13 --> Router Class Initialized
INFO - 2021-07-05 15:59:13 --> Output Class Initialized
INFO - 2021-07-05 15:59:13 --> Config Class Initialized
INFO - 2021-07-05 15:59:13 --> Security Class Initialized
INFO - 2021-07-05 15:59:13 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:59:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-05 15:59:13 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:59:13 --> Input Class Initialized
INFO - 2021-07-05 15:59:13 --> Utf8 Class Initialized
INFO - 2021-07-05 15:59:13 --> Language Class Initialized
INFO - 2021-07-05 15:59:13 --> URI Class Initialized
INFO - 2021-07-05 15:59:13 --> Config Class Initialized
INFO - 2021-07-05 15:59:13 --> Loader Class Initialized
INFO - 2021-07-05 15:59:13 --> Hooks Class Initialized
INFO - 2021-07-05 15:59:13 --> Router Class Initialized
INFO - 2021-07-05 15:59:13 --> Helper loaded: basic_helper
DEBUG - 2021-07-05 15:59:13 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:59:13 --> Output Class Initialized
INFO - 2021-07-05 15:59:13 --> Utf8 Class Initialized
INFO - 2021-07-05 15:59:13 --> Helper loaded: url_helper
INFO - 2021-07-05 15:59:13 --> Security Class Initialized
INFO - 2021-07-05 15:59:13 --> URI Class Initialized
INFO - 2021-07-05 15:59:13 --> Config Class Initialized
INFO - 2021-07-05 15:59:13 --> Helper loaded: file_helper
INFO - 2021-07-05 15:59:13 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:59:13 --> Input Class Initialized
INFO - 2021-07-05 15:59:13 --> Helper loaded: form_helper
INFO - 2021-07-05 15:59:13 --> Router Class Initialized
DEBUG - 2021-07-05 15:59:13 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:59:13 --> Language Class Initialized
INFO - 2021-07-05 15:59:13 --> Utf8 Class Initialized
INFO - 2021-07-05 15:59:13 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:59:13 --> Output Class Initialized
INFO - 2021-07-05 15:59:13 --> URI Class Initialized
INFO - 2021-07-05 15:59:13 --> Helper loaded: security_helper
INFO - 2021-07-05 15:59:13 --> Security Class Initialized
INFO - 2021-07-05 15:59:13 --> Loader Class Initialized
INFO - 2021-07-05 15:59:13 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:59:13 --> Router Class Initialized
DEBUG - 2021-07-05 15:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:59:13 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:59:13 --> Helper loaded: language_helper
INFO - 2021-07-05 15:59:13 --> Input Class Initialized
INFO - 2021-07-05 15:59:13 --> Output Class Initialized
INFO - 2021-07-05 15:59:13 --> Helper loaded: general_helper
INFO - 2021-07-05 15:59:13 --> Helper loaded: url_helper
INFO - 2021-07-05 15:59:13 --> Language Class Initialized
INFO - 2021-07-05 15:59:13 --> Security Class Initialized
INFO - 2021-07-05 15:59:13 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:59:13 --> Helper loaded: file_helper
INFO - 2021-07-05 15:59:13 --> Config Class Initialized
DEBUG - 2021-07-05 15:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:59:13 --> Loader Class Initialized
INFO - 2021-07-05 15:59:13 --> Hooks Class Initialized
INFO - 2021-07-05 15:59:13 --> Helper loaded: form_helper
INFO - 2021-07-05 15:59:13 --> Input Class Initialized
INFO - 2021-07-05 15:59:13 --> Database Driver Class Initialized
INFO - 2021-07-05 15:59:13 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:59:13 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:59:13 --> Language Class Initialized
DEBUG - 2021-07-05 15:59:13 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:59:13 --> Utf8 Class Initialized
INFO - 2021-07-05 15:59:13 --> Helper loaded: security_helper
INFO - 2021-07-05 15:59:13 --> Helper loaded: url_helper
INFO - 2021-07-05 15:59:13 --> Loader Class Initialized
INFO - 2021-07-05 15:59:13 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:59:13 --> URI Class Initialized
INFO - 2021-07-05 15:59:13 --> Helper loaded: file_helper
INFO - 2021-07-05 15:59:13 --> Helper loaded: basic_helper
DEBUG - 2021-07-05 15:59:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:59:13 --> Helper loaded: language_helper
INFO - 2021-07-05 15:59:13 --> Helper loaded: form_helper
INFO - 2021-07-05 15:59:13 --> Router Class Initialized
INFO - 2021-07-05 15:59:13 --> Config Class Initialized
INFO - 2021-07-05 15:59:13 --> Helper loaded: url_helper
INFO - 2021-07-05 15:59:13 --> Helper loaded: general_helper
INFO - 2021-07-05 15:59:13 --> Hooks Class Initialized
INFO - 2021-07-05 15:59:13 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:59:13 --> Output Class Initialized
INFO - 2021-07-05 15:59:13 --> Helper loaded: file_helper
INFO - 2021-07-05 15:59:13 --> Language file loaded: language/en/basic_lang.php
DEBUG - 2021-07-05 15:59:13 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:59:13 --> Helper loaded: security_helper
INFO - 2021-07-05 15:59:13 --> Parser Class Initialized
INFO - 2021-07-05 15:59:13 --> Utf8 Class Initialized
INFO - 2021-07-05 15:59:13 --> Security Class Initialized
INFO - 2021-07-05 15:59:13 --> Helper loaded: form_helper
INFO - 2021-07-05 15:59:13 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:59:13 --> Database Driver Class Initialized
INFO - 2021-07-05 15:59:13 --> URI Class Initialized
INFO - 2021-07-05 15:59:13 --> Form Validation Class Initialized
DEBUG - 2021-07-05 15:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:59:13 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:59:13 --> Helper loaded: language_helper
INFO - 2021-07-05 15:59:13 --> Input Class Initialized
INFO - 2021-07-05 15:59:13 --> Router Class Initialized
INFO - 2021-07-05 15:59:13 --> Helper loaded: security_helper
INFO - 2021-07-05 15:59:13 --> Helper loaded: general_helper
INFO - 2021-07-05 15:59:13 --> Upload Class Initialized
INFO - 2021-07-05 15:59:13 --> Language Class Initialized
INFO - 2021-07-05 15:59:13 --> Output Class Initialized
INFO - 2021-07-05 15:59:13 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:59:13 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:59:13 --> Email Class Initialized
DEBUG - 2021-07-05 15:59:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:59:13 --> Security Class Initialized
INFO - 2021-07-05 15:59:13 --> Helper loaded: language_helper
INFO - 2021-07-05 15:59:13 --> Loader Class Initialized
INFO - 2021-07-05 15:59:13 --> MY_Model class loaded
INFO - 2021-07-05 15:59:13 --> Database Driver Class Initialized
INFO - 2021-07-05 15:59:13 --> Model "Users_model" initialized
DEBUG - 2021-07-05 15:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:59:13 --> Helper loaded: general_helper
INFO - 2021-07-05 15:59:13 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:59:13 --> Input Class Initialized
INFO - 2021-07-05 15:59:13 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:59:13 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:59:13 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:59:13 --> Language Class Initialized
INFO - 2021-07-05 15:59:13 --> Helper loaded: url_helper
INFO - 2021-07-05 15:59:13 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:59:13 --> Database Driver Class Initialized
INFO - 2021-07-05 15:59:13 --> Helper loaded: file_helper
INFO - 2021-07-05 15:59:13 --> Loader Class Initialized
INFO - 2021-07-05 15:59:13 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:59:13 --> Model "Activity_model" initialized
DEBUG - 2021-07-05 15:59:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:59:13 --> Helper loaded: form_helper
INFO - 2021-07-05 15:59:13 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:59:13 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:59:13 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:59:13 --> Helper loaded: url_helper
INFO - 2021-07-05 15:59:13 --> Database Driver Class Initialized
INFO - 2021-07-05 15:59:13 --> Helper loaded: security_helper
INFO - 2021-07-05 15:59:13 --> Helper loaded: file_helper
DEBUG - 2021-07-05 15:59:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:59:13 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:59:13 --> Helper loaded: form_helper
INFO - 2021-07-05 15:59:13 --> Helper loaded: language_helper
INFO - 2021-07-05 15:59:13 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:59:13 --> Helper loaded: general_helper
INFO - 2021-07-05 15:59:13 --> Helper loaded: security_helper
INFO - 2021-07-05 15:59:13 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:59:13 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:59:13 --> Helper loaded: language_helper
INFO - 2021-07-05 15:59:13 --> Database Driver Class Initialized
INFO - 2021-07-05 15:59:13 --> Helper loaded: general_helper
INFO - 2021-07-05 15:59:13 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:59:13 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:59:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-07-05 15:59:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:59:13 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:59:13 --> Controller Class Initialized
INFO - 2021-07-05 18:59:13 --> Final output sent to browser
DEBUG - 2021-07-05 18:59:13 --> Total execution time: 0.0644
INFO - 2021-07-05 15:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:59:13 --> Parser Class Initialized
INFO - 2021-07-05 15:59:13 --> Form Validation Class Initialized
INFO - 2021-07-05 15:59:13 --> Upload Class Initialized
INFO - 2021-07-05 15:59:13 --> Email Class Initialized
INFO - 2021-07-05 15:59:13 --> MY_Model class loaded
INFO - 2021-07-05 15:59:13 --> Model "Users_model" initialized
INFO - 2021-07-05 15:59:13 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:59:13 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:59:13 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:59:13 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:59:13 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:59:13 --> Config Class Initialized
INFO - 2021-07-05 15:59:13 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:59:13 --> Hooks Class Initialized
INFO - 2021-07-05 15:59:13 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:59:13 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:59:13 --> Utf8 Class Initialized
INFO - 2021-07-05 15:59:13 --> URI Class Initialized
INFO - 2021-07-05 15:59:13 --> Router Class Initialized
INFO - 2021-07-05 15:59:13 --> Output Class Initialized
INFO - 2021-07-05 15:59:13 --> Security Class Initialized
DEBUG - 2021-07-05 15:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-05 15:59:13 --> Input Class Initialized
INFO - 2021-07-05 15:59:13 --> Language Class Initialized
INFO - 2021-07-05 15:59:13 --> Loader Class Initialized
INFO - 2021-07-05 15:59:13 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:59:13 --> Helper loaded: url_helper
INFO - 2021-07-05 15:59:13 --> Helper loaded: file_helper
INFO - 2021-07-05 15:59:13 --> Helper loaded: form_helper
INFO - 2021-07-05 15:59:13 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:59:13 --> Helper loaded: security_helper
INFO - 2021-07-05 15:59:13 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:59:13 --> Helper loaded: language_helper
INFO - 2021-07-05 15:59:13 --> Helper loaded: general_helper
INFO - 2021-07-05 15:59:13 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:59:13 --> Database Driver Class Initialized
INFO - 2021-07-05 15:59:13 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:59:13 --> Controller Class Initialized
INFO - 2021-07-05 18:59:13 --> Final output sent to browser
DEBUG - 2021-07-05 18:59:13 --> Total execution time: 0.0884
INFO - 2021-07-05 15:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:59:13 --> Parser Class Initialized
INFO - 2021-07-05 15:59:13 --> Form Validation Class Initialized
INFO - 2021-07-05 15:59:13 --> Upload Class Initialized
INFO - 2021-07-05 15:59:13 --> Email Class Initialized
INFO - 2021-07-05 15:59:13 --> MY_Model class loaded
INFO - 2021-07-05 15:59:13 --> Model "Users_model" initialized
INFO - 2021-07-05 15:59:13 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:59:13 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:59:13 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:59:13 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:59:13 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:59:13 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:59:13 --> Database Driver Class Initialized
INFO - 2021-07-05 15:59:13 --> Config Class Initialized
INFO - 2021-07-05 15:59:13 --> Hooks Class Initialized
DEBUG - 2021-07-05 15:59:13 --> UTF-8 Support Enabled
INFO - 2021-07-05 15:59:13 --> Utf8 Class Initialized
INFO - 2021-07-05 15:59:13 --> URI Class Initialized
INFO - 2021-07-05 15:59:13 --> Router Class Initialized
INFO - 2021-07-05 15:59:13 --> Output Class Initialized
INFO - 2021-07-05 15:59:13 --> Security Class Initialized
DEBUG - 2021-07-05 15:59:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-05 15:59:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:59:13 --> Input Class Initialized
INFO - 2021-07-05 15:59:13 --> Language Class Initialized
INFO - 2021-07-05 15:59:13 --> Loader Class Initialized
INFO - 2021-07-05 15:59:13 --> Helper loaded: basic_helper
INFO - 2021-07-05 15:59:13 --> Helper loaded: url_helper
INFO - 2021-07-05 15:59:13 --> Helper loaded: file_helper
INFO - 2021-07-05 15:59:13 --> Helper loaded: form_helper
INFO - 2021-07-05 15:59:13 --> Helper loaded: cookie_helper
INFO - 2021-07-05 15:59:13 --> Helper loaded: security_helper
INFO - 2021-07-05 15:59:13 --> Helper loaded: directory_helper
INFO - 2021-07-05 15:59:13 --> Helper loaded: language_helper
INFO - 2021-07-05 15:59:13 --> Helper loaded: general_helper
INFO - 2021-07-05 15:59:13 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-05 15:59:13 --> Database Driver Class Initialized
INFO - 2021-07-05 15:59:13 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:59:13 --> Controller Class Initialized
INFO - 2021-07-05 18:59:13 --> Final output sent to browser
DEBUG - 2021-07-05 18:59:13 --> Total execution time: 0.1190
INFO - 2021-07-05 15:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:59:13 --> Parser Class Initialized
INFO - 2021-07-05 15:59:13 --> Form Validation Class Initialized
INFO - 2021-07-05 15:59:13 --> Upload Class Initialized
INFO - 2021-07-05 15:59:13 --> Email Class Initialized
INFO - 2021-07-05 15:59:13 --> MY_Model class loaded
INFO - 2021-07-05 15:59:13 --> Model "Users_model" initialized
INFO - 2021-07-05 15:59:13 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:59:13 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:59:13 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:59:13 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:59:13 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:59:13 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:59:13 --> Database Driver Class Initialized
DEBUG - 2021-07-05 15:59:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-05 15:59:13 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:59:13 --> Controller Class Initialized
INFO - 2021-07-05 18:59:13 --> Final output sent to browser
DEBUG - 2021-07-05 18:59:13 --> Total execution time: 0.1456
INFO - 2021-07-05 15:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:59:13 --> Parser Class Initialized
INFO - 2021-07-05 15:59:13 --> Form Validation Class Initialized
INFO - 2021-07-05 15:59:13 --> Upload Class Initialized
INFO - 2021-07-05 15:59:13 --> Email Class Initialized
INFO - 2021-07-05 15:59:13 --> MY_Model class loaded
INFO - 2021-07-05 15:59:13 --> Model "Users_model" initialized
INFO - 2021-07-05 15:59:13 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:59:13 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:59:13 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:59:13 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:59:13 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:59:13 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:59:13 --> Database Driver Class Initialized
INFO - 2021-07-05 15:59:13 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:59:13 --> Controller Class Initialized
INFO - 2021-07-05 18:59:13 --> Final output sent to browser
DEBUG - 2021-07-05 18:59:13 --> Total execution time: 0.1678
INFO - 2021-07-05 15:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:59:13 --> Parser Class Initialized
INFO - 2021-07-05 15:59:13 --> Form Validation Class Initialized
INFO - 2021-07-05 15:59:13 --> Upload Class Initialized
INFO - 2021-07-05 15:59:13 --> Email Class Initialized
INFO - 2021-07-05 15:59:13 --> MY_Model class loaded
INFO - 2021-07-05 15:59:13 --> Model "Users_model" initialized
INFO - 2021-07-05 15:59:13 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:59:13 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:59:13 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:59:13 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:59:13 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:59:13 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:59:13 --> Database Driver Class Initialized
INFO - 2021-07-05 15:59:13 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:59:13 --> Controller Class Initialized
INFO - 2021-07-05 18:59:13 --> Final output sent to browser
DEBUG - 2021-07-05 18:59:13 --> Total execution time: 0.1917
INFO - 2021-07-05 15:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:59:13 --> Parser Class Initialized
INFO - 2021-07-05 15:59:13 --> Form Validation Class Initialized
INFO - 2021-07-05 15:59:13 --> Upload Class Initialized
INFO - 2021-07-05 15:59:13 --> Email Class Initialized
INFO - 2021-07-05 15:59:13 --> MY_Model class loaded
INFO - 2021-07-05 15:59:13 --> Model "Users_model" initialized
INFO - 2021-07-05 15:59:13 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:59:13 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:59:13 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:59:13 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:59:13 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:59:13 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:59:13 --> Database Driver Class Initialized
INFO - 2021-07-05 15:59:13 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:59:13 --> Controller Class Initialized
INFO - 2021-07-05 18:59:13 --> Final output sent to browser
DEBUG - 2021-07-05 18:59:13 --> Total execution time: 0.1716
INFO - 2021-07-05 15:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-05 15:59:13 --> Parser Class Initialized
INFO - 2021-07-05 15:59:13 --> Form Validation Class Initialized
INFO - 2021-07-05 15:59:13 --> Upload Class Initialized
INFO - 2021-07-05 15:59:13 --> Email Class Initialized
INFO - 2021-07-05 15:59:13 --> MY_Model class loaded
INFO - 2021-07-05 15:59:13 --> Model "Users_model" initialized
INFO - 2021-07-05 15:59:13 --> Model "Settings_model" initialized
INFO - 2021-07-05 15:59:13 --> Model "Role_permissions_model" initialized
INFO - 2021-07-05 15:59:13 --> Model "Permissions_model" initialized
INFO - 2021-07-05 15:59:13 --> Model "Roles_model" initialized
INFO - 2021-07-05 15:59:13 --> Model "Activity_model" initialized
INFO - 2021-07-05 15:59:13 --> Model "Templates_model" initialized
INFO - 2021-07-05 15:59:13 --> Database Driver Class Initialized
INFO - 2021-07-05 15:59:13 --> Model "Hesaplar_model" initialized
INFO - 2021-07-05 15:59:13 --> Controller Class Initialized
INFO - 2021-07-05 18:59:13 --> Final output sent to browser
DEBUG - 2021-07-05 18:59:13 --> Total execution time: 0.1653
