<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-07-12 09:53:01 --> Config Class Initialized
INFO - 2021-07-12 09:53:01 --> Hooks Class Initialized
DEBUG - 2021-07-12 09:53:01 --> UTF-8 Support Enabled
INFO - 2021-07-12 09:53:01 --> Utf8 Class Initialized
INFO - 2021-07-12 09:53:01 --> URI Class Initialized
DEBUG - 2021-07-12 09:53:01 --> No URI present. Default controller set.
INFO - 2021-07-12 09:53:01 --> Router Class Initialized
INFO - 2021-07-12 09:53:01 --> Output Class Initialized
INFO - 2021-07-12 09:53:01 --> Security Class Initialized
DEBUG - 2021-07-12 09:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 09:53:01 --> Input Class Initialized
INFO - 2021-07-12 09:53:01 --> Language Class Initialized
INFO - 2021-07-12 09:53:01 --> Loader Class Initialized
INFO - 2021-07-12 09:53:01 --> Helper loaded: basic_helper
INFO - 2021-07-12 09:53:01 --> Helper loaded: url_helper
INFO - 2021-07-12 09:53:01 --> Helper loaded: file_helper
INFO - 2021-07-12 09:53:01 --> Helper loaded: form_helper
INFO - 2021-07-12 09:53:01 --> Helper loaded: cookie_helper
INFO - 2021-07-12 09:53:01 --> Helper loaded: security_helper
INFO - 2021-07-12 09:53:01 --> Helper loaded: directory_helper
INFO - 2021-07-12 09:53:01 --> Helper loaded: language_helper
INFO - 2021-07-12 09:53:01 --> Helper loaded: general_helper
INFO - 2021-07-12 09:53:01 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 09:53:01 --> Database Driver Class Initialized
DEBUG - 2021-07-12 09:53:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 09:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 09:53:01 --> Parser Class Initialized
INFO - 2021-07-12 09:53:01 --> Form Validation Class Initialized
INFO - 2021-07-12 09:53:01 --> Upload Class Initialized
INFO - 2021-07-12 09:53:01 --> Email Class Initialized
INFO - 2021-07-12 09:53:01 --> MY_Model class loaded
INFO - 2021-07-12 09:53:01 --> Model "Users_model" initialized
INFO - 2021-07-12 09:53:01 --> Model "Settings_model" initialized
INFO - 2021-07-12 09:53:01 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 09:53:01 --> Model "Permissions_model" initialized
INFO - 2021-07-12 09:53:01 --> Model "Roles_model" initialized
INFO - 2021-07-12 09:53:01 --> Model "Activity_model" initialized
INFO - 2021-07-12 09:53:01 --> Model "Templates_model" initialized
INFO - 2021-07-12 09:53:01 --> Database Driver Class Initialized
INFO - 2021-07-12 09:53:01 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 09:53:01 --> Controller Class Initialized
INFO - 2021-07-12 11:05:08 --> Config Class Initialized
INFO - 2021-07-12 11:05:08 --> Hooks Class Initialized
DEBUG - 2021-07-12 11:05:08 --> UTF-8 Support Enabled
INFO - 2021-07-12 11:05:08 --> Utf8 Class Initialized
INFO - 2021-07-12 11:05:08 --> URI Class Initialized
DEBUG - 2021-07-12 11:05:08 --> No URI present. Default controller set.
INFO - 2021-07-12 11:05:08 --> Router Class Initialized
INFO - 2021-07-12 11:05:08 --> Output Class Initialized
INFO - 2021-07-12 11:05:08 --> Security Class Initialized
DEBUG - 2021-07-12 11:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 11:05:08 --> Input Class Initialized
INFO - 2021-07-12 11:05:08 --> Language Class Initialized
INFO - 2021-07-12 11:05:08 --> Loader Class Initialized
INFO - 2021-07-12 11:05:08 --> Helper loaded: basic_helper
INFO - 2021-07-12 11:05:08 --> Helper loaded: url_helper
INFO - 2021-07-12 11:05:08 --> Helper loaded: file_helper
INFO - 2021-07-12 11:05:08 --> Helper loaded: form_helper
INFO - 2021-07-12 11:05:08 --> Helper loaded: cookie_helper
INFO - 2021-07-12 11:05:08 --> Helper loaded: security_helper
INFO - 2021-07-12 11:05:08 --> Helper loaded: directory_helper
INFO - 2021-07-12 11:05:08 --> Helper loaded: language_helper
INFO - 2021-07-12 11:05:08 --> Helper loaded: general_helper
INFO - 2021-07-12 11:05:08 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 11:05:08 --> Database Driver Class Initialized
DEBUG - 2021-07-12 11:05:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 11:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 11:05:08 --> Parser Class Initialized
INFO - 2021-07-12 11:05:08 --> Form Validation Class Initialized
INFO - 2021-07-12 11:05:08 --> Upload Class Initialized
INFO - 2021-07-12 11:05:08 --> Email Class Initialized
INFO - 2021-07-12 11:05:08 --> MY_Model class loaded
INFO - 2021-07-12 11:05:08 --> Model "Users_model" initialized
INFO - 2021-07-12 11:05:08 --> Model "Settings_model" initialized
INFO - 2021-07-12 11:05:08 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 11:05:08 --> Model "Permissions_model" initialized
INFO - 2021-07-12 11:05:08 --> Model "Roles_model" initialized
INFO - 2021-07-12 11:05:08 --> Model "Activity_model" initialized
INFO - 2021-07-12 11:05:08 --> Model "Templates_model" initialized
INFO - 2021-07-12 11:05:08 --> Database Driver Class Initialized
INFO - 2021-07-12 11:05:08 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 11:05:08 --> Controller Class Initialized
INFO - 2021-07-12 11:56:30 --> Config Class Initialized
INFO - 2021-07-12 11:56:30 --> Hooks Class Initialized
DEBUG - 2021-07-12 11:56:30 --> UTF-8 Support Enabled
INFO - 2021-07-12 11:56:30 --> Utf8 Class Initialized
INFO - 2021-07-12 11:56:30 --> URI Class Initialized
DEBUG - 2021-07-12 11:56:30 --> No URI present. Default controller set.
INFO - 2021-07-12 11:56:30 --> Router Class Initialized
INFO - 2021-07-12 11:56:30 --> Output Class Initialized
INFO - 2021-07-12 11:56:30 --> Security Class Initialized
DEBUG - 2021-07-12 11:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 11:56:30 --> Input Class Initialized
INFO - 2021-07-12 11:56:30 --> Language Class Initialized
INFO - 2021-07-12 11:56:30 --> Loader Class Initialized
INFO - 2021-07-12 11:56:30 --> Helper loaded: basic_helper
INFO - 2021-07-12 11:56:30 --> Helper loaded: url_helper
INFO - 2021-07-12 11:56:30 --> Helper loaded: file_helper
INFO - 2021-07-12 11:56:30 --> Helper loaded: form_helper
INFO - 2021-07-12 11:56:30 --> Helper loaded: cookie_helper
INFO - 2021-07-12 11:56:30 --> Helper loaded: security_helper
INFO - 2021-07-12 11:56:30 --> Helper loaded: directory_helper
INFO - 2021-07-12 11:56:30 --> Helper loaded: language_helper
INFO - 2021-07-12 11:56:30 --> Helper loaded: general_helper
INFO - 2021-07-12 11:56:30 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 11:56:30 --> Database Driver Class Initialized
DEBUG - 2021-07-12 11:56:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 11:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 11:56:30 --> Parser Class Initialized
INFO - 2021-07-12 11:56:30 --> Form Validation Class Initialized
INFO - 2021-07-12 11:56:30 --> Upload Class Initialized
INFO - 2021-07-12 11:56:30 --> Email Class Initialized
INFO - 2021-07-12 11:56:30 --> MY_Model class loaded
INFO - 2021-07-12 11:56:30 --> Model "Users_model" initialized
INFO - 2021-07-12 11:56:30 --> Model "Settings_model" initialized
INFO - 2021-07-12 11:56:30 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 11:56:30 --> Model "Permissions_model" initialized
INFO - 2021-07-12 11:56:30 --> Model "Roles_model" initialized
INFO - 2021-07-12 11:56:30 --> Model "Activity_model" initialized
INFO - 2021-07-12 11:56:30 --> Model "Templates_model" initialized
INFO - 2021-07-12 11:56:30 --> Database Driver Class Initialized
INFO - 2021-07-12 11:56:30 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 11:56:30 --> Controller Class Initialized
ERROR - 2021-07-12 11:56:30 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 11:56:30 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-12 11:56:30 --> Final output sent to browser
DEBUG - 2021-07-12 11:56:30 --> Total execution time: 0.1255
INFO - 2021-07-12 11:56:32 --> Config Class Initialized
INFO - 2021-07-12 11:56:32 --> Hooks Class Initialized
DEBUG - 2021-07-12 11:56:32 --> UTF-8 Support Enabled
INFO - 2021-07-12 11:56:32 --> Utf8 Class Initialized
INFO - 2021-07-12 11:56:32 --> URI Class Initialized
INFO - 2021-07-12 11:56:32 --> Router Class Initialized
INFO - 2021-07-12 11:56:32 --> Output Class Initialized
INFO - 2021-07-12 11:56:32 --> Security Class Initialized
DEBUG - 2021-07-12 11:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 11:56:32 --> Input Class Initialized
INFO - 2021-07-12 11:56:32 --> Language Class Initialized
ERROR - 2021-07-12 11:56:32 --> 404 Page Not Found: Faviconico/index
INFO - 2021-07-12 11:56:33 --> Config Class Initialized
INFO - 2021-07-12 11:56:33 --> Hooks Class Initialized
DEBUG - 2021-07-12 11:56:33 --> UTF-8 Support Enabled
INFO - 2021-07-12 11:56:33 --> Utf8 Class Initialized
INFO - 2021-07-12 11:56:33 --> URI Class Initialized
INFO - 2021-07-12 11:56:33 --> Router Class Initialized
INFO - 2021-07-12 11:56:33 --> Output Class Initialized
INFO - 2021-07-12 11:56:33 --> Security Class Initialized
DEBUG - 2021-07-12 11:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 11:56:33 --> Input Class Initialized
INFO - 2021-07-12 11:56:33 --> Language Class Initialized
INFO - 2021-07-12 11:56:33 --> Loader Class Initialized
INFO - 2021-07-12 11:56:33 --> Helper loaded: basic_helper
INFO - 2021-07-12 11:56:33 --> Helper loaded: url_helper
INFO - 2021-07-12 11:56:33 --> Helper loaded: file_helper
INFO - 2021-07-12 11:56:33 --> Helper loaded: form_helper
INFO - 2021-07-12 11:56:33 --> Helper loaded: cookie_helper
INFO - 2021-07-12 11:56:33 --> Helper loaded: security_helper
INFO - 2021-07-12 11:56:33 --> Helper loaded: directory_helper
INFO - 2021-07-12 11:56:33 --> Helper loaded: language_helper
INFO - 2021-07-12 11:56:33 --> Helper loaded: general_helper
INFO - 2021-07-12 11:56:33 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 11:56:33 --> Database Driver Class Initialized
DEBUG - 2021-07-12 11:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 11:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 11:56:33 --> Parser Class Initialized
INFO - 2021-07-12 11:56:33 --> Form Validation Class Initialized
INFO - 2021-07-12 11:56:33 --> Upload Class Initialized
INFO - 2021-07-12 11:56:33 --> Email Class Initialized
INFO - 2021-07-12 11:56:33 --> MY_Model class loaded
INFO - 2021-07-12 11:56:33 --> Model "Users_model" initialized
INFO - 2021-07-12 11:56:33 --> Model "Settings_model" initialized
INFO - 2021-07-12 11:56:33 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 11:56:33 --> Model "Permissions_model" initialized
INFO - 2021-07-12 11:56:33 --> Model "Roles_model" initialized
INFO - 2021-07-12 11:56:33 --> Model "Activity_model" initialized
INFO - 2021-07-12 11:56:33 --> Model "Templates_model" initialized
INFO - 2021-07-12 11:56:33 --> Database Driver Class Initialized
INFO - 2021-07-12 11:56:33 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 11:56:33 --> Controller Class Initialized
ERROR - 2021-07-12 11:56:33 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 11:56:33 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-12 11:56:33 --> Final output sent to browser
DEBUG - 2021-07-12 11:56:33 --> Total execution time: 0.2078
INFO - 2021-07-12 11:56:38 --> Config Class Initialized
INFO - 2021-07-12 11:56:38 --> Hooks Class Initialized
DEBUG - 2021-07-12 11:56:38 --> UTF-8 Support Enabled
INFO - 2021-07-12 11:56:38 --> Utf8 Class Initialized
INFO - 2021-07-12 11:56:38 --> URI Class Initialized
INFO - 2021-07-12 11:56:38 --> Router Class Initialized
INFO - 2021-07-12 11:56:38 --> Output Class Initialized
INFO - 2021-07-12 11:56:38 --> Security Class Initialized
DEBUG - 2021-07-12 11:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 11:56:38 --> Input Class Initialized
INFO - 2021-07-12 11:56:38 --> Language Class Initialized
INFO - 2021-07-12 11:56:38 --> Loader Class Initialized
INFO - 2021-07-12 11:56:38 --> Helper loaded: basic_helper
INFO - 2021-07-12 11:56:38 --> Helper loaded: url_helper
INFO - 2021-07-12 11:56:38 --> Helper loaded: file_helper
INFO - 2021-07-12 11:56:38 --> Helper loaded: form_helper
INFO - 2021-07-12 11:56:38 --> Helper loaded: cookie_helper
INFO - 2021-07-12 11:56:38 --> Helper loaded: security_helper
INFO - 2021-07-12 11:56:38 --> Helper loaded: directory_helper
INFO - 2021-07-12 11:56:38 --> Helper loaded: language_helper
INFO - 2021-07-12 11:56:38 --> Helper loaded: general_helper
INFO - 2021-07-12 11:56:38 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 11:56:38 --> Database Driver Class Initialized
DEBUG - 2021-07-12 11:56:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 11:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 11:56:38 --> Parser Class Initialized
INFO - 2021-07-12 11:56:38 --> Form Validation Class Initialized
INFO - 2021-07-12 11:56:38 --> Upload Class Initialized
INFO - 2021-07-12 11:56:38 --> Email Class Initialized
INFO - 2021-07-12 11:56:38 --> MY_Model class loaded
INFO - 2021-07-12 11:56:38 --> Model "Users_model" initialized
INFO - 2021-07-12 11:56:38 --> Model "Settings_model" initialized
INFO - 2021-07-12 11:56:38 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 11:56:38 --> Model "Permissions_model" initialized
INFO - 2021-07-12 11:56:38 --> Model "Roles_model" initialized
INFO - 2021-07-12 11:56:38 --> Model "Activity_model" initialized
INFO - 2021-07-12 11:56:38 --> Model "Templates_model" initialized
INFO - 2021-07-12 11:56:38 --> Database Driver Class Initialized
INFO - 2021-07-12 11:56:38 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 11:56:38 --> Controller Class Initialized
ERROR - 2021-07-12 11:56:38 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 11:56:38 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-12 11:56:38 --> Final output sent to browser
DEBUG - 2021-07-12 11:56:38 --> Total execution time: 0.1464
INFO - 2021-07-12 11:56:46 --> Config Class Initialized
INFO - 2021-07-12 11:56:46 --> Hooks Class Initialized
DEBUG - 2021-07-12 11:56:46 --> UTF-8 Support Enabled
INFO - 2021-07-12 11:56:46 --> Utf8 Class Initialized
INFO - 2021-07-12 11:56:46 --> URI Class Initialized
INFO - 2021-07-12 11:56:46 --> Router Class Initialized
INFO - 2021-07-12 11:56:46 --> Output Class Initialized
INFO - 2021-07-12 11:56:46 --> Security Class Initialized
DEBUG - 2021-07-12 11:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 11:56:46 --> Input Class Initialized
INFO - 2021-07-12 11:56:46 --> Language Class Initialized
INFO - 2021-07-12 11:56:46 --> Loader Class Initialized
INFO - 2021-07-12 11:56:46 --> Helper loaded: basic_helper
INFO - 2021-07-12 11:56:46 --> Helper loaded: url_helper
INFO - 2021-07-12 11:56:46 --> Helper loaded: file_helper
INFO - 2021-07-12 11:56:46 --> Helper loaded: form_helper
INFO - 2021-07-12 11:56:46 --> Helper loaded: cookie_helper
INFO - 2021-07-12 11:56:46 --> Helper loaded: security_helper
INFO - 2021-07-12 11:56:46 --> Helper loaded: directory_helper
INFO - 2021-07-12 11:56:46 --> Helper loaded: language_helper
INFO - 2021-07-12 11:56:46 --> Helper loaded: general_helper
INFO - 2021-07-12 11:56:46 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 11:56:46 --> Database Driver Class Initialized
DEBUG - 2021-07-12 11:56:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 11:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 11:56:46 --> Parser Class Initialized
INFO - 2021-07-12 11:56:46 --> Form Validation Class Initialized
INFO - 2021-07-12 11:56:46 --> Upload Class Initialized
INFO - 2021-07-12 11:56:46 --> Email Class Initialized
INFO - 2021-07-12 11:56:46 --> MY_Model class loaded
INFO - 2021-07-12 11:56:46 --> Model "Users_model" initialized
INFO - 2021-07-12 11:56:46 --> Model "Settings_model" initialized
INFO - 2021-07-12 11:56:46 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 11:56:46 --> Model "Permissions_model" initialized
INFO - 2021-07-12 11:56:46 --> Model "Roles_model" initialized
INFO - 2021-07-12 11:56:46 --> Model "Activity_model" initialized
INFO - 2021-07-12 11:56:46 --> Model "Templates_model" initialized
INFO - 2021-07-12 11:56:46 --> Database Driver Class Initialized
INFO - 2021-07-12 11:56:46 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 11:56:46 --> Controller Class Initialized
ERROR - 2021-07-12 11:56:46 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 11:56:46 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/musteri_bilgi_guncelleme.php
INFO - 2021-07-12 11:56:46 --> Final output sent to browser
DEBUG - 2021-07-12 11:56:46 --> Total execution time: 0.1344
INFO - 2021-07-12 11:56:52 --> Config Class Initialized
INFO - 2021-07-12 11:56:52 --> Hooks Class Initialized
DEBUG - 2021-07-12 11:56:52 --> UTF-8 Support Enabled
INFO - 2021-07-12 11:56:52 --> Utf8 Class Initialized
INFO - 2021-07-12 11:56:52 --> URI Class Initialized
INFO - 2021-07-12 11:56:52 --> Router Class Initialized
INFO - 2021-07-12 11:56:52 --> Output Class Initialized
INFO - 2021-07-12 11:56:52 --> Security Class Initialized
DEBUG - 2021-07-12 11:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 11:56:52 --> Input Class Initialized
INFO - 2021-07-12 11:56:52 --> Language Class Initialized
INFO - 2021-07-12 11:56:52 --> Loader Class Initialized
INFO - 2021-07-12 11:56:52 --> Helper loaded: basic_helper
INFO - 2021-07-12 11:56:52 --> Helper loaded: url_helper
INFO - 2021-07-12 11:56:52 --> Helper loaded: file_helper
INFO - 2021-07-12 11:56:52 --> Helper loaded: form_helper
INFO - 2021-07-12 11:56:52 --> Helper loaded: cookie_helper
INFO - 2021-07-12 11:56:52 --> Helper loaded: security_helper
INFO - 2021-07-12 11:56:52 --> Helper loaded: directory_helper
INFO - 2021-07-12 11:56:52 --> Helper loaded: language_helper
INFO - 2021-07-12 11:56:52 --> Helper loaded: general_helper
INFO - 2021-07-12 11:56:52 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 11:56:52 --> Database Driver Class Initialized
DEBUG - 2021-07-12 11:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 11:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 11:56:52 --> Parser Class Initialized
INFO - 2021-07-12 11:56:52 --> Form Validation Class Initialized
INFO - 2021-07-12 11:56:52 --> Upload Class Initialized
INFO - 2021-07-12 11:56:52 --> Email Class Initialized
INFO - 2021-07-12 11:56:52 --> MY_Model class loaded
INFO - 2021-07-12 11:56:52 --> Model "Users_model" initialized
INFO - 2021-07-12 11:56:52 --> Model "Settings_model" initialized
INFO - 2021-07-12 11:56:52 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 11:56:52 --> Model "Permissions_model" initialized
INFO - 2021-07-12 11:56:52 --> Model "Roles_model" initialized
INFO - 2021-07-12 11:56:52 --> Model "Activity_model" initialized
INFO - 2021-07-12 11:56:52 --> Model "Templates_model" initialized
INFO - 2021-07-12 11:56:52 --> Database Driver Class Initialized
INFO - 2021-07-12 11:56:52 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 11:56:52 --> Controller Class Initialized
ERROR - 2021-07-12 11:56:52 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 11:56:52 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-12 11:56:52 --> Final output sent to browser
DEBUG - 2021-07-12 11:56:52 --> Total execution time: 0.2410
INFO - 2021-07-12 11:56:55 --> Config Class Initialized
INFO - 2021-07-12 11:56:55 --> Hooks Class Initialized
DEBUG - 2021-07-12 11:56:55 --> UTF-8 Support Enabled
INFO - 2021-07-12 11:56:55 --> Utf8 Class Initialized
INFO - 2021-07-12 11:56:55 --> URI Class Initialized
INFO - 2021-07-12 11:56:55 --> Router Class Initialized
INFO - 2021-07-12 11:56:55 --> Output Class Initialized
INFO - 2021-07-12 11:56:55 --> Security Class Initialized
DEBUG - 2021-07-12 11:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 11:56:55 --> Input Class Initialized
INFO - 2021-07-12 11:56:55 --> Language Class Initialized
INFO - 2021-07-12 11:56:55 --> Loader Class Initialized
INFO - 2021-07-12 11:56:55 --> Helper loaded: basic_helper
INFO - 2021-07-12 11:56:55 --> Helper loaded: url_helper
INFO - 2021-07-12 11:56:55 --> Helper loaded: file_helper
INFO - 2021-07-12 11:56:55 --> Helper loaded: form_helper
INFO - 2021-07-12 11:56:55 --> Helper loaded: cookie_helper
INFO - 2021-07-12 11:56:55 --> Helper loaded: security_helper
INFO - 2021-07-12 11:56:55 --> Helper loaded: directory_helper
INFO - 2021-07-12 11:56:55 --> Helper loaded: language_helper
INFO - 2021-07-12 11:56:55 --> Helper loaded: general_helper
INFO - 2021-07-12 11:56:55 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 11:56:55 --> Database Driver Class Initialized
DEBUG - 2021-07-12 11:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 11:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 11:56:55 --> Parser Class Initialized
INFO - 2021-07-12 11:56:55 --> Form Validation Class Initialized
INFO - 2021-07-12 11:56:55 --> Upload Class Initialized
INFO - 2021-07-12 11:56:55 --> Email Class Initialized
INFO - 2021-07-12 11:56:55 --> MY_Model class loaded
INFO - 2021-07-12 11:56:55 --> Model "Users_model" initialized
INFO - 2021-07-12 11:56:55 --> Model "Settings_model" initialized
INFO - 2021-07-12 11:56:55 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 11:56:55 --> Model "Permissions_model" initialized
INFO - 2021-07-12 11:56:55 --> Model "Roles_model" initialized
INFO - 2021-07-12 11:56:55 --> Model "Activity_model" initialized
INFO - 2021-07-12 11:56:55 --> Model "Templates_model" initialized
INFO - 2021-07-12 11:56:55 --> Database Driver Class Initialized
INFO - 2021-07-12 11:56:55 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 11:56:55 --> Controller Class Initialized
ERROR - 2021-07-12 11:56:55 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 11:56:55 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-12 11:56:55 --> Final output sent to browser
DEBUG - 2021-07-12 11:56:55 --> Total execution time: 0.0683
INFO - 2021-07-12 11:57:14 --> Config Class Initialized
INFO - 2021-07-12 11:57:14 --> Hooks Class Initialized
DEBUG - 2021-07-12 11:57:14 --> UTF-8 Support Enabled
INFO - 2021-07-12 11:57:14 --> Utf8 Class Initialized
INFO - 2021-07-12 11:57:14 --> URI Class Initialized
INFO - 2021-07-12 11:57:14 --> Router Class Initialized
INFO - 2021-07-12 11:57:14 --> Output Class Initialized
INFO - 2021-07-12 11:57:14 --> Security Class Initialized
DEBUG - 2021-07-12 11:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 11:57:14 --> Input Class Initialized
INFO - 2021-07-12 11:57:14 --> Language Class Initialized
INFO - 2021-07-12 11:57:14 --> Loader Class Initialized
INFO - 2021-07-12 11:57:14 --> Helper loaded: basic_helper
INFO - 2021-07-12 11:57:14 --> Helper loaded: url_helper
INFO - 2021-07-12 11:57:14 --> Helper loaded: file_helper
INFO - 2021-07-12 11:57:14 --> Helper loaded: form_helper
INFO - 2021-07-12 11:57:14 --> Helper loaded: cookie_helper
INFO - 2021-07-12 11:57:14 --> Helper loaded: security_helper
INFO - 2021-07-12 11:57:14 --> Helper loaded: directory_helper
INFO - 2021-07-12 11:57:14 --> Helper loaded: language_helper
INFO - 2021-07-12 11:57:14 --> Helper loaded: general_helper
INFO - 2021-07-12 11:57:14 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 11:57:14 --> Database Driver Class Initialized
DEBUG - 2021-07-12 11:57:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 11:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 11:57:14 --> Parser Class Initialized
INFO - 2021-07-12 11:57:14 --> Form Validation Class Initialized
INFO - 2021-07-12 11:57:14 --> Upload Class Initialized
INFO - 2021-07-12 11:57:14 --> Email Class Initialized
INFO - 2021-07-12 11:57:14 --> MY_Model class loaded
INFO - 2021-07-12 11:57:14 --> Model "Users_model" initialized
INFO - 2021-07-12 11:57:14 --> Model "Settings_model" initialized
INFO - 2021-07-12 11:57:14 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 11:57:14 --> Model "Permissions_model" initialized
INFO - 2021-07-12 11:57:14 --> Model "Roles_model" initialized
INFO - 2021-07-12 11:57:14 --> Model "Activity_model" initialized
INFO - 2021-07-12 11:57:14 --> Model "Templates_model" initialized
INFO - 2021-07-12 11:57:14 --> Database Driver Class Initialized
INFO - 2021-07-12 11:57:14 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 11:57:14 --> Controller Class Initialized
ERROR - 2021-07-12 11:57:14 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 11:57:14 --> File loaded: C:\wamp64\www\crm\application\views\users/list.php
INFO - 2021-07-12 11:57:14 --> Final output sent to browser
DEBUG - 2021-07-12 11:57:14 --> Total execution time: 0.1778
INFO - 2021-07-12 11:57:14 --> Config Class Initialized
INFO - 2021-07-12 11:57:14 --> Hooks Class Initialized
DEBUG - 2021-07-12 11:57:14 --> UTF-8 Support Enabled
INFO - 2021-07-12 11:57:14 --> Utf8 Class Initialized
INFO - 2021-07-12 11:57:14 --> URI Class Initialized
INFO - 2021-07-12 11:57:14 --> Router Class Initialized
INFO - 2021-07-12 11:57:14 --> Output Class Initialized
INFO - 2021-07-12 11:57:14 --> Security Class Initialized
DEBUG - 2021-07-12 11:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 11:57:14 --> Input Class Initialized
INFO - 2021-07-12 11:57:14 --> Language Class Initialized
INFO - 2021-07-12 11:57:14 --> Loader Class Initialized
INFO - 2021-07-12 11:57:14 --> Helper loaded: basic_helper
INFO - 2021-07-12 11:57:14 --> Helper loaded: url_helper
INFO - 2021-07-12 11:57:14 --> Helper loaded: file_helper
INFO - 2021-07-12 11:57:14 --> Helper loaded: form_helper
INFO - 2021-07-12 11:57:14 --> Helper loaded: cookie_helper
INFO - 2021-07-12 11:57:14 --> Helper loaded: security_helper
INFO - 2021-07-12 11:57:14 --> Config Class Initialized
INFO - 2021-07-12 11:57:14 --> Helper loaded: directory_helper
INFO - 2021-07-12 11:57:14 --> Hooks Class Initialized
INFO - 2021-07-12 11:57:14 --> Helper loaded: language_helper
DEBUG - 2021-07-12 11:57:14 --> UTF-8 Support Enabled
INFO - 2021-07-12 11:57:14 --> Helper loaded: general_helper
INFO - 2021-07-12 11:57:14 --> Utf8 Class Initialized
INFO - 2021-07-12 11:57:14 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 11:57:14 --> URI Class Initialized
INFO - 2021-07-12 11:57:14 --> Database Driver Class Initialized
INFO - 2021-07-12 11:57:14 --> Router Class Initialized
INFO - 2021-07-12 11:57:14 --> Output Class Initialized
INFO - 2021-07-12 11:57:14 --> Security Class Initialized
DEBUG - 2021-07-12 11:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-12 11:57:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 11:57:14 --> Input Class Initialized
INFO - 2021-07-12 11:57:14 --> Config Class Initialized
INFO - 2021-07-12 11:57:14 --> Language Class Initialized
INFO - 2021-07-12 11:57:14 --> Hooks Class Initialized
INFO - 2021-07-12 11:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 11:57:14 --> Loader Class Initialized
DEBUG - 2021-07-12 11:57:14 --> UTF-8 Support Enabled
INFO - 2021-07-12 11:57:14 --> Utf8 Class Initialized
INFO - 2021-07-12 11:57:14 --> Parser Class Initialized
INFO - 2021-07-12 11:57:14 --> Helper loaded: basic_helper
INFO - 2021-07-12 11:57:14 --> URI Class Initialized
INFO - 2021-07-12 11:57:14 --> Helper loaded: url_helper
INFO - 2021-07-12 11:57:14 --> Form Validation Class Initialized
INFO - 2021-07-12 11:57:14 --> Router Class Initialized
INFO - 2021-07-12 11:57:14 --> Helper loaded: file_helper
INFO - 2021-07-12 11:57:14 --> Upload Class Initialized
INFO - 2021-07-12 11:57:14 --> Output Class Initialized
INFO - 2021-07-12 11:57:14 --> Config Class Initialized
INFO - 2021-07-12 11:57:14 --> Helper loaded: form_helper
INFO - 2021-07-12 11:57:14 --> Hooks Class Initialized
INFO - 2021-07-12 11:57:14 --> Security Class Initialized
INFO - 2021-07-12 11:57:14 --> Email Class Initialized
INFO - 2021-07-12 11:57:14 --> Helper loaded: cookie_helper
DEBUG - 2021-07-12 11:57:14 --> UTF-8 Support Enabled
DEBUG - 2021-07-12 11:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 11:57:14 --> MY_Model class loaded
INFO - 2021-07-12 11:57:14 --> Helper loaded: security_helper
INFO - 2021-07-12 11:57:14 --> Utf8 Class Initialized
INFO - 2021-07-12 11:57:14 --> Input Class Initialized
INFO - 2021-07-12 11:57:14 --> Model "Users_model" initialized
INFO - 2021-07-12 11:57:14 --> Helper loaded: directory_helper
INFO - 2021-07-12 11:57:14 --> Language Class Initialized
INFO - 2021-07-12 11:57:14 --> URI Class Initialized
INFO - 2021-07-12 11:57:14 --> Model "Settings_model" initialized
INFO - 2021-07-12 11:57:14 --> Helper loaded: language_helper
INFO - 2021-07-12 11:57:14 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 11:57:14 --> Loader Class Initialized
INFO - 2021-07-12 11:57:14 --> Router Class Initialized
INFO - 2021-07-12 11:57:14 --> Helper loaded: general_helper
INFO - 2021-07-12 11:57:14 --> Model "Permissions_model" initialized
INFO - 2021-07-12 11:57:14 --> Model "Roles_model" initialized
INFO - 2021-07-12 11:57:14 --> Output Class Initialized
INFO - 2021-07-12 11:57:14 --> Helper loaded: basic_helper
INFO - 2021-07-12 11:57:14 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 11:57:14 --> Model "Activity_model" initialized
INFO - 2021-07-12 11:57:14 --> Config Class Initialized
INFO - 2021-07-12 11:57:14 --> Security Class Initialized
INFO - 2021-07-12 11:57:14 --> Helper loaded: url_helper
INFO - 2021-07-12 11:57:14 --> Model "Templates_model" initialized
INFO - 2021-07-12 11:57:14 --> Hooks Class Initialized
INFO - 2021-07-12 11:57:14 --> Database Driver Class Initialized
DEBUG - 2021-07-12 11:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 11:57:14 --> Helper loaded: file_helper
INFO - 2021-07-12 11:57:14 --> Database Driver Class Initialized
INFO - 2021-07-12 11:57:14 --> Input Class Initialized
DEBUG - 2021-07-12 11:57:14 --> UTF-8 Support Enabled
INFO - 2021-07-12 11:57:14 --> Helper loaded: form_helper
INFO - 2021-07-12 11:57:14 --> Utf8 Class Initialized
INFO - 2021-07-12 11:57:14 --> Language Class Initialized
INFO - 2021-07-12 11:57:14 --> URI Class Initialized
INFO - 2021-07-12 11:57:14 --> Helper loaded: cookie_helper
INFO - 2021-07-12 11:57:14 --> Loader Class Initialized
DEBUG - 2021-07-12 11:57:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 11:57:14 --> Helper loaded: security_helper
INFO - 2021-07-12 11:57:14 --> Router Class Initialized
INFO - 2021-07-12 11:57:14 --> Helper loaded: basic_helper
INFO - 2021-07-12 11:57:14 --> Helper loaded: directory_helper
INFO - 2021-07-12 11:57:14 --> Output Class Initialized
INFO - 2021-07-12 11:57:14 --> Helper loaded: url_helper
INFO - 2021-07-12 11:57:14 --> Helper loaded: language_helper
INFO - 2021-07-12 11:57:14 --> Security Class Initialized
INFO - 2021-07-12 11:57:14 --> Helper loaded: file_helper
INFO - 2021-07-12 11:57:14 --> Helper loaded: general_helper
DEBUG - 2021-07-12 11:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 11:57:14 --> Helper loaded: form_helper
INFO - 2021-07-12 11:57:14 --> Input Class Initialized
INFO - 2021-07-12 11:57:14 --> Config Class Initialized
INFO - 2021-07-12 11:57:14 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 11:57:14 --> Helper loaded: cookie_helper
INFO - 2021-07-12 11:57:14 --> Hooks Class Initialized
INFO - 2021-07-12 11:57:14 --> Language Class Initialized
INFO - 2021-07-12 11:57:14 --> Helper loaded: security_helper
INFO - 2021-07-12 11:57:14 --> Database Driver Class Initialized
DEBUG - 2021-07-12 11:57:14 --> UTF-8 Support Enabled
INFO - 2021-07-12 11:57:14 --> Loader Class Initialized
INFO - 2021-07-12 11:57:14 --> Helper loaded: directory_helper
INFO - 2021-07-12 11:57:14 --> Utf8 Class Initialized
INFO - 2021-07-12 11:57:14 --> Helper loaded: language_helper
INFO - 2021-07-12 11:57:14 --> Helper loaded: basic_helper
INFO - 2021-07-12 11:57:14 --> URI Class Initialized
INFO - 2021-07-12 11:57:14 --> Helper loaded: general_helper
INFO - 2021-07-12 11:57:14 --> Helper loaded: url_helper
INFO - 2021-07-12 11:57:14 --> Router Class Initialized
INFO - 2021-07-12 11:57:14 --> Language file loaded: language/en/basic_lang.php
DEBUG - 2021-07-12 11:57:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 11:57:14 --> Helper loaded: file_helper
INFO - 2021-07-12 11:57:14 --> Output Class Initialized
INFO - 2021-07-12 11:57:14 --> Database Driver Class Initialized
INFO - 2021-07-12 11:57:14 --> Helper loaded: form_helper
INFO - 2021-07-12 11:57:14 --> Security Class Initialized
INFO - 2021-07-12 11:57:14 --> Helper loaded: cookie_helper
DEBUG - 2021-07-12 11:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 11:57:14 --> Helper loaded: security_helper
INFO - 2021-07-12 11:57:14 --> Input Class Initialized
INFO - 2021-07-12 11:57:14 --> Helper loaded: directory_helper
INFO - 2021-07-12 11:57:14 --> Language Class Initialized
INFO - 2021-07-12 11:57:14 --> Helper loaded: language_helper
INFO - 2021-07-12 11:57:14 --> Loader Class Initialized
INFO - 2021-07-12 11:57:14 --> Helper loaded: general_helper
INFO - 2021-07-12 11:57:14 --> Helper loaded: basic_helper
INFO - 2021-07-12 11:57:14 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 11:57:14 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 11:57:14 --> Helper loaded: url_helper
INFO - 2021-07-12 11:57:14 --> Controller Class Initialized
INFO - 2021-07-12 11:57:14 --> Database Driver Class Initialized
INFO - 2021-07-12 11:57:14 --> Helper loaded: file_helper
INFO - 2021-07-12 11:57:14 --> Helper loaded: form_helper
INFO - 2021-07-12 11:57:14 --> Helper loaded: cookie_helper
INFO - 2021-07-12 11:57:14 --> Helper loaded: security_helper
INFO - 2021-07-12 11:57:14 --> Final output sent to browser
DEBUG - 2021-07-12 11:57:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 11:57:14 --> Helper loaded: directory_helper
DEBUG - 2021-07-12 11:57:14 --> Total execution time: 0.0522
INFO - 2021-07-12 11:57:14 --> Helper loaded: language_helper
INFO - 2021-07-12 11:57:14 --> Helper loaded: general_helper
INFO - 2021-07-12 11:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 11:57:14 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 11:57:14 --> Parser Class Initialized
INFO - 2021-07-12 11:57:14 --> Database Driver Class Initialized
INFO - 2021-07-12 11:57:14 --> Form Validation Class Initialized
INFO - 2021-07-12 11:57:14 --> Upload Class Initialized
INFO - 2021-07-12 11:57:14 --> Email Class Initialized
DEBUG - 2021-07-12 11:57:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 11:57:14 --> MY_Model class loaded
INFO - 2021-07-12 11:57:14 --> Model "Users_model" initialized
INFO - 2021-07-12 11:57:14 --> Model "Settings_model" initialized
INFO - 2021-07-12 11:57:14 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 11:57:14 --> Model "Permissions_model" initialized
INFO - 2021-07-12 11:57:14 --> Model "Roles_model" initialized
INFO - 2021-07-12 11:57:14 --> Model "Activity_model" initialized
DEBUG - 2021-07-12 11:57:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 11:57:14 --> Model "Templates_model" initialized
INFO - 2021-07-12 11:57:14 --> Database Driver Class Initialized
INFO - 2021-07-12 11:57:14 --> Config Class Initialized
INFO - 2021-07-12 11:57:14 --> Hooks Class Initialized
DEBUG - 2021-07-12 11:57:14 --> UTF-8 Support Enabled
INFO - 2021-07-12 11:57:14 --> Utf8 Class Initialized
INFO - 2021-07-12 11:57:14 --> URI Class Initialized
INFO - 2021-07-12 11:57:14 --> Router Class Initialized
INFO - 2021-07-12 11:57:14 --> Output Class Initialized
INFO - 2021-07-12 11:57:14 --> Security Class Initialized
DEBUG - 2021-07-12 11:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 11:57:14 --> Input Class Initialized
INFO - 2021-07-12 11:57:14 --> Language Class Initialized
INFO - 2021-07-12 11:57:14 --> Loader Class Initialized
INFO - 2021-07-12 11:57:14 --> Helper loaded: basic_helper
INFO - 2021-07-12 11:57:14 --> Helper loaded: url_helper
INFO - 2021-07-12 11:57:14 --> Helper loaded: file_helper
INFO - 2021-07-12 11:57:14 --> Helper loaded: form_helper
INFO - 2021-07-12 11:57:14 --> Helper loaded: cookie_helper
INFO - 2021-07-12 11:57:14 --> Helper loaded: security_helper
INFO - 2021-07-12 11:57:14 --> Helper loaded: directory_helper
INFO - 2021-07-12 11:57:14 --> Helper loaded: language_helper
INFO - 2021-07-12 11:57:14 --> Helper loaded: general_helper
INFO - 2021-07-12 11:57:14 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 11:57:14 --> Controller Class Initialized
INFO - 2021-07-12 11:57:14 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 11:57:14 --> Database Driver Class Initialized
INFO - 2021-07-12 11:57:14 --> Final output sent to browser
DEBUG - 2021-07-12 11:57:14 --> Total execution time: 0.0712
DEBUG - 2021-07-12 11:57:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 11:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 11:57:14 --> Parser Class Initialized
INFO - 2021-07-12 11:57:14 --> Form Validation Class Initialized
INFO - 2021-07-12 11:57:14 --> Upload Class Initialized
INFO - 2021-07-12 11:57:14 --> Email Class Initialized
INFO - 2021-07-12 11:57:14 --> MY_Model class loaded
INFO - 2021-07-12 11:57:14 --> Model "Users_model" initialized
INFO - 2021-07-12 11:57:14 --> Model "Settings_model" initialized
INFO - 2021-07-12 11:57:14 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 11:57:14 --> Model "Permissions_model" initialized
INFO - 2021-07-12 11:57:14 --> Model "Roles_model" initialized
INFO - 2021-07-12 11:57:14 --> Model "Activity_model" initialized
INFO - 2021-07-12 11:57:14 --> Model "Templates_model" initialized
INFO - 2021-07-12 11:57:14 --> Database Driver Class Initialized
INFO - 2021-07-12 11:57:14 --> Config Class Initialized
INFO - 2021-07-12 11:57:14 --> Hooks Class Initialized
DEBUG - 2021-07-12 11:57:14 --> UTF-8 Support Enabled
INFO - 2021-07-12 11:57:14 --> Utf8 Class Initialized
INFO - 2021-07-12 11:57:14 --> URI Class Initialized
INFO - 2021-07-12 11:57:14 --> Router Class Initialized
INFO - 2021-07-12 11:57:14 --> Output Class Initialized
INFO - 2021-07-12 11:57:14 --> Security Class Initialized
DEBUG - 2021-07-12 11:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 11:57:14 --> Input Class Initialized
INFO - 2021-07-12 11:57:14 --> Language Class Initialized
INFO - 2021-07-12 11:57:14 --> Loader Class Initialized
INFO - 2021-07-12 11:57:14 --> Helper loaded: basic_helper
INFO - 2021-07-12 11:57:14 --> Helper loaded: url_helper
INFO - 2021-07-12 11:57:14 --> Helper loaded: file_helper
INFO - 2021-07-12 11:57:14 --> Helper loaded: form_helper
INFO - 2021-07-12 11:57:14 --> Helper loaded: cookie_helper
INFO - 2021-07-12 11:57:14 --> Helper loaded: security_helper
INFO - 2021-07-12 11:57:14 --> Helper loaded: directory_helper
INFO - 2021-07-12 11:57:14 --> Helper loaded: language_helper
INFO - 2021-07-12 11:57:14 --> Helper loaded: general_helper
INFO - 2021-07-12 11:57:14 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 11:57:14 --> Database Driver Class Initialized
INFO - 2021-07-12 11:57:14 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 11:57:14 --> Controller Class Initialized
DEBUG - 2021-07-12 11:57:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 11:57:14 --> Final output sent to browser
DEBUG - 2021-07-12 11:57:14 --> Total execution time: 0.0956
INFO - 2021-07-12 11:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 11:57:14 --> Parser Class Initialized
INFO - 2021-07-12 11:57:14 --> Form Validation Class Initialized
INFO - 2021-07-12 11:57:14 --> Upload Class Initialized
INFO - 2021-07-12 11:57:14 --> Email Class Initialized
INFO - 2021-07-12 11:57:14 --> MY_Model class loaded
INFO - 2021-07-12 11:57:14 --> Model "Users_model" initialized
INFO - 2021-07-12 11:57:14 --> Model "Settings_model" initialized
INFO - 2021-07-12 11:57:14 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 11:57:14 --> Model "Permissions_model" initialized
INFO - 2021-07-12 11:57:14 --> Model "Roles_model" initialized
INFO - 2021-07-12 11:57:14 --> Model "Activity_model" initialized
INFO - 2021-07-12 11:57:14 --> Model "Templates_model" initialized
INFO - 2021-07-12 11:57:14 --> Database Driver Class Initialized
INFO - 2021-07-12 11:57:14 --> Config Class Initialized
INFO - 2021-07-12 11:57:14 --> Hooks Class Initialized
DEBUG - 2021-07-12 11:57:14 --> UTF-8 Support Enabled
INFO - 2021-07-12 11:57:14 --> Utf8 Class Initialized
INFO - 2021-07-12 11:57:14 --> URI Class Initialized
INFO - 2021-07-12 11:57:14 --> Router Class Initialized
INFO - 2021-07-12 11:57:14 --> Output Class Initialized
INFO - 2021-07-12 11:57:14 --> Security Class Initialized
DEBUG - 2021-07-12 11:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 11:57:14 --> Input Class Initialized
INFO - 2021-07-12 11:57:14 --> Language Class Initialized
INFO - 2021-07-12 11:57:14 --> Loader Class Initialized
INFO - 2021-07-12 11:57:14 --> Helper loaded: basic_helper
INFO - 2021-07-12 11:57:14 --> Helper loaded: url_helper
INFO - 2021-07-12 11:57:14 --> Helper loaded: file_helper
INFO - 2021-07-12 11:57:14 --> Helper loaded: form_helper
INFO - 2021-07-12 11:57:14 --> Helper loaded: cookie_helper
INFO - 2021-07-12 11:57:14 --> Helper loaded: security_helper
INFO - 2021-07-12 11:57:14 --> Helper loaded: directory_helper
INFO - 2021-07-12 11:57:14 --> Helper loaded: language_helper
INFO - 2021-07-12 11:57:14 --> Helper loaded: general_helper
INFO - 2021-07-12 11:57:14 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 11:57:14 --> Database Driver Class Initialized
INFO - 2021-07-12 11:57:14 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 11:57:14 --> Controller Class Initialized
INFO - 2021-07-12 11:57:14 --> Final output sent to browser
DEBUG - 2021-07-12 11:57:14 --> Total execution time: 0.1131
INFO - 2021-07-12 11:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 11:57:14 --> Parser Class Initialized
INFO - 2021-07-12 11:57:14 --> Form Validation Class Initialized
INFO - 2021-07-12 11:57:14 --> Upload Class Initialized
INFO - 2021-07-12 11:57:14 --> Email Class Initialized
INFO - 2021-07-12 11:57:14 --> MY_Model class loaded
INFO - 2021-07-12 11:57:14 --> Model "Users_model" initialized
INFO - 2021-07-12 11:57:14 --> Model "Settings_model" initialized
INFO - 2021-07-12 11:57:14 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 11:57:14 --> Model "Permissions_model" initialized
INFO - 2021-07-12 11:57:14 --> Model "Roles_model" initialized
INFO - 2021-07-12 11:57:14 --> Model "Activity_model" initialized
INFO - 2021-07-12 11:57:14 --> Model "Templates_model" initialized
INFO - 2021-07-12 11:57:14 --> Database Driver Class Initialized
DEBUG - 2021-07-12 11:57:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 11:57:14 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 11:57:14 --> Controller Class Initialized
INFO - 2021-07-12 11:57:14 --> Final output sent to browser
DEBUG - 2021-07-12 11:57:14 --> Total execution time: 0.1352
INFO - 2021-07-12 11:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 11:57:14 --> Parser Class Initialized
INFO - 2021-07-12 11:57:14 --> Form Validation Class Initialized
INFO - 2021-07-12 11:57:14 --> Upload Class Initialized
INFO - 2021-07-12 11:57:14 --> Email Class Initialized
INFO - 2021-07-12 11:57:14 --> MY_Model class loaded
INFO - 2021-07-12 11:57:14 --> Model "Users_model" initialized
INFO - 2021-07-12 11:57:14 --> Model "Settings_model" initialized
INFO - 2021-07-12 11:57:14 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 11:57:14 --> Model "Permissions_model" initialized
INFO - 2021-07-12 11:57:14 --> Model "Roles_model" initialized
INFO - 2021-07-12 11:57:14 --> Model "Activity_model" initialized
INFO - 2021-07-12 11:57:14 --> Model "Templates_model" initialized
INFO - 2021-07-12 11:57:14 --> Database Driver Class Initialized
INFO - 2021-07-12 11:57:14 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 11:57:14 --> Controller Class Initialized
INFO - 2021-07-12 11:57:14 --> Final output sent to browser
DEBUG - 2021-07-12 11:57:14 --> Total execution time: 0.1811
INFO - 2021-07-12 11:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 11:57:14 --> Parser Class Initialized
INFO - 2021-07-12 11:57:14 --> Form Validation Class Initialized
INFO - 2021-07-12 11:57:14 --> Upload Class Initialized
INFO - 2021-07-12 11:57:14 --> Email Class Initialized
INFO - 2021-07-12 11:57:14 --> MY_Model class loaded
INFO - 2021-07-12 11:57:14 --> Model "Users_model" initialized
INFO - 2021-07-12 11:57:14 --> Model "Settings_model" initialized
INFO - 2021-07-12 11:57:14 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 11:57:14 --> Model "Permissions_model" initialized
INFO - 2021-07-12 11:57:14 --> Model "Roles_model" initialized
INFO - 2021-07-12 11:57:14 --> Model "Activity_model" initialized
INFO - 2021-07-12 11:57:14 --> Model "Templates_model" initialized
INFO - 2021-07-12 11:57:14 --> Database Driver Class Initialized
INFO - 2021-07-12 11:57:14 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 11:57:14 --> Controller Class Initialized
INFO - 2021-07-12 11:57:14 --> Final output sent to browser
DEBUG - 2021-07-12 11:57:14 --> Total execution time: 0.1702
INFO - 2021-07-12 11:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 11:57:14 --> Parser Class Initialized
INFO - 2021-07-12 11:57:14 --> Form Validation Class Initialized
INFO - 2021-07-12 11:57:14 --> Upload Class Initialized
INFO - 2021-07-12 11:57:14 --> Email Class Initialized
INFO - 2021-07-12 11:57:14 --> MY_Model class loaded
INFO - 2021-07-12 11:57:14 --> Model "Users_model" initialized
INFO - 2021-07-12 11:57:14 --> Model "Settings_model" initialized
INFO - 2021-07-12 11:57:14 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 11:57:14 --> Model "Permissions_model" initialized
INFO - 2021-07-12 11:57:14 --> Model "Roles_model" initialized
INFO - 2021-07-12 11:57:14 --> Model "Activity_model" initialized
INFO - 2021-07-12 11:57:14 --> Model "Templates_model" initialized
INFO - 2021-07-12 11:57:14 --> Database Driver Class Initialized
INFO - 2021-07-12 11:57:14 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 11:57:14 --> Controller Class Initialized
INFO - 2021-07-12 11:57:14 --> Final output sent to browser
DEBUG - 2021-07-12 11:57:14 --> Total execution time: 0.1715
INFO - 2021-07-12 11:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 11:57:14 --> Parser Class Initialized
INFO - 2021-07-12 11:57:14 --> Form Validation Class Initialized
INFO - 2021-07-12 11:57:14 --> Upload Class Initialized
INFO - 2021-07-12 11:57:14 --> Email Class Initialized
INFO - 2021-07-12 11:57:14 --> MY_Model class loaded
INFO - 2021-07-12 11:57:14 --> Model "Users_model" initialized
INFO - 2021-07-12 11:57:14 --> Model "Settings_model" initialized
INFO - 2021-07-12 11:57:14 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 11:57:14 --> Model "Permissions_model" initialized
INFO - 2021-07-12 11:57:14 --> Model "Roles_model" initialized
INFO - 2021-07-12 11:57:14 --> Model "Activity_model" initialized
INFO - 2021-07-12 11:57:14 --> Model "Templates_model" initialized
INFO - 2021-07-12 11:57:14 --> Database Driver Class Initialized
INFO - 2021-07-12 11:57:14 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 11:57:14 --> Controller Class Initialized
INFO - 2021-07-12 11:57:14 --> Final output sent to browser
DEBUG - 2021-07-12 11:57:14 --> Total execution time: 0.1714
INFO - 2021-07-12 11:58:01 --> Config Class Initialized
INFO - 2021-07-12 11:58:01 --> Hooks Class Initialized
DEBUG - 2021-07-12 11:58:01 --> UTF-8 Support Enabled
INFO - 2021-07-12 11:58:01 --> Utf8 Class Initialized
INFO - 2021-07-12 11:58:01 --> URI Class Initialized
INFO - 2021-07-12 11:58:01 --> Router Class Initialized
INFO - 2021-07-12 11:58:01 --> Output Class Initialized
INFO - 2021-07-12 11:58:01 --> Security Class Initialized
DEBUG - 2021-07-12 11:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 11:58:01 --> Input Class Initialized
INFO - 2021-07-12 11:58:01 --> Language Class Initialized
INFO - 2021-07-12 11:58:01 --> Loader Class Initialized
INFO - 2021-07-12 11:58:01 --> Helper loaded: basic_helper
INFO - 2021-07-12 11:58:01 --> Helper loaded: url_helper
INFO - 2021-07-12 11:58:01 --> Helper loaded: file_helper
INFO - 2021-07-12 11:58:01 --> Helper loaded: form_helper
INFO - 2021-07-12 11:58:01 --> Helper loaded: cookie_helper
INFO - 2021-07-12 11:58:01 --> Helper loaded: security_helper
INFO - 2021-07-12 11:58:01 --> Helper loaded: directory_helper
INFO - 2021-07-12 11:58:01 --> Helper loaded: language_helper
INFO - 2021-07-12 11:58:01 --> Helper loaded: general_helper
INFO - 2021-07-12 11:58:01 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 11:58:01 --> Database Driver Class Initialized
DEBUG - 2021-07-12 11:58:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 11:58:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 11:58:01 --> Parser Class Initialized
INFO - 2021-07-12 11:58:01 --> Form Validation Class Initialized
INFO - 2021-07-12 11:58:01 --> Upload Class Initialized
INFO - 2021-07-12 11:58:01 --> Email Class Initialized
INFO - 2021-07-12 11:58:01 --> MY_Model class loaded
INFO - 2021-07-12 11:58:01 --> Model "Users_model" initialized
INFO - 2021-07-12 11:58:01 --> Model "Settings_model" initialized
INFO - 2021-07-12 11:58:01 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 11:58:01 --> Model "Permissions_model" initialized
INFO - 2021-07-12 11:58:01 --> Model "Roles_model" initialized
INFO - 2021-07-12 11:58:01 --> Model "Activity_model" initialized
INFO - 2021-07-12 11:58:01 --> Model "Templates_model" initialized
INFO - 2021-07-12 11:58:01 --> Database Driver Class Initialized
INFO - 2021-07-12 11:58:01 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 11:58:01 --> Controller Class Initialized
ERROR - 2021-07-12 11:58:01 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 11:58:01 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-12 11:58:01 --> Final output sent to browser
DEBUG - 2021-07-12 11:58:01 --> Total execution time: 0.2327
INFO - 2021-07-12 11:58:03 --> Config Class Initialized
INFO - 2021-07-12 11:58:03 --> Hooks Class Initialized
DEBUG - 2021-07-12 11:58:03 --> UTF-8 Support Enabled
INFO - 2021-07-12 11:58:03 --> Utf8 Class Initialized
INFO - 2021-07-12 11:58:03 --> URI Class Initialized
INFO - 2021-07-12 11:58:03 --> Router Class Initialized
INFO - 2021-07-12 11:58:03 --> Output Class Initialized
INFO - 2021-07-12 11:58:03 --> Security Class Initialized
DEBUG - 2021-07-12 11:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 11:58:03 --> Input Class Initialized
INFO - 2021-07-12 11:58:03 --> Language Class Initialized
INFO - 2021-07-12 11:58:03 --> Loader Class Initialized
INFO - 2021-07-12 11:58:03 --> Helper loaded: basic_helper
INFO - 2021-07-12 11:58:03 --> Helper loaded: url_helper
INFO - 2021-07-12 11:58:03 --> Helper loaded: file_helper
INFO - 2021-07-12 11:58:03 --> Helper loaded: form_helper
INFO - 2021-07-12 11:58:03 --> Helper loaded: cookie_helper
INFO - 2021-07-12 11:58:03 --> Helper loaded: security_helper
INFO - 2021-07-12 11:58:03 --> Helper loaded: directory_helper
INFO - 2021-07-12 11:58:03 --> Helper loaded: language_helper
INFO - 2021-07-12 11:58:03 --> Helper loaded: general_helper
INFO - 2021-07-12 11:58:03 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 11:58:03 --> Database Driver Class Initialized
DEBUG - 2021-07-12 11:58:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 11:58:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 11:58:03 --> Parser Class Initialized
INFO - 2021-07-12 11:58:03 --> Form Validation Class Initialized
INFO - 2021-07-12 11:58:03 --> Upload Class Initialized
INFO - 2021-07-12 11:58:03 --> Email Class Initialized
INFO - 2021-07-12 11:58:03 --> MY_Model class loaded
INFO - 2021-07-12 11:58:03 --> Model "Users_model" initialized
INFO - 2021-07-12 11:58:03 --> Model "Settings_model" initialized
INFO - 2021-07-12 11:58:03 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 11:58:03 --> Model "Permissions_model" initialized
INFO - 2021-07-12 11:58:03 --> Model "Roles_model" initialized
INFO - 2021-07-12 11:58:03 --> Model "Activity_model" initialized
INFO - 2021-07-12 11:58:03 --> Model "Templates_model" initialized
INFO - 2021-07-12 11:58:03 --> Database Driver Class Initialized
INFO - 2021-07-12 11:58:03 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 11:58:03 --> Controller Class Initialized
ERROR - 2021-07-12 11:58:03 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 11:58:04 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-12 11:58:04 --> Final output sent to browser
DEBUG - 2021-07-12 11:58:04 --> Total execution time: 0.1709
INFO - 2021-07-12 11:58:40 --> Config Class Initialized
INFO - 2021-07-12 11:58:40 --> Hooks Class Initialized
DEBUG - 2021-07-12 11:58:40 --> UTF-8 Support Enabled
INFO - 2021-07-12 11:58:40 --> Utf8 Class Initialized
INFO - 2021-07-12 11:58:40 --> URI Class Initialized
INFO - 2021-07-12 11:58:40 --> Router Class Initialized
INFO - 2021-07-12 11:58:40 --> Output Class Initialized
INFO - 2021-07-12 11:58:40 --> Security Class Initialized
DEBUG - 2021-07-12 11:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 11:58:40 --> Input Class Initialized
INFO - 2021-07-12 11:58:40 --> Language Class Initialized
INFO - 2021-07-12 11:58:40 --> Loader Class Initialized
INFO - 2021-07-12 11:58:40 --> Helper loaded: basic_helper
INFO - 2021-07-12 11:58:40 --> Helper loaded: url_helper
INFO - 2021-07-12 11:58:40 --> Helper loaded: file_helper
INFO - 2021-07-12 11:58:40 --> Helper loaded: form_helper
INFO - 2021-07-12 11:58:40 --> Helper loaded: cookie_helper
INFO - 2021-07-12 11:58:40 --> Helper loaded: security_helper
INFO - 2021-07-12 11:58:40 --> Helper loaded: directory_helper
INFO - 2021-07-12 11:58:40 --> Helper loaded: language_helper
INFO - 2021-07-12 11:58:40 --> Helper loaded: general_helper
INFO - 2021-07-12 11:58:40 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 11:58:40 --> Database Driver Class Initialized
DEBUG - 2021-07-12 11:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 11:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 11:58:40 --> Parser Class Initialized
INFO - 2021-07-12 11:58:40 --> Form Validation Class Initialized
INFO - 2021-07-12 11:58:40 --> Upload Class Initialized
INFO - 2021-07-12 11:58:40 --> Email Class Initialized
INFO - 2021-07-12 11:58:40 --> MY_Model class loaded
INFO - 2021-07-12 11:58:40 --> Model "Users_model" initialized
INFO - 2021-07-12 11:58:40 --> Model "Settings_model" initialized
INFO - 2021-07-12 11:58:40 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 11:58:40 --> Model "Permissions_model" initialized
INFO - 2021-07-12 11:58:40 --> Model "Roles_model" initialized
INFO - 2021-07-12 11:58:40 --> Model "Activity_model" initialized
INFO - 2021-07-12 11:58:40 --> Model "Templates_model" initialized
INFO - 2021-07-12 11:58:40 --> Database Driver Class Initialized
INFO - 2021-07-12 11:58:40 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 11:58:40 --> Controller Class Initialized
ERROR - 2021-07-12 11:58:40 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 11:58:40 --> File loaded: C:\wamp64\www\crm\application\views\users/list.php
INFO - 2021-07-12 11:58:40 --> Final output sent to browser
DEBUG - 2021-07-12 11:58:40 --> Total execution time: 0.1759
INFO - 2021-07-12 11:58:40 --> Config Class Initialized
INFO - 2021-07-12 11:58:40 --> Hooks Class Initialized
DEBUG - 2021-07-12 11:58:40 --> UTF-8 Support Enabled
INFO - 2021-07-12 11:58:41 --> Utf8 Class Initialized
INFO - 2021-07-12 11:58:41 --> URI Class Initialized
INFO - 2021-07-12 11:58:41 --> Router Class Initialized
INFO - 2021-07-12 11:58:41 --> Output Class Initialized
INFO - 2021-07-12 11:58:41 --> Security Class Initialized
DEBUG - 2021-07-12 11:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 11:58:41 --> Input Class Initialized
INFO - 2021-07-12 11:58:41 --> Language Class Initialized
INFO - 2021-07-12 11:58:41 --> Loader Class Initialized
INFO - 2021-07-12 11:58:41 --> Helper loaded: basic_helper
INFO - 2021-07-12 11:58:41 --> Helper loaded: url_helper
INFO - 2021-07-12 11:58:41 --> Helper loaded: file_helper
INFO - 2021-07-12 11:58:41 --> Helper loaded: form_helper
INFO - 2021-07-12 11:58:41 --> Helper loaded: cookie_helper
INFO - 2021-07-12 11:58:41 --> Helper loaded: security_helper
INFO - 2021-07-12 11:58:41 --> Helper loaded: directory_helper
INFO - 2021-07-12 11:58:41 --> Helper loaded: language_helper
INFO - 2021-07-12 11:58:41 --> Config Class Initialized
INFO - 2021-07-12 11:58:41 --> Hooks Class Initialized
INFO - 2021-07-12 11:58:41 --> Helper loaded: general_helper
DEBUG - 2021-07-12 11:58:41 --> UTF-8 Support Enabled
INFO - 2021-07-12 11:58:41 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 11:58:41 --> Utf8 Class Initialized
INFO - 2021-07-12 11:58:41 --> Database Driver Class Initialized
INFO - 2021-07-12 11:58:41 --> URI Class Initialized
INFO - 2021-07-12 11:58:41 --> Router Class Initialized
INFO - 2021-07-12 11:58:41 --> Output Class Initialized
INFO - 2021-07-12 11:58:41 --> Security Class Initialized
DEBUG - 2021-07-12 11:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-07-12 11:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 11:58:41 --> Input Class Initialized
INFO - 2021-07-12 11:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 11:58:41 --> Config Class Initialized
INFO - 2021-07-12 11:58:41 --> Language Class Initialized
INFO - 2021-07-12 11:58:41 --> Hooks Class Initialized
INFO - 2021-07-12 11:58:41 --> Parser Class Initialized
DEBUG - 2021-07-12 11:58:41 --> UTF-8 Support Enabled
INFO - 2021-07-12 11:58:41 --> Loader Class Initialized
INFO - 2021-07-12 11:58:41 --> Form Validation Class Initialized
INFO - 2021-07-12 11:58:41 --> Utf8 Class Initialized
INFO - 2021-07-12 11:58:41 --> Helper loaded: basic_helper
INFO - 2021-07-12 11:58:41 --> URI Class Initialized
INFO - 2021-07-12 11:58:41 --> Upload Class Initialized
INFO - 2021-07-12 11:58:41 --> Helper loaded: url_helper
INFO - 2021-07-12 11:58:41 --> Router Class Initialized
INFO - 2021-07-12 11:58:41 --> Helper loaded: file_helper
INFO - 2021-07-12 11:58:41 --> Email Class Initialized
INFO - 2021-07-12 11:58:41 --> Output Class Initialized
INFO - 2021-07-12 11:58:41 --> MY_Model class loaded
INFO - 2021-07-12 11:58:41 --> Helper loaded: form_helper
INFO - 2021-07-12 11:58:41 --> Model "Users_model" initialized
INFO - 2021-07-12 11:58:41 --> Security Class Initialized
INFO - 2021-07-12 11:58:41 --> Helper loaded: cookie_helper
INFO - 2021-07-12 11:58:41 --> Model "Settings_model" initialized
DEBUG - 2021-07-12 11:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 11:58:41 --> Helper loaded: security_helper
INFO - 2021-07-12 11:58:41 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 11:58:41 --> Input Class Initialized
INFO - 2021-07-12 11:58:41 --> Config Class Initialized
INFO - 2021-07-12 11:58:41 --> Model "Permissions_model" initialized
INFO - 2021-07-12 11:58:41 --> Helper loaded: directory_helper
INFO - 2021-07-12 11:58:41 --> Hooks Class Initialized
INFO - 2021-07-12 11:58:41 --> Language Class Initialized
INFO - 2021-07-12 11:58:41 --> Model "Roles_model" initialized
INFO - 2021-07-12 11:58:41 --> Helper loaded: language_helper
INFO - 2021-07-12 11:58:41 --> Model "Activity_model" initialized
DEBUG - 2021-07-12 11:58:41 --> UTF-8 Support Enabled
INFO - 2021-07-12 11:58:41 --> Loader Class Initialized
INFO - 2021-07-12 11:58:41 --> Utf8 Class Initialized
INFO - 2021-07-12 11:58:41 --> Model "Templates_model" initialized
INFO - 2021-07-12 11:58:41 --> Helper loaded: general_helper
INFO - 2021-07-12 11:58:41 --> URI Class Initialized
INFO - 2021-07-12 11:58:41 --> Helper loaded: basic_helper
INFO - 2021-07-12 11:58:41 --> Database Driver Class Initialized
INFO - 2021-07-12 11:58:41 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 11:58:41 --> Helper loaded: url_helper
INFO - 2021-07-12 11:58:41 --> Router Class Initialized
INFO - 2021-07-12 11:58:41 --> Database Driver Class Initialized
INFO - 2021-07-12 11:58:41 --> Helper loaded: file_helper
INFO - 2021-07-12 11:58:41 --> Config Class Initialized
INFO - 2021-07-12 11:58:41 --> Output Class Initialized
INFO - 2021-07-12 11:58:41 --> Hooks Class Initialized
INFO - 2021-07-12 11:58:41 --> Helper loaded: form_helper
INFO - 2021-07-12 11:58:41 --> Security Class Initialized
DEBUG - 2021-07-12 11:58:41 --> UTF-8 Support Enabled
INFO - 2021-07-12 11:58:41 --> Helper loaded: cookie_helper
INFO - 2021-07-12 11:58:41 --> Utf8 Class Initialized
DEBUG - 2021-07-12 11:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 11:58:41 --> Helper loaded: security_helper
INFO - 2021-07-12 11:58:41 --> Input Class Initialized
INFO - 2021-07-12 11:58:41 --> URI Class Initialized
DEBUG - 2021-07-12 11:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 11:58:41 --> Helper loaded: directory_helper
INFO - 2021-07-12 11:58:41 --> Language Class Initialized
INFO - 2021-07-12 11:58:41 --> Router Class Initialized
INFO - 2021-07-12 11:58:41 --> Helper loaded: language_helper
INFO - 2021-07-12 11:58:41 --> Loader Class Initialized
INFO - 2021-07-12 11:58:41 --> Helper loaded: general_helper
INFO - 2021-07-12 11:58:41 --> Output Class Initialized
INFO - 2021-07-12 11:58:41 --> Helper loaded: basic_helper
INFO - 2021-07-12 11:58:41 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 11:58:41 --> Security Class Initialized
INFO - 2021-07-12 11:58:41 --> Helper loaded: url_helper
INFO - 2021-07-12 11:58:41 --> Database Driver Class Initialized
DEBUG - 2021-07-12 11:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 11:58:41 --> Config Class Initialized
INFO - 2021-07-12 11:58:41 --> Input Class Initialized
INFO - 2021-07-12 11:58:41 --> Helper loaded: file_helper
INFO - 2021-07-12 11:58:41 --> Hooks Class Initialized
INFO - 2021-07-12 11:58:41 --> Language Class Initialized
INFO - 2021-07-12 11:58:41 --> Helper loaded: form_helper
DEBUG - 2021-07-12 11:58:41 --> UTF-8 Support Enabled
INFO - 2021-07-12 11:58:41 --> Utf8 Class Initialized
INFO - 2021-07-12 11:58:41 --> Loader Class Initialized
INFO - 2021-07-12 11:58:41 --> Helper loaded: cookie_helper
DEBUG - 2021-07-12 11:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 11:58:41 --> URI Class Initialized
INFO - 2021-07-12 11:58:41 --> Helper loaded: security_helper
INFO - 2021-07-12 11:58:41 --> Helper loaded: basic_helper
INFO - 2021-07-12 11:58:41 --> Helper loaded: directory_helper
INFO - 2021-07-12 11:58:41 --> Router Class Initialized
INFO - 2021-07-12 11:58:41 --> Helper loaded: url_helper
INFO - 2021-07-12 11:58:41 --> Helper loaded: language_helper
INFO - 2021-07-12 11:58:41 --> Output Class Initialized
INFO - 2021-07-12 11:58:41 --> Helper loaded: file_helper
INFO - 2021-07-12 11:58:41 --> Helper loaded: general_helper
INFO - 2021-07-12 11:58:41 --> Security Class Initialized
INFO - 2021-07-12 11:58:41 --> Helper loaded: form_helper
INFO - 2021-07-12 11:58:41 --> Language file loaded: language/en/basic_lang.php
DEBUG - 2021-07-12 11:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 11:58:41 --> Helper loaded: cookie_helper
INFO - 2021-07-12 11:58:41 --> Input Class Initialized
INFO - 2021-07-12 11:58:41 --> Database Driver Class Initialized
INFO - 2021-07-12 11:58:41 --> Helper loaded: security_helper
INFO - 2021-07-12 11:58:41 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 11:58:41 --> Language Class Initialized
INFO - 2021-07-12 11:58:41 --> Controller Class Initialized
INFO - 2021-07-12 11:58:41 --> Helper loaded: directory_helper
INFO - 2021-07-12 11:58:41 --> Loader Class Initialized
INFO - 2021-07-12 11:58:41 --> Helper loaded: language_helper
INFO - 2021-07-12 11:58:41 --> Helper loaded: general_helper
INFO - 2021-07-12 11:58:41 --> Helper loaded: basic_helper
DEBUG - 2021-07-12 11:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 11:58:41 --> Final output sent to browser
INFO - 2021-07-12 11:58:41 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 11:58:41 --> Helper loaded: url_helper
DEBUG - 2021-07-12 11:58:41 --> Total execution time: 0.0503
INFO - 2021-07-12 11:58:41 --> Database Driver Class Initialized
INFO - 2021-07-12 11:58:41 --> Helper loaded: file_helper
INFO - 2021-07-12 11:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 11:58:41 --> Helper loaded: form_helper
INFO - 2021-07-12 11:58:41 --> Parser Class Initialized
INFO - 2021-07-12 11:58:41 --> Helper loaded: cookie_helper
INFO - 2021-07-12 11:58:41 --> Form Validation Class Initialized
DEBUG - 2021-07-12 11:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 11:58:41 --> Helper loaded: security_helper
INFO - 2021-07-12 11:58:41 --> Helper loaded: directory_helper
INFO - 2021-07-12 11:58:41 --> Upload Class Initialized
INFO - 2021-07-12 11:58:41 --> Helper loaded: language_helper
INFO - 2021-07-12 11:58:41 --> Email Class Initialized
INFO - 2021-07-12 11:58:41 --> Helper loaded: general_helper
INFO - 2021-07-12 11:58:41 --> MY_Model class loaded
INFO - 2021-07-12 11:58:41 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 11:58:41 --> Model "Users_model" initialized
INFO - 2021-07-12 11:58:41 --> Database Driver Class Initialized
INFO - 2021-07-12 11:58:41 --> Model "Settings_model" initialized
INFO - 2021-07-12 11:58:41 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 11:58:41 --> Model "Permissions_model" initialized
INFO - 2021-07-12 11:58:41 --> Model "Roles_model" initialized
INFO - 2021-07-12 11:58:41 --> Model "Activity_model" initialized
INFO - 2021-07-12 11:58:41 --> Model "Templates_model" initialized
DEBUG - 2021-07-12 11:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 11:58:41 --> Database Driver Class Initialized
INFO - 2021-07-12 11:58:41 --> Config Class Initialized
INFO - 2021-07-12 11:58:41 --> Hooks Class Initialized
DEBUG - 2021-07-12 11:58:41 --> UTF-8 Support Enabled
INFO - 2021-07-12 11:58:41 --> Utf8 Class Initialized
INFO - 2021-07-12 11:58:41 --> URI Class Initialized
INFO - 2021-07-12 11:58:41 --> Router Class Initialized
INFO - 2021-07-12 11:58:41 --> Output Class Initialized
INFO - 2021-07-12 11:58:41 --> Security Class Initialized
DEBUG - 2021-07-12 11:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 11:58:41 --> Input Class Initialized
INFO - 2021-07-12 11:58:41 --> Language Class Initialized
INFO - 2021-07-12 11:58:41 --> Loader Class Initialized
INFO - 2021-07-12 11:58:41 --> Helper loaded: basic_helper
INFO - 2021-07-12 11:58:41 --> Helper loaded: url_helper
INFO - 2021-07-12 11:58:41 --> Helper loaded: file_helper
INFO - 2021-07-12 11:58:41 --> Helper loaded: form_helper
INFO - 2021-07-12 11:58:41 --> Helper loaded: cookie_helper
INFO - 2021-07-12 11:58:41 --> Helper loaded: security_helper
INFO - 2021-07-12 11:58:41 --> Helper loaded: directory_helper
INFO - 2021-07-12 11:58:41 --> Helper loaded: language_helper
INFO - 2021-07-12 11:58:41 --> Helper loaded: general_helper
INFO - 2021-07-12 11:58:41 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 11:58:41 --> Database Driver Class Initialized
INFO - 2021-07-12 11:58:41 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 11:58:41 --> Controller Class Initialized
DEBUG - 2021-07-12 11:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 11:58:41 --> Final output sent to browser
DEBUG - 2021-07-12 11:58:41 --> Total execution time: 0.0689
INFO - 2021-07-12 11:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 11:58:41 --> Parser Class Initialized
INFO - 2021-07-12 11:58:41 --> Form Validation Class Initialized
INFO - 2021-07-12 11:58:41 --> Upload Class Initialized
INFO - 2021-07-12 11:58:41 --> Email Class Initialized
INFO - 2021-07-12 11:58:41 --> MY_Model class loaded
INFO - 2021-07-12 11:58:41 --> Model "Users_model" initialized
INFO - 2021-07-12 11:58:41 --> Model "Settings_model" initialized
INFO - 2021-07-12 11:58:41 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 11:58:41 --> Model "Permissions_model" initialized
INFO - 2021-07-12 11:58:41 --> Model "Roles_model" initialized
INFO - 2021-07-12 11:58:41 --> Model "Activity_model" initialized
INFO - 2021-07-12 11:58:41 --> Model "Templates_model" initialized
INFO - 2021-07-12 11:58:41 --> Database Driver Class Initialized
INFO - 2021-07-12 11:58:41 --> Config Class Initialized
INFO - 2021-07-12 11:58:41 --> Hooks Class Initialized
DEBUG - 2021-07-12 11:58:41 --> UTF-8 Support Enabled
INFO - 2021-07-12 11:58:41 --> Utf8 Class Initialized
INFO - 2021-07-12 11:58:41 --> URI Class Initialized
INFO - 2021-07-12 11:58:41 --> Router Class Initialized
INFO - 2021-07-12 11:58:41 --> Output Class Initialized
INFO - 2021-07-12 11:58:41 --> Security Class Initialized
DEBUG - 2021-07-12 11:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 11:58:41 --> Input Class Initialized
INFO - 2021-07-12 11:58:41 --> Language Class Initialized
INFO - 2021-07-12 11:58:41 --> Loader Class Initialized
INFO - 2021-07-12 11:58:41 --> Helper loaded: basic_helper
INFO - 2021-07-12 11:58:41 --> Helper loaded: url_helper
INFO - 2021-07-12 11:58:41 --> Helper loaded: file_helper
INFO - 2021-07-12 11:58:41 --> Helper loaded: form_helper
INFO - 2021-07-12 11:58:41 --> Helper loaded: cookie_helper
INFO - 2021-07-12 11:58:41 --> Helper loaded: security_helper
INFO - 2021-07-12 11:58:41 --> Helper loaded: directory_helper
INFO - 2021-07-12 11:58:41 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 11:58:41 --> Helper loaded: language_helper
INFO - 2021-07-12 11:58:41 --> Controller Class Initialized
INFO - 2021-07-12 11:58:41 --> Helper loaded: general_helper
INFO - 2021-07-12 11:58:41 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 11:58:41 --> Database Driver Class Initialized
INFO - 2021-07-12 11:58:41 --> Final output sent to browser
DEBUG - 2021-07-12 11:58:41 --> Total execution time: 0.0917
INFO - 2021-07-12 11:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 11:58:41 --> Parser Class Initialized
DEBUG - 2021-07-12 11:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 11:58:41 --> Form Validation Class Initialized
INFO - 2021-07-12 11:58:41 --> Upload Class Initialized
INFO - 2021-07-12 11:58:41 --> Email Class Initialized
INFO - 2021-07-12 11:58:41 --> MY_Model class loaded
INFO - 2021-07-12 11:58:41 --> Model "Users_model" initialized
INFO - 2021-07-12 11:58:41 --> Model "Settings_model" initialized
INFO - 2021-07-12 11:58:41 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 11:58:41 --> Model "Permissions_model" initialized
INFO - 2021-07-12 11:58:41 --> Model "Roles_model" initialized
INFO - 2021-07-12 11:58:41 --> Model "Activity_model" initialized
INFO - 2021-07-12 11:58:41 --> Model "Templates_model" initialized
INFO - 2021-07-12 11:58:41 --> Database Driver Class Initialized
INFO - 2021-07-12 11:58:41 --> Config Class Initialized
INFO - 2021-07-12 11:58:41 --> Hooks Class Initialized
DEBUG - 2021-07-12 11:58:41 --> UTF-8 Support Enabled
INFO - 2021-07-12 11:58:41 --> Utf8 Class Initialized
INFO - 2021-07-12 11:58:41 --> URI Class Initialized
INFO - 2021-07-12 11:58:41 --> Router Class Initialized
INFO - 2021-07-12 11:58:41 --> Output Class Initialized
INFO - 2021-07-12 11:58:41 --> Security Class Initialized
DEBUG - 2021-07-12 11:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 11:58:41 --> Input Class Initialized
INFO - 2021-07-12 11:58:41 --> Language Class Initialized
INFO - 2021-07-12 11:58:41 --> Loader Class Initialized
INFO - 2021-07-12 11:58:41 --> Helper loaded: basic_helper
INFO - 2021-07-12 11:58:41 --> Helper loaded: url_helper
INFO - 2021-07-12 11:58:41 --> Helper loaded: file_helper
INFO - 2021-07-12 11:58:41 --> Helper loaded: form_helper
INFO - 2021-07-12 11:58:41 --> Helper loaded: cookie_helper
INFO - 2021-07-12 11:58:41 --> Helper loaded: security_helper
INFO - 2021-07-12 11:58:41 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 11:58:41 --> Helper loaded: directory_helper
INFO - 2021-07-12 11:58:41 --> Controller Class Initialized
INFO - 2021-07-12 11:58:41 --> Helper loaded: language_helper
INFO - 2021-07-12 11:58:41 --> Helper loaded: general_helper
INFO - 2021-07-12 11:58:41 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 11:58:41 --> Final output sent to browser
INFO - 2021-07-12 11:58:41 --> Database Driver Class Initialized
DEBUG - 2021-07-12 11:58:41 --> Total execution time: 0.1120
INFO - 2021-07-12 11:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 11:58:41 --> Parser Class Initialized
DEBUG - 2021-07-12 11:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 11:58:41 --> Form Validation Class Initialized
INFO - 2021-07-12 11:58:41 --> Upload Class Initialized
INFO - 2021-07-12 11:58:41 --> Email Class Initialized
INFO - 2021-07-12 11:58:41 --> MY_Model class loaded
INFO - 2021-07-12 11:58:41 --> Model "Users_model" initialized
INFO - 2021-07-12 11:58:41 --> Model "Settings_model" initialized
INFO - 2021-07-12 11:58:41 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 11:58:41 --> Model "Permissions_model" initialized
INFO - 2021-07-12 11:58:41 --> Model "Roles_model" initialized
INFO - 2021-07-12 11:58:41 --> Model "Activity_model" initialized
INFO - 2021-07-12 11:58:41 --> Model "Templates_model" initialized
INFO - 2021-07-12 11:58:41 --> Database Driver Class Initialized
INFO - 2021-07-12 11:58:41 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 11:58:41 --> Controller Class Initialized
INFO - 2021-07-12 11:58:41 --> Final output sent to browser
DEBUG - 2021-07-12 11:58:41 --> Total execution time: 0.1340
INFO - 2021-07-12 11:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 11:58:41 --> Parser Class Initialized
INFO - 2021-07-12 11:58:41 --> Form Validation Class Initialized
INFO - 2021-07-12 11:58:41 --> Upload Class Initialized
INFO - 2021-07-12 11:58:41 --> Email Class Initialized
INFO - 2021-07-12 11:58:41 --> MY_Model class loaded
INFO - 2021-07-12 11:58:41 --> Model "Users_model" initialized
INFO - 2021-07-12 11:58:41 --> Model "Settings_model" initialized
INFO - 2021-07-12 11:58:41 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 11:58:41 --> Model "Permissions_model" initialized
INFO - 2021-07-12 11:58:41 --> Model "Roles_model" initialized
INFO - 2021-07-12 11:58:41 --> Model "Activity_model" initialized
INFO - 2021-07-12 11:58:41 --> Model "Templates_model" initialized
INFO - 2021-07-12 11:58:41 --> Database Driver Class Initialized
INFO - 2021-07-12 11:58:41 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 11:58:41 --> Controller Class Initialized
INFO - 2021-07-12 11:58:41 --> Final output sent to browser
DEBUG - 2021-07-12 11:58:41 --> Total execution time: 0.1534
INFO - 2021-07-12 11:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 11:58:41 --> Parser Class Initialized
INFO - 2021-07-12 11:58:41 --> Form Validation Class Initialized
INFO - 2021-07-12 11:58:41 --> Upload Class Initialized
INFO - 2021-07-12 11:58:41 --> Email Class Initialized
INFO - 2021-07-12 11:58:41 --> MY_Model class loaded
INFO - 2021-07-12 11:58:41 --> Model "Users_model" initialized
INFO - 2021-07-12 11:58:41 --> Model "Settings_model" initialized
INFO - 2021-07-12 11:58:41 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 11:58:41 --> Model "Permissions_model" initialized
INFO - 2021-07-12 11:58:41 --> Model "Roles_model" initialized
INFO - 2021-07-12 11:58:41 --> Model "Activity_model" initialized
INFO - 2021-07-12 11:58:41 --> Model "Templates_model" initialized
INFO - 2021-07-12 11:58:41 --> Database Driver Class Initialized
INFO - 2021-07-12 11:58:41 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 11:58:41 --> Controller Class Initialized
INFO - 2021-07-12 11:58:41 --> Final output sent to browser
DEBUG - 2021-07-12 11:58:41 --> Total execution time: 0.1592
INFO - 2021-07-12 11:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 11:58:41 --> Parser Class Initialized
INFO - 2021-07-12 11:58:41 --> Form Validation Class Initialized
INFO - 2021-07-12 11:58:41 --> Upload Class Initialized
INFO - 2021-07-12 11:58:41 --> Email Class Initialized
INFO - 2021-07-12 11:58:41 --> MY_Model class loaded
INFO - 2021-07-12 11:58:41 --> Model "Users_model" initialized
INFO - 2021-07-12 11:58:41 --> Model "Settings_model" initialized
INFO - 2021-07-12 11:58:41 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 11:58:41 --> Model "Permissions_model" initialized
INFO - 2021-07-12 11:58:41 --> Model "Roles_model" initialized
INFO - 2021-07-12 11:58:41 --> Model "Activity_model" initialized
INFO - 2021-07-12 11:58:41 --> Model "Templates_model" initialized
INFO - 2021-07-12 11:58:41 --> Database Driver Class Initialized
INFO - 2021-07-12 11:58:41 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 11:58:41 --> Controller Class Initialized
INFO - 2021-07-12 11:58:41 --> Final output sent to browser
DEBUG - 2021-07-12 11:58:41 --> Total execution time: 0.1555
INFO - 2021-07-12 11:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 11:58:41 --> Parser Class Initialized
INFO - 2021-07-12 11:58:41 --> Form Validation Class Initialized
INFO - 2021-07-12 11:58:41 --> Upload Class Initialized
INFO - 2021-07-12 11:58:41 --> Email Class Initialized
INFO - 2021-07-12 11:58:41 --> MY_Model class loaded
INFO - 2021-07-12 11:58:41 --> Model "Users_model" initialized
INFO - 2021-07-12 11:58:41 --> Model "Settings_model" initialized
INFO - 2021-07-12 11:58:41 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 11:58:41 --> Model "Permissions_model" initialized
INFO - 2021-07-12 11:58:41 --> Model "Roles_model" initialized
INFO - 2021-07-12 11:58:41 --> Model "Activity_model" initialized
INFO - 2021-07-12 11:58:41 --> Model "Templates_model" initialized
INFO - 2021-07-12 11:58:41 --> Database Driver Class Initialized
INFO - 2021-07-12 11:58:41 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 11:58:41 --> Controller Class Initialized
INFO - 2021-07-12 11:58:41 --> Final output sent to browser
DEBUG - 2021-07-12 11:58:41 --> Total execution time: 0.1553
INFO - 2021-07-12 11:59:07 --> Config Class Initialized
INFO - 2021-07-12 11:59:07 --> Hooks Class Initialized
DEBUG - 2021-07-12 11:59:07 --> UTF-8 Support Enabled
INFO - 2021-07-12 11:59:07 --> Utf8 Class Initialized
INFO - 2021-07-12 11:59:07 --> URI Class Initialized
INFO - 2021-07-12 11:59:07 --> Router Class Initialized
INFO - 2021-07-12 11:59:07 --> Output Class Initialized
INFO - 2021-07-12 11:59:07 --> Security Class Initialized
DEBUG - 2021-07-12 11:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 11:59:07 --> Input Class Initialized
INFO - 2021-07-12 11:59:07 --> Language Class Initialized
INFO - 2021-07-12 11:59:07 --> Loader Class Initialized
INFO - 2021-07-12 11:59:07 --> Helper loaded: basic_helper
INFO - 2021-07-12 11:59:07 --> Helper loaded: url_helper
INFO - 2021-07-12 11:59:07 --> Helper loaded: file_helper
INFO - 2021-07-12 11:59:07 --> Helper loaded: form_helper
INFO - 2021-07-12 11:59:07 --> Helper loaded: cookie_helper
INFO - 2021-07-12 11:59:07 --> Helper loaded: security_helper
INFO - 2021-07-12 11:59:07 --> Helper loaded: directory_helper
INFO - 2021-07-12 11:59:07 --> Helper loaded: language_helper
INFO - 2021-07-12 11:59:07 --> Helper loaded: general_helper
INFO - 2021-07-12 11:59:07 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 11:59:07 --> Database Driver Class Initialized
DEBUG - 2021-07-12 11:59:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 11:59:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 11:59:07 --> Parser Class Initialized
INFO - 2021-07-12 11:59:07 --> Form Validation Class Initialized
INFO - 2021-07-12 11:59:07 --> Upload Class Initialized
INFO - 2021-07-12 11:59:07 --> Email Class Initialized
INFO - 2021-07-12 11:59:07 --> MY_Model class loaded
INFO - 2021-07-12 11:59:07 --> Model "Users_model" initialized
INFO - 2021-07-12 11:59:07 --> Model "Settings_model" initialized
INFO - 2021-07-12 11:59:07 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 11:59:07 --> Model "Permissions_model" initialized
INFO - 2021-07-12 11:59:07 --> Model "Roles_model" initialized
INFO - 2021-07-12 11:59:07 --> Model "Activity_model" initialized
INFO - 2021-07-12 11:59:07 --> Model "Templates_model" initialized
INFO - 2021-07-12 11:59:07 --> Database Driver Class Initialized
INFO - 2021-07-12 11:59:07 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 11:59:07 --> Controller Class Initialized
ERROR - 2021-07-12 11:59:07 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 11:59:07 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-12 11:59:07 --> Final output sent to browser
DEBUG - 2021-07-12 11:59:07 --> Total execution time: 0.2510
INFO - 2021-07-12 11:59:09 --> Config Class Initialized
INFO - 2021-07-12 11:59:09 --> Hooks Class Initialized
DEBUG - 2021-07-12 11:59:09 --> UTF-8 Support Enabled
INFO - 2021-07-12 11:59:09 --> Utf8 Class Initialized
INFO - 2021-07-12 11:59:09 --> URI Class Initialized
INFO - 2021-07-12 11:59:09 --> Router Class Initialized
INFO - 2021-07-12 11:59:09 --> Output Class Initialized
INFO - 2021-07-12 11:59:09 --> Security Class Initialized
DEBUG - 2021-07-12 11:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 11:59:09 --> Input Class Initialized
INFO - 2021-07-12 11:59:09 --> Language Class Initialized
INFO - 2021-07-12 11:59:09 --> Loader Class Initialized
INFO - 2021-07-12 11:59:09 --> Helper loaded: basic_helper
INFO - 2021-07-12 11:59:09 --> Helper loaded: url_helper
INFO - 2021-07-12 11:59:09 --> Helper loaded: file_helper
INFO - 2021-07-12 11:59:09 --> Helper loaded: form_helper
INFO - 2021-07-12 11:59:09 --> Helper loaded: cookie_helper
INFO - 2021-07-12 11:59:09 --> Helper loaded: security_helper
INFO - 2021-07-12 11:59:09 --> Helper loaded: directory_helper
INFO - 2021-07-12 11:59:09 --> Helper loaded: language_helper
INFO - 2021-07-12 11:59:09 --> Helper loaded: general_helper
INFO - 2021-07-12 11:59:09 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 11:59:09 --> Database Driver Class Initialized
DEBUG - 2021-07-12 11:59:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 11:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 11:59:09 --> Parser Class Initialized
INFO - 2021-07-12 11:59:09 --> Form Validation Class Initialized
INFO - 2021-07-12 11:59:09 --> Upload Class Initialized
INFO - 2021-07-12 11:59:09 --> Email Class Initialized
INFO - 2021-07-12 11:59:09 --> MY_Model class loaded
INFO - 2021-07-12 11:59:09 --> Model "Users_model" initialized
INFO - 2021-07-12 11:59:09 --> Model "Settings_model" initialized
INFO - 2021-07-12 11:59:09 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 11:59:09 --> Model "Permissions_model" initialized
INFO - 2021-07-12 11:59:09 --> Model "Roles_model" initialized
INFO - 2021-07-12 11:59:09 --> Model "Activity_model" initialized
INFO - 2021-07-12 11:59:09 --> Model "Templates_model" initialized
INFO - 2021-07-12 11:59:09 --> Database Driver Class Initialized
INFO - 2021-07-12 11:59:09 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 11:59:09 --> Controller Class Initialized
ERROR - 2021-07-12 11:59:09 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 11:59:09 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-12 11:59:09 --> Final output sent to browser
DEBUG - 2021-07-12 11:59:09 --> Total execution time: 0.0599
INFO - 2021-07-12 11:59:12 --> Config Class Initialized
INFO - 2021-07-12 11:59:12 --> Hooks Class Initialized
DEBUG - 2021-07-12 11:59:12 --> UTF-8 Support Enabled
INFO - 2021-07-12 11:59:12 --> Utf8 Class Initialized
INFO - 2021-07-12 11:59:12 --> URI Class Initialized
INFO - 2021-07-12 11:59:12 --> Router Class Initialized
INFO - 2021-07-12 11:59:12 --> Output Class Initialized
INFO - 2021-07-12 11:59:12 --> Security Class Initialized
DEBUG - 2021-07-12 11:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 11:59:12 --> Input Class Initialized
INFO - 2021-07-12 11:59:12 --> Language Class Initialized
INFO - 2021-07-12 11:59:12 --> Loader Class Initialized
INFO - 2021-07-12 11:59:12 --> Helper loaded: basic_helper
INFO - 2021-07-12 11:59:12 --> Helper loaded: url_helper
INFO - 2021-07-12 11:59:12 --> Helper loaded: file_helper
INFO - 2021-07-12 11:59:12 --> Helper loaded: form_helper
INFO - 2021-07-12 11:59:12 --> Helper loaded: cookie_helper
INFO - 2021-07-12 11:59:12 --> Helper loaded: security_helper
INFO - 2021-07-12 11:59:12 --> Helper loaded: directory_helper
INFO - 2021-07-12 11:59:12 --> Helper loaded: language_helper
INFO - 2021-07-12 11:59:12 --> Helper loaded: general_helper
INFO - 2021-07-12 11:59:12 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 11:59:12 --> Database Driver Class Initialized
DEBUG - 2021-07-12 11:59:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 11:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 11:59:12 --> Parser Class Initialized
INFO - 2021-07-12 11:59:12 --> Form Validation Class Initialized
INFO - 2021-07-12 11:59:12 --> Upload Class Initialized
INFO - 2021-07-12 11:59:12 --> Email Class Initialized
INFO - 2021-07-12 11:59:12 --> MY_Model class loaded
INFO - 2021-07-12 11:59:12 --> Model "Users_model" initialized
INFO - 2021-07-12 11:59:12 --> Model "Settings_model" initialized
INFO - 2021-07-12 11:59:12 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 11:59:12 --> Model "Permissions_model" initialized
INFO - 2021-07-12 11:59:12 --> Model "Roles_model" initialized
INFO - 2021-07-12 11:59:12 --> Model "Activity_model" initialized
INFO - 2021-07-12 11:59:12 --> Model "Templates_model" initialized
INFO - 2021-07-12 11:59:12 --> Database Driver Class Initialized
INFO - 2021-07-12 11:59:12 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 11:59:12 --> Controller Class Initialized
INFO - 2021-07-12 11:59:12 --> File loaded: C:\wamp64\www\crm\application\views\account/login.php
INFO - 2021-07-12 11:59:12 --> Final output sent to browser
DEBUG - 2021-07-12 11:59:12 --> Total execution time: 0.1049
INFO - 2021-07-12 11:59:12 --> Config Class Initialized
INFO - 2021-07-12 11:59:12 --> Config Class Initialized
INFO - 2021-07-12 11:59:12 --> Hooks Class Initialized
INFO - 2021-07-12 11:59:12 --> Hooks Class Initialized
DEBUG - 2021-07-12 11:59:12 --> UTF-8 Support Enabled
DEBUG - 2021-07-12 11:59:12 --> UTF-8 Support Enabled
INFO - 2021-07-12 11:59:12 --> Utf8 Class Initialized
INFO - 2021-07-12 11:59:12 --> Utf8 Class Initialized
INFO - 2021-07-12 11:59:12 --> URI Class Initialized
INFO - 2021-07-12 11:59:12 --> URI Class Initialized
INFO - 2021-07-12 11:59:12 --> Router Class Initialized
INFO - 2021-07-12 11:59:12 --> Router Class Initialized
INFO - 2021-07-12 11:59:12 --> Output Class Initialized
INFO - 2021-07-12 11:59:12 --> Output Class Initialized
INFO - 2021-07-12 11:59:12 --> Security Class Initialized
INFO - 2021-07-12 11:59:12 --> Security Class Initialized
DEBUG - 2021-07-12 11:59:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-12 11:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 11:59:12 --> Input Class Initialized
INFO - 2021-07-12 11:59:12 --> Input Class Initialized
INFO - 2021-07-12 11:59:12 --> Language Class Initialized
INFO - 2021-07-12 11:59:12 --> Language Class Initialized
ERROR - 2021-07-12 11:59:12 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-07-12 11:59:12 --> 404 Page Not Found: Assets/jquery
INFO - 2021-07-12 11:59:12 --> Config Class Initialized
INFO - 2021-07-12 11:59:12 --> Hooks Class Initialized
DEBUG - 2021-07-12 11:59:12 --> UTF-8 Support Enabled
INFO - 2021-07-12 11:59:12 --> Utf8 Class Initialized
INFO - 2021-07-12 11:59:12 --> URI Class Initialized
INFO - 2021-07-12 11:59:12 --> Router Class Initialized
INFO - 2021-07-12 11:59:12 --> Output Class Initialized
INFO - 2021-07-12 11:59:12 --> Security Class Initialized
DEBUG - 2021-07-12 11:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 11:59:12 --> Input Class Initialized
INFO - 2021-07-12 11:59:12 --> Language Class Initialized
ERROR - 2021-07-12 11:59:12 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-12 11:59:13 --> Config Class Initialized
INFO - 2021-07-12 11:59:13 --> Hooks Class Initialized
DEBUG - 2021-07-12 11:59:13 --> UTF-8 Support Enabled
INFO - 2021-07-12 11:59:13 --> Utf8 Class Initialized
INFO - 2021-07-12 11:59:13 --> URI Class Initialized
INFO - 2021-07-12 11:59:13 --> Router Class Initialized
INFO - 2021-07-12 11:59:13 --> Output Class Initialized
INFO - 2021-07-12 11:59:13 --> Security Class Initialized
DEBUG - 2021-07-12 11:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 11:59:13 --> Input Class Initialized
INFO - 2021-07-12 11:59:13 --> Language Class Initialized
ERROR - 2021-07-12 11:59:13 --> 404 Page Not Found: Faviconico/index
INFO - 2021-07-12 11:59:16 --> Config Class Initialized
INFO - 2021-07-12 11:59:16 --> Hooks Class Initialized
DEBUG - 2021-07-12 11:59:16 --> UTF-8 Support Enabled
INFO - 2021-07-12 11:59:16 --> Utf8 Class Initialized
INFO - 2021-07-12 11:59:16 --> URI Class Initialized
INFO - 2021-07-12 11:59:16 --> Router Class Initialized
INFO - 2021-07-12 11:59:16 --> Output Class Initialized
INFO - 2021-07-12 11:59:16 --> Security Class Initialized
DEBUG - 2021-07-12 11:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 11:59:16 --> Input Class Initialized
INFO - 2021-07-12 11:59:16 --> Language Class Initialized
INFO - 2021-07-12 11:59:16 --> Loader Class Initialized
INFO - 2021-07-12 11:59:16 --> Helper loaded: basic_helper
INFO - 2021-07-12 11:59:16 --> Helper loaded: url_helper
INFO - 2021-07-12 11:59:16 --> Helper loaded: file_helper
INFO - 2021-07-12 11:59:16 --> Helper loaded: form_helper
INFO - 2021-07-12 11:59:16 --> Helper loaded: cookie_helper
INFO - 2021-07-12 11:59:16 --> Helper loaded: security_helper
INFO - 2021-07-12 11:59:16 --> Helper loaded: directory_helper
INFO - 2021-07-12 11:59:16 --> Helper loaded: language_helper
INFO - 2021-07-12 11:59:16 --> Helper loaded: general_helper
INFO - 2021-07-12 11:59:16 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 11:59:16 --> Database Driver Class Initialized
DEBUG - 2021-07-12 11:59:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 11:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 11:59:16 --> Parser Class Initialized
INFO - 2021-07-12 11:59:16 --> Form Validation Class Initialized
INFO - 2021-07-12 11:59:16 --> Upload Class Initialized
INFO - 2021-07-12 11:59:16 --> Email Class Initialized
INFO - 2021-07-12 11:59:16 --> MY_Model class loaded
INFO - 2021-07-12 11:59:16 --> Model "Users_model" initialized
INFO - 2021-07-12 11:59:16 --> Model "Settings_model" initialized
INFO - 2021-07-12 11:59:16 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 11:59:16 --> Model "Permissions_model" initialized
INFO - 2021-07-12 11:59:16 --> Model "Roles_model" initialized
INFO - 2021-07-12 11:59:16 --> Model "Activity_model" initialized
INFO - 2021-07-12 11:59:16 --> Model "Templates_model" initialized
INFO - 2021-07-12 11:59:16 --> Database Driver Class Initialized
INFO - 2021-07-12 11:59:16 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 11:59:16 --> Controller Class Initialized
DEBUG - 2021-07-12 11:59:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-12 11:59:16 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2021-07-12 11:59:16 --> Config Class Initialized
INFO - 2021-07-12 11:59:16 --> Hooks Class Initialized
DEBUG - 2021-07-12 11:59:16 --> UTF-8 Support Enabled
INFO - 2021-07-12 11:59:16 --> Utf8 Class Initialized
INFO - 2021-07-12 11:59:16 --> URI Class Initialized
DEBUG - 2021-07-12 11:59:16 --> No URI present. Default controller set.
INFO - 2021-07-12 11:59:16 --> Router Class Initialized
INFO - 2021-07-12 11:59:16 --> Output Class Initialized
INFO - 2021-07-12 11:59:16 --> Security Class Initialized
DEBUG - 2021-07-12 11:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 11:59:16 --> Input Class Initialized
INFO - 2021-07-12 11:59:16 --> Language Class Initialized
INFO - 2021-07-12 11:59:16 --> Loader Class Initialized
INFO - 2021-07-12 11:59:16 --> Helper loaded: basic_helper
INFO - 2021-07-12 11:59:16 --> Helper loaded: url_helper
INFO - 2021-07-12 11:59:16 --> Helper loaded: file_helper
INFO - 2021-07-12 11:59:16 --> Helper loaded: form_helper
INFO - 2021-07-12 11:59:16 --> Helper loaded: cookie_helper
INFO - 2021-07-12 11:59:16 --> Helper loaded: security_helper
INFO - 2021-07-12 11:59:16 --> Helper loaded: directory_helper
INFO - 2021-07-12 11:59:16 --> Helper loaded: language_helper
INFO - 2021-07-12 11:59:16 --> Helper loaded: general_helper
INFO - 2021-07-12 11:59:16 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 11:59:16 --> Database Driver Class Initialized
DEBUG - 2021-07-12 11:59:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 11:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 11:59:16 --> Parser Class Initialized
INFO - 2021-07-12 11:59:16 --> Form Validation Class Initialized
INFO - 2021-07-12 11:59:16 --> Upload Class Initialized
INFO - 2021-07-12 11:59:16 --> Email Class Initialized
INFO - 2021-07-12 11:59:16 --> MY_Model class loaded
INFO - 2021-07-12 11:59:16 --> Model "Users_model" initialized
INFO - 2021-07-12 11:59:16 --> Model "Settings_model" initialized
INFO - 2021-07-12 11:59:16 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 11:59:16 --> Model "Permissions_model" initialized
INFO - 2021-07-12 11:59:16 --> Model "Roles_model" initialized
INFO - 2021-07-12 11:59:16 --> Model "Activity_model" initialized
INFO - 2021-07-12 11:59:16 --> Model "Templates_model" initialized
INFO - 2021-07-12 11:59:16 --> Database Driver Class Initialized
INFO - 2021-07-12 11:59:16 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 11:59:16 --> Controller Class Initialized
ERROR - 2021-07-12 11:59:16 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 11:59:16 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-12 11:59:16 --> Final output sent to browser
DEBUG - 2021-07-12 11:59:16 --> Total execution time: 0.0562
INFO - 2021-07-12 11:59:20 --> Config Class Initialized
INFO - 2021-07-12 11:59:20 --> Hooks Class Initialized
DEBUG - 2021-07-12 11:59:20 --> UTF-8 Support Enabled
INFO - 2021-07-12 11:59:20 --> Utf8 Class Initialized
INFO - 2021-07-12 11:59:20 --> URI Class Initialized
INFO - 2021-07-12 11:59:20 --> Router Class Initialized
INFO - 2021-07-12 11:59:20 --> Output Class Initialized
INFO - 2021-07-12 11:59:20 --> Security Class Initialized
DEBUG - 2021-07-12 11:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 11:59:20 --> Input Class Initialized
INFO - 2021-07-12 11:59:20 --> Language Class Initialized
INFO - 2021-07-12 11:59:20 --> Loader Class Initialized
INFO - 2021-07-12 11:59:20 --> Helper loaded: basic_helper
INFO - 2021-07-12 11:59:20 --> Helper loaded: url_helper
INFO - 2021-07-12 11:59:20 --> Helper loaded: file_helper
INFO - 2021-07-12 11:59:20 --> Helper loaded: form_helper
INFO - 2021-07-12 11:59:20 --> Helper loaded: cookie_helper
INFO - 2021-07-12 11:59:20 --> Helper loaded: security_helper
INFO - 2021-07-12 11:59:20 --> Helper loaded: directory_helper
INFO - 2021-07-12 11:59:20 --> Helper loaded: language_helper
INFO - 2021-07-12 11:59:20 --> Helper loaded: general_helper
INFO - 2021-07-12 11:59:20 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 11:59:20 --> Database Driver Class Initialized
DEBUG - 2021-07-12 11:59:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 11:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 11:59:20 --> Parser Class Initialized
INFO - 2021-07-12 11:59:20 --> Form Validation Class Initialized
INFO - 2021-07-12 11:59:20 --> Upload Class Initialized
INFO - 2021-07-12 11:59:20 --> Email Class Initialized
INFO - 2021-07-12 11:59:20 --> MY_Model class loaded
INFO - 2021-07-12 11:59:20 --> Model "Users_model" initialized
INFO - 2021-07-12 11:59:20 --> Model "Settings_model" initialized
INFO - 2021-07-12 11:59:20 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 11:59:20 --> Model "Permissions_model" initialized
INFO - 2021-07-12 11:59:20 --> Model "Roles_model" initialized
INFO - 2021-07-12 11:59:20 --> Model "Activity_model" initialized
INFO - 2021-07-12 11:59:20 --> Model "Templates_model" initialized
INFO - 2021-07-12 11:59:20 --> Database Driver Class Initialized
INFO - 2021-07-12 11:59:20 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 11:59:20 --> Controller Class Initialized
ERROR - 2021-07-12 11:59:20 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 11:59:20 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-12 11:59:20 --> Final output sent to browser
DEBUG - 2021-07-12 11:59:20 --> Total execution time: 0.1210
INFO - 2021-07-12 11:59:25 --> Config Class Initialized
INFO - 2021-07-12 11:59:25 --> Hooks Class Initialized
DEBUG - 2021-07-12 11:59:25 --> UTF-8 Support Enabled
INFO - 2021-07-12 11:59:25 --> Utf8 Class Initialized
INFO - 2021-07-12 11:59:25 --> URI Class Initialized
INFO - 2021-07-12 11:59:25 --> Router Class Initialized
INFO - 2021-07-12 11:59:25 --> Output Class Initialized
INFO - 2021-07-12 11:59:25 --> Security Class Initialized
DEBUG - 2021-07-12 11:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 11:59:25 --> Input Class Initialized
INFO - 2021-07-12 11:59:25 --> Language Class Initialized
INFO - 2021-07-12 11:59:25 --> Loader Class Initialized
INFO - 2021-07-12 11:59:25 --> Helper loaded: basic_helper
INFO - 2021-07-12 11:59:25 --> Helper loaded: url_helper
INFO - 2021-07-12 11:59:25 --> Helper loaded: file_helper
INFO - 2021-07-12 11:59:25 --> Helper loaded: form_helper
INFO - 2021-07-12 11:59:25 --> Helper loaded: cookie_helper
INFO - 2021-07-12 11:59:25 --> Helper loaded: security_helper
INFO - 2021-07-12 11:59:25 --> Helper loaded: directory_helper
INFO - 2021-07-12 11:59:25 --> Helper loaded: language_helper
INFO - 2021-07-12 11:59:25 --> Helper loaded: general_helper
INFO - 2021-07-12 11:59:25 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 11:59:25 --> Database Driver Class Initialized
DEBUG - 2021-07-12 11:59:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 11:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 11:59:25 --> Parser Class Initialized
INFO - 2021-07-12 11:59:25 --> Form Validation Class Initialized
INFO - 2021-07-12 11:59:25 --> Upload Class Initialized
INFO - 2021-07-12 11:59:25 --> Email Class Initialized
INFO - 2021-07-12 11:59:25 --> MY_Model class loaded
INFO - 2021-07-12 11:59:25 --> Model "Users_model" initialized
INFO - 2021-07-12 11:59:25 --> Model "Settings_model" initialized
INFO - 2021-07-12 11:59:25 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 11:59:25 --> Model "Permissions_model" initialized
INFO - 2021-07-12 11:59:25 --> Model "Roles_model" initialized
INFO - 2021-07-12 11:59:25 --> Model "Activity_model" initialized
INFO - 2021-07-12 11:59:25 --> Model "Templates_model" initialized
INFO - 2021-07-12 11:59:25 --> Database Driver Class Initialized
INFO - 2021-07-12 11:59:25 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 11:59:25 --> Controller Class Initialized
ERROR - 2021-07-12 11:59:25 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 11:59:25 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-12 11:59:25 --> Final output sent to browser
DEBUG - 2021-07-12 11:59:25 --> Total execution time: 0.2453
INFO - 2021-07-12 11:59:39 --> Config Class Initialized
INFO - 2021-07-12 11:59:39 --> Hooks Class Initialized
DEBUG - 2021-07-12 11:59:39 --> UTF-8 Support Enabled
INFO - 2021-07-12 11:59:39 --> Utf8 Class Initialized
INFO - 2021-07-12 11:59:39 --> URI Class Initialized
INFO - 2021-07-12 11:59:39 --> Router Class Initialized
INFO - 2021-07-12 11:59:39 --> Output Class Initialized
INFO - 2021-07-12 11:59:39 --> Security Class Initialized
DEBUG - 2021-07-12 11:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 11:59:39 --> Input Class Initialized
INFO - 2021-07-12 11:59:39 --> Language Class Initialized
INFO - 2021-07-12 11:59:39 --> Loader Class Initialized
INFO - 2021-07-12 11:59:39 --> Helper loaded: basic_helper
INFO - 2021-07-12 11:59:39 --> Helper loaded: url_helper
INFO - 2021-07-12 11:59:39 --> Helper loaded: file_helper
INFO - 2021-07-12 11:59:39 --> Helper loaded: form_helper
INFO - 2021-07-12 11:59:39 --> Helper loaded: cookie_helper
INFO - 2021-07-12 11:59:39 --> Helper loaded: security_helper
INFO - 2021-07-12 11:59:39 --> Helper loaded: directory_helper
INFO - 2021-07-12 11:59:39 --> Helper loaded: language_helper
INFO - 2021-07-12 11:59:39 --> Helper loaded: general_helper
INFO - 2021-07-12 11:59:39 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 11:59:39 --> Database Driver Class Initialized
DEBUG - 2021-07-12 11:59:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 11:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 11:59:39 --> Parser Class Initialized
INFO - 2021-07-12 11:59:39 --> Form Validation Class Initialized
INFO - 2021-07-12 11:59:39 --> Upload Class Initialized
INFO - 2021-07-12 11:59:39 --> Email Class Initialized
INFO - 2021-07-12 11:59:39 --> MY_Model class loaded
INFO - 2021-07-12 11:59:39 --> Model "Users_model" initialized
INFO - 2021-07-12 11:59:39 --> Model "Settings_model" initialized
INFO - 2021-07-12 11:59:39 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 11:59:39 --> Model "Permissions_model" initialized
INFO - 2021-07-12 11:59:39 --> Model "Roles_model" initialized
INFO - 2021-07-12 11:59:39 --> Model "Activity_model" initialized
INFO - 2021-07-12 11:59:39 --> Model "Templates_model" initialized
INFO - 2021-07-12 11:59:39 --> Database Driver Class Initialized
INFO - 2021-07-12 11:59:39 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 11:59:39 --> Controller Class Initialized
ERROR - 2021-07-12 11:59:39 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 11:59:39 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-12 11:59:39 --> Final output sent to browser
DEBUG - 2021-07-12 11:59:39 --> Total execution time: 0.1292
INFO - 2021-07-12 11:59:41 --> Config Class Initialized
INFO - 2021-07-12 11:59:41 --> Hooks Class Initialized
DEBUG - 2021-07-12 11:59:41 --> UTF-8 Support Enabled
INFO - 2021-07-12 11:59:41 --> Utf8 Class Initialized
INFO - 2021-07-12 11:59:41 --> URI Class Initialized
INFO - 2021-07-12 11:59:41 --> Router Class Initialized
INFO - 2021-07-12 11:59:41 --> Output Class Initialized
INFO - 2021-07-12 11:59:41 --> Security Class Initialized
DEBUG - 2021-07-12 11:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 11:59:41 --> Input Class Initialized
INFO - 2021-07-12 11:59:41 --> Language Class Initialized
INFO - 2021-07-12 11:59:41 --> Loader Class Initialized
INFO - 2021-07-12 11:59:41 --> Helper loaded: basic_helper
INFO - 2021-07-12 11:59:41 --> Helper loaded: url_helper
INFO - 2021-07-12 11:59:41 --> Helper loaded: file_helper
INFO - 2021-07-12 11:59:41 --> Helper loaded: form_helper
INFO - 2021-07-12 11:59:41 --> Helper loaded: cookie_helper
INFO - 2021-07-12 11:59:41 --> Helper loaded: security_helper
INFO - 2021-07-12 11:59:41 --> Helper loaded: directory_helper
INFO - 2021-07-12 11:59:41 --> Helper loaded: language_helper
INFO - 2021-07-12 11:59:41 --> Helper loaded: general_helper
INFO - 2021-07-12 11:59:41 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 11:59:41 --> Database Driver Class Initialized
DEBUG - 2021-07-12 11:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 11:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 11:59:41 --> Parser Class Initialized
INFO - 2021-07-12 11:59:41 --> Form Validation Class Initialized
INFO - 2021-07-12 11:59:41 --> Upload Class Initialized
INFO - 2021-07-12 11:59:41 --> Email Class Initialized
INFO - 2021-07-12 11:59:41 --> MY_Model class loaded
INFO - 2021-07-12 11:59:41 --> Model "Users_model" initialized
INFO - 2021-07-12 11:59:41 --> Model "Settings_model" initialized
INFO - 2021-07-12 11:59:41 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 11:59:41 --> Model "Permissions_model" initialized
INFO - 2021-07-12 11:59:41 --> Model "Roles_model" initialized
INFO - 2021-07-12 11:59:41 --> Model "Activity_model" initialized
INFO - 2021-07-12 11:59:41 --> Model "Templates_model" initialized
INFO - 2021-07-12 11:59:41 --> Database Driver Class Initialized
INFO - 2021-07-12 11:59:41 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 11:59:41 --> Controller Class Initialized
ERROR - 2021-07-12 11:59:41 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 11:59:42 --> File loaded: C:\wamp64\www\crm\application\views\activity_logs/list.php
INFO - 2021-07-12 11:59:42 --> Final output sent to browser
DEBUG - 2021-07-12 11:59:42 --> Total execution time: 0.1264
INFO - 2021-07-12 11:59:48 --> Config Class Initialized
INFO - 2021-07-12 11:59:48 --> Hooks Class Initialized
DEBUG - 2021-07-12 11:59:48 --> UTF-8 Support Enabled
INFO - 2021-07-12 11:59:48 --> Utf8 Class Initialized
INFO - 2021-07-12 11:59:48 --> URI Class Initialized
INFO - 2021-07-12 11:59:48 --> Router Class Initialized
INFO - 2021-07-12 11:59:48 --> Output Class Initialized
INFO - 2021-07-12 11:59:48 --> Security Class Initialized
DEBUG - 2021-07-12 11:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 11:59:48 --> Input Class Initialized
INFO - 2021-07-12 11:59:48 --> Language Class Initialized
INFO - 2021-07-12 11:59:48 --> Loader Class Initialized
INFO - 2021-07-12 11:59:48 --> Helper loaded: basic_helper
INFO - 2021-07-12 11:59:48 --> Helper loaded: url_helper
INFO - 2021-07-12 11:59:48 --> Helper loaded: file_helper
INFO - 2021-07-12 11:59:48 --> Helper loaded: form_helper
INFO - 2021-07-12 11:59:48 --> Helper loaded: cookie_helper
INFO - 2021-07-12 11:59:48 --> Helper loaded: security_helper
INFO - 2021-07-12 11:59:48 --> Helper loaded: directory_helper
INFO - 2021-07-12 11:59:48 --> Helper loaded: language_helper
INFO - 2021-07-12 11:59:48 --> Helper loaded: general_helper
INFO - 2021-07-12 11:59:48 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 11:59:48 --> Database Driver Class Initialized
DEBUG - 2021-07-12 11:59:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 11:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 11:59:48 --> Parser Class Initialized
INFO - 2021-07-12 11:59:48 --> Form Validation Class Initialized
INFO - 2021-07-12 11:59:48 --> Upload Class Initialized
INFO - 2021-07-12 11:59:48 --> Email Class Initialized
INFO - 2021-07-12 11:59:48 --> MY_Model class loaded
INFO - 2021-07-12 11:59:48 --> Model "Users_model" initialized
INFO - 2021-07-12 11:59:48 --> Model "Settings_model" initialized
INFO - 2021-07-12 11:59:48 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 11:59:48 --> Model "Permissions_model" initialized
INFO - 2021-07-12 11:59:48 --> Model "Roles_model" initialized
INFO - 2021-07-12 11:59:48 --> Model "Activity_model" initialized
INFO - 2021-07-12 11:59:48 --> Model "Templates_model" initialized
INFO - 2021-07-12 11:59:48 --> Database Driver Class Initialized
INFO - 2021-07-12 11:59:48 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 11:59:48 --> Controller Class Initialized
ERROR - 2021-07-12 11:59:48 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 11:59:48 --> File loaded: C:\wamp64\www\crm\application\views\blank_page.php
INFO - 2021-07-12 11:59:48 --> Final output sent to browser
DEBUG - 2021-07-12 11:59:48 --> Total execution time: 0.1200
INFO - 2021-07-12 11:59:50 --> Config Class Initialized
INFO - 2021-07-12 11:59:50 --> Hooks Class Initialized
DEBUG - 2021-07-12 11:59:50 --> UTF-8 Support Enabled
INFO - 2021-07-12 11:59:50 --> Utf8 Class Initialized
INFO - 2021-07-12 11:59:50 --> URI Class Initialized
INFO - 2021-07-12 11:59:50 --> Router Class Initialized
INFO - 2021-07-12 11:59:50 --> Output Class Initialized
INFO - 2021-07-12 11:59:50 --> Security Class Initialized
DEBUG - 2021-07-12 11:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 11:59:50 --> Input Class Initialized
INFO - 2021-07-12 11:59:50 --> Language Class Initialized
INFO - 2021-07-12 11:59:50 --> Loader Class Initialized
INFO - 2021-07-12 11:59:50 --> Helper loaded: basic_helper
INFO - 2021-07-12 11:59:50 --> Helper loaded: url_helper
INFO - 2021-07-12 11:59:50 --> Helper loaded: file_helper
INFO - 2021-07-12 11:59:50 --> Helper loaded: form_helper
INFO - 2021-07-12 11:59:50 --> Helper loaded: cookie_helper
INFO - 2021-07-12 11:59:50 --> Helper loaded: security_helper
INFO - 2021-07-12 11:59:50 --> Helper loaded: directory_helper
INFO - 2021-07-12 11:59:50 --> Helper loaded: language_helper
INFO - 2021-07-12 11:59:50 --> Helper loaded: general_helper
INFO - 2021-07-12 11:59:50 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 11:59:50 --> Database Driver Class Initialized
DEBUG - 2021-07-12 11:59:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 11:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 11:59:50 --> Parser Class Initialized
INFO - 2021-07-12 11:59:50 --> Form Validation Class Initialized
INFO - 2021-07-12 11:59:50 --> Upload Class Initialized
INFO - 2021-07-12 11:59:50 --> Email Class Initialized
INFO - 2021-07-12 11:59:50 --> MY_Model class loaded
INFO - 2021-07-12 11:59:50 --> Model "Users_model" initialized
INFO - 2021-07-12 11:59:50 --> Model "Settings_model" initialized
INFO - 2021-07-12 11:59:50 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 11:59:50 --> Model "Permissions_model" initialized
INFO - 2021-07-12 11:59:50 --> Model "Roles_model" initialized
INFO - 2021-07-12 11:59:50 --> Model "Activity_model" initialized
INFO - 2021-07-12 11:59:50 --> Model "Templates_model" initialized
INFO - 2021-07-12 11:59:50 --> Database Driver Class Initialized
INFO - 2021-07-12 11:59:50 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 11:59:50 --> Controller Class Initialized
ERROR - 2021-07-12 11:59:50 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 11:59:50 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-12 11:59:50 --> Final output sent to browser
DEBUG - 2021-07-12 11:59:50 --> Total execution time: 0.1910
INFO - 2021-07-12 11:59:54 --> Config Class Initialized
INFO - 2021-07-12 11:59:54 --> Hooks Class Initialized
DEBUG - 2021-07-12 11:59:54 --> UTF-8 Support Enabled
INFO - 2021-07-12 11:59:54 --> Utf8 Class Initialized
INFO - 2021-07-12 11:59:54 --> URI Class Initialized
INFO - 2021-07-12 11:59:54 --> Router Class Initialized
INFO - 2021-07-12 11:59:54 --> Output Class Initialized
INFO - 2021-07-12 11:59:54 --> Security Class Initialized
DEBUG - 2021-07-12 11:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 11:59:54 --> Input Class Initialized
INFO - 2021-07-12 11:59:54 --> Language Class Initialized
INFO - 2021-07-12 11:59:54 --> Loader Class Initialized
INFO - 2021-07-12 11:59:54 --> Helper loaded: basic_helper
INFO - 2021-07-12 11:59:54 --> Helper loaded: url_helper
INFO - 2021-07-12 11:59:54 --> Helper loaded: file_helper
INFO - 2021-07-12 11:59:54 --> Helper loaded: form_helper
INFO - 2021-07-12 11:59:54 --> Helper loaded: cookie_helper
INFO - 2021-07-12 11:59:54 --> Helper loaded: security_helper
INFO - 2021-07-12 11:59:54 --> Helper loaded: directory_helper
INFO - 2021-07-12 11:59:54 --> Helper loaded: language_helper
INFO - 2021-07-12 11:59:54 --> Helper loaded: general_helper
INFO - 2021-07-12 11:59:54 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 11:59:54 --> Database Driver Class Initialized
DEBUG - 2021-07-12 11:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 11:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 11:59:54 --> Parser Class Initialized
INFO - 2021-07-12 11:59:54 --> Form Validation Class Initialized
INFO - 2021-07-12 11:59:54 --> Upload Class Initialized
INFO - 2021-07-12 11:59:54 --> Email Class Initialized
INFO - 2021-07-12 11:59:54 --> MY_Model class loaded
INFO - 2021-07-12 11:59:54 --> Model "Users_model" initialized
INFO - 2021-07-12 11:59:54 --> Model "Settings_model" initialized
INFO - 2021-07-12 11:59:54 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 11:59:54 --> Model "Permissions_model" initialized
INFO - 2021-07-12 11:59:54 --> Model "Roles_model" initialized
INFO - 2021-07-12 11:59:54 --> Model "Activity_model" initialized
INFO - 2021-07-12 11:59:54 --> Model "Templates_model" initialized
INFO - 2021-07-12 11:59:54 --> Database Driver Class Initialized
INFO - 2021-07-12 11:59:54 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 11:59:54 --> Controller Class Initialized
ERROR - 2021-07-12 11:59:54 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 11:59:54 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-12 11:59:54 --> Final output sent to browser
DEBUG - 2021-07-12 11:59:54 --> Total execution time: 0.2538
INFO - 2021-07-12 12:00:05 --> Config Class Initialized
INFO - 2021-07-12 12:00:05 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:00:05 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:00:05 --> Utf8 Class Initialized
INFO - 2021-07-12 12:00:05 --> URI Class Initialized
INFO - 2021-07-12 12:00:05 --> Router Class Initialized
INFO - 2021-07-12 12:00:05 --> Output Class Initialized
INFO - 2021-07-12 12:00:05 --> Security Class Initialized
DEBUG - 2021-07-12 12:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:00:05 --> Input Class Initialized
INFO - 2021-07-12 12:00:05 --> Language Class Initialized
INFO - 2021-07-12 12:00:05 --> Loader Class Initialized
INFO - 2021-07-12 12:00:05 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:00:05 --> Helper loaded: url_helper
INFO - 2021-07-12 12:00:05 --> Helper loaded: file_helper
INFO - 2021-07-12 12:00:05 --> Helper loaded: form_helper
INFO - 2021-07-12 12:00:05 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:00:05 --> Helper loaded: security_helper
INFO - 2021-07-12 12:00:05 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:00:05 --> Helper loaded: language_helper
INFO - 2021-07-12 12:00:05 --> Helper loaded: general_helper
INFO - 2021-07-12 12:00:05 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:00:05 --> Database Driver Class Initialized
DEBUG - 2021-07-12 12:00:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:00:05 --> Parser Class Initialized
INFO - 2021-07-12 12:00:05 --> Form Validation Class Initialized
INFO - 2021-07-12 12:00:05 --> Upload Class Initialized
INFO - 2021-07-12 12:00:05 --> Email Class Initialized
INFO - 2021-07-12 12:00:05 --> MY_Model class loaded
INFO - 2021-07-12 12:00:05 --> Model "Users_model" initialized
INFO - 2021-07-12 12:00:05 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:00:05 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:00:05 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:00:05 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:00:05 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:00:05 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:00:05 --> Database Driver Class Initialized
INFO - 2021-07-12 12:00:05 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:00:05 --> Controller Class Initialized
ERROR - 2021-07-12 12:00:05 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 12:00:05 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-12 12:00:05 --> Final output sent to browser
DEBUG - 2021-07-12 12:00:05 --> Total execution time: 0.1372
INFO - 2021-07-12 12:05:16 --> Config Class Initialized
INFO - 2021-07-12 12:05:16 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:05:16 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:05:16 --> Utf8 Class Initialized
INFO - 2021-07-12 12:05:16 --> URI Class Initialized
DEBUG - 2021-07-12 12:05:16 --> No URI present. Default controller set.
INFO - 2021-07-12 12:05:16 --> Router Class Initialized
INFO - 2021-07-12 12:05:16 --> Output Class Initialized
INFO - 2021-07-12 12:05:16 --> Security Class Initialized
DEBUG - 2021-07-12 12:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:05:16 --> Input Class Initialized
INFO - 2021-07-12 12:05:16 --> Language Class Initialized
INFO - 2021-07-12 12:05:16 --> Loader Class Initialized
INFO - 2021-07-12 12:05:16 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:05:16 --> Helper loaded: url_helper
INFO - 2021-07-12 12:05:16 --> Helper loaded: file_helper
INFO - 2021-07-12 12:05:16 --> Helper loaded: form_helper
INFO - 2021-07-12 12:05:16 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:05:16 --> Helper loaded: security_helper
INFO - 2021-07-12 12:05:16 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:05:16 --> Helper loaded: language_helper
INFO - 2021-07-12 12:05:16 --> Helper loaded: general_helper
INFO - 2021-07-12 12:05:16 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:05:16 --> Database Driver Class Initialized
DEBUG - 2021-07-12 12:05:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:05:16 --> Parser Class Initialized
INFO - 2021-07-12 12:05:16 --> Form Validation Class Initialized
INFO - 2021-07-12 12:05:16 --> Upload Class Initialized
INFO - 2021-07-12 12:05:16 --> Email Class Initialized
INFO - 2021-07-12 12:05:16 --> MY_Model class loaded
INFO - 2021-07-12 12:05:16 --> Model "Users_model" initialized
INFO - 2021-07-12 12:05:16 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:05:16 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:05:16 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:05:16 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:05:16 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:05:16 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:05:16 --> Database Driver Class Initialized
INFO - 2021-07-12 12:05:16 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:05:16 --> Controller Class Initialized
INFO - 2021-07-12 12:08:56 --> Config Class Initialized
INFO - 2021-07-12 12:08:56 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:08:56 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:08:56 --> Utf8 Class Initialized
INFO - 2021-07-12 12:08:56 --> URI Class Initialized
DEBUG - 2021-07-12 12:08:56 --> No URI present. Default controller set.
INFO - 2021-07-12 12:08:56 --> Router Class Initialized
INFO - 2021-07-12 12:08:56 --> Output Class Initialized
INFO - 2021-07-12 12:08:56 --> Security Class Initialized
DEBUG - 2021-07-12 12:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:08:56 --> Input Class Initialized
INFO - 2021-07-12 12:08:56 --> Language Class Initialized
INFO - 2021-07-12 12:08:56 --> Loader Class Initialized
INFO - 2021-07-12 12:08:56 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:08:56 --> Helper loaded: url_helper
INFO - 2021-07-12 12:08:56 --> Helper loaded: file_helper
INFO - 2021-07-12 12:08:56 --> Helper loaded: form_helper
INFO - 2021-07-12 12:08:56 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:08:56 --> Helper loaded: security_helper
INFO - 2021-07-12 12:08:56 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:08:56 --> Helper loaded: language_helper
INFO - 2021-07-12 12:08:56 --> Helper loaded: general_helper
INFO - 2021-07-12 12:08:56 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:08:56 --> Database Driver Class Initialized
DEBUG - 2021-07-12 12:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:08:56 --> Parser Class Initialized
INFO - 2021-07-12 12:08:56 --> Form Validation Class Initialized
INFO - 2021-07-12 12:08:56 --> Upload Class Initialized
INFO - 2021-07-12 12:08:56 --> Email Class Initialized
INFO - 2021-07-12 12:08:56 --> MY_Model class loaded
INFO - 2021-07-12 12:08:56 --> Model "Users_model" initialized
INFO - 2021-07-12 12:08:56 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:08:56 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:08:56 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:08:56 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:08:56 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:08:56 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:08:56 --> Database Driver Class Initialized
INFO - 2021-07-12 12:08:57 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:08:57 --> Controller Class Initialized
ERROR - 2021-07-12 12:08:57 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 12:08:57 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-12 12:08:57 --> Final output sent to browser
DEBUG - 2021-07-12 12:08:57 --> Total execution time: 0.1504
INFO - 2021-07-12 12:08:57 --> Config Class Initialized
INFO - 2021-07-12 12:08:57 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:08:57 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:08:57 --> Utf8 Class Initialized
INFO - 2021-07-12 12:08:57 --> URI Class Initialized
INFO - 2021-07-12 12:08:57 --> Router Class Initialized
INFO - 2021-07-12 12:08:57 --> Output Class Initialized
INFO - 2021-07-12 12:08:57 --> Security Class Initialized
DEBUG - 2021-07-12 12:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:08:57 --> Input Class Initialized
INFO - 2021-07-12 12:08:57 --> Language Class Initialized
ERROR - 2021-07-12 12:08:57 --> 404 Page Not Found: Faviconico/index
INFO - 2021-07-12 12:08:58 --> Config Class Initialized
INFO - 2021-07-12 12:08:58 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:08:58 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:08:58 --> Utf8 Class Initialized
INFO - 2021-07-12 12:08:58 --> URI Class Initialized
INFO - 2021-07-12 12:08:58 --> Router Class Initialized
INFO - 2021-07-12 12:08:58 --> Output Class Initialized
INFO - 2021-07-12 12:08:58 --> Security Class Initialized
DEBUG - 2021-07-12 12:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:08:58 --> Input Class Initialized
INFO - 2021-07-12 12:08:58 --> Language Class Initialized
INFO - 2021-07-12 12:08:58 --> Loader Class Initialized
INFO - 2021-07-12 12:08:58 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:08:58 --> Helper loaded: url_helper
INFO - 2021-07-12 12:08:58 --> Helper loaded: file_helper
INFO - 2021-07-12 12:08:58 --> Helper loaded: form_helper
INFO - 2021-07-12 12:08:58 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:08:58 --> Helper loaded: security_helper
INFO - 2021-07-12 12:08:58 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:08:58 --> Helper loaded: language_helper
INFO - 2021-07-12 12:08:58 --> Helper loaded: general_helper
INFO - 2021-07-12 12:08:58 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:08:58 --> Database Driver Class Initialized
DEBUG - 2021-07-12 12:08:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:08:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:08:58 --> Parser Class Initialized
INFO - 2021-07-12 12:08:58 --> Form Validation Class Initialized
INFO - 2021-07-12 12:08:58 --> Upload Class Initialized
INFO - 2021-07-12 12:08:58 --> Email Class Initialized
INFO - 2021-07-12 12:08:58 --> MY_Model class loaded
INFO - 2021-07-12 12:08:58 --> Model "Users_model" initialized
INFO - 2021-07-12 12:08:58 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:08:58 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:08:58 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:08:58 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:08:58 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:08:58 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:08:58 --> Database Driver Class Initialized
INFO - 2021-07-12 12:08:58 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:08:58 --> Controller Class Initialized
ERROR - 2021-07-12 12:08:58 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 12:08:58 --> File loaded: C:\wamp64\www\crm\application\views\users/list.php
INFO - 2021-07-12 12:08:58 --> Final output sent to browser
DEBUG - 2021-07-12 12:08:58 --> Total execution time: 0.1121
INFO - 2021-07-12 12:08:59 --> Config Class Initialized
INFO - 2021-07-12 12:08:59 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:08:59 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:08:59 --> Utf8 Class Initialized
INFO - 2021-07-12 12:08:59 --> URI Class Initialized
INFO - 2021-07-12 12:08:59 --> Router Class Initialized
INFO - 2021-07-12 12:08:59 --> Output Class Initialized
INFO - 2021-07-12 12:08:59 --> Security Class Initialized
DEBUG - 2021-07-12 12:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:08:59 --> Input Class Initialized
INFO - 2021-07-12 12:08:59 --> Language Class Initialized
INFO - 2021-07-12 12:08:59 --> Loader Class Initialized
INFO - 2021-07-12 12:08:59 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:08:59 --> Helper loaded: url_helper
INFO - 2021-07-12 12:08:59 --> Helper loaded: file_helper
INFO - 2021-07-12 12:08:59 --> Config Class Initialized
INFO - 2021-07-12 12:08:59 --> Helper loaded: form_helper
INFO - 2021-07-12 12:08:59 --> Hooks Class Initialized
INFO - 2021-07-12 12:08:59 --> Helper loaded: cookie_helper
DEBUG - 2021-07-12 12:08:59 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:08:59 --> Helper loaded: security_helper
INFO - 2021-07-12 12:08:59 --> Utf8 Class Initialized
INFO - 2021-07-12 12:08:59 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:08:59 --> URI Class Initialized
INFO - 2021-07-12 12:08:59 --> Helper loaded: language_helper
INFO - 2021-07-12 12:08:59 --> Helper loaded: general_helper
INFO - 2021-07-12 12:08:59 --> Router Class Initialized
INFO - 2021-07-12 12:08:59 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:08:59 --> Output Class Initialized
INFO - 2021-07-12 12:08:59 --> Config Class Initialized
INFO - 2021-07-12 12:08:59 --> Hooks Class Initialized
INFO - 2021-07-12 12:08:59 --> Database Driver Class Initialized
INFO - 2021-07-12 12:08:59 --> Security Class Initialized
DEBUG - 2021-07-12 12:08:59 --> UTF-8 Support Enabled
DEBUG - 2021-07-12 12:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:08:59 --> Utf8 Class Initialized
INFO - 2021-07-12 12:08:59 --> Input Class Initialized
INFO - 2021-07-12 12:08:59 --> URI Class Initialized
INFO - 2021-07-12 12:08:59 --> Language Class Initialized
INFO - 2021-07-12 12:08:59 --> Router Class Initialized
INFO - 2021-07-12 12:08:59 --> Loader Class Initialized
DEBUG - 2021-07-12 12:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:08:59 --> Output Class Initialized
INFO - 2021-07-12 12:08:59 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:08:59 --> Security Class Initialized
INFO - 2021-07-12 12:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:08:59 --> Helper loaded: url_helper
DEBUG - 2021-07-12 12:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:08:59 --> Parser Class Initialized
INFO - 2021-07-12 12:08:59 --> Helper loaded: file_helper
INFO - 2021-07-12 12:08:59 --> Input Class Initialized
INFO - 2021-07-12 12:08:59 --> Language Class Initialized
INFO - 2021-07-12 12:08:59 --> Config Class Initialized
INFO - 2021-07-12 12:08:59 --> Form Validation Class Initialized
INFO - 2021-07-12 12:08:59 --> Helper loaded: form_helper
INFO - 2021-07-12 12:08:59 --> Hooks Class Initialized
INFO - 2021-07-12 12:08:59 --> Loader Class Initialized
INFO - 2021-07-12 12:08:59 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:08:59 --> Upload Class Initialized
DEBUG - 2021-07-12 12:08:59 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:08:59 --> Helper loaded: security_helper
INFO - 2021-07-12 12:08:59 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:08:59 --> Utf8 Class Initialized
INFO - 2021-07-12 12:08:59 --> Email Class Initialized
INFO - 2021-07-12 12:08:59 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:08:59 --> URI Class Initialized
INFO - 2021-07-12 12:08:59 --> Helper loaded: url_helper
INFO - 2021-07-12 12:08:59 --> MY_Model class loaded
INFO - 2021-07-12 12:08:59 --> Helper loaded: language_helper
INFO - 2021-07-12 12:08:59 --> Helper loaded: file_helper
INFO - 2021-07-12 12:08:59 --> Model "Users_model" initialized
INFO - 2021-07-12 12:08:59 --> Router Class Initialized
INFO - 2021-07-12 12:08:59 --> Helper loaded: general_helper
INFO - 2021-07-12 12:08:59 --> Helper loaded: form_helper
INFO - 2021-07-12 12:08:59 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:08:59 --> Config Class Initialized
INFO - 2021-07-12 12:08:59 --> Output Class Initialized
INFO - 2021-07-12 12:08:59 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:08:59 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:08:59 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:08:59 --> Hooks Class Initialized
INFO - 2021-07-12 12:08:59 --> Security Class Initialized
INFO - 2021-07-12 12:08:59 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:08:59 --> Database Driver Class Initialized
INFO - 2021-07-12 12:08:59 --> Helper loaded: security_helper
DEBUG - 2021-07-12 12:08:59 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:08:59 --> Model "Roles_model" initialized
DEBUG - 2021-07-12 12:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:08:59 --> Utf8 Class Initialized
INFO - 2021-07-12 12:08:59 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:08:59 --> Input Class Initialized
INFO - 2021-07-12 12:08:59 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:08:59 --> URI Class Initialized
INFO - 2021-07-12 12:08:59 --> Language Class Initialized
INFO - 2021-07-12 12:08:59 --> Helper loaded: language_helper
INFO - 2021-07-12 12:08:59 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:08:59 --> Helper loaded: general_helper
DEBUG - 2021-07-12 12:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:08:59 --> Loader Class Initialized
INFO - 2021-07-12 12:08:59 --> Router Class Initialized
INFO - 2021-07-12 12:08:59 --> Database Driver Class Initialized
INFO - 2021-07-12 12:08:59 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:08:59 --> Config Class Initialized
INFO - 2021-07-12 12:08:59 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:08:59 --> Output Class Initialized
INFO - 2021-07-12 12:08:59 --> Hooks Class Initialized
INFO - 2021-07-12 12:08:59 --> Database Driver Class Initialized
INFO - 2021-07-12 12:08:59 --> Security Class Initialized
INFO - 2021-07-12 12:08:59 --> Helper loaded: url_helper
DEBUG - 2021-07-12 12:08:59 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:08:59 --> Utf8 Class Initialized
INFO - 2021-07-12 12:08:59 --> Helper loaded: file_helper
DEBUG - 2021-07-12 12:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:08:59 --> Input Class Initialized
INFO - 2021-07-12 12:08:59 --> Helper loaded: form_helper
INFO - 2021-07-12 12:08:59 --> URI Class Initialized
INFO - 2021-07-12 12:08:59 --> Language Class Initialized
INFO - 2021-07-12 12:08:59 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:08:59 --> Router Class Initialized
INFO - 2021-07-12 12:08:59 --> Loader Class Initialized
INFO - 2021-07-12 12:08:59 --> Helper loaded: security_helper
INFO - 2021-07-12 12:08:59 --> Output Class Initialized
INFO - 2021-07-12 12:08:59 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:08:59 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:08:59 --> Security Class Initialized
INFO - 2021-07-12 12:08:59 --> Helper loaded: language_helper
INFO - 2021-07-12 12:08:59 --> Helper loaded: url_helper
INFO - 2021-07-12 12:08:59 --> Helper loaded: general_helper
DEBUG - 2021-07-12 12:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:08:59 --> Helper loaded: file_helper
INFO - 2021-07-12 12:08:59 --> Input Class Initialized
INFO - 2021-07-12 12:08:59 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:08:59 --> Helper loaded: form_helper
INFO - 2021-07-12 12:08:59 --> Language Class Initialized
INFO - 2021-07-12 12:08:59 --> Database Driver Class Initialized
INFO - 2021-07-12 12:08:59 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:08:59 --> Loader Class Initialized
INFO - 2021-07-12 12:08:59 --> Helper loaded: security_helper
INFO - 2021-07-12 12:08:59 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:08:59 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:08:59 --> Helper loaded: url_helper
INFO - 2021-07-12 12:08:59 --> Helper loaded: language_helper
DEBUG - 2021-07-12 12:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:08:59 --> Helper loaded: file_helper
INFO - 2021-07-12 12:08:59 --> Helper loaded: general_helper
INFO - 2021-07-12 12:08:59 --> Helper loaded: form_helper
INFO - 2021-07-12 12:08:59 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:08:59 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:08:59 --> Database Driver Class Initialized
INFO - 2021-07-12 12:08:59 --> Helper loaded: security_helper
DEBUG - 2021-07-12 12:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:08:59 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:08:59 --> Helper loaded: language_helper
INFO - 2021-07-12 12:08:59 --> Helper loaded: general_helper
DEBUG - 2021-07-12 12:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:08:59 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:08:59 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:08:59 --> Database Driver Class Initialized
INFO - 2021-07-12 12:08:59 --> Controller Class Initialized
DEBUG - 2021-07-12 12:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:08:59 --> Final output sent to browser
DEBUG - 2021-07-12 12:08:59 --> Total execution time: 0.0571
INFO - 2021-07-12 12:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:08:59 --> Parser Class Initialized
INFO - 2021-07-12 12:08:59 --> Form Validation Class Initialized
INFO - 2021-07-12 12:08:59 --> Upload Class Initialized
INFO - 2021-07-12 12:08:59 --> Email Class Initialized
INFO - 2021-07-12 12:08:59 --> MY_Model class loaded
INFO - 2021-07-12 12:08:59 --> Model "Users_model" initialized
INFO - 2021-07-12 12:08:59 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:08:59 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:08:59 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:08:59 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:08:59 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:08:59 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:08:59 --> Database Driver Class Initialized
INFO - 2021-07-12 12:08:59 --> Config Class Initialized
INFO - 2021-07-12 12:08:59 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:08:59 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:08:59 --> Utf8 Class Initialized
INFO - 2021-07-12 12:08:59 --> URI Class Initialized
INFO - 2021-07-12 12:08:59 --> Router Class Initialized
INFO - 2021-07-12 12:08:59 --> Output Class Initialized
INFO - 2021-07-12 12:08:59 --> Security Class Initialized
DEBUG - 2021-07-12 12:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:08:59 --> Input Class Initialized
INFO - 2021-07-12 12:08:59 --> Language Class Initialized
INFO - 2021-07-12 12:08:59 --> Loader Class Initialized
INFO - 2021-07-12 12:08:59 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:08:59 --> Helper loaded: url_helper
INFO - 2021-07-12 12:08:59 --> Helper loaded: file_helper
INFO - 2021-07-12 12:08:59 --> Helper loaded: form_helper
INFO - 2021-07-12 12:08:59 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:08:59 --> Helper loaded: security_helper
INFO - 2021-07-12 12:08:59 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:08:59 --> Helper loaded: language_helper
INFO - 2021-07-12 12:08:59 --> Helper loaded: general_helper
INFO - 2021-07-12 12:08:59 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:08:59 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:08:59 --> Controller Class Initialized
INFO - 2021-07-12 12:08:59 --> Database Driver Class Initialized
INFO - 2021-07-12 12:08:59 --> Final output sent to browser
DEBUG - 2021-07-12 12:08:59 --> Total execution time: 0.0746
DEBUG - 2021-07-12 12:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:08:59 --> Parser Class Initialized
INFO - 2021-07-12 12:08:59 --> Form Validation Class Initialized
INFO - 2021-07-12 12:08:59 --> Upload Class Initialized
INFO - 2021-07-12 12:08:59 --> Email Class Initialized
INFO - 2021-07-12 12:08:59 --> MY_Model class loaded
INFO - 2021-07-12 12:08:59 --> Model "Users_model" initialized
INFO - 2021-07-12 12:08:59 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:08:59 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:08:59 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:08:59 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:08:59 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:08:59 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:08:59 --> Database Driver Class Initialized
INFO - 2021-07-12 12:08:59 --> Config Class Initialized
INFO - 2021-07-12 12:08:59 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:08:59 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:08:59 --> Utf8 Class Initialized
INFO - 2021-07-12 12:08:59 --> URI Class Initialized
INFO - 2021-07-12 12:08:59 --> Router Class Initialized
INFO - 2021-07-12 12:08:59 --> Output Class Initialized
INFO - 2021-07-12 12:08:59 --> Security Class Initialized
DEBUG - 2021-07-12 12:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:08:59 --> Input Class Initialized
INFO - 2021-07-12 12:08:59 --> Language Class Initialized
INFO - 2021-07-12 12:08:59 --> Loader Class Initialized
INFO - 2021-07-12 12:08:59 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:08:59 --> Helper loaded: url_helper
INFO - 2021-07-12 12:08:59 --> Helper loaded: file_helper
INFO - 2021-07-12 12:08:59 --> Helper loaded: form_helper
INFO - 2021-07-12 12:08:59 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:08:59 --> Helper loaded: security_helper
INFO - 2021-07-12 12:08:59 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:08:59 --> Helper loaded: language_helper
INFO - 2021-07-12 12:08:59 --> Helper loaded: general_helper
INFO - 2021-07-12 12:08:59 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:08:59 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:08:59 --> Controller Class Initialized
INFO - 2021-07-12 12:08:59 --> Database Driver Class Initialized
INFO - 2021-07-12 12:08:59 --> Final output sent to browser
DEBUG - 2021-07-12 12:08:59 --> Total execution time: 0.0896
DEBUG - 2021-07-12 12:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:08:59 --> Parser Class Initialized
INFO - 2021-07-12 12:08:59 --> Form Validation Class Initialized
INFO - 2021-07-12 12:08:59 --> Upload Class Initialized
INFO - 2021-07-12 12:08:59 --> Email Class Initialized
INFO - 2021-07-12 12:08:59 --> MY_Model class loaded
INFO - 2021-07-12 12:08:59 --> Model "Users_model" initialized
INFO - 2021-07-12 12:08:59 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:08:59 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:08:59 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:08:59 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:08:59 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:08:59 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:08:59 --> Database Driver Class Initialized
INFO - 2021-07-12 12:08:59 --> Config Class Initialized
INFO - 2021-07-12 12:08:59 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:08:59 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:08:59 --> Utf8 Class Initialized
INFO - 2021-07-12 12:08:59 --> URI Class Initialized
INFO - 2021-07-12 12:08:59 --> Router Class Initialized
INFO - 2021-07-12 12:08:59 --> Output Class Initialized
INFO - 2021-07-12 12:08:59 --> Security Class Initialized
DEBUG - 2021-07-12 12:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:08:59 --> Input Class Initialized
INFO - 2021-07-12 12:08:59 --> Language Class Initialized
INFO - 2021-07-12 12:08:59 --> Loader Class Initialized
INFO - 2021-07-12 12:08:59 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:08:59 --> Helper loaded: url_helper
INFO - 2021-07-12 12:08:59 --> Helper loaded: file_helper
INFO - 2021-07-12 12:08:59 --> Helper loaded: form_helper
INFO - 2021-07-12 12:08:59 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:08:59 --> Helper loaded: security_helper
INFO - 2021-07-12 12:08:59 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:08:59 --> Helper loaded: language_helper
INFO - 2021-07-12 12:08:59 --> Helper loaded: general_helper
INFO - 2021-07-12 12:08:59 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:08:59 --> Database Driver Class Initialized
INFO - 2021-07-12 12:08:59 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:08:59 --> Controller Class Initialized
DEBUG - 2021-07-12 12:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:08:59 --> Final output sent to browser
DEBUG - 2021-07-12 12:08:59 --> Total execution time: 0.1246
INFO - 2021-07-12 12:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:08:59 --> Parser Class Initialized
INFO - 2021-07-12 12:08:59 --> Form Validation Class Initialized
INFO - 2021-07-12 12:08:59 --> Upload Class Initialized
INFO - 2021-07-12 12:08:59 --> Email Class Initialized
INFO - 2021-07-12 12:08:59 --> MY_Model class loaded
INFO - 2021-07-12 12:08:59 --> Model "Users_model" initialized
INFO - 2021-07-12 12:08:59 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:08:59 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:08:59 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:08:59 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:08:59 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:08:59 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:08:59 --> Database Driver Class Initialized
INFO - 2021-07-12 12:08:59 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:08:59 --> Controller Class Initialized
INFO - 2021-07-12 12:08:59 --> Final output sent to browser
DEBUG - 2021-07-12 12:08:59 --> Total execution time: 0.1393
INFO - 2021-07-12 12:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:08:59 --> Parser Class Initialized
INFO - 2021-07-12 12:08:59 --> Form Validation Class Initialized
INFO - 2021-07-12 12:08:59 --> Upload Class Initialized
INFO - 2021-07-12 12:08:59 --> Email Class Initialized
INFO - 2021-07-12 12:08:59 --> MY_Model class loaded
INFO - 2021-07-12 12:08:59 --> Model "Users_model" initialized
INFO - 2021-07-12 12:08:59 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:08:59 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:08:59 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:08:59 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:08:59 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:08:59 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:08:59 --> Database Driver Class Initialized
INFO - 2021-07-12 12:08:59 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:08:59 --> Controller Class Initialized
INFO - 2021-07-12 12:08:59 --> Final output sent to browser
DEBUG - 2021-07-12 12:08:59 --> Total execution time: 0.1621
INFO - 2021-07-12 12:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:08:59 --> Parser Class Initialized
INFO - 2021-07-12 12:08:59 --> Form Validation Class Initialized
INFO - 2021-07-12 12:08:59 --> Upload Class Initialized
INFO - 2021-07-12 12:08:59 --> Email Class Initialized
INFO - 2021-07-12 12:08:59 --> MY_Model class loaded
INFO - 2021-07-12 12:08:59 --> Model "Users_model" initialized
INFO - 2021-07-12 12:08:59 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:08:59 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:08:59 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:08:59 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:08:59 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:08:59 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:08:59 --> Database Driver Class Initialized
INFO - 2021-07-12 12:08:59 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:08:59 --> Controller Class Initialized
INFO - 2021-07-12 12:08:59 --> Final output sent to browser
DEBUG - 2021-07-12 12:08:59 --> Total execution time: 0.1553
INFO - 2021-07-12 12:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:08:59 --> Parser Class Initialized
INFO - 2021-07-12 12:08:59 --> Form Validation Class Initialized
INFO - 2021-07-12 12:08:59 --> Upload Class Initialized
INFO - 2021-07-12 12:08:59 --> Email Class Initialized
INFO - 2021-07-12 12:08:59 --> MY_Model class loaded
INFO - 2021-07-12 12:08:59 --> Model "Users_model" initialized
INFO - 2021-07-12 12:08:59 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:08:59 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:08:59 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:08:59 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:08:59 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:08:59 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:08:59 --> Database Driver Class Initialized
INFO - 2021-07-12 12:08:59 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:08:59 --> Controller Class Initialized
INFO - 2021-07-12 12:08:59 --> Final output sent to browser
DEBUG - 2021-07-12 12:08:59 --> Total execution time: 0.1558
INFO - 2021-07-12 12:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:08:59 --> Parser Class Initialized
INFO - 2021-07-12 12:08:59 --> Form Validation Class Initialized
INFO - 2021-07-12 12:08:59 --> Upload Class Initialized
INFO - 2021-07-12 12:08:59 --> Email Class Initialized
INFO - 2021-07-12 12:08:59 --> MY_Model class loaded
INFO - 2021-07-12 12:08:59 --> Model "Users_model" initialized
INFO - 2021-07-12 12:08:59 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:08:59 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:08:59 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:08:59 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:08:59 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:08:59 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:08:59 --> Database Driver Class Initialized
INFO - 2021-07-12 12:08:59 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:08:59 --> Controller Class Initialized
INFO - 2021-07-12 12:08:59 --> Final output sent to browser
DEBUG - 2021-07-12 12:08:59 --> Total execution time: 0.1583
INFO - 2021-07-12 12:09:17 --> Config Class Initialized
INFO - 2021-07-12 12:09:17 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:09:17 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:09:17 --> Utf8 Class Initialized
INFO - 2021-07-12 12:09:17 --> URI Class Initialized
INFO - 2021-07-12 12:09:17 --> Router Class Initialized
INFO - 2021-07-12 12:09:17 --> Output Class Initialized
INFO - 2021-07-12 12:09:17 --> Security Class Initialized
DEBUG - 2021-07-12 12:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:09:17 --> Input Class Initialized
INFO - 2021-07-12 12:09:17 --> Language Class Initialized
INFO - 2021-07-12 12:09:17 --> Loader Class Initialized
INFO - 2021-07-12 12:09:17 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:09:17 --> Helper loaded: url_helper
INFO - 2021-07-12 12:09:17 --> Helper loaded: file_helper
INFO - 2021-07-12 12:09:17 --> Helper loaded: form_helper
INFO - 2021-07-12 12:09:17 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:09:17 --> Helper loaded: security_helper
INFO - 2021-07-12 12:09:17 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:09:17 --> Helper loaded: language_helper
INFO - 2021-07-12 12:09:17 --> Helper loaded: general_helper
INFO - 2021-07-12 12:09:17 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:09:17 --> Database Driver Class Initialized
DEBUG - 2021-07-12 12:09:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:09:17 --> Parser Class Initialized
INFO - 2021-07-12 12:09:17 --> Form Validation Class Initialized
INFO - 2021-07-12 12:09:17 --> Upload Class Initialized
INFO - 2021-07-12 12:09:17 --> Email Class Initialized
INFO - 2021-07-12 12:09:17 --> MY_Model class loaded
INFO - 2021-07-12 12:09:17 --> Model "Users_model" initialized
INFO - 2021-07-12 12:09:17 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:09:17 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:09:17 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:09:17 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:09:17 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:09:17 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:09:17 --> Database Driver Class Initialized
INFO - 2021-07-12 12:09:17 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:09:17 --> Controller Class Initialized
ERROR - 2021-07-12 12:09:17 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 12:09:17 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-12 12:09:17 --> Final output sent to browser
DEBUG - 2021-07-12 12:09:17 --> Total execution time: 0.1871
INFO - 2021-07-12 12:09:22 --> Config Class Initialized
INFO - 2021-07-12 12:09:22 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:09:22 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:09:22 --> Utf8 Class Initialized
INFO - 2021-07-12 12:09:22 --> URI Class Initialized
INFO - 2021-07-12 12:09:22 --> Router Class Initialized
INFO - 2021-07-12 12:09:22 --> Output Class Initialized
INFO - 2021-07-12 12:09:22 --> Security Class Initialized
DEBUG - 2021-07-12 12:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:09:22 --> Input Class Initialized
INFO - 2021-07-12 12:09:22 --> Language Class Initialized
INFO - 2021-07-12 12:09:22 --> Loader Class Initialized
INFO - 2021-07-12 12:09:22 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:09:22 --> Helper loaded: url_helper
INFO - 2021-07-12 12:09:22 --> Helper loaded: file_helper
INFO - 2021-07-12 12:09:22 --> Helper loaded: form_helper
INFO - 2021-07-12 12:09:22 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:09:22 --> Helper loaded: security_helper
INFO - 2021-07-12 12:09:22 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:09:22 --> Helper loaded: language_helper
INFO - 2021-07-12 12:09:22 --> Helper loaded: general_helper
INFO - 2021-07-12 12:09:22 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:09:22 --> Database Driver Class Initialized
DEBUG - 2021-07-12 12:09:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:09:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:09:22 --> Parser Class Initialized
INFO - 2021-07-12 12:09:22 --> Form Validation Class Initialized
INFO - 2021-07-12 12:09:22 --> Upload Class Initialized
INFO - 2021-07-12 12:09:22 --> Email Class Initialized
INFO - 2021-07-12 12:09:22 --> MY_Model class loaded
INFO - 2021-07-12 12:09:22 --> Model "Users_model" initialized
INFO - 2021-07-12 12:09:22 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:09:22 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:09:22 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:09:22 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:09:22 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:09:22 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:09:22 --> Database Driver Class Initialized
INFO - 2021-07-12 12:09:22 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:09:22 --> Controller Class Initialized
ERROR - 2021-07-12 12:09:22 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 12:09:22 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-12 12:09:22 --> Final output sent to browser
DEBUG - 2021-07-12 12:09:22 --> Total execution time: 0.1215
INFO - 2021-07-12 12:10:23 --> Config Class Initialized
INFO - 2021-07-12 12:10:23 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:10:23 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:10:23 --> Utf8 Class Initialized
INFO - 2021-07-12 12:10:23 --> URI Class Initialized
INFO - 2021-07-12 12:10:23 --> Router Class Initialized
INFO - 2021-07-12 12:10:23 --> Output Class Initialized
INFO - 2021-07-12 12:10:23 --> Security Class Initialized
DEBUG - 2021-07-12 12:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:10:23 --> Input Class Initialized
INFO - 2021-07-12 12:10:23 --> Language Class Initialized
INFO - 2021-07-12 12:10:23 --> Loader Class Initialized
INFO - 2021-07-12 12:10:23 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:10:23 --> Helper loaded: url_helper
INFO - 2021-07-12 12:10:23 --> Helper loaded: file_helper
INFO - 2021-07-12 12:10:23 --> Helper loaded: form_helper
INFO - 2021-07-12 12:10:23 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:10:23 --> Helper loaded: security_helper
INFO - 2021-07-12 12:10:23 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:10:23 --> Helper loaded: language_helper
INFO - 2021-07-12 12:10:23 --> Helper loaded: general_helper
INFO - 2021-07-12 12:10:23 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:10:23 --> Database Driver Class Initialized
DEBUG - 2021-07-12 12:10:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:10:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:10:23 --> Parser Class Initialized
INFO - 2021-07-12 12:10:23 --> Form Validation Class Initialized
INFO - 2021-07-12 12:10:23 --> Upload Class Initialized
INFO - 2021-07-12 12:10:23 --> Email Class Initialized
INFO - 2021-07-12 12:10:23 --> MY_Model class loaded
INFO - 2021-07-12 12:10:23 --> Model "Users_model" initialized
INFO - 2021-07-12 12:10:23 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:10:23 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:10:23 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:10:23 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:10:23 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:10:23 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:10:23 --> Database Driver Class Initialized
INFO - 2021-07-12 12:10:24 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:10:24 --> Controller Class Initialized
ERROR - 2021-07-12 12:10:24 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 12:10:24 --> File loaded: C:\wamp64\www\crm\application\views\users/edit.php
INFO - 2021-07-12 12:10:24 --> Final output sent to browser
DEBUG - 2021-07-12 12:10:24 --> Total execution time: 0.5431
INFO - 2021-07-12 12:10:30 --> Config Class Initialized
INFO - 2021-07-12 12:10:30 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:10:30 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:10:30 --> Utf8 Class Initialized
INFO - 2021-07-12 12:10:30 --> URI Class Initialized
INFO - 2021-07-12 12:10:30 --> Router Class Initialized
INFO - 2021-07-12 12:10:30 --> Output Class Initialized
INFO - 2021-07-12 12:10:30 --> Security Class Initialized
DEBUG - 2021-07-12 12:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:10:30 --> Input Class Initialized
INFO - 2021-07-12 12:10:30 --> Language Class Initialized
INFO - 2021-07-12 12:10:30 --> Loader Class Initialized
INFO - 2021-07-12 12:10:30 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:10:30 --> Helper loaded: url_helper
INFO - 2021-07-12 12:10:30 --> Helper loaded: file_helper
INFO - 2021-07-12 12:10:30 --> Helper loaded: form_helper
INFO - 2021-07-12 12:10:30 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:10:30 --> Helper loaded: security_helper
INFO - 2021-07-12 12:10:30 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:10:30 --> Helper loaded: language_helper
INFO - 2021-07-12 12:10:30 --> Helper loaded: general_helper
INFO - 2021-07-12 12:10:30 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:10:30 --> Database Driver Class Initialized
DEBUG - 2021-07-12 12:10:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:10:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:10:30 --> Parser Class Initialized
INFO - 2021-07-12 12:10:30 --> Form Validation Class Initialized
INFO - 2021-07-12 12:10:30 --> Upload Class Initialized
INFO - 2021-07-12 12:10:30 --> Email Class Initialized
INFO - 2021-07-12 12:10:30 --> MY_Model class loaded
INFO - 2021-07-12 12:10:30 --> Model "Users_model" initialized
INFO - 2021-07-12 12:10:30 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:10:30 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:10:30 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:10:30 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:10:30 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:10:30 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:10:30 --> Database Driver Class Initialized
INFO - 2021-07-12 12:10:30 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:10:30 --> Controller Class Initialized
ERROR - 2021-07-12 12:10:30 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 12:10:30 --> File loaded: C:\wamp64\www\crm\application\views\users/list.php
INFO - 2021-07-12 12:10:30 --> Final output sent to browser
DEBUG - 2021-07-12 12:10:30 --> Total execution time: 0.1946
INFO - 2021-07-12 12:10:31 --> Config Class Initialized
INFO - 2021-07-12 12:10:31 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:10:31 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:10:31 --> Utf8 Class Initialized
INFO - 2021-07-12 12:10:31 --> URI Class Initialized
INFO - 2021-07-12 12:10:31 --> Router Class Initialized
INFO - 2021-07-12 12:10:31 --> Output Class Initialized
INFO - 2021-07-12 12:10:31 --> Security Class Initialized
DEBUG - 2021-07-12 12:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:10:31 --> Input Class Initialized
INFO - 2021-07-12 12:10:31 --> Language Class Initialized
INFO - 2021-07-12 12:10:31 --> Loader Class Initialized
INFO - 2021-07-12 12:10:31 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:10:31 --> Helper loaded: url_helper
INFO - 2021-07-12 12:10:31 --> Helper loaded: file_helper
INFO - 2021-07-12 12:10:31 --> Helper loaded: form_helper
INFO - 2021-07-12 12:10:31 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:10:31 --> Helper loaded: security_helper
INFO - 2021-07-12 12:10:31 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:10:31 --> Helper loaded: language_helper
INFO - 2021-07-12 12:10:31 --> Helper loaded: general_helper
INFO - 2021-07-12 12:10:31 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:10:31 --> Database Driver Class Initialized
INFO - 2021-07-12 12:10:31 --> Config Class Initialized
INFO - 2021-07-12 12:10:31 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:10:31 --> UTF-8 Support Enabled
DEBUG - 2021-07-12 12:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:10:31 --> Utf8 Class Initialized
INFO - 2021-07-12 12:10:31 --> URI Class Initialized
INFO - 2021-07-12 12:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:10:31 --> Router Class Initialized
INFO - 2021-07-12 12:10:31 --> Parser Class Initialized
INFO - 2021-07-12 12:10:31 --> Config Class Initialized
INFO - 2021-07-12 12:10:31 --> Hooks Class Initialized
INFO - 2021-07-12 12:10:31 --> Output Class Initialized
INFO - 2021-07-12 12:10:31 --> Form Validation Class Initialized
DEBUG - 2021-07-12 12:10:31 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:10:31 --> Security Class Initialized
INFO - 2021-07-12 12:10:31 --> Utf8 Class Initialized
INFO - 2021-07-12 12:10:31 --> Upload Class Initialized
DEBUG - 2021-07-12 12:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:10:31 --> URI Class Initialized
INFO - 2021-07-12 12:10:31 --> Input Class Initialized
INFO - 2021-07-12 12:10:31 --> Email Class Initialized
INFO - 2021-07-12 12:10:31 --> Language Class Initialized
INFO - 2021-07-12 12:10:31 --> Router Class Initialized
INFO - 2021-07-12 12:10:31 --> MY_Model class loaded
INFO - 2021-07-12 12:10:31 --> Model "Users_model" initialized
INFO - 2021-07-12 12:10:31 --> Output Class Initialized
INFO - 2021-07-12 12:10:31 --> Loader Class Initialized
INFO - 2021-07-12 12:10:31 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:10:31 --> Security Class Initialized
INFO - 2021-07-12 12:10:31 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:10:31 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:10:31 --> Config Class Initialized
DEBUG - 2021-07-12 12:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:10:31 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:10:31 --> Hooks Class Initialized
INFO - 2021-07-12 12:10:31 --> Input Class Initialized
INFO - 2021-07-12 12:10:31 --> Helper loaded: url_helper
INFO - 2021-07-12 12:10:31 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:10:31 --> Language Class Initialized
INFO - 2021-07-12 12:10:31 --> Model "Activity_model" initialized
DEBUG - 2021-07-12 12:10:31 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:10:31 --> Helper loaded: file_helper
INFO - 2021-07-12 12:10:31 --> Utf8 Class Initialized
INFO - 2021-07-12 12:10:31 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:10:31 --> Loader Class Initialized
INFO - 2021-07-12 12:10:31 --> Helper loaded: form_helper
INFO - 2021-07-12 12:10:31 --> URI Class Initialized
INFO - 2021-07-12 12:10:31 --> Database Driver Class Initialized
INFO - 2021-07-12 12:10:31 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:10:31 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:10:31 --> Helper loaded: security_helper
INFO - 2021-07-12 12:10:31 --> Router Class Initialized
INFO - 2021-07-12 12:10:31 --> Helper loaded: url_helper
INFO - 2021-07-12 12:10:31 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:10:31 --> Output Class Initialized
INFO - 2021-07-12 12:10:31 --> Helper loaded: file_helper
INFO - 2021-07-12 12:10:31 --> Helper loaded: language_helper
INFO - 2021-07-12 12:10:31 --> Security Class Initialized
INFO - 2021-07-12 12:10:31 --> Helper loaded: form_helper
INFO - 2021-07-12 12:10:31 --> Helper loaded: general_helper
INFO - 2021-07-12 12:10:31 --> Helper loaded: cookie_helper
DEBUG - 2021-07-12 12:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:10:31 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:10:31 --> Config Class Initialized
INFO - 2021-07-12 12:10:31 --> Input Class Initialized
INFO - 2021-07-12 12:10:31 --> Helper loaded: security_helper
INFO - 2021-07-12 12:10:31 --> Hooks Class Initialized
INFO - 2021-07-12 12:10:31 --> Language Class Initialized
INFO - 2021-07-12 12:10:31 --> Database Driver Class Initialized
INFO - 2021-07-12 12:10:31 --> Helper loaded: directory_helper
DEBUG - 2021-07-12 12:10:31 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:10:31 --> Loader Class Initialized
INFO - 2021-07-12 12:10:31 --> Utf8 Class Initialized
INFO - 2021-07-12 12:10:31 --> Helper loaded: language_helper
INFO - 2021-07-12 12:10:31 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:10:31 --> Helper loaded: general_helper
INFO - 2021-07-12 12:10:31 --> Config Class Initialized
INFO - 2021-07-12 12:10:31 --> URI Class Initialized
DEBUG - 2021-07-12 12:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:10:31 --> Helper loaded: url_helper
INFO - 2021-07-12 12:10:31 --> Hooks Class Initialized
INFO - 2021-07-12 12:10:31 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:10:31 --> Router Class Initialized
INFO - 2021-07-12 12:10:31 --> Helper loaded: file_helper
DEBUG - 2021-07-12 12:10:31 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:10:31 --> Database Driver Class Initialized
INFO - 2021-07-12 12:10:31 --> Utf8 Class Initialized
INFO - 2021-07-12 12:10:31 --> Output Class Initialized
INFO - 2021-07-12 12:10:31 --> Helper loaded: form_helper
INFO - 2021-07-12 12:10:31 --> URI Class Initialized
INFO - 2021-07-12 12:10:31 --> Security Class Initialized
INFO - 2021-07-12 12:10:31 --> Helper loaded: cookie_helper
DEBUG - 2021-07-12 12:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:10:31 --> Helper loaded: security_helper
INFO - 2021-07-12 12:10:31 --> Router Class Initialized
INFO - 2021-07-12 12:10:31 --> Input Class Initialized
INFO - 2021-07-12 12:10:31 --> Helper loaded: directory_helper
DEBUG - 2021-07-12 12:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:10:31 --> Output Class Initialized
INFO - 2021-07-12 12:10:31 --> Language Class Initialized
INFO - 2021-07-12 12:10:31 --> Helper loaded: language_helper
INFO - 2021-07-12 12:10:31 --> Security Class Initialized
INFO - 2021-07-12 12:10:31 --> Helper loaded: general_helper
INFO - 2021-07-12 12:10:31 --> Loader Class Initialized
DEBUG - 2021-07-12 12:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:10:31 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:10:31 --> Input Class Initialized
INFO - 2021-07-12 12:10:31 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:10:31 --> Language Class Initialized
INFO - 2021-07-12 12:10:31 --> Database Driver Class Initialized
INFO - 2021-07-12 12:10:31 --> Helper loaded: url_helper
INFO - 2021-07-12 12:10:31 --> Loader Class Initialized
INFO - 2021-07-12 12:10:31 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:10:31 --> Helper loaded: file_helper
INFO - 2021-07-12 12:10:31 --> Controller Class Initialized
INFO - 2021-07-12 12:10:31 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:10:31 --> Helper loaded: form_helper
INFO - 2021-07-12 12:10:31 --> Helper loaded: url_helper
DEBUG - 2021-07-12 12:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:10:31 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:10:31 --> Helper loaded: file_helper
INFO - 2021-07-12 12:10:31 --> Helper loaded: security_helper
INFO - 2021-07-12 12:10:31 --> Final output sent to browser
INFO - 2021-07-12 12:10:31 --> Helper loaded: form_helper
DEBUG - 2021-07-12 12:10:31 --> Total execution time: 0.0499
INFO - 2021-07-12 12:10:31 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:10:31 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:10:31 --> Helper loaded: language_helper
INFO - 2021-07-12 12:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:10:31 --> Helper loaded: security_helper
INFO - 2021-07-12 12:10:31 --> Helper loaded: general_helper
INFO - 2021-07-12 12:10:31 --> Parser Class Initialized
INFO - 2021-07-12 12:10:31 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:10:31 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:10:31 --> Helper loaded: language_helper
INFO - 2021-07-12 12:10:31 --> Form Validation Class Initialized
INFO - 2021-07-12 12:10:31 --> Database Driver Class Initialized
INFO - 2021-07-12 12:10:31 --> Helper loaded: general_helper
INFO - 2021-07-12 12:10:31 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:10:31 --> Upload Class Initialized
INFO - 2021-07-12 12:10:31 --> Database Driver Class Initialized
INFO - 2021-07-12 12:10:31 --> Email Class Initialized
INFO - 2021-07-12 12:10:31 --> MY_Model class loaded
DEBUG - 2021-07-12 12:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:10:31 --> Model "Users_model" initialized
INFO - 2021-07-12 12:10:31 --> Model "Settings_model" initialized
DEBUG - 2021-07-12 12:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:10:31 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:10:31 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:10:31 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:10:31 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:10:31 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:10:31 --> Database Driver Class Initialized
INFO - 2021-07-12 12:10:31 --> Config Class Initialized
INFO - 2021-07-12 12:10:31 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:10:31 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:10:31 --> Utf8 Class Initialized
INFO - 2021-07-12 12:10:31 --> URI Class Initialized
INFO - 2021-07-12 12:10:31 --> Router Class Initialized
INFO - 2021-07-12 12:10:31 --> Output Class Initialized
INFO - 2021-07-12 12:10:31 --> Security Class Initialized
DEBUG - 2021-07-12 12:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:10:31 --> Input Class Initialized
INFO - 2021-07-12 12:10:31 --> Language Class Initialized
INFO - 2021-07-12 12:10:31 --> Loader Class Initialized
INFO - 2021-07-12 12:10:31 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:10:31 --> Helper loaded: url_helper
INFO - 2021-07-12 12:10:31 --> Helper loaded: file_helper
INFO - 2021-07-12 12:10:31 --> Helper loaded: form_helper
INFO - 2021-07-12 12:10:31 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:10:31 --> Helper loaded: security_helper
INFO - 2021-07-12 12:10:31 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:10:31 --> Helper loaded: language_helper
INFO - 2021-07-12 12:10:31 --> Helper loaded: general_helper
INFO - 2021-07-12 12:10:31 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:10:31 --> Database Driver Class Initialized
INFO - 2021-07-12 12:10:31 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:10:31 --> Controller Class Initialized
DEBUG - 2021-07-12 12:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:10:31 --> Final output sent to browser
DEBUG - 2021-07-12 12:10:31 --> Total execution time: 0.0644
INFO - 2021-07-12 12:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:10:31 --> Parser Class Initialized
INFO - 2021-07-12 12:10:31 --> Form Validation Class Initialized
INFO - 2021-07-12 12:10:31 --> Upload Class Initialized
INFO - 2021-07-12 12:10:31 --> Email Class Initialized
INFO - 2021-07-12 12:10:31 --> MY_Model class loaded
INFO - 2021-07-12 12:10:31 --> Model "Users_model" initialized
INFO - 2021-07-12 12:10:31 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:10:31 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:10:31 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:10:31 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:10:31 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:10:31 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:10:31 --> Database Driver Class Initialized
INFO - 2021-07-12 12:10:31 --> Config Class Initialized
INFO - 2021-07-12 12:10:31 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:10:31 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:10:31 --> Utf8 Class Initialized
INFO - 2021-07-12 12:10:31 --> URI Class Initialized
INFO - 2021-07-12 12:10:31 --> Router Class Initialized
INFO - 2021-07-12 12:10:31 --> Output Class Initialized
INFO - 2021-07-12 12:10:31 --> Security Class Initialized
DEBUG - 2021-07-12 12:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:10:31 --> Input Class Initialized
INFO - 2021-07-12 12:10:31 --> Language Class Initialized
INFO - 2021-07-12 12:10:31 --> Loader Class Initialized
INFO - 2021-07-12 12:10:31 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:10:31 --> Helper loaded: url_helper
INFO - 2021-07-12 12:10:31 --> Helper loaded: file_helper
INFO - 2021-07-12 12:10:31 --> Helper loaded: form_helper
INFO - 2021-07-12 12:10:31 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:10:31 --> Helper loaded: security_helper
INFO - 2021-07-12 12:10:31 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:10:31 --> Helper loaded: language_helper
INFO - 2021-07-12 12:10:31 --> Helper loaded: general_helper
INFO - 2021-07-12 12:10:31 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:10:31 --> Database Driver Class Initialized
INFO - 2021-07-12 12:10:31 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:10:31 --> Controller Class Initialized
DEBUG - 2021-07-12 12:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:10:31 --> Final output sent to browser
DEBUG - 2021-07-12 12:10:31 --> Total execution time: 0.0900
INFO - 2021-07-12 12:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:10:31 --> Parser Class Initialized
INFO - 2021-07-12 12:10:31 --> Form Validation Class Initialized
INFO - 2021-07-12 12:10:31 --> Upload Class Initialized
INFO - 2021-07-12 12:10:31 --> Email Class Initialized
INFO - 2021-07-12 12:10:31 --> MY_Model class loaded
INFO - 2021-07-12 12:10:31 --> Model "Users_model" initialized
INFO - 2021-07-12 12:10:31 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:10:31 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:10:31 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:10:31 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:10:31 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:10:31 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:10:31 --> Database Driver Class Initialized
INFO - 2021-07-12 12:10:31 --> Config Class Initialized
INFO - 2021-07-12 12:10:31 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:10:31 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:10:31 --> Utf8 Class Initialized
INFO - 2021-07-12 12:10:31 --> URI Class Initialized
INFO - 2021-07-12 12:10:31 --> Router Class Initialized
INFO - 2021-07-12 12:10:31 --> Output Class Initialized
INFO - 2021-07-12 12:10:31 --> Security Class Initialized
DEBUG - 2021-07-12 12:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:10:31 --> Input Class Initialized
INFO - 2021-07-12 12:10:31 --> Language Class Initialized
INFO - 2021-07-12 12:10:31 --> Loader Class Initialized
INFO - 2021-07-12 12:10:31 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:10:31 --> Helper loaded: url_helper
INFO - 2021-07-12 12:10:31 --> Helper loaded: file_helper
INFO - 2021-07-12 12:10:31 --> Helper loaded: form_helper
INFO - 2021-07-12 12:10:31 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:10:31 --> Helper loaded: security_helper
INFO - 2021-07-12 12:10:31 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:10:31 --> Helper loaded: language_helper
INFO - 2021-07-12 12:10:31 --> Helper loaded: general_helper
INFO - 2021-07-12 12:10:31 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:10:31 --> Database Driver Class Initialized
INFO - 2021-07-12 12:10:31 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:10:31 --> Controller Class Initialized
DEBUG - 2021-07-12 12:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:10:31 --> Final output sent to browser
DEBUG - 2021-07-12 12:10:31 --> Total execution time: 0.1158
INFO - 2021-07-12 12:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:10:31 --> Parser Class Initialized
INFO - 2021-07-12 12:10:31 --> Form Validation Class Initialized
INFO - 2021-07-12 12:10:31 --> Upload Class Initialized
INFO - 2021-07-12 12:10:31 --> Email Class Initialized
INFO - 2021-07-12 12:10:31 --> MY_Model class loaded
INFO - 2021-07-12 12:10:31 --> Model "Users_model" initialized
INFO - 2021-07-12 12:10:31 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:10:31 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:10:31 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:10:31 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:10:31 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:10:31 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:10:31 --> Database Driver Class Initialized
INFO - 2021-07-12 12:10:31 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:10:31 --> Controller Class Initialized
INFO - 2021-07-12 12:10:31 --> Final output sent to browser
DEBUG - 2021-07-12 12:10:31 --> Total execution time: 0.1360
INFO - 2021-07-12 12:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:10:31 --> Parser Class Initialized
INFO - 2021-07-12 12:10:31 --> Form Validation Class Initialized
INFO - 2021-07-12 12:10:31 --> Upload Class Initialized
INFO - 2021-07-12 12:10:31 --> Email Class Initialized
INFO - 2021-07-12 12:10:31 --> MY_Model class loaded
INFO - 2021-07-12 12:10:31 --> Model "Users_model" initialized
INFO - 2021-07-12 12:10:31 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:10:31 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:10:31 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:10:31 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:10:31 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:10:31 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:10:31 --> Database Driver Class Initialized
INFO - 2021-07-12 12:10:31 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:10:31 --> Controller Class Initialized
INFO - 2021-07-12 12:10:31 --> Final output sent to browser
DEBUG - 2021-07-12 12:10:31 --> Total execution time: 0.1587
INFO - 2021-07-12 12:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:10:31 --> Parser Class Initialized
INFO - 2021-07-12 12:10:31 --> Form Validation Class Initialized
INFO - 2021-07-12 12:10:31 --> Upload Class Initialized
INFO - 2021-07-12 12:10:31 --> Email Class Initialized
INFO - 2021-07-12 12:10:31 --> MY_Model class loaded
INFO - 2021-07-12 12:10:31 --> Model "Users_model" initialized
INFO - 2021-07-12 12:10:31 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:10:31 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:10:31 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:10:31 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:10:31 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:10:31 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:10:31 --> Database Driver Class Initialized
INFO - 2021-07-12 12:10:31 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:10:31 --> Controller Class Initialized
INFO - 2021-07-12 12:10:31 --> Final output sent to browser
DEBUG - 2021-07-12 12:10:31 --> Total execution time: 0.1615
INFO - 2021-07-12 12:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:10:31 --> Parser Class Initialized
INFO - 2021-07-12 12:10:31 --> Form Validation Class Initialized
INFO - 2021-07-12 12:10:31 --> Upload Class Initialized
INFO - 2021-07-12 12:10:31 --> Email Class Initialized
INFO - 2021-07-12 12:10:31 --> MY_Model class loaded
INFO - 2021-07-12 12:10:31 --> Model "Users_model" initialized
INFO - 2021-07-12 12:10:31 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:10:31 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:10:31 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:10:31 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:10:31 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:10:31 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:10:31 --> Database Driver Class Initialized
INFO - 2021-07-12 12:10:31 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:10:31 --> Controller Class Initialized
INFO - 2021-07-12 12:10:31 --> Final output sent to browser
DEBUG - 2021-07-12 12:10:31 --> Total execution time: 0.1598
INFO - 2021-07-12 12:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:10:31 --> Parser Class Initialized
INFO - 2021-07-12 12:10:31 --> Form Validation Class Initialized
INFO - 2021-07-12 12:10:31 --> Upload Class Initialized
INFO - 2021-07-12 12:10:31 --> Email Class Initialized
INFO - 2021-07-12 12:10:31 --> MY_Model class loaded
INFO - 2021-07-12 12:10:31 --> Model "Users_model" initialized
INFO - 2021-07-12 12:10:31 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:10:31 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:10:31 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:10:31 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:10:31 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:10:31 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:10:31 --> Database Driver Class Initialized
INFO - 2021-07-12 12:10:31 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:10:31 --> Controller Class Initialized
INFO - 2021-07-12 12:10:31 --> Final output sent to browser
DEBUG - 2021-07-12 12:10:31 --> Total execution time: 0.1602
INFO - 2021-07-12 12:10:32 --> Config Class Initialized
INFO - 2021-07-12 12:10:32 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:10:32 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:10:32 --> Utf8 Class Initialized
INFO - 2021-07-12 12:10:32 --> URI Class Initialized
INFO - 2021-07-12 12:10:32 --> Router Class Initialized
INFO - 2021-07-12 12:10:32 --> Output Class Initialized
INFO - 2021-07-12 12:10:32 --> Security Class Initialized
DEBUG - 2021-07-12 12:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:10:32 --> Input Class Initialized
INFO - 2021-07-12 12:10:32 --> Language Class Initialized
INFO - 2021-07-12 12:10:32 --> Loader Class Initialized
INFO - 2021-07-12 12:10:32 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:10:32 --> Helper loaded: url_helper
INFO - 2021-07-12 12:10:32 --> Helper loaded: file_helper
INFO - 2021-07-12 12:10:32 --> Helper loaded: form_helper
INFO - 2021-07-12 12:10:32 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:10:32 --> Helper loaded: security_helper
INFO - 2021-07-12 12:10:32 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:10:32 --> Helper loaded: language_helper
INFO - 2021-07-12 12:10:32 --> Helper loaded: general_helper
INFO - 2021-07-12 12:10:32 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:10:32 --> Database Driver Class Initialized
DEBUG - 2021-07-12 12:10:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:10:32 --> Parser Class Initialized
INFO - 2021-07-12 12:10:32 --> Form Validation Class Initialized
INFO - 2021-07-12 12:10:32 --> Upload Class Initialized
INFO - 2021-07-12 12:10:32 --> Email Class Initialized
INFO - 2021-07-12 12:10:32 --> MY_Model class loaded
INFO - 2021-07-12 12:10:32 --> Model "Users_model" initialized
INFO - 2021-07-12 12:10:32 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:10:32 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:10:32 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:10:32 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:10:32 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:10:32 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:10:32 --> Database Driver Class Initialized
INFO - 2021-07-12 12:10:32 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:10:32 --> Controller Class Initialized
ERROR - 2021-07-12 12:10:32 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 12:10:33 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-12 12:10:33 --> Final output sent to browser
DEBUG - 2021-07-12 12:10:33 --> Total execution time: 0.2400
INFO - 2021-07-12 12:10:35 --> Config Class Initialized
INFO - 2021-07-12 12:10:35 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:10:35 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:10:35 --> Utf8 Class Initialized
INFO - 2021-07-12 12:10:35 --> URI Class Initialized
INFO - 2021-07-12 12:10:35 --> Router Class Initialized
INFO - 2021-07-12 12:10:35 --> Output Class Initialized
INFO - 2021-07-12 12:10:35 --> Security Class Initialized
DEBUG - 2021-07-12 12:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:10:35 --> Input Class Initialized
INFO - 2021-07-12 12:10:35 --> Language Class Initialized
INFO - 2021-07-12 12:10:35 --> Loader Class Initialized
INFO - 2021-07-12 12:10:35 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:10:35 --> Helper loaded: url_helper
INFO - 2021-07-12 12:10:35 --> Helper loaded: file_helper
INFO - 2021-07-12 12:10:35 --> Helper loaded: form_helper
INFO - 2021-07-12 12:10:35 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:10:35 --> Helper loaded: security_helper
INFO - 2021-07-12 12:10:35 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:10:35 --> Helper loaded: language_helper
INFO - 2021-07-12 12:10:35 --> Helper loaded: general_helper
INFO - 2021-07-12 12:10:35 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:10:35 --> Database Driver Class Initialized
DEBUG - 2021-07-12 12:10:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:10:35 --> Parser Class Initialized
INFO - 2021-07-12 12:10:35 --> Form Validation Class Initialized
INFO - 2021-07-12 12:10:35 --> Upload Class Initialized
INFO - 2021-07-12 12:10:35 --> Email Class Initialized
INFO - 2021-07-12 12:10:35 --> MY_Model class loaded
INFO - 2021-07-12 12:10:35 --> Model "Users_model" initialized
INFO - 2021-07-12 12:10:35 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:10:35 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:10:35 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:10:35 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:10:35 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:10:35 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:10:35 --> Database Driver Class Initialized
INFO - 2021-07-12 12:10:35 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:10:35 --> Controller Class Initialized
ERROR - 2021-07-12 12:10:35 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 12:10:35 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-12 12:10:35 --> Final output sent to browser
DEBUG - 2021-07-12 12:10:35 --> Total execution time: 0.0608
INFO - 2021-07-12 12:11:07 --> Config Class Initialized
INFO - 2021-07-12 12:11:07 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:11:07 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:11:07 --> Utf8 Class Initialized
INFO - 2021-07-12 12:11:07 --> URI Class Initialized
INFO - 2021-07-12 12:11:07 --> Router Class Initialized
INFO - 2021-07-12 12:11:07 --> Output Class Initialized
INFO - 2021-07-12 12:11:07 --> Security Class Initialized
DEBUG - 2021-07-12 12:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:11:07 --> Input Class Initialized
INFO - 2021-07-12 12:11:07 --> Language Class Initialized
INFO - 2021-07-12 12:11:07 --> Loader Class Initialized
INFO - 2021-07-12 12:11:07 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:11:07 --> Helper loaded: url_helper
INFO - 2021-07-12 12:11:07 --> Helper loaded: file_helper
INFO - 2021-07-12 12:11:07 --> Helper loaded: form_helper
INFO - 2021-07-12 12:11:07 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:11:07 --> Helper loaded: security_helper
INFO - 2021-07-12 12:11:07 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:11:07 --> Helper loaded: language_helper
INFO - 2021-07-12 12:11:07 --> Helper loaded: general_helper
INFO - 2021-07-12 12:11:07 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:11:07 --> Database Driver Class Initialized
DEBUG - 2021-07-12 12:11:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:11:07 --> Parser Class Initialized
INFO - 2021-07-12 12:11:07 --> Form Validation Class Initialized
INFO - 2021-07-12 12:11:07 --> Upload Class Initialized
INFO - 2021-07-12 12:11:07 --> Email Class Initialized
INFO - 2021-07-12 12:11:07 --> MY_Model class loaded
INFO - 2021-07-12 12:11:07 --> Model "Users_model" initialized
INFO - 2021-07-12 12:11:07 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:11:07 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:11:07 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:11:07 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:11:07 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:11:07 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:11:07 --> Database Driver Class Initialized
INFO - 2021-07-12 12:11:07 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:11:07 --> Controller Class Initialized
ERROR - 2021-07-12 12:11:07 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 12:11:07 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-12 12:11:07 --> Final output sent to browser
DEBUG - 2021-07-12 12:11:07 --> Total execution time: 0.1214
INFO - 2021-07-12 12:11:54 --> Config Class Initialized
INFO - 2021-07-12 12:11:54 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:11:54 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:11:54 --> Utf8 Class Initialized
INFO - 2021-07-12 12:11:54 --> URI Class Initialized
DEBUG - 2021-07-12 12:11:54 --> No URI present. Default controller set.
INFO - 2021-07-12 12:11:54 --> Router Class Initialized
INFO - 2021-07-12 12:11:54 --> Output Class Initialized
INFO - 2021-07-12 12:11:54 --> Security Class Initialized
DEBUG - 2021-07-12 12:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:11:54 --> Input Class Initialized
INFO - 2021-07-12 12:11:54 --> Language Class Initialized
INFO - 2021-07-12 12:11:54 --> Loader Class Initialized
INFO - 2021-07-12 12:11:54 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:11:54 --> Helper loaded: url_helper
INFO - 2021-07-12 12:11:54 --> Helper loaded: file_helper
INFO - 2021-07-12 12:11:54 --> Helper loaded: form_helper
INFO - 2021-07-12 12:11:54 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:11:54 --> Helper loaded: security_helper
INFO - 2021-07-12 12:11:54 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:11:54 --> Helper loaded: language_helper
INFO - 2021-07-12 12:11:54 --> Helper loaded: general_helper
INFO - 2021-07-12 12:11:54 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:11:54 --> Database Driver Class Initialized
DEBUG - 2021-07-12 12:11:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:11:54 --> Parser Class Initialized
INFO - 2021-07-12 12:11:54 --> Form Validation Class Initialized
INFO - 2021-07-12 12:11:54 --> Upload Class Initialized
INFO - 2021-07-12 12:11:54 --> Email Class Initialized
INFO - 2021-07-12 12:11:54 --> MY_Model class loaded
INFO - 2021-07-12 12:11:54 --> Model "Users_model" initialized
INFO - 2021-07-12 12:11:54 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:11:54 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:11:54 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:11:54 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:11:54 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:11:54 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:11:54 --> Database Driver Class Initialized
INFO - 2021-07-12 12:11:54 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:11:54 --> Controller Class Initialized
ERROR - 2021-07-12 12:11:54 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 12:11:54 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-12 12:11:54 --> Final output sent to browser
DEBUG - 2021-07-12 12:11:54 --> Total execution time: 0.1205
INFO - 2021-07-12 12:11:56 --> Config Class Initialized
INFO - 2021-07-12 12:11:56 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:11:57 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:11:57 --> Utf8 Class Initialized
INFO - 2021-07-12 12:11:57 --> URI Class Initialized
INFO - 2021-07-12 12:11:57 --> Router Class Initialized
INFO - 2021-07-12 12:11:57 --> Output Class Initialized
INFO - 2021-07-12 12:11:57 --> Security Class Initialized
DEBUG - 2021-07-12 12:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:11:57 --> Input Class Initialized
INFO - 2021-07-12 12:11:57 --> Language Class Initialized
INFO - 2021-07-12 12:11:57 --> Loader Class Initialized
INFO - 2021-07-12 12:11:57 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:11:57 --> Helper loaded: url_helper
INFO - 2021-07-12 12:11:57 --> Helper loaded: file_helper
INFO - 2021-07-12 12:11:57 --> Helper loaded: form_helper
INFO - 2021-07-12 12:11:57 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:11:57 --> Helper loaded: security_helper
INFO - 2021-07-12 12:11:57 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:11:57 --> Helper loaded: language_helper
INFO - 2021-07-12 12:11:57 --> Helper loaded: general_helper
INFO - 2021-07-12 12:11:57 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:11:57 --> Database Driver Class Initialized
DEBUG - 2021-07-12 12:11:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:11:57 --> Parser Class Initialized
INFO - 2021-07-12 12:11:57 --> Form Validation Class Initialized
INFO - 2021-07-12 12:11:57 --> Upload Class Initialized
INFO - 2021-07-12 12:11:57 --> Email Class Initialized
INFO - 2021-07-12 12:11:57 --> MY_Model class loaded
INFO - 2021-07-12 12:11:57 --> Model "Users_model" initialized
INFO - 2021-07-12 12:11:57 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:11:57 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:11:57 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:11:57 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:11:57 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:11:57 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:11:57 --> Database Driver Class Initialized
INFO - 2021-07-12 12:11:57 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:11:57 --> Controller Class Initialized
ERROR - 2021-07-12 12:11:57 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 12:11:57 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-12 12:11:57 --> Final output sent to browser
DEBUG - 2021-07-12 12:11:57 --> Total execution time: 0.1747
INFO - 2021-07-12 12:12:18 --> Config Class Initialized
INFO - 2021-07-12 12:12:18 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:12:18 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:12:18 --> Utf8 Class Initialized
INFO - 2021-07-12 12:12:18 --> URI Class Initialized
INFO - 2021-07-12 12:12:18 --> Router Class Initialized
INFO - 2021-07-12 12:12:18 --> Output Class Initialized
INFO - 2021-07-12 12:12:18 --> Security Class Initialized
DEBUG - 2021-07-12 12:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:12:18 --> Input Class Initialized
INFO - 2021-07-12 12:12:18 --> Language Class Initialized
INFO - 2021-07-12 12:12:18 --> Loader Class Initialized
INFO - 2021-07-12 12:12:18 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:12:18 --> Helper loaded: url_helper
INFO - 2021-07-12 12:12:18 --> Helper loaded: file_helper
INFO - 2021-07-12 12:12:18 --> Helper loaded: form_helper
INFO - 2021-07-12 12:12:18 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:12:18 --> Helper loaded: security_helper
INFO - 2021-07-12 12:12:18 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:12:18 --> Helper loaded: language_helper
INFO - 2021-07-12 12:12:18 --> Helper loaded: general_helper
INFO - 2021-07-12 12:12:18 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:12:18 --> Database Driver Class Initialized
DEBUG - 2021-07-12 12:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:12:18 --> Parser Class Initialized
INFO - 2021-07-12 12:12:18 --> Form Validation Class Initialized
INFO - 2021-07-12 12:12:18 --> Upload Class Initialized
INFO - 2021-07-12 12:12:18 --> Email Class Initialized
INFO - 2021-07-12 12:12:18 --> MY_Model class loaded
INFO - 2021-07-12 12:12:18 --> Model "Users_model" initialized
INFO - 2021-07-12 12:12:18 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:12:18 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:12:18 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:12:18 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:12:18 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:12:18 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:12:18 --> Database Driver Class Initialized
INFO - 2021-07-12 12:12:19 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:12:19 --> Controller Class Initialized
ERROR - 2021-07-12 12:12:19 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 12:12:19 --> File loaded: C:\wamp64\www\crm\application\views\users/list.php
INFO - 2021-07-12 12:12:19 --> Final output sent to browser
DEBUG - 2021-07-12 12:12:19 --> Total execution time: 0.1736
INFO - 2021-07-12 12:12:19 --> Config Class Initialized
INFO - 2021-07-12 12:12:19 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:12:19 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:12:19 --> Utf8 Class Initialized
INFO - 2021-07-12 12:12:19 --> URI Class Initialized
INFO - 2021-07-12 12:12:19 --> Router Class Initialized
INFO - 2021-07-12 12:12:19 --> Output Class Initialized
INFO - 2021-07-12 12:12:19 --> Security Class Initialized
DEBUG - 2021-07-12 12:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:12:19 --> Input Class Initialized
INFO - 2021-07-12 12:12:19 --> Language Class Initialized
INFO - 2021-07-12 12:12:19 --> Loader Class Initialized
INFO - 2021-07-12 12:12:19 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:12:19 --> Helper loaded: url_helper
INFO - 2021-07-12 12:12:19 --> Helper loaded: file_helper
INFO - 2021-07-12 12:12:19 --> Helper loaded: form_helper
INFO - 2021-07-12 12:12:19 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:12:19 --> Helper loaded: security_helper
INFO - 2021-07-12 12:12:19 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:12:19 --> Helper loaded: language_helper
INFO - 2021-07-12 12:12:19 --> Helper loaded: general_helper
INFO - 2021-07-12 12:12:19 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:12:19 --> Config Class Initialized
INFO - 2021-07-12 12:12:19 --> Hooks Class Initialized
INFO - 2021-07-12 12:12:19 --> Database Driver Class Initialized
DEBUG - 2021-07-12 12:12:19 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:12:19 --> Utf8 Class Initialized
INFO - 2021-07-12 12:12:19 --> URI Class Initialized
INFO - 2021-07-12 12:12:19 --> Router Class Initialized
DEBUG - 2021-07-12 12:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:12:19 --> Output Class Initialized
INFO - 2021-07-12 12:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:12:19 --> Security Class Initialized
INFO - 2021-07-12 12:12:19 --> Parser Class Initialized
DEBUG - 2021-07-12 12:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:12:19 --> Input Class Initialized
INFO - 2021-07-12 12:12:19 --> Form Validation Class Initialized
INFO - 2021-07-12 12:12:19 --> Config Class Initialized
INFO - 2021-07-12 12:12:19 --> Language Class Initialized
INFO - 2021-07-12 12:12:19 --> Hooks Class Initialized
INFO - 2021-07-12 12:12:19 --> Upload Class Initialized
INFO - 2021-07-12 12:12:19 --> Loader Class Initialized
DEBUG - 2021-07-12 12:12:19 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:12:19 --> Email Class Initialized
INFO - 2021-07-12 12:12:19 --> Utf8 Class Initialized
INFO - 2021-07-12 12:12:19 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:12:19 --> MY_Model class loaded
INFO - 2021-07-12 12:12:19 --> URI Class Initialized
INFO - 2021-07-12 12:12:19 --> Model "Users_model" initialized
INFO - 2021-07-12 12:12:19 --> Helper loaded: url_helper
INFO - 2021-07-12 12:12:19 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:12:19 --> Helper loaded: file_helper
INFO - 2021-07-12 12:12:19 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:12:19 --> Router Class Initialized
INFO - 2021-07-12 12:12:19 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:12:19 --> Helper loaded: form_helper
INFO - 2021-07-12 12:12:19 --> Output Class Initialized
INFO - 2021-07-12 12:12:19 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:12:19 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:12:19 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:12:19 --> Security Class Initialized
INFO - 2021-07-12 12:12:19 --> Config Class Initialized
INFO - 2021-07-12 12:12:19 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:12:19 --> Helper loaded: security_helper
DEBUG - 2021-07-12 12:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:12:19 --> Hooks Class Initialized
INFO - 2021-07-12 12:12:19 --> Input Class Initialized
INFO - 2021-07-12 12:12:19 --> Database Driver Class Initialized
INFO - 2021-07-12 12:12:19 --> Helper loaded: directory_helper
DEBUG - 2021-07-12 12:12:19 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:12:19 --> Language Class Initialized
INFO - 2021-07-12 12:12:19 --> Utf8 Class Initialized
INFO - 2021-07-12 12:12:19 --> Helper loaded: language_helper
INFO - 2021-07-12 12:12:19 --> Loader Class Initialized
INFO - 2021-07-12 12:12:19 --> URI Class Initialized
INFO - 2021-07-12 12:12:19 --> Helper loaded: general_helper
INFO - 2021-07-12 12:12:19 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:12:19 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:12:19 --> Router Class Initialized
INFO - 2021-07-12 12:12:19 --> Helper loaded: url_helper
INFO - 2021-07-12 12:12:19 --> Database Driver Class Initialized
INFO - 2021-07-12 12:12:19 --> Output Class Initialized
INFO - 2021-07-12 12:12:19 --> Config Class Initialized
INFO - 2021-07-12 12:12:19 --> Helper loaded: file_helper
INFO - 2021-07-12 12:12:19 --> Hooks Class Initialized
INFO - 2021-07-12 12:12:19 --> Security Class Initialized
INFO - 2021-07-12 12:12:19 --> Helper loaded: form_helper
DEBUG - 2021-07-12 12:12:19 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:12:19 --> Helper loaded: cookie_helper
DEBUG - 2021-07-12 12:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:12:19 --> Utf8 Class Initialized
INFO - 2021-07-12 12:12:19 --> Input Class Initialized
INFO - 2021-07-12 12:12:19 --> Helper loaded: security_helper
DEBUG - 2021-07-12 12:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:12:19 --> URI Class Initialized
INFO - 2021-07-12 12:12:19 --> Language Class Initialized
INFO - 2021-07-12 12:12:19 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:12:19 --> Helper loaded: language_helper
INFO - 2021-07-12 12:12:19 --> Router Class Initialized
INFO - 2021-07-12 12:12:19 --> Loader Class Initialized
INFO - 2021-07-12 12:12:19 --> Helper loaded: general_helper
INFO - 2021-07-12 12:12:19 --> Config Class Initialized
INFO - 2021-07-12 12:12:19 --> Output Class Initialized
INFO - 2021-07-12 12:12:19 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:12:19 --> Hooks Class Initialized
INFO - 2021-07-12 12:12:19 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:12:19 --> Security Class Initialized
INFO - 2021-07-12 12:12:19 --> Helper loaded: url_helper
DEBUG - 2021-07-12 12:12:19 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:12:19 --> Database Driver Class Initialized
INFO - 2021-07-12 12:12:19 --> Helper loaded: file_helper
INFO - 2021-07-12 12:12:19 --> Utf8 Class Initialized
DEBUG - 2021-07-12 12:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:12:19 --> Input Class Initialized
INFO - 2021-07-12 12:12:19 --> Helper loaded: form_helper
INFO - 2021-07-12 12:12:19 --> URI Class Initialized
INFO - 2021-07-12 12:12:19 --> Language Class Initialized
INFO - 2021-07-12 12:12:19 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:12:19 --> Router Class Initialized
INFO - 2021-07-12 12:12:19 --> Helper loaded: security_helper
INFO - 2021-07-12 12:12:19 --> Loader Class Initialized
INFO - 2021-07-12 12:12:19 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:12:19 --> Output Class Initialized
INFO - 2021-07-12 12:12:19 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:12:19 --> Helper loaded: language_helper
INFO - 2021-07-12 12:12:19 --> Security Class Initialized
INFO - 2021-07-12 12:12:19 --> Helper loaded: url_helper
INFO - 2021-07-12 12:12:19 --> Helper loaded: general_helper
DEBUG - 2021-07-12 12:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:12:19 --> Helper loaded: file_helper
INFO - 2021-07-12 12:12:19 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:12:19 --> Input Class Initialized
INFO - 2021-07-12 12:12:19 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:12:19 --> Helper loaded: form_helper
INFO - 2021-07-12 12:12:19 --> Language Class Initialized
INFO - 2021-07-12 12:12:19 --> Controller Class Initialized
INFO - 2021-07-12 12:12:19 --> Database Driver Class Initialized
INFO - 2021-07-12 12:12:19 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:12:19 --> Loader Class Initialized
INFO - 2021-07-12 12:12:19 --> Helper loaded: security_helper
INFO - 2021-07-12 12:12:19 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:12:19 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:12:19 --> Final output sent to browser
INFO - 2021-07-12 12:12:19 --> Helper loaded: url_helper
DEBUG - 2021-07-12 12:12:19 --> Total execution time: 0.0493
INFO - 2021-07-12 12:12:19 --> Helper loaded: language_helper
DEBUG - 2021-07-12 12:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:12:19 --> Helper loaded: file_helper
INFO - 2021-07-12 12:12:19 --> Helper loaded: general_helper
INFO - 2021-07-12 12:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:12:19 --> Helper loaded: form_helper
INFO - 2021-07-12 12:12:19 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:12:19 --> Parser Class Initialized
INFO - 2021-07-12 12:12:19 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:12:19 --> Database Driver Class Initialized
INFO - 2021-07-12 12:12:19 --> Helper loaded: security_helper
INFO - 2021-07-12 12:12:19 --> Form Validation Class Initialized
INFO - 2021-07-12 12:12:19 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:12:19 --> Upload Class Initialized
INFO - 2021-07-12 12:12:19 --> Helper loaded: language_helper
INFO - 2021-07-12 12:12:19 --> Helper loaded: general_helper
INFO - 2021-07-12 12:12:19 --> Email Class Initialized
DEBUG - 2021-07-12 12:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:12:19 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:12:19 --> MY_Model class loaded
INFO - 2021-07-12 12:12:19 --> Model "Users_model" initialized
INFO - 2021-07-12 12:12:19 --> Database Driver Class Initialized
INFO - 2021-07-12 12:12:19 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:12:19 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:12:19 --> Model "Permissions_model" initialized
DEBUG - 2021-07-12 12:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:12:19 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:12:19 --> Model "Activity_model" initialized
DEBUG - 2021-07-12 12:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:12:19 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:12:19 --> Database Driver Class Initialized
INFO - 2021-07-12 12:12:19 --> Config Class Initialized
INFO - 2021-07-12 12:12:19 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:12:19 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:12:19 --> Utf8 Class Initialized
INFO - 2021-07-12 12:12:19 --> URI Class Initialized
INFO - 2021-07-12 12:12:19 --> Router Class Initialized
INFO - 2021-07-12 12:12:19 --> Output Class Initialized
INFO - 2021-07-12 12:12:19 --> Security Class Initialized
DEBUG - 2021-07-12 12:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:12:19 --> Input Class Initialized
INFO - 2021-07-12 12:12:19 --> Language Class Initialized
INFO - 2021-07-12 12:12:19 --> Loader Class Initialized
INFO - 2021-07-12 12:12:19 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:12:19 --> Helper loaded: url_helper
INFO - 2021-07-12 12:12:19 --> Helper loaded: file_helper
INFO - 2021-07-12 12:12:19 --> Helper loaded: form_helper
INFO - 2021-07-12 12:12:19 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:12:19 --> Helper loaded: security_helper
INFO - 2021-07-12 12:12:19 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:12:19 --> Helper loaded: language_helper
INFO - 2021-07-12 12:12:19 --> Helper loaded: general_helper
INFO - 2021-07-12 12:12:19 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:12:19 --> Database Driver Class Initialized
DEBUG - 2021-07-12 12:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:12:19 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:12:19 --> Controller Class Initialized
INFO - 2021-07-12 12:12:19 --> Final output sent to browser
DEBUG - 2021-07-12 12:12:19 --> Total execution time: 0.0674
INFO - 2021-07-12 12:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:12:19 --> Parser Class Initialized
INFO - 2021-07-12 12:12:19 --> Form Validation Class Initialized
INFO - 2021-07-12 12:12:19 --> Upload Class Initialized
INFO - 2021-07-12 12:12:19 --> Email Class Initialized
INFO - 2021-07-12 12:12:19 --> MY_Model class loaded
INFO - 2021-07-12 12:12:19 --> Model "Users_model" initialized
INFO - 2021-07-12 12:12:19 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:12:19 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:12:19 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:12:19 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:12:19 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:12:19 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:12:19 --> Database Driver Class Initialized
INFO - 2021-07-12 12:12:19 --> Config Class Initialized
INFO - 2021-07-12 12:12:19 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:12:19 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:12:19 --> Utf8 Class Initialized
INFO - 2021-07-12 12:12:19 --> URI Class Initialized
INFO - 2021-07-12 12:12:19 --> Router Class Initialized
INFO - 2021-07-12 12:12:19 --> Output Class Initialized
INFO - 2021-07-12 12:12:19 --> Security Class Initialized
DEBUG - 2021-07-12 12:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:12:19 --> Input Class Initialized
INFO - 2021-07-12 12:12:19 --> Language Class Initialized
INFO - 2021-07-12 12:12:19 --> Loader Class Initialized
INFO - 2021-07-12 12:12:19 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:12:19 --> Helper loaded: url_helper
INFO - 2021-07-12 12:12:19 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:12:19 --> Helper loaded: file_helper
INFO - 2021-07-12 12:12:19 --> Controller Class Initialized
INFO - 2021-07-12 12:12:19 --> Helper loaded: form_helper
INFO - 2021-07-12 12:12:19 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:12:19 --> Helper loaded: security_helper
INFO - 2021-07-12 12:12:19 --> Final output sent to browser
INFO - 2021-07-12 12:12:19 --> Helper loaded: directory_helper
DEBUG - 2021-07-12 12:12:19 --> Total execution time: 0.0826
INFO - 2021-07-12 12:12:19 --> Helper loaded: language_helper
INFO - 2021-07-12 12:12:19 --> Helper loaded: general_helper
INFO - 2021-07-12 12:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:12:19 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:12:19 --> Parser Class Initialized
INFO - 2021-07-12 12:12:19 --> Database Driver Class Initialized
INFO - 2021-07-12 12:12:19 --> Form Validation Class Initialized
INFO - 2021-07-12 12:12:19 --> Upload Class Initialized
DEBUG - 2021-07-12 12:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:12:19 --> Email Class Initialized
INFO - 2021-07-12 12:12:19 --> MY_Model class loaded
INFO - 2021-07-12 12:12:19 --> Model "Users_model" initialized
INFO - 2021-07-12 12:12:19 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:12:19 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:12:19 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:12:19 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:12:19 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:12:19 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:12:19 --> Database Driver Class Initialized
INFO - 2021-07-12 12:12:19 --> Config Class Initialized
INFO - 2021-07-12 12:12:19 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:12:19 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:12:19 --> Utf8 Class Initialized
INFO - 2021-07-12 12:12:19 --> URI Class Initialized
INFO - 2021-07-12 12:12:19 --> Router Class Initialized
INFO - 2021-07-12 12:12:19 --> Output Class Initialized
INFO - 2021-07-12 12:12:19 --> Security Class Initialized
DEBUG - 2021-07-12 12:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:12:19 --> Input Class Initialized
INFO - 2021-07-12 12:12:19 --> Language Class Initialized
INFO - 2021-07-12 12:12:19 --> Loader Class Initialized
INFO - 2021-07-12 12:12:19 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:12:19 --> Helper loaded: url_helper
INFO - 2021-07-12 12:12:19 --> Helper loaded: file_helper
INFO - 2021-07-12 12:12:19 --> Helper loaded: form_helper
INFO - 2021-07-12 12:12:19 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:12:19 --> Helper loaded: security_helper
INFO - 2021-07-12 12:12:19 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:12:19 --> Helper loaded: language_helper
INFO - 2021-07-12 12:12:19 --> Helper loaded: general_helper
INFO - 2021-07-12 12:12:19 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:12:19 --> Database Driver Class Initialized
INFO - 2021-07-12 12:12:19 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:12:19 --> Controller Class Initialized
DEBUG - 2021-07-12 12:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:12:19 --> Final output sent to browser
DEBUG - 2021-07-12 12:12:19 --> Total execution time: 0.1059
INFO - 2021-07-12 12:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:12:19 --> Parser Class Initialized
INFO - 2021-07-12 12:12:19 --> Form Validation Class Initialized
INFO - 2021-07-12 12:12:19 --> Upload Class Initialized
INFO - 2021-07-12 12:12:19 --> Email Class Initialized
INFO - 2021-07-12 12:12:19 --> MY_Model class loaded
INFO - 2021-07-12 12:12:19 --> Model "Users_model" initialized
INFO - 2021-07-12 12:12:19 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:12:19 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:12:19 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:12:19 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:12:19 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:12:19 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:12:19 --> Database Driver Class Initialized
INFO - 2021-07-12 12:12:19 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:12:19 --> Controller Class Initialized
INFO - 2021-07-12 12:12:19 --> Final output sent to browser
DEBUG - 2021-07-12 12:12:19 --> Total execution time: 0.1449
INFO - 2021-07-12 12:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:12:19 --> Parser Class Initialized
INFO - 2021-07-12 12:12:19 --> Form Validation Class Initialized
INFO - 2021-07-12 12:12:19 --> Upload Class Initialized
INFO - 2021-07-12 12:12:19 --> Email Class Initialized
INFO - 2021-07-12 12:12:19 --> MY_Model class loaded
INFO - 2021-07-12 12:12:19 --> Model "Users_model" initialized
INFO - 2021-07-12 12:12:19 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:12:19 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:12:19 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:12:19 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:12:19 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:12:19 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:12:19 --> Database Driver Class Initialized
INFO - 2021-07-12 12:12:19 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:12:19 --> Controller Class Initialized
INFO - 2021-07-12 12:12:19 --> Final output sent to browser
DEBUG - 2021-07-12 12:12:19 --> Total execution time: 0.1552
INFO - 2021-07-12 12:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:12:19 --> Parser Class Initialized
INFO - 2021-07-12 12:12:19 --> Form Validation Class Initialized
INFO - 2021-07-12 12:12:19 --> Upload Class Initialized
INFO - 2021-07-12 12:12:19 --> Email Class Initialized
INFO - 2021-07-12 12:12:19 --> MY_Model class loaded
INFO - 2021-07-12 12:12:19 --> Model "Users_model" initialized
INFO - 2021-07-12 12:12:19 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:12:19 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:12:19 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:12:19 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:12:19 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:12:19 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:12:19 --> Database Driver Class Initialized
INFO - 2021-07-12 12:12:19 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:12:19 --> Controller Class Initialized
INFO - 2021-07-12 12:12:19 --> Final output sent to browser
DEBUG - 2021-07-12 12:12:19 --> Total execution time: 0.1592
INFO - 2021-07-12 12:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:12:19 --> Parser Class Initialized
INFO - 2021-07-12 12:12:19 --> Form Validation Class Initialized
INFO - 2021-07-12 12:12:19 --> Upload Class Initialized
INFO - 2021-07-12 12:12:19 --> Email Class Initialized
INFO - 2021-07-12 12:12:19 --> MY_Model class loaded
INFO - 2021-07-12 12:12:19 --> Model "Users_model" initialized
INFO - 2021-07-12 12:12:19 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:12:19 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:12:19 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:12:19 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:12:19 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:12:19 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:12:19 --> Database Driver Class Initialized
INFO - 2021-07-12 12:12:19 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:12:19 --> Controller Class Initialized
INFO - 2021-07-12 12:12:19 --> Final output sent to browser
DEBUG - 2021-07-12 12:12:19 --> Total execution time: 0.1508
INFO - 2021-07-12 12:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:12:19 --> Parser Class Initialized
INFO - 2021-07-12 12:12:19 --> Form Validation Class Initialized
INFO - 2021-07-12 12:12:19 --> Upload Class Initialized
INFO - 2021-07-12 12:12:19 --> Email Class Initialized
INFO - 2021-07-12 12:12:19 --> MY_Model class loaded
INFO - 2021-07-12 12:12:19 --> Model "Users_model" initialized
INFO - 2021-07-12 12:12:19 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:12:19 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:12:19 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:12:19 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:12:19 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:12:19 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:12:19 --> Database Driver Class Initialized
INFO - 2021-07-12 12:12:19 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:12:19 --> Controller Class Initialized
INFO - 2021-07-12 12:12:19 --> Final output sent to browser
DEBUG - 2021-07-12 12:12:19 --> Total execution time: 0.1541
INFO - 2021-07-12 12:12:26 --> Config Class Initialized
INFO - 2021-07-12 12:12:26 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:12:26 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:12:26 --> Utf8 Class Initialized
INFO - 2021-07-12 12:12:26 --> URI Class Initialized
INFO - 2021-07-12 12:12:26 --> Router Class Initialized
INFO - 2021-07-12 12:12:26 --> Output Class Initialized
INFO - 2021-07-12 12:12:26 --> Security Class Initialized
DEBUG - 2021-07-12 12:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:12:26 --> Input Class Initialized
INFO - 2021-07-12 12:12:26 --> Language Class Initialized
INFO - 2021-07-12 12:12:26 --> Loader Class Initialized
INFO - 2021-07-12 12:12:26 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:12:26 --> Helper loaded: url_helper
INFO - 2021-07-12 12:12:26 --> Helper loaded: file_helper
INFO - 2021-07-12 12:12:26 --> Helper loaded: form_helper
INFO - 2021-07-12 12:12:26 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:12:26 --> Helper loaded: security_helper
INFO - 2021-07-12 12:12:26 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:12:26 --> Helper loaded: language_helper
INFO - 2021-07-12 12:12:26 --> Helper loaded: general_helper
INFO - 2021-07-12 12:12:26 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:12:26 --> Database Driver Class Initialized
DEBUG - 2021-07-12 12:12:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:12:26 --> Parser Class Initialized
INFO - 2021-07-12 12:12:26 --> Form Validation Class Initialized
INFO - 2021-07-12 12:12:26 --> Upload Class Initialized
INFO - 2021-07-12 12:12:26 --> Email Class Initialized
INFO - 2021-07-12 12:12:26 --> MY_Model class loaded
INFO - 2021-07-12 12:12:26 --> Model "Users_model" initialized
INFO - 2021-07-12 12:12:26 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:12:26 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:12:26 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:12:26 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:12:26 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:12:26 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:12:26 --> Database Driver Class Initialized
INFO - 2021-07-12 12:12:26 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:12:26 --> Controller Class Initialized
INFO - 2021-07-12 12:12:26 --> Config Class Initialized
INFO - 2021-07-12 12:12:26 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:12:26 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:12:26 --> Utf8 Class Initialized
INFO - 2021-07-12 12:12:26 --> URI Class Initialized
INFO - 2021-07-12 12:12:26 --> Router Class Initialized
INFO - 2021-07-12 12:12:26 --> Output Class Initialized
INFO - 2021-07-12 12:12:26 --> Security Class Initialized
DEBUG - 2021-07-12 12:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:12:26 --> Input Class Initialized
INFO - 2021-07-12 12:12:26 --> Language Class Initialized
INFO - 2021-07-12 12:12:26 --> Loader Class Initialized
INFO - 2021-07-12 12:12:26 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:12:26 --> Helper loaded: url_helper
INFO - 2021-07-12 12:12:26 --> Helper loaded: file_helper
INFO - 2021-07-12 12:12:26 --> Helper loaded: form_helper
INFO - 2021-07-12 12:12:26 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:12:26 --> Helper loaded: security_helper
INFO - 2021-07-12 12:12:26 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:12:26 --> Helper loaded: language_helper
INFO - 2021-07-12 12:12:26 --> Helper loaded: general_helper
INFO - 2021-07-12 12:12:26 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:12:26 --> Database Driver Class Initialized
DEBUG - 2021-07-12 12:12:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:12:26 --> Parser Class Initialized
INFO - 2021-07-12 12:12:26 --> Form Validation Class Initialized
INFO - 2021-07-12 12:12:26 --> Upload Class Initialized
INFO - 2021-07-12 12:12:26 --> Email Class Initialized
INFO - 2021-07-12 12:12:26 --> MY_Model class loaded
INFO - 2021-07-12 12:12:26 --> Model "Users_model" initialized
INFO - 2021-07-12 12:12:26 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:12:26 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:12:26 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:12:26 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:12:26 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:12:26 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:12:26 --> Database Driver Class Initialized
INFO - 2021-07-12 12:12:26 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:12:26 --> Controller Class Initialized
INFO - 2021-07-12 12:12:26 --> File loaded: C:\wamp64\www\crm\application\views\account/login.php
INFO - 2021-07-12 12:12:26 --> Final output sent to browser
DEBUG - 2021-07-12 12:12:26 --> Total execution time: 0.0447
INFO - 2021-07-12 12:12:26 --> Config Class Initialized
INFO - 2021-07-12 12:12:26 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:12:26 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:12:26 --> Utf8 Class Initialized
INFO - 2021-07-12 12:12:26 --> URI Class Initialized
INFO - 2021-07-12 12:12:26 --> Router Class Initialized
INFO - 2021-07-12 12:12:26 --> Output Class Initialized
INFO - 2021-07-12 12:12:26 --> Security Class Initialized
DEBUG - 2021-07-12 12:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:12:26 --> Config Class Initialized
INFO - 2021-07-12 12:12:26 --> Input Class Initialized
INFO - 2021-07-12 12:12:26 --> Hooks Class Initialized
INFO - 2021-07-12 12:12:26 --> Language Class Initialized
DEBUG - 2021-07-12 12:12:26 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:12:26 --> Utf8 Class Initialized
ERROR - 2021-07-12 12:12:26 --> 404 Page Not Found: Assets/jquery
INFO - 2021-07-12 12:12:26 --> URI Class Initialized
INFO - 2021-07-12 12:12:26 --> Router Class Initialized
INFO - 2021-07-12 12:12:26 --> Output Class Initialized
INFO - 2021-07-12 12:12:26 --> Security Class Initialized
DEBUG - 2021-07-12 12:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:12:26 --> Input Class Initialized
INFO - 2021-07-12 12:12:26 --> Language Class Initialized
ERROR - 2021-07-12 12:12:26 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-12 12:12:44 --> Config Class Initialized
INFO - 2021-07-12 12:12:44 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:12:44 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:12:44 --> Utf8 Class Initialized
INFO - 2021-07-12 12:12:44 --> URI Class Initialized
INFO - 2021-07-12 12:12:44 --> Router Class Initialized
INFO - 2021-07-12 12:12:44 --> Output Class Initialized
INFO - 2021-07-12 12:12:44 --> Security Class Initialized
DEBUG - 2021-07-12 12:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:12:44 --> Input Class Initialized
INFO - 2021-07-12 12:12:44 --> Language Class Initialized
INFO - 2021-07-12 12:12:44 --> Loader Class Initialized
INFO - 2021-07-12 12:12:44 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:12:44 --> Helper loaded: url_helper
INFO - 2021-07-12 12:12:44 --> Helper loaded: file_helper
INFO - 2021-07-12 12:12:44 --> Helper loaded: form_helper
INFO - 2021-07-12 12:12:44 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:12:44 --> Helper loaded: security_helper
INFO - 2021-07-12 12:12:44 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:12:44 --> Helper loaded: language_helper
INFO - 2021-07-12 12:12:44 --> Helper loaded: general_helper
INFO - 2021-07-12 12:12:44 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:12:44 --> Database Driver Class Initialized
DEBUG - 2021-07-12 12:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:12:44 --> Parser Class Initialized
INFO - 2021-07-12 12:12:44 --> Form Validation Class Initialized
INFO - 2021-07-12 12:12:44 --> Upload Class Initialized
INFO - 2021-07-12 12:12:44 --> Email Class Initialized
INFO - 2021-07-12 12:12:44 --> MY_Model class loaded
INFO - 2021-07-12 12:12:44 --> Model "Users_model" initialized
INFO - 2021-07-12 12:12:44 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:12:44 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:12:44 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:12:44 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:12:44 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:12:44 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:12:44 --> Database Driver Class Initialized
INFO - 2021-07-12 12:12:44 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:12:44 --> Controller Class Initialized
ERROR - 2021-07-12 12:12:44 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 12:12:44 --> File loaded: C:\wamp64\www\crm\application\views\users/list.php
INFO - 2021-07-12 12:12:44 --> Final output sent to browser
DEBUG - 2021-07-12 12:12:44 --> Total execution time: 0.2054
INFO - 2021-07-12 12:12:45 --> Config Class Initialized
INFO - 2021-07-12 12:12:45 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:12:45 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:12:45 --> Utf8 Class Initialized
INFO - 2021-07-12 12:12:45 --> URI Class Initialized
INFO - 2021-07-12 12:12:45 --> Router Class Initialized
INFO - 2021-07-12 12:12:45 --> Output Class Initialized
INFO - 2021-07-12 12:12:45 --> Security Class Initialized
DEBUG - 2021-07-12 12:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:12:45 --> Input Class Initialized
INFO - 2021-07-12 12:12:45 --> Language Class Initialized
INFO - 2021-07-12 12:12:45 --> Loader Class Initialized
INFO - 2021-07-12 12:12:45 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:12:45 --> Helper loaded: url_helper
INFO - 2021-07-12 12:12:45 --> Helper loaded: file_helper
INFO - 2021-07-12 12:12:45 --> Helper loaded: form_helper
INFO - 2021-07-12 12:12:45 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:12:45 --> Helper loaded: security_helper
INFO - 2021-07-12 12:12:45 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:12:45 --> Helper loaded: language_helper
INFO - 2021-07-12 12:12:45 --> Config Class Initialized
INFO - 2021-07-12 12:12:45 --> Hooks Class Initialized
INFO - 2021-07-12 12:12:45 --> Helper loaded: general_helper
DEBUG - 2021-07-12 12:12:45 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:12:45 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:12:45 --> Utf8 Class Initialized
INFO - 2021-07-12 12:12:45 --> URI Class Initialized
INFO - 2021-07-12 12:12:45 --> Database Driver Class Initialized
INFO - 2021-07-12 12:12:45 --> Router Class Initialized
INFO - 2021-07-12 12:12:45 --> Output Class Initialized
INFO - 2021-07-12 12:12:45 --> Security Class Initialized
DEBUG - 2021-07-12 12:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-07-12 12:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:12:45 --> Input Class Initialized
INFO - 2021-07-12 12:12:45 --> Config Class Initialized
INFO - 2021-07-12 12:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:12:45 --> Hooks Class Initialized
INFO - 2021-07-12 12:12:45 --> Language Class Initialized
INFO - 2021-07-12 12:12:45 --> Parser Class Initialized
DEBUG - 2021-07-12 12:12:45 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:12:45 --> Loader Class Initialized
INFO - 2021-07-12 12:12:45 --> Utf8 Class Initialized
INFO - 2021-07-12 12:12:45 --> Form Validation Class Initialized
INFO - 2021-07-12 12:12:45 --> URI Class Initialized
INFO - 2021-07-12 12:12:45 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:12:45 --> Upload Class Initialized
INFO - 2021-07-12 12:12:45 --> Helper loaded: url_helper
INFO - 2021-07-12 12:12:45 --> Router Class Initialized
INFO - 2021-07-12 12:12:45 --> Email Class Initialized
INFO - 2021-07-12 12:12:45 --> Helper loaded: file_helper
INFO - 2021-07-12 12:12:45 --> MY_Model class loaded
INFO - 2021-07-12 12:12:45 --> Output Class Initialized
INFO - 2021-07-12 12:12:45 --> Helper loaded: form_helper
INFO - 2021-07-12 12:12:45 --> Model "Users_model" initialized
INFO - 2021-07-12 12:12:45 --> Security Class Initialized
INFO - 2021-07-12 12:12:45 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:12:45 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:12:45 --> Config Class Initialized
DEBUG - 2021-07-12 12:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:12:45 --> Hooks Class Initialized
INFO - 2021-07-12 12:12:45 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:12:45 --> Helper loaded: security_helper
INFO - 2021-07-12 12:12:45 --> Input Class Initialized
INFO - 2021-07-12 12:12:45 --> Model "Permissions_model" initialized
DEBUG - 2021-07-12 12:12:45 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:12:45 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:12:45 --> Language Class Initialized
INFO - 2021-07-12 12:12:45 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:12:45 --> Utf8 Class Initialized
INFO - 2021-07-12 12:12:45 --> Helper loaded: language_helper
INFO - 2021-07-12 12:12:45 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:12:45 --> URI Class Initialized
INFO - 2021-07-12 12:12:45 --> Loader Class Initialized
INFO - 2021-07-12 12:12:45 --> Helper loaded: general_helper
INFO - 2021-07-12 12:12:45 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:12:45 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:12:45 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:12:45 --> Router Class Initialized
INFO - 2021-07-12 12:12:45 --> Database Driver Class Initialized
INFO - 2021-07-12 12:12:45 --> Helper loaded: url_helper
INFO - 2021-07-12 12:12:45 --> Database Driver Class Initialized
INFO - 2021-07-12 12:12:45 --> Output Class Initialized
INFO - 2021-07-12 12:12:45 --> Config Class Initialized
INFO - 2021-07-12 12:12:45 --> Helper loaded: file_helper
INFO - 2021-07-12 12:12:45 --> Hooks Class Initialized
INFO - 2021-07-12 12:12:45 --> Security Class Initialized
INFO - 2021-07-12 12:12:45 --> Helper loaded: form_helper
DEBUG - 2021-07-12 12:12:45 --> UTF-8 Support Enabled
DEBUG - 2021-07-12 12:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:12:45 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:12:45 --> Utf8 Class Initialized
INFO - 2021-07-12 12:12:45 --> Input Class Initialized
DEBUG - 2021-07-12 12:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:12:45 --> Helper loaded: security_helper
INFO - 2021-07-12 12:12:45 --> Language Class Initialized
INFO - 2021-07-12 12:12:45 --> URI Class Initialized
INFO - 2021-07-12 12:12:45 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:12:45 --> Loader Class Initialized
INFO - 2021-07-12 12:12:45 --> Helper loaded: language_helper
INFO - 2021-07-12 12:12:45 --> Router Class Initialized
INFO - 2021-07-12 12:12:45 --> Helper loaded: general_helper
INFO - 2021-07-12 12:12:45 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:12:45 --> Output Class Initialized
INFO - 2021-07-12 12:12:45 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:12:45 --> Config Class Initialized
INFO - 2021-07-12 12:12:45 --> Helper loaded: url_helper
INFO - 2021-07-12 12:12:45 --> Security Class Initialized
INFO - 2021-07-12 12:12:45 --> Hooks Class Initialized
INFO - 2021-07-12 12:12:45 --> Database Driver Class Initialized
INFO - 2021-07-12 12:12:45 --> Helper loaded: file_helper
DEBUG - 2021-07-12 12:12:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-12 12:12:45 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:12:45 --> Helper loaded: form_helper
INFO - 2021-07-12 12:12:45 --> Input Class Initialized
INFO - 2021-07-12 12:12:45 --> Utf8 Class Initialized
INFO - 2021-07-12 12:12:45 --> Language Class Initialized
INFO - 2021-07-12 12:12:45 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:12:45 --> URI Class Initialized
INFO - 2021-07-12 12:12:45 --> Helper loaded: security_helper
INFO - 2021-07-12 12:12:45 --> Loader Class Initialized
DEBUG - 2021-07-12 12:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:12:45 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:12:45 --> Router Class Initialized
INFO - 2021-07-12 12:12:45 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:12:45 --> Helper loaded: language_helper
INFO - 2021-07-12 12:12:45 --> Output Class Initialized
INFO - 2021-07-12 12:12:45 --> Helper loaded: general_helper
INFO - 2021-07-12 12:12:45 --> Helper loaded: url_helper
INFO - 2021-07-12 12:12:45 --> Security Class Initialized
INFO - 2021-07-12 12:12:45 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:12:45 --> Helper loaded: file_helper
DEBUG - 2021-07-12 12:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:12:45 --> Helper loaded: form_helper
INFO - 2021-07-12 12:12:45 --> Database Driver Class Initialized
INFO - 2021-07-12 12:12:45 --> Input Class Initialized
INFO - 2021-07-12 12:12:45 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:12:45 --> Language Class Initialized
INFO - 2021-07-12 12:12:45 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:12:45 --> Controller Class Initialized
INFO - 2021-07-12 12:12:45 --> Helper loaded: security_helper
INFO - 2021-07-12 12:12:45 --> Loader Class Initialized
INFO - 2021-07-12 12:12:45 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:12:45 --> Helper loaded: basic_helper
DEBUG - 2021-07-12 12:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:12:45 --> Helper loaded: language_helper
INFO - 2021-07-12 12:12:45 --> Helper loaded: url_helper
INFO - 2021-07-12 12:12:45 --> Final output sent to browser
INFO - 2021-07-12 12:12:45 --> Helper loaded: general_helper
INFO - 2021-07-12 12:12:45 --> Helper loaded: file_helper
DEBUG - 2021-07-12 12:12:45 --> Total execution time: 0.0496
INFO - 2021-07-12 12:12:45 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:12:45 --> Helper loaded: form_helper
INFO - 2021-07-12 12:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:12:45 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:12:45 --> Database Driver Class Initialized
INFO - 2021-07-12 12:12:45 --> Parser Class Initialized
INFO - 2021-07-12 12:12:45 --> Helper loaded: security_helper
INFO - 2021-07-12 12:12:45 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:12:45 --> Form Validation Class Initialized
INFO - 2021-07-12 12:12:45 --> Helper loaded: language_helper
INFO - 2021-07-12 12:12:45 --> Helper loaded: general_helper
INFO - 2021-07-12 12:12:45 --> Upload Class Initialized
DEBUG - 2021-07-12 12:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:12:45 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:12:45 --> Email Class Initialized
INFO - 2021-07-12 12:12:45 --> MY_Model class loaded
INFO - 2021-07-12 12:12:45 --> Database Driver Class Initialized
INFO - 2021-07-12 12:12:45 --> Model "Users_model" initialized
INFO - 2021-07-12 12:12:45 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:12:45 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:12:45 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:12:45 --> Model "Roles_model" initialized
DEBUG - 2021-07-12 12:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:12:45 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:12:45 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:12:45 --> Database Driver Class Initialized
INFO - 2021-07-12 12:12:45 --> Config Class Initialized
INFO - 2021-07-12 12:12:45 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:12:45 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:12:45 --> Utf8 Class Initialized
INFO - 2021-07-12 12:12:45 --> URI Class Initialized
INFO - 2021-07-12 12:12:45 --> Router Class Initialized
INFO - 2021-07-12 12:12:45 --> Output Class Initialized
INFO - 2021-07-12 12:12:45 --> Security Class Initialized
DEBUG - 2021-07-12 12:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:12:45 --> Input Class Initialized
INFO - 2021-07-12 12:12:45 --> Language Class Initialized
INFO - 2021-07-12 12:12:45 --> Loader Class Initialized
INFO - 2021-07-12 12:12:45 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:12:45 --> Helper loaded: url_helper
INFO - 2021-07-12 12:12:45 --> Helper loaded: file_helper
INFO - 2021-07-12 12:12:45 --> Helper loaded: form_helper
INFO - 2021-07-12 12:12:45 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:12:45 --> Helper loaded: security_helper
INFO - 2021-07-12 12:12:45 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:12:45 --> Helper loaded: language_helper
INFO - 2021-07-12 12:12:45 --> Helper loaded: general_helper
INFO - 2021-07-12 12:12:45 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:12:45 --> Database Driver Class Initialized
DEBUG - 2021-07-12 12:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:12:45 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:12:45 --> Controller Class Initialized
INFO - 2021-07-12 12:12:45 --> Final output sent to browser
DEBUG - 2021-07-12 12:12:45 --> Total execution time: 0.0695
INFO - 2021-07-12 12:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:12:45 --> Parser Class Initialized
INFO - 2021-07-12 12:12:45 --> Form Validation Class Initialized
INFO - 2021-07-12 12:12:45 --> Upload Class Initialized
INFO - 2021-07-12 12:12:45 --> Email Class Initialized
INFO - 2021-07-12 12:12:45 --> MY_Model class loaded
INFO - 2021-07-12 12:12:45 --> Model "Users_model" initialized
INFO - 2021-07-12 12:12:45 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:12:45 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:12:45 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:12:45 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:12:45 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:12:45 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:12:45 --> Database Driver Class Initialized
INFO - 2021-07-12 12:12:45 --> Config Class Initialized
INFO - 2021-07-12 12:12:45 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:12:45 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:12:45 --> Utf8 Class Initialized
INFO - 2021-07-12 12:12:45 --> URI Class Initialized
INFO - 2021-07-12 12:12:45 --> Router Class Initialized
INFO - 2021-07-12 12:12:45 --> Output Class Initialized
INFO - 2021-07-12 12:12:45 --> Security Class Initialized
DEBUG - 2021-07-12 12:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:12:45 --> Input Class Initialized
INFO - 2021-07-12 12:12:45 --> Language Class Initialized
INFO - 2021-07-12 12:12:45 --> Loader Class Initialized
INFO - 2021-07-12 12:12:45 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:12:45 --> Helper loaded: url_helper
INFO - 2021-07-12 12:12:45 --> Helper loaded: file_helper
INFO - 2021-07-12 12:12:45 --> Helper loaded: form_helper
INFO - 2021-07-12 12:12:45 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:12:45 --> Helper loaded: security_helper
INFO - 2021-07-12 12:12:45 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:12:45 --> Helper loaded: language_helper
INFO - 2021-07-12 12:12:45 --> Helper loaded: general_helper
INFO - 2021-07-12 12:12:45 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:12:45 --> Database Driver Class Initialized
INFO - 2021-07-12 12:12:45 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:12:45 --> Controller Class Initialized
DEBUG - 2021-07-12 12:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:12:45 --> Final output sent to browser
DEBUG - 2021-07-12 12:12:45 --> Total execution time: 0.0932
INFO - 2021-07-12 12:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:12:45 --> Parser Class Initialized
INFO - 2021-07-12 12:12:45 --> Form Validation Class Initialized
INFO - 2021-07-12 12:12:45 --> Upload Class Initialized
INFO - 2021-07-12 12:12:45 --> Email Class Initialized
INFO - 2021-07-12 12:12:45 --> MY_Model class loaded
INFO - 2021-07-12 12:12:45 --> Model "Users_model" initialized
INFO - 2021-07-12 12:12:45 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:12:45 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:12:45 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:12:45 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:12:45 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:12:45 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:12:45 --> Database Driver Class Initialized
INFO - 2021-07-12 12:12:45 --> Config Class Initialized
INFO - 2021-07-12 12:12:45 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:12:45 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:12:45 --> Utf8 Class Initialized
INFO - 2021-07-12 12:12:45 --> URI Class Initialized
INFO - 2021-07-12 12:12:45 --> Router Class Initialized
INFO - 2021-07-12 12:12:45 --> Output Class Initialized
INFO - 2021-07-12 12:12:45 --> Security Class Initialized
DEBUG - 2021-07-12 12:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:12:45 --> Input Class Initialized
INFO - 2021-07-12 12:12:45 --> Language Class Initialized
INFO - 2021-07-12 12:12:45 --> Loader Class Initialized
INFO - 2021-07-12 12:12:45 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:12:45 --> Helper loaded: url_helper
INFO - 2021-07-12 12:12:45 --> Helper loaded: file_helper
INFO - 2021-07-12 12:12:45 --> Helper loaded: form_helper
INFO - 2021-07-12 12:12:45 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:12:45 --> Helper loaded: security_helper
INFO - 2021-07-12 12:12:45 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:12:45 --> Helper loaded: language_helper
INFO - 2021-07-12 12:12:45 --> Helper loaded: general_helper
INFO - 2021-07-12 12:12:45 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:12:45 --> Database Driver Class Initialized
INFO - 2021-07-12 12:12:45 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:12:45 --> Controller Class Initialized
INFO - 2021-07-12 12:12:45 --> Final output sent to browser
DEBUG - 2021-07-12 12:12:45 --> Total execution time: 0.1135
INFO - 2021-07-12 12:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:12:45 --> Parser Class Initialized
INFO - 2021-07-12 12:12:45 --> Form Validation Class Initialized
INFO - 2021-07-12 12:12:45 --> Upload Class Initialized
INFO - 2021-07-12 12:12:45 --> Email Class Initialized
INFO - 2021-07-12 12:12:45 --> MY_Model class loaded
INFO - 2021-07-12 12:12:45 --> Model "Users_model" initialized
INFO - 2021-07-12 12:12:45 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:12:45 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:12:45 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:12:45 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:12:45 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:12:45 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:12:45 --> Database Driver Class Initialized
DEBUG - 2021-07-12 12:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:12:45 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:12:45 --> Controller Class Initialized
INFO - 2021-07-12 12:12:45 --> Final output sent to browser
DEBUG - 2021-07-12 12:12:45 --> Total execution time: 0.1346
INFO - 2021-07-12 12:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:12:45 --> Parser Class Initialized
INFO - 2021-07-12 12:12:45 --> Form Validation Class Initialized
INFO - 2021-07-12 12:12:45 --> Upload Class Initialized
INFO - 2021-07-12 12:12:45 --> Email Class Initialized
INFO - 2021-07-12 12:12:45 --> MY_Model class loaded
INFO - 2021-07-12 12:12:45 --> Model "Users_model" initialized
INFO - 2021-07-12 12:12:45 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:12:45 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:12:45 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:12:45 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:12:45 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:12:45 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:12:45 --> Database Driver Class Initialized
INFO - 2021-07-12 12:12:45 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:12:45 --> Controller Class Initialized
INFO - 2021-07-12 12:12:45 --> Final output sent to browser
DEBUG - 2021-07-12 12:12:45 --> Total execution time: 0.1596
INFO - 2021-07-12 12:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:12:45 --> Parser Class Initialized
INFO - 2021-07-12 12:12:45 --> Form Validation Class Initialized
INFO - 2021-07-12 12:12:45 --> Upload Class Initialized
INFO - 2021-07-12 12:12:45 --> Email Class Initialized
INFO - 2021-07-12 12:12:45 --> MY_Model class loaded
INFO - 2021-07-12 12:12:45 --> Model "Users_model" initialized
INFO - 2021-07-12 12:12:45 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:12:45 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:12:45 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:12:45 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:12:45 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:12:45 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:12:45 --> Database Driver Class Initialized
INFO - 2021-07-12 12:12:45 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:12:45 --> Controller Class Initialized
INFO - 2021-07-12 12:12:45 --> Final output sent to browser
DEBUG - 2021-07-12 12:12:45 --> Total execution time: 0.1657
INFO - 2021-07-12 12:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:12:45 --> Parser Class Initialized
INFO - 2021-07-12 12:12:45 --> Form Validation Class Initialized
INFO - 2021-07-12 12:12:45 --> Upload Class Initialized
INFO - 2021-07-12 12:12:45 --> Email Class Initialized
INFO - 2021-07-12 12:12:45 --> MY_Model class loaded
INFO - 2021-07-12 12:12:45 --> Model "Users_model" initialized
INFO - 2021-07-12 12:12:45 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:12:45 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:12:45 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:12:45 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:12:45 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:12:45 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:12:45 --> Database Driver Class Initialized
INFO - 2021-07-12 12:12:45 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:12:45 --> Controller Class Initialized
INFO - 2021-07-12 12:12:45 --> Final output sent to browser
DEBUG - 2021-07-12 12:12:45 --> Total execution time: 0.1609
INFO - 2021-07-12 12:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:12:45 --> Parser Class Initialized
INFO - 2021-07-12 12:12:45 --> Form Validation Class Initialized
INFO - 2021-07-12 12:12:45 --> Upload Class Initialized
INFO - 2021-07-12 12:12:45 --> Email Class Initialized
INFO - 2021-07-12 12:12:45 --> MY_Model class loaded
INFO - 2021-07-12 12:12:45 --> Model "Users_model" initialized
INFO - 2021-07-12 12:12:45 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:12:45 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:12:45 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:12:45 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:12:45 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:12:45 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:12:45 --> Database Driver Class Initialized
INFO - 2021-07-12 12:12:45 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:12:45 --> Controller Class Initialized
INFO - 2021-07-12 12:12:45 --> Final output sent to browser
DEBUG - 2021-07-12 12:12:45 --> Total execution time: 0.1598
INFO - 2021-07-12 12:12:46 --> Config Class Initialized
INFO - 2021-07-12 12:12:46 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:12:46 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:12:46 --> Utf8 Class Initialized
INFO - 2021-07-12 12:12:46 --> URI Class Initialized
INFO - 2021-07-12 12:12:46 --> Router Class Initialized
INFO - 2021-07-12 12:12:46 --> Output Class Initialized
INFO - 2021-07-12 12:12:46 --> Security Class Initialized
DEBUG - 2021-07-12 12:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:12:46 --> Input Class Initialized
INFO - 2021-07-12 12:12:46 --> Language Class Initialized
INFO - 2021-07-12 12:12:46 --> Loader Class Initialized
INFO - 2021-07-12 12:12:46 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:12:46 --> Helper loaded: url_helper
INFO - 2021-07-12 12:12:46 --> Helper loaded: file_helper
INFO - 2021-07-12 12:12:46 --> Helper loaded: form_helper
INFO - 2021-07-12 12:12:46 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:12:46 --> Helper loaded: security_helper
INFO - 2021-07-12 12:12:46 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:12:46 --> Helper loaded: language_helper
INFO - 2021-07-12 12:12:46 --> Helper loaded: general_helper
INFO - 2021-07-12 12:12:46 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:12:46 --> Database Driver Class Initialized
DEBUG - 2021-07-12 12:12:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:12:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:12:46 --> Parser Class Initialized
INFO - 2021-07-12 12:12:46 --> Form Validation Class Initialized
INFO - 2021-07-12 12:12:46 --> Upload Class Initialized
INFO - 2021-07-12 12:12:46 --> Email Class Initialized
INFO - 2021-07-12 12:12:46 --> MY_Model class loaded
INFO - 2021-07-12 12:12:46 --> Model "Users_model" initialized
INFO - 2021-07-12 12:12:46 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:12:46 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:12:46 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:12:46 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:12:46 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:12:46 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:12:46 --> Database Driver Class Initialized
INFO - 2021-07-12 12:12:46 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:12:46 --> Controller Class Initialized
DEBUG - 2021-07-12 12:12:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-12 12:12:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2021-07-12 12:12:46 --> Config Class Initialized
INFO - 2021-07-12 12:12:46 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:12:46 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:12:46 --> Utf8 Class Initialized
INFO - 2021-07-12 12:12:46 --> URI Class Initialized
DEBUG - 2021-07-12 12:12:46 --> No URI present. Default controller set.
INFO - 2021-07-12 12:12:46 --> Router Class Initialized
INFO - 2021-07-12 12:12:46 --> Output Class Initialized
INFO - 2021-07-12 12:12:46 --> Security Class Initialized
DEBUG - 2021-07-12 12:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:12:46 --> Input Class Initialized
INFO - 2021-07-12 12:12:46 --> Language Class Initialized
INFO - 2021-07-12 12:12:46 --> Loader Class Initialized
INFO - 2021-07-12 12:12:46 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:12:46 --> Helper loaded: url_helper
INFO - 2021-07-12 12:12:46 --> Helper loaded: file_helper
INFO - 2021-07-12 12:12:46 --> Helper loaded: form_helper
INFO - 2021-07-12 12:12:46 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:12:46 --> Helper loaded: security_helper
INFO - 2021-07-12 12:12:46 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:12:46 --> Helper loaded: language_helper
INFO - 2021-07-12 12:12:46 --> Helper loaded: general_helper
INFO - 2021-07-12 12:12:46 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:12:46 --> Database Driver Class Initialized
DEBUG - 2021-07-12 12:12:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:12:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:12:46 --> Parser Class Initialized
INFO - 2021-07-12 12:12:46 --> Form Validation Class Initialized
INFO - 2021-07-12 12:12:46 --> Upload Class Initialized
INFO - 2021-07-12 12:12:46 --> Email Class Initialized
INFO - 2021-07-12 12:12:46 --> MY_Model class loaded
INFO - 2021-07-12 12:12:46 --> Model "Users_model" initialized
INFO - 2021-07-12 12:12:46 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:12:46 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:12:46 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:12:46 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:12:46 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:12:46 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:12:46 --> Database Driver Class Initialized
INFO - 2021-07-12 12:12:46 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:12:46 --> Controller Class Initialized
ERROR - 2021-07-12 12:12:46 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 12:12:46 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-12 12:12:46 --> Final output sent to browser
DEBUG - 2021-07-12 12:12:46 --> Total execution time: 0.0809
INFO - 2021-07-12 12:12:56 --> Config Class Initialized
INFO - 2021-07-12 12:12:56 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:12:56 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:12:56 --> Utf8 Class Initialized
INFO - 2021-07-12 12:12:56 --> URI Class Initialized
INFO - 2021-07-12 12:12:56 --> Router Class Initialized
INFO - 2021-07-12 12:12:56 --> Output Class Initialized
INFO - 2021-07-12 12:12:56 --> Security Class Initialized
DEBUG - 2021-07-12 12:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:12:56 --> Input Class Initialized
INFO - 2021-07-12 12:12:56 --> Language Class Initialized
INFO - 2021-07-12 12:12:56 --> Loader Class Initialized
INFO - 2021-07-12 12:12:56 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:12:56 --> Helper loaded: url_helper
INFO - 2021-07-12 12:12:56 --> Helper loaded: file_helper
INFO - 2021-07-12 12:12:56 --> Helper loaded: form_helper
INFO - 2021-07-12 12:12:56 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:12:56 --> Helper loaded: security_helper
INFO - 2021-07-12 12:12:56 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:12:56 --> Helper loaded: language_helper
INFO - 2021-07-12 12:12:56 --> Helper loaded: general_helper
INFO - 2021-07-12 12:12:56 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:12:56 --> Database Driver Class Initialized
DEBUG - 2021-07-12 12:12:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:12:56 --> Parser Class Initialized
INFO - 2021-07-12 12:12:56 --> Form Validation Class Initialized
INFO - 2021-07-12 12:12:56 --> Upload Class Initialized
INFO - 2021-07-12 12:12:56 --> Email Class Initialized
INFO - 2021-07-12 12:12:56 --> MY_Model class loaded
INFO - 2021-07-12 12:12:56 --> Model "Users_model" initialized
INFO - 2021-07-12 12:12:56 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:12:56 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:12:56 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:12:56 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:12:56 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:12:56 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:12:56 --> Database Driver Class Initialized
INFO - 2021-07-12 12:12:56 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:12:56 --> Controller Class Initialized
ERROR - 2021-07-12 12:12:56 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-12 12:12:56 --> Could not find the language line "user_username_taken"
ERROR - 2021-07-12 12:12:56 --> Could not find the language line "confirm)new_password"
INFO - 2021-07-12 12:12:56 --> File loaded: C:\wamp64\www\crm\application\views\account/profile.php
INFO - 2021-07-12 12:12:56 --> Final output sent to browser
DEBUG - 2021-07-12 12:12:56 --> Total execution time: 0.1452
INFO - 2021-07-12 12:13:37 --> Config Class Initialized
INFO - 2021-07-12 12:13:37 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:13:37 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:13:37 --> Utf8 Class Initialized
INFO - 2021-07-12 12:13:37 --> URI Class Initialized
INFO - 2021-07-12 12:13:37 --> Router Class Initialized
INFO - 2021-07-12 12:13:37 --> Output Class Initialized
INFO - 2021-07-12 12:13:37 --> Security Class Initialized
DEBUG - 2021-07-12 12:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:13:37 --> Input Class Initialized
INFO - 2021-07-12 12:13:37 --> Language Class Initialized
INFO - 2021-07-12 12:13:37 --> Loader Class Initialized
INFO - 2021-07-12 12:13:37 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:13:37 --> Helper loaded: url_helper
INFO - 2021-07-12 12:13:37 --> Helper loaded: file_helper
INFO - 2021-07-12 12:13:37 --> Helper loaded: form_helper
INFO - 2021-07-12 12:13:37 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:13:37 --> Helper loaded: security_helper
INFO - 2021-07-12 12:13:37 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:13:37 --> Helper loaded: language_helper
INFO - 2021-07-12 12:13:37 --> Helper loaded: general_helper
INFO - 2021-07-12 12:13:37 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:13:37 --> Database Driver Class Initialized
DEBUG - 2021-07-12 12:13:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:13:37 --> Parser Class Initialized
INFO - 2021-07-12 12:13:37 --> Form Validation Class Initialized
INFO - 2021-07-12 12:13:37 --> Upload Class Initialized
INFO - 2021-07-12 12:13:37 --> Email Class Initialized
INFO - 2021-07-12 12:13:37 --> MY_Model class loaded
INFO - 2021-07-12 12:13:37 --> Model "Users_model" initialized
INFO - 2021-07-12 12:13:37 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:13:37 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:13:37 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:13:37 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:13:37 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:13:37 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:13:37 --> Database Driver Class Initialized
INFO - 2021-07-12 12:13:37 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:13:37 --> Controller Class Initialized
ERROR - 2021-07-12 12:13:37 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 12:13:37 --> File loaded: C:\wamp64\www\crm\application\views\activity_logs/list.php
INFO - 2021-07-12 12:13:37 --> Final output sent to browser
DEBUG - 2021-07-12 12:13:37 --> Total execution time: 0.1843
INFO - 2021-07-12 12:13:59 --> Config Class Initialized
INFO - 2021-07-12 12:13:59 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:13:59 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:13:59 --> Utf8 Class Initialized
INFO - 2021-07-12 12:13:59 --> URI Class Initialized
INFO - 2021-07-12 12:13:59 --> Router Class Initialized
INFO - 2021-07-12 12:13:59 --> Output Class Initialized
INFO - 2021-07-12 12:13:59 --> Security Class Initialized
DEBUG - 2021-07-12 12:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:13:59 --> Input Class Initialized
INFO - 2021-07-12 12:13:59 --> Language Class Initialized
INFO - 2021-07-12 12:13:59 --> Loader Class Initialized
INFO - 2021-07-12 12:13:59 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:13:59 --> Helper loaded: url_helper
INFO - 2021-07-12 12:13:59 --> Helper loaded: file_helper
INFO - 2021-07-12 12:13:59 --> Helper loaded: form_helper
INFO - 2021-07-12 12:13:59 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:13:59 --> Helper loaded: security_helper
INFO - 2021-07-12 12:13:59 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:13:59 --> Helper loaded: language_helper
INFO - 2021-07-12 12:13:59 --> Helper loaded: general_helper
INFO - 2021-07-12 12:13:59 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:13:59 --> Database Driver Class Initialized
DEBUG - 2021-07-12 12:13:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:13:59 --> Parser Class Initialized
INFO - 2021-07-12 12:13:59 --> Form Validation Class Initialized
INFO - 2021-07-12 12:13:59 --> Upload Class Initialized
INFO - 2021-07-12 12:13:59 --> Email Class Initialized
INFO - 2021-07-12 12:13:59 --> MY_Model class loaded
INFO - 2021-07-12 12:13:59 --> Model "Users_model" initialized
INFO - 2021-07-12 12:13:59 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:13:59 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:13:59 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:13:59 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:13:59 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:13:59 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:13:59 --> Database Driver Class Initialized
INFO - 2021-07-12 12:13:59 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:13:59 --> Controller Class Initialized
ERROR - 2021-07-12 12:13:59 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-12 12:13:59 --> Could not find the language line "user_username_taken"
ERROR - 2021-07-12 12:13:59 --> Could not find the language line "confirm)new_password"
INFO - 2021-07-12 12:13:59 --> File loaded: C:\wamp64\www\crm\application\views\account/profile.php
INFO - 2021-07-12 12:13:59 --> Final output sent to browser
DEBUG - 2021-07-12 12:13:59 --> Total execution time: 0.1484
INFO - 2021-07-12 12:14:10 --> Config Class Initialized
INFO - 2021-07-12 12:14:10 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:14:10 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:14:10 --> Utf8 Class Initialized
INFO - 2021-07-12 12:14:10 --> URI Class Initialized
INFO - 2021-07-12 12:14:10 --> Router Class Initialized
INFO - 2021-07-12 12:14:10 --> Output Class Initialized
INFO - 2021-07-12 12:14:10 --> Security Class Initialized
DEBUG - 2021-07-12 12:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:14:10 --> Input Class Initialized
INFO - 2021-07-12 12:14:10 --> Language Class Initialized
INFO - 2021-07-12 12:14:10 --> Loader Class Initialized
INFO - 2021-07-12 12:14:10 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:14:10 --> Helper loaded: url_helper
INFO - 2021-07-12 12:14:10 --> Helper loaded: file_helper
INFO - 2021-07-12 12:14:10 --> Helper loaded: form_helper
INFO - 2021-07-12 12:14:10 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:14:10 --> Helper loaded: security_helper
INFO - 2021-07-12 12:14:10 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:14:10 --> Helper loaded: language_helper
INFO - 2021-07-12 12:14:10 --> Helper loaded: general_helper
INFO - 2021-07-12 12:14:10 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:14:10 --> Database Driver Class Initialized
DEBUG - 2021-07-12 12:14:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:14:10 --> Parser Class Initialized
INFO - 2021-07-12 12:14:10 --> Form Validation Class Initialized
INFO - 2021-07-12 12:14:10 --> Upload Class Initialized
INFO - 2021-07-12 12:14:10 --> Email Class Initialized
INFO - 2021-07-12 12:14:10 --> MY_Model class loaded
INFO - 2021-07-12 12:14:10 --> Model "Users_model" initialized
INFO - 2021-07-12 12:14:10 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:14:10 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:14:10 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:14:10 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:14:10 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:14:10 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:14:10 --> Database Driver Class Initialized
INFO - 2021-07-12 12:14:10 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:14:10 --> Controller Class Initialized
ERROR - 2021-07-12 12:14:10 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 12:14:11 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-12 12:14:11 --> Final output sent to browser
DEBUG - 2021-07-12 12:14:11 --> Total execution time: 0.2607
INFO - 2021-07-12 12:14:12 --> Config Class Initialized
INFO - 2021-07-12 12:14:12 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:14:12 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:14:12 --> Utf8 Class Initialized
INFO - 2021-07-12 12:14:12 --> URI Class Initialized
INFO - 2021-07-12 12:14:12 --> Router Class Initialized
INFO - 2021-07-12 12:14:12 --> Output Class Initialized
INFO - 2021-07-12 12:14:12 --> Security Class Initialized
DEBUG - 2021-07-12 12:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:14:12 --> Input Class Initialized
INFO - 2021-07-12 12:14:12 --> Language Class Initialized
INFO - 2021-07-12 12:14:12 --> Loader Class Initialized
INFO - 2021-07-12 12:14:12 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:14:12 --> Helper loaded: url_helper
INFO - 2021-07-12 12:14:12 --> Helper loaded: file_helper
INFO - 2021-07-12 12:14:12 --> Helper loaded: form_helper
INFO - 2021-07-12 12:14:12 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:14:12 --> Helper loaded: security_helper
INFO - 2021-07-12 12:14:12 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:14:12 --> Helper loaded: language_helper
INFO - 2021-07-12 12:14:12 --> Helper loaded: general_helper
INFO - 2021-07-12 12:14:12 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:14:12 --> Database Driver Class Initialized
DEBUG - 2021-07-12 12:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:14:12 --> Parser Class Initialized
INFO - 2021-07-12 12:14:12 --> Form Validation Class Initialized
INFO - 2021-07-12 12:14:12 --> Upload Class Initialized
INFO - 2021-07-12 12:14:12 --> Email Class Initialized
INFO - 2021-07-12 12:14:12 --> MY_Model class loaded
INFO - 2021-07-12 12:14:12 --> Model "Users_model" initialized
INFO - 2021-07-12 12:14:12 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:14:12 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:14:12 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:14:12 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:14:12 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:14:12 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:14:12 --> Database Driver Class Initialized
INFO - 2021-07-12 12:14:12 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:14:12 --> Controller Class Initialized
ERROR - 2021-07-12 12:14:12 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 12:14:12 --> File loaded: C:\wamp64\www\crm\application\views\users/list.php
INFO - 2021-07-12 12:14:12 --> Final output sent to browser
DEBUG - 2021-07-12 12:14:12 --> Total execution time: 0.1058
INFO - 2021-07-12 12:14:12 --> Config Class Initialized
INFO - 2021-07-12 12:14:12 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:14:12 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:14:12 --> Utf8 Class Initialized
INFO - 2021-07-12 12:14:12 --> URI Class Initialized
INFO - 2021-07-12 12:14:12 --> Router Class Initialized
INFO - 2021-07-12 12:14:12 --> Output Class Initialized
INFO - 2021-07-12 12:14:12 --> Security Class Initialized
DEBUG - 2021-07-12 12:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:14:12 --> Input Class Initialized
INFO - 2021-07-12 12:14:12 --> Language Class Initialized
INFO - 2021-07-12 12:14:12 --> Loader Class Initialized
INFO - 2021-07-12 12:14:12 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:14:12 --> Helper loaded: url_helper
INFO - 2021-07-12 12:14:12 --> Helper loaded: file_helper
INFO - 2021-07-12 12:14:12 --> Helper loaded: form_helper
INFO - 2021-07-12 12:14:12 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:14:12 --> Helper loaded: security_helper
INFO - 2021-07-12 12:14:12 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:14:12 --> Config Class Initialized
INFO - 2021-07-12 12:14:12 --> Hooks Class Initialized
INFO - 2021-07-12 12:14:12 --> Helper loaded: language_helper
DEBUG - 2021-07-12 12:14:12 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:14:12 --> Helper loaded: general_helper
INFO - 2021-07-12 12:14:12 --> Utf8 Class Initialized
INFO - 2021-07-12 12:14:12 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:14:12 --> URI Class Initialized
INFO - 2021-07-12 12:14:12 --> Database Driver Class Initialized
INFO - 2021-07-12 12:14:12 --> Router Class Initialized
INFO - 2021-07-12 12:14:12 --> Output Class Initialized
INFO - 2021-07-12 12:14:12 --> Security Class Initialized
DEBUG - 2021-07-12 12:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-12 12:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:14:12 --> Input Class Initialized
INFO - 2021-07-12 12:14:12 --> Config Class Initialized
INFO - 2021-07-12 12:14:12 --> Language Class Initialized
INFO - 2021-07-12 12:14:12 --> Hooks Class Initialized
INFO - 2021-07-12 12:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:14:12 --> Loader Class Initialized
DEBUG - 2021-07-12 12:14:12 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:14:12 --> Utf8 Class Initialized
INFO - 2021-07-12 12:14:12 --> Parser Class Initialized
INFO - 2021-07-12 12:14:12 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:14:12 --> URI Class Initialized
INFO - 2021-07-12 12:14:12 --> Form Validation Class Initialized
INFO - 2021-07-12 12:14:12 --> Helper loaded: url_helper
INFO - 2021-07-12 12:14:12 --> Helper loaded: file_helper
INFO - 2021-07-12 12:14:12 --> Router Class Initialized
INFO - 2021-07-12 12:14:12 --> Upload Class Initialized
INFO - 2021-07-12 12:14:12 --> Helper loaded: form_helper
INFO - 2021-07-12 12:14:12 --> Output Class Initialized
INFO - 2021-07-12 12:14:12 --> Email Class Initialized
INFO - 2021-07-12 12:14:12 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:14:12 --> Security Class Initialized
INFO - 2021-07-12 12:14:12 --> MY_Model class loaded
INFO - 2021-07-12 12:14:12 --> Config Class Initialized
INFO - 2021-07-12 12:14:12 --> Helper loaded: security_helper
DEBUG - 2021-07-12 12:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:14:12 --> Hooks Class Initialized
INFO - 2021-07-12 12:14:12 --> Model "Users_model" initialized
INFO - 2021-07-12 12:14:12 --> Input Class Initialized
INFO - 2021-07-12 12:14:12 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:14:12 --> Model "Settings_model" initialized
DEBUG - 2021-07-12 12:14:12 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:14:12 --> Language Class Initialized
INFO - 2021-07-12 12:14:12 --> Helper loaded: language_helper
INFO - 2021-07-12 12:14:12 --> Utf8 Class Initialized
INFO - 2021-07-12 12:14:12 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:14:12 --> Helper loaded: general_helper
INFO - 2021-07-12 12:14:12 --> Loader Class Initialized
INFO - 2021-07-12 12:14:12 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:14:12 --> URI Class Initialized
INFO - 2021-07-12 12:14:12 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:14:12 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:14:12 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:14:12 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:14:12 --> Router Class Initialized
INFO - 2021-07-12 12:14:12 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:14:12 --> Helper loaded: url_helper
INFO - 2021-07-12 12:14:12 --> Database Driver Class Initialized
INFO - 2021-07-12 12:14:12 --> Output Class Initialized
INFO - 2021-07-12 12:14:12 --> Database Driver Class Initialized
INFO - 2021-07-12 12:14:12 --> Helper loaded: file_helper
INFO - 2021-07-12 12:14:12 --> Security Class Initialized
INFO - 2021-07-12 12:14:12 --> Config Class Initialized
INFO - 2021-07-12 12:14:12 --> Hooks Class Initialized
INFO - 2021-07-12 12:14:12 --> Helper loaded: form_helper
DEBUG - 2021-07-12 12:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:14:12 --> Input Class Initialized
DEBUG - 2021-07-12 12:14:12 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:14:12 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:14:12 --> Utf8 Class Initialized
INFO - 2021-07-12 12:14:12 --> Language Class Initialized
DEBUG - 2021-07-12 12:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:14:12 --> Helper loaded: security_helper
INFO - 2021-07-12 12:14:12 --> URI Class Initialized
INFO - 2021-07-12 12:14:12 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:14:12 --> Loader Class Initialized
INFO - 2021-07-12 12:14:12 --> Helper loaded: language_helper
INFO - 2021-07-12 12:14:12 --> Router Class Initialized
INFO - 2021-07-12 12:14:12 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:14:12 --> Helper loaded: general_helper
INFO - 2021-07-12 12:14:12 --> Output Class Initialized
INFO - 2021-07-12 12:14:12 --> Helper loaded: url_helper
INFO - 2021-07-12 12:14:12 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:14:12 --> Config Class Initialized
INFO - 2021-07-12 12:14:12 --> Security Class Initialized
INFO - 2021-07-12 12:14:12 --> Helper loaded: file_helper
INFO - 2021-07-12 12:14:12 --> Hooks Class Initialized
INFO - 2021-07-12 12:14:12 --> Database Driver Class Initialized
DEBUG - 2021-07-12 12:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:14:12 --> Helper loaded: form_helper
DEBUG - 2021-07-12 12:14:12 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:14:12 --> Input Class Initialized
INFO - 2021-07-12 12:14:12 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:14:12 --> Utf8 Class Initialized
INFO - 2021-07-12 12:14:12 --> Language Class Initialized
INFO - 2021-07-12 12:14:12 --> Helper loaded: security_helper
INFO - 2021-07-12 12:14:12 --> URI Class Initialized
INFO - 2021-07-12 12:14:12 --> Loader Class Initialized
INFO - 2021-07-12 12:14:12 --> Helper loaded: directory_helper
DEBUG - 2021-07-12 12:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:14:12 --> Router Class Initialized
INFO - 2021-07-12 12:14:12 --> Helper loaded: language_helper
INFO - 2021-07-12 12:14:12 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:14:12 --> Output Class Initialized
INFO - 2021-07-12 12:14:12 --> Helper loaded: general_helper
INFO - 2021-07-12 12:14:12 --> Helper loaded: url_helper
INFO - 2021-07-12 12:14:12 --> Security Class Initialized
INFO - 2021-07-12 12:14:12 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:14:12 --> Helper loaded: file_helper
DEBUG - 2021-07-12 12:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:14:12 --> Input Class Initialized
INFO - 2021-07-12 12:14:12 --> Helper loaded: form_helper
INFO - 2021-07-12 12:14:12 --> Database Driver Class Initialized
INFO - 2021-07-12 12:14:12 --> Language Class Initialized
INFO - 2021-07-12 12:14:12 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:14:12 --> Loader Class Initialized
INFO - 2021-07-12 12:14:12 --> Helper loaded: security_helper
INFO - 2021-07-12 12:14:12 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:14:12 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:14:12 --> Model "Hesaplar_model" initialized
DEBUG - 2021-07-12 12:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:14:12 --> Helper loaded: url_helper
INFO - 2021-07-12 12:14:12 --> Controller Class Initialized
INFO - 2021-07-12 12:14:12 --> Helper loaded: language_helper
INFO - 2021-07-12 12:14:12 --> Helper loaded: file_helper
INFO - 2021-07-12 12:14:12 --> Helper loaded: general_helper
INFO - 2021-07-12 12:14:12 --> Helper loaded: form_helper
INFO - 2021-07-12 12:14:12 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:14:12 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:14:12 --> Final output sent to browser
INFO - 2021-07-12 12:14:12 --> Database Driver Class Initialized
DEBUG - 2021-07-12 12:14:12 --> Total execution time: 0.0514
INFO - 2021-07-12 12:14:12 --> Helper loaded: security_helper
INFO - 2021-07-12 12:14:12 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:14:12 --> Helper loaded: language_helper
INFO - 2021-07-12 12:14:12 --> Parser Class Initialized
INFO - 2021-07-12 12:14:12 --> Helper loaded: general_helper
DEBUG - 2021-07-12 12:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:14:12 --> Form Validation Class Initialized
INFO - 2021-07-12 12:14:12 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:14:12 --> Database Driver Class Initialized
INFO - 2021-07-12 12:14:12 --> Upload Class Initialized
INFO - 2021-07-12 12:14:12 --> Email Class Initialized
INFO - 2021-07-12 12:14:12 --> MY_Model class loaded
INFO - 2021-07-12 12:14:12 --> Model "Users_model" initialized
INFO - 2021-07-12 12:14:12 --> Model "Settings_model" initialized
DEBUG - 2021-07-12 12:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:14:12 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:14:12 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:14:12 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:14:12 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:14:12 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:14:12 --> Database Driver Class Initialized
INFO - 2021-07-12 12:14:12 --> Config Class Initialized
INFO - 2021-07-12 12:14:12 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:14:12 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:14:12 --> Utf8 Class Initialized
INFO - 2021-07-12 12:14:12 --> URI Class Initialized
INFO - 2021-07-12 12:14:12 --> Router Class Initialized
INFO - 2021-07-12 12:14:12 --> Output Class Initialized
INFO - 2021-07-12 12:14:12 --> Security Class Initialized
DEBUG - 2021-07-12 12:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:14:12 --> Input Class Initialized
INFO - 2021-07-12 12:14:12 --> Language Class Initialized
INFO - 2021-07-12 12:14:12 --> Loader Class Initialized
INFO - 2021-07-12 12:14:12 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:14:12 --> Helper loaded: url_helper
INFO - 2021-07-12 12:14:12 --> Helper loaded: file_helper
INFO - 2021-07-12 12:14:12 --> Helper loaded: form_helper
INFO - 2021-07-12 12:14:12 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:14:12 --> Helper loaded: security_helper
INFO - 2021-07-12 12:14:12 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:14:12 --> Helper loaded: language_helper
INFO - 2021-07-12 12:14:12 --> Helper loaded: general_helper
INFO - 2021-07-12 12:14:12 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:14:12 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:14:12 --> Database Driver Class Initialized
INFO - 2021-07-12 12:14:12 --> Controller Class Initialized
INFO - 2021-07-12 12:14:12 --> Final output sent to browser
DEBUG - 2021-07-12 12:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-07-12 12:14:12 --> Total execution time: 0.0698
INFO - 2021-07-12 12:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:14:12 --> Parser Class Initialized
INFO - 2021-07-12 12:14:12 --> Form Validation Class Initialized
INFO - 2021-07-12 12:14:12 --> Upload Class Initialized
INFO - 2021-07-12 12:14:12 --> Email Class Initialized
INFO - 2021-07-12 12:14:12 --> MY_Model class loaded
INFO - 2021-07-12 12:14:12 --> Model "Users_model" initialized
INFO - 2021-07-12 12:14:12 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:14:12 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:14:12 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:14:12 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:14:12 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:14:12 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:14:12 --> Database Driver Class Initialized
INFO - 2021-07-12 12:14:12 --> Config Class Initialized
INFO - 2021-07-12 12:14:12 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:14:12 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:14:12 --> Utf8 Class Initialized
INFO - 2021-07-12 12:14:12 --> URI Class Initialized
INFO - 2021-07-12 12:14:12 --> Router Class Initialized
INFO - 2021-07-12 12:14:12 --> Output Class Initialized
INFO - 2021-07-12 12:14:12 --> Security Class Initialized
DEBUG - 2021-07-12 12:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:14:12 --> Input Class Initialized
INFO - 2021-07-12 12:14:12 --> Language Class Initialized
INFO - 2021-07-12 12:14:12 --> Loader Class Initialized
INFO - 2021-07-12 12:14:12 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:14:12 --> Helper loaded: url_helper
INFO - 2021-07-12 12:14:12 --> Helper loaded: file_helper
INFO - 2021-07-12 12:14:12 --> Helper loaded: form_helper
INFO - 2021-07-12 12:14:12 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:14:12 --> Helper loaded: security_helper
INFO - 2021-07-12 12:14:12 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:14:12 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:14:12 --> Controller Class Initialized
INFO - 2021-07-12 12:14:12 --> Helper loaded: language_helper
INFO - 2021-07-12 12:14:12 --> Helper loaded: general_helper
INFO - 2021-07-12 12:14:12 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:14:12 --> Final output sent to browser
INFO - 2021-07-12 12:14:12 --> Database Driver Class Initialized
DEBUG - 2021-07-12 12:14:12 --> Total execution time: 0.0915
INFO - 2021-07-12 12:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:14:12 --> Parser Class Initialized
DEBUG - 2021-07-12 12:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:14:12 --> Form Validation Class Initialized
INFO - 2021-07-12 12:14:12 --> Upload Class Initialized
INFO - 2021-07-12 12:14:12 --> Email Class Initialized
INFO - 2021-07-12 12:14:12 --> MY_Model class loaded
INFO - 2021-07-12 12:14:12 --> Model "Users_model" initialized
INFO - 2021-07-12 12:14:12 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:14:12 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:14:12 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:14:12 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:14:12 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:14:12 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:14:12 --> Database Driver Class Initialized
INFO - 2021-07-12 12:14:12 --> Config Class Initialized
INFO - 2021-07-12 12:14:12 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:14:12 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:14:12 --> Utf8 Class Initialized
INFO - 2021-07-12 12:14:12 --> URI Class Initialized
INFO - 2021-07-12 12:14:12 --> Router Class Initialized
INFO - 2021-07-12 12:14:12 --> Output Class Initialized
INFO - 2021-07-12 12:14:12 --> Security Class Initialized
DEBUG - 2021-07-12 12:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:14:12 --> Input Class Initialized
INFO - 2021-07-12 12:14:12 --> Language Class Initialized
INFO - 2021-07-12 12:14:12 --> Loader Class Initialized
INFO - 2021-07-12 12:14:12 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:14:12 --> Helper loaded: url_helper
INFO - 2021-07-12 12:14:12 --> Helper loaded: file_helper
INFO - 2021-07-12 12:14:12 --> Helper loaded: form_helper
INFO - 2021-07-12 12:14:12 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:14:12 --> Helper loaded: security_helper
INFO - 2021-07-12 12:14:12 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:14:12 --> Helper loaded: language_helper
INFO - 2021-07-12 12:14:12 --> Helper loaded: general_helper
INFO - 2021-07-12 12:14:12 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:14:12 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:14:12 --> Controller Class Initialized
INFO - 2021-07-12 12:14:12 --> Database Driver Class Initialized
INFO - 2021-07-12 12:14:12 --> Final output sent to browser
DEBUG - 2021-07-12 12:14:12 --> Total execution time: 0.1121
DEBUG - 2021-07-12 12:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:14:12 --> Parser Class Initialized
INFO - 2021-07-12 12:14:12 --> Form Validation Class Initialized
INFO - 2021-07-12 12:14:12 --> Upload Class Initialized
INFO - 2021-07-12 12:14:12 --> Email Class Initialized
INFO - 2021-07-12 12:14:12 --> MY_Model class loaded
INFO - 2021-07-12 12:14:12 --> Model "Users_model" initialized
INFO - 2021-07-12 12:14:12 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:14:12 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:14:12 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:14:12 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:14:12 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:14:12 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:14:12 --> Database Driver Class Initialized
INFO - 2021-07-12 12:14:12 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:14:12 --> Controller Class Initialized
INFO - 2021-07-12 12:14:12 --> Final output sent to browser
DEBUG - 2021-07-12 12:14:12 --> Total execution time: 0.1331
INFO - 2021-07-12 12:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:14:12 --> Parser Class Initialized
INFO - 2021-07-12 12:14:12 --> Form Validation Class Initialized
INFO - 2021-07-12 12:14:12 --> Upload Class Initialized
INFO - 2021-07-12 12:14:12 --> Email Class Initialized
INFO - 2021-07-12 12:14:12 --> MY_Model class loaded
INFO - 2021-07-12 12:14:12 --> Model "Users_model" initialized
INFO - 2021-07-12 12:14:12 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:14:12 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:14:12 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:14:12 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:14:12 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:14:12 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:14:12 --> Database Driver Class Initialized
INFO - 2021-07-12 12:14:12 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:14:12 --> Controller Class Initialized
INFO - 2021-07-12 12:14:12 --> Final output sent to browser
DEBUG - 2021-07-12 12:14:12 --> Total execution time: 0.1543
INFO - 2021-07-12 12:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:14:12 --> Parser Class Initialized
INFO - 2021-07-12 12:14:12 --> Form Validation Class Initialized
INFO - 2021-07-12 12:14:12 --> Upload Class Initialized
INFO - 2021-07-12 12:14:12 --> Email Class Initialized
INFO - 2021-07-12 12:14:12 --> MY_Model class loaded
INFO - 2021-07-12 12:14:12 --> Model "Users_model" initialized
INFO - 2021-07-12 12:14:12 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:14:12 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:14:12 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:14:12 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:14:12 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:14:12 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:14:12 --> Database Driver Class Initialized
INFO - 2021-07-12 12:14:12 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:14:12 --> Controller Class Initialized
INFO - 2021-07-12 12:14:12 --> Final output sent to browser
DEBUG - 2021-07-12 12:14:12 --> Total execution time: 0.1542
INFO - 2021-07-12 12:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:14:12 --> Parser Class Initialized
INFO - 2021-07-12 12:14:12 --> Form Validation Class Initialized
INFO - 2021-07-12 12:14:12 --> Upload Class Initialized
INFO - 2021-07-12 12:14:12 --> Email Class Initialized
INFO - 2021-07-12 12:14:12 --> MY_Model class loaded
INFO - 2021-07-12 12:14:12 --> Model "Users_model" initialized
INFO - 2021-07-12 12:14:12 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:14:12 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:14:12 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:14:12 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:14:12 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:14:12 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:14:12 --> Database Driver Class Initialized
INFO - 2021-07-12 12:14:12 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:14:12 --> Controller Class Initialized
INFO - 2021-07-12 12:14:12 --> Final output sent to browser
DEBUG - 2021-07-12 12:14:12 --> Total execution time: 0.1521
INFO - 2021-07-12 12:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:14:12 --> Parser Class Initialized
INFO - 2021-07-12 12:14:12 --> Form Validation Class Initialized
INFO - 2021-07-12 12:14:12 --> Upload Class Initialized
INFO - 2021-07-12 12:14:12 --> Email Class Initialized
INFO - 2021-07-12 12:14:12 --> MY_Model class loaded
INFO - 2021-07-12 12:14:12 --> Model "Users_model" initialized
INFO - 2021-07-12 12:14:12 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:14:12 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:14:12 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:14:12 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:14:12 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:14:12 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:14:12 --> Database Driver Class Initialized
INFO - 2021-07-12 12:14:12 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:14:12 --> Controller Class Initialized
INFO - 2021-07-12 12:14:12 --> Final output sent to browser
DEBUG - 2021-07-12 12:14:12 --> Total execution time: 0.1537
INFO - 2021-07-12 12:14:28 --> Config Class Initialized
INFO - 2021-07-12 12:14:28 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:14:28 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:14:28 --> Utf8 Class Initialized
INFO - 2021-07-12 12:14:28 --> URI Class Initialized
INFO - 2021-07-12 12:14:28 --> Router Class Initialized
INFO - 2021-07-12 12:14:28 --> Output Class Initialized
INFO - 2021-07-12 12:14:28 --> Security Class Initialized
DEBUG - 2021-07-12 12:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:14:28 --> Input Class Initialized
INFO - 2021-07-12 12:14:28 --> Language Class Initialized
INFO - 2021-07-12 12:14:28 --> Loader Class Initialized
INFO - 2021-07-12 12:14:28 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:14:28 --> Helper loaded: url_helper
INFO - 2021-07-12 12:14:28 --> Helper loaded: file_helper
INFO - 2021-07-12 12:14:28 --> Helper loaded: form_helper
INFO - 2021-07-12 12:14:28 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:14:28 --> Helper loaded: security_helper
INFO - 2021-07-12 12:14:28 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:14:28 --> Helper loaded: language_helper
INFO - 2021-07-12 12:14:28 --> Helper loaded: general_helper
INFO - 2021-07-12 12:14:28 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:14:28 --> Database Driver Class Initialized
DEBUG - 2021-07-12 12:14:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:14:28 --> Parser Class Initialized
INFO - 2021-07-12 12:14:28 --> Form Validation Class Initialized
INFO - 2021-07-12 12:14:28 --> Upload Class Initialized
INFO - 2021-07-12 12:14:28 --> Email Class Initialized
INFO - 2021-07-12 12:14:28 --> MY_Model class loaded
INFO - 2021-07-12 12:14:28 --> Model "Users_model" initialized
INFO - 2021-07-12 12:14:28 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:14:28 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:14:28 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:14:28 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:14:28 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:14:28 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:14:28 --> Database Driver Class Initialized
INFO - 2021-07-12 12:14:28 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:14:28 --> Controller Class Initialized
ERROR - 2021-07-12 12:14:28 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 12:14:28 --> File loaded: C:\wamp64\www\crm\application\views\activity_logs/list.php
INFO - 2021-07-12 12:14:28 --> Final output sent to browser
DEBUG - 2021-07-12 12:14:28 --> Total execution time: 0.1823
INFO - 2021-07-12 12:14:53 --> Config Class Initialized
INFO - 2021-07-12 12:14:53 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:14:53 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:14:53 --> Utf8 Class Initialized
INFO - 2021-07-12 12:14:53 --> URI Class Initialized
INFO - 2021-07-12 12:14:53 --> Router Class Initialized
INFO - 2021-07-12 12:14:53 --> Output Class Initialized
INFO - 2021-07-12 12:14:53 --> Security Class Initialized
DEBUG - 2021-07-12 12:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:14:53 --> Input Class Initialized
INFO - 2021-07-12 12:14:53 --> Language Class Initialized
INFO - 2021-07-12 12:14:53 --> Loader Class Initialized
INFO - 2021-07-12 12:14:53 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:14:53 --> Helper loaded: url_helper
INFO - 2021-07-12 12:14:53 --> Helper loaded: file_helper
INFO - 2021-07-12 12:14:53 --> Helper loaded: form_helper
INFO - 2021-07-12 12:14:53 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:14:53 --> Helper loaded: security_helper
INFO - 2021-07-12 12:14:53 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:14:53 --> Helper loaded: language_helper
INFO - 2021-07-12 12:14:53 --> Helper loaded: general_helper
INFO - 2021-07-12 12:14:53 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:14:53 --> Database Driver Class Initialized
DEBUG - 2021-07-12 12:14:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:14:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:14:53 --> Parser Class Initialized
INFO - 2021-07-12 12:14:53 --> Form Validation Class Initialized
INFO - 2021-07-12 12:14:53 --> Upload Class Initialized
INFO - 2021-07-12 12:14:53 --> Email Class Initialized
INFO - 2021-07-12 12:14:53 --> MY_Model class loaded
INFO - 2021-07-12 12:14:53 --> Model "Users_model" initialized
INFO - 2021-07-12 12:14:53 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:14:53 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:14:53 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:14:53 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:14:53 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:14:53 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:14:53 --> Database Driver Class Initialized
INFO - 2021-07-12 12:14:53 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:14:53 --> Controller Class Initialized
ERROR - 2021-07-12 12:14:53 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 12:14:53 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-12 12:14:53 --> Final output sent to browser
DEBUG - 2021-07-12 12:14:53 --> Total execution time: 0.1556
INFO - 2021-07-12 12:26:36 --> Config Class Initialized
INFO - 2021-07-12 12:26:36 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:26:36 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:26:36 --> Utf8 Class Initialized
INFO - 2021-07-12 12:26:36 --> URI Class Initialized
INFO - 2021-07-12 12:26:36 --> Router Class Initialized
INFO - 2021-07-12 12:26:36 --> Output Class Initialized
INFO - 2021-07-12 12:26:36 --> Security Class Initialized
DEBUG - 2021-07-12 12:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:26:36 --> Input Class Initialized
INFO - 2021-07-12 12:26:36 --> Language Class Initialized
INFO - 2021-07-12 12:26:36 --> Loader Class Initialized
INFO - 2021-07-12 12:26:36 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:26:36 --> Helper loaded: url_helper
INFO - 2021-07-12 12:26:36 --> Helper loaded: file_helper
INFO - 2021-07-12 12:26:36 --> Helper loaded: form_helper
INFO - 2021-07-12 12:26:36 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:26:36 --> Helper loaded: security_helper
INFO - 2021-07-12 12:26:36 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:26:36 --> Helper loaded: language_helper
INFO - 2021-07-12 12:26:36 --> Helper loaded: general_helper
INFO - 2021-07-12 12:26:36 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:26:36 --> Database Driver Class Initialized
DEBUG - 2021-07-12 12:26:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:26:36 --> Parser Class Initialized
INFO - 2021-07-12 12:26:36 --> Form Validation Class Initialized
INFO - 2021-07-12 12:26:36 --> Upload Class Initialized
INFO - 2021-07-12 12:26:36 --> Email Class Initialized
INFO - 2021-07-12 12:26:36 --> MY_Model class loaded
INFO - 2021-07-12 12:26:36 --> Model "Users_model" initialized
INFO - 2021-07-12 12:26:36 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:26:36 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:26:36 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:26:36 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:26:36 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:26:36 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:26:36 --> Database Driver Class Initialized
INFO - 2021-07-12 12:26:36 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:26:36 --> Controller Class Initialized
ERROR - 2021-07-12 12:26:36 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 12:26:36 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-12 12:26:36 --> Final output sent to browser
DEBUG - 2021-07-12 12:26:36 --> Total execution time: 0.2400
INFO - 2021-07-12 12:30:41 --> Config Class Initialized
INFO - 2021-07-12 12:30:41 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:30:41 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:30:41 --> Utf8 Class Initialized
INFO - 2021-07-12 12:30:41 --> URI Class Initialized
DEBUG - 2021-07-12 12:30:41 --> No URI present. Default controller set.
INFO - 2021-07-12 12:30:41 --> Router Class Initialized
INFO - 2021-07-12 12:30:41 --> Output Class Initialized
INFO - 2021-07-12 12:30:41 --> Security Class Initialized
DEBUG - 2021-07-12 12:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:30:41 --> Input Class Initialized
INFO - 2021-07-12 12:30:41 --> Language Class Initialized
INFO - 2021-07-12 12:30:41 --> Loader Class Initialized
INFO - 2021-07-12 12:30:41 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:30:41 --> Helper loaded: url_helper
INFO - 2021-07-12 12:30:41 --> Helper loaded: file_helper
INFO - 2021-07-12 12:30:41 --> Helper loaded: form_helper
INFO - 2021-07-12 12:30:41 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:30:41 --> Helper loaded: security_helper
INFO - 2021-07-12 12:30:41 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:30:41 --> Helper loaded: language_helper
INFO - 2021-07-12 12:30:41 --> Helper loaded: general_helper
INFO - 2021-07-12 12:30:41 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:30:41 --> Database Driver Class Initialized
DEBUG - 2021-07-12 12:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:30:41 --> Parser Class Initialized
INFO - 2021-07-12 12:30:41 --> Form Validation Class Initialized
INFO - 2021-07-12 12:30:41 --> Upload Class Initialized
INFO - 2021-07-12 12:30:41 --> Email Class Initialized
INFO - 2021-07-12 12:30:41 --> MY_Model class loaded
INFO - 2021-07-12 12:30:41 --> Model "Users_model" initialized
INFO - 2021-07-12 12:30:41 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:30:41 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:30:41 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:30:41 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:30:41 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:30:41 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:30:41 --> Database Driver Class Initialized
INFO - 2021-07-12 12:30:41 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:30:41 --> Controller Class Initialized
INFO - 2021-07-12 12:30:42 --> Config Class Initialized
INFO - 2021-07-12 12:30:42 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:30:42 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:30:42 --> Utf8 Class Initialized
INFO - 2021-07-12 12:30:42 --> URI Class Initialized
INFO - 2021-07-12 12:30:42 --> Router Class Initialized
INFO - 2021-07-12 12:30:42 --> Output Class Initialized
INFO - 2021-07-12 12:30:42 --> Security Class Initialized
DEBUG - 2021-07-12 12:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:30:42 --> Input Class Initialized
INFO - 2021-07-12 12:30:42 --> Language Class Initialized
INFO - 2021-07-12 12:30:42 --> Loader Class Initialized
INFO - 2021-07-12 12:30:42 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:30:42 --> Helper loaded: url_helper
INFO - 2021-07-12 12:30:42 --> Helper loaded: file_helper
INFO - 2021-07-12 12:30:42 --> Helper loaded: form_helper
INFO - 2021-07-12 12:30:42 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:30:42 --> Helper loaded: security_helper
INFO - 2021-07-12 12:30:42 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:30:42 --> Helper loaded: language_helper
INFO - 2021-07-12 12:30:42 --> Helper loaded: general_helper
INFO - 2021-07-12 12:30:42 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:30:42 --> Database Driver Class Initialized
DEBUG - 2021-07-12 12:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:30:42 --> Parser Class Initialized
INFO - 2021-07-12 12:30:42 --> Form Validation Class Initialized
INFO - 2021-07-12 12:30:42 --> Upload Class Initialized
INFO - 2021-07-12 12:30:42 --> Email Class Initialized
INFO - 2021-07-12 12:30:42 --> MY_Model class loaded
INFO - 2021-07-12 12:30:42 --> Model "Users_model" initialized
INFO - 2021-07-12 12:30:42 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:30:42 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:30:42 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:30:42 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:30:42 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:30:42 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:30:42 --> Database Driver Class Initialized
INFO - 2021-07-12 12:30:42 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:30:42 --> Controller Class Initialized
INFO - 2021-07-12 12:30:42 --> File loaded: C:\wamp64\www\crm\application\views\account/login.php
INFO - 2021-07-12 12:30:42 --> Final output sent to browser
DEBUG - 2021-07-12 12:30:42 --> Total execution time: 0.0537
INFO - 2021-07-12 12:30:42 --> Config Class Initialized
INFO - 2021-07-12 12:30:42 --> Config Class Initialized
INFO - 2021-07-12 12:30:42 --> Hooks Class Initialized
INFO - 2021-07-12 12:30:42 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:30:42 --> UTF-8 Support Enabled
DEBUG - 2021-07-12 12:30:42 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:30:42 --> Utf8 Class Initialized
INFO - 2021-07-12 12:30:42 --> Utf8 Class Initialized
INFO - 2021-07-12 12:30:42 --> URI Class Initialized
INFO - 2021-07-12 12:30:42 --> URI Class Initialized
INFO - 2021-07-12 12:30:42 --> Router Class Initialized
INFO - 2021-07-12 12:30:42 --> Router Class Initialized
INFO - 2021-07-12 12:30:42 --> Output Class Initialized
INFO - 2021-07-12 12:30:42 --> Output Class Initialized
INFO - 2021-07-12 12:30:42 --> Security Class Initialized
INFO - 2021-07-12 12:30:42 --> Security Class Initialized
DEBUG - 2021-07-12 12:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-12 12:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:30:42 --> Input Class Initialized
INFO - 2021-07-12 12:30:42 --> Input Class Initialized
INFO - 2021-07-12 12:30:42 --> Language Class Initialized
INFO - 2021-07-12 12:30:42 --> Language Class Initialized
ERROR - 2021-07-12 12:30:42 --> 404 Page Not Found: Assets/jquery
ERROR - 2021-07-12 12:30:42 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-12 12:30:42 --> Config Class Initialized
INFO - 2021-07-12 12:30:42 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:30:42 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:30:42 --> Utf8 Class Initialized
INFO - 2021-07-12 12:30:42 --> URI Class Initialized
INFO - 2021-07-12 12:30:42 --> Router Class Initialized
INFO - 2021-07-12 12:30:42 --> Output Class Initialized
INFO - 2021-07-12 12:30:42 --> Security Class Initialized
DEBUG - 2021-07-12 12:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:30:42 --> Input Class Initialized
INFO - 2021-07-12 12:30:42 --> Language Class Initialized
ERROR - 2021-07-12 12:30:42 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-12 12:30:50 --> Config Class Initialized
INFO - 2021-07-12 12:30:50 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:30:50 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:30:50 --> Utf8 Class Initialized
INFO - 2021-07-12 12:30:50 --> URI Class Initialized
INFO - 2021-07-12 12:30:50 --> Router Class Initialized
INFO - 2021-07-12 12:30:50 --> Output Class Initialized
INFO - 2021-07-12 12:30:50 --> Security Class Initialized
DEBUG - 2021-07-12 12:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:30:50 --> Input Class Initialized
INFO - 2021-07-12 12:30:50 --> Language Class Initialized
INFO - 2021-07-12 12:30:50 --> Loader Class Initialized
INFO - 2021-07-12 12:30:50 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:30:50 --> Helper loaded: url_helper
INFO - 2021-07-12 12:30:50 --> Helper loaded: file_helper
INFO - 2021-07-12 12:30:50 --> Helper loaded: form_helper
INFO - 2021-07-12 12:30:50 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:30:50 --> Helper loaded: security_helper
INFO - 2021-07-12 12:30:50 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:30:50 --> Helper loaded: language_helper
INFO - 2021-07-12 12:30:50 --> Helper loaded: general_helper
INFO - 2021-07-12 12:30:50 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:30:50 --> Database Driver Class Initialized
DEBUG - 2021-07-12 12:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:30:50 --> Parser Class Initialized
INFO - 2021-07-12 12:30:50 --> Form Validation Class Initialized
INFO - 2021-07-12 12:30:50 --> Upload Class Initialized
INFO - 2021-07-12 12:30:50 --> Email Class Initialized
INFO - 2021-07-12 12:30:50 --> MY_Model class loaded
INFO - 2021-07-12 12:30:50 --> Model "Users_model" initialized
INFO - 2021-07-12 12:30:50 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:30:50 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:30:50 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:30:50 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:30:50 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:30:50 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:30:50 --> Database Driver Class Initialized
INFO - 2021-07-12 12:30:50 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:30:50 --> Controller Class Initialized
DEBUG - 2021-07-12 12:30:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-12 12:30:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2021-07-12 12:30:50 --> Config Class Initialized
INFO - 2021-07-12 12:30:50 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:30:50 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:30:50 --> Utf8 Class Initialized
INFO - 2021-07-12 12:30:50 --> URI Class Initialized
DEBUG - 2021-07-12 12:30:50 --> No URI present. Default controller set.
INFO - 2021-07-12 12:30:50 --> Router Class Initialized
INFO - 2021-07-12 12:30:50 --> Output Class Initialized
INFO - 2021-07-12 12:30:50 --> Security Class Initialized
DEBUG - 2021-07-12 12:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:30:50 --> Input Class Initialized
INFO - 2021-07-12 12:30:50 --> Language Class Initialized
INFO - 2021-07-12 12:30:50 --> Loader Class Initialized
INFO - 2021-07-12 12:30:50 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:30:50 --> Helper loaded: url_helper
INFO - 2021-07-12 12:30:50 --> Helper loaded: file_helper
INFO - 2021-07-12 12:30:50 --> Helper loaded: form_helper
INFO - 2021-07-12 12:30:50 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:30:50 --> Helper loaded: security_helper
INFO - 2021-07-12 12:30:50 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:30:50 --> Helper loaded: language_helper
INFO - 2021-07-12 12:30:50 --> Helper loaded: general_helper
INFO - 2021-07-12 12:30:50 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:30:50 --> Database Driver Class Initialized
DEBUG - 2021-07-12 12:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:30:50 --> Parser Class Initialized
INFO - 2021-07-12 12:30:50 --> Form Validation Class Initialized
INFO - 2021-07-12 12:30:50 --> Upload Class Initialized
INFO - 2021-07-12 12:30:50 --> Email Class Initialized
INFO - 2021-07-12 12:30:50 --> MY_Model class loaded
INFO - 2021-07-12 12:30:50 --> Model "Users_model" initialized
INFO - 2021-07-12 12:30:50 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:30:50 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:30:50 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:30:50 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:30:50 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:30:50 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:30:50 --> Database Driver Class Initialized
INFO - 2021-07-12 12:30:50 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:30:50 --> Controller Class Initialized
ERROR - 2021-07-12 12:30:50 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 12:30:50 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-12 12:30:50 --> Final output sent to browser
DEBUG - 2021-07-12 12:30:50 --> Total execution time: 0.0596
INFO - 2021-07-12 12:30:53 --> Config Class Initialized
INFO - 2021-07-12 12:30:53 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:30:53 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:30:53 --> Utf8 Class Initialized
INFO - 2021-07-12 12:30:53 --> URI Class Initialized
INFO - 2021-07-12 12:30:53 --> Router Class Initialized
INFO - 2021-07-12 12:30:53 --> Output Class Initialized
INFO - 2021-07-12 12:30:53 --> Security Class Initialized
DEBUG - 2021-07-12 12:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:30:53 --> Input Class Initialized
INFO - 2021-07-12 12:30:53 --> Language Class Initialized
INFO - 2021-07-12 12:30:53 --> Loader Class Initialized
INFO - 2021-07-12 12:30:53 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:30:53 --> Helper loaded: url_helper
INFO - 2021-07-12 12:30:53 --> Helper loaded: file_helper
INFO - 2021-07-12 12:30:53 --> Helper loaded: form_helper
INFO - 2021-07-12 12:30:53 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:30:53 --> Helper loaded: security_helper
INFO - 2021-07-12 12:30:53 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:30:53 --> Helper loaded: language_helper
INFO - 2021-07-12 12:30:53 --> Helper loaded: general_helper
INFO - 2021-07-12 12:30:53 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:30:53 --> Database Driver Class Initialized
DEBUG - 2021-07-12 12:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:30:53 --> Parser Class Initialized
INFO - 2021-07-12 12:30:53 --> Form Validation Class Initialized
INFO - 2021-07-12 12:30:53 --> Upload Class Initialized
INFO - 2021-07-12 12:30:53 --> Email Class Initialized
INFO - 2021-07-12 12:30:53 --> MY_Model class loaded
INFO - 2021-07-12 12:30:53 --> Model "Users_model" initialized
INFO - 2021-07-12 12:30:53 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:30:53 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:30:53 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:30:53 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:30:53 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:30:53 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:30:53 --> Database Driver Class Initialized
INFO - 2021-07-12 12:30:53 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:30:53 --> Controller Class Initialized
ERROR - 2021-07-12 12:30:53 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 12:30:53 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-12 12:30:53 --> Final output sent to browser
DEBUG - 2021-07-12 12:30:53 --> Total execution time: 0.2320
INFO - 2021-07-12 12:31:04 --> Config Class Initialized
INFO - 2021-07-12 12:31:04 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:31:04 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:31:04 --> Utf8 Class Initialized
INFO - 2021-07-12 12:31:04 --> URI Class Initialized
INFO - 2021-07-12 12:31:04 --> Router Class Initialized
INFO - 2021-07-12 12:31:04 --> Output Class Initialized
INFO - 2021-07-12 12:31:04 --> Security Class Initialized
DEBUG - 2021-07-12 12:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:31:04 --> Input Class Initialized
INFO - 2021-07-12 12:31:04 --> Language Class Initialized
INFO - 2021-07-12 12:31:04 --> Loader Class Initialized
INFO - 2021-07-12 12:31:04 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:31:04 --> Helper loaded: url_helper
INFO - 2021-07-12 12:31:04 --> Helper loaded: file_helper
INFO - 2021-07-12 12:31:04 --> Helper loaded: form_helper
INFO - 2021-07-12 12:31:04 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:31:04 --> Helper loaded: security_helper
INFO - 2021-07-12 12:31:04 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:31:04 --> Helper loaded: language_helper
INFO - 2021-07-12 12:31:04 --> Helper loaded: general_helper
INFO - 2021-07-12 12:31:04 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:31:04 --> Database Driver Class Initialized
DEBUG - 2021-07-12 12:31:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:31:04 --> Parser Class Initialized
INFO - 2021-07-12 12:31:04 --> Form Validation Class Initialized
INFO - 2021-07-12 12:31:04 --> Upload Class Initialized
INFO - 2021-07-12 12:31:04 --> Email Class Initialized
INFO - 2021-07-12 12:31:04 --> MY_Model class loaded
INFO - 2021-07-12 12:31:04 --> Model "Users_model" initialized
INFO - 2021-07-12 12:31:04 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:31:04 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:31:04 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:31:04 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:31:04 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:31:04 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:31:04 --> Database Driver Class Initialized
INFO - 2021-07-12 12:31:04 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:31:04 --> Controller Class Initialized
ERROR - 2021-07-12 12:31:05 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 12:31:05 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-12 12:31:05 --> Final output sent to browser
DEBUG - 2021-07-12 12:31:05 --> Total execution time: 0.2044
INFO - 2021-07-12 12:31:08 --> Config Class Initialized
INFO - 2021-07-12 12:31:08 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:31:08 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:31:08 --> Utf8 Class Initialized
INFO - 2021-07-12 12:31:08 --> URI Class Initialized
INFO - 2021-07-12 12:31:08 --> Router Class Initialized
INFO - 2021-07-12 12:31:08 --> Output Class Initialized
INFO - 2021-07-12 12:31:08 --> Security Class Initialized
DEBUG - 2021-07-12 12:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:31:08 --> Input Class Initialized
INFO - 2021-07-12 12:31:08 --> Language Class Initialized
INFO - 2021-07-12 12:31:08 --> Loader Class Initialized
INFO - 2021-07-12 12:31:08 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:31:08 --> Helper loaded: url_helper
INFO - 2021-07-12 12:31:08 --> Helper loaded: file_helper
INFO - 2021-07-12 12:31:08 --> Helper loaded: form_helper
INFO - 2021-07-12 12:31:08 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:31:08 --> Helper loaded: security_helper
INFO - 2021-07-12 12:31:08 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:31:08 --> Helper loaded: language_helper
INFO - 2021-07-12 12:31:08 --> Helper loaded: general_helper
INFO - 2021-07-12 12:31:08 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:31:08 --> Database Driver Class Initialized
DEBUG - 2021-07-12 12:31:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:31:08 --> Parser Class Initialized
INFO - 2021-07-12 12:31:08 --> Form Validation Class Initialized
INFO - 2021-07-12 12:31:08 --> Upload Class Initialized
INFO - 2021-07-12 12:31:08 --> Email Class Initialized
INFO - 2021-07-12 12:31:08 --> MY_Model class loaded
INFO - 2021-07-12 12:31:08 --> Model "Users_model" initialized
INFO - 2021-07-12 12:31:08 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:31:08 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:31:08 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:31:08 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:31:08 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:31:08 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:31:08 --> Database Driver Class Initialized
INFO - 2021-07-12 12:31:08 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:31:08 --> Controller Class Initialized
ERROR - 2021-07-12 12:31:08 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 12:31:08 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-12 12:31:08 --> Final output sent to browser
DEBUG - 2021-07-12 12:31:08 --> Total execution time: 0.1901
INFO - 2021-07-12 12:31:10 --> Config Class Initialized
INFO - 2021-07-12 12:31:10 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:31:10 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:31:10 --> Utf8 Class Initialized
INFO - 2021-07-12 12:31:10 --> URI Class Initialized
INFO - 2021-07-12 12:31:10 --> Router Class Initialized
INFO - 2021-07-12 12:31:10 --> Output Class Initialized
INFO - 2021-07-12 12:31:10 --> Security Class Initialized
DEBUG - 2021-07-12 12:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:31:10 --> Input Class Initialized
INFO - 2021-07-12 12:31:10 --> Language Class Initialized
INFO - 2021-07-12 12:31:10 --> Loader Class Initialized
INFO - 2021-07-12 12:31:10 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:31:10 --> Helper loaded: url_helper
INFO - 2021-07-12 12:31:10 --> Helper loaded: file_helper
INFO - 2021-07-12 12:31:10 --> Helper loaded: form_helper
INFO - 2021-07-12 12:31:10 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:31:10 --> Helper loaded: security_helper
INFO - 2021-07-12 12:31:10 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:31:10 --> Helper loaded: language_helper
INFO - 2021-07-12 12:31:10 --> Helper loaded: general_helper
INFO - 2021-07-12 12:31:10 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:31:10 --> Database Driver Class Initialized
DEBUG - 2021-07-12 12:31:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:31:10 --> Parser Class Initialized
INFO - 2021-07-12 12:31:10 --> Form Validation Class Initialized
INFO - 2021-07-12 12:31:10 --> Upload Class Initialized
INFO - 2021-07-12 12:31:10 --> Email Class Initialized
INFO - 2021-07-12 12:31:10 --> MY_Model class loaded
INFO - 2021-07-12 12:31:10 --> Model "Users_model" initialized
INFO - 2021-07-12 12:31:10 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:31:10 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:31:10 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:31:10 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:31:10 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:31:10 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:31:10 --> Database Driver Class Initialized
INFO - 2021-07-12 12:31:10 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:31:10 --> Controller Class Initialized
ERROR - 2021-07-12 12:31:10 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 12:31:10 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-12 12:31:10 --> Final output sent to browser
DEBUG - 2021-07-12 12:31:10 --> Total execution time: 0.1452
INFO - 2021-07-12 12:51:58 --> Config Class Initialized
INFO - 2021-07-12 12:51:58 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:51:58 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:51:58 --> Utf8 Class Initialized
INFO - 2021-07-12 12:51:58 --> URI Class Initialized
INFO - 2021-07-12 12:51:58 --> Router Class Initialized
INFO - 2021-07-12 12:51:58 --> Output Class Initialized
INFO - 2021-07-12 12:51:58 --> Security Class Initialized
DEBUG - 2021-07-12 12:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:51:58 --> Input Class Initialized
INFO - 2021-07-12 12:51:58 --> Language Class Initialized
INFO - 2021-07-12 12:51:58 --> Loader Class Initialized
INFO - 2021-07-12 12:51:58 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:51:58 --> Helper loaded: url_helper
INFO - 2021-07-12 12:51:58 --> Helper loaded: file_helper
INFO - 2021-07-12 12:51:58 --> Helper loaded: form_helper
INFO - 2021-07-12 12:51:58 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:51:58 --> Helper loaded: security_helper
INFO - 2021-07-12 12:51:58 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:51:58 --> Helper loaded: language_helper
INFO - 2021-07-12 12:51:58 --> Helper loaded: general_helper
INFO - 2021-07-12 12:51:58 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:51:58 --> Database Driver Class Initialized
DEBUG - 2021-07-12 12:51:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:51:58 --> Parser Class Initialized
INFO - 2021-07-12 12:51:58 --> Form Validation Class Initialized
INFO - 2021-07-12 12:51:58 --> Upload Class Initialized
INFO - 2021-07-12 12:51:58 --> Email Class Initialized
INFO - 2021-07-12 12:51:58 --> MY_Model class loaded
INFO - 2021-07-12 12:51:58 --> Model "Users_model" initialized
INFO - 2021-07-12 12:51:58 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:51:58 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:51:58 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:51:58 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:51:58 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:51:58 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:51:58 --> Database Driver Class Initialized
INFO - 2021-07-12 12:51:58 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:51:58 --> Controller Class Initialized
ERROR - 2021-07-12 12:51:58 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 12:51:58 --> File loaded: C:\wamp64\www\crm\application\views\users/list.php
INFO - 2021-07-12 12:51:58 --> Final output sent to browser
DEBUG - 2021-07-12 12:51:58 --> Total execution time: 0.1723
INFO - 2021-07-12 12:51:59 --> Config Class Initialized
INFO - 2021-07-12 12:51:59 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:51:59 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:51:59 --> Utf8 Class Initialized
INFO - 2021-07-12 12:51:59 --> URI Class Initialized
INFO - 2021-07-12 12:51:59 --> Router Class Initialized
INFO - 2021-07-12 12:51:59 --> Output Class Initialized
INFO - 2021-07-12 12:51:59 --> Security Class Initialized
DEBUG - 2021-07-12 12:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:51:59 --> Input Class Initialized
INFO - 2021-07-12 12:51:59 --> Language Class Initialized
INFO - 2021-07-12 12:51:59 --> Loader Class Initialized
INFO - 2021-07-12 12:51:59 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:51:59 --> Helper loaded: url_helper
INFO - 2021-07-12 12:51:59 --> Helper loaded: file_helper
INFO - 2021-07-12 12:51:59 --> Helper loaded: form_helper
INFO - 2021-07-12 12:51:59 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:51:59 --> Config Class Initialized
INFO - 2021-07-12 12:51:59 --> Helper loaded: security_helper
INFO - 2021-07-12 12:51:59 --> Hooks Class Initialized
INFO - 2021-07-12 12:51:59 --> Helper loaded: directory_helper
DEBUG - 2021-07-12 12:51:59 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:51:59 --> Helper loaded: language_helper
INFO - 2021-07-12 12:51:59 --> Utf8 Class Initialized
INFO - 2021-07-12 12:51:59 --> Helper loaded: general_helper
INFO - 2021-07-12 12:51:59 --> URI Class Initialized
INFO - 2021-07-12 12:51:59 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:51:59 --> Router Class Initialized
INFO - 2021-07-12 12:51:59 --> Database Driver Class Initialized
INFO - 2021-07-12 12:51:59 --> Output Class Initialized
INFO - 2021-07-12 12:51:59 --> Security Class Initialized
DEBUG - 2021-07-12 12:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:51:59 --> Input Class Initialized
DEBUG - 2021-07-12 12:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:51:59 --> Language Class Initialized
INFO - 2021-07-12 12:51:59 --> Config Class Initialized
INFO - 2021-07-12 12:51:59 --> Hooks Class Initialized
INFO - 2021-07-12 12:51:59 --> Loader Class Initialized
INFO - 2021-07-12 12:51:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2021-07-12 12:51:59 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:51:59 --> Utf8 Class Initialized
INFO - 2021-07-12 12:51:59 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:51:59 --> Parser Class Initialized
INFO - 2021-07-12 12:51:59 --> URI Class Initialized
INFO - 2021-07-12 12:51:59 --> Helper loaded: url_helper
INFO - 2021-07-12 12:51:59 --> Form Validation Class Initialized
INFO - 2021-07-12 12:51:59 --> Helper loaded: file_helper
INFO - 2021-07-12 12:51:59 --> Router Class Initialized
INFO - 2021-07-12 12:51:59 --> Upload Class Initialized
INFO - 2021-07-12 12:51:59 --> Helper loaded: form_helper
INFO - 2021-07-12 12:51:59 --> Output Class Initialized
INFO - 2021-07-12 12:51:59 --> Email Class Initialized
INFO - 2021-07-12 12:51:59 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:51:59 --> Security Class Initialized
INFO - 2021-07-12 12:51:59 --> MY_Model class loaded
INFO - 2021-07-12 12:51:59 --> Helper loaded: security_helper
INFO - 2021-07-12 12:51:59 --> Model "Users_model" initialized
DEBUG - 2021-07-12 12:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:51:59 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:51:59 --> Input Class Initialized
INFO - 2021-07-12 12:51:59 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:51:59 --> Config Class Initialized
INFO - 2021-07-12 12:51:59 --> Helper loaded: language_helper
INFO - 2021-07-12 12:51:59 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:51:59 --> Language Class Initialized
INFO - 2021-07-12 12:51:59 --> Hooks Class Initialized
INFO - 2021-07-12 12:51:59 --> Helper loaded: general_helper
INFO - 2021-07-12 12:51:59 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:51:59 --> Loader Class Initialized
DEBUG - 2021-07-12 12:51:59 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:51:59 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:51:59 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:51:59 --> Utf8 Class Initialized
INFO - 2021-07-12 12:51:59 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:51:59 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:51:59 --> URI Class Initialized
INFO - 2021-07-12 12:51:59 --> Database Driver Class Initialized
INFO - 2021-07-12 12:51:59 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:51:59 --> Helper loaded: url_helper
INFO - 2021-07-12 12:51:59 --> Router Class Initialized
INFO - 2021-07-12 12:51:59 --> Database Driver Class Initialized
INFO - 2021-07-12 12:51:59 --> Helper loaded: file_helper
INFO - 2021-07-12 12:51:59 --> Output Class Initialized
INFO - 2021-07-12 12:51:59 --> Config Class Initialized
INFO - 2021-07-12 12:51:59 --> Helper loaded: form_helper
INFO - 2021-07-12 12:51:59 --> Hooks Class Initialized
INFO - 2021-07-12 12:51:59 --> Security Class Initialized
INFO - 2021-07-12 12:51:59 --> Helper loaded: cookie_helper
DEBUG - 2021-07-12 12:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-07-12 12:51:59 --> UTF-8 Support Enabled
DEBUG - 2021-07-12 12:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:51:59 --> Utf8 Class Initialized
INFO - 2021-07-12 12:51:59 --> Helper loaded: security_helper
INFO - 2021-07-12 12:51:59 --> Input Class Initialized
INFO - 2021-07-12 12:51:59 --> URI Class Initialized
INFO - 2021-07-12 12:51:59 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:51:59 --> Language Class Initialized
INFO - 2021-07-12 12:51:59 --> Helper loaded: language_helper
INFO - 2021-07-12 12:51:59 --> Router Class Initialized
INFO - 2021-07-12 12:51:59 --> Loader Class Initialized
INFO - 2021-07-12 12:51:59 --> Helper loaded: general_helper
INFO - 2021-07-12 12:51:59 --> Output Class Initialized
INFO - 2021-07-12 12:51:59 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:51:59 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:51:59 --> Security Class Initialized
INFO - 2021-07-12 12:51:59 --> Config Class Initialized
INFO - 2021-07-12 12:51:59 --> Helper loaded: url_helper
INFO - 2021-07-12 12:51:59 --> Database Driver Class Initialized
INFO - 2021-07-12 12:51:59 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:51:59 --> Helper loaded: file_helper
INFO - 2021-07-12 12:51:59 --> Input Class Initialized
DEBUG - 2021-07-12 12:51:59 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:51:59 --> Helper loaded: form_helper
INFO - 2021-07-12 12:51:59 --> Language Class Initialized
INFO - 2021-07-12 12:51:59 --> Utf8 Class Initialized
INFO - 2021-07-12 12:51:59 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:51:59 --> URI Class Initialized
INFO - 2021-07-12 12:51:59 --> Loader Class Initialized
DEBUG - 2021-07-12 12:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:51:59 --> Helper loaded: security_helper
INFO - 2021-07-12 12:51:59 --> Router Class Initialized
INFO - 2021-07-12 12:51:59 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:51:59 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:51:59 --> Output Class Initialized
INFO - 2021-07-12 12:51:59 --> Helper loaded: language_helper
INFO - 2021-07-12 12:51:59 --> Helper loaded: url_helper
INFO - 2021-07-12 12:51:59 --> Security Class Initialized
INFO - 2021-07-12 12:51:59 --> Helper loaded: general_helper
INFO - 2021-07-12 12:51:59 --> Helper loaded: file_helper
DEBUG - 2021-07-12 12:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:51:59 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:51:59 --> Helper loaded: form_helper
INFO - 2021-07-12 12:51:59 --> Input Class Initialized
INFO - 2021-07-12 12:51:59 --> Language Class Initialized
INFO - 2021-07-12 12:51:59 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:51:59 --> Database Driver Class Initialized
INFO - 2021-07-12 12:51:59 --> Helper loaded: security_helper
INFO - 2021-07-12 12:51:59 --> Loader Class Initialized
INFO - 2021-07-12 12:51:59 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:51:59 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:51:59 --> Helper loaded: language_helper
INFO - 2021-07-12 12:51:59 --> Helper loaded: url_helper
INFO - 2021-07-12 12:51:59 --> Helper loaded: general_helper
INFO - 2021-07-12 12:51:59 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:51:59 --> Helper loaded: file_helper
INFO - 2021-07-12 12:51:59 --> Controller Class Initialized
INFO - 2021-07-12 12:51:59 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:51:59 --> Helper loaded: form_helper
INFO - 2021-07-12 12:51:59 --> Database Driver Class Initialized
INFO - 2021-07-12 12:51:59 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:51:59 --> Helper loaded: security_helper
INFO - 2021-07-12 12:51:59 --> Final output sent to browser
INFO - 2021-07-12 12:51:59 --> Helper loaded: directory_helper
DEBUG - 2021-07-12 12:51:59 --> Total execution time: 0.0526
INFO - 2021-07-12 12:51:59 --> Helper loaded: language_helper
DEBUG - 2021-07-12 12:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:51:59 --> Helper loaded: general_helper
INFO - 2021-07-12 12:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:51:59 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:51:59 --> Parser Class Initialized
INFO - 2021-07-12 12:51:59 --> Database Driver Class Initialized
INFO - 2021-07-12 12:51:59 --> Form Validation Class Initialized
INFO - 2021-07-12 12:51:59 --> Upload Class Initialized
INFO - 2021-07-12 12:51:59 --> Email Class Initialized
DEBUG - 2021-07-12 12:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:51:59 --> MY_Model class loaded
INFO - 2021-07-12 12:51:59 --> Model "Users_model" initialized
INFO - 2021-07-12 12:51:59 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:51:59 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:51:59 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:51:59 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:51:59 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:51:59 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:51:59 --> Database Driver Class Initialized
INFO - 2021-07-12 12:51:59 --> Config Class Initialized
INFO - 2021-07-12 12:51:59 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:51:59 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:51:59 --> Utf8 Class Initialized
INFO - 2021-07-12 12:51:59 --> URI Class Initialized
INFO - 2021-07-12 12:51:59 --> Router Class Initialized
INFO - 2021-07-12 12:51:59 --> Output Class Initialized
INFO - 2021-07-12 12:51:59 --> Security Class Initialized
DEBUG - 2021-07-12 12:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-07-12 12:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:51:59 --> Input Class Initialized
INFO - 2021-07-12 12:51:59 --> Language Class Initialized
INFO - 2021-07-12 12:51:59 --> Loader Class Initialized
INFO - 2021-07-12 12:51:59 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:51:59 --> Helper loaded: url_helper
INFO - 2021-07-12 12:51:59 --> Helper loaded: file_helper
INFO - 2021-07-12 12:51:59 --> Helper loaded: form_helper
INFO - 2021-07-12 12:51:59 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:51:59 --> Helper loaded: security_helper
INFO - 2021-07-12 12:51:59 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:51:59 --> Helper loaded: language_helper
INFO - 2021-07-12 12:51:59 --> Helper loaded: general_helper
INFO - 2021-07-12 12:51:59 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:51:59 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:51:59 --> Database Driver Class Initialized
INFO - 2021-07-12 12:51:59 --> Controller Class Initialized
INFO - 2021-07-12 12:51:59 --> Final output sent to browser
DEBUG - 2021-07-12 12:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-07-12 12:51:59 --> Total execution time: 0.0711
INFO - 2021-07-12 12:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:51:59 --> Parser Class Initialized
INFO - 2021-07-12 12:51:59 --> Form Validation Class Initialized
INFO - 2021-07-12 12:51:59 --> Upload Class Initialized
INFO - 2021-07-12 12:51:59 --> Email Class Initialized
INFO - 2021-07-12 12:51:59 --> MY_Model class loaded
INFO - 2021-07-12 12:51:59 --> Model "Users_model" initialized
INFO - 2021-07-12 12:51:59 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:51:59 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:51:59 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:51:59 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:51:59 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:51:59 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:51:59 --> Database Driver Class Initialized
INFO - 2021-07-12 12:51:59 --> Config Class Initialized
INFO - 2021-07-12 12:51:59 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:51:59 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:51:59 --> Utf8 Class Initialized
INFO - 2021-07-12 12:51:59 --> URI Class Initialized
INFO - 2021-07-12 12:51:59 --> Router Class Initialized
INFO - 2021-07-12 12:51:59 --> Output Class Initialized
INFO - 2021-07-12 12:51:59 --> Security Class Initialized
DEBUG - 2021-07-12 12:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:51:59 --> Input Class Initialized
INFO - 2021-07-12 12:51:59 --> Language Class Initialized
INFO - 2021-07-12 12:51:59 --> Loader Class Initialized
INFO - 2021-07-12 12:51:59 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:51:59 --> Helper loaded: url_helper
INFO - 2021-07-12 12:51:59 --> Helper loaded: file_helper
INFO - 2021-07-12 12:51:59 --> Helper loaded: form_helper
INFO - 2021-07-12 12:51:59 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:51:59 --> Helper loaded: security_helper
INFO - 2021-07-12 12:51:59 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:51:59 --> Helper loaded: language_helper
INFO - 2021-07-12 12:51:59 --> Helper loaded: general_helper
INFO - 2021-07-12 12:51:59 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:51:59 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:51:59 --> Controller Class Initialized
INFO - 2021-07-12 12:51:59 --> Database Driver Class Initialized
INFO - 2021-07-12 12:51:59 --> Final output sent to browser
DEBUG - 2021-07-12 12:51:59 --> Total execution time: 0.0926
DEBUG - 2021-07-12 12:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:51:59 --> Parser Class Initialized
INFO - 2021-07-12 12:51:59 --> Form Validation Class Initialized
INFO - 2021-07-12 12:51:59 --> Upload Class Initialized
INFO - 2021-07-12 12:51:59 --> Email Class Initialized
INFO - 2021-07-12 12:51:59 --> MY_Model class loaded
INFO - 2021-07-12 12:51:59 --> Model "Users_model" initialized
INFO - 2021-07-12 12:51:59 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:51:59 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:51:59 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:51:59 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:51:59 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:51:59 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:51:59 --> Database Driver Class Initialized
INFO - 2021-07-12 12:51:59 --> Config Class Initialized
INFO - 2021-07-12 12:51:59 --> Hooks Class Initialized
DEBUG - 2021-07-12 12:51:59 --> UTF-8 Support Enabled
INFO - 2021-07-12 12:51:59 --> Utf8 Class Initialized
INFO - 2021-07-12 12:51:59 --> URI Class Initialized
INFO - 2021-07-12 12:51:59 --> Router Class Initialized
INFO - 2021-07-12 12:51:59 --> Output Class Initialized
INFO - 2021-07-12 12:51:59 --> Security Class Initialized
DEBUG - 2021-07-12 12:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 12:51:59 --> Input Class Initialized
INFO - 2021-07-12 12:51:59 --> Language Class Initialized
INFO - 2021-07-12 12:51:59 --> Loader Class Initialized
INFO - 2021-07-12 12:51:59 --> Helper loaded: basic_helper
INFO - 2021-07-12 12:51:59 --> Helper loaded: url_helper
INFO - 2021-07-12 12:51:59 --> Helper loaded: file_helper
INFO - 2021-07-12 12:51:59 --> Helper loaded: form_helper
INFO - 2021-07-12 12:51:59 --> Helper loaded: cookie_helper
INFO - 2021-07-12 12:51:59 --> Helper loaded: security_helper
INFO - 2021-07-12 12:51:59 --> Helper loaded: directory_helper
INFO - 2021-07-12 12:51:59 --> Helper loaded: language_helper
INFO - 2021-07-12 12:51:59 --> Helper loaded: general_helper
INFO - 2021-07-12 12:51:59 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 12:51:59 --> Database Driver Class Initialized
INFO - 2021-07-12 12:51:59 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:51:59 --> Controller Class Initialized
DEBUG - 2021-07-12 12:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 12:51:59 --> Final output sent to browser
DEBUG - 2021-07-12 12:51:59 --> Total execution time: 0.1082
INFO - 2021-07-12 12:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:51:59 --> Parser Class Initialized
INFO - 2021-07-12 12:51:59 --> Form Validation Class Initialized
INFO - 2021-07-12 12:51:59 --> Upload Class Initialized
INFO - 2021-07-12 12:51:59 --> Email Class Initialized
INFO - 2021-07-12 12:51:59 --> MY_Model class loaded
INFO - 2021-07-12 12:51:59 --> Model "Users_model" initialized
INFO - 2021-07-12 12:51:59 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:51:59 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:51:59 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:51:59 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:51:59 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:51:59 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:51:59 --> Database Driver Class Initialized
INFO - 2021-07-12 12:51:59 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:51:59 --> Controller Class Initialized
INFO - 2021-07-12 12:51:59 --> Final output sent to browser
DEBUG - 2021-07-12 12:51:59 --> Total execution time: 0.1291
INFO - 2021-07-12 12:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:51:59 --> Parser Class Initialized
INFO - 2021-07-12 12:51:59 --> Form Validation Class Initialized
INFO - 2021-07-12 12:51:59 --> Upload Class Initialized
INFO - 2021-07-12 12:51:59 --> Email Class Initialized
INFO - 2021-07-12 12:51:59 --> MY_Model class loaded
INFO - 2021-07-12 12:51:59 --> Model "Users_model" initialized
INFO - 2021-07-12 12:51:59 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:51:59 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:51:59 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:51:59 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:51:59 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:51:59 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:51:59 --> Database Driver Class Initialized
INFO - 2021-07-12 12:51:59 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:51:59 --> Controller Class Initialized
INFO - 2021-07-12 12:51:59 --> Final output sent to browser
DEBUG - 2021-07-12 12:51:59 --> Total execution time: 0.1679
INFO - 2021-07-12 12:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:51:59 --> Parser Class Initialized
INFO - 2021-07-12 12:51:59 --> Form Validation Class Initialized
INFO - 2021-07-12 12:51:59 --> Upload Class Initialized
INFO - 2021-07-12 12:51:59 --> Email Class Initialized
INFO - 2021-07-12 12:51:59 --> MY_Model class loaded
INFO - 2021-07-12 12:51:59 --> Model "Users_model" initialized
INFO - 2021-07-12 12:51:59 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:51:59 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:51:59 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:51:59 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:51:59 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:51:59 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:51:59 --> Database Driver Class Initialized
INFO - 2021-07-12 12:51:59 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:51:59 --> Controller Class Initialized
INFO - 2021-07-12 12:51:59 --> Final output sent to browser
DEBUG - 2021-07-12 12:51:59 --> Total execution time: 0.1577
INFO - 2021-07-12 12:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:51:59 --> Parser Class Initialized
INFO - 2021-07-12 12:51:59 --> Form Validation Class Initialized
INFO - 2021-07-12 12:51:59 --> Upload Class Initialized
INFO - 2021-07-12 12:51:59 --> Email Class Initialized
INFO - 2021-07-12 12:51:59 --> MY_Model class loaded
INFO - 2021-07-12 12:51:59 --> Model "Users_model" initialized
INFO - 2021-07-12 12:51:59 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:51:59 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:51:59 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:51:59 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:51:59 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:51:59 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:51:59 --> Database Driver Class Initialized
INFO - 2021-07-12 12:51:59 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:51:59 --> Controller Class Initialized
INFO - 2021-07-12 12:51:59 --> Final output sent to browser
DEBUG - 2021-07-12 12:51:59 --> Total execution time: 0.1571
INFO - 2021-07-12 12:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 12:51:59 --> Parser Class Initialized
INFO - 2021-07-12 12:51:59 --> Form Validation Class Initialized
INFO - 2021-07-12 12:51:59 --> Upload Class Initialized
INFO - 2021-07-12 12:51:59 --> Email Class Initialized
INFO - 2021-07-12 12:51:59 --> MY_Model class loaded
INFO - 2021-07-12 12:51:59 --> Model "Users_model" initialized
INFO - 2021-07-12 12:51:59 --> Model "Settings_model" initialized
INFO - 2021-07-12 12:51:59 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 12:51:59 --> Model "Permissions_model" initialized
INFO - 2021-07-12 12:51:59 --> Model "Roles_model" initialized
INFO - 2021-07-12 12:51:59 --> Model "Activity_model" initialized
INFO - 2021-07-12 12:51:59 --> Model "Templates_model" initialized
INFO - 2021-07-12 12:51:59 --> Database Driver Class Initialized
INFO - 2021-07-12 12:51:59 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 12:51:59 --> Controller Class Initialized
INFO - 2021-07-12 12:51:59 --> Final output sent to browser
DEBUG - 2021-07-12 12:51:59 --> Total execution time: 0.1584
INFO - 2021-07-12 13:28:00 --> Config Class Initialized
INFO - 2021-07-12 13:28:00 --> Hooks Class Initialized
DEBUG - 2021-07-12 13:28:00 --> UTF-8 Support Enabled
INFO - 2021-07-12 13:28:00 --> Utf8 Class Initialized
INFO - 2021-07-12 13:28:00 --> URI Class Initialized
INFO - 2021-07-12 13:28:00 --> Router Class Initialized
INFO - 2021-07-12 13:28:00 --> Output Class Initialized
INFO - 2021-07-12 13:28:00 --> Security Class Initialized
DEBUG - 2021-07-12 13:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 13:28:00 --> Input Class Initialized
INFO - 2021-07-12 13:28:00 --> Language Class Initialized
INFO - 2021-07-12 13:28:00 --> Loader Class Initialized
INFO - 2021-07-12 13:28:00 --> Helper loaded: basic_helper
INFO - 2021-07-12 13:28:00 --> Helper loaded: url_helper
INFO - 2021-07-12 13:28:00 --> Helper loaded: file_helper
INFO - 2021-07-12 13:28:00 --> Helper loaded: form_helper
INFO - 2021-07-12 13:28:00 --> Helper loaded: cookie_helper
INFO - 2021-07-12 13:28:00 --> Helper loaded: security_helper
INFO - 2021-07-12 13:28:00 --> Helper loaded: directory_helper
INFO - 2021-07-12 13:28:00 --> Helper loaded: language_helper
INFO - 2021-07-12 13:28:00 --> Helper loaded: general_helper
INFO - 2021-07-12 13:28:00 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 13:28:00 --> Database Driver Class Initialized
DEBUG - 2021-07-12 13:28:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 13:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 13:28:00 --> Parser Class Initialized
INFO - 2021-07-12 13:28:00 --> Form Validation Class Initialized
INFO - 2021-07-12 13:28:00 --> Upload Class Initialized
INFO - 2021-07-12 13:28:00 --> Email Class Initialized
INFO - 2021-07-12 13:28:00 --> MY_Model class loaded
INFO - 2021-07-12 13:28:00 --> Model "Users_model" initialized
INFO - 2021-07-12 13:28:00 --> Model "Settings_model" initialized
INFO - 2021-07-12 13:28:00 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 13:28:00 --> Model "Permissions_model" initialized
INFO - 2021-07-12 13:28:00 --> Model "Roles_model" initialized
INFO - 2021-07-12 13:28:00 --> Model "Activity_model" initialized
INFO - 2021-07-12 13:28:00 --> Model "Templates_model" initialized
INFO - 2021-07-12 13:28:00 --> Database Driver Class Initialized
INFO - 2021-07-12 13:28:00 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 13:28:00 --> Controller Class Initialized
ERROR - 2021-07-12 13:28:00 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 13:28:00 --> File loaded: C:\wamp64\www\crm\application\views\users/list.php
INFO - 2021-07-12 13:28:00 --> Final output sent to browser
DEBUG - 2021-07-12 13:28:00 --> Total execution time: 0.1821
INFO - 2021-07-12 13:28:01 --> Config Class Initialized
INFO - 2021-07-12 13:28:01 --> Hooks Class Initialized
DEBUG - 2021-07-12 13:28:01 --> UTF-8 Support Enabled
INFO - 2021-07-12 13:28:01 --> Utf8 Class Initialized
INFO - 2021-07-12 13:28:01 --> URI Class Initialized
INFO - 2021-07-12 13:28:01 --> Router Class Initialized
INFO - 2021-07-12 13:28:01 --> Output Class Initialized
INFO - 2021-07-12 13:28:01 --> Security Class Initialized
DEBUG - 2021-07-12 13:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 13:28:01 --> Input Class Initialized
INFO - 2021-07-12 13:28:01 --> Language Class Initialized
INFO - 2021-07-12 13:28:01 --> Loader Class Initialized
INFO - 2021-07-12 13:28:01 --> Helper loaded: basic_helper
INFO - 2021-07-12 13:28:01 --> Helper loaded: url_helper
INFO - 2021-07-12 13:28:01 --> Helper loaded: file_helper
INFO - 2021-07-12 13:28:01 --> Helper loaded: form_helper
INFO - 2021-07-12 13:28:01 --> Helper loaded: cookie_helper
INFO - 2021-07-12 13:28:01 --> Helper loaded: security_helper
INFO - 2021-07-12 13:28:01 --> Helper loaded: directory_helper
INFO - 2021-07-12 13:28:01 --> Helper loaded: language_helper
INFO - 2021-07-12 13:28:01 --> Config Class Initialized
INFO - 2021-07-12 13:28:01 --> Helper loaded: general_helper
INFO - 2021-07-12 13:28:01 --> Hooks Class Initialized
INFO - 2021-07-12 13:28:01 --> Language file loaded: language/en/basic_lang.php
DEBUG - 2021-07-12 13:28:01 --> UTF-8 Support Enabled
INFO - 2021-07-12 13:28:01 --> Utf8 Class Initialized
INFO - 2021-07-12 13:28:01 --> Database Driver Class Initialized
INFO - 2021-07-12 13:28:01 --> URI Class Initialized
INFO - 2021-07-12 13:28:01 --> Router Class Initialized
INFO - 2021-07-12 13:28:01 --> Output Class Initialized
DEBUG - 2021-07-12 13:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 13:28:01 --> Security Class Initialized
DEBUG - 2021-07-12 13:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 13:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 13:28:01 --> Input Class Initialized
INFO - 2021-07-12 13:28:01 --> Parser Class Initialized
INFO - 2021-07-12 13:28:01 --> Language Class Initialized
INFO - 2021-07-12 13:28:01 --> Form Validation Class Initialized
INFO - 2021-07-12 13:28:01 --> Loader Class Initialized
INFO - 2021-07-12 13:28:01 --> Config Class Initialized
INFO - 2021-07-12 13:28:01 --> Hooks Class Initialized
INFO - 2021-07-12 13:28:01 --> Helper loaded: basic_helper
INFO - 2021-07-12 13:28:01 --> Upload Class Initialized
DEBUG - 2021-07-12 13:28:01 --> UTF-8 Support Enabled
INFO - 2021-07-12 13:28:01 --> Utf8 Class Initialized
INFO - 2021-07-12 13:28:01 --> Helper loaded: url_helper
INFO - 2021-07-12 13:28:01 --> Email Class Initialized
INFO - 2021-07-12 13:28:01 --> URI Class Initialized
INFO - 2021-07-12 13:28:01 --> MY_Model class loaded
INFO - 2021-07-12 13:28:01 --> Helper loaded: file_helper
INFO - 2021-07-12 13:28:01 --> Model "Users_model" initialized
INFO - 2021-07-12 13:28:01 --> Router Class Initialized
INFO - 2021-07-12 13:28:01 --> Helper loaded: form_helper
INFO - 2021-07-12 13:28:01 --> Model "Settings_model" initialized
INFO - 2021-07-12 13:28:01 --> Output Class Initialized
INFO - 2021-07-12 13:28:01 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 13:28:01 --> Helper loaded: cookie_helper
INFO - 2021-07-12 13:28:01 --> Security Class Initialized
INFO - 2021-07-12 13:28:01 --> Model "Permissions_model" initialized
INFO - 2021-07-12 13:28:01 --> Helper loaded: security_helper
INFO - 2021-07-12 13:28:01 --> Model "Roles_model" initialized
DEBUG - 2021-07-12 13:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 13:28:01 --> Input Class Initialized
INFO - 2021-07-12 13:28:01 --> Model "Activity_model" initialized
INFO - 2021-07-12 13:28:01 --> Helper loaded: directory_helper
INFO - 2021-07-12 13:28:01 --> Language Class Initialized
INFO - 2021-07-12 13:28:01 --> Model "Templates_model" initialized
INFO - 2021-07-12 13:28:01 --> Config Class Initialized
INFO - 2021-07-12 13:28:01 --> Helper loaded: language_helper
INFO - 2021-07-12 13:28:01 --> Hooks Class Initialized
INFO - 2021-07-12 13:28:01 --> Database Driver Class Initialized
INFO - 2021-07-12 13:28:01 --> Loader Class Initialized
INFO - 2021-07-12 13:28:01 --> Helper loaded: general_helper
DEBUG - 2021-07-12 13:28:01 --> UTF-8 Support Enabled
INFO - 2021-07-12 13:28:01 --> Helper loaded: basic_helper
INFO - 2021-07-12 13:28:01 --> Utf8 Class Initialized
INFO - 2021-07-12 13:28:01 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 13:28:01 --> URI Class Initialized
INFO - 2021-07-12 13:28:01 --> Helper loaded: url_helper
INFO - 2021-07-12 13:28:01 --> Database Driver Class Initialized
INFO - 2021-07-12 13:28:01 --> Helper loaded: file_helper
INFO - 2021-07-12 13:28:01 --> Router Class Initialized
INFO - 2021-07-12 13:28:01 --> Helper loaded: form_helper
INFO - 2021-07-12 13:28:01 --> Output Class Initialized
INFO - 2021-07-12 13:28:01 --> Helper loaded: cookie_helper
INFO - 2021-07-12 13:28:01 --> Security Class Initialized
INFO - 2021-07-12 13:28:01 --> Helper loaded: security_helper
DEBUG - 2021-07-12 13:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-07-12 13:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 13:28:01 --> Config Class Initialized
INFO - 2021-07-12 13:28:01 --> Helper loaded: directory_helper
INFO - 2021-07-12 13:28:01 --> Input Class Initialized
INFO - 2021-07-12 13:28:01 --> Hooks Class Initialized
INFO - 2021-07-12 13:28:01 --> Helper loaded: language_helper
INFO - 2021-07-12 13:28:01 --> Language Class Initialized
DEBUG - 2021-07-12 13:28:01 --> UTF-8 Support Enabled
INFO - 2021-07-12 13:28:01 --> Helper loaded: general_helper
INFO - 2021-07-12 13:28:01 --> Utf8 Class Initialized
INFO - 2021-07-12 13:28:01 --> Loader Class Initialized
INFO - 2021-07-12 13:28:01 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 13:28:01 --> URI Class Initialized
INFO - 2021-07-12 13:28:01 --> Helper loaded: basic_helper
INFO - 2021-07-12 13:28:01 --> Database Driver Class Initialized
INFO - 2021-07-12 13:28:01 --> Router Class Initialized
INFO - 2021-07-12 13:28:01 --> Helper loaded: url_helper
INFO - 2021-07-12 13:28:01 --> Output Class Initialized
INFO - 2021-07-12 13:28:01 --> Helper loaded: file_helper
INFO - 2021-07-12 13:28:01 --> Security Class Initialized
INFO - 2021-07-12 13:28:01 --> Helper loaded: form_helper
INFO - 2021-07-12 13:28:01 --> Config Class Initialized
DEBUG - 2021-07-12 13:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 13:28:01 --> Helper loaded: cookie_helper
INFO - 2021-07-12 13:28:01 --> Hooks Class Initialized
DEBUG - 2021-07-12 13:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 13:28:01 --> Input Class Initialized
INFO - 2021-07-12 13:28:01 --> Helper loaded: security_helper
DEBUG - 2021-07-12 13:28:01 --> UTF-8 Support Enabled
INFO - 2021-07-12 13:28:01 --> Language Class Initialized
INFO - 2021-07-12 13:28:01 --> Helper loaded: directory_helper
INFO - 2021-07-12 13:28:01 --> Utf8 Class Initialized
INFO - 2021-07-12 13:28:01 --> Helper loaded: language_helper
INFO - 2021-07-12 13:28:01 --> URI Class Initialized
INFO - 2021-07-12 13:28:01 --> Loader Class Initialized
INFO - 2021-07-12 13:28:01 --> Helper loaded: general_helper
INFO - 2021-07-12 13:28:01 --> Helper loaded: basic_helper
INFO - 2021-07-12 13:28:01 --> Router Class Initialized
INFO - 2021-07-12 13:28:01 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 13:28:01 --> Helper loaded: url_helper
INFO - 2021-07-12 13:28:01 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 13:28:01 --> Output Class Initialized
INFO - 2021-07-12 13:28:01 --> Database Driver Class Initialized
INFO - 2021-07-12 13:28:01 --> Controller Class Initialized
INFO - 2021-07-12 13:28:01 --> Helper loaded: file_helper
INFO - 2021-07-12 13:28:01 --> Security Class Initialized
INFO - 2021-07-12 13:28:01 --> Helper loaded: form_helper
DEBUG - 2021-07-12 13:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 13:28:01 --> Input Class Initialized
INFO - 2021-07-12 13:28:01 --> Helper loaded: cookie_helper
INFO - 2021-07-12 13:28:01 --> Language Class Initialized
INFO - 2021-07-12 13:28:01 --> Helper loaded: security_helper
INFO - 2021-07-12 13:28:01 --> Final output sent to browser
DEBUG - 2021-07-12 13:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-07-12 13:28:01 --> Total execution time: 0.0519
INFO - 2021-07-12 13:28:01 --> Helper loaded: directory_helper
INFO - 2021-07-12 13:28:01 --> Loader Class Initialized
INFO - 2021-07-12 13:28:01 --> Helper loaded: language_helper
INFO - 2021-07-12 13:28:01 --> Helper loaded: basic_helper
INFO - 2021-07-12 13:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 13:28:01 --> Helper loaded: general_helper
INFO - 2021-07-12 13:28:01 --> Helper loaded: url_helper
INFO - 2021-07-12 13:28:01 --> Parser Class Initialized
INFO - 2021-07-12 13:28:01 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 13:28:01 --> Helper loaded: file_helper
INFO - 2021-07-12 13:28:01 --> Form Validation Class Initialized
INFO - 2021-07-12 13:28:01 --> Database Driver Class Initialized
INFO - 2021-07-12 13:28:01 --> Helper loaded: form_helper
INFO - 2021-07-12 13:28:01 --> Upload Class Initialized
INFO - 2021-07-12 13:28:01 --> Helper loaded: cookie_helper
INFO - 2021-07-12 13:28:01 --> Helper loaded: security_helper
INFO - 2021-07-12 13:28:01 --> Email Class Initialized
INFO - 2021-07-12 13:28:01 --> Helper loaded: directory_helper
INFO - 2021-07-12 13:28:01 --> MY_Model class loaded
DEBUG - 2021-07-12 13:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 13:28:01 --> Helper loaded: language_helper
INFO - 2021-07-12 13:28:01 --> Model "Users_model" initialized
INFO - 2021-07-12 13:28:01 --> Helper loaded: general_helper
INFO - 2021-07-12 13:28:01 --> Model "Settings_model" initialized
INFO - 2021-07-12 13:28:01 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 13:28:01 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 13:28:01 --> Model "Permissions_model" initialized
INFO - 2021-07-12 13:28:01 --> Model "Roles_model" initialized
INFO - 2021-07-12 13:28:01 --> Database Driver Class Initialized
INFO - 2021-07-12 13:28:01 --> Model "Activity_model" initialized
INFO - 2021-07-12 13:28:01 --> Model "Templates_model" initialized
INFO - 2021-07-12 13:28:01 --> Config Class Initialized
INFO - 2021-07-12 13:28:01 --> Database Driver Class Initialized
INFO - 2021-07-12 13:28:01 --> Hooks Class Initialized
DEBUG - 2021-07-12 13:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-07-12 13:28:01 --> UTF-8 Support Enabled
INFO - 2021-07-12 13:28:01 --> Utf8 Class Initialized
INFO - 2021-07-12 13:28:01 --> URI Class Initialized
INFO - 2021-07-12 13:28:01 --> Router Class Initialized
INFO - 2021-07-12 13:28:01 --> Output Class Initialized
INFO - 2021-07-12 13:28:01 --> Security Class Initialized
DEBUG - 2021-07-12 13:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 13:28:01 --> Input Class Initialized
INFO - 2021-07-12 13:28:01 --> Language Class Initialized
INFO - 2021-07-12 13:28:01 --> Loader Class Initialized
INFO - 2021-07-12 13:28:01 --> Helper loaded: basic_helper
INFO - 2021-07-12 13:28:01 --> Helper loaded: url_helper
INFO - 2021-07-12 13:28:01 --> Helper loaded: file_helper
INFO - 2021-07-12 13:28:01 --> Helper loaded: form_helper
INFO - 2021-07-12 13:28:01 --> Helper loaded: cookie_helper
INFO - 2021-07-12 13:28:01 --> Helper loaded: security_helper
INFO - 2021-07-12 13:28:01 --> Helper loaded: directory_helper
INFO - 2021-07-12 13:28:01 --> Helper loaded: language_helper
INFO - 2021-07-12 13:28:01 --> Helper loaded: general_helper
INFO - 2021-07-12 13:28:01 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 13:28:01 --> Database Driver Class Initialized
INFO - 2021-07-12 13:28:01 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 13:28:01 --> Controller Class Initialized
DEBUG - 2021-07-12 13:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 13:28:01 --> Final output sent to browser
DEBUG - 2021-07-12 13:28:01 --> Total execution time: 0.0687
INFO - 2021-07-12 13:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 13:28:01 --> Parser Class Initialized
INFO - 2021-07-12 13:28:01 --> Form Validation Class Initialized
INFO - 2021-07-12 13:28:01 --> Upload Class Initialized
INFO - 2021-07-12 13:28:01 --> Email Class Initialized
INFO - 2021-07-12 13:28:01 --> MY_Model class loaded
INFO - 2021-07-12 13:28:01 --> Model "Users_model" initialized
INFO - 2021-07-12 13:28:01 --> Model "Settings_model" initialized
INFO - 2021-07-12 13:28:01 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 13:28:01 --> Model "Permissions_model" initialized
INFO - 2021-07-12 13:28:01 --> Model "Roles_model" initialized
INFO - 2021-07-12 13:28:01 --> Model "Activity_model" initialized
INFO - 2021-07-12 13:28:01 --> Model "Templates_model" initialized
INFO - 2021-07-12 13:28:01 --> Database Driver Class Initialized
INFO - 2021-07-12 13:28:01 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 13:28:01 --> Controller Class Initialized
INFO - 2021-07-12 13:28:01 --> Final output sent to browser
DEBUG - 2021-07-12 13:28:01 --> Total execution time: 0.0907
INFO - 2021-07-12 13:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 13:28:01 --> Parser Class Initialized
INFO - 2021-07-12 13:28:01 --> Form Validation Class Initialized
INFO - 2021-07-12 13:28:01 --> Upload Class Initialized
INFO - 2021-07-12 13:28:01 --> Email Class Initialized
INFO - 2021-07-12 13:28:01 --> MY_Model class loaded
INFO - 2021-07-12 13:28:01 --> Model "Users_model" initialized
INFO - 2021-07-12 13:28:01 --> Model "Settings_model" initialized
INFO - 2021-07-12 13:28:01 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 13:28:01 --> Model "Permissions_model" initialized
INFO - 2021-07-12 13:28:01 --> Model "Roles_model" initialized
INFO - 2021-07-12 13:28:01 --> Model "Activity_model" initialized
INFO - 2021-07-12 13:28:01 --> Model "Templates_model" initialized
INFO - 2021-07-12 13:28:01 --> Database Driver Class Initialized
INFO - 2021-07-12 13:28:01 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 13:28:01 --> Controller Class Initialized
INFO - 2021-07-12 13:28:01 --> Final output sent to browser
DEBUG - 2021-07-12 13:28:01 --> Total execution time: 0.1116
INFO - 2021-07-12 13:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 13:28:01 --> Parser Class Initialized
INFO - 2021-07-12 13:28:01 --> Form Validation Class Initialized
INFO - 2021-07-12 13:28:01 --> Upload Class Initialized
INFO - 2021-07-12 13:28:01 --> Email Class Initialized
INFO - 2021-07-12 13:28:01 --> MY_Model class loaded
INFO - 2021-07-12 13:28:01 --> Model "Users_model" initialized
INFO - 2021-07-12 13:28:01 --> Model "Settings_model" initialized
INFO - 2021-07-12 13:28:01 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 13:28:01 --> Model "Permissions_model" initialized
INFO - 2021-07-12 13:28:01 --> Model "Roles_model" initialized
INFO - 2021-07-12 13:28:01 --> Model "Activity_model" initialized
INFO - 2021-07-12 13:28:01 --> Config Class Initialized
INFO - 2021-07-12 13:28:01 --> Model "Templates_model" initialized
INFO - 2021-07-12 13:28:01 --> Hooks Class Initialized
INFO - 2021-07-12 13:28:01 --> Database Driver Class Initialized
DEBUG - 2021-07-12 13:28:01 --> UTF-8 Support Enabled
INFO - 2021-07-12 13:28:01 --> Utf8 Class Initialized
INFO - 2021-07-12 13:28:01 --> URI Class Initialized
INFO - 2021-07-12 13:28:01 --> Router Class Initialized
INFO - 2021-07-12 13:28:01 --> Output Class Initialized
INFO - 2021-07-12 13:28:01 --> Security Class Initialized
DEBUG - 2021-07-12 13:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 13:28:01 --> Input Class Initialized
INFO - 2021-07-12 13:28:01 --> Config Class Initialized
INFO - 2021-07-12 13:28:01 --> Language Class Initialized
INFO - 2021-07-12 13:28:01 --> Hooks Class Initialized
INFO - 2021-07-12 13:28:01 --> Loader Class Initialized
DEBUG - 2021-07-12 13:28:01 --> UTF-8 Support Enabled
INFO - 2021-07-12 13:28:01 --> Utf8 Class Initialized
INFO - 2021-07-12 13:28:01 --> Helper loaded: basic_helper
INFO - 2021-07-12 13:28:01 --> URI Class Initialized
INFO - 2021-07-12 13:28:01 --> Helper loaded: url_helper
INFO - 2021-07-12 13:28:01 --> Helper loaded: file_helper
INFO - 2021-07-12 13:28:01 --> Router Class Initialized
INFO - 2021-07-12 13:28:01 --> Helper loaded: form_helper
INFO - 2021-07-12 13:28:01 --> Output Class Initialized
INFO - 2021-07-12 13:28:01 --> Helper loaded: cookie_helper
INFO - 2021-07-12 13:28:01 --> Security Class Initialized
INFO - 2021-07-12 13:28:01 --> Helper loaded: security_helper
DEBUG - 2021-07-12 13:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 13:28:01 --> Input Class Initialized
INFO - 2021-07-12 13:28:01 --> Helper loaded: directory_helper
INFO - 2021-07-12 13:28:01 --> Language Class Initialized
INFO - 2021-07-12 13:28:01 --> Helper loaded: language_helper
INFO - 2021-07-12 13:28:01 --> Helper loaded: general_helper
INFO - 2021-07-12 13:28:01 --> Loader Class Initialized
INFO - 2021-07-12 13:28:01 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 13:28:01 --> Helper loaded: basic_helper
INFO - 2021-07-12 13:28:01 --> Database Driver Class Initialized
INFO - 2021-07-12 13:28:01 --> Helper loaded: url_helper
INFO - 2021-07-12 13:28:01 --> Helper loaded: file_helper
INFO - 2021-07-12 13:28:01 --> Helper loaded: form_helper
INFO - 2021-07-12 13:28:01 --> Helper loaded: cookie_helper
INFO - 2021-07-12 13:28:01 --> Model "Hesaplar_model" initialized
DEBUG - 2021-07-12 13:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 13:28:01 --> Helper loaded: security_helper
INFO - 2021-07-12 13:28:01 --> Controller Class Initialized
INFO - 2021-07-12 13:28:01 --> Helper loaded: directory_helper
INFO - 2021-07-12 13:28:01 --> Helper loaded: language_helper
INFO - 2021-07-12 13:28:01 --> Helper loaded: general_helper
INFO - 2021-07-12 13:28:01 --> Final output sent to browser
INFO - 2021-07-12 13:28:01 --> Language file loaded: language/en/basic_lang.php
DEBUG - 2021-07-12 13:28:01 --> Total execution time: 0.1335
INFO - 2021-07-12 13:28:01 --> Database Driver Class Initialized
INFO - 2021-07-12 13:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 13:28:01 --> Parser Class Initialized
INFO - 2021-07-12 13:28:01 --> Form Validation Class Initialized
DEBUG - 2021-07-12 13:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 13:28:01 --> Upload Class Initialized
INFO - 2021-07-12 13:28:01 --> Email Class Initialized
INFO - 2021-07-12 13:28:01 --> MY_Model class loaded
INFO - 2021-07-12 13:28:01 --> Model "Users_model" initialized
INFO - 2021-07-12 13:28:01 --> Model "Settings_model" initialized
INFO - 2021-07-12 13:28:01 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 13:28:01 --> Model "Permissions_model" initialized
INFO - 2021-07-12 13:28:01 --> Model "Roles_model" initialized
INFO - 2021-07-12 13:28:01 --> Model "Activity_model" initialized
INFO - 2021-07-12 13:28:01 --> Model "Templates_model" initialized
INFO - 2021-07-12 13:28:01 --> Database Driver Class Initialized
INFO - 2021-07-12 13:28:01 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 13:28:01 --> Controller Class Initialized
INFO - 2021-07-12 13:28:01 --> Final output sent to browser
DEBUG - 2021-07-12 13:28:01 --> Total execution time: 0.1537
INFO - 2021-07-12 13:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 13:28:01 --> Parser Class Initialized
INFO - 2021-07-12 13:28:01 --> Form Validation Class Initialized
INFO - 2021-07-12 13:28:01 --> Upload Class Initialized
INFO - 2021-07-12 13:28:01 --> Email Class Initialized
INFO - 2021-07-12 13:28:01 --> MY_Model class loaded
INFO - 2021-07-12 13:28:01 --> Model "Users_model" initialized
INFO - 2021-07-12 13:28:01 --> Model "Settings_model" initialized
INFO - 2021-07-12 13:28:01 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 13:28:01 --> Model "Permissions_model" initialized
INFO - 2021-07-12 13:28:01 --> Model "Roles_model" initialized
INFO - 2021-07-12 13:28:01 --> Model "Activity_model" initialized
INFO - 2021-07-12 13:28:01 --> Model "Templates_model" initialized
INFO - 2021-07-12 13:28:01 --> Database Driver Class Initialized
INFO - 2021-07-12 13:28:01 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 13:28:01 --> Controller Class Initialized
INFO - 2021-07-12 13:28:01 --> Final output sent to browser
DEBUG - 2021-07-12 13:28:01 --> Total execution time: 0.1611
INFO - 2021-07-12 13:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 13:28:01 --> Parser Class Initialized
INFO - 2021-07-12 13:28:01 --> Form Validation Class Initialized
INFO - 2021-07-12 13:28:01 --> Upload Class Initialized
INFO - 2021-07-12 13:28:01 --> Email Class Initialized
INFO - 2021-07-12 13:28:01 --> MY_Model class loaded
INFO - 2021-07-12 13:28:01 --> Model "Users_model" initialized
INFO - 2021-07-12 13:28:01 --> Model "Settings_model" initialized
INFO - 2021-07-12 13:28:01 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 13:28:01 --> Model "Permissions_model" initialized
INFO - 2021-07-12 13:28:01 --> Model "Roles_model" initialized
INFO - 2021-07-12 13:28:01 --> Model "Activity_model" initialized
INFO - 2021-07-12 13:28:01 --> Model "Templates_model" initialized
INFO - 2021-07-12 13:28:01 --> Database Driver Class Initialized
INFO - 2021-07-12 13:28:01 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 13:28:01 --> Controller Class Initialized
INFO - 2021-07-12 13:28:01 --> Final output sent to browser
DEBUG - 2021-07-12 13:28:01 --> Total execution time: 0.1054
INFO - 2021-07-12 13:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 13:28:01 --> Parser Class Initialized
INFO - 2021-07-12 13:28:01 --> Form Validation Class Initialized
INFO - 2021-07-12 13:28:01 --> Upload Class Initialized
INFO - 2021-07-12 13:28:01 --> Email Class Initialized
INFO - 2021-07-12 13:28:01 --> MY_Model class loaded
INFO - 2021-07-12 13:28:01 --> Model "Users_model" initialized
INFO - 2021-07-12 13:28:01 --> Model "Settings_model" initialized
INFO - 2021-07-12 13:28:01 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 13:28:01 --> Model "Permissions_model" initialized
INFO - 2021-07-12 13:28:01 --> Model "Roles_model" initialized
INFO - 2021-07-12 13:28:01 --> Model "Activity_model" initialized
INFO - 2021-07-12 13:28:01 --> Model "Templates_model" initialized
INFO - 2021-07-12 13:28:01 --> Database Driver Class Initialized
INFO - 2021-07-12 13:28:01 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 13:28:01 --> Controller Class Initialized
INFO - 2021-07-12 13:28:01 --> Final output sent to browser
DEBUG - 2021-07-12 13:28:01 --> Total execution time: 0.1272
INFO - 2021-07-12 13:37:17 --> Config Class Initialized
INFO - 2021-07-12 13:37:17 --> Hooks Class Initialized
DEBUG - 2021-07-12 13:37:17 --> UTF-8 Support Enabled
INFO - 2021-07-12 13:37:17 --> Utf8 Class Initialized
INFO - 2021-07-12 13:37:17 --> URI Class Initialized
INFO - 2021-07-12 13:37:17 --> Router Class Initialized
INFO - 2021-07-12 13:37:17 --> Output Class Initialized
INFO - 2021-07-12 13:37:17 --> Security Class Initialized
DEBUG - 2021-07-12 13:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 13:37:17 --> Input Class Initialized
INFO - 2021-07-12 13:37:17 --> Language Class Initialized
INFO - 2021-07-12 13:37:17 --> Loader Class Initialized
INFO - 2021-07-12 13:37:17 --> Helper loaded: basic_helper
INFO - 2021-07-12 13:37:17 --> Helper loaded: url_helper
INFO - 2021-07-12 13:37:17 --> Helper loaded: file_helper
INFO - 2021-07-12 13:37:17 --> Helper loaded: form_helper
INFO - 2021-07-12 13:37:17 --> Helper loaded: cookie_helper
INFO - 2021-07-12 13:37:17 --> Helper loaded: security_helper
INFO - 2021-07-12 13:37:17 --> Helper loaded: directory_helper
INFO - 2021-07-12 13:37:17 --> Helper loaded: language_helper
INFO - 2021-07-12 13:37:17 --> Helper loaded: general_helper
INFO - 2021-07-12 13:37:17 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 13:37:17 --> Database Driver Class Initialized
DEBUG - 2021-07-12 13:37:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 13:37:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 13:37:17 --> Parser Class Initialized
INFO - 2021-07-12 13:37:17 --> Form Validation Class Initialized
INFO - 2021-07-12 13:37:17 --> Upload Class Initialized
INFO - 2021-07-12 13:37:17 --> Email Class Initialized
INFO - 2021-07-12 13:37:17 --> MY_Model class loaded
INFO - 2021-07-12 13:37:17 --> Model "Users_model" initialized
INFO - 2021-07-12 13:37:17 --> Model "Settings_model" initialized
INFO - 2021-07-12 13:37:17 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 13:37:17 --> Model "Permissions_model" initialized
INFO - 2021-07-12 13:37:17 --> Model "Roles_model" initialized
INFO - 2021-07-12 13:37:17 --> Model "Activity_model" initialized
INFO - 2021-07-12 13:37:17 --> Model "Templates_model" initialized
INFO - 2021-07-12 13:37:17 --> Database Driver Class Initialized
INFO - 2021-07-12 13:37:17 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 13:37:17 --> Controller Class Initialized
ERROR - 2021-07-12 13:37:17 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 13:37:17 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-12 13:37:17 --> Final output sent to browser
DEBUG - 2021-07-12 13:37:17 --> Total execution time: 0.6850
INFO - 2021-07-12 13:41:12 --> Config Class Initialized
INFO - 2021-07-12 13:41:12 --> Hooks Class Initialized
DEBUG - 2021-07-12 13:41:12 --> UTF-8 Support Enabled
INFO - 2021-07-12 13:41:12 --> Utf8 Class Initialized
INFO - 2021-07-12 13:41:12 --> URI Class Initialized
DEBUG - 2021-07-12 13:41:12 --> No URI present. Default controller set.
INFO - 2021-07-12 13:41:12 --> Router Class Initialized
INFO - 2021-07-12 13:41:12 --> Output Class Initialized
INFO - 2021-07-12 13:41:12 --> Security Class Initialized
DEBUG - 2021-07-12 13:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 13:41:12 --> Input Class Initialized
INFO - 2021-07-12 13:41:12 --> Language Class Initialized
INFO - 2021-07-12 13:41:12 --> Loader Class Initialized
INFO - 2021-07-12 13:41:12 --> Helper loaded: basic_helper
INFO - 2021-07-12 13:41:12 --> Helper loaded: url_helper
INFO - 2021-07-12 13:41:12 --> Helper loaded: file_helper
INFO - 2021-07-12 13:41:12 --> Helper loaded: form_helper
INFO - 2021-07-12 13:41:12 --> Helper loaded: cookie_helper
INFO - 2021-07-12 13:41:12 --> Helper loaded: security_helper
INFO - 2021-07-12 13:41:12 --> Helper loaded: directory_helper
INFO - 2021-07-12 13:41:12 --> Helper loaded: language_helper
INFO - 2021-07-12 13:41:12 --> Helper loaded: general_helper
INFO - 2021-07-12 13:41:12 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 13:41:12 --> Database Driver Class Initialized
DEBUG - 2021-07-12 13:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 13:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 13:41:12 --> Parser Class Initialized
INFO - 2021-07-12 13:41:12 --> Form Validation Class Initialized
INFO - 2021-07-12 13:41:12 --> Upload Class Initialized
INFO - 2021-07-12 13:41:12 --> Email Class Initialized
INFO - 2021-07-12 13:41:12 --> MY_Model class loaded
INFO - 2021-07-12 13:41:12 --> Model "Users_model" initialized
INFO - 2021-07-12 13:41:12 --> Model "Settings_model" initialized
INFO - 2021-07-12 13:41:12 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 13:41:12 --> Model "Permissions_model" initialized
INFO - 2021-07-12 13:41:12 --> Model "Roles_model" initialized
INFO - 2021-07-12 13:41:12 --> Model "Activity_model" initialized
INFO - 2021-07-12 13:41:12 --> Model "Templates_model" initialized
INFO - 2021-07-12 13:41:12 --> Database Driver Class Initialized
INFO - 2021-07-12 13:41:12 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 13:41:12 --> Controller Class Initialized
INFO - 2021-07-12 14:53:10 --> Config Class Initialized
INFO - 2021-07-12 14:53:10 --> Hooks Class Initialized
DEBUG - 2021-07-12 14:53:10 --> UTF-8 Support Enabled
INFO - 2021-07-12 14:53:10 --> Utf8 Class Initialized
INFO - 2021-07-12 14:53:10 --> URI Class Initialized
DEBUG - 2021-07-12 14:53:10 --> No URI present. Default controller set.
INFO - 2021-07-12 14:53:10 --> Router Class Initialized
INFO - 2021-07-12 14:53:10 --> Output Class Initialized
INFO - 2021-07-12 14:53:10 --> Security Class Initialized
DEBUG - 2021-07-12 14:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 14:53:10 --> Input Class Initialized
INFO - 2021-07-12 14:53:10 --> Language Class Initialized
INFO - 2021-07-12 14:53:10 --> Loader Class Initialized
INFO - 2021-07-12 14:53:10 --> Helper loaded: basic_helper
INFO - 2021-07-12 14:53:10 --> Helper loaded: url_helper
INFO - 2021-07-12 14:53:10 --> Helper loaded: file_helper
INFO - 2021-07-12 14:53:10 --> Helper loaded: form_helper
INFO - 2021-07-12 14:53:10 --> Helper loaded: cookie_helper
INFO - 2021-07-12 14:53:10 --> Helper loaded: security_helper
INFO - 2021-07-12 14:53:10 --> Helper loaded: directory_helper
INFO - 2021-07-12 14:53:10 --> Helper loaded: language_helper
INFO - 2021-07-12 14:53:10 --> Helper loaded: general_helper
INFO - 2021-07-12 14:53:10 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 14:53:10 --> Database Driver Class Initialized
DEBUG - 2021-07-12 14:53:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 14:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 14:53:10 --> Parser Class Initialized
INFO - 2021-07-12 14:53:10 --> Form Validation Class Initialized
INFO - 2021-07-12 14:53:10 --> Upload Class Initialized
INFO - 2021-07-12 14:53:10 --> Email Class Initialized
INFO - 2021-07-12 14:53:10 --> MY_Model class loaded
INFO - 2021-07-12 14:53:10 --> Model "Users_model" initialized
INFO - 2021-07-12 14:53:10 --> Model "Settings_model" initialized
INFO - 2021-07-12 14:53:10 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 14:53:10 --> Model "Permissions_model" initialized
INFO - 2021-07-12 14:53:10 --> Model "Roles_model" initialized
INFO - 2021-07-12 14:53:10 --> Model "Activity_model" initialized
INFO - 2021-07-12 14:53:10 --> Model "Templates_model" initialized
INFO - 2021-07-12 14:53:10 --> Database Driver Class Initialized
INFO - 2021-07-12 14:53:10 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 14:53:10 --> Controller Class Initialized
INFO - 2021-07-12 16:05:00 --> Config Class Initialized
INFO - 2021-07-12 16:05:00 --> Hooks Class Initialized
DEBUG - 2021-07-12 16:05:00 --> UTF-8 Support Enabled
INFO - 2021-07-12 16:05:00 --> Utf8 Class Initialized
INFO - 2021-07-12 16:05:00 --> URI Class Initialized
DEBUG - 2021-07-12 16:05:00 --> No URI present. Default controller set.
INFO - 2021-07-12 16:05:00 --> Router Class Initialized
INFO - 2021-07-12 16:05:00 --> Output Class Initialized
INFO - 2021-07-12 16:05:00 --> Security Class Initialized
DEBUG - 2021-07-12 16:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 16:05:00 --> Input Class Initialized
INFO - 2021-07-12 16:05:00 --> Language Class Initialized
INFO - 2021-07-12 16:05:00 --> Loader Class Initialized
INFO - 2021-07-12 16:05:00 --> Helper loaded: basic_helper
INFO - 2021-07-12 16:05:00 --> Helper loaded: url_helper
INFO - 2021-07-12 16:05:00 --> Helper loaded: file_helper
INFO - 2021-07-12 16:05:00 --> Helper loaded: form_helper
INFO - 2021-07-12 16:05:00 --> Helper loaded: cookie_helper
INFO - 2021-07-12 16:05:00 --> Helper loaded: security_helper
INFO - 2021-07-12 16:05:00 --> Helper loaded: directory_helper
INFO - 2021-07-12 16:05:00 --> Helper loaded: language_helper
INFO - 2021-07-12 16:05:00 --> Helper loaded: general_helper
INFO - 2021-07-12 16:05:00 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 16:05:00 --> Database Driver Class Initialized
DEBUG - 2021-07-12 16:05:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 16:05:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 16:05:00 --> Parser Class Initialized
INFO - 2021-07-12 16:05:00 --> Form Validation Class Initialized
INFO - 2021-07-12 16:05:00 --> Upload Class Initialized
INFO - 2021-07-12 16:05:00 --> Email Class Initialized
INFO - 2021-07-12 16:05:00 --> MY_Model class loaded
INFO - 2021-07-12 16:05:00 --> Model "Users_model" initialized
INFO - 2021-07-12 16:05:00 --> Model "Settings_model" initialized
INFO - 2021-07-12 16:05:00 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 16:05:00 --> Model "Permissions_model" initialized
INFO - 2021-07-12 16:05:00 --> Model "Roles_model" initialized
INFO - 2021-07-12 16:05:00 --> Model "Activity_model" initialized
INFO - 2021-07-12 16:05:00 --> Model "Templates_model" initialized
INFO - 2021-07-12 16:05:00 --> Database Driver Class Initialized
INFO - 2021-07-12 16:05:01 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 16:05:01 --> Controller Class Initialized
INFO - 2021-07-12 16:34:33 --> Config Class Initialized
INFO - 2021-07-12 16:34:33 --> Hooks Class Initialized
DEBUG - 2021-07-12 16:34:33 --> UTF-8 Support Enabled
INFO - 2021-07-12 16:34:33 --> Utf8 Class Initialized
INFO - 2021-07-12 16:34:33 --> URI Class Initialized
DEBUG - 2021-07-12 16:34:33 --> No URI present. Default controller set.
INFO - 2021-07-12 16:34:33 --> Router Class Initialized
INFO - 2021-07-12 16:34:33 --> Output Class Initialized
INFO - 2021-07-12 16:34:33 --> Security Class Initialized
DEBUG - 2021-07-12 16:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 16:34:33 --> Input Class Initialized
INFO - 2021-07-12 16:34:33 --> Language Class Initialized
INFO - 2021-07-12 16:34:33 --> Loader Class Initialized
INFO - 2021-07-12 16:34:33 --> Helper loaded: basic_helper
INFO - 2021-07-12 16:34:33 --> Helper loaded: url_helper
INFO - 2021-07-12 16:34:33 --> Helper loaded: file_helper
INFO - 2021-07-12 16:34:33 --> Helper loaded: form_helper
INFO - 2021-07-12 16:34:33 --> Helper loaded: cookie_helper
INFO - 2021-07-12 16:34:33 --> Helper loaded: security_helper
INFO - 2021-07-12 16:34:33 --> Helper loaded: directory_helper
INFO - 2021-07-12 16:34:33 --> Helper loaded: language_helper
INFO - 2021-07-12 16:34:33 --> Helper loaded: general_helper
INFO - 2021-07-12 16:34:33 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 16:34:33 --> Database Driver Class Initialized
DEBUG - 2021-07-12 16:34:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 16:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 16:34:33 --> Parser Class Initialized
INFO - 2021-07-12 16:34:33 --> Form Validation Class Initialized
INFO - 2021-07-12 16:34:33 --> Upload Class Initialized
INFO - 2021-07-12 16:34:33 --> Email Class Initialized
INFO - 2021-07-12 16:34:33 --> MY_Model class loaded
INFO - 2021-07-12 16:34:33 --> Model "Users_model" initialized
INFO - 2021-07-12 16:34:33 --> Model "Settings_model" initialized
INFO - 2021-07-12 16:34:33 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 16:34:33 --> Model "Permissions_model" initialized
INFO - 2021-07-12 16:34:33 --> Model "Roles_model" initialized
INFO - 2021-07-12 16:34:33 --> Model "Activity_model" initialized
INFO - 2021-07-12 16:34:33 --> Model "Templates_model" initialized
INFO - 2021-07-12 16:34:33 --> Database Driver Class Initialized
INFO - 2021-07-12 16:34:33 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 16:34:33 --> Controller Class Initialized
ERROR - 2021-07-12 16:34:33 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 16:34:33 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-12 16:34:33 --> Final output sent to browser
DEBUG - 2021-07-12 16:34:33 --> Total execution time: 0.1523
INFO - 2021-07-12 16:34:34 --> Config Class Initialized
INFO - 2021-07-12 16:34:34 --> Hooks Class Initialized
DEBUG - 2021-07-12 16:34:34 --> UTF-8 Support Enabled
INFO - 2021-07-12 16:34:34 --> Utf8 Class Initialized
INFO - 2021-07-12 16:34:34 --> URI Class Initialized
INFO - 2021-07-12 16:34:34 --> Router Class Initialized
INFO - 2021-07-12 16:34:34 --> Output Class Initialized
INFO - 2021-07-12 16:34:34 --> Security Class Initialized
DEBUG - 2021-07-12 16:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 16:34:34 --> Input Class Initialized
INFO - 2021-07-12 16:34:34 --> Language Class Initialized
ERROR - 2021-07-12 16:34:34 --> 404 Page Not Found: Faviconico/index
INFO - 2021-07-12 16:34:35 --> Config Class Initialized
INFO - 2021-07-12 16:34:35 --> Hooks Class Initialized
DEBUG - 2021-07-12 16:34:35 --> UTF-8 Support Enabled
INFO - 2021-07-12 16:34:35 --> Utf8 Class Initialized
INFO - 2021-07-12 16:34:35 --> URI Class Initialized
INFO - 2021-07-12 16:34:35 --> Router Class Initialized
INFO - 2021-07-12 16:34:35 --> Output Class Initialized
INFO - 2021-07-12 16:34:35 --> Security Class Initialized
DEBUG - 2021-07-12 16:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 16:34:35 --> Input Class Initialized
INFO - 2021-07-12 16:34:35 --> Language Class Initialized
INFO - 2021-07-12 16:34:35 --> Loader Class Initialized
INFO - 2021-07-12 16:34:35 --> Helper loaded: basic_helper
INFO - 2021-07-12 16:34:35 --> Helper loaded: url_helper
INFO - 2021-07-12 16:34:35 --> Helper loaded: file_helper
INFO - 2021-07-12 16:34:35 --> Helper loaded: form_helper
INFO - 2021-07-12 16:34:35 --> Helper loaded: cookie_helper
INFO - 2021-07-12 16:34:35 --> Helper loaded: security_helper
INFO - 2021-07-12 16:34:35 --> Helper loaded: directory_helper
INFO - 2021-07-12 16:34:35 --> Helper loaded: language_helper
INFO - 2021-07-12 16:34:35 --> Helper loaded: general_helper
INFO - 2021-07-12 16:34:35 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 16:34:35 --> Database Driver Class Initialized
DEBUG - 2021-07-12 16:34:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 16:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 16:34:35 --> Parser Class Initialized
INFO - 2021-07-12 16:34:35 --> Form Validation Class Initialized
INFO - 2021-07-12 16:34:35 --> Upload Class Initialized
INFO - 2021-07-12 16:34:35 --> Email Class Initialized
INFO - 2021-07-12 16:34:35 --> MY_Model class loaded
INFO - 2021-07-12 16:34:35 --> Model "Users_model" initialized
INFO - 2021-07-12 16:34:35 --> Model "Settings_model" initialized
INFO - 2021-07-12 16:34:35 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 16:34:35 --> Model "Permissions_model" initialized
INFO - 2021-07-12 16:34:35 --> Model "Roles_model" initialized
INFO - 2021-07-12 16:34:35 --> Model "Activity_model" initialized
INFO - 2021-07-12 16:34:35 --> Model "Templates_model" initialized
INFO - 2021-07-12 16:34:35 --> Database Driver Class Initialized
INFO - 2021-07-12 16:34:35 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 16:34:35 --> Controller Class Initialized
ERROR - 2021-07-12 16:34:35 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 16:34:35 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-12 16:34:35 --> Final output sent to browser
DEBUG - 2021-07-12 16:34:35 --> Total execution time: 0.3498
INFO - 2021-07-12 16:34:37 --> Config Class Initialized
INFO - 2021-07-12 16:34:37 --> Hooks Class Initialized
DEBUG - 2021-07-12 16:34:37 --> UTF-8 Support Enabled
INFO - 2021-07-12 16:34:37 --> Utf8 Class Initialized
INFO - 2021-07-12 16:34:37 --> URI Class Initialized
INFO - 2021-07-12 16:34:37 --> Router Class Initialized
INFO - 2021-07-12 16:34:37 --> Output Class Initialized
INFO - 2021-07-12 16:34:37 --> Security Class Initialized
DEBUG - 2021-07-12 16:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 16:34:37 --> Input Class Initialized
INFO - 2021-07-12 16:34:37 --> Language Class Initialized
INFO - 2021-07-12 16:34:37 --> Loader Class Initialized
INFO - 2021-07-12 16:34:37 --> Helper loaded: basic_helper
INFO - 2021-07-12 16:34:37 --> Helper loaded: url_helper
INFO - 2021-07-12 16:34:37 --> Helper loaded: file_helper
INFO - 2021-07-12 16:34:37 --> Helper loaded: form_helper
INFO - 2021-07-12 16:34:37 --> Helper loaded: cookie_helper
INFO - 2021-07-12 16:34:37 --> Helper loaded: security_helper
INFO - 2021-07-12 16:34:37 --> Helper loaded: directory_helper
INFO - 2021-07-12 16:34:37 --> Helper loaded: language_helper
INFO - 2021-07-12 16:34:37 --> Helper loaded: general_helper
INFO - 2021-07-12 16:34:37 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 16:34:37 --> Database Driver Class Initialized
DEBUG - 2021-07-12 16:34:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 16:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 16:34:37 --> Parser Class Initialized
INFO - 2021-07-12 16:34:37 --> Form Validation Class Initialized
INFO - 2021-07-12 16:34:37 --> Upload Class Initialized
INFO - 2021-07-12 16:34:37 --> Email Class Initialized
INFO - 2021-07-12 16:34:37 --> MY_Model class loaded
INFO - 2021-07-12 16:34:37 --> Model "Users_model" initialized
INFO - 2021-07-12 16:34:37 --> Model "Settings_model" initialized
INFO - 2021-07-12 16:34:37 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 16:34:37 --> Model "Permissions_model" initialized
INFO - 2021-07-12 16:34:37 --> Model "Roles_model" initialized
INFO - 2021-07-12 16:34:37 --> Model "Activity_model" initialized
INFO - 2021-07-12 16:34:37 --> Model "Templates_model" initialized
INFO - 2021-07-12 16:34:37 --> Database Driver Class Initialized
INFO - 2021-07-12 16:34:37 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 16:34:37 --> Controller Class Initialized
ERROR - 2021-07-12 16:34:37 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 16:34:37 --> File loaded: C:\wamp64\www\crm\application\views\users/list.php
INFO - 2021-07-12 16:34:37 --> Final output sent to browser
DEBUG - 2021-07-12 16:34:37 --> Total execution time: 0.1686
INFO - 2021-07-12 16:34:38 --> Config Class Initialized
INFO - 2021-07-12 16:34:38 --> Hooks Class Initialized
DEBUG - 2021-07-12 16:34:38 --> UTF-8 Support Enabled
INFO - 2021-07-12 16:34:38 --> Utf8 Class Initialized
INFO - 2021-07-12 16:34:38 --> URI Class Initialized
INFO - 2021-07-12 16:34:38 --> Router Class Initialized
INFO - 2021-07-12 16:34:38 --> Output Class Initialized
INFO - 2021-07-12 16:34:38 --> Security Class Initialized
DEBUG - 2021-07-12 16:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 16:34:38 --> Input Class Initialized
INFO - 2021-07-12 16:34:38 --> Language Class Initialized
INFO - 2021-07-12 16:34:38 --> Loader Class Initialized
INFO - 2021-07-12 16:34:38 --> Helper loaded: basic_helper
INFO - 2021-07-12 16:34:38 --> Helper loaded: url_helper
INFO - 2021-07-12 16:34:38 --> Helper loaded: file_helper
INFO - 2021-07-12 16:34:38 --> Helper loaded: form_helper
INFO - 2021-07-12 16:34:38 --> Helper loaded: cookie_helper
INFO - 2021-07-12 16:34:38 --> Helper loaded: security_helper
INFO - 2021-07-12 16:34:38 --> Config Class Initialized
INFO - 2021-07-12 16:34:38 --> Hooks Class Initialized
INFO - 2021-07-12 16:34:38 --> Helper loaded: directory_helper
INFO - 2021-07-12 16:34:38 --> Helper loaded: language_helper
DEBUG - 2021-07-12 16:34:38 --> UTF-8 Support Enabled
INFO - 2021-07-12 16:34:38 --> Helper loaded: general_helper
INFO - 2021-07-12 16:34:38 --> Utf8 Class Initialized
INFO - 2021-07-12 16:34:38 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 16:34:38 --> URI Class Initialized
INFO - 2021-07-12 16:34:38 --> Database Driver Class Initialized
INFO - 2021-07-12 16:34:38 --> Router Class Initialized
INFO - 2021-07-12 16:34:38 --> Output Class Initialized
INFO - 2021-07-12 16:34:38 --> Security Class Initialized
DEBUG - 2021-07-12 16:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-07-12 16:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 16:34:38 --> Input Class Initialized
INFO - 2021-07-12 16:34:38 --> Config Class Initialized
INFO - 2021-07-12 16:34:38 --> Hooks Class Initialized
INFO - 2021-07-12 16:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 16:34:38 --> Language Class Initialized
DEBUG - 2021-07-12 16:34:38 --> UTF-8 Support Enabled
INFO - 2021-07-12 16:34:38 --> Parser Class Initialized
INFO - 2021-07-12 16:34:38 --> Loader Class Initialized
INFO - 2021-07-12 16:34:38 --> Utf8 Class Initialized
INFO - 2021-07-12 16:34:38 --> Form Validation Class Initialized
INFO - 2021-07-12 16:34:38 --> Helper loaded: basic_helper
INFO - 2021-07-12 16:34:38 --> URI Class Initialized
INFO - 2021-07-12 16:34:38 --> Helper loaded: url_helper
INFO - 2021-07-12 16:34:38 --> Upload Class Initialized
INFO - 2021-07-12 16:34:38 --> Router Class Initialized
INFO - 2021-07-12 16:34:38 --> Helper loaded: file_helper
INFO - 2021-07-12 16:34:38 --> Output Class Initialized
INFO - 2021-07-12 16:34:38 --> Email Class Initialized
INFO - 2021-07-12 16:34:38 --> Helper loaded: form_helper
INFO - 2021-07-12 16:34:38 --> MY_Model class loaded
INFO - 2021-07-12 16:34:38 --> Security Class Initialized
INFO - 2021-07-12 16:34:38 --> Model "Users_model" initialized
INFO - 2021-07-12 16:34:38 --> Helper loaded: cookie_helper
DEBUG - 2021-07-12 16:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 16:34:38 --> Model "Settings_model" initialized
INFO - 2021-07-12 16:34:38 --> Input Class Initialized
INFO - 2021-07-12 16:34:38 --> Config Class Initialized
INFO - 2021-07-12 16:34:38 --> Helper loaded: security_helper
INFO - 2021-07-12 16:34:38 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 16:34:38 --> Hooks Class Initialized
INFO - 2021-07-12 16:34:38 --> Language Class Initialized
INFO - 2021-07-12 16:34:38 --> Model "Permissions_model" initialized
INFO - 2021-07-12 16:34:38 --> Helper loaded: directory_helper
DEBUG - 2021-07-12 16:34:38 --> UTF-8 Support Enabled
INFO - 2021-07-12 16:34:38 --> Model "Roles_model" initialized
INFO - 2021-07-12 16:34:38 --> Loader Class Initialized
INFO - 2021-07-12 16:34:38 --> Utf8 Class Initialized
INFO - 2021-07-12 16:34:38 --> Helper loaded: language_helper
INFO - 2021-07-12 16:34:38 --> Model "Activity_model" initialized
INFO - 2021-07-12 16:34:38 --> URI Class Initialized
INFO - 2021-07-12 16:34:38 --> Model "Templates_model" initialized
INFO - 2021-07-12 16:34:38 --> Helper loaded: general_helper
INFO - 2021-07-12 16:34:38 --> Helper loaded: basic_helper
INFO - 2021-07-12 16:34:38 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 16:34:38 --> Database Driver Class Initialized
INFO - 2021-07-12 16:34:38 --> Router Class Initialized
INFO - 2021-07-12 16:34:38 --> Helper loaded: url_helper
INFO - 2021-07-12 16:34:38 --> Database Driver Class Initialized
INFO - 2021-07-12 16:34:38 --> Config Class Initialized
INFO - 2021-07-12 16:34:38 --> Output Class Initialized
INFO - 2021-07-12 16:34:38 --> Helper loaded: file_helper
INFO - 2021-07-12 16:34:38 --> Hooks Class Initialized
INFO - 2021-07-12 16:34:38 --> Security Class Initialized
INFO - 2021-07-12 16:34:38 --> Helper loaded: form_helper
DEBUG - 2021-07-12 16:34:38 --> UTF-8 Support Enabled
DEBUG - 2021-07-12 16:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 16:34:38 --> Helper loaded: cookie_helper
INFO - 2021-07-12 16:34:38 --> Utf8 Class Initialized
INFO - 2021-07-12 16:34:38 --> Input Class Initialized
INFO - 2021-07-12 16:34:38 --> Helper loaded: security_helper
DEBUG - 2021-07-12 16:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 16:34:38 --> URI Class Initialized
INFO - 2021-07-12 16:34:38 --> Language Class Initialized
INFO - 2021-07-12 16:34:38 --> Helper loaded: directory_helper
INFO - 2021-07-12 16:34:38 --> Router Class Initialized
INFO - 2021-07-12 16:34:38 --> Loader Class Initialized
INFO - 2021-07-12 16:34:38 --> Helper loaded: language_helper
INFO - 2021-07-12 16:34:38 --> Output Class Initialized
INFO - 2021-07-12 16:34:38 --> Config Class Initialized
INFO - 2021-07-12 16:34:38 --> Helper loaded: general_helper
INFO - 2021-07-12 16:34:38 --> Helper loaded: basic_helper
INFO - 2021-07-12 16:34:38 --> Hooks Class Initialized
INFO - 2021-07-12 16:34:38 --> Security Class Initialized
INFO - 2021-07-12 16:34:38 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 16:34:38 --> Helper loaded: url_helper
DEBUG - 2021-07-12 16:34:38 --> UTF-8 Support Enabled
DEBUG - 2021-07-12 16:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 16:34:38 --> Helper loaded: file_helper
INFO - 2021-07-12 16:34:38 --> Utf8 Class Initialized
INFO - 2021-07-12 16:34:38 --> Database Driver Class Initialized
INFO - 2021-07-12 16:34:38 --> Input Class Initialized
INFO - 2021-07-12 16:34:38 --> Helper loaded: form_helper
INFO - 2021-07-12 16:34:38 --> URI Class Initialized
INFO - 2021-07-12 16:34:38 --> Language Class Initialized
INFO - 2021-07-12 16:34:38 --> Helper loaded: cookie_helper
INFO - 2021-07-12 16:34:38 --> Router Class Initialized
INFO - 2021-07-12 16:34:38 --> Loader Class Initialized
INFO - 2021-07-12 16:34:38 --> Helper loaded: security_helper
INFO - 2021-07-12 16:34:38 --> Output Class Initialized
INFO - 2021-07-12 16:34:38 --> Helper loaded: directory_helper
INFO - 2021-07-12 16:34:38 --> Helper loaded: basic_helper
DEBUG - 2021-07-12 16:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 16:34:38 --> Security Class Initialized
INFO - 2021-07-12 16:34:38 --> Helper loaded: language_helper
INFO - 2021-07-12 16:34:38 --> Helper loaded: url_helper
DEBUG - 2021-07-12 16:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 16:34:38 --> Helper loaded: general_helper
INFO - 2021-07-12 16:34:38 --> Input Class Initialized
INFO - 2021-07-12 16:34:38 --> Helper loaded: file_helper
INFO - 2021-07-12 16:34:38 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 16:34:38 --> Language Class Initialized
INFO - 2021-07-12 16:34:38 --> Helper loaded: form_helper
INFO - 2021-07-12 16:34:38 --> Database Driver Class Initialized
INFO - 2021-07-12 16:34:38 --> Loader Class Initialized
INFO - 2021-07-12 16:34:38 --> Helper loaded: cookie_helper
INFO - 2021-07-12 16:34:38 --> Helper loaded: basic_helper
INFO - 2021-07-12 16:34:38 --> Helper loaded: security_helper
INFO - 2021-07-12 16:34:38 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 16:34:38 --> Helper loaded: directory_helper
INFO - 2021-07-12 16:34:38 --> Helper loaded: url_helper
INFO - 2021-07-12 16:34:38 --> Controller Class Initialized
INFO - 2021-07-12 16:34:38 --> Helper loaded: language_helper
DEBUG - 2021-07-12 16:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 16:34:38 --> Helper loaded: file_helper
INFO - 2021-07-12 16:34:38 --> Helper loaded: general_helper
INFO - 2021-07-12 16:34:38 --> Helper loaded: form_helper
INFO - 2021-07-12 16:34:38 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 16:34:38 --> Helper loaded: cookie_helper
INFO - 2021-07-12 16:34:38 --> Final output sent to browser
INFO - 2021-07-12 16:34:38 --> Database Driver Class Initialized
INFO - 2021-07-12 16:34:38 --> Helper loaded: security_helper
DEBUG - 2021-07-12 16:34:38 --> Total execution time: 0.0509
INFO - 2021-07-12 16:34:38 --> Helper loaded: directory_helper
INFO - 2021-07-12 16:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 16:34:38 --> Helper loaded: language_helper
INFO - 2021-07-12 16:34:38 --> Parser Class Initialized
INFO - 2021-07-12 16:34:38 --> Helper loaded: general_helper
DEBUG - 2021-07-12 16:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 16:34:38 --> Form Validation Class Initialized
INFO - 2021-07-12 16:34:38 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 16:34:38 --> Database Driver Class Initialized
INFO - 2021-07-12 16:34:38 --> Upload Class Initialized
INFO - 2021-07-12 16:34:38 --> Email Class Initialized
INFO - 2021-07-12 16:34:38 --> MY_Model class loaded
INFO - 2021-07-12 16:34:38 --> Model "Users_model" initialized
INFO - 2021-07-12 16:34:38 --> Model "Settings_model" initialized
DEBUG - 2021-07-12 16:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 16:34:38 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 16:34:38 --> Model "Permissions_model" initialized
INFO - 2021-07-12 16:34:38 --> Model "Roles_model" initialized
INFO - 2021-07-12 16:34:38 --> Model "Activity_model" initialized
INFO - 2021-07-12 16:34:38 --> Model "Templates_model" initialized
INFO - 2021-07-12 16:34:38 --> Database Driver Class Initialized
INFO - 2021-07-12 16:34:38 --> Config Class Initialized
INFO - 2021-07-12 16:34:38 --> Hooks Class Initialized
DEBUG - 2021-07-12 16:34:38 --> UTF-8 Support Enabled
INFO - 2021-07-12 16:34:38 --> Utf8 Class Initialized
INFO - 2021-07-12 16:34:38 --> URI Class Initialized
INFO - 2021-07-12 16:34:38 --> Router Class Initialized
INFO - 2021-07-12 16:34:38 --> Output Class Initialized
INFO - 2021-07-12 16:34:38 --> Security Class Initialized
DEBUG - 2021-07-12 16:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 16:34:38 --> Input Class Initialized
INFO - 2021-07-12 16:34:38 --> Language Class Initialized
INFO - 2021-07-12 16:34:38 --> Loader Class Initialized
INFO - 2021-07-12 16:34:38 --> Helper loaded: basic_helper
INFO - 2021-07-12 16:34:38 --> Helper loaded: url_helper
INFO - 2021-07-12 16:34:38 --> Helper loaded: file_helper
INFO - 2021-07-12 16:34:38 --> Helper loaded: form_helper
INFO - 2021-07-12 16:34:38 --> Helper loaded: cookie_helper
INFO - 2021-07-12 16:34:38 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 16:34:38 --> Helper loaded: security_helper
INFO - 2021-07-12 16:34:38 --> Controller Class Initialized
INFO - 2021-07-12 16:34:38 --> Helper loaded: directory_helper
INFO - 2021-07-12 16:34:38 --> Helper loaded: language_helper
INFO - 2021-07-12 16:34:38 --> Helper loaded: general_helper
INFO - 2021-07-12 16:34:38 --> Final output sent to browser
INFO - 2021-07-12 16:34:38 --> Language file loaded: language/en/basic_lang.php
DEBUG - 2021-07-12 16:34:38 --> Total execution time: 0.0705
INFO - 2021-07-12 16:34:38 --> Database Driver Class Initialized
INFO - 2021-07-12 16:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 16:34:38 --> Parser Class Initialized
INFO - 2021-07-12 16:34:38 --> Form Validation Class Initialized
DEBUG - 2021-07-12 16:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 16:34:38 --> Upload Class Initialized
INFO - 2021-07-12 16:34:38 --> Email Class Initialized
INFO - 2021-07-12 16:34:38 --> MY_Model class loaded
INFO - 2021-07-12 16:34:38 --> Model "Users_model" initialized
INFO - 2021-07-12 16:34:38 --> Model "Settings_model" initialized
INFO - 2021-07-12 16:34:38 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 16:34:38 --> Model "Permissions_model" initialized
INFO - 2021-07-12 16:34:38 --> Model "Roles_model" initialized
INFO - 2021-07-12 16:34:38 --> Model "Activity_model" initialized
INFO - 2021-07-12 16:34:38 --> Model "Templates_model" initialized
INFO - 2021-07-12 16:34:38 --> Database Driver Class Initialized
INFO - 2021-07-12 16:34:38 --> Config Class Initialized
INFO - 2021-07-12 16:34:38 --> Hooks Class Initialized
DEBUG - 2021-07-12 16:34:38 --> UTF-8 Support Enabled
INFO - 2021-07-12 16:34:38 --> Utf8 Class Initialized
INFO - 2021-07-12 16:34:38 --> URI Class Initialized
INFO - 2021-07-12 16:34:38 --> Router Class Initialized
INFO - 2021-07-12 16:34:38 --> Output Class Initialized
INFO - 2021-07-12 16:34:38 --> Security Class Initialized
DEBUG - 2021-07-12 16:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 16:34:38 --> Input Class Initialized
INFO - 2021-07-12 16:34:38 --> Language Class Initialized
INFO - 2021-07-12 16:34:38 --> Loader Class Initialized
INFO - 2021-07-12 16:34:38 --> Helper loaded: basic_helper
INFO - 2021-07-12 16:34:38 --> Helper loaded: url_helper
INFO - 2021-07-12 16:34:38 --> Helper loaded: file_helper
INFO - 2021-07-12 16:34:38 --> Helper loaded: form_helper
INFO - 2021-07-12 16:34:38 --> Helper loaded: cookie_helper
INFO - 2021-07-12 16:34:38 --> Helper loaded: security_helper
INFO - 2021-07-12 16:34:38 --> Helper loaded: directory_helper
INFO - 2021-07-12 16:34:38 --> Helper loaded: language_helper
INFO - 2021-07-12 16:34:38 --> Helper loaded: general_helper
INFO - 2021-07-12 16:34:38 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 16:34:38 --> Database Driver Class Initialized
INFO - 2021-07-12 16:34:38 --> Model "Hesaplar_model" initialized
DEBUG - 2021-07-12 16:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 16:34:38 --> Controller Class Initialized
INFO - 2021-07-12 16:34:38 --> Final output sent to browser
DEBUG - 2021-07-12 16:34:38 --> Total execution time: 0.0939
INFO - 2021-07-12 16:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 16:34:38 --> Parser Class Initialized
INFO - 2021-07-12 16:34:38 --> Form Validation Class Initialized
INFO - 2021-07-12 16:34:38 --> Upload Class Initialized
INFO - 2021-07-12 16:34:38 --> Email Class Initialized
INFO - 2021-07-12 16:34:38 --> MY_Model class loaded
INFO - 2021-07-12 16:34:38 --> Model "Users_model" initialized
INFO - 2021-07-12 16:34:38 --> Model "Settings_model" initialized
INFO - 2021-07-12 16:34:38 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 16:34:38 --> Model "Permissions_model" initialized
INFO - 2021-07-12 16:34:38 --> Model "Roles_model" initialized
INFO - 2021-07-12 16:34:38 --> Model "Activity_model" initialized
INFO - 2021-07-12 16:34:38 --> Model "Templates_model" initialized
INFO - 2021-07-12 16:34:38 --> Database Driver Class Initialized
INFO - 2021-07-12 16:34:38 --> Config Class Initialized
INFO - 2021-07-12 16:34:38 --> Hooks Class Initialized
DEBUG - 2021-07-12 16:34:38 --> UTF-8 Support Enabled
INFO - 2021-07-12 16:34:38 --> Utf8 Class Initialized
INFO - 2021-07-12 16:34:38 --> URI Class Initialized
INFO - 2021-07-12 16:34:38 --> Router Class Initialized
INFO - 2021-07-12 16:34:38 --> Output Class Initialized
INFO - 2021-07-12 16:34:38 --> Security Class Initialized
DEBUG - 2021-07-12 16:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 16:34:38 --> Input Class Initialized
INFO - 2021-07-12 16:34:38 --> Language Class Initialized
INFO - 2021-07-12 16:34:38 --> Loader Class Initialized
INFO - 2021-07-12 16:34:38 --> Helper loaded: basic_helper
INFO - 2021-07-12 16:34:38 --> Helper loaded: url_helper
INFO - 2021-07-12 16:34:38 --> Helper loaded: file_helper
INFO - 2021-07-12 16:34:38 --> Helper loaded: form_helper
INFO - 2021-07-12 16:34:38 --> Helper loaded: cookie_helper
INFO - 2021-07-12 16:34:38 --> Helper loaded: security_helper
INFO - 2021-07-12 16:34:38 --> Helper loaded: directory_helper
INFO - 2021-07-12 16:34:38 --> Helper loaded: language_helper
INFO - 2021-07-12 16:34:38 --> Helper loaded: general_helper
INFO - 2021-07-12 16:34:38 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 16:34:38 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 16:34:38 --> Database Driver Class Initialized
INFO - 2021-07-12 16:34:38 --> Controller Class Initialized
INFO - 2021-07-12 16:34:38 --> Final output sent to browser
DEBUG - 2021-07-12 16:34:38 --> Total execution time: 0.1163
INFO - 2021-07-12 16:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 16:34:38 --> Parser Class Initialized
INFO - 2021-07-12 16:34:38 --> Form Validation Class Initialized
INFO - 2021-07-12 16:34:38 --> Upload Class Initialized
INFO - 2021-07-12 16:34:38 --> Email Class Initialized
INFO - 2021-07-12 16:34:38 --> MY_Model class loaded
INFO - 2021-07-12 16:34:38 --> Model "Users_model" initialized
INFO - 2021-07-12 16:34:38 --> Model "Settings_model" initialized
INFO - 2021-07-12 16:34:38 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 16:34:38 --> Model "Permissions_model" initialized
INFO - 2021-07-12 16:34:38 --> Model "Roles_model" initialized
INFO - 2021-07-12 16:34:38 --> Model "Activity_model" initialized
INFO - 2021-07-12 16:34:38 --> Model "Templates_model" initialized
INFO - 2021-07-12 16:34:38 --> Database Driver Class Initialized
DEBUG - 2021-07-12 16:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 16:34:38 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 16:34:38 --> Controller Class Initialized
INFO - 2021-07-12 16:34:38 --> Final output sent to browser
DEBUG - 2021-07-12 16:34:38 --> Total execution time: 0.1402
INFO - 2021-07-12 16:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 16:34:38 --> Parser Class Initialized
INFO - 2021-07-12 16:34:38 --> Form Validation Class Initialized
INFO - 2021-07-12 16:34:38 --> Upload Class Initialized
INFO - 2021-07-12 16:34:38 --> Email Class Initialized
INFO - 2021-07-12 16:34:38 --> MY_Model class loaded
INFO - 2021-07-12 16:34:38 --> Model "Users_model" initialized
INFO - 2021-07-12 16:34:38 --> Model "Settings_model" initialized
INFO - 2021-07-12 16:34:38 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 16:34:38 --> Model "Permissions_model" initialized
INFO - 2021-07-12 16:34:38 --> Model "Roles_model" initialized
INFO - 2021-07-12 16:34:38 --> Model "Activity_model" initialized
INFO - 2021-07-12 16:34:38 --> Model "Templates_model" initialized
INFO - 2021-07-12 16:34:38 --> Database Driver Class Initialized
INFO - 2021-07-12 16:34:38 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 16:34:38 --> Controller Class Initialized
INFO - 2021-07-12 16:34:38 --> Final output sent to browser
DEBUG - 2021-07-12 16:34:38 --> Total execution time: 0.1657
INFO - 2021-07-12 16:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 16:34:38 --> Parser Class Initialized
INFO - 2021-07-12 16:34:38 --> Form Validation Class Initialized
INFO - 2021-07-12 16:34:38 --> Upload Class Initialized
INFO - 2021-07-12 16:34:38 --> Email Class Initialized
INFO - 2021-07-12 16:34:38 --> MY_Model class loaded
INFO - 2021-07-12 16:34:38 --> Model "Users_model" initialized
INFO - 2021-07-12 16:34:38 --> Model "Settings_model" initialized
INFO - 2021-07-12 16:34:38 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 16:34:38 --> Model "Permissions_model" initialized
INFO - 2021-07-12 16:34:38 --> Model "Roles_model" initialized
INFO - 2021-07-12 16:34:38 --> Model "Activity_model" initialized
INFO - 2021-07-12 16:34:38 --> Model "Templates_model" initialized
INFO - 2021-07-12 16:34:38 --> Database Driver Class Initialized
INFO - 2021-07-12 16:34:38 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 16:34:38 --> Controller Class Initialized
INFO - 2021-07-12 16:34:38 --> Final output sent to browser
DEBUG - 2021-07-12 16:34:38 --> Total execution time: 0.1613
INFO - 2021-07-12 16:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 16:34:38 --> Parser Class Initialized
INFO - 2021-07-12 16:34:38 --> Form Validation Class Initialized
INFO - 2021-07-12 16:34:38 --> Upload Class Initialized
INFO - 2021-07-12 16:34:38 --> Email Class Initialized
INFO - 2021-07-12 16:34:38 --> MY_Model class loaded
INFO - 2021-07-12 16:34:38 --> Model "Users_model" initialized
INFO - 2021-07-12 16:34:38 --> Model "Settings_model" initialized
INFO - 2021-07-12 16:34:38 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 16:34:38 --> Model "Permissions_model" initialized
INFO - 2021-07-12 16:34:38 --> Model "Roles_model" initialized
INFO - 2021-07-12 16:34:38 --> Model "Activity_model" initialized
INFO - 2021-07-12 16:34:38 --> Model "Templates_model" initialized
INFO - 2021-07-12 16:34:38 --> Database Driver Class Initialized
INFO - 2021-07-12 16:34:38 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 16:34:38 --> Controller Class Initialized
INFO - 2021-07-12 16:34:38 --> Final output sent to browser
DEBUG - 2021-07-12 16:34:38 --> Total execution time: 0.1656
INFO - 2021-07-12 16:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 16:34:38 --> Parser Class Initialized
INFO - 2021-07-12 16:34:38 --> Form Validation Class Initialized
INFO - 2021-07-12 16:34:38 --> Upload Class Initialized
INFO - 2021-07-12 16:34:38 --> Email Class Initialized
INFO - 2021-07-12 16:34:38 --> MY_Model class loaded
INFO - 2021-07-12 16:34:38 --> Model "Users_model" initialized
INFO - 2021-07-12 16:34:38 --> Model "Settings_model" initialized
INFO - 2021-07-12 16:34:38 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 16:34:38 --> Model "Permissions_model" initialized
INFO - 2021-07-12 16:34:38 --> Model "Roles_model" initialized
INFO - 2021-07-12 16:34:38 --> Model "Activity_model" initialized
INFO - 2021-07-12 16:34:38 --> Model "Templates_model" initialized
INFO - 2021-07-12 16:34:38 --> Database Driver Class Initialized
INFO - 2021-07-12 16:34:38 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 16:34:38 --> Controller Class Initialized
INFO - 2021-07-12 16:34:38 --> Final output sent to browser
DEBUG - 2021-07-12 16:34:38 --> Total execution time: 0.1612
INFO - 2021-07-12 16:36:03 --> Config Class Initialized
INFO - 2021-07-12 16:36:03 --> Hooks Class Initialized
DEBUG - 2021-07-12 16:36:03 --> UTF-8 Support Enabled
INFO - 2021-07-12 16:36:03 --> Utf8 Class Initialized
INFO - 2021-07-12 16:36:03 --> URI Class Initialized
INFO - 2021-07-12 16:36:03 --> Router Class Initialized
INFO - 2021-07-12 16:36:03 --> Output Class Initialized
INFO - 2021-07-12 16:36:03 --> Security Class Initialized
DEBUG - 2021-07-12 16:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 16:36:03 --> Input Class Initialized
INFO - 2021-07-12 16:36:03 --> Language Class Initialized
INFO - 2021-07-12 16:36:03 --> Loader Class Initialized
INFO - 2021-07-12 16:36:03 --> Helper loaded: basic_helper
INFO - 2021-07-12 16:36:03 --> Helper loaded: url_helper
INFO - 2021-07-12 16:36:03 --> Helper loaded: file_helper
INFO - 2021-07-12 16:36:03 --> Helper loaded: form_helper
INFO - 2021-07-12 16:36:03 --> Helper loaded: cookie_helper
INFO - 2021-07-12 16:36:03 --> Helper loaded: security_helper
INFO - 2021-07-12 16:36:03 --> Helper loaded: directory_helper
INFO - 2021-07-12 16:36:03 --> Helper loaded: language_helper
INFO - 2021-07-12 16:36:03 --> Helper loaded: general_helper
INFO - 2021-07-12 16:36:03 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 16:36:03 --> Database Driver Class Initialized
DEBUG - 2021-07-12 16:36:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 16:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 16:36:03 --> Parser Class Initialized
INFO - 2021-07-12 16:36:03 --> Form Validation Class Initialized
INFO - 2021-07-12 16:36:03 --> Upload Class Initialized
INFO - 2021-07-12 16:36:03 --> Email Class Initialized
INFO - 2021-07-12 16:36:03 --> MY_Model class loaded
INFO - 2021-07-12 16:36:03 --> Model "Users_model" initialized
INFO - 2021-07-12 16:36:03 --> Model "Settings_model" initialized
INFO - 2021-07-12 16:36:03 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 16:36:03 --> Model "Permissions_model" initialized
INFO - 2021-07-12 16:36:03 --> Model "Roles_model" initialized
INFO - 2021-07-12 16:36:03 --> Model "Activity_model" initialized
INFO - 2021-07-12 16:36:03 --> Model "Templates_model" initialized
INFO - 2021-07-12 16:36:03 --> Database Driver Class Initialized
INFO - 2021-07-12 16:36:04 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 16:36:04 --> Controller Class Initialized
ERROR - 2021-07-12 16:36:04 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 16:36:04 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-12 16:36:04 --> Final output sent to browser
DEBUG - 2021-07-12 16:36:04 --> Total execution time: 0.6454
INFO - 2021-07-12 16:37:33 --> Config Class Initialized
INFO - 2021-07-12 16:37:33 --> Hooks Class Initialized
DEBUG - 2021-07-12 16:37:33 --> UTF-8 Support Enabled
INFO - 2021-07-12 16:37:33 --> Utf8 Class Initialized
INFO - 2021-07-12 16:37:33 --> URI Class Initialized
INFO - 2021-07-12 16:37:33 --> Router Class Initialized
INFO - 2021-07-12 16:37:33 --> Output Class Initialized
INFO - 2021-07-12 16:37:33 --> Security Class Initialized
DEBUG - 2021-07-12 16:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 16:37:33 --> Input Class Initialized
INFO - 2021-07-12 16:37:33 --> Language Class Initialized
INFO - 2021-07-12 16:37:33 --> Loader Class Initialized
INFO - 2021-07-12 16:37:33 --> Helper loaded: basic_helper
INFO - 2021-07-12 16:37:33 --> Helper loaded: url_helper
INFO - 2021-07-12 16:37:33 --> Helper loaded: file_helper
INFO - 2021-07-12 16:37:33 --> Helper loaded: form_helper
INFO - 2021-07-12 16:37:33 --> Helper loaded: cookie_helper
INFO - 2021-07-12 16:37:33 --> Helper loaded: security_helper
INFO - 2021-07-12 16:37:33 --> Helper loaded: directory_helper
INFO - 2021-07-12 16:37:33 --> Helper loaded: language_helper
INFO - 2021-07-12 16:37:33 --> Helper loaded: general_helper
INFO - 2021-07-12 16:37:33 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 16:37:33 --> Database Driver Class Initialized
DEBUG - 2021-07-12 16:37:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 16:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 16:37:33 --> Parser Class Initialized
INFO - 2021-07-12 16:37:33 --> Form Validation Class Initialized
INFO - 2021-07-12 16:37:33 --> Upload Class Initialized
INFO - 2021-07-12 16:37:33 --> Email Class Initialized
INFO - 2021-07-12 16:37:33 --> MY_Model class loaded
INFO - 2021-07-12 16:37:33 --> Model "Users_model" initialized
INFO - 2021-07-12 16:37:33 --> Model "Settings_model" initialized
INFO - 2021-07-12 16:37:33 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 16:37:33 --> Model "Permissions_model" initialized
INFO - 2021-07-12 16:37:33 --> Model "Roles_model" initialized
INFO - 2021-07-12 16:37:33 --> Model "Activity_model" initialized
INFO - 2021-07-12 16:37:33 --> Model "Templates_model" initialized
INFO - 2021-07-12 16:37:33 --> Database Driver Class Initialized
INFO - 2021-07-12 16:37:33 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 16:37:33 --> Controller Class Initialized
ERROR - 2021-07-12 16:37:33 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 16:37:33 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-12 16:37:33 --> Final output sent to browser
DEBUG - 2021-07-12 16:37:33 --> Total execution time: 0.5663
INFO - 2021-07-12 16:37:40 --> Config Class Initialized
INFO - 2021-07-12 16:37:40 --> Hooks Class Initialized
DEBUG - 2021-07-12 16:37:40 --> UTF-8 Support Enabled
INFO - 2021-07-12 16:37:40 --> Utf8 Class Initialized
INFO - 2021-07-12 16:37:40 --> URI Class Initialized
INFO - 2021-07-12 16:37:40 --> Router Class Initialized
INFO - 2021-07-12 16:37:40 --> Output Class Initialized
INFO - 2021-07-12 16:37:40 --> Security Class Initialized
DEBUG - 2021-07-12 16:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 16:37:40 --> Input Class Initialized
INFO - 2021-07-12 16:37:40 --> Language Class Initialized
INFO - 2021-07-12 16:37:40 --> Loader Class Initialized
INFO - 2021-07-12 16:37:40 --> Helper loaded: basic_helper
INFO - 2021-07-12 16:37:40 --> Helper loaded: url_helper
INFO - 2021-07-12 16:37:40 --> Helper loaded: file_helper
INFO - 2021-07-12 16:37:40 --> Helper loaded: form_helper
INFO - 2021-07-12 16:37:40 --> Helper loaded: cookie_helper
INFO - 2021-07-12 16:37:40 --> Helper loaded: security_helper
INFO - 2021-07-12 16:37:40 --> Helper loaded: directory_helper
INFO - 2021-07-12 16:37:40 --> Helper loaded: language_helper
INFO - 2021-07-12 16:37:40 --> Helper loaded: general_helper
INFO - 2021-07-12 16:37:40 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 16:37:40 --> Database Driver Class Initialized
DEBUG - 2021-07-12 16:37:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 16:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 16:37:40 --> Parser Class Initialized
INFO - 2021-07-12 16:37:40 --> Form Validation Class Initialized
INFO - 2021-07-12 16:37:40 --> Upload Class Initialized
INFO - 2021-07-12 16:37:40 --> Email Class Initialized
INFO - 2021-07-12 16:37:40 --> MY_Model class loaded
INFO - 2021-07-12 16:37:40 --> Model "Users_model" initialized
INFO - 2021-07-12 16:37:40 --> Model "Settings_model" initialized
INFO - 2021-07-12 16:37:40 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 16:37:40 --> Model "Permissions_model" initialized
INFO - 2021-07-12 16:37:40 --> Model "Roles_model" initialized
INFO - 2021-07-12 16:37:40 --> Model "Activity_model" initialized
INFO - 2021-07-12 16:37:40 --> Model "Templates_model" initialized
INFO - 2021-07-12 16:37:40 --> Database Driver Class Initialized
INFO - 2021-07-12 16:37:40 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 16:37:40 --> Controller Class Initialized
ERROR - 2021-07-12 16:37:40 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 16:37:41 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-12 16:37:41 --> Final output sent to browser
DEBUG - 2021-07-12 16:37:41 --> Total execution time: 0.2823
INFO - 2021-07-12 16:37:47 --> Config Class Initialized
INFO - 2021-07-12 16:37:47 --> Hooks Class Initialized
DEBUG - 2021-07-12 16:37:47 --> UTF-8 Support Enabled
INFO - 2021-07-12 16:37:47 --> Utf8 Class Initialized
INFO - 2021-07-12 16:37:47 --> URI Class Initialized
INFO - 2021-07-12 16:37:47 --> Router Class Initialized
INFO - 2021-07-12 16:37:47 --> Output Class Initialized
INFO - 2021-07-12 16:37:47 --> Security Class Initialized
DEBUG - 2021-07-12 16:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 16:37:47 --> Input Class Initialized
INFO - 2021-07-12 16:37:47 --> Language Class Initialized
INFO - 2021-07-12 16:37:47 --> Loader Class Initialized
INFO - 2021-07-12 16:37:47 --> Helper loaded: basic_helper
INFO - 2021-07-12 16:37:47 --> Helper loaded: url_helper
INFO - 2021-07-12 16:37:47 --> Helper loaded: file_helper
INFO - 2021-07-12 16:37:47 --> Helper loaded: form_helper
INFO - 2021-07-12 16:37:47 --> Helper loaded: cookie_helper
INFO - 2021-07-12 16:37:47 --> Helper loaded: security_helper
INFO - 2021-07-12 16:37:47 --> Helper loaded: directory_helper
INFO - 2021-07-12 16:37:47 --> Helper loaded: language_helper
INFO - 2021-07-12 16:37:47 --> Helper loaded: general_helper
INFO - 2021-07-12 16:37:47 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 16:37:47 --> Database Driver Class Initialized
DEBUG - 2021-07-12 16:37:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 16:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 16:37:47 --> Parser Class Initialized
INFO - 2021-07-12 16:37:47 --> Form Validation Class Initialized
INFO - 2021-07-12 16:37:47 --> Upload Class Initialized
INFO - 2021-07-12 16:37:47 --> Email Class Initialized
INFO - 2021-07-12 16:37:47 --> MY_Model class loaded
INFO - 2021-07-12 16:37:47 --> Model "Users_model" initialized
INFO - 2021-07-12 16:37:47 --> Model "Settings_model" initialized
INFO - 2021-07-12 16:37:47 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 16:37:47 --> Model "Permissions_model" initialized
INFO - 2021-07-12 16:37:47 --> Model "Roles_model" initialized
INFO - 2021-07-12 16:37:47 --> Model "Activity_model" initialized
INFO - 2021-07-12 16:37:47 --> Model "Templates_model" initialized
INFO - 2021-07-12 16:37:47 --> Database Driver Class Initialized
INFO - 2021-07-12 16:37:47 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 16:37:47 --> Controller Class Initialized
ERROR - 2021-07-12 16:37:47 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 16:37:47 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-12 16:37:47 --> Final output sent to browser
DEBUG - 2021-07-12 16:37:47 --> Total execution time: 0.1407
INFO - 2021-07-12 16:37:50 --> Config Class Initialized
INFO - 2021-07-12 16:37:50 --> Hooks Class Initialized
DEBUG - 2021-07-12 16:37:50 --> UTF-8 Support Enabled
INFO - 2021-07-12 16:37:50 --> Utf8 Class Initialized
INFO - 2021-07-12 16:37:50 --> URI Class Initialized
INFO - 2021-07-12 16:37:50 --> Router Class Initialized
INFO - 2021-07-12 16:37:50 --> Output Class Initialized
INFO - 2021-07-12 16:37:50 --> Security Class Initialized
DEBUG - 2021-07-12 16:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 16:37:50 --> Input Class Initialized
INFO - 2021-07-12 16:37:50 --> Language Class Initialized
INFO - 2021-07-12 16:37:50 --> Loader Class Initialized
INFO - 2021-07-12 16:37:50 --> Helper loaded: basic_helper
INFO - 2021-07-12 16:37:50 --> Helper loaded: url_helper
INFO - 2021-07-12 16:37:50 --> Helper loaded: file_helper
INFO - 2021-07-12 16:37:50 --> Helper loaded: form_helper
INFO - 2021-07-12 16:37:50 --> Helper loaded: cookie_helper
INFO - 2021-07-12 16:37:50 --> Helper loaded: security_helper
INFO - 2021-07-12 16:37:50 --> Helper loaded: directory_helper
INFO - 2021-07-12 16:37:50 --> Helper loaded: language_helper
INFO - 2021-07-12 16:37:50 --> Helper loaded: general_helper
INFO - 2021-07-12 16:37:50 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 16:37:50 --> Database Driver Class Initialized
DEBUG - 2021-07-12 16:37:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 16:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 16:37:50 --> Parser Class Initialized
INFO - 2021-07-12 16:37:50 --> Form Validation Class Initialized
INFO - 2021-07-12 16:37:50 --> Upload Class Initialized
INFO - 2021-07-12 16:37:50 --> Email Class Initialized
INFO - 2021-07-12 16:37:50 --> MY_Model class loaded
INFO - 2021-07-12 16:37:50 --> Model "Users_model" initialized
INFO - 2021-07-12 16:37:50 --> Model "Settings_model" initialized
INFO - 2021-07-12 16:37:50 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 16:37:50 --> Model "Permissions_model" initialized
INFO - 2021-07-12 16:37:50 --> Model "Roles_model" initialized
INFO - 2021-07-12 16:37:50 --> Model "Activity_model" initialized
INFO - 2021-07-12 16:37:50 --> Model "Templates_model" initialized
INFO - 2021-07-12 16:37:50 --> Database Driver Class Initialized
INFO - 2021-07-12 16:37:50 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 16:37:50 --> Controller Class Initialized
ERROR - 2021-07-12 16:37:50 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 16:37:50 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-12 16:37:50 --> Final output sent to browser
DEBUG - 2021-07-12 16:37:50 --> Total execution time: 0.1877
INFO - 2021-07-12 16:38:08 --> Config Class Initialized
INFO - 2021-07-12 16:38:08 --> Hooks Class Initialized
DEBUG - 2021-07-12 16:38:08 --> UTF-8 Support Enabled
INFO - 2021-07-12 16:38:08 --> Utf8 Class Initialized
INFO - 2021-07-12 16:38:08 --> URI Class Initialized
INFO - 2021-07-12 16:38:08 --> Router Class Initialized
INFO - 2021-07-12 16:38:08 --> Output Class Initialized
INFO - 2021-07-12 16:38:08 --> Security Class Initialized
DEBUG - 2021-07-12 16:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 16:38:08 --> Input Class Initialized
INFO - 2021-07-12 16:38:08 --> Language Class Initialized
INFO - 2021-07-12 16:38:08 --> Loader Class Initialized
INFO - 2021-07-12 16:38:08 --> Helper loaded: basic_helper
INFO - 2021-07-12 16:38:08 --> Helper loaded: url_helper
INFO - 2021-07-12 16:38:08 --> Helper loaded: file_helper
INFO - 2021-07-12 16:38:08 --> Helper loaded: form_helper
INFO - 2021-07-12 16:38:08 --> Helper loaded: cookie_helper
INFO - 2021-07-12 16:38:08 --> Helper loaded: security_helper
INFO - 2021-07-12 16:38:08 --> Helper loaded: directory_helper
INFO - 2021-07-12 16:38:08 --> Helper loaded: language_helper
INFO - 2021-07-12 16:38:08 --> Helper loaded: general_helper
INFO - 2021-07-12 16:38:08 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 16:38:08 --> Database Driver Class Initialized
DEBUG - 2021-07-12 16:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 16:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 16:38:08 --> Parser Class Initialized
INFO - 2021-07-12 16:38:08 --> Form Validation Class Initialized
INFO - 2021-07-12 16:38:08 --> Upload Class Initialized
INFO - 2021-07-12 16:38:08 --> Email Class Initialized
INFO - 2021-07-12 16:38:08 --> MY_Model class loaded
INFO - 2021-07-12 16:38:08 --> Model "Users_model" initialized
INFO - 2021-07-12 16:38:08 --> Model "Settings_model" initialized
INFO - 2021-07-12 16:38:08 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 16:38:08 --> Model "Permissions_model" initialized
INFO - 2021-07-12 16:38:08 --> Model "Roles_model" initialized
INFO - 2021-07-12 16:38:08 --> Model "Activity_model" initialized
INFO - 2021-07-12 16:38:08 --> Model "Templates_model" initialized
INFO - 2021-07-12 16:38:08 --> Database Driver Class Initialized
INFO - 2021-07-12 16:38:08 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 16:38:08 --> Controller Class Initialized
ERROR - 2021-07-12 16:38:08 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 16:38:08 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-12 16:38:08 --> Final output sent to browser
DEBUG - 2021-07-12 16:38:08 --> Total execution time: 0.1377
INFO - 2021-07-12 16:38:11 --> Config Class Initialized
INFO - 2021-07-12 16:38:11 --> Hooks Class Initialized
DEBUG - 2021-07-12 16:38:11 --> UTF-8 Support Enabled
INFO - 2021-07-12 16:38:11 --> Utf8 Class Initialized
INFO - 2021-07-12 16:38:11 --> URI Class Initialized
INFO - 2021-07-12 16:38:11 --> Router Class Initialized
INFO - 2021-07-12 16:38:11 --> Output Class Initialized
INFO - 2021-07-12 16:38:11 --> Security Class Initialized
DEBUG - 2021-07-12 16:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 16:38:11 --> Input Class Initialized
INFO - 2021-07-12 16:38:11 --> Language Class Initialized
INFO - 2021-07-12 16:38:11 --> Loader Class Initialized
INFO - 2021-07-12 16:38:11 --> Helper loaded: basic_helper
INFO - 2021-07-12 16:38:11 --> Helper loaded: url_helper
INFO - 2021-07-12 16:38:11 --> Helper loaded: file_helper
INFO - 2021-07-12 16:38:11 --> Helper loaded: form_helper
INFO - 2021-07-12 16:38:11 --> Helper loaded: cookie_helper
INFO - 2021-07-12 16:38:11 --> Helper loaded: security_helper
INFO - 2021-07-12 16:38:11 --> Helper loaded: directory_helper
INFO - 2021-07-12 16:38:11 --> Helper loaded: language_helper
INFO - 2021-07-12 16:38:11 --> Helper loaded: general_helper
INFO - 2021-07-12 16:38:11 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 16:38:11 --> Database Driver Class Initialized
DEBUG - 2021-07-12 16:38:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 16:38:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 16:38:11 --> Parser Class Initialized
INFO - 2021-07-12 16:38:11 --> Form Validation Class Initialized
INFO - 2021-07-12 16:38:11 --> Upload Class Initialized
INFO - 2021-07-12 16:38:11 --> Email Class Initialized
INFO - 2021-07-12 16:38:11 --> MY_Model class loaded
INFO - 2021-07-12 16:38:11 --> Model "Users_model" initialized
INFO - 2021-07-12 16:38:11 --> Model "Settings_model" initialized
INFO - 2021-07-12 16:38:11 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 16:38:11 --> Model "Permissions_model" initialized
INFO - 2021-07-12 16:38:11 --> Model "Roles_model" initialized
INFO - 2021-07-12 16:38:11 --> Model "Activity_model" initialized
INFO - 2021-07-12 16:38:11 --> Model "Templates_model" initialized
INFO - 2021-07-12 16:38:11 --> Database Driver Class Initialized
INFO - 2021-07-12 16:38:11 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 16:38:11 --> Controller Class Initialized
ERROR - 2021-07-12 16:38:11 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 16:38:12 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-12 16:38:12 --> Final output sent to browser
DEBUG - 2021-07-12 16:38:12 --> Total execution time: 0.3919
INFO - 2021-07-12 16:38:24 --> Config Class Initialized
INFO - 2021-07-12 16:38:24 --> Hooks Class Initialized
DEBUG - 2021-07-12 16:38:24 --> UTF-8 Support Enabled
INFO - 2021-07-12 16:38:24 --> Utf8 Class Initialized
INFO - 2021-07-12 16:38:24 --> URI Class Initialized
INFO - 2021-07-12 16:38:24 --> Router Class Initialized
INFO - 2021-07-12 16:38:24 --> Output Class Initialized
INFO - 2021-07-12 16:38:24 --> Security Class Initialized
DEBUG - 2021-07-12 16:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 16:38:24 --> Input Class Initialized
INFO - 2021-07-12 16:38:24 --> Language Class Initialized
INFO - 2021-07-12 16:38:24 --> Loader Class Initialized
INFO - 2021-07-12 16:38:24 --> Helper loaded: basic_helper
INFO - 2021-07-12 16:38:24 --> Helper loaded: url_helper
INFO - 2021-07-12 16:38:24 --> Helper loaded: file_helper
INFO - 2021-07-12 16:38:24 --> Helper loaded: form_helper
INFO - 2021-07-12 16:38:24 --> Helper loaded: cookie_helper
INFO - 2021-07-12 16:38:24 --> Helper loaded: security_helper
INFO - 2021-07-12 16:38:24 --> Helper loaded: directory_helper
INFO - 2021-07-12 16:38:24 --> Helper loaded: language_helper
INFO - 2021-07-12 16:38:24 --> Helper loaded: general_helper
INFO - 2021-07-12 16:38:24 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 16:38:24 --> Database Driver Class Initialized
DEBUG - 2021-07-12 16:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 16:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 16:38:24 --> Parser Class Initialized
INFO - 2021-07-12 16:38:24 --> Form Validation Class Initialized
INFO - 2021-07-12 16:38:24 --> Upload Class Initialized
INFO - 2021-07-12 16:38:24 --> Email Class Initialized
INFO - 2021-07-12 16:38:24 --> MY_Model class loaded
INFO - 2021-07-12 16:38:24 --> Model "Users_model" initialized
INFO - 2021-07-12 16:38:24 --> Model "Settings_model" initialized
INFO - 2021-07-12 16:38:24 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 16:38:24 --> Model "Permissions_model" initialized
INFO - 2021-07-12 16:38:24 --> Model "Roles_model" initialized
INFO - 2021-07-12 16:38:24 --> Model "Activity_model" initialized
INFO - 2021-07-12 16:38:24 --> Model "Templates_model" initialized
INFO - 2021-07-12 16:38:24 --> Database Driver Class Initialized
INFO - 2021-07-12 16:38:24 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 16:38:24 --> Controller Class Initialized
ERROR - 2021-07-12 16:38:24 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 16:38:24 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-12 16:38:24 --> Final output sent to browser
DEBUG - 2021-07-12 16:38:24 --> Total execution time: 0.2991
INFO - 2021-07-12 17:28:58 --> Config Class Initialized
INFO - 2021-07-12 17:28:58 --> Hooks Class Initialized
DEBUG - 2021-07-12 17:28:58 --> UTF-8 Support Enabled
INFO - 2021-07-12 17:28:58 --> Utf8 Class Initialized
INFO - 2021-07-12 17:28:58 --> URI Class Initialized
DEBUG - 2021-07-12 17:28:58 --> No URI present. Default controller set.
INFO - 2021-07-12 17:28:58 --> Router Class Initialized
INFO - 2021-07-12 17:28:58 --> Output Class Initialized
INFO - 2021-07-12 17:28:58 --> Security Class Initialized
DEBUG - 2021-07-12 17:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 17:28:58 --> Input Class Initialized
INFO - 2021-07-12 17:28:58 --> Language Class Initialized
INFO - 2021-07-12 17:28:58 --> Loader Class Initialized
INFO - 2021-07-12 17:28:58 --> Helper loaded: basic_helper
INFO - 2021-07-12 17:28:58 --> Helper loaded: url_helper
INFO - 2021-07-12 17:28:58 --> Helper loaded: file_helper
INFO - 2021-07-12 17:28:58 --> Helper loaded: form_helper
INFO - 2021-07-12 17:28:58 --> Helper loaded: cookie_helper
INFO - 2021-07-12 17:28:58 --> Helper loaded: security_helper
INFO - 2021-07-12 17:28:58 --> Helper loaded: directory_helper
INFO - 2021-07-12 17:28:58 --> Helper loaded: language_helper
INFO - 2021-07-12 17:28:58 --> Helper loaded: general_helper
INFO - 2021-07-12 17:28:58 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 17:28:58 --> Database Driver Class Initialized
DEBUG - 2021-07-12 17:28:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 17:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 17:28:58 --> Parser Class Initialized
INFO - 2021-07-12 17:28:58 --> Form Validation Class Initialized
INFO - 2021-07-12 17:28:58 --> Upload Class Initialized
INFO - 2021-07-12 17:28:58 --> Email Class Initialized
INFO - 2021-07-12 17:28:58 --> MY_Model class loaded
INFO - 2021-07-12 17:28:58 --> Model "Users_model" initialized
INFO - 2021-07-12 17:28:58 --> Model "Settings_model" initialized
INFO - 2021-07-12 17:28:58 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 17:28:58 --> Model "Permissions_model" initialized
INFO - 2021-07-12 17:28:58 --> Model "Roles_model" initialized
INFO - 2021-07-12 17:28:58 --> Model "Activity_model" initialized
INFO - 2021-07-12 17:28:58 --> Model "Templates_model" initialized
INFO - 2021-07-12 17:28:58 --> Database Driver Class Initialized
INFO - 2021-07-12 17:28:58 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 17:28:58 --> Controller Class Initialized
INFO - 2021-07-12 17:36:55 --> Config Class Initialized
INFO - 2021-07-12 17:36:55 --> Hooks Class Initialized
DEBUG - 2021-07-12 17:36:55 --> UTF-8 Support Enabled
INFO - 2021-07-12 17:36:55 --> Utf8 Class Initialized
INFO - 2021-07-12 17:36:55 --> URI Class Initialized
DEBUG - 2021-07-12 17:36:55 --> No URI present. Default controller set.
INFO - 2021-07-12 17:36:55 --> Router Class Initialized
INFO - 2021-07-12 17:36:55 --> Output Class Initialized
INFO - 2021-07-12 17:36:55 --> Security Class Initialized
DEBUG - 2021-07-12 17:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-12 17:36:55 --> Input Class Initialized
INFO - 2021-07-12 17:36:55 --> Language Class Initialized
INFO - 2021-07-12 17:36:55 --> Loader Class Initialized
INFO - 2021-07-12 17:36:55 --> Helper loaded: basic_helper
INFO - 2021-07-12 17:36:55 --> Helper loaded: url_helper
INFO - 2021-07-12 17:36:55 --> Helper loaded: file_helper
INFO - 2021-07-12 17:36:55 --> Helper loaded: form_helper
INFO - 2021-07-12 17:36:55 --> Helper loaded: cookie_helper
INFO - 2021-07-12 17:36:55 --> Helper loaded: security_helper
INFO - 2021-07-12 17:36:55 --> Helper loaded: directory_helper
INFO - 2021-07-12 17:36:55 --> Helper loaded: language_helper
INFO - 2021-07-12 17:36:55 --> Helper loaded: general_helper
INFO - 2021-07-12 17:36:55 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-12 17:36:55 --> Database Driver Class Initialized
DEBUG - 2021-07-12 17:36:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-12 17:36:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-12 17:36:55 --> Parser Class Initialized
INFO - 2021-07-12 17:36:55 --> Form Validation Class Initialized
INFO - 2021-07-12 17:36:55 --> Upload Class Initialized
INFO - 2021-07-12 17:36:55 --> Email Class Initialized
INFO - 2021-07-12 17:36:55 --> MY_Model class loaded
INFO - 2021-07-12 17:36:55 --> Model "Users_model" initialized
INFO - 2021-07-12 17:36:55 --> Model "Settings_model" initialized
INFO - 2021-07-12 17:36:55 --> Model "Role_permissions_model" initialized
INFO - 2021-07-12 17:36:55 --> Model "Permissions_model" initialized
INFO - 2021-07-12 17:36:55 --> Model "Roles_model" initialized
INFO - 2021-07-12 17:36:55 --> Model "Activity_model" initialized
INFO - 2021-07-12 17:36:55 --> Model "Templates_model" initialized
INFO - 2021-07-12 17:36:55 --> Database Driver Class Initialized
INFO - 2021-07-12 17:36:55 --> Model "Hesaplar_model" initialized
INFO - 2021-07-12 17:36:55 --> Controller Class Initialized
ERROR - 2021-07-12 17:36:55 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-12 17:36:55 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-12 17:36:55 --> Final output sent to browser
DEBUG - 2021-07-12 17:36:55 --> Total execution time: 0.5454
