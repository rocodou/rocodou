<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-07-18 16:43:59 --> Config Class Initialized
INFO - 2021-07-18 16:43:59 --> Hooks Class Initialized
DEBUG - 2021-07-18 16:43:59 --> UTF-8 Support Enabled
INFO - 2021-07-18 16:43:59 --> Utf8 Class Initialized
INFO - 2021-07-18 16:43:59 --> URI Class Initialized
DEBUG - 2021-07-18 16:43:59 --> No URI present. Default controller set.
INFO - 2021-07-18 16:43:59 --> Router Class Initialized
INFO - 2021-07-18 16:43:59 --> Output Class Initialized
INFO - 2021-07-18 16:43:59 --> Security Class Initialized
DEBUG - 2021-07-18 16:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 16:43:59 --> Input Class Initialized
INFO - 2021-07-18 16:43:59 --> Language Class Initialized
INFO - 2021-07-18 16:44:00 --> Loader Class Initialized
INFO - 2021-07-18 16:44:00 --> Helper loaded: basic_helper
INFO - 2021-07-18 16:44:00 --> Helper loaded: url_helper
INFO - 2021-07-18 16:44:00 --> Helper loaded: file_helper
INFO - 2021-07-18 16:44:00 --> Helper loaded: form_helper
INFO - 2021-07-18 16:44:00 --> Helper loaded: cookie_helper
INFO - 2021-07-18 16:44:00 --> Helper loaded: security_helper
INFO - 2021-07-18 16:44:00 --> Helper loaded: directory_helper
INFO - 2021-07-18 16:44:00 --> Helper loaded: language_helper
INFO - 2021-07-18 16:44:00 --> Helper loaded: general_helper
INFO - 2021-07-18 16:44:00 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-18 16:44:00 --> Database Driver Class Initialized
DEBUG - 2021-07-18 16:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-18 16:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-18 16:44:01 --> Parser Class Initialized
INFO - 2021-07-18 16:44:01 --> Form Validation Class Initialized
INFO - 2021-07-18 16:44:01 --> Upload Class Initialized
INFO - 2021-07-18 16:44:01 --> Email Class Initialized
INFO - 2021-07-18 16:44:01 --> MY_Model class loaded
INFO - 2021-07-18 16:44:01 --> Model "Users_model" initialized
INFO - 2021-07-18 16:44:01 --> Model "Settings_model" initialized
INFO - 2021-07-18 16:44:01 --> Model "Role_permissions_model" initialized
INFO - 2021-07-18 16:44:01 --> Model "Permissions_model" initialized
INFO - 2021-07-18 16:44:01 --> Model "Roles_model" initialized
INFO - 2021-07-18 16:44:01 --> Model "Activity_model" initialized
INFO - 2021-07-18 16:44:01 --> Model "Templates_model" initialized
INFO - 2021-07-18 16:44:01 --> Database Driver Class Initialized
INFO - 2021-07-18 16:44:02 --> Model "Hesaplar_model" initialized
INFO - 2021-07-18 16:44:02 --> Model "Car_activity_model" initialized
INFO - 2021-07-18 16:44:02 --> Controller Class Initialized
INFO - 2021-07-18 16:44:03 --> Config Class Initialized
INFO - 2021-07-18 16:44:03 --> Hooks Class Initialized
INFO - 2021-07-18 16:44:03 --> Config Class Initialized
INFO - 2021-07-18 16:44:03 --> Hooks Class Initialized
DEBUG - 2021-07-18 16:44:03 --> UTF-8 Support Enabled
INFO - 2021-07-18 16:44:03 --> Utf8 Class Initialized
DEBUG - 2021-07-18 16:44:03 --> UTF-8 Support Enabled
INFO - 2021-07-18 16:44:03 --> Utf8 Class Initialized
INFO - 2021-07-18 16:44:03 --> URI Class Initialized
INFO - 2021-07-18 16:44:03 --> URI Class Initialized
INFO - 2021-07-18 16:44:03 --> Router Class Initialized
INFO - 2021-07-18 16:44:03 --> Router Class Initialized
INFO - 2021-07-18 16:44:03 --> Output Class Initialized
INFO - 2021-07-18 16:44:03 --> Output Class Initialized
INFO - 2021-07-18 16:44:03 --> Security Class Initialized
INFO - 2021-07-18 16:44:03 --> Security Class Initialized
DEBUG - 2021-07-18 16:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 16:44:03 --> Input Class Initialized
DEBUG - 2021-07-18 16:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 16:44:03 --> Input Class Initialized
INFO - 2021-07-18 16:44:03 --> Language Class Initialized
INFO - 2021-07-18 16:44:03 --> Language Class Initialized
ERROR - 2021-07-18 16:44:03 --> 404 Page Not Found: Faviconico/index
INFO - 2021-07-18 16:44:03 --> Loader Class Initialized
INFO - 2021-07-18 16:44:03 --> Helper loaded: basic_helper
INFO - 2021-07-18 16:44:03 --> Helper loaded: url_helper
INFO - 2021-07-18 16:44:03 --> Helper loaded: file_helper
INFO - 2021-07-18 16:44:03 --> Helper loaded: form_helper
INFO - 2021-07-18 16:44:03 --> Helper loaded: cookie_helper
INFO - 2021-07-18 16:44:03 --> Helper loaded: security_helper
INFO - 2021-07-18 16:44:03 --> Helper loaded: directory_helper
INFO - 2021-07-18 16:44:03 --> Helper loaded: language_helper
INFO - 2021-07-18 16:44:03 --> Helper loaded: general_helper
INFO - 2021-07-18 16:44:03 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-18 16:44:03 --> Database Driver Class Initialized
DEBUG - 2021-07-18 16:44:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-18 16:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-18 16:44:03 --> Parser Class Initialized
INFO - 2021-07-18 16:44:03 --> Form Validation Class Initialized
INFO - 2021-07-18 16:44:03 --> Upload Class Initialized
INFO - 2021-07-18 16:44:03 --> Email Class Initialized
INFO - 2021-07-18 16:44:03 --> MY_Model class loaded
INFO - 2021-07-18 16:44:03 --> Model "Users_model" initialized
INFO - 2021-07-18 16:44:03 --> Model "Settings_model" initialized
INFO - 2021-07-18 16:44:03 --> Model "Role_permissions_model" initialized
INFO - 2021-07-18 16:44:03 --> Model "Permissions_model" initialized
INFO - 2021-07-18 16:44:03 --> Model "Roles_model" initialized
INFO - 2021-07-18 16:44:03 --> Model "Activity_model" initialized
INFO - 2021-07-18 16:44:03 --> Model "Templates_model" initialized
INFO - 2021-07-18 16:44:03 --> Database Driver Class Initialized
INFO - 2021-07-18 16:44:03 --> Model "Hesaplar_model" initialized
INFO - 2021-07-18 16:44:03 --> Model "Car_activity_model" initialized
INFO - 2021-07-18 16:44:03 --> Controller Class Initialized
INFO - 2021-07-18 16:44:03 --> File loaded: C:\wamp64\www\crm\application\views\account/login.php
INFO - 2021-07-18 16:44:03 --> Final output sent to browser
DEBUG - 2021-07-18 16:44:03 --> Total execution time: 0.2785
INFO - 2021-07-18 16:44:03 --> Config Class Initialized
INFO - 2021-07-18 16:44:03 --> Hooks Class Initialized
INFO - 2021-07-18 16:44:03 --> Config Class Initialized
INFO - 2021-07-18 16:44:03 --> Hooks Class Initialized
DEBUG - 2021-07-18 16:44:03 --> UTF-8 Support Enabled
INFO - 2021-07-18 16:44:03 --> Utf8 Class Initialized
DEBUG - 2021-07-18 16:44:03 --> UTF-8 Support Enabled
INFO - 2021-07-18 16:44:03 --> Utf8 Class Initialized
INFO - 2021-07-18 16:44:03 --> URI Class Initialized
INFO - 2021-07-18 16:44:03 --> URI Class Initialized
INFO - 2021-07-18 16:44:03 --> Router Class Initialized
INFO - 2021-07-18 16:44:03 --> Router Class Initialized
INFO - 2021-07-18 16:44:03 --> Output Class Initialized
INFO - 2021-07-18 16:44:03 --> Output Class Initialized
INFO - 2021-07-18 16:44:03 --> Security Class Initialized
INFO - 2021-07-18 16:44:03 --> Security Class Initialized
DEBUG - 2021-07-18 16:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 16:44:03 --> Input Class Initialized
DEBUG - 2021-07-18 16:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 16:44:03 --> Input Class Initialized
INFO - 2021-07-18 16:44:03 --> Language Class Initialized
INFO - 2021-07-18 16:44:03 --> Language Class Initialized
ERROR - 2021-07-18 16:44:03 --> 404 Page Not Found: Assets/jquery
ERROR - 2021-07-18 16:44:03 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-18 16:44:03 --> Config Class Initialized
INFO - 2021-07-18 16:44:03 --> Hooks Class Initialized
DEBUG - 2021-07-18 16:44:03 --> UTF-8 Support Enabled
INFO - 2021-07-18 16:44:03 --> Utf8 Class Initialized
INFO - 2021-07-18 16:44:03 --> URI Class Initialized
INFO - 2021-07-18 16:44:03 --> Router Class Initialized
INFO - 2021-07-18 16:44:03 --> Output Class Initialized
INFO - 2021-07-18 16:44:04 --> Security Class Initialized
DEBUG - 2021-07-18 16:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 16:44:04 --> Input Class Initialized
INFO - 2021-07-18 16:44:04 --> Language Class Initialized
ERROR - 2021-07-18 16:44:04 --> 404 Page Not Found: Assets/jquery
INFO - 2021-07-18 16:44:04 --> Config Class Initialized
INFO - 2021-07-18 16:44:04 --> Hooks Class Initialized
DEBUG - 2021-07-18 16:44:04 --> UTF-8 Support Enabled
INFO - 2021-07-18 16:44:04 --> Utf8 Class Initialized
INFO - 2021-07-18 16:44:04 --> URI Class Initialized
INFO - 2021-07-18 16:44:04 --> Router Class Initialized
INFO - 2021-07-18 16:44:04 --> Output Class Initialized
INFO - 2021-07-18 16:44:04 --> Security Class Initialized
DEBUG - 2021-07-18 16:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-18 16:44:04 --> Input Class Initialized
INFO - 2021-07-18 16:44:04 --> Language Class Initialized
ERROR - 2021-07-18 16:44:04 --> 404 Page Not Found: Assets/bootstrap
