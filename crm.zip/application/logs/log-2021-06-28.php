<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-28 18:16:53 --> Query error: Table 'crm.users' doesn't exist - Invalid query: SELECT *
FROM `users`
WHERE `username` = 'admin'
OR `email` = 'admin'
ERROR - 2021-06-28 18:16:53 --> Severity: error --> Exception: Call to a member function num_rows() on bool C:\wamp64\www\crm\application\controllers\Login.php 129
ERROR - 2021-06-28 12:47:27 --> 404 Page Not Found: Assets/jquery
ERROR - 2021-06-28 12:47:27 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-06-28 12:47:27 --> 404 Page Not Found: Assets/jquery
ERROR - 2021-06-28 12:47:27 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-06-28 12:51:01 --> 404 Page Not Found: Assets/jquery
ERROR - 2021-06-28 12:51:01 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-06-28 12:51:01 --> 404 Page Not Found: Assets/jquery
ERROR - 2021-06-28 12:51:01 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-06-28 18:21:21 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:21:26 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:21:27 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:21:29 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:21:30 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:21:31 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:21:32 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:21:34 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:21:36 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:21:37 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:21:44 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:21:46 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:22:01 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:22:04 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:22:05 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:22:07 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:22:10 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:22:11 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:22:12 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:22:53 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:23:55 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 12:54:03 --> Severity: Warning --> require(C:\wamp64\www\crm\application\/libraries/BaseController.php): failed to open stream: No such file or directory C:\wamp64\www\crm\application\controllers\Hesaplar.php 3
ERROR - 2021-06-28 12:54:03 --> Severity: Compile Error --> require(): Failed opening required 'C:\wamp64\www\crm\application\/libraries/BaseController.php' (include_path='.;C:\php\pear') C:\wamp64\www\crm\application\controllers\Hesaplar.php 3
ERROR - 2021-06-28 13:00:47 --> Severity: Warning --> require(C:\wamp64\www\crm\application\/libraries/BaseController.php): failed to open stream: No such file or directory C:\wamp64\www\crm\application\controllers\Hesaplar.php 3
ERROR - 2021-06-28 13:00:47 --> Severity: Compile Error --> require(): Failed opening required 'C:\wamp64\www\crm\application\/libraries/BaseController.php' (include_path='.;C:\php\pear') C:\wamp64\www\crm\application\controllers\Hesaplar.php 3
ERROR - 2021-06-28 13:00:58 --> Severity: Warning --> require(C:\wamp64\www\crm\application\/libraries/BaseController.php): failed to open stream: No such file or directory C:\wamp64\www\crm\application\controllers\Hesaplar.php 3
ERROR - 2021-06-28 13:00:58 --> Severity: Compile Error --> require(): Failed opening required 'C:\wamp64\www\crm\application\/libraries/BaseController.php' (include_path='.;C:\php\pear') C:\wamp64\www\crm\application\controllers\Hesaplar.php 3
ERROR - 2021-06-28 13:00:59 --> Severity: Warning --> require(C:\wamp64\www\crm\application\/libraries/BaseController.php): failed to open stream: No such file or directory C:\wamp64\www\crm\application\controllers\Hesaplar.php 3
ERROR - 2021-06-28 13:00:59 --> Severity: Compile Error --> require(): Failed opening required 'C:\wamp64\www\crm\application\/libraries/BaseController.php' (include_path='.;C:\php\pear') C:\wamp64\www\crm\application\controllers\Hesaplar.php 3
ERROR - 2021-06-28 13:00:59 --> Severity: Warning --> require(C:\wamp64\www\crm\application\/libraries/BaseController.php): failed to open stream: No such file or directory C:\wamp64\www\crm\application\controllers\Hesaplar.php 3
ERROR - 2021-06-28 13:00:59 --> Severity: Compile Error --> require(): Failed opening required 'C:\wamp64\www\crm\application\/libraries/BaseController.php' (include_path='.;C:\php\pear') C:\wamp64\www\crm\application\controllers\Hesaplar.php 3
ERROR - 2021-06-28 13:01:56 --> Severity: Warning --> require(C:\wamp64\www\crm\application\/libraries/BaseController.php): failed to open stream: No such file or directory C:\wamp64\www\crm\application\controllers\Hesaplar.php 3
ERROR - 2021-06-28 13:01:56 --> Severity: Compile Error --> require(): Failed opening required 'C:\wamp64\www\crm\application\/libraries/BaseController.php' (include_path='.;C:\php\pear') C:\wamp64\www\crm\application\controllers\Hesaplar.php 3
ERROR - 2021-06-28 13:01:56 --> Severity: Warning --> require(C:\wamp64\www\crm\application\/libraries/BaseController.php): failed to open stream: No such file or directory C:\wamp64\www\crm\application\controllers\Hesaplar.php 3
ERROR - 2021-06-28 13:01:56 --> Severity: Compile Error --> require(): Failed opening required 'C:\wamp64\www\crm\application\/libraries/BaseController.php' (include_path='.;C:\php\pear') C:\wamp64\www\crm\application\controllers\Hesaplar.php 3
ERROR - 2021-06-28 13:01:56 --> Severity: Warning --> require(C:\wamp64\www\crm\application\/libraries/BaseController.php): failed to open stream: No such file or directory C:\wamp64\www\crm\application\controllers\Hesaplar.php 3
ERROR - 2021-06-28 13:01:56 --> Severity: Compile Error --> require(): Failed opening required 'C:\wamp64\www\crm\application\/libraries/BaseController.php' (include_path='.;C:\php\pear') C:\wamp64\www\crm\application\controllers\Hesaplar.php 3
ERROR - 2021-06-28 13:19:25 --> Severity: Warning --> require(C:\wamp64\www\crm\application\/libraries/BaseController.php): failed to open stream: No such file or directory C:\wamp64\www\crm\application\controllers\Hesaplar.php 3
ERROR - 2021-06-28 13:19:25 --> Severity: Compile Error --> require(): Failed opening required 'C:\wamp64\www\crm\application\/libraries/BaseController.php' (include_path='.;C:\php\pear') C:\wamp64\www\crm\application\controllers\Hesaplar.php 3
ERROR - 2021-06-28 13:19:26 --> Severity: Warning --> require(C:\wamp64\www\crm\application\/libraries/BaseController.php): failed to open stream: No such file or directory C:\wamp64\www\crm\application\controllers\Hesaplar.php 3
ERROR - 2021-06-28 13:19:26 --> Severity: Compile Error --> require(): Failed opening required 'C:\wamp64\www\crm\application\/libraries/BaseController.php' (include_path='.;C:\php\pear') C:\wamp64\www\crm\application\controllers\Hesaplar.php 3
ERROR - 2021-06-28 18:50:02 --> Severity: error --> Exception: Call to undefined method Hesaplar::loadViews() C:\wamp64\www\crm\application\controllers\Hesaplar.php 33
ERROR - 2021-06-28 18:50:03 --> Severity: error --> Exception: Call to undefined method Hesaplar::loadViews() C:\wamp64\www\crm\application\controllers\Hesaplar.php 33
ERROR - 2021-06-28 18:57:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\crm\application\views\hesaplar\raporlar.php 50
ERROR - 2021-06-28 18:57:12 --> Severity: error --> Exception: Call to a member function get_customers_balance_list() on null C:\wamp64\www\crm\application\views\hesaplar\raporlar.php 79
ERROR - 2021-06-28 18:57:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\crm\application\views\hesaplar\raporlar.php 50
ERROR - 2021-06-28 18:57:19 --> Severity: error --> Exception: Call to a member function get_customers_balance_list() on null C:\wamp64\www\crm\application\views\hesaplar\raporlar.php 79
ERROR - 2021-06-28 13:30:23 --> Severity: error --> Exception: Call to undefined function mssql_connect() C:\wamp64\www\crm\system\database\drivers\mssql\mssql_driver.php 113
ERROR - 2021-06-28 13:30:59 --> Severity: error --> Exception: Call to undefined function mssql_connect() C:\wamp64\www\crm\system\database\drivers\mssql\mssql_driver.php 113
ERROR - 2021-06-28 13:32:37 --> Severity: error --> Exception: Call to undefined function mssql_connect() C:\wamp64\www\crm\system\database\drivers\mssql\mssql_driver.php 113
ERROR - 2021-06-28 13:32:37 --> Severity: error --> Exception: Call to undefined function mssql_connect() C:\wamp64\www\crm\system\database\drivers\mssql\mssql_driver.php 113
ERROR - 2021-06-28 13:33:03 --> Severity: error --> Exception: Call to undefined function mssql_connect() C:\wamp64\www\crm\system\database\drivers\mssql\mssql_driver.php 113
ERROR - 2021-06-28 13:33:05 --> Severity: error --> Exception: Call to undefined function mssql_connect() C:\wamp64\www\crm\system\database\drivers\mssql\mssql_driver.php 113
ERROR - 2021-06-28 14:01:39 --> Severity: error --> Exception: Call to undefined function mssql_connect() C:\wamp64\www\crm\system\database\drivers\mssql\mssql_driver.php 113
ERROR - 2021-06-28 14:01:40 --> Severity: error --> Exception: Call to undefined function mssql_connect() C:\wamp64\www\crm\system\database\drivers\mssql\mssql_driver.php 113
ERROR - 2021-06-28 14:04:11 --> Severity: Error --> Call to undefined function mssql_connect() C:\wamp64\www\crm\system\database\drivers\mssql\mssql_driver.php 113
ERROR - 2021-06-28 14:04:12 --> Severity: Error --> Call to undefined function mssql_connect() C:\wamp64\www\crm\system\database\drivers\mssql\mssql_driver.php 113
ERROR - 2021-06-28 14:04:12 --> Severity: Error --> Call to undefined function mssql_connect() C:\wamp64\www\crm\system\database\drivers\mssql\mssql_driver.php 113
ERROR - 2021-06-28 14:04:13 --> Severity: Error --> Call to undefined function mssql_connect() C:\wamp64\www\crm\system\database\drivers\mssql\mssql_driver.php 113
ERROR - 2021-06-28 14:06:26 --> Severity: Error --> Call to undefined function mysqli_init() C:\wamp64\www\crm\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2021-06-28 14:14:25 --> Severity: error --> Exception: Call to undefined function mssql_connect() C:\wamp64\www\crm\system\database\drivers\mssql\mssql_driver.php 113
ERROR - 2021-06-28 14:14:26 --> Severity: error --> Exception: Call to undefined function mssql_connect() C:\wamp64\www\crm\system\database\drivers\mssql\mssql_driver.php 113
ERROR - 2021-06-28 14:14:27 --> Severity: error --> Exception: Call to undefined function mssql_connect() C:\wamp64\www\crm\system\database\drivers\mssql\mssql_driver.php 113
ERROR - 2021-06-28 19:45:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\crm\application\views\hesaplar\raporlar.php 50
ERROR - 2021-06-28 19:45:14 --> Severity: error --> Exception: Call to undefined function money_f() C:\wamp64\www\crm\application\views\hesaplar\raporlar.php 90
ERROR - 2021-06-28 19:47:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\crm\application\views\hesaplar\raporlar.php 50
ERROR - 2021-06-28 19:47:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\crm\application\views\hesaplar\raporlar.php 50
ERROR - 2021-06-28 19:48:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\crm\application\views\hesaplar\raporlar.php 50
ERROR - 2021-06-28 19:48:21 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 19:48:25 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 19:48:39 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 19:50:27 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 19:50:29 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 19:53:43 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 19:54:34 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 19:54:52 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 19:55:01 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 19:55:03 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 19:55:04 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 19:55:04 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 19:55:06 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 19:55:07 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 19:55:08 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 19:55:09 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 19:55:09 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 19:55:11 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 19:55:12 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 19:55:12 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 19:55:13 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 19:55:14 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 19:56:34 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:00:30 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:00:31 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:00:33 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:00:33 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:00:33 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:00:33 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:00:34 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:00:34 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:00:37 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:00:38 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:00:39 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:00:39 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:00:40 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:00:52 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:01:53 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:02:47 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 14:32:58 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:32:59 --> 404 Page Not Found: Assets/css
ERROR - 2021-06-28 14:32:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:32:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:32:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:32:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:32:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:32:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:32:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:32:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:32:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:32:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:32:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:32:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:32:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:32:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:32:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:32:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:32:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:32:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:32:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:32:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:32:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:32:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:32:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:32:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:32:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:32:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:32:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:32:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:32:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:32:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:32:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:32:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:32:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:32:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:32:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:32:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:32:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:32:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:32:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:32:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:32:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:32:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:32:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:32:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 20:03:03 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:05:23 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:08:47 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:09:56 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:10:19 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:10:23 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:10:54 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:11:18 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:12:02 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:12:18 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:12:23 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:12:25 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:13:52 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:14:31 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:14:43 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:14:47 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:14:49 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:14:51 --> Severity: error --> Exception: Call to undefined method Hesaplar::loadViews() C:\wamp64\www\crm\application\controllers\Hesaplar.php 51
ERROR - 2021-06-28 20:17:33 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 14:47:34 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:34 --> 404 Page Not Found: Assets/css
ERROR - 2021-06-28 14:47:34 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:34 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:34 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:34 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:34 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:34 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:34 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:34 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:34 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:34 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:34 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:34 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:34 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:34 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:34 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:34 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:34 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:34 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:34 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:34 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:34 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:34 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:34 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:34 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:34 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:34 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:34 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:34 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:34 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:34 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:34 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:34 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:34 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:34 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:34 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:34 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:34 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:34 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:34 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:34 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:34 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:34 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:34 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:34 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 20:17:40 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:17:41 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 14:47:45 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:45 --> 404 Page Not Found: Assets/css
ERROR - 2021-06-28 14:47:45 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:45 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:45 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:45 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:45 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:45 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:45 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:45 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:45 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:45 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:45 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:45 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:45 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:45 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:45 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:45 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:45 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:45 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:45 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:45 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:45 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:45 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:45 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:45 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:45 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:45 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:45 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:45 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:45 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:45 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:45 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:45 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:45 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:45 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:45 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:45 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:45 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:45 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:45 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:45 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:45 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:45 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:45 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:47:45 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 20:18:11 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:18:13 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:18:14 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:18:14 --> Invalid query: 
ERROR - 2021-06-28 20:18:32 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:18:32 --> Invalid query: 
ERROR - 2021-06-28 20:18:34 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:18:34 --> Invalid query: 
ERROR - 2021-06-28 20:18:35 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:18:35 --> Invalid query: 
ERROR - 2021-06-28 20:19:05 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:19:05 --> Invalid query: 
ERROR - 2021-06-28 20:19:39 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:19:49 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:22:01 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 14:52:29 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:29 --> 404 Page Not Found: Assets/css
ERROR - 2021-06-28 14:52:29 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:29 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:29 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:29 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:29 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:29 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:29 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:29 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:29 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:29 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:29 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:29 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:29 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:29 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:29 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:29 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:29 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:29 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:29 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:29 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:29 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:29 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:29 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:29 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:29 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:29 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:29 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:29 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:29 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:29 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:29 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:29 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:30 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:30 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:30 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:30 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:30 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:30 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:30 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:30 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:30 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:30 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:30 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:30 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 20:22:31 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:22:32 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:22:32 --> Invalid query: 
ERROR - 2021-06-28 20:22:37 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:22:37 --> Invalid query: 
ERROR - 2021-06-28 20:22:40 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:22:41 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:22:56 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 14:52:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:59 --> 404 Page Not Found: Assets/css
ERROR - 2021-06-28 14:52:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:52:59 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:00 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:00 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:00 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:00 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:00 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:00 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:00 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:00 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:00 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:00 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:00 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:00 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:00 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:00 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:00 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:02 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:02 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:02 --> 404 Page Not Found: Assets/css
ERROR - 2021-06-28 14:53:02 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:02 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:02 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:02 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:02 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:02 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:02 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:02 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:02 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:02 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:02 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:02 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:02 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:02 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:02 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:02 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:02 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:02 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:02 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:02 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:02 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:02 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:02 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:02 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:02 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:02 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:02 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:02 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:02 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:02 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:02 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:02 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:02 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:02 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:02 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:02 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:02 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:02 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:02 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:02 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:02 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:02 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:02 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:03 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:03 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:03 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:03 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:03 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:03 --> 404 Page Not Found: Assets/css
ERROR - 2021-06-28 14:53:03 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:03 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:03 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:03 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:03 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:03 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:03 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:03 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:03 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:03 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:03 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:03 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:03 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:03 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:03 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:03 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:03 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:03 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:03 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:03 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:03 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:03 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:03 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:03 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:03 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:03 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:03 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:03 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:03 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:03 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:03 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:03 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:03 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:03 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:03 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:03 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:03 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:03 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:03 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 14:53:03 --> 404 Page Not Found: Raporlar/raporlar
ERROR - 2021-06-28 20:23:06 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:23:11 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:23:13 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:23:13 --> Invalid query: 
ERROR - 2021-06-28 20:24:28 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:24:58 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:25:01 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:25:08 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:25:10 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:25:24 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:28:19 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:29:21 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:29:22 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 20:29:57 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:00:13 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:00:14 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:00:24 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:00:25 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:00:31 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:00:32 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:05:08 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:05:23 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:05:25 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:05:27 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:05:34 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:05:35 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:05:40 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:05:41 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:06:09 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:06:47 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:06:58 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:06:59 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:07:01 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:07:02 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:07:03 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:07:17 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:09:15 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:11:40 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:15:10 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:15:12 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:16:22 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:16:32 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:17:32 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:18:45 --> Severity: error --> Exception: syntax error, unexpected '<', expecting end of file C:\wamp64\www\crm\application\views\hesaplar\raporlar.php 31
ERROR - 2021-06-28 18:19:22 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:19:33 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:19:33 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:20:20 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:21:12 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:21:15 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:21:19 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:22:33 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:22:35 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:23:36 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:23:41 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:23:51 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:24:57 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:24:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\crm\application\views\hesaplar\rapor_ayrinti.php 26
ERROR - 2021-06-28 18:25:32 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:25:36 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:26:07 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:26:12 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:26:17 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:26:36 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:27:56 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:28:24 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:28:30 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:28:47 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:29:45 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:29:53 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:30:00 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:30:20 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 15:30:22 --> 404 Page Not Found: Ch_ayrintiphp/index
ERROR - 2021-06-28 15:30:22 --> 404 Page Not Found: Plugins/chart.js
ERROR - 2021-06-28 15:30:22 --> 404 Page Not Found: Plugins/sparklines
ERROR - 2021-06-28 15:30:22 --> 404 Page Not Found: Assets/css
ERROR - 2021-06-28 15:30:22 --> 404 Page Not Found: Plugins/jqvmap
ERROR - 2021-06-28 15:30:22 --> 404 Page Not Found: Plugins/jquery-knob
ERROR - 2021-06-28 15:30:22 --> 404 Page Not Found: Plugins/jqvmap
ERROR - 2021-06-28 15:30:22 --> 404 Page Not Found: Plugins/moment
ERROR - 2021-06-28 15:30:22 --> 404 Page Not Found: Plugins/daterangepicker
ERROR - 2021-06-28 15:30:22 --> 404 Page Not Found: Plugins/tempusdominus-bootstrap-4
ERROR - 2021-06-28 15:30:22 --> 404 Page Not Found: Plugins/summernote
ERROR - 2021-06-28 15:30:22 --> 404 Page Not Found: Plugins/overlayScrollbars
ERROR - 2021-06-28 15:30:22 --> 404 Page Not Found: Plugins/sweetalert2
ERROR - 2021-06-28 15:30:22 --> 404 Page Not Found: Plugins/toastr
ERROR - 2021-06-28 15:30:22 --> 404 Page Not Found: Plugins/datatables
ERROR - 2021-06-28 15:30:22 --> 404 Page Not Found: Plugins/datatables-bs4
ERROR - 2021-06-28 15:30:22 --> 404 Page Not Found: Plugins/datatables-responsive
ERROR - 2021-06-28 15:30:22 --> 404 Page Not Found: Plugins/datatables-responsive
ERROR - 2021-06-28 15:30:22 --> 404 Page Not Found: Plugins/jquery-validation
ERROR - 2021-06-28 15:30:22 --> 404 Page Not Found: Plugins/jquery-validation
ERROR - 2021-06-28 15:30:22 --> 404 Page Not Found: Plugins/select2
ERROR - 2021-06-28 15:30:22 --> 404 Page Not Found: Plugins/bootstrap-switch
ERROR - 2021-06-28 15:30:22 --> 404 Page Not Found: Js/adminlte.min.js
ERROR - 2021-06-28 15:30:22 --> 404 Page Not Found: Js/demo.js
ERROR - 2021-06-28 15:30:22 --> 404 Page Not Found: Plugins/chart.js
ERROR - 2021-06-28 15:30:22 --> 404 Page Not Found: Plugins/sparklines
ERROR - 2021-06-28 15:30:22 --> 404 Page Not Found: Plugins/jqvmap
ERROR - 2021-06-28 15:30:22 --> 404 Page Not Found: Plugins/jqvmap
ERROR - 2021-06-28 15:30:22 --> 404 Page Not Found: Plugins/jquery-knob
ERROR - 2021-06-28 15:30:22 --> 404 Page Not Found: Plugins/moment
ERROR - 2021-06-28 15:30:22 --> 404 Page Not Found: Plugins/daterangepicker
ERROR - 2021-06-28 15:30:22 --> 404 Page Not Found: Plugins/tempusdominus-bootstrap-4
ERROR - 2021-06-28 15:30:22 --> 404 Page Not Found: Plugins/summernote
ERROR - 2021-06-28 15:30:22 --> 404 Page Not Found: Plugins/overlayScrollbars
ERROR - 2021-06-28 15:30:22 --> 404 Page Not Found: Plugins/sweetalert2
ERROR - 2021-06-28 15:30:22 --> 404 Page Not Found: Plugins/toastr
ERROR - 2021-06-28 15:30:22 --> 404 Page Not Found: Plugins/datatables
ERROR - 2021-06-28 15:30:22 --> 404 Page Not Found: Plugins/datatables-bs4
ERROR - 2021-06-28 15:30:22 --> 404 Page Not Found: Plugins/datatables-responsive
ERROR - 2021-06-28 15:30:22 --> 404 Page Not Found: Plugins/datatables-responsive
ERROR - 2021-06-28 15:30:22 --> 404 Page Not Found: Plugins/jquery-validation
ERROR - 2021-06-28 15:30:22 --> 404 Page Not Found: Plugins/jquery-validation
ERROR - 2021-06-28 15:30:22 --> 404 Page Not Found: Plugins/bootstrap-switch
ERROR - 2021-06-28 15:30:22 --> 404 Page Not Found: Plugins/select2
ERROR - 2021-06-28 15:30:22 --> 404 Page Not Found: Js/adminlte.min.js
ERROR - 2021-06-28 15:30:22 --> 404 Page Not Found: Js/demo.js
ERROR - 2021-06-28 18:30:37 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:30:51 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 15:30:55 --> 404 Page Not Found: Ch_ayrintiphp/index
ERROR - 2021-06-28 15:30:55 --> 404 Page Not Found: Assets/css
ERROR - 2021-06-28 15:30:55 --> 404 Page Not Found: Plugins/sparklines
ERROR - 2021-06-28 15:30:55 --> 404 Page Not Found: Plugins/jquery-knob
ERROR - 2021-06-28 15:30:55 --> 404 Page Not Found: Plugins/chart.js
ERROR - 2021-06-28 15:30:55 --> 404 Page Not Found: Plugins/jqvmap
ERROR - 2021-06-28 15:30:55 --> 404 Page Not Found: Plugins/jqvmap
ERROR - 2021-06-28 15:30:55 --> 404 Page Not Found: Plugins/moment
ERROR - 2021-06-28 15:30:55 --> 404 Page Not Found: Plugins/overlayScrollbars
ERROR - 2021-06-28 15:30:55 --> 404 Page Not Found: Plugins/daterangepicker
ERROR - 2021-06-28 15:30:55 --> 404 Page Not Found: Plugins/sweetalert2
ERROR - 2021-06-28 15:30:55 --> 404 Page Not Found: Plugins/summernote
ERROR - 2021-06-28 15:30:55 --> 404 Page Not Found: Plugins/tempusdominus-bootstrap-4
ERROR - 2021-06-28 15:30:55 --> 404 Page Not Found: Plugins/toastr
ERROR - 2021-06-28 15:30:55 --> 404 Page Not Found: Plugins/datatables
ERROR - 2021-06-28 15:30:55 --> 404 Page Not Found: Plugins/datatables-bs4
ERROR - 2021-06-28 15:30:55 --> 404 Page Not Found: Plugins/datatables-responsive
ERROR - 2021-06-28 15:30:55 --> 404 Page Not Found: Plugins/datatables-responsive
ERROR - 2021-06-28 15:30:55 --> 404 Page Not Found: Plugins/jquery-validation
ERROR - 2021-06-28 15:30:55 --> 404 Page Not Found: Plugins/jquery-validation
ERROR - 2021-06-28 15:30:55 --> 404 Page Not Found: Plugins/bootstrap-switch
ERROR - 2021-06-28 15:30:55 --> 404 Page Not Found: Js/adminlte.min.js
ERROR - 2021-06-28 15:30:55 --> 404 Page Not Found: Js/demo.js
ERROR - 2021-06-28 15:30:55 --> 404 Page Not Found: Plugins/select2
ERROR - 2021-06-28 15:30:55 --> 404 Page Not Found: Plugins/chart.js
ERROR - 2021-06-28 15:30:55 --> 404 Page Not Found: Plugins/sparklines
ERROR - 2021-06-28 15:30:55 --> 404 Page Not Found: Plugins/jqvmap
ERROR - 2021-06-28 15:30:55 --> 404 Page Not Found: Plugins/jqvmap
ERROR - 2021-06-28 15:30:55 --> 404 Page Not Found: Plugins/jquery-knob
ERROR - 2021-06-28 15:30:55 --> 404 Page Not Found: Plugins/moment
ERROR - 2021-06-28 15:30:55 --> 404 Page Not Found: Plugins/daterangepicker
ERROR - 2021-06-28 15:30:55 --> 404 Page Not Found: Plugins/tempusdominus-bootstrap-4
ERROR - 2021-06-28 15:30:55 --> 404 Page Not Found: Plugins/summernote
ERROR - 2021-06-28 15:30:55 --> 404 Page Not Found: Plugins/overlayScrollbars
ERROR - 2021-06-28 15:30:55 --> 404 Page Not Found: Plugins/sweetalert2
ERROR - 2021-06-28 15:30:55 --> 404 Page Not Found: Plugins/toastr
ERROR - 2021-06-28 15:30:55 --> 404 Page Not Found: Plugins/datatables
ERROR - 2021-06-28 15:30:55 --> 404 Page Not Found: Plugins/datatables-bs4
ERROR - 2021-06-28 15:30:55 --> 404 Page Not Found: Plugins/datatables-responsive
ERROR - 2021-06-28 15:30:55 --> 404 Page Not Found: Plugins/datatables-responsive
ERROR - 2021-06-28 15:30:55 --> 404 Page Not Found: Plugins/jquery-validation
ERROR - 2021-06-28 15:30:55 --> 404 Page Not Found: Plugins/jquery-validation
ERROR - 2021-06-28 15:30:55 --> 404 Page Not Found: Plugins/bootstrap-switch
ERROR - 2021-06-28 15:30:55 --> 404 Page Not Found: Plugins/select2
ERROR - 2021-06-28 15:30:55 --> 404 Page Not Found: Js/adminlte.min.js
ERROR - 2021-06-28 15:30:55 --> 404 Page Not Found: Js/demo.js
ERROR - 2021-06-28 18:31:06 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:31:13 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:31:15 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:31:17 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:31:21 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:31:32 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:33:01 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:33:02 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:33:03 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:33:35 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:33:38 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:33:41 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:33:44 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:33:47 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:33:52 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:33:59 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:34:03 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:34:19 --> Could not find the language line "sample_message_bro"
ERROR - 2021-06-28 18:34:23 --> Could not find the language line "sample_message_bro"
