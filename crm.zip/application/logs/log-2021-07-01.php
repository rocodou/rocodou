<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-07-01 09:05:29 --> Config Class Initialized
INFO - 2021-07-01 09:05:29 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:05:29 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:05:29 --> Utf8 Class Initialized
INFO - 2021-07-01 09:05:29 --> URI Class Initialized
DEBUG - 2021-07-01 09:05:29 --> No URI present. Default controller set.
INFO - 2021-07-01 09:05:29 --> Router Class Initialized
INFO - 2021-07-01 09:05:29 --> Output Class Initialized
INFO - 2021-07-01 09:05:29 --> Security Class Initialized
DEBUG - 2021-07-01 09:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:05:29 --> Input Class Initialized
INFO - 2021-07-01 09:05:29 --> Language Class Initialized
INFO - 2021-07-01 09:05:29 --> Loader Class Initialized
INFO - 2021-07-01 09:05:29 --> Helper loaded: basic_helper
INFO - 2021-07-01 09:05:29 --> Helper loaded: url_helper
INFO - 2021-07-01 09:05:29 --> Helper loaded: file_helper
INFO - 2021-07-01 09:05:29 --> Helper loaded: form_helper
INFO - 2021-07-01 09:05:29 --> Helper loaded: cookie_helper
INFO - 2021-07-01 09:05:29 --> Helper loaded: security_helper
INFO - 2021-07-01 09:05:29 --> Helper loaded: directory_helper
INFO - 2021-07-01 09:05:29 --> Helper loaded: language_helper
INFO - 2021-07-01 09:05:29 --> Helper loaded: general_helper
INFO - 2021-07-01 09:05:29 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 09:05:29 --> Database Driver Class Initialized
DEBUG - 2021-07-01 09:05:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 09:05:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:05:29 --> Parser Class Initialized
INFO - 2021-07-01 09:05:29 --> Form Validation Class Initialized
INFO - 2021-07-01 09:05:29 --> Upload Class Initialized
INFO - 2021-07-01 09:05:29 --> Email Class Initialized
INFO - 2021-07-01 09:05:29 --> MY_Model class loaded
INFO - 2021-07-01 09:05:29 --> Model "Users_model" initialized
INFO - 2021-07-01 09:05:29 --> Model "Settings_model" initialized
INFO - 2021-07-01 09:05:29 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 09:05:29 --> Model "Permissions_model" initialized
INFO - 2021-07-01 09:05:29 --> Model "Roles_model" initialized
INFO - 2021-07-01 09:05:29 --> Model "Activity_model" initialized
INFO - 2021-07-01 09:05:29 --> Model "Templates_model" initialized
INFO - 2021-07-01 09:05:29 --> Database Driver Class Initialized
INFO - 2021-07-01 09:05:29 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 09:05:29 --> Controller Class Initialized
INFO - 2021-07-01 09:28:58 --> Config Class Initialized
INFO - 2021-07-01 09:28:58 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:28:58 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:28:58 --> Utf8 Class Initialized
INFO - 2021-07-01 09:28:58 --> URI Class Initialized
DEBUG - 2021-07-01 09:28:58 --> No URI present. Default controller set.
INFO - 2021-07-01 09:28:58 --> Router Class Initialized
INFO - 2021-07-01 09:28:58 --> Output Class Initialized
INFO - 2021-07-01 09:28:58 --> Security Class Initialized
DEBUG - 2021-07-01 09:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:28:58 --> Input Class Initialized
INFO - 2021-07-01 09:28:58 --> Language Class Initialized
INFO - 2021-07-01 09:28:58 --> Loader Class Initialized
INFO - 2021-07-01 09:28:58 --> Helper loaded: basic_helper
INFO - 2021-07-01 09:28:58 --> Helper loaded: url_helper
INFO - 2021-07-01 09:28:58 --> Helper loaded: file_helper
INFO - 2021-07-01 09:28:58 --> Helper loaded: form_helper
INFO - 2021-07-01 09:28:58 --> Helper loaded: cookie_helper
INFO - 2021-07-01 09:28:58 --> Helper loaded: security_helper
INFO - 2021-07-01 09:28:58 --> Helper loaded: directory_helper
INFO - 2021-07-01 09:28:58 --> Helper loaded: language_helper
INFO - 2021-07-01 09:28:58 --> Helper loaded: general_helper
INFO - 2021-07-01 09:28:58 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 09:28:58 --> Database Driver Class Initialized
DEBUG - 2021-07-01 09:28:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 09:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:28:58 --> Parser Class Initialized
INFO - 2021-07-01 09:28:58 --> Form Validation Class Initialized
INFO - 2021-07-01 09:28:58 --> Upload Class Initialized
INFO - 2021-07-01 09:28:58 --> Email Class Initialized
INFO - 2021-07-01 09:28:58 --> MY_Model class loaded
INFO - 2021-07-01 09:28:58 --> Model "Users_model" initialized
INFO - 2021-07-01 09:28:58 --> Model "Settings_model" initialized
INFO - 2021-07-01 09:28:58 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 09:28:58 --> Model "Permissions_model" initialized
INFO - 2021-07-01 09:28:58 --> Model "Roles_model" initialized
INFO - 2021-07-01 09:28:58 --> Model "Activity_model" initialized
INFO - 2021-07-01 09:28:58 --> Model "Templates_model" initialized
INFO - 2021-07-01 09:28:58 --> Database Driver Class Initialized
INFO - 2021-07-01 09:28:58 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 09:28:58 --> Controller Class Initialized
INFO - 2021-07-01 09:58:00 --> Config Class Initialized
INFO - 2021-07-01 09:58:00 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:58:00 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:58:00 --> Utf8 Class Initialized
INFO - 2021-07-01 09:58:00 --> URI Class Initialized
DEBUG - 2021-07-01 09:58:00 --> No URI present. Default controller set.
INFO - 2021-07-01 09:58:00 --> Router Class Initialized
INFO - 2021-07-01 09:58:00 --> Output Class Initialized
INFO - 2021-07-01 09:58:00 --> Security Class Initialized
DEBUG - 2021-07-01 09:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:58:00 --> Input Class Initialized
INFO - 2021-07-01 09:58:00 --> Language Class Initialized
INFO - 2021-07-01 09:58:00 --> Loader Class Initialized
INFO - 2021-07-01 09:58:00 --> Helper loaded: basic_helper
INFO - 2021-07-01 09:58:00 --> Helper loaded: url_helper
INFO - 2021-07-01 09:58:00 --> Helper loaded: file_helper
INFO - 2021-07-01 09:58:00 --> Helper loaded: form_helper
INFO - 2021-07-01 09:58:00 --> Helper loaded: cookie_helper
INFO - 2021-07-01 09:58:00 --> Helper loaded: security_helper
INFO - 2021-07-01 09:58:00 --> Helper loaded: directory_helper
INFO - 2021-07-01 09:58:00 --> Helper loaded: language_helper
INFO - 2021-07-01 09:58:00 --> Helper loaded: general_helper
INFO - 2021-07-01 09:58:00 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 09:58:00 --> Database Driver Class Initialized
DEBUG - 2021-07-01 09:58:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 09:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:58:00 --> Parser Class Initialized
INFO - 2021-07-01 09:58:00 --> Form Validation Class Initialized
INFO - 2021-07-01 09:58:00 --> Upload Class Initialized
INFO - 2021-07-01 09:58:00 --> Email Class Initialized
INFO - 2021-07-01 09:58:00 --> MY_Model class loaded
INFO - 2021-07-01 09:58:00 --> Model "Users_model" initialized
INFO - 2021-07-01 09:58:00 --> Model "Settings_model" initialized
INFO - 2021-07-01 09:58:00 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 09:58:00 --> Model "Permissions_model" initialized
INFO - 2021-07-01 09:58:00 --> Model "Roles_model" initialized
INFO - 2021-07-01 09:58:00 --> Model "Activity_model" initialized
INFO - 2021-07-01 09:58:00 --> Model "Templates_model" initialized
INFO - 2021-07-01 09:58:00 --> Database Driver Class Initialized
INFO - 2021-07-01 09:58:00 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 09:58:00 --> Controller Class Initialized
INFO - 2021-07-01 09:58:01 --> Config Class Initialized
INFO - 2021-07-01 09:58:01 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:58:01 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:58:01 --> Utf8 Class Initialized
INFO - 2021-07-01 09:58:01 --> URI Class Initialized
INFO - 2021-07-01 09:58:01 --> Router Class Initialized
INFO - 2021-07-01 09:58:01 --> Output Class Initialized
INFO - 2021-07-01 09:58:01 --> Security Class Initialized
DEBUG - 2021-07-01 09:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:58:01 --> Input Class Initialized
INFO - 2021-07-01 09:58:01 --> Language Class Initialized
INFO - 2021-07-01 09:58:01 --> Loader Class Initialized
INFO - 2021-07-01 09:58:01 --> Helper loaded: basic_helper
INFO - 2021-07-01 09:58:01 --> Helper loaded: url_helper
INFO - 2021-07-01 09:58:01 --> Helper loaded: file_helper
INFO - 2021-07-01 09:58:01 --> Helper loaded: form_helper
INFO - 2021-07-01 09:58:01 --> Config Class Initialized
INFO - 2021-07-01 09:58:01 --> Helper loaded: cookie_helper
INFO - 2021-07-01 09:58:01 --> Hooks Class Initialized
INFO - 2021-07-01 09:58:01 --> Helper loaded: security_helper
DEBUG - 2021-07-01 09:58:01 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:58:01 --> Utf8 Class Initialized
INFO - 2021-07-01 09:58:01 --> Helper loaded: directory_helper
INFO - 2021-07-01 09:58:01 --> URI Class Initialized
INFO - 2021-07-01 09:58:01 --> Helper loaded: language_helper
INFO - 2021-07-01 09:58:01 --> Helper loaded: general_helper
INFO - 2021-07-01 09:58:01 --> Router Class Initialized
INFO - 2021-07-01 09:58:01 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 09:58:01 --> Output Class Initialized
INFO - 2021-07-01 09:58:01 --> Database Driver Class Initialized
INFO - 2021-07-01 09:58:01 --> Security Class Initialized
DEBUG - 2021-07-01 09:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:58:01 --> Input Class Initialized
INFO - 2021-07-01 09:58:01 --> Language Class Initialized
ERROR - 2021-07-01 09:58:01 --> 404 Page Not Found: Faviconico/index
DEBUG - 2021-07-01 09:58:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 09:58:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:58:01 --> Parser Class Initialized
INFO - 2021-07-01 09:58:01 --> Form Validation Class Initialized
INFO - 2021-07-01 09:58:01 --> Upload Class Initialized
INFO - 2021-07-01 09:58:01 --> Email Class Initialized
INFO - 2021-07-01 09:58:01 --> MY_Model class loaded
INFO - 2021-07-01 09:58:01 --> Model "Users_model" initialized
INFO - 2021-07-01 09:58:01 --> Model "Settings_model" initialized
INFO - 2021-07-01 09:58:01 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 09:58:01 --> Model "Permissions_model" initialized
INFO - 2021-07-01 09:58:01 --> Model "Roles_model" initialized
INFO - 2021-07-01 09:58:01 --> Model "Activity_model" initialized
INFO - 2021-07-01 09:58:01 --> Model "Templates_model" initialized
INFO - 2021-07-01 09:58:01 --> Database Driver Class Initialized
INFO - 2021-07-01 09:58:01 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 09:58:01 --> Controller Class Initialized
INFO - 2021-07-01 12:58:01 --> File loaded: C:\wamp64\www\crm\application\views\account/login.php
INFO - 2021-07-01 12:58:01 --> Final output sent to browser
DEBUG - 2021-07-01 12:58:01 --> Total execution time: 0.0848
INFO - 2021-07-01 09:58:01 --> Config Class Initialized
INFO - 2021-07-01 09:58:01 --> Hooks Class Initialized
INFO - 2021-07-01 09:58:01 --> Config Class Initialized
INFO - 2021-07-01 09:58:01 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:58:01 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:58:01 --> Utf8 Class Initialized
DEBUG - 2021-07-01 09:58:01 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:58:01 --> Utf8 Class Initialized
INFO - 2021-07-01 09:58:01 --> URI Class Initialized
INFO - 2021-07-01 09:58:01 --> URI Class Initialized
INFO - 2021-07-01 09:58:01 --> Router Class Initialized
INFO - 2021-07-01 09:58:01 --> Router Class Initialized
INFO - 2021-07-01 09:58:01 --> Output Class Initialized
INFO - 2021-07-01 09:58:01 --> Output Class Initialized
INFO - 2021-07-01 09:58:01 --> Security Class Initialized
INFO - 2021-07-01 09:58:01 --> Security Class Initialized
DEBUG - 2021-07-01 09:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:58:01 --> Input Class Initialized
DEBUG - 2021-07-01 09:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:58:01 --> Input Class Initialized
INFO - 2021-07-01 09:58:01 --> Language Class Initialized
INFO - 2021-07-01 09:58:01 --> Language Class Initialized
ERROR - 2021-07-01 09:58:01 --> 404 Page Not Found: Assets/jquery
ERROR - 2021-07-01 09:58:01 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-01 09:58:01 --> Config Class Initialized
INFO - 2021-07-01 09:58:01 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:58:01 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:58:01 --> Utf8 Class Initialized
INFO - 2021-07-01 09:58:01 --> URI Class Initialized
INFO - 2021-07-01 09:58:01 --> Router Class Initialized
INFO - 2021-07-01 09:58:01 --> Output Class Initialized
INFO - 2021-07-01 09:58:01 --> Security Class Initialized
DEBUG - 2021-07-01 09:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:58:01 --> Input Class Initialized
INFO - 2021-07-01 09:58:01 --> Language Class Initialized
ERROR - 2021-07-01 09:58:01 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-01 09:58:18 --> Config Class Initialized
INFO - 2021-07-01 09:58:18 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:58:18 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:58:18 --> Utf8 Class Initialized
INFO - 2021-07-01 09:58:18 --> URI Class Initialized
INFO - 2021-07-01 09:58:18 --> Router Class Initialized
INFO - 2021-07-01 09:58:18 --> Output Class Initialized
INFO - 2021-07-01 09:58:18 --> Security Class Initialized
DEBUG - 2021-07-01 09:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:58:18 --> Input Class Initialized
INFO - 2021-07-01 09:58:18 --> Language Class Initialized
INFO - 2021-07-01 09:58:18 --> Loader Class Initialized
INFO - 2021-07-01 09:58:18 --> Helper loaded: basic_helper
INFO - 2021-07-01 09:58:18 --> Helper loaded: url_helper
INFO - 2021-07-01 09:58:18 --> Helper loaded: file_helper
INFO - 2021-07-01 09:58:18 --> Helper loaded: form_helper
INFO - 2021-07-01 09:58:18 --> Helper loaded: cookie_helper
INFO - 2021-07-01 09:58:18 --> Helper loaded: security_helper
INFO - 2021-07-01 09:58:18 --> Helper loaded: directory_helper
INFO - 2021-07-01 09:58:18 --> Helper loaded: language_helper
INFO - 2021-07-01 09:58:18 --> Helper loaded: general_helper
INFO - 2021-07-01 09:58:18 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 09:58:18 --> Database Driver Class Initialized
DEBUG - 2021-07-01 09:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 09:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:58:18 --> Parser Class Initialized
INFO - 2021-07-01 09:58:18 --> Form Validation Class Initialized
INFO - 2021-07-01 09:58:18 --> Upload Class Initialized
INFO - 2021-07-01 09:58:18 --> Email Class Initialized
INFO - 2021-07-01 09:58:18 --> MY_Model class loaded
INFO - 2021-07-01 09:58:18 --> Model "Users_model" initialized
INFO - 2021-07-01 09:58:18 --> Model "Settings_model" initialized
INFO - 2021-07-01 09:58:18 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 09:58:18 --> Model "Permissions_model" initialized
INFO - 2021-07-01 09:58:18 --> Model "Roles_model" initialized
INFO - 2021-07-01 09:58:18 --> Model "Activity_model" initialized
INFO - 2021-07-01 09:58:18 --> Model "Templates_model" initialized
INFO - 2021-07-01 09:58:18 --> Database Driver Class Initialized
INFO - 2021-07-01 09:58:18 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 09:58:18 --> Controller Class Initialized
DEBUG - 2021-07-01 12:58:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-01 12:58:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2021-07-01 09:58:19 --> Config Class Initialized
INFO - 2021-07-01 09:58:19 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:58:19 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:58:19 --> Utf8 Class Initialized
INFO - 2021-07-01 09:58:19 --> URI Class Initialized
DEBUG - 2021-07-01 09:58:19 --> No URI present. Default controller set.
INFO - 2021-07-01 09:58:19 --> Router Class Initialized
INFO - 2021-07-01 09:58:19 --> Output Class Initialized
INFO - 2021-07-01 09:58:19 --> Security Class Initialized
DEBUG - 2021-07-01 09:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:58:19 --> Input Class Initialized
INFO - 2021-07-01 09:58:19 --> Language Class Initialized
INFO - 2021-07-01 09:58:19 --> Loader Class Initialized
INFO - 2021-07-01 09:58:19 --> Helper loaded: basic_helper
INFO - 2021-07-01 09:58:19 --> Helper loaded: url_helper
INFO - 2021-07-01 09:58:19 --> Helper loaded: file_helper
INFO - 2021-07-01 09:58:19 --> Helper loaded: form_helper
INFO - 2021-07-01 09:58:19 --> Helper loaded: cookie_helper
INFO - 2021-07-01 09:58:19 --> Helper loaded: security_helper
INFO - 2021-07-01 09:58:19 --> Helper loaded: directory_helper
INFO - 2021-07-01 09:58:19 --> Helper loaded: language_helper
INFO - 2021-07-01 09:58:19 --> Helper loaded: general_helper
INFO - 2021-07-01 09:58:19 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 09:58:19 --> Database Driver Class Initialized
DEBUG - 2021-07-01 09:58:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 09:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:58:19 --> Parser Class Initialized
INFO - 2021-07-01 09:58:19 --> Form Validation Class Initialized
INFO - 2021-07-01 09:58:19 --> Upload Class Initialized
INFO - 2021-07-01 09:58:19 --> Email Class Initialized
INFO - 2021-07-01 09:58:19 --> MY_Model class loaded
INFO - 2021-07-01 09:58:19 --> Model "Users_model" initialized
INFO - 2021-07-01 09:58:19 --> Model "Settings_model" initialized
INFO - 2021-07-01 09:58:19 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 09:58:19 --> Model "Permissions_model" initialized
INFO - 2021-07-01 09:58:19 --> Model "Roles_model" initialized
INFO - 2021-07-01 09:58:19 --> Model "Activity_model" initialized
INFO - 2021-07-01 09:58:19 --> Model "Templates_model" initialized
INFO - 2021-07-01 09:58:19 --> Database Driver Class Initialized
INFO - 2021-07-01 09:58:19 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 09:58:19 --> Controller Class Initialized
ERROR - 2021-07-01 12:58:19 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-01 12:58:19 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-01 12:58:19 --> Final output sent to browser
DEBUG - 2021-07-01 12:58:19 --> Total execution time: 0.0782
INFO - 2021-07-01 09:58:22 --> Config Class Initialized
INFO - 2021-07-01 09:58:22 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:58:22 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:58:22 --> Utf8 Class Initialized
INFO - 2021-07-01 09:58:22 --> URI Class Initialized
INFO - 2021-07-01 09:58:22 --> Router Class Initialized
INFO - 2021-07-01 09:58:22 --> Output Class Initialized
INFO - 2021-07-01 09:58:22 --> Security Class Initialized
DEBUG - 2021-07-01 09:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:58:22 --> Input Class Initialized
INFO - 2021-07-01 09:58:22 --> Language Class Initialized
INFO - 2021-07-01 09:58:22 --> Loader Class Initialized
INFO - 2021-07-01 09:58:22 --> Helper loaded: basic_helper
INFO - 2021-07-01 09:58:22 --> Helper loaded: url_helper
INFO - 2021-07-01 09:58:22 --> Helper loaded: file_helper
INFO - 2021-07-01 09:58:22 --> Helper loaded: form_helper
INFO - 2021-07-01 09:58:22 --> Helper loaded: cookie_helper
INFO - 2021-07-01 09:58:22 --> Helper loaded: security_helper
INFO - 2021-07-01 09:58:22 --> Helper loaded: directory_helper
INFO - 2021-07-01 09:58:22 --> Helper loaded: language_helper
INFO - 2021-07-01 09:58:22 --> Helper loaded: general_helper
INFO - 2021-07-01 09:58:22 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 09:58:22 --> Database Driver Class Initialized
DEBUG - 2021-07-01 09:58:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 09:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:58:22 --> Parser Class Initialized
INFO - 2021-07-01 09:58:22 --> Form Validation Class Initialized
INFO - 2021-07-01 09:58:22 --> Upload Class Initialized
INFO - 2021-07-01 09:58:22 --> Email Class Initialized
INFO - 2021-07-01 09:58:22 --> MY_Model class loaded
INFO - 2021-07-01 09:58:22 --> Model "Users_model" initialized
INFO - 2021-07-01 09:58:22 --> Model "Settings_model" initialized
INFO - 2021-07-01 09:58:22 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 09:58:22 --> Model "Permissions_model" initialized
INFO - 2021-07-01 09:58:22 --> Model "Roles_model" initialized
INFO - 2021-07-01 09:58:22 --> Model "Activity_model" initialized
INFO - 2021-07-01 09:58:22 --> Model "Templates_model" initialized
INFO - 2021-07-01 09:58:22 --> Database Driver Class Initialized
INFO - 2021-07-01 09:58:22 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 09:58:22 --> Controller Class Initialized
ERROR - 2021-07-01 12:58:22 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-01 12:58:22 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-01 12:58:22 --> Final output sent to browser
DEBUG - 2021-07-01 12:58:22 --> Total execution time: 0.1638
INFO - 2021-07-01 09:58:26 --> Config Class Initialized
INFO - 2021-07-01 09:58:26 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:58:26 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:58:26 --> Utf8 Class Initialized
INFO - 2021-07-01 09:58:26 --> URI Class Initialized
INFO - 2021-07-01 09:58:26 --> Router Class Initialized
INFO - 2021-07-01 09:58:26 --> Output Class Initialized
INFO - 2021-07-01 09:58:26 --> Security Class Initialized
DEBUG - 2021-07-01 09:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:58:26 --> Input Class Initialized
INFO - 2021-07-01 09:58:26 --> Language Class Initialized
INFO - 2021-07-01 09:58:26 --> Loader Class Initialized
INFO - 2021-07-01 09:58:26 --> Helper loaded: basic_helper
INFO - 2021-07-01 09:58:26 --> Helper loaded: url_helper
INFO - 2021-07-01 09:58:26 --> Helper loaded: file_helper
INFO - 2021-07-01 09:58:26 --> Helper loaded: form_helper
INFO - 2021-07-01 09:58:26 --> Helper loaded: cookie_helper
INFO - 2021-07-01 09:58:26 --> Helper loaded: security_helper
INFO - 2021-07-01 09:58:26 --> Helper loaded: directory_helper
INFO - 2021-07-01 09:58:26 --> Helper loaded: language_helper
INFO - 2021-07-01 09:58:26 --> Helper loaded: general_helper
INFO - 2021-07-01 09:58:26 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 09:58:26 --> Database Driver Class Initialized
DEBUG - 2021-07-01 09:58:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 09:58:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:58:26 --> Parser Class Initialized
INFO - 2021-07-01 09:58:26 --> Form Validation Class Initialized
INFO - 2021-07-01 09:58:26 --> Upload Class Initialized
INFO - 2021-07-01 09:58:26 --> Email Class Initialized
INFO - 2021-07-01 09:58:26 --> MY_Model class loaded
INFO - 2021-07-01 09:58:26 --> Model "Users_model" initialized
INFO - 2021-07-01 09:58:26 --> Model "Settings_model" initialized
INFO - 2021-07-01 09:58:26 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 09:58:26 --> Model "Permissions_model" initialized
INFO - 2021-07-01 09:58:26 --> Model "Roles_model" initialized
INFO - 2021-07-01 09:58:26 --> Model "Activity_model" initialized
INFO - 2021-07-01 09:58:26 --> Model "Templates_model" initialized
INFO - 2021-07-01 09:58:26 --> Database Driver Class Initialized
INFO - 2021-07-01 09:58:26 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 09:58:26 --> Controller Class Initialized
ERROR - 2021-07-01 12:58:26 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-01 12:58:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\crm\application\views\hesaplar\rapor_ayrinti.php 30
INFO - 2021-07-01 12:58:26 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-01 12:58:26 --> Final output sent to browser
DEBUG - 2021-07-01 12:58:26 --> Total execution time: 0.1592
INFO - 2021-07-01 09:58:55 --> Config Class Initialized
INFO - 2021-07-01 09:58:55 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:58:55 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:58:55 --> Utf8 Class Initialized
INFO - 2021-07-01 09:58:55 --> URI Class Initialized
INFO - 2021-07-01 09:58:55 --> Router Class Initialized
INFO - 2021-07-01 09:58:55 --> Output Class Initialized
INFO - 2021-07-01 09:58:55 --> Security Class Initialized
DEBUG - 2021-07-01 09:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:58:55 --> Input Class Initialized
INFO - 2021-07-01 09:58:55 --> Language Class Initialized
INFO - 2021-07-01 09:58:55 --> Loader Class Initialized
INFO - 2021-07-01 09:58:55 --> Helper loaded: basic_helper
INFO - 2021-07-01 09:58:55 --> Helper loaded: url_helper
INFO - 2021-07-01 09:58:55 --> Helper loaded: file_helper
INFO - 2021-07-01 09:58:55 --> Helper loaded: form_helper
INFO - 2021-07-01 09:58:55 --> Helper loaded: cookie_helper
INFO - 2021-07-01 09:58:55 --> Helper loaded: security_helper
INFO - 2021-07-01 09:58:55 --> Helper loaded: directory_helper
INFO - 2021-07-01 09:58:55 --> Helper loaded: language_helper
INFO - 2021-07-01 09:58:55 --> Helper loaded: general_helper
INFO - 2021-07-01 09:58:55 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 09:58:55 --> Database Driver Class Initialized
DEBUG - 2021-07-01 09:58:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 09:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:58:55 --> Parser Class Initialized
INFO - 2021-07-01 09:58:55 --> Form Validation Class Initialized
INFO - 2021-07-01 09:58:55 --> Upload Class Initialized
INFO - 2021-07-01 09:58:55 --> Email Class Initialized
INFO - 2021-07-01 09:58:55 --> MY_Model class loaded
INFO - 2021-07-01 09:58:55 --> Model "Users_model" initialized
INFO - 2021-07-01 09:58:55 --> Model "Settings_model" initialized
INFO - 2021-07-01 09:58:55 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 09:58:55 --> Model "Permissions_model" initialized
INFO - 2021-07-01 09:58:55 --> Model "Roles_model" initialized
INFO - 2021-07-01 09:58:55 --> Model "Activity_model" initialized
INFO - 2021-07-01 09:58:55 --> Model "Templates_model" initialized
INFO - 2021-07-01 09:58:55 --> Database Driver Class Initialized
INFO - 2021-07-01 09:58:55 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 09:58:55 --> Controller Class Initialized
ERROR - 2021-07-01 12:58:55 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-01 12:58:55 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-01 12:58:55 --> Final output sent to browser
DEBUG - 2021-07-01 12:58:55 --> Total execution time: 0.2274
INFO - 2021-07-01 09:59:56 --> Config Class Initialized
INFO - 2021-07-01 09:59:56 --> Hooks Class Initialized
DEBUG - 2021-07-01 09:59:56 --> UTF-8 Support Enabled
INFO - 2021-07-01 09:59:56 --> Utf8 Class Initialized
INFO - 2021-07-01 09:59:56 --> URI Class Initialized
INFO - 2021-07-01 09:59:56 --> Router Class Initialized
INFO - 2021-07-01 09:59:56 --> Output Class Initialized
INFO - 2021-07-01 09:59:56 --> Security Class Initialized
DEBUG - 2021-07-01 09:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 09:59:56 --> Input Class Initialized
INFO - 2021-07-01 09:59:56 --> Language Class Initialized
INFO - 2021-07-01 09:59:56 --> Loader Class Initialized
INFO - 2021-07-01 09:59:56 --> Helper loaded: basic_helper
INFO - 2021-07-01 09:59:56 --> Helper loaded: url_helper
INFO - 2021-07-01 09:59:56 --> Helper loaded: file_helper
INFO - 2021-07-01 09:59:56 --> Helper loaded: form_helper
INFO - 2021-07-01 09:59:56 --> Helper loaded: cookie_helper
INFO - 2021-07-01 09:59:56 --> Helper loaded: security_helper
INFO - 2021-07-01 09:59:56 --> Helper loaded: directory_helper
INFO - 2021-07-01 09:59:56 --> Helper loaded: language_helper
INFO - 2021-07-01 09:59:56 --> Helper loaded: general_helper
INFO - 2021-07-01 09:59:56 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 09:59:56 --> Database Driver Class Initialized
DEBUG - 2021-07-01 09:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 09:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 09:59:56 --> Parser Class Initialized
INFO - 2021-07-01 09:59:56 --> Form Validation Class Initialized
INFO - 2021-07-01 09:59:56 --> Upload Class Initialized
INFO - 2021-07-01 09:59:56 --> Email Class Initialized
INFO - 2021-07-01 09:59:56 --> MY_Model class loaded
INFO - 2021-07-01 09:59:56 --> Model "Users_model" initialized
INFO - 2021-07-01 09:59:56 --> Model "Settings_model" initialized
INFO - 2021-07-01 09:59:56 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 09:59:56 --> Model "Permissions_model" initialized
INFO - 2021-07-01 09:59:56 --> Model "Roles_model" initialized
INFO - 2021-07-01 09:59:56 --> Model "Activity_model" initialized
INFO - 2021-07-01 09:59:56 --> Model "Templates_model" initialized
INFO - 2021-07-01 09:59:56 --> Database Driver Class Initialized
INFO - 2021-07-01 09:59:57 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 09:59:57 --> Controller Class Initialized
ERROR - 2021-07-01 12:59:57 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-01 12:59:57 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-01 12:59:57 --> Final output sent to browser
DEBUG - 2021-07-01 12:59:57 --> Total execution time: 0.6539
INFO - 2021-07-01 10:00:03 --> Config Class Initialized
INFO - 2021-07-01 10:00:03 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:00:03 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:00:03 --> Utf8 Class Initialized
INFO - 2021-07-01 10:00:03 --> URI Class Initialized
INFO - 2021-07-01 10:00:03 --> Router Class Initialized
INFO - 2021-07-01 10:00:03 --> Output Class Initialized
INFO - 2021-07-01 10:00:03 --> Security Class Initialized
DEBUG - 2021-07-01 10:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:00:03 --> Input Class Initialized
INFO - 2021-07-01 10:00:03 --> Language Class Initialized
INFO - 2021-07-01 10:00:03 --> Loader Class Initialized
INFO - 2021-07-01 10:00:03 --> Helper loaded: basic_helper
INFO - 2021-07-01 10:00:03 --> Helper loaded: url_helper
INFO - 2021-07-01 10:00:03 --> Helper loaded: file_helper
INFO - 2021-07-01 10:00:03 --> Helper loaded: form_helper
INFO - 2021-07-01 10:00:03 --> Helper loaded: cookie_helper
INFO - 2021-07-01 10:00:03 --> Helper loaded: security_helper
INFO - 2021-07-01 10:00:03 --> Helper loaded: directory_helper
INFO - 2021-07-01 10:00:03 --> Helper loaded: language_helper
INFO - 2021-07-01 10:00:03 --> Helper loaded: general_helper
INFO - 2021-07-01 10:00:03 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 10:00:03 --> Database Driver Class Initialized
DEBUG - 2021-07-01 10:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 10:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:00:03 --> Parser Class Initialized
INFO - 2021-07-01 10:00:03 --> Form Validation Class Initialized
INFO - 2021-07-01 10:00:03 --> Upload Class Initialized
INFO - 2021-07-01 10:00:03 --> Email Class Initialized
INFO - 2021-07-01 10:00:03 --> MY_Model class loaded
INFO - 2021-07-01 10:00:03 --> Model "Users_model" initialized
INFO - 2021-07-01 10:00:03 --> Model "Settings_model" initialized
INFO - 2021-07-01 10:00:03 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 10:00:03 --> Model "Permissions_model" initialized
INFO - 2021-07-01 10:00:03 --> Model "Roles_model" initialized
INFO - 2021-07-01 10:00:03 --> Model "Activity_model" initialized
INFO - 2021-07-01 10:00:03 --> Model "Templates_model" initialized
INFO - 2021-07-01 10:00:03 --> Database Driver Class Initialized
INFO - 2021-07-01 10:00:03 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 10:00:03 --> Controller Class Initialized
INFO - 2021-07-01 10:00:03 --> Config Class Initialized
INFO - 2021-07-01 10:00:03 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:00:03 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:00:03 --> Utf8 Class Initialized
INFO - 2021-07-01 10:00:03 --> URI Class Initialized
INFO - 2021-07-01 10:00:03 --> Router Class Initialized
INFO - 2021-07-01 10:00:03 --> Output Class Initialized
INFO - 2021-07-01 10:00:03 --> Security Class Initialized
DEBUG - 2021-07-01 10:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:00:03 --> Input Class Initialized
INFO - 2021-07-01 10:00:03 --> Language Class Initialized
INFO - 2021-07-01 10:00:03 --> Loader Class Initialized
INFO - 2021-07-01 10:00:03 --> Helper loaded: basic_helper
INFO - 2021-07-01 10:00:03 --> Helper loaded: url_helper
INFO - 2021-07-01 10:00:03 --> Helper loaded: file_helper
INFO - 2021-07-01 10:00:03 --> Helper loaded: form_helper
INFO - 2021-07-01 10:00:03 --> Helper loaded: cookie_helper
INFO - 2021-07-01 10:00:03 --> Helper loaded: security_helper
INFO - 2021-07-01 10:00:03 --> Helper loaded: directory_helper
INFO - 2021-07-01 10:00:03 --> Helper loaded: language_helper
INFO - 2021-07-01 10:00:03 --> Helper loaded: general_helper
INFO - 2021-07-01 10:00:03 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 10:00:03 --> Database Driver Class Initialized
DEBUG - 2021-07-01 10:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 10:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:00:03 --> Parser Class Initialized
INFO - 2021-07-01 10:00:03 --> Form Validation Class Initialized
INFO - 2021-07-01 10:00:03 --> Upload Class Initialized
INFO - 2021-07-01 10:00:03 --> Email Class Initialized
INFO - 2021-07-01 10:00:03 --> MY_Model class loaded
INFO - 2021-07-01 10:00:03 --> Model "Users_model" initialized
INFO - 2021-07-01 10:00:03 --> Model "Settings_model" initialized
INFO - 2021-07-01 10:00:03 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 10:00:03 --> Model "Permissions_model" initialized
INFO - 2021-07-01 10:00:03 --> Model "Roles_model" initialized
INFO - 2021-07-01 10:00:03 --> Model "Activity_model" initialized
INFO - 2021-07-01 10:00:03 --> Model "Templates_model" initialized
INFO - 2021-07-01 10:00:03 --> Database Driver Class Initialized
INFO - 2021-07-01 10:00:03 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 10:00:03 --> Controller Class Initialized
INFO - 2021-07-01 13:00:03 --> File loaded: C:\wamp64\www\crm\application\views\account/login.php
INFO - 2021-07-01 13:00:03 --> Final output sent to browser
DEBUG - 2021-07-01 13:00:03 --> Total execution time: 0.0661
INFO - 2021-07-01 10:00:03 --> Config Class Initialized
INFO - 2021-07-01 10:00:03 --> Config Class Initialized
INFO - 2021-07-01 10:00:03 --> Hooks Class Initialized
INFO - 2021-07-01 10:00:03 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:00:03 --> UTF-8 Support Enabled
DEBUG - 2021-07-01 10:00:03 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:00:03 --> Utf8 Class Initialized
INFO - 2021-07-01 10:00:03 --> Utf8 Class Initialized
INFO - 2021-07-01 10:00:03 --> URI Class Initialized
INFO - 2021-07-01 10:00:03 --> URI Class Initialized
INFO - 2021-07-01 10:00:03 --> Router Class Initialized
INFO - 2021-07-01 10:00:03 --> Router Class Initialized
INFO - 2021-07-01 10:00:03 --> Output Class Initialized
INFO - 2021-07-01 10:00:03 --> Output Class Initialized
INFO - 2021-07-01 10:00:03 --> Security Class Initialized
INFO - 2021-07-01 10:00:03 --> Security Class Initialized
DEBUG - 2021-07-01 10:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-01 10:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:00:03 --> Input Class Initialized
INFO - 2021-07-01 10:00:03 --> Input Class Initialized
INFO - 2021-07-01 10:00:03 --> Language Class Initialized
INFO - 2021-07-01 10:00:03 --> Language Class Initialized
ERROR - 2021-07-01 10:00:03 --> 404 Page Not Found: Assets/jquery
ERROR - 2021-07-01 10:00:03 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-01 10:00:03 --> Config Class Initialized
INFO - 2021-07-01 10:00:03 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:00:03 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:00:03 --> Utf8 Class Initialized
INFO - 2021-07-01 10:00:03 --> URI Class Initialized
INFO - 2021-07-01 10:00:03 --> Router Class Initialized
INFO - 2021-07-01 10:00:03 --> Output Class Initialized
INFO - 2021-07-01 10:00:03 --> Security Class Initialized
DEBUG - 2021-07-01 10:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:00:03 --> Input Class Initialized
INFO - 2021-07-01 10:00:03 --> Language Class Initialized
ERROR - 2021-07-01 10:00:03 --> 404 Page Not Found: Assets/jquery
INFO - 2021-07-01 10:00:03 --> Config Class Initialized
INFO - 2021-07-01 10:00:03 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:00:03 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:00:03 --> Utf8 Class Initialized
INFO - 2021-07-01 10:00:03 --> URI Class Initialized
INFO - 2021-07-01 10:00:03 --> Router Class Initialized
INFO - 2021-07-01 10:00:03 --> Output Class Initialized
INFO - 2021-07-01 10:00:03 --> Security Class Initialized
DEBUG - 2021-07-01 10:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:00:03 --> Input Class Initialized
INFO - 2021-07-01 10:00:03 --> Language Class Initialized
ERROR - 2021-07-01 10:00:03 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-01 10:00:25 --> Config Class Initialized
INFO - 2021-07-01 10:00:25 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:00:25 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:00:25 --> Utf8 Class Initialized
INFO - 2021-07-01 10:00:25 --> URI Class Initialized
DEBUG - 2021-07-01 10:00:25 --> No URI present. Default controller set.
INFO - 2021-07-01 10:00:25 --> Router Class Initialized
INFO - 2021-07-01 10:00:25 --> Output Class Initialized
INFO - 2021-07-01 10:00:25 --> Security Class Initialized
DEBUG - 2021-07-01 10:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:00:25 --> Input Class Initialized
INFO - 2021-07-01 10:00:25 --> Language Class Initialized
INFO - 2021-07-01 10:00:25 --> Loader Class Initialized
INFO - 2021-07-01 10:00:25 --> Helper loaded: basic_helper
INFO - 2021-07-01 10:00:25 --> Helper loaded: url_helper
INFO - 2021-07-01 10:00:25 --> Helper loaded: file_helper
INFO - 2021-07-01 10:00:25 --> Helper loaded: form_helper
INFO - 2021-07-01 10:00:25 --> Helper loaded: cookie_helper
INFO - 2021-07-01 10:00:25 --> Helper loaded: security_helper
INFO - 2021-07-01 10:00:25 --> Helper loaded: directory_helper
INFO - 2021-07-01 10:00:25 --> Helper loaded: language_helper
INFO - 2021-07-01 10:00:25 --> Helper loaded: general_helper
INFO - 2021-07-01 10:00:25 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 10:00:25 --> Database Driver Class Initialized
DEBUG - 2021-07-01 10:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 10:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:00:25 --> Parser Class Initialized
INFO - 2021-07-01 10:00:25 --> Form Validation Class Initialized
INFO - 2021-07-01 10:00:25 --> Upload Class Initialized
INFO - 2021-07-01 10:00:25 --> Email Class Initialized
INFO - 2021-07-01 10:00:25 --> MY_Model class loaded
INFO - 2021-07-01 10:00:25 --> Model "Users_model" initialized
INFO - 2021-07-01 10:00:25 --> Model "Settings_model" initialized
INFO - 2021-07-01 10:00:25 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 10:00:25 --> Model "Permissions_model" initialized
INFO - 2021-07-01 10:00:25 --> Model "Roles_model" initialized
INFO - 2021-07-01 10:00:25 --> Model "Activity_model" initialized
INFO - 2021-07-01 10:00:25 --> Model "Templates_model" initialized
INFO - 2021-07-01 10:00:25 --> Database Driver Class Initialized
INFO - 2021-07-01 10:00:25 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 10:00:25 --> Controller Class Initialized
INFO - 2021-07-01 10:00:26 --> Config Class Initialized
INFO - 2021-07-01 10:00:26 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:00:26 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:00:26 --> Utf8 Class Initialized
INFO - 2021-07-01 10:00:26 --> URI Class Initialized
INFO - 2021-07-01 10:00:26 --> Router Class Initialized
INFO - 2021-07-01 10:00:26 --> Output Class Initialized
INFO - 2021-07-01 10:00:26 --> Security Class Initialized
DEBUG - 2021-07-01 10:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:00:26 --> Input Class Initialized
INFO - 2021-07-01 10:00:26 --> Language Class Initialized
INFO - 2021-07-01 10:00:26 --> Loader Class Initialized
INFO - 2021-07-01 10:00:26 --> Config Class Initialized
INFO - 2021-07-01 10:00:26 --> Helper loaded: basic_helper
INFO - 2021-07-01 10:00:26 --> Hooks Class Initialized
INFO - 2021-07-01 10:00:26 --> Helper loaded: url_helper
DEBUG - 2021-07-01 10:00:26 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:00:26 --> Utf8 Class Initialized
INFO - 2021-07-01 10:00:26 --> Helper loaded: file_helper
INFO - 2021-07-01 10:00:26 --> URI Class Initialized
INFO - 2021-07-01 10:00:26 --> Helper loaded: form_helper
INFO - 2021-07-01 10:00:26 --> Helper loaded: cookie_helper
INFO - 2021-07-01 10:00:26 --> Router Class Initialized
INFO - 2021-07-01 10:00:26 --> Helper loaded: security_helper
INFO - 2021-07-01 10:00:26 --> Output Class Initialized
INFO - 2021-07-01 10:00:26 --> Helper loaded: directory_helper
INFO - 2021-07-01 10:00:26 --> Security Class Initialized
INFO - 2021-07-01 10:00:26 --> Helper loaded: language_helper
DEBUG - 2021-07-01 10:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:00:26 --> Helper loaded: general_helper
INFO - 2021-07-01 10:00:26 --> Input Class Initialized
INFO - 2021-07-01 10:00:26 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 10:00:26 --> Language Class Initialized
INFO - 2021-07-01 10:00:26 --> Database Driver Class Initialized
ERROR - 2021-07-01 10:00:26 --> 404 Page Not Found: Faviconico/index
DEBUG - 2021-07-01 10:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 10:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:00:26 --> Parser Class Initialized
INFO - 2021-07-01 10:00:26 --> Form Validation Class Initialized
INFO - 2021-07-01 10:00:26 --> Upload Class Initialized
INFO - 2021-07-01 10:00:26 --> Email Class Initialized
INFO - 2021-07-01 10:00:26 --> MY_Model class loaded
INFO - 2021-07-01 10:00:26 --> Model "Users_model" initialized
INFO - 2021-07-01 10:00:26 --> Model "Settings_model" initialized
INFO - 2021-07-01 10:00:26 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 10:00:26 --> Model "Permissions_model" initialized
INFO - 2021-07-01 10:00:26 --> Model "Roles_model" initialized
INFO - 2021-07-01 10:00:26 --> Model "Activity_model" initialized
INFO - 2021-07-01 10:00:26 --> Model "Templates_model" initialized
INFO - 2021-07-01 10:00:26 --> Database Driver Class Initialized
INFO - 2021-07-01 10:00:26 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 10:00:26 --> Controller Class Initialized
INFO - 2021-07-01 13:00:26 --> File loaded: C:\wamp64\www\crm\application\views\account/login.php
INFO - 2021-07-01 13:00:26 --> Final output sent to browser
DEBUG - 2021-07-01 13:00:26 --> Total execution time: 0.0500
INFO - 2021-07-01 10:00:26 --> Config Class Initialized
INFO - 2021-07-01 10:00:26 --> Config Class Initialized
INFO - 2021-07-01 10:00:26 --> Hooks Class Initialized
INFO - 2021-07-01 10:00:26 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:00:26 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:00:26 --> Utf8 Class Initialized
DEBUG - 2021-07-01 10:00:26 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:00:26 --> Utf8 Class Initialized
INFO - 2021-07-01 10:00:26 --> URI Class Initialized
INFO - 2021-07-01 10:00:26 --> URI Class Initialized
INFO - 2021-07-01 10:00:26 --> Router Class Initialized
INFO - 2021-07-01 10:00:26 --> Router Class Initialized
INFO - 2021-07-01 10:00:26 --> Output Class Initialized
INFO - 2021-07-01 10:00:26 --> Output Class Initialized
INFO - 2021-07-01 10:00:26 --> Security Class Initialized
INFO - 2021-07-01 10:00:26 --> Security Class Initialized
DEBUG - 2021-07-01 10:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-01 10:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:00:26 --> Input Class Initialized
INFO - 2021-07-01 10:00:26 --> Input Class Initialized
INFO - 2021-07-01 10:00:26 --> Language Class Initialized
INFO - 2021-07-01 10:00:26 --> Language Class Initialized
ERROR - 2021-07-01 10:00:26 --> 404 Page Not Found: Assets/jquery
ERROR - 2021-07-01 10:00:26 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-01 10:00:26 --> Config Class Initialized
INFO - 2021-07-01 10:00:26 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:00:26 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:00:26 --> Utf8 Class Initialized
INFO - 2021-07-01 10:00:26 --> URI Class Initialized
INFO - 2021-07-01 10:00:26 --> Router Class Initialized
INFO - 2021-07-01 10:00:26 --> Output Class Initialized
INFO - 2021-07-01 10:00:26 --> Security Class Initialized
DEBUG - 2021-07-01 10:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:00:26 --> Input Class Initialized
INFO - 2021-07-01 10:00:26 --> Language Class Initialized
ERROR - 2021-07-01 10:00:26 --> 404 Page Not Found: Assets/jquery
INFO - 2021-07-01 10:00:26 --> Config Class Initialized
INFO - 2021-07-01 10:00:26 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:00:26 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:00:26 --> Utf8 Class Initialized
INFO - 2021-07-01 10:00:26 --> URI Class Initialized
INFO - 2021-07-01 10:00:26 --> Router Class Initialized
INFO - 2021-07-01 10:00:26 --> Output Class Initialized
INFO - 2021-07-01 10:00:26 --> Security Class Initialized
DEBUG - 2021-07-01 10:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:00:26 --> Input Class Initialized
INFO - 2021-07-01 10:00:26 --> Language Class Initialized
ERROR - 2021-07-01 10:00:26 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-01 10:00:46 --> Config Class Initialized
INFO - 2021-07-01 10:00:46 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:00:46 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:00:46 --> Utf8 Class Initialized
INFO - 2021-07-01 10:00:46 --> URI Class Initialized
INFO - 2021-07-01 10:00:46 --> Router Class Initialized
INFO - 2021-07-01 10:00:46 --> Output Class Initialized
INFO - 2021-07-01 10:00:46 --> Security Class Initialized
DEBUG - 2021-07-01 10:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:00:46 --> Input Class Initialized
INFO - 2021-07-01 10:00:46 --> Language Class Initialized
INFO - 2021-07-01 10:00:46 --> Loader Class Initialized
INFO - 2021-07-01 10:00:46 --> Helper loaded: basic_helper
INFO - 2021-07-01 10:00:46 --> Helper loaded: url_helper
INFO - 2021-07-01 10:00:46 --> Helper loaded: file_helper
INFO - 2021-07-01 10:00:46 --> Helper loaded: form_helper
INFO - 2021-07-01 10:00:46 --> Helper loaded: cookie_helper
INFO - 2021-07-01 10:00:46 --> Helper loaded: security_helper
INFO - 2021-07-01 10:00:46 --> Helper loaded: directory_helper
INFO - 2021-07-01 10:00:46 --> Helper loaded: language_helper
INFO - 2021-07-01 10:00:46 --> Helper loaded: general_helper
INFO - 2021-07-01 10:00:46 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 10:00:46 --> Database Driver Class Initialized
DEBUG - 2021-07-01 10:00:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 10:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:00:46 --> Parser Class Initialized
INFO - 2021-07-01 10:00:46 --> Form Validation Class Initialized
INFO - 2021-07-01 10:00:46 --> Upload Class Initialized
INFO - 2021-07-01 10:00:46 --> Email Class Initialized
INFO - 2021-07-01 10:00:46 --> MY_Model class loaded
INFO - 2021-07-01 10:00:46 --> Model "Users_model" initialized
INFO - 2021-07-01 10:00:46 --> Model "Settings_model" initialized
INFO - 2021-07-01 10:00:46 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 10:00:46 --> Model "Permissions_model" initialized
INFO - 2021-07-01 10:00:46 --> Model "Roles_model" initialized
INFO - 2021-07-01 10:00:46 --> Model "Activity_model" initialized
INFO - 2021-07-01 10:00:46 --> Model "Templates_model" initialized
INFO - 2021-07-01 10:00:46 --> Database Driver Class Initialized
INFO - 2021-07-01 10:00:46 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 10:00:46 --> Controller Class Initialized
DEBUG - 2021-07-01 13:00:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-01 13:00:46 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2021-07-01 10:00:46 --> Config Class Initialized
INFO - 2021-07-01 10:00:46 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:00:46 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:00:46 --> Utf8 Class Initialized
INFO - 2021-07-01 10:00:46 --> URI Class Initialized
DEBUG - 2021-07-01 10:00:46 --> No URI present. Default controller set.
INFO - 2021-07-01 10:00:46 --> Router Class Initialized
INFO - 2021-07-01 10:00:46 --> Output Class Initialized
INFO - 2021-07-01 10:00:46 --> Security Class Initialized
DEBUG - 2021-07-01 10:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:00:46 --> Input Class Initialized
INFO - 2021-07-01 10:00:46 --> Language Class Initialized
INFO - 2021-07-01 10:00:46 --> Loader Class Initialized
INFO - 2021-07-01 10:00:46 --> Helper loaded: basic_helper
INFO - 2021-07-01 10:00:46 --> Helper loaded: url_helper
INFO - 2021-07-01 10:00:46 --> Helper loaded: file_helper
INFO - 2021-07-01 10:00:46 --> Helper loaded: form_helper
INFO - 2021-07-01 10:00:46 --> Helper loaded: cookie_helper
INFO - 2021-07-01 10:00:46 --> Helper loaded: security_helper
INFO - 2021-07-01 10:00:46 --> Helper loaded: directory_helper
INFO - 2021-07-01 10:00:46 --> Helper loaded: language_helper
INFO - 2021-07-01 10:00:46 --> Helper loaded: general_helper
INFO - 2021-07-01 10:00:46 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 10:00:46 --> Database Driver Class Initialized
DEBUG - 2021-07-01 10:00:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 10:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:00:46 --> Parser Class Initialized
INFO - 2021-07-01 10:00:46 --> Form Validation Class Initialized
INFO - 2021-07-01 10:00:46 --> Upload Class Initialized
INFO - 2021-07-01 10:00:46 --> Email Class Initialized
INFO - 2021-07-01 10:00:46 --> MY_Model class loaded
INFO - 2021-07-01 10:00:46 --> Model "Users_model" initialized
INFO - 2021-07-01 10:00:46 --> Model "Settings_model" initialized
INFO - 2021-07-01 10:00:46 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 10:00:46 --> Model "Permissions_model" initialized
INFO - 2021-07-01 10:00:46 --> Model "Roles_model" initialized
INFO - 2021-07-01 10:00:46 --> Model "Activity_model" initialized
INFO - 2021-07-01 10:00:46 --> Model "Templates_model" initialized
INFO - 2021-07-01 10:00:46 --> Database Driver Class Initialized
INFO - 2021-07-01 10:00:46 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 10:00:46 --> Controller Class Initialized
ERROR - 2021-07-01 13:00:46 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-01 13:00:46 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-01 13:00:46 --> Final output sent to browser
DEBUG - 2021-07-01 13:00:46 --> Total execution time: 0.0646
INFO - 2021-07-01 10:00:49 --> Config Class Initialized
INFO - 2021-07-01 10:00:49 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:00:49 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:00:49 --> Utf8 Class Initialized
INFO - 2021-07-01 10:00:49 --> URI Class Initialized
INFO - 2021-07-01 10:00:49 --> Router Class Initialized
INFO - 2021-07-01 10:00:49 --> Output Class Initialized
INFO - 2021-07-01 10:00:49 --> Security Class Initialized
DEBUG - 2021-07-01 10:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:00:49 --> Input Class Initialized
INFO - 2021-07-01 10:00:49 --> Language Class Initialized
INFO - 2021-07-01 10:00:49 --> Loader Class Initialized
INFO - 2021-07-01 10:00:49 --> Helper loaded: basic_helper
INFO - 2021-07-01 10:00:49 --> Helper loaded: url_helper
INFO - 2021-07-01 10:00:49 --> Helper loaded: file_helper
INFO - 2021-07-01 10:00:49 --> Helper loaded: form_helper
INFO - 2021-07-01 10:00:49 --> Helper loaded: cookie_helper
INFO - 2021-07-01 10:00:49 --> Helper loaded: security_helper
INFO - 2021-07-01 10:00:49 --> Helper loaded: directory_helper
INFO - 2021-07-01 10:00:49 --> Helper loaded: language_helper
INFO - 2021-07-01 10:00:49 --> Helper loaded: general_helper
INFO - 2021-07-01 10:00:49 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 10:00:49 --> Database Driver Class Initialized
DEBUG - 2021-07-01 10:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 10:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:00:49 --> Parser Class Initialized
INFO - 2021-07-01 10:00:49 --> Form Validation Class Initialized
INFO - 2021-07-01 10:00:49 --> Upload Class Initialized
INFO - 2021-07-01 10:00:49 --> Email Class Initialized
INFO - 2021-07-01 10:00:49 --> MY_Model class loaded
INFO - 2021-07-01 10:00:49 --> Model "Users_model" initialized
INFO - 2021-07-01 10:00:49 --> Model "Settings_model" initialized
INFO - 2021-07-01 10:00:49 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 10:00:49 --> Model "Permissions_model" initialized
INFO - 2021-07-01 10:00:49 --> Model "Roles_model" initialized
INFO - 2021-07-01 10:00:49 --> Model "Activity_model" initialized
INFO - 2021-07-01 10:00:49 --> Model "Templates_model" initialized
INFO - 2021-07-01 10:00:49 --> Database Driver Class Initialized
INFO - 2021-07-01 10:00:49 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 10:00:49 --> Controller Class Initialized
ERROR - 2021-07-01 13:00:49 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-01 13:00:49 --> File loaded: C:\wamp64\www\crm\application\views\users/list.php
INFO - 2021-07-01 13:00:49 --> Final output sent to browser
DEBUG - 2021-07-01 13:00:49 --> Total execution time: 0.1208
INFO - 2021-07-01 10:00:50 --> Config Class Initialized
INFO - 2021-07-01 10:00:50 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:00:50 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:00:50 --> Utf8 Class Initialized
INFO - 2021-07-01 10:00:50 --> URI Class Initialized
INFO - 2021-07-01 10:00:50 --> Config Class Initialized
INFO - 2021-07-01 10:00:50 --> Router Class Initialized
INFO - 2021-07-01 10:00:50 --> Hooks Class Initialized
INFO - 2021-07-01 10:00:50 --> Output Class Initialized
DEBUG - 2021-07-01 10:00:50 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:00:50 --> Utf8 Class Initialized
INFO - 2021-07-01 10:00:50 --> Security Class Initialized
INFO - 2021-07-01 10:00:50 --> URI Class Initialized
DEBUG - 2021-07-01 10:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:00:50 --> Input Class Initialized
INFO - 2021-07-01 10:00:50 --> Language Class Initialized
INFO - 2021-07-01 10:00:50 --> Router Class Initialized
INFO - 2021-07-01 10:00:50 --> Output Class Initialized
INFO - 2021-07-01 10:00:50 --> Loader Class Initialized
INFO - 2021-07-01 10:00:50 --> Security Class Initialized
INFO - 2021-07-01 10:00:50 --> Helper loaded: basic_helper
DEBUG - 2021-07-01 10:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:00:50 --> Helper loaded: url_helper
INFO - 2021-07-01 10:00:50 --> Input Class Initialized
INFO - 2021-07-01 10:00:50 --> Config Class Initialized
INFO - 2021-07-01 10:00:50 --> Helper loaded: file_helper
INFO - 2021-07-01 10:00:50 --> Hooks Class Initialized
INFO - 2021-07-01 10:00:50 --> Language Class Initialized
INFO - 2021-07-01 10:00:50 --> Helper loaded: form_helper
DEBUG - 2021-07-01 10:00:50 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:00:50 --> Loader Class Initialized
INFO - 2021-07-01 10:00:50 --> Helper loaded: cookie_helper
INFO - 2021-07-01 10:00:50 --> Utf8 Class Initialized
INFO - 2021-07-01 10:00:50 --> Config Class Initialized
INFO - 2021-07-01 10:00:50 --> Hooks Class Initialized
INFO - 2021-07-01 10:00:50 --> Helper loaded: security_helper
INFO - 2021-07-01 10:00:50 --> URI Class Initialized
INFO - 2021-07-01 10:00:50 --> Helper loaded: basic_helper
INFO - 2021-07-01 10:00:50 --> Helper loaded: directory_helper
DEBUG - 2021-07-01 10:00:50 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:00:50 --> Helper loaded: url_helper
INFO - 2021-07-01 10:00:50 --> Utf8 Class Initialized
INFO - 2021-07-01 10:00:50 --> Router Class Initialized
INFO - 2021-07-01 10:00:50 --> Helper loaded: language_helper
INFO - 2021-07-01 10:00:50 --> Helper loaded: file_helper
INFO - 2021-07-01 10:00:50 --> URI Class Initialized
INFO - 2021-07-01 10:00:50 --> Helper loaded: general_helper
INFO - 2021-07-01 10:00:50 --> Output Class Initialized
INFO - 2021-07-01 10:00:50 --> Helper loaded: form_helper
INFO - 2021-07-01 10:00:50 --> Router Class Initialized
INFO - 2021-07-01 10:00:50 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 10:00:50 --> Security Class Initialized
INFO - 2021-07-01 10:00:50 --> Config Class Initialized
INFO - 2021-07-01 10:00:50 --> Helper loaded: cookie_helper
INFO - 2021-07-01 10:00:50 --> Output Class Initialized
DEBUG - 2021-07-01 10:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:00:50 --> Database Driver Class Initialized
INFO - 2021-07-01 10:00:50 --> Hooks Class Initialized
INFO - 2021-07-01 10:00:50 --> Helper loaded: security_helper
INFO - 2021-07-01 10:00:50 --> Input Class Initialized
INFO - 2021-07-01 10:00:50 --> Security Class Initialized
DEBUG - 2021-07-01 10:00:50 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:00:50 --> Helper loaded: directory_helper
INFO - 2021-07-01 10:00:50 --> Language Class Initialized
INFO - 2021-07-01 10:00:50 --> Utf8 Class Initialized
DEBUG - 2021-07-01 10:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:00:50 --> Helper loaded: language_helper
INFO - 2021-07-01 10:00:50 --> Input Class Initialized
INFO - 2021-07-01 10:00:50 --> URI Class Initialized
INFO - 2021-07-01 10:00:50 --> Loader Class Initialized
INFO - 2021-07-01 10:00:50 --> Helper loaded: general_helper
INFO - 2021-07-01 10:00:50 --> Language Class Initialized
DEBUG - 2021-07-01 10:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 10:00:50 --> Router Class Initialized
INFO - 2021-07-01 10:00:50 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 10:00:50 --> Helper loaded: basic_helper
INFO - 2021-07-01 10:00:50 --> Loader Class Initialized
INFO - 2021-07-01 10:00:50 --> Output Class Initialized
INFO - 2021-07-01 10:00:50 --> Helper loaded: url_helper
INFO - 2021-07-01 10:00:50 --> Database Driver Class Initialized
INFO - 2021-07-01 10:00:50 --> Helper loaded: basic_helper
INFO - 2021-07-01 10:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:00:50 --> Security Class Initialized
INFO - 2021-07-01 10:00:50 --> Helper loaded: file_helper
INFO - 2021-07-01 10:00:50 --> Helper loaded: url_helper
INFO - 2021-07-01 10:00:50 --> Parser Class Initialized
INFO - 2021-07-01 10:00:50 --> Helper loaded: form_helper
DEBUG - 2021-07-01 10:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:00:50 --> Helper loaded: file_helper
INFO - 2021-07-01 10:00:50 --> Input Class Initialized
INFO - 2021-07-01 10:00:50 --> Helper loaded: cookie_helper
INFO - 2021-07-01 10:00:50 --> Form Validation Class Initialized
INFO - 2021-07-01 10:00:50 --> Helper loaded: form_helper
INFO - 2021-07-01 10:00:50 --> Language Class Initialized
INFO - 2021-07-01 10:00:50 --> Helper loaded: security_helper
DEBUG - 2021-07-01 10:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 10:00:50 --> Upload Class Initialized
INFO - 2021-07-01 10:00:50 --> Helper loaded: cookie_helper
INFO - 2021-07-01 10:00:50 --> Helper loaded: directory_helper
INFO - 2021-07-01 10:00:50 --> Loader Class Initialized
INFO - 2021-07-01 10:00:50 --> Helper loaded: security_helper
INFO - 2021-07-01 10:00:50 --> Config Class Initialized
INFO - 2021-07-01 10:00:50 --> Email Class Initialized
INFO - 2021-07-01 10:00:50 --> Helper loaded: language_helper
INFO - 2021-07-01 10:00:50 --> Helper loaded: basic_helper
INFO - 2021-07-01 10:00:50 --> Hooks Class Initialized
INFO - 2021-07-01 10:00:50 --> Helper loaded: directory_helper
INFO - 2021-07-01 10:00:50 --> MY_Model class loaded
INFO - 2021-07-01 10:00:50 --> Helper loaded: general_helper
INFO - 2021-07-01 10:00:50 --> Helper loaded: url_helper
INFO - 2021-07-01 10:00:50 --> Helper loaded: language_helper
DEBUG - 2021-07-01 10:00:50 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:00:50 --> Model "Users_model" initialized
INFO - 2021-07-01 10:00:50 --> Utf8 Class Initialized
INFO - 2021-07-01 10:00:50 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 10:00:50 --> Helper loaded: file_helper
INFO - 2021-07-01 10:00:50 --> Helper loaded: general_helper
INFO - 2021-07-01 10:00:50 --> Model "Settings_model" initialized
INFO - 2021-07-01 10:00:50 --> URI Class Initialized
INFO - 2021-07-01 10:00:50 --> Helper loaded: form_helper
INFO - 2021-07-01 10:00:50 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 10:00:50 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 10:00:50 --> Database Driver Class Initialized
INFO - 2021-07-01 10:00:50 --> Model "Permissions_model" initialized
INFO - 2021-07-01 10:00:50 --> Helper loaded: cookie_helper
INFO - 2021-07-01 10:00:50 --> Database Driver Class Initialized
INFO - 2021-07-01 10:00:50 --> Model "Roles_model" initialized
INFO - 2021-07-01 10:00:50 --> Router Class Initialized
INFO - 2021-07-01 10:00:50 --> Helper loaded: security_helper
INFO - 2021-07-01 10:00:50 --> Model "Activity_model" initialized
INFO - 2021-07-01 10:00:50 --> Output Class Initialized
INFO - 2021-07-01 10:00:50 --> Model "Templates_model" initialized
INFO - 2021-07-01 10:00:50 --> Helper loaded: directory_helper
INFO - 2021-07-01 10:00:50 --> Security Class Initialized
INFO - 2021-07-01 10:00:50 --> Helper loaded: language_helper
INFO - 2021-07-01 10:00:50 --> Database Driver Class Initialized
DEBUG - 2021-07-01 10:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-07-01 10:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:00:50 --> Helper loaded: general_helper
DEBUG - 2021-07-01 10:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 10:00:50 --> Input Class Initialized
INFO - 2021-07-01 10:00:50 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 10:00:50 --> Language Class Initialized
INFO - 2021-07-01 10:00:50 --> Database Driver Class Initialized
INFO - 2021-07-01 10:00:50 --> Loader Class Initialized
INFO - 2021-07-01 10:00:50 --> Helper loaded: basic_helper
INFO - 2021-07-01 10:00:50 --> Helper loaded: url_helper
INFO - 2021-07-01 10:00:50 --> Helper loaded: file_helper
DEBUG - 2021-07-01 10:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 10:00:50 --> Helper loaded: form_helper
INFO - 2021-07-01 10:00:50 --> Helper loaded: cookie_helper
INFO - 2021-07-01 10:00:50 --> Helper loaded: security_helper
INFO - 2021-07-01 10:00:50 --> Helper loaded: directory_helper
INFO - 2021-07-01 10:00:50 --> Helper loaded: language_helper
INFO - 2021-07-01 10:00:50 --> Helper loaded: general_helper
INFO - 2021-07-01 10:00:50 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 10:00:50 --> Database Driver Class Initialized
DEBUG - 2021-07-01 10:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 10:00:50 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 10:00:50 --> Controller Class Initialized
INFO - 2021-07-01 13:00:50 --> Final output sent to browser
DEBUG - 2021-07-01 13:00:50 --> Total execution time: 0.0588
INFO - 2021-07-01 10:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:00:50 --> Parser Class Initialized
INFO - 2021-07-01 10:00:50 --> Form Validation Class Initialized
INFO - 2021-07-01 10:00:50 --> Upload Class Initialized
INFO - 2021-07-01 10:00:50 --> Email Class Initialized
INFO - 2021-07-01 10:00:50 --> MY_Model class loaded
INFO - 2021-07-01 10:00:50 --> Model "Users_model" initialized
INFO - 2021-07-01 10:00:50 --> Model "Settings_model" initialized
INFO - 2021-07-01 10:00:50 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 10:00:50 --> Model "Permissions_model" initialized
INFO - 2021-07-01 10:00:50 --> Model "Roles_model" initialized
INFO - 2021-07-01 10:00:50 --> Model "Activity_model" initialized
INFO - 2021-07-01 10:00:50 --> Model "Templates_model" initialized
INFO - 2021-07-01 10:00:50 --> Database Driver Class Initialized
INFO - 2021-07-01 10:00:50 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 10:00:50 --> Controller Class Initialized
INFO - 2021-07-01 13:00:50 --> Final output sent to browser
DEBUG - 2021-07-01 13:00:50 --> Total execution time: 0.0845
INFO - 2021-07-01 10:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:00:50 --> Parser Class Initialized
INFO - 2021-07-01 10:00:50 --> Form Validation Class Initialized
INFO - 2021-07-01 10:00:50 --> Upload Class Initialized
INFO - 2021-07-01 10:00:50 --> Email Class Initialized
INFO - 2021-07-01 10:00:50 --> MY_Model class loaded
INFO - 2021-07-01 10:00:50 --> Model "Users_model" initialized
INFO - 2021-07-01 10:00:50 --> Model "Settings_model" initialized
INFO - 2021-07-01 10:00:50 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 10:00:50 --> Model "Permissions_model" initialized
INFO - 2021-07-01 10:00:50 --> Model "Roles_model" initialized
INFO - 2021-07-01 10:00:50 --> Model "Activity_model" initialized
INFO - 2021-07-01 10:00:50 --> Model "Templates_model" initialized
INFO - 2021-07-01 10:00:50 --> Database Driver Class Initialized
INFO - 2021-07-01 10:00:50 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 10:00:50 --> Controller Class Initialized
INFO - 2021-07-01 13:00:50 --> Final output sent to browser
DEBUG - 2021-07-01 13:00:50 --> Total execution time: 0.1085
INFO - 2021-07-01 10:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:00:50 --> Parser Class Initialized
INFO - 2021-07-01 10:00:50 --> Form Validation Class Initialized
INFO - 2021-07-01 10:00:50 --> Upload Class Initialized
INFO - 2021-07-01 10:00:50 --> Email Class Initialized
INFO - 2021-07-01 10:00:50 --> MY_Model class loaded
INFO - 2021-07-01 10:00:50 --> Model "Users_model" initialized
INFO - 2021-07-01 10:00:50 --> Model "Settings_model" initialized
INFO - 2021-07-01 10:00:50 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 10:00:50 --> Model "Permissions_model" initialized
INFO - 2021-07-01 10:00:50 --> Model "Roles_model" initialized
INFO - 2021-07-01 10:00:50 --> Model "Activity_model" initialized
INFO - 2021-07-01 10:00:50 --> Model "Templates_model" initialized
INFO - 2021-07-01 10:00:50 --> Database Driver Class Initialized
INFO - 2021-07-01 10:00:50 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 10:00:50 --> Controller Class Initialized
INFO - 2021-07-01 13:00:50 --> Final output sent to browser
DEBUG - 2021-07-01 13:00:50 --> Total execution time: 0.1347
INFO - 2021-07-01 10:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:00:50 --> Parser Class Initialized
INFO - 2021-07-01 10:00:50 --> Form Validation Class Initialized
INFO - 2021-07-01 10:00:50 --> Upload Class Initialized
INFO - 2021-07-01 10:00:50 --> Email Class Initialized
INFO - 2021-07-01 10:00:50 --> MY_Model class loaded
INFO - 2021-07-01 10:00:50 --> Model "Users_model" initialized
INFO - 2021-07-01 10:00:50 --> Model "Settings_model" initialized
INFO - 2021-07-01 10:00:50 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 10:00:50 --> Model "Permissions_model" initialized
INFO - 2021-07-01 10:00:50 --> Model "Roles_model" initialized
INFO - 2021-07-01 10:00:50 --> Model "Activity_model" initialized
INFO - 2021-07-01 10:00:50 --> Model "Templates_model" initialized
INFO - 2021-07-01 10:00:50 --> Database Driver Class Initialized
INFO - 2021-07-01 10:00:50 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 10:00:50 --> Controller Class Initialized
INFO - 2021-07-01 13:00:50 --> Final output sent to browser
DEBUG - 2021-07-01 13:00:50 --> Total execution time: 0.1596
INFO - 2021-07-01 10:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:00:50 --> Parser Class Initialized
INFO - 2021-07-01 10:00:50 --> Form Validation Class Initialized
INFO - 2021-07-01 10:00:50 --> Upload Class Initialized
INFO - 2021-07-01 10:00:50 --> Email Class Initialized
INFO - 2021-07-01 10:00:50 --> MY_Model class loaded
INFO - 2021-07-01 10:00:50 --> Model "Users_model" initialized
INFO - 2021-07-01 10:00:50 --> Model "Settings_model" initialized
INFO - 2021-07-01 10:00:50 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 10:00:50 --> Model "Permissions_model" initialized
INFO - 2021-07-01 10:00:50 --> Model "Roles_model" initialized
INFO - 2021-07-01 10:00:50 --> Model "Activity_model" initialized
INFO - 2021-07-01 10:00:50 --> Model "Templates_model" initialized
INFO - 2021-07-01 10:00:50 --> Database Driver Class Initialized
INFO - 2021-07-01 10:00:50 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 10:00:50 --> Controller Class Initialized
INFO - 2021-07-01 13:00:50 --> Final output sent to browser
DEBUG - 2021-07-01 13:00:50 --> Total execution time: 0.1787
INFO - 2021-07-01 10:00:54 --> Config Class Initialized
INFO - 2021-07-01 10:00:54 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:00:54 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:00:54 --> Utf8 Class Initialized
INFO - 2021-07-01 10:00:54 --> URI Class Initialized
INFO - 2021-07-01 10:00:54 --> Router Class Initialized
INFO - 2021-07-01 10:00:54 --> Output Class Initialized
INFO - 2021-07-01 10:00:54 --> Security Class Initialized
DEBUG - 2021-07-01 10:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:00:54 --> Input Class Initialized
INFO - 2021-07-01 10:00:54 --> Language Class Initialized
INFO - 2021-07-01 10:00:54 --> Loader Class Initialized
INFO - 2021-07-01 10:00:54 --> Helper loaded: basic_helper
INFO - 2021-07-01 10:00:54 --> Helper loaded: url_helper
INFO - 2021-07-01 10:00:54 --> Helper loaded: file_helper
INFO - 2021-07-01 10:00:54 --> Helper loaded: form_helper
INFO - 2021-07-01 10:00:54 --> Helper loaded: cookie_helper
INFO - 2021-07-01 10:00:54 --> Helper loaded: security_helper
INFO - 2021-07-01 10:00:54 --> Helper loaded: directory_helper
INFO - 2021-07-01 10:00:54 --> Helper loaded: language_helper
INFO - 2021-07-01 10:00:54 --> Helper loaded: general_helper
INFO - 2021-07-01 10:00:54 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 10:00:54 --> Database Driver Class Initialized
DEBUG - 2021-07-01 10:00:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 10:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:00:54 --> Parser Class Initialized
INFO - 2021-07-01 10:00:54 --> Form Validation Class Initialized
INFO - 2021-07-01 10:00:54 --> Upload Class Initialized
INFO - 2021-07-01 10:00:54 --> Email Class Initialized
INFO - 2021-07-01 10:00:54 --> MY_Model class loaded
INFO - 2021-07-01 10:00:54 --> Model "Users_model" initialized
INFO - 2021-07-01 10:00:54 --> Model "Settings_model" initialized
INFO - 2021-07-01 10:00:54 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 10:00:54 --> Model "Permissions_model" initialized
INFO - 2021-07-01 10:00:54 --> Model "Roles_model" initialized
INFO - 2021-07-01 10:00:54 --> Model "Activity_model" initialized
INFO - 2021-07-01 10:00:54 --> Model "Templates_model" initialized
INFO - 2021-07-01 10:00:54 --> Database Driver Class Initialized
INFO - 2021-07-01 10:00:54 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 10:00:54 --> Controller Class Initialized
ERROR - 2021-07-01 13:00:54 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-01 13:00:54 --> File loaded: C:\wamp64\www\crm\application\views\users/edit.php
INFO - 2021-07-01 13:00:54 --> Final output sent to browser
DEBUG - 2021-07-01 13:00:54 --> Total execution time: 0.1458
INFO - 2021-07-01 10:01:03 --> Config Class Initialized
INFO - 2021-07-01 10:01:03 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:01:03 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:01:03 --> Utf8 Class Initialized
INFO - 2021-07-01 10:01:03 --> URI Class Initialized
INFO - 2021-07-01 10:01:03 --> Router Class Initialized
INFO - 2021-07-01 10:01:03 --> Output Class Initialized
INFO - 2021-07-01 10:01:03 --> Security Class Initialized
DEBUG - 2021-07-01 10:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:01:03 --> Input Class Initialized
INFO - 2021-07-01 10:01:03 --> Language Class Initialized
INFO - 2021-07-01 10:01:03 --> Loader Class Initialized
INFO - 2021-07-01 10:01:03 --> Helper loaded: basic_helper
INFO - 2021-07-01 10:01:03 --> Helper loaded: url_helper
INFO - 2021-07-01 10:01:03 --> Helper loaded: file_helper
INFO - 2021-07-01 10:01:03 --> Helper loaded: form_helper
INFO - 2021-07-01 10:01:03 --> Helper loaded: cookie_helper
INFO - 2021-07-01 10:01:03 --> Helper loaded: security_helper
INFO - 2021-07-01 10:01:03 --> Helper loaded: directory_helper
INFO - 2021-07-01 10:01:03 --> Helper loaded: language_helper
INFO - 2021-07-01 10:01:03 --> Helper loaded: general_helper
INFO - 2021-07-01 10:01:03 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 10:01:03 --> Database Driver Class Initialized
DEBUG - 2021-07-01 10:01:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 10:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:01:03 --> Parser Class Initialized
INFO - 2021-07-01 10:01:03 --> Form Validation Class Initialized
INFO - 2021-07-01 10:01:03 --> Upload Class Initialized
INFO - 2021-07-01 10:01:03 --> Email Class Initialized
INFO - 2021-07-01 10:01:03 --> MY_Model class loaded
INFO - 2021-07-01 10:01:03 --> Model "Users_model" initialized
INFO - 2021-07-01 10:01:03 --> Model "Settings_model" initialized
INFO - 2021-07-01 10:01:03 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 10:01:03 --> Model "Permissions_model" initialized
INFO - 2021-07-01 10:01:03 --> Model "Roles_model" initialized
INFO - 2021-07-01 10:01:03 --> Model "Activity_model" initialized
INFO - 2021-07-01 10:01:03 --> Model "Templates_model" initialized
INFO - 2021-07-01 10:01:03 --> Database Driver Class Initialized
INFO - 2021-07-01 10:01:03 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 10:01:03 --> Controller Class Initialized
INFO - 2021-07-01 13:01:03 --> Final output sent to browser
DEBUG - 2021-07-01 13:01:03 --> Total execution time: 0.1161
INFO - 2021-07-01 10:01:07 --> Config Class Initialized
INFO - 2021-07-01 10:01:07 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:01:07 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:01:07 --> Utf8 Class Initialized
INFO - 2021-07-01 10:01:07 --> URI Class Initialized
INFO - 2021-07-01 10:01:07 --> Router Class Initialized
INFO - 2021-07-01 10:01:07 --> Output Class Initialized
INFO - 2021-07-01 10:01:07 --> Security Class Initialized
DEBUG - 2021-07-01 10:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:01:07 --> Input Class Initialized
INFO - 2021-07-01 10:01:07 --> Language Class Initialized
INFO - 2021-07-01 10:01:07 --> Loader Class Initialized
INFO - 2021-07-01 10:01:07 --> Helper loaded: basic_helper
INFO - 2021-07-01 10:01:07 --> Helper loaded: url_helper
INFO - 2021-07-01 10:01:07 --> Helper loaded: file_helper
INFO - 2021-07-01 10:01:07 --> Helper loaded: form_helper
INFO - 2021-07-01 10:01:07 --> Helper loaded: cookie_helper
INFO - 2021-07-01 10:01:07 --> Helper loaded: security_helper
INFO - 2021-07-01 10:01:07 --> Helper loaded: directory_helper
INFO - 2021-07-01 10:01:07 --> Helper loaded: language_helper
INFO - 2021-07-01 10:01:07 --> Helper loaded: general_helper
INFO - 2021-07-01 10:01:07 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 10:01:07 --> Database Driver Class Initialized
DEBUG - 2021-07-01 10:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 10:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:01:07 --> Parser Class Initialized
INFO - 2021-07-01 10:01:07 --> Form Validation Class Initialized
INFO - 2021-07-01 10:01:07 --> Upload Class Initialized
INFO - 2021-07-01 10:01:07 --> Email Class Initialized
INFO - 2021-07-01 10:01:07 --> MY_Model class loaded
INFO - 2021-07-01 10:01:07 --> Model "Users_model" initialized
INFO - 2021-07-01 10:01:07 --> Model "Settings_model" initialized
INFO - 2021-07-01 10:01:07 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 10:01:07 --> Model "Permissions_model" initialized
INFO - 2021-07-01 10:01:07 --> Model "Roles_model" initialized
INFO - 2021-07-01 10:01:07 --> Model "Activity_model" initialized
INFO - 2021-07-01 10:01:07 --> Model "Templates_model" initialized
INFO - 2021-07-01 10:01:07 --> Database Driver Class Initialized
INFO - 2021-07-01 10:01:07 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 10:01:07 --> Controller Class Initialized
INFO - 2021-07-01 13:01:07 --> Final output sent to browser
DEBUG - 2021-07-01 13:01:07 --> Total execution time: 0.0644
INFO - 2021-07-01 10:01:07 --> Config Class Initialized
INFO - 2021-07-01 10:01:07 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:01:07 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:01:07 --> Utf8 Class Initialized
INFO - 2021-07-01 10:01:07 --> URI Class Initialized
INFO - 2021-07-01 10:01:07 --> Router Class Initialized
INFO - 2021-07-01 10:01:07 --> Output Class Initialized
INFO - 2021-07-01 10:01:07 --> Security Class Initialized
DEBUG - 2021-07-01 10:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:01:07 --> Input Class Initialized
INFO - 2021-07-01 10:01:07 --> Language Class Initialized
INFO - 2021-07-01 10:01:07 --> Loader Class Initialized
INFO - 2021-07-01 10:01:07 --> Helper loaded: basic_helper
INFO - 2021-07-01 10:01:07 --> Helper loaded: url_helper
INFO - 2021-07-01 10:01:07 --> Helper loaded: file_helper
INFO - 2021-07-01 10:01:07 --> Helper loaded: form_helper
INFO - 2021-07-01 10:01:07 --> Helper loaded: cookie_helper
INFO - 2021-07-01 10:01:07 --> Helper loaded: security_helper
INFO - 2021-07-01 10:01:07 --> Helper loaded: directory_helper
INFO - 2021-07-01 10:01:07 --> Helper loaded: language_helper
INFO - 2021-07-01 10:01:07 --> Helper loaded: general_helper
INFO - 2021-07-01 10:01:07 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 10:01:07 --> Database Driver Class Initialized
DEBUG - 2021-07-01 10:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 10:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:01:07 --> Parser Class Initialized
INFO - 2021-07-01 10:01:07 --> Form Validation Class Initialized
INFO - 2021-07-01 10:01:07 --> Upload Class Initialized
INFO - 2021-07-01 10:01:07 --> Email Class Initialized
INFO - 2021-07-01 10:01:07 --> MY_Model class loaded
INFO - 2021-07-01 10:01:07 --> Model "Users_model" initialized
INFO - 2021-07-01 10:01:07 --> Model "Settings_model" initialized
INFO - 2021-07-01 10:01:07 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 10:01:07 --> Model "Permissions_model" initialized
INFO - 2021-07-01 10:01:07 --> Model "Roles_model" initialized
INFO - 2021-07-01 10:01:07 --> Model "Activity_model" initialized
INFO - 2021-07-01 10:01:07 --> Model "Templates_model" initialized
INFO - 2021-07-01 10:01:07 --> Database Driver Class Initialized
INFO - 2021-07-01 10:01:07 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 10:01:07 --> Controller Class Initialized
INFO - 2021-07-01 10:01:07 --> Config Class Initialized
INFO - 2021-07-01 10:01:07 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:01:07 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:01:07 --> Utf8 Class Initialized
INFO - 2021-07-01 10:01:07 --> URI Class Initialized
INFO - 2021-07-01 10:01:07 --> Router Class Initialized
INFO - 2021-07-01 10:01:07 --> Output Class Initialized
INFO - 2021-07-01 10:01:07 --> Security Class Initialized
DEBUG - 2021-07-01 10:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:01:07 --> Input Class Initialized
INFO - 2021-07-01 10:01:07 --> Language Class Initialized
INFO - 2021-07-01 10:01:07 --> Loader Class Initialized
INFO - 2021-07-01 10:01:07 --> Helper loaded: basic_helper
INFO - 2021-07-01 10:01:07 --> Helper loaded: url_helper
INFO - 2021-07-01 10:01:07 --> Helper loaded: file_helper
INFO - 2021-07-01 10:01:07 --> Helper loaded: form_helper
INFO - 2021-07-01 10:01:07 --> Helper loaded: cookie_helper
INFO - 2021-07-01 10:01:07 --> Helper loaded: security_helper
INFO - 2021-07-01 10:01:07 --> Helper loaded: directory_helper
INFO - 2021-07-01 10:01:07 --> Helper loaded: language_helper
INFO - 2021-07-01 10:01:07 --> Helper loaded: general_helper
INFO - 2021-07-01 10:01:07 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 10:01:07 --> Database Driver Class Initialized
DEBUG - 2021-07-01 10:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 10:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:01:07 --> Parser Class Initialized
INFO - 2021-07-01 10:01:07 --> Form Validation Class Initialized
INFO - 2021-07-01 10:01:07 --> Upload Class Initialized
INFO - 2021-07-01 10:01:07 --> Email Class Initialized
INFO - 2021-07-01 10:01:07 --> MY_Model class loaded
INFO - 2021-07-01 10:01:07 --> Model "Users_model" initialized
INFO - 2021-07-01 10:01:07 --> Model "Settings_model" initialized
INFO - 2021-07-01 10:01:07 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 10:01:07 --> Model "Permissions_model" initialized
INFO - 2021-07-01 10:01:07 --> Model "Roles_model" initialized
INFO - 2021-07-01 10:01:07 --> Model "Activity_model" initialized
INFO - 2021-07-01 10:01:07 --> Model "Templates_model" initialized
INFO - 2021-07-01 10:01:07 --> Database Driver Class Initialized
INFO - 2021-07-01 10:01:07 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 10:01:07 --> Controller Class Initialized
ERROR - 2021-07-01 13:01:07 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-01 13:01:07 --> File loaded: C:\wamp64\www\crm\application\views\users/list.php
INFO - 2021-07-01 13:01:07 --> Final output sent to browser
DEBUG - 2021-07-01 13:01:07 --> Total execution time: 0.0945
INFO - 2021-07-01 10:01:07 --> Config Class Initialized
INFO - 2021-07-01 10:01:07 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:01:07 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:01:07 --> Utf8 Class Initialized
INFO - 2021-07-01 10:01:07 --> URI Class Initialized
INFO - 2021-07-01 10:01:07 --> Router Class Initialized
INFO - 2021-07-01 10:01:07 --> Config Class Initialized
INFO - 2021-07-01 10:01:07 --> Output Class Initialized
INFO - 2021-07-01 10:01:07 --> Hooks Class Initialized
INFO - 2021-07-01 10:01:07 --> Security Class Initialized
DEBUG - 2021-07-01 10:01:07 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:01:07 --> Utf8 Class Initialized
DEBUG - 2021-07-01 10:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:01:07 --> Input Class Initialized
INFO - 2021-07-01 10:01:07 --> URI Class Initialized
INFO - 2021-07-01 10:01:07 --> Language Class Initialized
INFO - 2021-07-01 10:01:07 --> Router Class Initialized
INFO - 2021-07-01 10:01:07 --> Loader Class Initialized
INFO - 2021-07-01 10:01:07 --> Output Class Initialized
INFO - 2021-07-01 10:01:07 --> Config Class Initialized
INFO - 2021-07-01 10:01:07 --> Helper loaded: basic_helper
INFO - 2021-07-01 10:01:07 --> Hooks Class Initialized
INFO - 2021-07-01 10:01:07 --> Security Class Initialized
INFO - 2021-07-01 10:01:07 --> Helper loaded: url_helper
DEBUG - 2021-07-01 10:01:07 --> UTF-8 Support Enabled
DEBUG - 2021-07-01 10:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:01:07 --> Utf8 Class Initialized
INFO - 2021-07-01 10:01:07 --> Input Class Initialized
INFO - 2021-07-01 10:01:07 --> Helper loaded: file_helper
INFO - 2021-07-01 10:01:07 --> URI Class Initialized
INFO - 2021-07-01 10:01:07 --> Language Class Initialized
INFO - 2021-07-01 10:01:07 --> Helper loaded: form_helper
INFO - 2021-07-01 10:01:07 --> Router Class Initialized
INFO - 2021-07-01 10:01:07 --> Helper loaded: cookie_helper
INFO - 2021-07-01 10:01:07 --> Loader Class Initialized
INFO - 2021-07-01 10:01:07 --> Output Class Initialized
INFO - 2021-07-01 10:01:07 --> Helper loaded: security_helper
INFO - 2021-07-01 10:01:07 --> Config Class Initialized
INFO - 2021-07-01 10:01:07 --> Helper loaded: basic_helper
INFO - 2021-07-01 10:01:07 --> Security Class Initialized
INFO - 2021-07-01 10:01:07 --> Helper loaded: directory_helper
INFO - 2021-07-01 10:01:07 --> Hooks Class Initialized
INFO - 2021-07-01 10:01:07 --> Helper loaded: url_helper
DEBUG - 2021-07-01 10:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:01:07 --> Helper loaded: language_helper
DEBUG - 2021-07-01 10:01:07 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:01:07 --> Input Class Initialized
INFO - 2021-07-01 10:01:07 --> Helper loaded: file_helper
INFO - 2021-07-01 10:01:07 --> Helper loaded: general_helper
INFO - 2021-07-01 10:01:07 --> Utf8 Class Initialized
INFO - 2021-07-01 10:01:07 --> Language Class Initialized
INFO - 2021-07-01 10:01:07 --> Config Class Initialized
INFO - 2021-07-01 10:01:07 --> Helper loaded: form_helper
INFO - 2021-07-01 10:01:07 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 10:01:07 --> URI Class Initialized
INFO - 2021-07-01 10:01:07 --> Hooks Class Initialized
INFO - 2021-07-01 10:01:07 --> Loader Class Initialized
INFO - 2021-07-01 10:01:07 --> Helper loaded: cookie_helper
INFO - 2021-07-01 10:01:07 --> Database Driver Class Initialized
DEBUG - 2021-07-01 10:01:07 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:01:07 --> Router Class Initialized
INFO - 2021-07-01 10:01:07 --> Utf8 Class Initialized
INFO - 2021-07-01 10:01:07 --> Helper loaded: security_helper
INFO - 2021-07-01 10:01:07 --> Helper loaded: basic_helper
INFO - 2021-07-01 10:01:07 --> Output Class Initialized
INFO - 2021-07-01 10:01:07 --> URI Class Initialized
INFO - 2021-07-01 10:01:07 --> Helper loaded: directory_helper
INFO - 2021-07-01 10:01:07 --> Config Class Initialized
INFO - 2021-07-01 10:01:07 --> Helper loaded: url_helper
INFO - 2021-07-01 10:01:07 --> Security Class Initialized
INFO - 2021-07-01 10:01:07 --> Hooks Class Initialized
INFO - 2021-07-01 10:01:07 --> Helper loaded: language_helper
DEBUG - 2021-07-01 10:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 10:01:07 --> Router Class Initialized
INFO - 2021-07-01 10:01:07 --> Helper loaded: file_helper
DEBUG - 2021-07-01 10:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:01:07 --> Helper loaded: general_helper
DEBUG - 2021-07-01 10:01:07 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:01:07 --> Input Class Initialized
INFO - 2021-07-01 10:01:07 --> Output Class Initialized
INFO - 2021-07-01 10:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:01:07 --> Helper loaded: form_helper
INFO - 2021-07-01 10:01:07 --> Utf8 Class Initialized
INFO - 2021-07-01 10:01:07 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 10:01:07 --> Language Class Initialized
INFO - 2021-07-01 10:01:07 --> Security Class Initialized
INFO - 2021-07-01 10:01:07 --> Helper loaded: cookie_helper
INFO - 2021-07-01 10:01:07 --> Parser Class Initialized
INFO - 2021-07-01 10:01:07 --> URI Class Initialized
INFO - 2021-07-01 10:01:07 --> Database Driver Class Initialized
INFO - 2021-07-01 10:01:07 --> Loader Class Initialized
DEBUG - 2021-07-01 10:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:01:07 --> Helper loaded: security_helper
INFO - 2021-07-01 10:01:07 --> Input Class Initialized
INFO - 2021-07-01 10:01:07 --> Form Validation Class Initialized
INFO - 2021-07-01 10:01:07 --> Router Class Initialized
INFO - 2021-07-01 10:01:07 --> Helper loaded: directory_helper
INFO - 2021-07-01 10:01:07 --> Helper loaded: basic_helper
INFO - 2021-07-01 10:01:07 --> Language Class Initialized
INFO - 2021-07-01 10:01:07 --> Helper loaded: language_helper
INFO - 2021-07-01 10:01:07 --> Output Class Initialized
INFO - 2021-07-01 10:01:07 --> Upload Class Initialized
INFO - 2021-07-01 10:01:07 --> Helper loaded: url_helper
INFO - 2021-07-01 10:01:07 --> Loader Class Initialized
INFO - 2021-07-01 10:01:07 --> Helper loaded: general_helper
DEBUG - 2021-07-01 10:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 10:01:07 --> Security Class Initialized
INFO - 2021-07-01 10:01:07 --> Email Class Initialized
INFO - 2021-07-01 10:01:07 --> Helper loaded: file_helper
INFO - 2021-07-01 10:01:07 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 10:01:07 --> Helper loaded: basic_helper
INFO - 2021-07-01 10:01:07 --> MY_Model class loaded
DEBUG - 2021-07-01 10:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:01:07 --> Helper loaded: form_helper
INFO - 2021-07-01 10:01:07 --> Input Class Initialized
INFO - 2021-07-01 10:01:07 --> Helper loaded: url_helper
INFO - 2021-07-01 10:01:07 --> Model "Users_model" initialized
INFO - 2021-07-01 10:01:07 --> Database Driver Class Initialized
INFO - 2021-07-01 10:01:07 --> Helper loaded: cookie_helper
INFO - 2021-07-01 10:01:07 --> Language Class Initialized
INFO - 2021-07-01 10:01:07 --> Model "Settings_model" initialized
INFO - 2021-07-01 10:01:07 --> Helper loaded: file_helper
INFO - 2021-07-01 10:01:07 --> Helper loaded: security_helper
INFO - 2021-07-01 10:01:07 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 10:01:07 --> Loader Class Initialized
INFO - 2021-07-01 10:01:07 --> Helper loaded: form_helper
INFO - 2021-07-01 10:01:07 --> Model "Permissions_model" initialized
INFO - 2021-07-01 10:01:07 --> Helper loaded: directory_helper
INFO - 2021-07-01 10:01:07 --> Helper loaded: cookie_helper
INFO - 2021-07-01 10:01:07 --> Model "Roles_model" initialized
INFO - 2021-07-01 10:01:07 --> Helper loaded: basic_helper
INFO - 2021-07-01 10:01:07 --> Helper loaded: language_helper
INFO - 2021-07-01 10:01:07 --> Model "Activity_model" initialized
INFO - 2021-07-01 10:01:07 --> Helper loaded: security_helper
DEBUG - 2021-07-01 10:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 10:01:07 --> Helper loaded: url_helper
INFO - 2021-07-01 10:01:07 --> Helper loaded: general_helper
INFO - 2021-07-01 10:01:07 --> Model "Templates_model" initialized
INFO - 2021-07-01 10:01:07 --> Helper loaded: directory_helper
INFO - 2021-07-01 10:01:07 --> Helper loaded: file_helper
INFO - 2021-07-01 10:01:07 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 10:01:07 --> Database Driver Class Initialized
INFO - 2021-07-01 10:01:07 --> Helper loaded: language_helper
INFO - 2021-07-01 10:01:07 --> Helper loaded: form_helper
INFO - 2021-07-01 10:01:07 --> Database Driver Class Initialized
INFO - 2021-07-01 10:01:07 --> Helper loaded: general_helper
INFO - 2021-07-01 10:01:07 --> Helper loaded: cookie_helper
INFO - 2021-07-01 10:01:07 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 10:01:07 --> Helper loaded: security_helper
INFO - 2021-07-01 10:01:07 --> Database Driver Class Initialized
INFO - 2021-07-01 10:01:07 --> Helper loaded: directory_helper
DEBUG - 2021-07-01 10:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 10:01:07 --> Helper loaded: language_helper
INFO - 2021-07-01 10:01:07 --> Helper loaded: general_helper
INFO - 2021-07-01 10:01:07 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 10:01:07 --> Database Driver Class Initialized
DEBUG - 2021-07-01 10:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 10:01:07 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 10:01:07 --> Controller Class Initialized
INFO - 2021-07-01 13:01:07 --> Final output sent to browser
DEBUG - 2021-07-01 13:01:07 --> Total execution time: 0.0598
INFO - 2021-07-01 10:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:01:07 --> Parser Class Initialized
INFO - 2021-07-01 10:01:07 --> Form Validation Class Initialized
INFO - 2021-07-01 10:01:07 --> Upload Class Initialized
INFO - 2021-07-01 10:01:07 --> Email Class Initialized
INFO - 2021-07-01 10:01:07 --> MY_Model class loaded
INFO - 2021-07-01 10:01:07 --> Model "Users_model" initialized
INFO - 2021-07-01 10:01:07 --> Model "Settings_model" initialized
DEBUG - 2021-07-01 10:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 10:01:07 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 10:01:07 --> Model "Permissions_model" initialized
INFO - 2021-07-01 10:01:07 --> Model "Roles_model" initialized
INFO - 2021-07-01 10:01:07 --> Model "Activity_model" initialized
INFO - 2021-07-01 10:01:07 --> Model "Templates_model" initialized
INFO - 2021-07-01 10:01:07 --> Database Driver Class Initialized
INFO - 2021-07-01 10:01:07 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 10:01:07 --> Controller Class Initialized
INFO - 2021-07-01 13:01:07 --> Final output sent to browser
DEBUG - 2021-07-01 13:01:07 --> Total execution time: 0.0854
INFO - 2021-07-01 10:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:01:07 --> Parser Class Initialized
INFO - 2021-07-01 10:01:07 --> Form Validation Class Initialized
INFO - 2021-07-01 10:01:07 --> Upload Class Initialized
INFO - 2021-07-01 10:01:07 --> Email Class Initialized
INFO - 2021-07-01 10:01:07 --> MY_Model class loaded
INFO - 2021-07-01 10:01:07 --> Model "Users_model" initialized
INFO - 2021-07-01 10:01:07 --> Model "Settings_model" initialized
INFO - 2021-07-01 10:01:07 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 10:01:07 --> Model "Permissions_model" initialized
INFO - 2021-07-01 10:01:07 --> Model "Roles_model" initialized
INFO - 2021-07-01 10:01:07 --> Model "Activity_model" initialized
INFO - 2021-07-01 10:01:07 --> Model "Templates_model" initialized
INFO - 2021-07-01 10:01:07 --> Database Driver Class Initialized
INFO - 2021-07-01 10:01:07 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 10:01:07 --> Controller Class Initialized
INFO - 2021-07-01 13:01:07 --> Final output sent to browser
DEBUG - 2021-07-01 13:01:07 --> Total execution time: 0.1090
INFO - 2021-07-01 10:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:01:07 --> Parser Class Initialized
INFO - 2021-07-01 10:01:07 --> Form Validation Class Initialized
INFO - 2021-07-01 10:01:07 --> Upload Class Initialized
INFO - 2021-07-01 10:01:07 --> Email Class Initialized
INFO - 2021-07-01 10:01:07 --> MY_Model class loaded
INFO - 2021-07-01 10:01:07 --> Model "Users_model" initialized
INFO - 2021-07-01 10:01:07 --> Model "Settings_model" initialized
INFO - 2021-07-01 10:01:07 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 10:01:07 --> Model "Permissions_model" initialized
INFO - 2021-07-01 10:01:07 --> Model "Roles_model" initialized
INFO - 2021-07-01 10:01:07 --> Model "Activity_model" initialized
INFO - 2021-07-01 10:01:07 --> Model "Templates_model" initialized
INFO - 2021-07-01 10:01:07 --> Database Driver Class Initialized
INFO - 2021-07-01 10:01:07 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 10:01:07 --> Controller Class Initialized
INFO - 2021-07-01 13:01:07 --> Final output sent to browser
DEBUG - 2021-07-01 13:01:07 --> Total execution time: 0.1320
INFO - 2021-07-01 10:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:01:07 --> Parser Class Initialized
INFO - 2021-07-01 10:01:07 --> Form Validation Class Initialized
INFO - 2021-07-01 10:01:07 --> Upload Class Initialized
INFO - 2021-07-01 10:01:07 --> Email Class Initialized
INFO - 2021-07-01 10:01:07 --> MY_Model class loaded
INFO - 2021-07-01 10:01:07 --> Model "Users_model" initialized
INFO - 2021-07-01 10:01:07 --> Model "Settings_model" initialized
INFO - 2021-07-01 10:01:07 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 10:01:07 --> Model "Permissions_model" initialized
INFO - 2021-07-01 10:01:07 --> Model "Roles_model" initialized
INFO - 2021-07-01 10:01:07 --> Model "Activity_model" initialized
INFO - 2021-07-01 10:01:07 --> Model "Templates_model" initialized
INFO - 2021-07-01 10:01:07 --> Database Driver Class Initialized
INFO - 2021-07-01 10:01:07 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 10:01:07 --> Controller Class Initialized
INFO - 2021-07-01 13:01:07 --> Final output sent to browser
DEBUG - 2021-07-01 13:01:07 --> Total execution time: 0.1536
INFO - 2021-07-01 10:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:01:07 --> Parser Class Initialized
INFO - 2021-07-01 10:01:07 --> Form Validation Class Initialized
INFO - 2021-07-01 10:01:07 --> Upload Class Initialized
INFO - 2021-07-01 10:01:07 --> Email Class Initialized
INFO - 2021-07-01 10:01:07 --> MY_Model class loaded
INFO - 2021-07-01 10:01:07 --> Model "Users_model" initialized
INFO - 2021-07-01 10:01:07 --> Model "Settings_model" initialized
INFO - 2021-07-01 10:01:07 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 10:01:07 --> Model "Permissions_model" initialized
INFO - 2021-07-01 10:01:07 --> Model "Roles_model" initialized
INFO - 2021-07-01 10:01:07 --> Model "Activity_model" initialized
INFO - 2021-07-01 10:01:07 --> Model "Templates_model" initialized
INFO - 2021-07-01 10:01:07 --> Database Driver Class Initialized
INFO - 2021-07-01 10:01:07 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 10:01:07 --> Controller Class Initialized
INFO - 2021-07-01 13:01:07 --> Final output sent to browser
DEBUG - 2021-07-01 13:01:07 --> Total execution time: 0.1865
INFO - 2021-07-01 10:01:10 --> Config Class Initialized
INFO - 2021-07-01 10:01:10 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:01:10 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:01:10 --> Utf8 Class Initialized
INFO - 2021-07-01 10:01:10 --> URI Class Initialized
INFO - 2021-07-01 10:01:10 --> Router Class Initialized
INFO - 2021-07-01 10:01:10 --> Output Class Initialized
INFO - 2021-07-01 10:01:10 --> Security Class Initialized
DEBUG - 2021-07-01 10:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:01:10 --> Input Class Initialized
INFO - 2021-07-01 10:01:10 --> Language Class Initialized
INFO - 2021-07-01 10:01:10 --> Loader Class Initialized
INFO - 2021-07-01 10:01:10 --> Helper loaded: basic_helper
INFO - 2021-07-01 10:01:10 --> Helper loaded: url_helper
INFO - 2021-07-01 10:01:10 --> Helper loaded: file_helper
INFO - 2021-07-01 10:01:10 --> Helper loaded: form_helper
INFO - 2021-07-01 10:01:10 --> Helper loaded: cookie_helper
INFO - 2021-07-01 10:01:10 --> Helper loaded: security_helper
INFO - 2021-07-01 10:01:10 --> Helper loaded: directory_helper
INFO - 2021-07-01 10:01:10 --> Helper loaded: language_helper
INFO - 2021-07-01 10:01:10 --> Helper loaded: general_helper
INFO - 2021-07-01 10:01:10 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 10:01:10 --> Database Driver Class Initialized
DEBUG - 2021-07-01 10:01:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 10:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:01:10 --> Parser Class Initialized
INFO - 2021-07-01 10:01:10 --> Form Validation Class Initialized
INFO - 2021-07-01 10:01:10 --> Upload Class Initialized
INFO - 2021-07-01 10:01:10 --> Email Class Initialized
INFO - 2021-07-01 10:01:10 --> MY_Model class loaded
INFO - 2021-07-01 10:01:10 --> Model "Users_model" initialized
INFO - 2021-07-01 10:01:10 --> Model "Settings_model" initialized
INFO - 2021-07-01 10:01:10 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 10:01:10 --> Model "Permissions_model" initialized
INFO - 2021-07-01 10:01:10 --> Model "Roles_model" initialized
INFO - 2021-07-01 10:01:10 --> Model "Activity_model" initialized
INFO - 2021-07-01 10:01:10 --> Model "Templates_model" initialized
INFO - 2021-07-01 10:01:10 --> Database Driver Class Initialized
INFO - 2021-07-01 10:01:10 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 10:01:10 --> Controller Class Initialized
INFO - 2021-07-01 10:01:10 --> Config Class Initialized
INFO - 2021-07-01 10:01:10 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:01:10 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:01:10 --> Utf8 Class Initialized
INFO - 2021-07-01 10:01:10 --> URI Class Initialized
INFO - 2021-07-01 10:01:10 --> Router Class Initialized
INFO - 2021-07-01 10:01:10 --> Output Class Initialized
INFO - 2021-07-01 10:01:10 --> Security Class Initialized
DEBUG - 2021-07-01 10:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:01:10 --> Input Class Initialized
INFO - 2021-07-01 10:01:10 --> Language Class Initialized
INFO - 2021-07-01 10:01:10 --> Loader Class Initialized
INFO - 2021-07-01 10:01:10 --> Helper loaded: basic_helper
INFO - 2021-07-01 10:01:10 --> Helper loaded: url_helper
INFO - 2021-07-01 10:01:10 --> Helper loaded: file_helper
INFO - 2021-07-01 10:01:10 --> Helper loaded: form_helper
INFO - 2021-07-01 10:01:10 --> Helper loaded: cookie_helper
INFO - 2021-07-01 10:01:10 --> Helper loaded: security_helper
INFO - 2021-07-01 10:01:10 --> Helper loaded: directory_helper
INFO - 2021-07-01 10:01:10 --> Helper loaded: language_helper
INFO - 2021-07-01 10:01:10 --> Helper loaded: general_helper
INFO - 2021-07-01 10:01:10 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 10:01:10 --> Database Driver Class Initialized
DEBUG - 2021-07-01 10:01:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 10:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:01:10 --> Parser Class Initialized
INFO - 2021-07-01 10:01:10 --> Form Validation Class Initialized
INFO - 2021-07-01 10:01:10 --> Upload Class Initialized
INFO - 2021-07-01 10:01:10 --> Email Class Initialized
INFO - 2021-07-01 10:01:10 --> MY_Model class loaded
INFO - 2021-07-01 10:01:10 --> Model "Users_model" initialized
INFO - 2021-07-01 10:01:10 --> Model "Settings_model" initialized
INFO - 2021-07-01 10:01:10 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 10:01:10 --> Model "Permissions_model" initialized
INFO - 2021-07-01 10:01:10 --> Model "Roles_model" initialized
INFO - 2021-07-01 10:01:10 --> Model "Activity_model" initialized
INFO - 2021-07-01 10:01:10 --> Model "Templates_model" initialized
INFO - 2021-07-01 10:01:10 --> Database Driver Class Initialized
INFO - 2021-07-01 10:01:10 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 10:01:10 --> Controller Class Initialized
INFO - 2021-07-01 13:01:10 --> File loaded: C:\wamp64\www\crm\application\views\account/login.php
INFO - 2021-07-01 13:01:10 --> Final output sent to browser
DEBUG - 2021-07-01 13:01:10 --> Total execution time: 0.0468
INFO - 2021-07-01 10:01:10 --> Config Class Initialized
INFO - 2021-07-01 10:01:10 --> Hooks Class Initialized
INFO - 2021-07-01 10:01:10 --> Config Class Initialized
INFO - 2021-07-01 10:01:10 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:01:10 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:01:11 --> Utf8 Class Initialized
DEBUG - 2021-07-01 10:01:11 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:01:11 --> Utf8 Class Initialized
INFO - 2021-07-01 10:01:11 --> URI Class Initialized
INFO - 2021-07-01 10:01:11 --> URI Class Initialized
INFO - 2021-07-01 10:01:11 --> Router Class Initialized
INFO - 2021-07-01 10:01:11 --> Router Class Initialized
INFO - 2021-07-01 10:01:11 --> Output Class Initialized
INFO - 2021-07-01 10:01:11 --> Output Class Initialized
INFO - 2021-07-01 10:01:11 --> Security Class Initialized
INFO - 2021-07-01 10:01:11 --> Security Class Initialized
DEBUG - 2021-07-01 10:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-01 10:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:01:11 --> Input Class Initialized
INFO - 2021-07-01 10:01:11 --> Input Class Initialized
INFO - 2021-07-01 10:01:11 --> Language Class Initialized
INFO - 2021-07-01 10:01:11 --> Language Class Initialized
ERROR - 2021-07-01 10:01:11 --> 404 Page Not Found: Assets/jquery
ERROR - 2021-07-01 10:01:11 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-01 10:01:11 --> Config Class Initialized
INFO - 2021-07-01 10:01:11 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:01:11 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:01:11 --> Utf8 Class Initialized
INFO - 2021-07-01 10:01:11 --> URI Class Initialized
INFO - 2021-07-01 10:01:11 --> Router Class Initialized
INFO - 2021-07-01 10:01:11 --> Output Class Initialized
INFO - 2021-07-01 10:01:11 --> Security Class Initialized
DEBUG - 2021-07-01 10:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:01:11 --> Input Class Initialized
INFO - 2021-07-01 10:01:11 --> Language Class Initialized
ERROR - 2021-07-01 10:01:11 --> 404 Page Not Found: Assets/jquery
INFO - 2021-07-01 10:01:11 --> Config Class Initialized
INFO - 2021-07-01 10:01:11 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:01:11 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:01:11 --> Utf8 Class Initialized
INFO - 2021-07-01 10:01:11 --> URI Class Initialized
INFO - 2021-07-01 10:01:11 --> Router Class Initialized
INFO - 2021-07-01 10:01:11 --> Output Class Initialized
INFO - 2021-07-01 10:01:11 --> Security Class Initialized
DEBUG - 2021-07-01 10:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:01:11 --> Input Class Initialized
INFO - 2021-07-01 10:01:11 --> Language Class Initialized
ERROR - 2021-07-01 10:01:11 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-01 10:04:29 --> Config Class Initialized
INFO - 2021-07-01 10:04:29 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:04:29 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:04:29 --> Utf8 Class Initialized
INFO - 2021-07-01 10:04:29 --> URI Class Initialized
INFO - 2021-07-01 10:04:29 --> Router Class Initialized
INFO - 2021-07-01 10:04:29 --> Output Class Initialized
INFO - 2021-07-01 10:04:29 --> Security Class Initialized
DEBUG - 2021-07-01 10:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:04:29 --> Input Class Initialized
INFO - 2021-07-01 10:04:29 --> Language Class Initialized
INFO - 2021-07-01 10:04:29 --> Loader Class Initialized
INFO - 2021-07-01 10:04:29 --> Helper loaded: basic_helper
INFO - 2021-07-01 10:04:29 --> Helper loaded: url_helper
INFO - 2021-07-01 10:04:29 --> Helper loaded: file_helper
INFO - 2021-07-01 10:04:29 --> Helper loaded: form_helper
INFO - 2021-07-01 10:04:29 --> Helper loaded: cookie_helper
INFO - 2021-07-01 10:04:29 --> Helper loaded: security_helper
INFO - 2021-07-01 10:04:29 --> Helper loaded: directory_helper
INFO - 2021-07-01 10:04:29 --> Helper loaded: language_helper
INFO - 2021-07-01 10:04:29 --> Helper loaded: general_helper
INFO - 2021-07-01 10:04:29 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 10:04:29 --> Database Driver Class Initialized
DEBUG - 2021-07-01 10:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 10:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:04:29 --> Parser Class Initialized
INFO - 2021-07-01 10:04:29 --> Form Validation Class Initialized
INFO - 2021-07-01 10:04:29 --> Upload Class Initialized
INFO - 2021-07-01 10:04:29 --> Email Class Initialized
INFO - 2021-07-01 10:04:29 --> MY_Model class loaded
INFO - 2021-07-01 10:04:29 --> Model "Users_model" initialized
INFO - 2021-07-01 10:04:29 --> Model "Settings_model" initialized
INFO - 2021-07-01 10:04:29 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 10:04:29 --> Model "Permissions_model" initialized
INFO - 2021-07-01 10:04:29 --> Model "Roles_model" initialized
INFO - 2021-07-01 10:04:29 --> Model "Activity_model" initialized
INFO - 2021-07-01 10:04:29 --> Model "Templates_model" initialized
INFO - 2021-07-01 10:04:29 --> Database Driver Class Initialized
INFO - 2021-07-01 10:04:30 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 10:04:30 --> Controller Class Initialized
DEBUG - 2021-07-01 13:04:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-01 13:04:30 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2021-07-01 10:04:30 --> Config Class Initialized
INFO - 2021-07-01 10:04:30 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:04:30 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:04:30 --> Utf8 Class Initialized
INFO - 2021-07-01 10:04:30 --> URI Class Initialized
DEBUG - 2021-07-01 10:04:30 --> No URI present. Default controller set.
INFO - 2021-07-01 10:04:30 --> Router Class Initialized
INFO - 2021-07-01 10:04:30 --> Output Class Initialized
INFO - 2021-07-01 10:04:30 --> Security Class Initialized
DEBUG - 2021-07-01 10:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:04:30 --> Input Class Initialized
INFO - 2021-07-01 10:04:30 --> Language Class Initialized
INFO - 2021-07-01 10:04:30 --> Loader Class Initialized
INFO - 2021-07-01 10:04:30 --> Helper loaded: basic_helper
INFO - 2021-07-01 10:04:30 --> Helper loaded: url_helper
INFO - 2021-07-01 10:04:30 --> Helper loaded: file_helper
INFO - 2021-07-01 10:04:30 --> Helper loaded: form_helper
INFO - 2021-07-01 10:04:30 --> Helper loaded: cookie_helper
INFO - 2021-07-01 10:04:30 --> Helper loaded: security_helper
INFO - 2021-07-01 10:04:30 --> Helper loaded: directory_helper
INFO - 2021-07-01 10:04:30 --> Helper loaded: language_helper
INFO - 2021-07-01 10:04:30 --> Helper loaded: general_helper
INFO - 2021-07-01 10:04:30 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 10:04:30 --> Database Driver Class Initialized
DEBUG - 2021-07-01 10:04:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 10:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:04:30 --> Parser Class Initialized
INFO - 2021-07-01 10:04:30 --> Form Validation Class Initialized
INFO - 2021-07-01 10:04:30 --> Upload Class Initialized
INFO - 2021-07-01 10:04:30 --> Email Class Initialized
INFO - 2021-07-01 10:04:30 --> MY_Model class loaded
INFO - 2021-07-01 10:04:30 --> Model "Users_model" initialized
INFO - 2021-07-01 10:04:30 --> Model "Settings_model" initialized
INFO - 2021-07-01 10:04:30 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 10:04:30 --> Model "Permissions_model" initialized
INFO - 2021-07-01 10:04:30 --> Model "Roles_model" initialized
INFO - 2021-07-01 10:04:30 --> Model "Activity_model" initialized
INFO - 2021-07-01 10:04:30 --> Model "Templates_model" initialized
INFO - 2021-07-01 10:04:30 --> Database Driver Class Initialized
INFO - 2021-07-01 10:04:30 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 10:04:30 --> Controller Class Initialized
ERROR - 2021-07-01 13:04:30 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-01 13:04:30 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-01 13:04:30 --> Final output sent to browser
DEBUG - 2021-07-01 13:04:30 --> Total execution time: 0.0611
INFO - 2021-07-01 10:04:32 --> Config Class Initialized
INFO - 2021-07-01 10:04:32 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:04:32 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:04:32 --> Utf8 Class Initialized
INFO - 2021-07-01 10:04:32 --> URI Class Initialized
INFO - 2021-07-01 10:04:32 --> Router Class Initialized
INFO - 2021-07-01 10:04:32 --> Output Class Initialized
INFO - 2021-07-01 10:04:32 --> Security Class Initialized
DEBUG - 2021-07-01 10:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:04:32 --> Input Class Initialized
INFO - 2021-07-01 10:04:32 --> Language Class Initialized
INFO - 2021-07-01 10:04:32 --> Loader Class Initialized
INFO - 2021-07-01 10:04:32 --> Helper loaded: basic_helper
INFO - 2021-07-01 10:04:32 --> Helper loaded: url_helper
INFO - 2021-07-01 10:04:32 --> Helper loaded: file_helper
INFO - 2021-07-01 10:04:32 --> Helper loaded: form_helper
INFO - 2021-07-01 10:04:32 --> Helper loaded: cookie_helper
INFO - 2021-07-01 10:04:32 --> Helper loaded: security_helper
INFO - 2021-07-01 10:04:32 --> Helper loaded: directory_helper
INFO - 2021-07-01 10:04:32 --> Helper loaded: language_helper
INFO - 2021-07-01 10:04:32 --> Helper loaded: general_helper
INFO - 2021-07-01 10:04:32 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 10:04:32 --> Database Driver Class Initialized
DEBUG - 2021-07-01 10:04:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 10:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:04:32 --> Parser Class Initialized
INFO - 2021-07-01 10:04:32 --> Form Validation Class Initialized
INFO - 2021-07-01 10:04:32 --> Upload Class Initialized
INFO - 2021-07-01 10:04:32 --> Email Class Initialized
INFO - 2021-07-01 10:04:32 --> MY_Model class loaded
INFO - 2021-07-01 10:04:32 --> Model "Users_model" initialized
INFO - 2021-07-01 10:04:32 --> Model "Settings_model" initialized
INFO - 2021-07-01 10:04:32 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 10:04:32 --> Model "Permissions_model" initialized
INFO - 2021-07-01 10:04:32 --> Model "Roles_model" initialized
INFO - 2021-07-01 10:04:32 --> Model "Activity_model" initialized
INFO - 2021-07-01 10:04:32 --> Model "Templates_model" initialized
INFO - 2021-07-01 10:04:32 --> Database Driver Class Initialized
INFO - 2021-07-01 10:04:32 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 10:04:32 --> Controller Class Initialized
ERROR - 2021-07-01 13:04:32 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-01 13:04:32 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-01 13:04:32 --> Final output sent to browser
DEBUG - 2021-07-01 13:04:32 --> Total execution time: 0.2049
INFO - 2021-07-01 10:04:35 --> Config Class Initialized
INFO - 2021-07-01 10:04:35 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:04:35 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:04:35 --> Utf8 Class Initialized
INFO - 2021-07-01 10:04:35 --> URI Class Initialized
INFO - 2021-07-01 10:04:35 --> Router Class Initialized
INFO - 2021-07-01 10:04:35 --> Output Class Initialized
INFO - 2021-07-01 10:04:35 --> Security Class Initialized
DEBUG - 2021-07-01 10:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:04:35 --> Input Class Initialized
INFO - 2021-07-01 10:04:35 --> Language Class Initialized
INFO - 2021-07-01 10:04:35 --> Loader Class Initialized
INFO - 2021-07-01 10:04:35 --> Helper loaded: basic_helper
INFO - 2021-07-01 10:04:35 --> Helper loaded: url_helper
INFO - 2021-07-01 10:04:35 --> Helper loaded: file_helper
INFO - 2021-07-01 10:04:35 --> Helper loaded: form_helper
INFO - 2021-07-01 10:04:35 --> Helper loaded: cookie_helper
INFO - 2021-07-01 10:04:35 --> Helper loaded: security_helper
INFO - 2021-07-01 10:04:35 --> Helper loaded: directory_helper
INFO - 2021-07-01 10:04:35 --> Helper loaded: language_helper
INFO - 2021-07-01 10:04:35 --> Helper loaded: general_helper
INFO - 2021-07-01 10:04:35 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 10:04:35 --> Database Driver Class Initialized
DEBUG - 2021-07-01 10:04:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 10:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:04:35 --> Parser Class Initialized
INFO - 2021-07-01 10:04:35 --> Form Validation Class Initialized
INFO - 2021-07-01 10:04:35 --> Upload Class Initialized
INFO - 2021-07-01 10:04:35 --> Email Class Initialized
INFO - 2021-07-01 10:04:35 --> MY_Model class loaded
INFO - 2021-07-01 10:04:35 --> Model "Users_model" initialized
INFO - 2021-07-01 10:04:35 --> Model "Settings_model" initialized
INFO - 2021-07-01 10:04:35 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 10:04:35 --> Model "Permissions_model" initialized
INFO - 2021-07-01 10:04:35 --> Model "Roles_model" initialized
INFO - 2021-07-01 10:04:35 --> Model "Activity_model" initialized
INFO - 2021-07-01 10:04:35 --> Model "Templates_model" initialized
INFO - 2021-07-01 10:04:35 --> Database Driver Class Initialized
INFO - 2021-07-01 10:04:35 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 10:04:35 --> Controller Class Initialized
ERROR - 2021-07-01 13:04:35 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-01 13:04:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\crm\application\helpers\general_helper.php 25
INFO - 2021-07-01 13:04:35 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-01 13:04:35 --> Final output sent to browser
DEBUG - 2021-07-01 13:04:35 --> Total execution time: 0.1244
INFO - 2021-07-01 10:05:08 --> Config Class Initialized
INFO - 2021-07-01 10:05:08 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:05:08 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:05:08 --> Utf8 Class Initialized
INFO - 2021-07-01 10:05:08 --> URI Class Initialized
INFO - 2021-07-01 10:05:08 --> Router Class Initialized
INFO - 2021-07-01 10:05:08 --> Output Class Initialized
INFO - 2021-07-01 10:05:08 --> Security Class Initialized
DEBUG - 2021-07-01 10:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:05:08 --> Input Class Initialized
INFO - 2021-07-01 10:05:08 --> Language Class Initialized
INFO - 2021-07-01 10:05:08 --> Loader Class Initialized
INFO - 2021-07-01 10:05:08 --> Helper loaded: basic_helper
INFO - 2021-07-01 10:05:08 --> Helper loaded: url_helper
INFO - 2021-07-01 10:05:08 --> Helper loaded: file_helper
INFO - 2021-07-01 10:05:08 --> Helper loaded: form_helper
INFO - 2021-07-01 10:05:08 --> Helper loaded: cookie_helper
INFO - 2021-07-01 10:05:08 --> Helper loaded: security_helper
INFO - 2021-07-01 10:05:08 --> Helper loaded: directory_helper
INFO - 2021-07-01 10:05:08 --> Helper loaded: language_helper
INFO - 2021-07-01 10:05:08 --> Helper loaded: general_helper
INFO - 2021-07-01 10:05:08 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 10:05:08 --> Database Driver Class Initialized
DEBUG - 2021-07-01 10:05:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 10:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:05:08 --> Parser Class Initialized
INFO - 2021-07-01 10:05:08 --> Form Validation Class Initialized
INFO - 2021-07-01 10:05:08 --> Upload Class Initialized
INFO - 2021-07-01 10:05:08 --> Email Class Initialized
INFO - 2021-07-01 10:05:08 --> MY_Model class loaded
INFO - 2021-07-01 10:05:08 --> Model "Users_model" initialized
INFO - 2021-07-01 10:05:08 --> Model "Settings_model" initialized
INFO - 2021-07-01 10:05:08 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 10:05:08 --> Model "Permissions_model" initialized
INFO - 2021-07-01 10:05:08 --> Model "Roles_model" initialized
INFO - 2021-07-01 10:05:08 --> Model "Activity_model" initialized
INFO - 2021-07-01 10:05:08 --> Model "Templates_model" initialized
INFO - 2021-07-01 10:05:08 --> Database Driver Class Initialized
INFO - 2021-07-01 10:05:08 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 10:05:08 --> Controller Class Initialized
ERROR - 2021-07-01 13:05:08 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-01 13:05:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\crm\application\helpers\general_helper.php 25
INFO - 2021-07-01 13:05:08 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-01 13:05:08 --> Final output sent to browser
DEBUG - 2021-07-01 13:05:08 --> Total execution time: 0.1368
INFO - 2021-07-01 10:05:51 --> Config Class Initialized
INFO - 2021-07-01 10:05:51 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:05:51 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:05:51 --> Utf8 Class Initialized
INFO - 2021-07-01 10:05:51 --> URI Class Initialized
INFO - 2021-07-01 10:05:51 --> Router Class Initialized
INFO - 2021-07-01 10:05:51 --> Output Class Initialized
INFO - 2021-07-01 10:05:51 --> Security Class Initialized
DEBUG - 2021-07-01 10:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:05:51 --> Input Class Initialized
INFO - 2021-07-01 10:05:51 --> Language Class Initialized
INFO - 2021-07-01 10:05:51 --> Loader Class Initialized
INFO - 2021-07-01 10:05:51 --> Helper loaded: basic_helper
INFO - 2021-07-01 10:05:51 --> Helper loaded: url_helper
INFO - 2021-07-01 10:05:51 --> Helper loaded: file_helper
INFO - 2021-07-01 10:05:51 --> Helper loaded: form_helper
INFO - 2021-07-01 10:05:51 --> Helper loaded: cookie_helper
INFO - 2021-07-01 10:05:51 --> Helper loaded: security_helper
INFO - 2021-07-01 10:05:51 --> Helper loaded: directory_helper
INFO - 2021-07-01 10:05:51 --> Helper loaded: language_helper
INFO - 2021-07-01 10:05:51 --> Helper loaded: general_helper
INFO - 2021-07-01 10:05:51 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 10:05:51 --> Database Driver Class Initialized
DEBUG - 2021-07-01 10:05:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 10:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:05:51 --> Parser Class Initialized
INFO - 2021-07-01 10:05:51 --> Form Validation Class Initialized
INFO - 2021-07-01 10:05:51 --> Upload Class Initialized
INFO - 2021-07-01 10:05:51 --> Email Class Initialized
INFO - 2021-07-01 10:05:51 --> MY_Model class loaded
INFO - 2021-07-01 10:05:51 --> Model "Users_model" initialized
INFO - 2021-07-01 10:05:51 --> Model "Settings_model" initialized
INFO - 2021-07-01 10:05:51 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 10:05:51 --> Model "Permissions_model" initialized
INFO - 2021-07-01 10:05:51 --> Model "Roles_model" initialized
INFO - 2021-07-01 10:05:51 --> Model "Activity_model" initialized
INFO - 2021-07-01 10:05:51 --> Model "Templates_model" initialized
INFO - 2021-07-01 10:05:51 --> Database Driver Class Initialized
INFO - 2021-07-01 10:05:51 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 10:05:51 --> Controller Class Initialized
ERROR - 2021-07-01 13:05:51 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-01 13:05:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\crm\application\helpers\general_helper.php 51
INFO - 2021-07-01 13:05:51 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-01 13:05:51 --> Final output sent to browser
DEBUG - 2021-07-01 13:05:51 --> Total execution time: 0.1402
INFO - 2021-07-01 10:05:53 --> Config Class Initialized
INFO - 2021-07-01 10:05:53 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:05:53 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:05:53 --> Utf8 Class Initialized
INFO - 2021-07-01 10:05:53 --> URI Class Initialized
INFO - 2021-07-01 10:05:53 --> Router Class Initialized
INFO - 2021-07-01 10:05:53 --> Output Class Initialized
INFO - 2021-07-01 10:05:53 --> Security Class Initialized
DEBUG - 2021-07-01 10:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:05:53 --> Input Class Initialized
INFO - 2021-07-01 10:05:53 --> Language Class Initialized
INFO - 2021-07-01 10:05:53 --> Loader Class Initialized
INFO - 2021-07-01 10:05:53 --> Helper loaded: basic_helper
INFO - 2021-07-01 10:05:53 --> Helper loaded: url_helper
INFO - 2021-07-01 10:05:53 --> Helper loaded: file_helper
INFO - 2021-07-01 10:05:53 --> Helper loaded: form_helper
INFO - 2021-07-01 10:05:53 --> Helper loaded: cookie_helper
INFO - 2021-07-01 10:05:53 --> Helper loaded: security_helper
INFO - 2021-07-01 10:05:53 --> Helper loaded: directory_helper
INFO - 2021-07-01 10:05:53 --> Helper loaded: language_helper
INFO - 2021-07-01 10:05:53 --> Helper loaded: general_helper
INFO - 2021-07-01 10:05:53 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 10:05:53 --> Database Driver Class Initialized
DEBUG - 2021-07-01 10:05:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 10:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:05:53 --> Parser Class Initialized
INFO - 2021-07-01 10:05:53 --> Form Validation Class Initialized
INFO - 2021-07-01 10:05:53 --> Upload Class Initialized
INFO - 2021-07-01 10:05:53 --> Email Class Initialized
INFO - 2021-07-01 10:05:53 --> MY_Model class loaded
INFO - 2021-07-01 10:05:53 --> Model "Users_model" initialized
INFO - 2021-07-01 10:05:53 --> Model "Settings_model" initialized
INFO - 2021-07-01 10:05:53 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 10:05:53 --> Model "Permissions_model" initialized
INFO - 2021-07-01 10:05:53 --> Model "Roles_model" initialized
INFO - 2021-07-01 10:05:53 --> Model "Activity_model" initialized
INFO - 2021-07-01 10:05:53 --> Model "Templates_model" initialized
INFO - 2021-07-01 10:05:53 --> Database Driver Class Initialized
INFO - 2021-07-01 10:05:53 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 10:05:53 --> Controller Class Initialized
ERROR - 2021-07-01 13:05:53 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-01 13:05:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\crm\application\helpers\general_helper.php 51
INFO - 2021-07-01 13:05:53 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-01 13:05:53 --> Final output sent to browser
DEBUG - 2021-07-01 13:05:53 --> Total execution time: 0.0727
INFO - 2021-07-01 10:05:53 --> Config Class Initialized
INFO - 2021-07-01 10:05:53 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:05:53 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:05:53 --> Utf8 Class Initialized
INFO - 2021-07-01 10:05:53 --> URI Class Initialized
INFO - 2021-07-01 10:05:53 --> Router Class Initialized
INFO - 2021-07-01 10:05:53 --> Output Class Initialized
INFO - 2021-07-01 10:05:53 --> Security Class Initialized
DEBUG - 2021-07-01 10:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:05:53 --> Input Class Initialized
INFO - 2021-07-01 10:05:53 --> Language Class Initialized
INFO - 2021-07-01 10:05:53 --> Loader Class Initialized
INFO - 2021-07-01 10:05:53 --> Helper loaded: basic_helper
INFO - 2021-07-01 10:05:53 --> Helper loaded: url_helper
INFO - 2021-07-01 10:05:53 --> Helper loaded: file_helper
INFO - 2021-07-01 10:05:53 --> Helper loaded: form_helper
INFO - 2021-07-01 10:05:53 --> Helper loaded: cookie_helper
INFO - 2021-07-01 10:05:53 --> Helper loaded: security_helper
INFO - 2021-07-01 10:05:53 --> Helper loaded: directory_helper
INFO - 2021-07-01 10:05:53 --> Helper loaded: language_helper
INFO - 2021-07-01 10:05:53 --> Helper loaded: general_helper
INFO - 2021-07-01 10:05:53 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 10:05:53 --> Database Driver Class Initialized
DEBUG - 2021-07-01 10:05:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 10:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:05:53 --> Parser Class Initialized
INFO - 2021-07-01 10:05:53 --> Form Validation Class Initialized
INFO - 2021-07-01 10:05:53 --> Upload Class Initialized
INFO - 2021-07-01 10:05:53 --> Email Class Initialized
INFO - 2021-07-01 10:05:53 --> MY_Model class loaded
INFO - 2021-07-01 10:05:53 --> Model "Users_model" initialized
INFO - 2021-07-01 10:05:53 --> Model "Settings_model" initialized
INFO - 2021-07-01 10:05:53 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 10:05:53 --> Model "Permissions_model" initialized
INFO - 2021-07-01 10:05:53 --> Model "Roles_model" initialized
INFO - 2021-07-01 10:05:53 --> Model "Activity_model" initialized
INFO - 2021-07-01 10:05:53 --> Model "Templates_model" initialized
INFO - 2021-07-01 10:05:53 --> Database Driver Class Initialized
INFO - 2021-07-01 10:05:53 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 10:05:53 --> Controller Class Initialized
ERROR - 2021-07-01 13:05:53 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-01 13:05:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\crm\application\helpers\general_helper.php 51
INFO - 2021-07-01 13:05:54 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-01 13:05:54 --> Final output sent to browser
DEBUG - 2021-07-01 13:05:54 --> Total execution time: 0.0692
INFO - 2021-07-01 10:06:51 --> Config Class Initialized
INFO - 2021-07-01 10:06:51 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:06:51 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:06:51 --> Utf8 Class Initialized
INFO - 2021-07-01 10:06:51 --> URI Class Initialized
INFO - 2021-07-01 10:06:51 --> Router Class Initialized
INFO - 2021-07-01 10:06:51 --> Output Class Initialized
INFO - 2021-07-01 10:06:51 --> Security Class Initialized
DEBUG - 2021-07-01 10:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:06:51 --> Input Class Initialized
INFO - 2021-07-01 10:06:51 --> Language Class Initialized
INFO - 2021-07-01 10:06:51 --> Loader Class Initialized
INFO - 2021-07-01 10:06:51 --> Helper loaded: basic_helper
INFO - 2021-07-01 10:06:51 --> Helper loaded: url_helper
INFO - 2021-07-01 10:06:51 --> Helper loaded: file_helper
INFO - 2021-07-01 10:06:51 --> Helper loaded: form_helper
INFO - 2021-07-01 10:06:51 --> Helper loaded: cookie_helper
INFO - 2021-07-01 10:06:51 --> Helper loaded: security_helper
INFO - 2021-07-01 10:06:51 --> Helper loaded: directory_helper
INFO - 2021-07-01 10:06:51 --> Helper loaded: language_helper
INFO - 2021-07-01 10:06:51 --> Helper loaded: general_helper
INFO - 2021-07-01 10:06:51 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 10:06:51 --> Database Driver Class Initialized
DEBUG - 2021-07-01 10:06:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 10:06:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:06:51 --> Parser Class Initialized
INFO - 2021-07-01 10:06:51 --> Form Validation Class Initialized
INFO - 2021-07-01 10:06:51 --> Upload Class Initialized
INFO - 2021-07-01 10:06:51 --> Email Class Initialized
INFO - 2021-07-01 10:06:51 --> MY_Model class loaded
INFO - 2021-07-01 10:06:51 --> Model "Users_model" initialized
INFO - 2021-07-01 10:06:51 --> Model "Settings_model" initialized
INFO - 2021-07-01 10:06:51 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 10:06:51 --> Model "Permissions_model" initialized
INFO - 2021-07-01 10:06:51 --> Model "Roles_model" initialized
INFO - 2021-07-01 10:06:51 --> Model "Activity_model" initialized
INFO - 2021-07-01 10:06:51 --> Model "Templates_model" initialized
INFO - 2021-07-01 10:06:51 --> Database Driver Class Initialized
INFO - 2021-07-01 10:06:51 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 10:06:51 --> Controller Class Initialized
ERROR - 2021-07-01 13:06:51 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-01 13:06:51 --> Severity: error --> Exception: Using $this when not in object context C:\wamp64\www\crm\application\helpers\general_helper.php 53
INFO - 2021-07-01 10:07:07 --> Config Class Initialized
INFO - 2021-07-01 10:07:07 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:07:07 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:07:07 --> Utf8 Class Initialized
INFO - 2021-07-01 10:07:07 --> URI Class Initialized
INFO - 2021-07-01 10:07:07 --> Router Class Initialized
INFO - 2021-07-01 10:07:07 --> Output Class Initialized
INFO - 2021-07-01 10:07:07 --> Security Class Initialized
DEBUG - 2021-07-01 10:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:07:07 --> Input Class Initialized
INFO - 2021-07-01 10:07:07 --> Language Class Initialized
INFO - 2021-07-01 10:07:07 --> Loader Class Initialized
INFO - 2021-07-01 10:07:07 --> Helper loaded: basic_helper
INFO - 2021-07-01 10:07:07 --> Helper loaded: url_helper
INFO - 2021-07-01 10:07:07 --> Helper loaded: file_helper
INFO - 2021-07-01 10:07:07 --> Helper loaded: form_helper
INFO - 2021-07-01 10:07:07 --> Helper loaded: cookie_helper
INFO - 2021-07-01 10:07:07 --> Helper loaded: security_helper
INFO - 2021-07-01 10:07:07 --> Helper loaded: directory_helper
INFO - 2021-07-01 10:07:07 --> Helper loaded: language_helper
INFO - 2021-07-01 10:07:07 --> Helper loaded: general_helper
INFO - 2021-07-01 10:07:07 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 10:07:07 --> Database Driver Class Initialized
DEBUG - 2021-07-01 10:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 10:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:07:07 --> Parser Class Initialized
INFO - 2021-07-01 10:07:07 --> Form Validation Class Initialized
INFO - 2021-07-01 10:07:07 --> Upload Class Initialized
INFO - 2021-07-01 10:07:07 --> Email Class Initialized
INFO - 2021-07-01 10:07:07 --> MY_Model class loaded
INFO - 2021-07-01 10:07:07 --> Model "Users_model" initialized
INFO - 2021-07-01 10:07:07 --> Model "Settings_model" initialized
INFO - 2021-07-01 10:07:07 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 10:07:07 --> Model "Permissions_model" initialized
INFO - 2021-07-01 10:07:07 --> Model "Roles_model" initialized
INFO - 2021-07-01 10:07:07 --> Model "Activity_model" initialized
INFO - 2021-07-01 10:07:07 --> Model "Templates_model" initialized
INFO - 2021-07-01 10:07:07 --> Database Driver Class Initialized
INFO - 2021-07-01 10:07:07 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 10:07:07 --> Controller Class Initialized
ERROR - 2021-07-01 13:07:07 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-01 13:07:07 --> Severity: error --> Exception: Using $this when not in object context C:\wamp64\www\crm\application\helpers\general_helper.php 53
INFO - 2021-07-01 10:07:29 --> Config Class Initialized
INFO - 2021-07-01 10:07:29 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:07:29 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:07:29 --> Utf8 Class Initialized
INFO - 2021-07-01 10:07:29 --> URI Class Initialized
INFO - 2021-07-01 10:07:29 --> Router Class Initialized
INFO - 2021-07-01 10:07:29 --> Output Class Initialized
INFO - 2021-07-01 10:07:29 --> Security Class Initialized
DEBUG - 2021-07-01 10:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:07:29 --> Input Class Initialized
INFO - 2021-07-01 10:07:29 --> Language Class Initialized
INFO - 2021-07-01 10:07:29 --> Loader Class Initialized
INFO - 2021-07-01 10:07:29 --> Helper loaded: basic_helper
INFO - 2021-07-01 10:07:29 --> Helper loaded: url_helper
INFO - 2021-07-01 10:07:29 --> Helper loaded: file_helper
INFO - 2021-07-01 10:07:29 --> Helper loaded: form_helper
INFO - 2021-07-01 10:07:29 --> Helper loaded: cookie_helper
INFO - 2021-07-01 10:07:29 --> Helper loaded: security_helper
INFO - 2021-07-01 10:07:29 --> Helper loaded: directory_helper
INFO - 2021-07-01 10:07:29 --> Helper loaded: language_helper
INFO - 2021-07-01 10:07:29 --> Helper loaded: general_helper
INFO - 2021-07-01 10:07:29 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 10:07:29 --> Database Driver Class Initialized
DEBUG - 2021-07-01 10:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 10:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:07:29 --> Parser Class Initialized
INFO - 2021-07-01 10:07:29 --> Form Validation Class Initialized
INFO - 2021-07-01 10:07:29 --> Upload Class Initialized
INFO - 2021-07-01 10:07:29 --> Email Class Initialized
INFO - 2021-07-01 10:07:29 --> MY_Model class loaded
INFO - 2021-07-01 10:07:29 --> Model "Users_model" initialized
INFO - 2021-07-01 10:07:29 --> Model "Settings_model" initialized
INFO - 2021-07-01 10:07:29 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 10:07:29 --> Model "Permissions_model" initialized
INFO - 2021-07-01 10:07:29 --> Model "Roles_model" initialized
INFO - 2021-07-01 10:07:29 --> Model "Activity_model" initialized
INFO - 2021-07-01 10:07:29 --> Model "Templates_model" initialized
INFO - 2021-07-01 10:07:29 --> Database Driver Class Initialized
INFO - 2021-07-01 10:07:29 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 10:07:29 --> Controller Class Initialized
ERROR - 2021-07-01 13:07:29 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-01 13:07:29 --> Severity: error --> Exception: Using $this when not in object context C:\wamp64\www\crm\application\helpers\general_helper.php 53
INFO - 2021-07-01 10:07:31 --> Config Class Initialized
INFO - 2021-07-01 10:07:31 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:07:31 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:07:31 --> Utf8 Class Initialized
INFO - 2021-07-01 10:07:31 --> URI Class Initialized
INFO - 2021-07-01 10:07:31 --> Router Class Initialized
INFO - 2021-07-01 10:07:31 --> Output Class Initialized
INFO - 2021-07-01 10:07:31 --> Security Class Initialized
DEBUG - 2021-07-01 10:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:07:31 --> Input Class Initialized
INFO - 2021-07-01 10:07:31 --> Language Class Initialized
INFO - 2021-07-01 10:07:31 --> Loader Class Initialized
INFO - 2021-07-01 10:07:31 --> Helper loaded: basic_helper
INFO - 2021-07-01 10:07:31 --> Helper loaded: url_helper
INFO - 2021-07-01 10:07:31 --> Helper loaded: file_helper
INFO - 2021-07-01 10:07:31 --> Helper loaded: form_helper
INFO - 2021-07-01 10:07:31 --> Helper loaded: cookie_helper
INFO - 2021-07-01 10:07:31 --> Helper loaded: security_helper
INFO - 2021-07-01 10:07:31 --> Helper loaded: directory_helper
INFO - 2021-07-01 10:07:31 --> Helper loaded: language_helper
INFO - 2021-07-01 10:07:31 --> Helper loaded: general_helper
INFO - 2021-07-01 10:07:31 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 10:07:31 --> Database Driver Class Initialized
DEBUG - 2021-07-01 10:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 10:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:07:31 --> Parser Class Initialized
INFO - 2021-07-01 10:07:31 --> Form Validation Class Initialized
INFO - 2021-07-01 10:07:31 --> Upload Class Initialized
INFO - 2021-07-01 10:07:31 --> Email Class Initialized
INFO - 2021-07-01 10:07:31 --> MY_Model class loaded
INFO - 2021-07-01 10:07:31 --> Model "Users_model" initialized
INFO - 2021-07-01 10:07:31 --> Model "Settings_model" initialized
INFO - 2021-07-01 10:07:31 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 10:07:31 --> Model "Permissions_model" initialized
INFO - 2021-07-01 10:07:31 --> Model "Roles_model" initialized
INFO - 2021-07-01 10:07:31 --> Model "Activity_model" initialized
INFO - 2021-07-01 10:07:31 --> Model "Templates_model" initialized
INFO - 2021-07-01 10:07:31 --> Database Driver Class Initialized
INFO - 2021-07-01 10:07:31 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 10:07:31 --> Controller Class Initialized
ERROR - 2021-07-01 13:07:31 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-01 13:07:31 --> Severity: error --> Exception: Using $this when not in object context C:\wamp64\www\crm\application\helpers\general_helper.php 53
INFO - 2021-07-01 10:07:32 --> Config Class Initialized
INFO - 2021-07-01 10:07:32 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:07:32 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:07:32 --> Utf8 Class Initialized
INFO - 2021-07-01 10:07:32 --> URI Class Initialized
INFO - 2021-07-01 10:07:32 --> Router Class Initialized
INFO - 2021-07-01 10:07:32 --> Output Class Initialized
INFO - 2021-07-01 10:07:32 --> Security Class Initialized
DEBUG - 2021-07-01 10:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:07:32 --> Input Class Initialized
INFO - 2021-07-01 10:07:32 --> Language Class Initialized
INFO - 2021-07-01 10:07:32 --> Loader Class Initialized
INFO - 2021-07-01 10:07:32 --> Helper loaded: basic_helper
INFO - 2021-07-01 10:07:32 --> Helper loaded: url_helper
INFO - 2021-07-01 10:07:32 --> Helper loaded: file_helper
INFO - 2021-07-01 10:07:32 --> Helper loaded: form_helper
INFO - 2021-07-01 10:07:32 --> Helper loaded: cookie_helper
INFO - 2021-07-01 10:07:32 --> Helper loaded: security_helper
INFO - 2021-07-01 10:07:32 --> Helper loaded: directory_helper
INFO - 2021-07-01 10:07:32 --> Helper loaded: language_helper
INFO - 2021-07-01 10:07:32 --> Helper loaded: general_helper
INFO - 2021-07-01 10:07:32 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 10:07:32 --> Database Driver Class Initialized
DEBUG - 2021-07-01 10:07:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 10:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:07:32 --> Parser Class Initialized
INFO - 2021-07-01 10:07:32 --> Form Validation Class Initialized
INFO - 2021-07-01 10:07:32 --> Upload Class Initialized
INFO - 2021-07-01 10:07:32 --> Email Class Initialized
INFO - 2021-07-01 10:07:32 --> MY_Model class loaded
INFO - 2021-07-01 10:07:32 --> Model "Users_model" initialized
INFO - 2021-07-01 10:07:32 --> Model "Settings_model" initialized
INFO - 2021-07-01 10:07:32 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 10:07:32 --> Model "Permissions_model" initialized
INFO - 2021-07-01 10:07:32 --> Model "Roles_model" initialized
INFO - 2021-07-01 10:07:32 --> Model "Activity_model" initialized
INFO - 2021-07-01 10:07:32 --> Model "Templates_model" initialized
INFO - 2021-07-01 10:07:32 --> Database Driver Class Initialized
INFO - 2021-07-01 10:07:32 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 10:07:32 --> Controller Class Initialized
ERROR - 2021-07-01 13:07:32 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-01 13:07:32 --> Severity: error --> Exception: Using $this when not in object context C:\wamp64\www\crm\application\helpers\general_helper.php 53
INFO - 2021-07-01 10:07:32 --> Config Class Initialized
INFO - 2021-07-01 10:07:32 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:07:32 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:07:32 --> Utf8 Class Initialized
INFO - 2021-07-01 10:07:32 --> URI Class Initialized
INFO - 2021-07-01 10:07:32 --> Router Class Initialized
INFO - 2021-07-01 10:07:32 --> Output Class Initialized
INFO - 2021-07-01 10:07:32 --> Security Class Initialized
DEBUG - 2021-07-01 10:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:07:32 --> Input Class Initialized
INFO - 2021-07-01 10:07:32 --> Language Class Initialized
INFO - 2021-07-01 10:07:32 --> Loader Class Initialized
INFO - 2021-07-01 10:07:32 --> Helper loaded: basic_helper
INFO - 2021-07-01 10:07:32 --> Helper loaded: url_helper
INFO - 2021-07-01 10:07:32 --> Helper loaded: file_helper
INFO - 2021-07-01 10:07:32 --> Helper loaded: form_helper
INFO - 2021-07-01 10:07:32 --> Helper loaded: cookie_helper
INFO - 2021-07-01 10:07:32 --> Helper loaded: security_helper
INFO - 2021-07-01 10:07:32 --> Helper loaded: directory_helper
INFO - 2021-07-01 10:07:32 --> Helper loaded: language_helper
INFO - 2021-07-01 10:07:32 --> Helper loaded: general_helper
INFO - 2021-07-01 10:07:32 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 10:07:32 --> Database Driver Class Initialized
DEBUG - 2021-07-01 10:07:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 10:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:07:32 --> Parser Class Initialized
INFO - 2021-07-01 10:07:32 --> Form Validation Class Initialized
INFO - 2021-07-01 10:07:32 --> Upload Class Initialized
INFO - 2021-07-01 10:07:32 --> Email Class Initialized
INFO - 2021-07-01 10:07:32 --> MY_Model class loaded
INFO - 2021-07-01 10:07:32 --> Model "Users_model" initialized
INFO - 2021-07-01 10:07:32 --> Model "Settings_model" initialized
INFO - 2021-07-01 10:07:32 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 10:07:32 --> Model "Permissions_model" initialized
INFO - 2021-07-01 10:07:32 --> Model "Roles_model" initialized
INFO - 2021-07-01 10:07:32 --> Model "Activity_model" initialized
INFO - 2021-07-01 10:07:32 --> Model "Templates_model" initialized
INFO - 2021-07-01 10:07:32 --> Database Driver Class Initialized
INFO - 2021-07-01 10:07:32 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 10:07:32 --> Controller Class Initialized
ERROR - 2021-07-01 13:07:32 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-01 13:07:32 --> Severity: error --> Exception: Using $this when not in object context C:\wamp64\www\crm\application\helpers\general_helper.php 53
INFO - 2021-07-01 10:07:33 --> Config Class Initialized
INFO - 2021-07-01 10:07:33 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:07:33 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:07:33 --> Utf8 Class Initialized
INFO - 2021-07-01 10:07:33 --> URI Class Initialized
INFO - 2021-07-01 10:07:33 --> Router Class Initialized
INFO - 2021-07-01 10:07:33 --> Output Class Initialized
INFO - 2021-07-01 10:07:33 --> Security Class Initialized
DEBUG - 2021-07-01 10:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:07:33 --> Input Class Initialized
INFO - 2021-07-01 10:07:33 --> Language Class Initialized
INFO - 2021-07-01 10:07:33 --> Loader Class Initialized
INFO - 2021-07-01 10:07:33 --> Helper loaded: basic_helper
INFO - 2021-07-01 10:07:33 --> Helper loaded: url_helper
INFO - 2021-07-01 10:07:33 --> Helper loaded: file_helper
INFO - 2021-07-01 10:07:33 --> Helper loaded: form_helper
INFO - 2021-07-01 10:07:33 --> Helper loaded: cookie_helper
INFO - 2021-07-01 10:07:33 --> Helper loaded: security_helper
INFO - 2021-07-01 10:07:33 --> Helper loaded: directory_helper
INFO - 2021-07-01 10:07:33 --> Helper loaded: language_helper
INFO - 2021-07-01 10:07:33 --> Helper loaded: general_helper
INFO - 2021-07-01 10:07:33 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 10:07:33 --> Database Driver Class Initialized
DEBUG - 2021-07-01 10:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 10:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:07:33 --> Parser Class Initialized
INFO - 2021-07-01 10:07:33 --> Form Validation Class Initialized
INFO - 2021-07-01 10:07:33 --> Upload Class Initialized
INFO - 2021-07-01 10:07:33 --> Email Class Initialized
INFO - 2021-07-01 10:07:33 --> MY_Model class loaded
INFO - 2021-07-01 10:07:33 --> Model "Users_model" initialized
INFO - 2021-07-01 10:07:33 --> Model "Settings_model" initialized
INFO - 2021-07-01 10:07:33 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 10:07:33 --> Model "Permissions_model" initialized
INFO - 2021-07-01 10:07:33 --> Model "Roles_model" initialized
INFO - 2021-07-01 10:07:33 --> Model "Activity_model" initialized
INFO - 2021-07-01 10:07:33 --> Model "Templates_model" initialized
INFO - 2021-07-01 10:07:33 --> Database Driver Class Initialized
INFO - 2021-07-01 10:07:33 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 10:07:33 --> Controller Class Initialized
ERROR - 2021-07-01 13:07:33 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-01 13:07:33 --> Severity: error --> Exception: Using $this when not in object context C:\wamp64\www\crm\application\helpers\general_helper.php 53
INFO - 2021-07-01 10:07:33 --> Config Class Initialized
INFO - 2021-07-01 10:07:33 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:07:33 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:07:33 --> Utf8 Class Initialized
INFO - 2021-07-01 10:07:33 --> URI Class Initialized
INFO - 2021-07-01 10:07:33 --> Router Class Initialized
INFO - 2021-07-01 10:07:33 --> Output Class Initialized
INFO - 2021-07-01 10:07:33 --> Security Class Initialized
DEBUG - 2021-07-01 10:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:07:33 --> Input Class Initialized
INFO - 2021-07-01 10:07:33 --> Language Class Initialized
INFO - 2021-07-01 10:07:33 --> Loader Class Initialized
INFO - 2021-07-01 10:07:33 --> Helper loaded: basic_helper
INFO - 2021-07-01 10:07:33 --> Helper loaded: url_helper
INFO - 2021-07-01 10:07:33 --> Helper loaded: file_helper
INFO - 2021-07-01 10:07:33 --> Helper loaded: form_helper
INFO - 2021-07-01 10:07:33 --> Helper loaded: cookie_helper
INFO - 2021-07-01 10:07:33 --> Helper loaded: security_helper
INFO - 2021-07-01 10:07:33 --> Helper loaded: directory_helper
INFO - 2021-07-01 10:07:33 --> Helper loaded: language_helper
INFO - 2021-07-01 10:07:33 --> Helper loaded: general_helper
INFO - 2021-07-01 10:07:33 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 10:07:33 --> Database Driver Class Initialized
DEBUG - 2021-07-01 10:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 10:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:07:33 --> Parser Class Initialized
INFO - 2021-07-01 10:07:33 --> Form Validation Class Initialized
INFO - 2021-07-01 10:07:33 --> Upload Class Initialized
INFO - 2021-07-01 10:07:33 --> Email Class Initialized
INFO - 2021-07-01 10:07:33 --> MY_Model class loaded
INFO - 2021-07-01 10:07:33 --> Model "Users_model" initialized
INFO - 2021-07-01 10:07:33 --> Model "Settings_model" initialized
INFO - 2021-07-01 10:07:33 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 10:07:33 --> Model "Permissions_model" initialized
INFO - 2021-07-01 10:07:33 --> Model "Roles_model" initialized
INFO - 2021-07-01 10:07:33 --> Model "Activity_model" initialized
INFO - 2021-07-01 10:07:33 --> Model "Templates_model" initialized
INFO - 2021-07-01 10:07:33 --> Database Driver Class Initialized
INFO - 2021-07-01 10:07:33 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 10:07:33 --> Controller Class Initialized
ERROR - 2021-07-01 13:07:33 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-01 13:07:33 --> Severity: error --> Exception: Using $this when not in object context C:\wamp64\www\crm\application\helpers\general_helper.php 53
INFO - 2021-07-01 10:08:27 --> Config Class Initialized
INFO - 2021-07-01 10:08:27 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:08:27 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:08:27 --> Utf8 Class Initialized
INFO - 2021-07-01 10:08:27 --> URI Class Initialized
INFO - 2021-07-01 10:08:27 --> Router Class Initialized
INFO - 2021-07-01 10:08:27 --> Output Class Initialized
INFO - 2021-07-01 10:08:27 --> Security Class Initialized
DEBUG - 2021-07-01 10:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:08:27 --> Input Class Initialized
INFO - 2021-07-01 10:08:27 --> Language Class Initialized
INFO - 2021-07-01 10:08:27 --> Loader Class Initialized
INFO - 2021-07-01 10:08:27 --> Helper loaded: basic_helper
INFO - 2021-07-01 10:08:27 --> Helper loaded: url_helper
INFO - 2021-07-01 10:08:27 --> Helper loaded: file_helper
INFO - 2021-07-01 10:08:27 --> Helper loaded: form_helper
INFO - 2021-07-01 10:08:27 --> Helper loaded: cookie_helper
INFO - 2021-07-01 10:08:27 --> Helper loaded: security_helper
INFO - 2021-07-01 10:08:27 --> Helper loaded: directory_helper
INFO - 2021-07-01 10:08:27 --> Helper loaded: language_helper
INFO - 2021-07-01 10:08:27 --> Helper loaded: general_helper
INFO - 2021-07-01 10:08:27 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 10:08:27 --> Database Driver Class Initialized
DEBUG - 2021-07-01 10:08:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 10:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:08:27 --> Parser Class Initialized
INFO - 2021-07-01 10:08:27 --> Form Validation Class Initialized
INFO - 2021-07-01 10:08:27 --> Upload Class Initialized
INFO - 2021-07-01 10:08:27 --> Email Class Initialized
INFO - 2021-07-01 10:08:27 --> MY_Model class loaded
INFO - 2021-07-01 10:08:27 --> Model "Users_model" initialized
INFO - 2021-07-01 10:08:27 --> Model "Settings_model" initialized
INFO - 2021-07-01 10:08:27 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 10:08:27 --> Model "Permissions_model" initialized
INFO - 2021-07-01 10:08:27 --> Model "Roles_model" initialized
INFO - 2021-07-01 10:08:27 --> Model "Activity_model" initialized
INFO - 2021-07-01 10:08:27 --> Model "Templates_model" initialized
INFO - 2021-07-01 10:08:27 --> Database Driver Class Initialized
INFO - 2021-07-01 10:08:27 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 10:08:27 --> Controller Class Initialized
ERROR - 2021-07-01 13:08:27 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-01 13:08:27 --> Severity: error --> Exception: Using $this when not in object context C:\wamp64\www\crm\application\helpers\general_helper.php 53
INFO - 2021-07-01 10:09:24 --> Config Class Initialized
INFO - 2021-07-01 10:09:24 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:09:24 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:09:24 --> Utf8 Class Initialized
INFO - 2021-07-01 10:09:24 --> URI Class Initialized
INFO - 2021-07-01 10:09:24 --> Router Class Initialized
INFO - 2021-07-01 10:09:24 --> Output Class Initialized
INFO - 2021-07-01 10:09:24 --> Security Class Initialized
DEBUG - 2021-07-01 10:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:09:24 --> Input Class Initialized
INFO - 2021-07-01 10:09:24 --> Language Class Initialized
INFO - 2021-07-01 10:09:24 --> Loader Class Initialized
INFO - 2021-07-01 10:09:24 --> Helper loaded: basic_helper
INFO - 2021-07-01 10:09:24 --> Helper loaded: url_helper
INFO - 2021-07-01 10:09:24 --> Helper loaded: file_helper
INFO - 2021-07-01 10:09:24 --> Helper loaded: form_helper
INFO - 2021-07-01 10:09:24 --> Helper loaded: cookie_helper
INFO - 2021-07-01 10:09:24 --> Helper loaded: security_helper
INFO - 2021-07-01 10:09:24 --> Helper loaded: directory_helper
INFO - 2021-07-01 10:09:24 --> Helper loaded: language_helper
INFO - 2021-07-01 10:09:24 --> Helper loaded: general_helper
INFO - 2021-07-01 10:09:24 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 10:09:24 --> Database Driver Class Initialized
DEBUG - 2021-07-01 10:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 10:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:09:24 --> Parser Class Initialized
INFO - 2021-07-01 10:09:24 --> Form Validation Class Initialized
INFO - 2021-07-01 10:09:24 --> Upload Class Initialized
INFO - 2021-07-01 10:09:24 --> Email Class Initialized
INFO - 2021-07-01 10:09:24 --> MY_Model class loaded
INFO - 2021-07-01 10:09:24 --> Model "Users_model" initialized
INFO - 2021-07-01 10:09:24 --> Model "Settings_model" initialized
INFO - 2021-07-01 10:09:24 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 10:09:24 --> Model "Permissions_model" initialized
INFO - 2021-07-01 10:09:24 --> Model "Roles_model" initialized
INFO - 2021-07-01 10:09:24 --> Model "Activity_model" initialized
INFO - 2021-07-01 10:09:24 --> Model "Templates_model" initialized
INFO - 2021-07-01 10:09:24 --> Database Driver Class Initialized
INFO - 2021-07-01 10:09:24 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 10:09:24 --> Controller Class Initialized
ERROR - 2021-07-01 13:09:24 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-01 13:09:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\crm\application\views\hesaplar\rapor_ayrinti.php 30
INFO - 2021-07-01 13:09:24 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-01 13:09:24 --> Final output sent to browser
DEBUG - 2021-07-01 13:09:24 --> Total execution time: 0.1218
INFO - 2021-07-01 10:10:47 --> Config Class Initialized
INFO - 2021-07-01 10:10:47 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:10:47 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:10:47 --> Utf8 Class Initialized
INFO - 2021-07-01 10:10:47 --> URI Class Initialized
INFO - 2021-07-01 10:10:47 --> Router Class Initialized
INFO - 2021-07-01 10:10:47 --> Output Class Initialized
INFO - 2021-07-01 10:10:47 --> Security Class Initialized
DEBUG - 2021-07-01 10:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:10:47 --> Input Class Initialized
INFO - 2021-07-01 10:10:47 --> Language Class Initialized
INFO - 2021-07-01 10:10:47 --> Loader Class Initialized
INFO - 2021-07-01 10:10:47 --> Helper loaded: basic_helper
INFO - 2021-07-01 10:10:47 --> Helper loaded: url_helper
INFO - 2021-07-01 10:10:47 --> Helper loaded: file_helper
INFO - 2021-07-01 10:10:47 --> Helper loaded: form_helper
INFO - 2021-07-01 10:10:47 --> Helper loaded: cookie_helper
INFO - 2021-07-01 10:10:47 --> Helper loaded: security_helper
INFO - 2021-07-01 10:10:47 --> Helper loaded: directory_helper
INFO - 2021-07-01 10:10:47 --> Helper loaded: language_helper
INFO - 2021-07-01 10:10:47 --> Helper loaded: general_helper
INFO - 2021-07-01 10:10:47 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 10:10:47 --> Database Driver Class Initialized
DEBUG - 2021-07-01 10:10:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 10:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:10:47 --> Parser Class Initialized
INFO - 2021-07-01 10:10:47 --> Form Validation Class Initialized
INFO - 2021-07-01 10:10:47 --> Upload Class Initialized
INFO - 2021-07-01 10:10:47 --> Email Class Initialized
INFO - 2021-07-01 10:10:47 --> MY_Model class loaded
INFO - 2021-07-01 10:10:47 --> Model "Users_model" initialized
INFO - 2021-07-01 10:10:47 --> Model "Settings_model" initialized
INFO - 2021-07-01 10:10:47 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 10:10:47 --> Model "Permissions_model" initialized
INFO - 2021-07-01 10:10:47 --> Model "Roles_model" initialized
INFO - 2021-07-01 10:10:47 --> Model "Activity_model" initialized
INFO - 2021-07-01 10:10:47 --> Model "Templates_model" initialized
INFO - 2021-07-01 10:10:47 --> Database Driver Class Initialized
INFO - 2021-07-01 10:10:47 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 10:10:47 --> Controller Class Initialized
ERROR - 2021-07-01 13:10:47 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-01 13:10:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\crm\application\views\hesaplar\rapor_ayrinti.php 30
INFO - 2021-07-01 13:10:47 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-01 13:10:47 --> Final output sent to browser
DEBUG - 2021-07-01 13:10:47 --> Total execution time: 0.5449
INFO - 2021-07-01 10:11:09 --> Config Class Initialized
INFO - 2021-07-01 10:11:09 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:11:09 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:11:09 --> Utf8 Class Initialized
INFO - 2021-07-01 10:11:09 --> URI Class Initialized
INFO - 2021-07-01 10:11:09 --> Router Class Initialized
INFO - 2021-07-01 10:11:09 --> Output Class Initialized
INFO - 2021-07-01 10:11:09 --> Security Class Initialized
DEBUG - 2021-07-01 10:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:11:09 --> Input Class Initialized
INFO - 2021-07-01 10:11:09 --> Language Class Initialized
INFO - 2021-07-01 10:11:09 --> Loader Class Initialized
INFO - 2021-07-01 10:11:09 --> Helper loaded: basic_helper
INFO - 2021-07-01 10:11:09 --> Helper loaded: url_helper
INFO - 2021-07-01 10:11:09 --> Helper loaded: file_helper
INFO - 2021-07-01 10:11:09 --> Helper loaded: form_helper
INFO - 2021-07-01 10:11:09 --> Helper loaded: cookie_helper
INFO - 2021-07-01 10:11:09 --> Helper loaded: security_helper
INFO - 2021-07-01 10:11:09 --> Helper loaded: directory_helper
INFO - 2021-07-01 10:11:09 --> Helper loaded: language_helper
INFO - 2021-07-01 10:11:09 --> Helper loaded: general_helper
INFO - 2021-07-01 10:11:09 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 10:11:09 --> Database Driver Class Initialized
DEBUG - 2021-07-01 10:11:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 10:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:11:09 --> Parser Class Initialized
INFO - 2021-07-01 10:11:09 --> Form Validation Class Initialized
INFO - 2021-07-01 10:11:09 --> Upload Class Initialized
INFO - 2021-07-01 10:11:09 --> Email Class Initialized
INFO - 2021-07-01 10:11:09 --> MY_Model class loaded
INFO - 2021-07-01 10:11:09 --> Model "Users_model" initialized
INFO - 2021-07-01 10:11:09 --> Model "Settings_model" initialized
INFO - 2021-07-01 10:11:09 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 10:11:09 --> Model "Permissions_model" initialized
INFO - 2021-07-01 10:11:09 --> Model "Roles_model" initialized
INFO - 2021-07-01 10:11:09 --> Model "Activity_model" initialized
INFO - 2021-07-01 10:11:09 --> Model "Templates_model" initialized
INFO - 2021-07-01 10:11:09 --> Database Driver Class Initialized
INFO - 2021-07-01 10:11:09 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 10:11:09 --> Controller Class Initialized
ERROR - 2021-07-01 13:11:09 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-01 13:11:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\crm\application\views\hesaplar\rapor_ayrinti.php 30
INFO - 2021-07-01 13:11:09 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-01 13:11:09 --> Final output sent to browser
DEBUG - 2021-07-01 13:11:09 --> Total execution time: 0.1349
INFO - 2021-07-01 10:11:10 --> Config Class Initialized
INFO - 2021-07-01 10:11:10 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:11:10 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:11:10 --> Utf8 Class Initialized
INFO - 2021-07-01 10:11:10 --> URI Class Initialized
INFO - 2021-07-01 10:11:10 --> Router Class Initialized
INFO - 2021-07-01 10:11:10 --> Output Class Initialized
INFO - 2021-07-01 10:11:10 --> Security Class Initialized
DEBUG - 2021-07-01 10:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:11:10 --> Input Class Initialized
INFO - 2021-07-01 10:11:10 --> Language Class Initialized
INFO - 2021-07-01 10:11:10 --> Loader Class Initialized
INFO - 2021-07-01 10:11:10 --> Helper loaded: basic_helper
INFO - 2021-07-01 10:11:10 --> Helper loaded: url_helper
INFO - 2021-07-01 10:11:10 --> Helper loaded: file_helper
INFO - 2021-07-01 10:11:10 --> Helper loaded: form_helper
INFO - 2021-07-01 10:11:10 --> Helper loaded: cookie_helper
INFO - 2021-07-01 10:11:10 --> Helper loaded: security_helper
INFO - 2021-07-01 10:11:10 --> Helper loaded: directory_helper
INFO - 2021-07-01 10:11:10 --> Helper loaded: language_helper
INFO - 2021-07-01 10:11:10 --> Helper loaded: general_helper
INFO - 2021-07-01 10:11:10 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 10:11:10 --> Database Driver Class Initialized
DEBUG - 2021-07-01 10:11:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 10:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:11:10 --> Parser Class Initialized
INFO - 2021-07-01 10:11:10 --> Form Validation Class Initialized
INFO - 2021-07-01 10:11:10 --> Upload Class Initialized
INFO - 2021-07-01 10:11:10 --> Email Class Initialized
INFO - 2021-07-01 10:11:10 --> MY_Model class loaded
INFO - 2021-07-01 10:11:10 --> Model "Users_model" initialized
INFO - 2021-07-01 10:11:10 --> Model "Settings_model" initialized
INFO - 2021-07-01 10:11:10 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 10:11:10 --> Model "Permissions_model" initialized
INFO - 2021-07-01 10:11:10 --> Model "Roles_model" initialized
INFO - 2021-07-01 10:11:10 --> Model "Activity_model" initialized
INFO - 2021-07-01 10:11:10 --> Model "Templates_model" initialized
INFO - 2021-07-01 10:11:10 --> Database Driver Class Initialized
INFO - 2021-07-01 10:11:11 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 10:11:11 --> Controller Class Initialized
ERROR - 2021-07-01 13:11:11 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-01 13:11:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\crm\application\views\hesaplar\rapor_ayrinti.php 30
INFO - 2021-07-01 13:11:11 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-01 13:11:11 --> Final output sent to browser
DEBUG - 2021-07-01 13:11:11 --> Total execution time: 0.0621
INFO - 2021-07-01 10:11:11 --> Config Class Initialized
INFO - 2021-07-01 10:11:11 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:11:11 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:11:11 --> Utf8 Class Initialized
INFO - 2021-07-01 10:11:11 --> URI Class Initialized
INFO - 2021-07-01 10:11:11 --> Router Class Initialized
INFO - 2021-07-01 10:11:11 --> Output Class Initialized
INFO - 2021-07-01 10:11:11 --> Security Class Initialized
DEBUG - 2021-07-01 10:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:11:11 --> Input Class Initialized
INFO - 2021-07-01 10:11:11 --> Language Class Initialized
INFO - 2021-07-01 10:11:11 --> Loader Class Initialized
INFO - 2021-07-01 10:11:11 --> Helper loaded: basic_helper
INFO - 2021-07-01 10:11:11 --> Helper loaded: url_helper
INFO - 2021-07-01 10:11:11 --> Helper loaded: file_helper
INFO - 2021-07-01 10:11:11 --> Helper loaded: form_helper
INFO - 2021-07-01 10:11:11 --> Helper loaded: cookie_helper
INFO - 2021-07-01 10:11:11 --> Helper loaded: security_helper
INFO - 2021-07-01 10:11:11 --> Helper loaded: directory_helper
INFO - 2021-07-01 10:11:11 --> Helper loaded: language_helper
INFO - 2021-07-01 10:11:11 --> Helper loaded: general_helper
INFO - 2021-07-01 10:11:11 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 10:11:11 --> Database Driver Class Initialized
DEBUG - 2021-07-01 10:11:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 10:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:11:11 --> Parser Class Initialized
INFO - 2021-07-01 10:11:11 --> Form Validation Class Initialized
INFO - 2021-07-01 10:11:11 --> Upload Class Initialized
INFO - 2021-07-01 10:11:11 --> Email Class Initialized
INFO - 2021-07-01 10:11:11 --> MY_Model class loaded
INFO - 2021-07-01 10:11:11 --> Model "Users_model" initialized
INFO - 2021-07-01 10:11:11 --> Model "Settings_model" initialized
INFO - 2021-07-01 10:11:11 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 10:11:11 --> Model "Permissions_model" initialized
INFO - 2021-07-01 10:11:11 --> Model "Roles_model" initialized
INFO - 2021-07-01 10:11:11 --> Model "Activity_model" initialized
INFO - 2021-07-01 10:11:11 --> Model "Templates_model" initialized
INFO - 2021-07-01 10:11:11 --> Database Driver Class Initialized
INFO - 2021-07-01 10:11:11 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 10:11:11 --> Controller Class Initialized
ERROR - 2021-07-01 13:11:11 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-01 13:11:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\crm\application\views\hesaplar\rapor_ayrinti.php 30
INFO - 2021-07-01 13:11:11 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-01 13:11:11 --> Final output sent to browser
DEBUG - 2021-07-01 13:11:11 --> Total execution time: 0.0587
INFO - 2021-07-01 10:11:12 --> Config Class Initialized
INFO - 2021-07-01 10:11:12 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:11:12 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:11:12 --> Utf8 Class Initialized
INFO - 2021-07-01 10:11:12 --> URI Class Initialized
INFO - 2021-07-01 10:11:12 --> Router Class Initialized
INFO - 2021-07-01 10:11:12 --> Output Class Initialized
INFO - 2021-07-01 10:11:12 --> Security Class Initialized
DEBUG - 2021-07-01 10:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:11:12 --> Input Class Initialized
INFO - 2021-07-01 10:11:12 --> Language Class Initialized
INFO - 2021-07-01 10:11:12 --> Loader Class Initialized
INFO - 2021-07-01 10:11:12 --> Helper loaded: basic_helper
INFO - 2021-07-01 10:11:12 --> Helper loaded: url_helper
INFO - 2021-07-01 10:11:12 --> Helper loaded: file_helper
INFO - 2021-07-01 10:11:12 --> Helper loaded: form_helper
INFO - 2021-07-01 10:11:12 --> Helper loaded: cookie_helper
INFO - 2021-07-01 10:11:12 --> Helper loaded: security_helper
INFO - 2021-07-01 10:11:12 --> Helper loaded: directory_helper
INFO - 2021-07-01 10:11:12 --> Helper loaded: language_helper
INFO - 2021-07-01 10:11:12 --> Helper loaded: general_helper
INFO - 2021-07-01 10:11:12 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 10:11:12 --> Database Driver Class Initialized
DEBUG - 2021-07-01 10:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 10:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:11:12 --> Parser Class Initialized
INFO - 2021-07-01 10:11:12 --> Form Validation Class Initialized
INFO - 2021-07-01 10:11:12 --> Upload Class Initialized
INFO - 2021-07-01 10:11:12 --> Email Class Initialized
INFO - 2021-07-01 10:11:12 --> MY_Model class loaded
INFO - 2021-07-01 10:11:12 --> Model "Users_model" initialized
INFO - 2021-07-01 10:11:12 --> Model "Settings_model" initialized
INFO - 2021-07-01 10:11:12 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 10:11:12 --> Model "Permissions_model" initialized
INFO - 2021-07-01 10:11:12 --> Model "Roles_model" initialized
INFO - 2021-07-01 10:11:12 --> Model "Activity_model" initialized
INFO - 2021-07-01 10:11:12 --> Model "Templates_model" initialized
INFO - 2021-07-01 10:11:12 --> Database Driver Class Initialized
INFO - 2021-07-01 10:11:12 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 10:11:12 --> Controller Class Initialized
ERROR - 2021-07-01 13:11:12 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-01 13:11:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\crm\application\views\hesaplar\rapor_ayrinti.php 30
INFO - 2021-07-01 13:11:12 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-01 13:11:12 --> Final output sent to browser
DEBUG - 2021-07-01 13:11:12 --> Total execution time: 0.0612
INFO - 2021-07-01 10:11:12 --> Config Class Initialized
INFO - 2021-07-01 10:11:12 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:11:12 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:11:12 --> Utf8 Class Initialized
INFO - 2021-07-01 10:11:12 --> URI Class Initialized
INFO - 2021-07-01 10:11:12 --> Router Class Initialized
INFO - 2021-07-01 10:11:12 --> Output Class Initialized
INFO - 2021-07-01 10:11:12 --> Security Class Initialized
DEBUG - 2021-07-01 10:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:11:12 --> Input Class Initialized
INFO - 2021-07-01 10:11:12 --> Language Class Initialized
INFO - 2021-07-01 10:11:12 --> Loader Class Initialized
INFO - 2021-07-01 10:11:12 --> Helper loaded: basic_helper
INFO - 2021-07-01 10:11:12 --> Helper loaded: url_helper
INFO - 2021-07-01 10:11:12 --> Helper loaded: file_helper
INFO - 2021-07-01 10:11:12 --> Helper loaded: form_helper
INFO - 2021-07-01 10:11:12 --> Helper loaded: cookie_helper
INFO - 2021-07-01 10:11:12 --> Helper loaded: security_helper
INFO - 2021-07-01 10:11:12 --> Helper loaded: directory_helper
INFO - 2021-07-01 10:11:12 --> Helper loaded: language_helper
INFO - 2021-07-01 10:11:12 --> Helper loaded: general_helper
INFO - 2021-07-01 10:11:12 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 10:11:12 --> Database Driver Class Initialized
DEBUG - 2021-07-01 10:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 10:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:11:12 --> Parser Class Initialized
INFO - 2021-07-01 10:11:12 --> Form Validation Class Initialized
INFO - 2021-07-01 10:11:12 --> Upload Class Initialized
INFO - 2021-07-01 10:11:12 --> Email Class Initialized
INFO - 2021-07-01 10:11:12 --> MY_Model class loaded
INFO - 2021-07-01 10:11:12 --> Model "Users_model" initialized
INFO - 2021-07-01 10:11:12 --> Model "Settings_model" initialized
INFO - 2021-07-01 10:11:12 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 10:11:12 --> Model "Permissions_model" initialized
INFO - 2021-07-01 10:11:12 --> Model "Roles_model" initialized
INFO - 2021-07-01 10:11:12 --> Model "Activity_model" initialized
INFO - 2021-07-01 10:11:12 --> Model "Templates_model" initialized
INFO - 2021-07-01 10:11:12 --> Database Driver Class Initialized
INFO - 2021-07-01 10:11:12 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 10:11:12 --> Controller Class Initialized
ERROR - 2021-07-01 13:11:12 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-01 13:11:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\crm\application\views\hesaplar\rapor_ayrinti.php 30
INFO - 2021-07-01 13:11:12 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-01 13:11:12 --> Final output sent to browser
DEBUG - 2021-07-01 13:11:12 --> Total execution time: 0.0611
INFO - 2021-07-01 10:11:12 --> Config Class Initialized
INFO - 2021-07-01 10:11:12 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:11:12 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:11:12 --> Utf8 Class Initialized
INFO - 2021-07-01 10:11:12 --> URI Class Initialized
INFO - 2021-07-01 10:11:12 --> Router Class Initialized
INFO - 2021-07-01 10:11:12 --> Output Class Initialized
INFO - 2021-07-01 10:11:12 --> Security Class Initialized
DEBUG - 2021-07-01 10:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:11:12 --> Input Class Initialized
INFO - 2021-07-01 10:11:12 --> Language Class Initialized
INFO - 2021-07-01 10:11:12 --> Loader Class Initialized
INFO - 2021-07-01 10:11:12 --> Helper loaded: basic_helper
INFO - 2021-07-01 10:11:12 --> Helper loaded: url_helper
INFO - 2021-07-01 10:11:12 --> Helper loaded: file_helper
INFO - 2021-07-01 10:11:12 --> Helper loaded: form_helper
INFO - 2021-07-01 10:11:12 --> Helper loaded: cookie_helper
INFO - 2021-07-01 10:11:12 --> Helper loaded: security_helper
INFO - 2021-07-01 10:11:12 --> Helper loaded: directory_helper
INFO - 2021-07-01 10:11:12 --> Helper loaded: language_helper
INFO - 2021-07-01 10:11:12 --> Helper loaded: general_helper
INFO - 2021-07-01 10:11:12 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 10:11:12 --> Database Driver Class Initialized
DEBUG - 2021-07-01 10:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 10:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:11:12 --> Parser Class Initialized
INFO - 2021-07-01 10:11:12 --> Form Validation Class Initialized
INFO - 2021-07-01 10:11:12 --> Upload Class Initialized
INFO - 2021-07-01 10:11:12 --> Email Class Initialized
INFO - 2021-07-01 10:11:12 --> MY_Model class loaded
INFO - 2021-07-01 10:11:12 --> Model "Users_model" initialized
INFO - 2021-07-01 10:11:12 --> Model "Settings_model" initialized
INFO - 2021-07-01 10:11:12 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 10:11:12 --> Model "Permissions_model" initialized
INFO - 2021-07-01 10:11:12 --> Model "Roles_model" initialized
INFO - 2021-07-01 10:11:12 --> Model "Activity_model" initialized
INFO - 2021-07-01 10:11:12 --> Model "Templates_model" initialized
INFO - 2021-07-01 10:11:12 --> Database Driver Class Initialized
INFO - 2021-07-01 10:11:12 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 10:11:12 --> Controller Class Initialized
ERROR - 2021-07-01 13:11:12 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-01 13:11:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\crm\application\views\hesaplar\rapor_ayrinti.php 30
INFO - 2021-07-01 13:11:12 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-01 13:11:12 --> Final output sent to browser
DEBUG - 2021-07-01 13:11:12 --> Total execution time: 0.0623
INFO - 2021-07-01 10:29:02 --> Config Class Initialized
INFO - 2021-07-01 10:29:02 --> Hooks Class Initialized
DEBUG - 2021-07-01 10:29:02 --> UTF-8 Support Enabled
INFO - 2021-07-01 10:29:02 --> Utf8 Class Initialized
INFO - 2021-07-01 10:29:02 --> URI Class Initialized
DEBUG - 2021-07-01 10:29:02 --> No URI present. Default controller set.
INFO - 2021-07-01 10:29:02 --> Router Class Initialized
INFO - 2021-07-01 10:29:02 --> Output Class Initialized
INFO - 2021-07-01 10:29:02 --> Security Class Initialized
DEBUG - 2021-07-01 10:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 10:29:02 --> Input Class Initialized
INFO - 2021-07-01 10:29:02 --> Language Class Initialized
INFO - 2021-07-01 10:29:02 --> Loader Class Initialized
INFO - 2021-07-01 10:29:02 --> Helper loaded: basic_helper
INFO - 2021-07-01 10:29:02 --> Helper loaded: url_helper
INFO - 2021-07-01 10:29:02 --> Helper loaded: file_helper
INFO - 2021-07-01 10:29:02 --> Helper loaded: form_helper
INFO - 2021-07-01 10:29:02 --> Helper loaded: cookie_helper
INFO - 2021-07-01 10:29:02 --> Helper loaded: security_helper
INFO - 2021-07-01 10:29:02 --> Helper loaded: directory_helper
INFO - 2021-07-01 10:29:02 --> Helper loaded: language_helper
INFO - 2021-07-01 10:29:02 --> Helper loaded: general_helper
INFO - 2021-07-01 10:29:02 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 10:29:02 --> Database Driver Class Initialized
DEBUG - 2021-07-01 10:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 10:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 10:29:02 --> Parser Class Initialized
INFO - 2021-07-01 10:29:02 --> Form Validation Class Initialized
INFO - 2021-07-01 10:29:02 --> Upload Class Initialized
INFO - 2021-07-01 10:29:02 --> Email Class Initialized
INFO - 2021-07-01 10:29:02 --> MY_Model class loaded
INFO - 2021-07-01 10:29:02 --> Model "Users_model" initialized
INFO - 2021-07-01 10:29:02 --> Model "Settings_model" initialized
INFO - 2021-07-01 10:29:02 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 10:29:02 --> Model "Permissions_model" initialized
INFO - 2021-07-01 10:29:02 --> Model "Roles_model" initialized
INFO - 2021-07-01 10:29:02 --> Model "Activity_model" initialized
INFO - 2021-07-01 10:29:02 --> Model "Templates_model" initialized
INFO - 2021-07-01 10:29:02 --> Database Driver Class Initialized
INFO - 2021-07-01 10:29:02 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 10:29:02 --> Controller Class Initialized
INFO - 2021-07-01 11:11:03 --> Config Class Initialized
INFO - 2021-07-01 11:11:03 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:11:03 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:11:03 --> Utf8 Class Initialized
INFO - 2021-07-01 11:11:03 --> URI Class Initialized
INFO - 2021-07-01 11:11:03 --> Router Class Initialized
INFO - 2021-07-01 11:11:03 --> Output Class Initialized
INFO - 2021-07-01 11:11:03 --> Security Class Initialized
DEBUG - 2021-07-01 11:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:11:03 --> Input Class Initialized
INFO - 2021-07-01 11:11:03 --> Language Class Initialized
INFO - 2021-07-01 11:11:03 --> Loader Class Initialized
INFO - 2021-07-01 11:11:03 --> Helper loaded: basic_helper
INFO - 2021-07-01 11:11:03 --> Helper loaded: url_helper
INFO - 2021-07-01 11:11:03 --> Helper loaded: file_helper
INFO - 2021-07-01 11:11:03 --> Helper loaded: form_helper
INFO - 2021-07-01 11:11:03 --> Helper loaded: cookie_helper
INFO - 2021-07-01 11:11:03 --> Helper loaded: security_helper
INFO - 2021-07-01 11:11:03 --> Helper loaded: directory_helper
INFO - 2021-07-01 11:11:03 --> Helper loaded: language_helper
INFO - 2021-07-01 11:11:03 --> Helper loaded: general_helper
INFO - 2021-07-01 11:11:03 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 11:11:03 --> Database Driver Class Initialized
DEBUG - 2021-07-01 11:11:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 11:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:11:03 --> Parser Class Initialized
INFO - 2021-07-01 11:11:03 --> Form Validation Class Initialized
INFO - 2021-07-01 11:11:03 --> Upload Class Initialized
INFO - 2021-07-01 11:11:03 --> Email Class Initialized
INFO - 2021-07-01 11:11:03 --> MY_Model class loaded
INFO - 2021-07-01 11:11:03 --> Model "Users_model" initialized
INFO - 2021-07-01 11:11:03 --> Model "Settings_model" initialized
INFO - 2021-07-01 11:11:03 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 11:11:03 --> Model "Permissions_model" initialized
INFO - 2021-07-01 11:11:03 --> Model "Roles_model" initialized
INFO - 2021-07-01 11:11:03 --> Model "Activity_model" initialized
INFO - 2021-07-01 11:11:03 --> Model "Templates_model" initialized
INFO - 2021-07-01 11:11:03 --> Database Driver Class Initialized
INFO - 2021-07-01 11:11:03 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 11:11:03 --> Controller Class Initialized
ERROR - 2021-07-01 14:11:03 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-01 14:11:03 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-01 14:11:03 --> Final output sent to browser
DEBUG - 2021-07-01 14:11:03 --> Total execution time: 0.2290
INFO - 2021-07-01 11:11:19 --> Config Class Initialized
INFO - 2021-07-01 11:11:19 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:11:19 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:11:19 --> Utf8 Class Initialized
INFO - 2021-07-01 11:11:19 --> URI Class Initialized
INFO - 2021-07-01 11:11:19 --> Router Class Initialized
INFO - 2021-07-01 11:11:19 --> Output Class Initialized
INFO - 2021-07-01 11:11:19 --> Security Class Initialized
DEBUG - 2021-07-01 11:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:11:19 --> Input Class Initialized
INFO - 2021-07-01 11:11:19 --> Language Class Initialized
INFO - 2021-07-01 11:11:19 --> Loader Class Initialized
INFO - 2021-07-01 11:11:19 --> Helper loaded: basic_helper
INFO - 2021-07-01 11:11:19 --> Helper loaded: url_helper
INFO - 2021-07-01 11:11:19 --> Helper loaded: file_helper
INFO - 2021-07-01 11:11:19 --> Helper loaded: form_helper
INFO - 2021-07-01 11:11:19 --> Helper loaded: cookie_helper
INFO - 2021-07-01 11:11:19 --> Helper loaded: security_helper
INFO - 2021-07-01 11:11:19 --> Helper loaded: directory_helper
INFO - 2021-07-01 11:11:19 --> Helper loaded: language_helper
INFO - 2021-07-01 11:11:19 --> Helper loaded: general_helper
INFO - 2021-07-01 11:11:19 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 11:11:19 --> Database Driver Class Initialized
DEBUG - 2021-07-01 11:11:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 11:11:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:11:19 --> Parser Class Initialized
INFO - 2021-07-01 11:11:19 --> Form Validation Class Initialized
INFO - 2021-07-01 11:11:19 --> Upload Class Initialized
INFO - 2021-07-01 11:11:19 --> Email Class Initialized
INFO - 2021-07-01 11:11:19 --> MY_Model class loaded
INFO - 2021-07-01 11:11:19 --> Model "Users_model" initialized
INFO - 2021-07-01 11:11:19 --> Model "Settings_model" initialized
INFO - 2021-07-01 11:11:19 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 11:11:19 --> Model "Permissions_model" initialized
INFO - 2021-07-01 11:11:19 --> Model "Roles_model" initialized
INFO - 2021-07-01 11:11:19 --> Model "Activity_model" initialized
INFO - 2021-07-01 11:11:19 --> Model "Templates_model" initialized
INFO - 2021-07-01 11:11:19 --> Database Driver Class Initialized
INFO - 2021-07-01 11:11:19 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 11:11:19 --> Controller Class Initialized
ERROR - 2021-07-01 14:11:19 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-01 14:11:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\crm\application\views\hesaplar\rapor_ayrinti.php 30
INFO - 2021-07-01 14:11:19 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-01 14:11:19 --> Final output sent to browser
DEBUG - 2021-07-01 14:11:19 --> Total execution time: 0.1315
INFO - 2021-07-01 11:11:24 --> Config Class Initialized
INFO - 2021-07-01 11:11:24 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:11:24 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:11:24 --> Utf8 Class Initialized
INFO - 2021-07-01 11:11:24 --> URI Class Initialized
INFO - 2021-07-01 11:11:24 --> Router Class Initialized
INFO - 2021-07-01 11:11:24 --> Output Class Initialized
INFO - 2021-07-01 11:11:24 --> Security Class Initialized
DEBUG - 2021-07-01 11:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:11:24 --> Input Class Initialized
INFO - 2021-07-01 11:11:24 --> Language Class Initialized
INFO - 2021-07-01 11:11:24 --> Loader Class Initialized
INFO - 2021-07-01 11:11:24 --> Helper loaded: basic_helper
INFO - 2021-07-01 11:11:24 --> Helper loaded: url_helper
INFO - 2021-07-01 11:11:24 --> Helper loaded: file_helper
INFO - 2021-07-01 11:11:24 --> Helper loaded: form_helper
INFO - 2021-07-01 11:11:24 --> Helper loaded: cookie_helper
INFO - 2021-07-01 11:11:24 --> Helper loaded: security_helper
INFO - 2021-07-01 11:11:24 --> Helper loaded: directory_helper
INFO - 2021-07-01 11:11:24 --> Helper loaded: language_helper
INFO - 2021-07-01 11:11:24 --> Helper loaded: general_helper
INFO - 2021-07-01 11:11:24 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 11:11:24 --> Database Driver Class Initialized
DEBUG - 2021-07-01 11:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 11:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:11:24 --> Parser Class Initialized
INFO - 2021-07-01 11:11:24 --> Form Validation Class Initialized
INFO - 2021-07-01 11:11:24 --> Upload Class Initialized
INFO - 2021-07-01 11:11:24 --> Email Class Initialized
INFO - 2021-07-01 11:11:24 --> MY_Model class loaded
INFO - 2021-07-01 11:11:24 --> Model "Users_model" initialized
INFO - 2021-07-01 11:11:24 --> Model "Settings_model" initialized
INFO - 2021-07-01 11:11:24 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 11:11:24 --> Model "Permissions_model" initialized
INFO - 2021-07-01 11:11:24 --> Model "Roles_model" initialized
INFO - 2021-07-01 11:11:24 --> Model "Activity_model" initialized
INFO - 2021-07-01 11:11:24 --> Model "Templates_model" initialized
INFO - 2021-07-01 11:11:24 --> Database Driver Class Initialized
INFO - 2021-07-01 11:11:24 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 11:11:24 --> Controller Class Initialized
ERROR - 2021-07-01 14:11:24 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-01 14:11:24 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-01 14:11:24 --> Final output sent to browser
DEBUG - 2021-07-01 14:11:24 --> Total execution time: 0.2269
INFO - 2021-07-01 11:12:03 --> Config Class Initialized
INFO - 2021-07-01 11:12:03 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:12:03 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:12:03 --> Utf8 Class Initialized
INFO - 2021-07-01 11:12:03 --> URI Class Initialized
INFO - 2021-07-01 11:12:03 --> Router Class Initialized
INFO - 2021-07-01 11:12:03 --> Output Class Initialized
INFO - 2021-07-01 11:12:03 --> Security Class Initialized
DEBUG - 2021-07-01 11:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:12:03 --> Input Class Initialized
INFO - 2021-07-01 11:12:03 --> Language Class Initialized
INFO - 2021-07-01 11:12:03 --> Loader Class Initialized
INFO - 2021-07-01 11:12:03 --> Helper loaded: basic_helper
INFO - 2021-07-01 11:12:03 --> Helper loaded: url_helper
INFO - 2021-07-01 11:12:03 --> Helper loaded: file_helper
INFO - 2021-07-01 11:12:03 --> Helper loaded: form_helper
INFO - 2021-07-01 11:12:03 --> Helper loaded: cookie_helper
INFO - 2021-07-01 11:12:03 --> Helper loaded: security_helper
INFO - 2021-07-01 11:12:03 --> Helper loaded: directory_helper
INFO - 2021-07-01 11:12:03 --> Helper loaded: language_helper
INFO - 2021-07-01 11:12:03 --> Helper loaded: general_helper
INFO - 2021-07-01 11:12:03 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 11:12:03 --> Database Driver Class Initialized
DEBUG - 2021-07-01 11:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 11:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:12:03 --> Parser Class Initialized
INFO - 2021-07-01 11:12:03 --> Form Validation Class Initialized
INFO - 2021-07-01 11:12:03 --> Upload Class Initialized
INFO - 2021-07-01 11:12:03 --> Email Class Initialized
INFO - 2021-07-01 11:12:03 --> MY_Model class loaded
INFO - 2021-07-01 11:12:03 --> Model "Users_model" initialized
INFO - 2021-07-01 11:12:03 --> Model "Settings_model" initialized
INFO - 2021-07-01 11:12:03 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 11:12:03 --> Model "Permissions_model" initialized
INFO - 2021-07-01 11:12:03 --> Model "Roles_model" initialized
INFO - 2021-07-01 11:12:03 --> Model "Activity_model" initialized
INFO - 2021-07-01 11:12:03 --> Model "Templates_model" initialized
INFO - 2021-07-01 11:12:03 --> Database Driver Class Initialized
INFO - 2021-07-01 11:12:04 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 11:12:04 --> Controller Class Initialized
ERROR - 2021-07-01 14:12:04 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-01 14:12:04 --> Invalid query: 
INFO - 2021-07-01 14:12:04 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-01 14:12:04 --> Final output sent to browser
DEBUG - 2021-07-01 14:12:04 --> Total execution time: 0.1397
INFO - 2021-07-01 11:40:56 --> Config Class Initialized
INFO - 2021-07-01 11:40:56 --> Hooks Class Initialized
DEBUG - 2021-07-01 11:40:56 --> UTF-8 Support Enabled
INFO - 2021-07-01 11:40:56 --> Utf8 Class Initialized
INFO - 2021-07-01 11:40:56 --> URI Class Initialized
DEBUG - 2021-07-01 11:40:56 --> No URI present. Default controller set.
INFO - 2021-07-01 11:40:56 --> Router Class Initialized
INFO - 2021-07-01 11:40:56 --> Output Class Initialized
INFO - 2021-07-01 11:40:56 --> Security Class Initialized
DEBUG - 2021-07-01 11:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 11:40:56 --> Input Class Initialized
INFO - 2021-07-01 11:40:56 --> Language Class Initialized
INFO - 2021-07-01 11:40:56 --> Loader Class Initialized
INFO - 2021-07-01 11:40:56 --> Helper loaded: basic_helper
INFO - 2021-07-01 11:40:56 --> Helper loaded: url_helper
INFO - 2021-07-01 11:40:56 --> Helper loaded: file_helper
INFO - 2021-07-01 11:40:56 --> Helper loaded: form_helper
INFO - 2021-07-01 11:40:56 --> Helper loaded: cookie_helper
INFO - 2021-07-01 11:40:56 --> Helper loaded: security_helper
INFO - 2021-07-01 11:40:56 --> Helper loaded: directory_helper
INFO - 2021-07-01 11:40:56 --> Helper loaded: language_helper
INFO - 2021-07-01 11:40:56 --> Helper loaded: general_helper
INFO - 2021-07-01 11:40:56 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 11:40:56 --> Database Driver Class Initialized
DEBUG - 2021-07-01 11:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 11:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 11:40:56 --> Parser Class Initialized
INFO - 2021-07-01 11:40:56 --> Form Validation Class Initialized
INFO - 2021-07-01 11:40:56 --> Upload Class Initialized
INFO - 2021-07-01 11:40:56 --> Email Class Initialized
INFO - 2021-07-01 11:40:56 --> MY_Model class loaded
INFO - 2021-07-01 11:40:56 --> Model "Users_model" initialized
INFO - 2021-07-01 11:40:56 --> Model "Settings_model" initialized
INFO - 2021-07-01 11:40:56 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 11:40:56 --> Model "Permissions_model" initialized
INFO - 2021-07-01 11:40:56 --> Model "Roles_model" initialized
INFO - 2021-07-01 11:40:56 --> Model "Activity_model" initialized
INFO - 2021-07-01 11:40:56 --> Model "Templates_model" initialized
INFO - 2021-07-01 11:40:56 --> Database Driver Class Initialized
INFO - 2021-07-01 11:40:56 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 11:40:56 --> Controller Class Initialized
INFO - 2021-07-01 12:46:31 --> Config Class Initialized
INFO - 2021-07-01 12:46:31 --> Hooks Class Initialized
DEBUG - 2021-07-01 12:46:31 --> UTF-8 Support Enabled
INFO - 2021-07-01 12:46:31 --> Utf8 Class Initialized
INFO - 2021-07-01 12:46:31 --> URI Class Initialized
DEBUG - 2021-07-01 12:46:31 --> No URI present. Default controller set.
INFO - 2021-07-01 12:46:31 --> Router Class Initialized
INFO - 2021-07-01 12:46:31 --> Output Class Initialized
INFO - 2021-07-01 12:46:31 --> Security Class Initialized
DEBUG - 2021-07-01 12:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 12:46:31 --> Input Class Initialized
INFO - 2021-07-01 12:46:31 --> Language Class Initialized
INFO - 2021-07-01 12:46:31 --> Loader Class Initialized
INFO - 2021-07-01 12:46:31 --> Helper loaded: basic_helper
INFO - 2021-07-01 12:46:31 --> Helper loaded: url_helper
INFO - 2021-07-01 12:46:31 --> Helper loaded: file_helper
INFO - 2021-07-01 12:46:31 --> Helper loaded: form_helper
INFO - 2021-07-01 12:46:31 --> Helper loaded: cookie_helper
INFO - 2021-07-01 12:46:31 --> Helper loaded: security_helper
INFO - 2021-07-01 12:46:31 --> Helper loaded: directory_helper
INFO - 2021-07-01 12:46:31 --> Helper loaded: language_helper
INFO - 2021-07-01 12:46:31 --> Helper loaded: general_helper
INFO - 2021-07-01 12:46:31 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 12:46:31 --> Database Driver Class Initialized
DEBUG - 2021-07-01 12:46:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 12:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 12:46:31 --> Parser Class Initialized
INFO - 2021-07-01 12:46:31 --> Form Validation Class Initialized
INFO - 2021-07-01 12:46:31 --> Upload Class Initialized
INFO - 2021-07-01 12:46:31 --> Email Class Initialized
INFO - 2021-07-01 12:46:31 --> MY_Model class loaded
INFO - 2021-07-01 12:46:31 --> Model "Users_model" initialized
INFO - 2021-07-01 12:46:31 --> Model "Settings_model" initialized
INFO - 2021-07-01 12:46:31 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 12:46:31 --> Model "Permissions_model" initialized
INFO - 2021-07-01 12:46:31 --> Model "Roles_model" initialized
INFO - 2021-07-01 12:46:31 --> Model "Activity_model" initialized
INFO - 2021-07-01 12:46:31 --> Model "Templates_model" initialized
INFO - 2021-07-01 12:46:31 --> Database Driver Class Initialized
INFO - 2021-07-01 12:46:31 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 12:46:31 --> Controller Class Initialized
INFO - 2021-07-01 13:58:21 --> Config Class Initialized
INFO - 2021-07-01 13:58:21 --> Hooks Class Initialized
DEBUG - 2021-07-01 13:58:21 --> UTF-8 Support Enabled
INFO - 2021-07-01 13:58:21 --> Utf8 Class Initialized
INFO - 2021-07-01 13:58:21 --> URI Class Initialized
DEBUG - 2021-07-01 13:58:21 --> No URI present. Default controller set.
INFO - 2021-07-01 13:58:21 --> Router Class Initialized
INFO - 2021-07-01 13:58:21 --> Output Class Initialized
INFO - 2021-07-01 13:58:21 --> Security Class Initialized
DEBUG - 2021-07-01 13:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-01 13:58:21 --> Input Class Initialized
INFO - 2021-07-01 13:58:21 --> Language Class Initialized
INFO - 2021-07-01 13:58:21 --> Loader Class Initialized
INFO - 2021-07-01 13:58:21 --> Helper loaded: basic_helper
INFO - 2021-07-01 13:58:21 --> Helper loaded: url_helper
INFO - 2021-07-01 13:58:21 --> Helper loaded: file_helper
INFO - 2021-07-01 13:58:21 --> Helper loaded: form_helper
INFO - 2021-07-01 13:58:21 --> Helper loaded: cookie_helper
INFO - 2021-07-01 13:58:21 --> Helper loaded: security_helper
INFO - 2021-07-01 13:58:21 --> Helper loaded: directory_helper
INFO - 2021-07-01 13:58:21 --> Helper loaded: language_helper
INFO - 2021-07-01 13:58:21 --> Helper loaded: general_helper
INFO - 2021-07-01 13:58:21 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-01 13:58:21 --> Database Driver Class Initialized
DEBUG - 2021-07-01 13:58:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-01 13:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-01 13:58:21 --> Parser Class Initialized
INFO - 2021-07-01 13:58:21 --> Form Validation Class Initialized
INFO - 2021-07-01 13:58:21 --> Upload Class Initialized
INFO - 2021-07-01 13:58:21 --> Email Class Initialized
INFO - 2021-07-01 13:58:21 --> MY_Model class loaded
INFO - 2021-07-01 13:58:21 --> Model "Users_model" initialized
INFO - 2021-07-01 13:58:21 --> Model "Settings_model" initialized
INFO - 2021-07-01 13:58:21 --> Model "Role_permissions_model" initialized
INFO - 2021-07-01 13:58:21 --> Model "Permissions_model" initialized
INFO - 2021-07-01 13:58:21 --> Model "Roles_model" initialized
INFO - 2021-07-01 13:58:21 --> Model "Activity_model" initialized
INFO - 2021-07-01 13:58:21 --> Model "Templates_model" initialized
INFO - 2021-07-01 13:58:21 --> Database Driver Class Initialized
INFO - 2021-07-01 13:58:21 --> Model "Hesaplar_model" initialized
INFO - 2021-07-01 13:58:21 --> Controller Class Initialized
