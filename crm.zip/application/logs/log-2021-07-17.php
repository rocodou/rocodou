<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-07-17 01:16:26 --> Config Class Initialized
INFO - 2021-07-17 01:16:26 --> Hooks Class Initialized
DEBUG - 2021-07-17 01:16:26 --> UTF-8 Support Enabled
INFO - 2021-07-17 01:16:26 --> Utf8 Class Initialized
INFO - 2021-07-17 01:16:26 --> URI Class Initialized
DEBUG - 2021-07-17 01:16:26 --> No URI present. Default controller set.
INFO - 2021-07-17 01:16:26 --> Router Class Initialized
INFO - 2021-07-17 01:16:26 --> Output Class Initialized
INFO - 2021-07-17 01:16:26 --> Security Class Initialized
DEBUG - 2021-07-17 01:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 01:16:26 --> Input Class Initialized
INFO - 2021-07-17 01:16:26 --> Language Class Initialized
INFO - 2021-07-17 01:16:26 --> Loader Class Initialized
INFO - 2021-07-17 01:16:26 --> Helper loaded: basic_helper
INFO - 2021-07-17 01:16:26 --> Helper loaded: url_helper
INFO - 2021-07-17 01:16:26 --> Helper loaded: file_helper
INFO - 2021-07-17 01:16:26 --> Helper loaded: form_helper
INFO - 2021-07-17 01:16:26 --> Helper loaded: cookie_helper
INFO - 2021-07-17 01:16:26 --> Helper loaded: security_helper
INFO - 2021-07-17 01:16:26 --> Helper loaded: directory_helper
INFO - 2021-07-17 01:16:26 --> Helper loaded: language_helper
INFO - 2021-07-17 01:16:26 --> Helper loaded: general_helper
INFO - 2021-07-17 01:16:26 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 01:16:26 --> Database Driver Class Initialized
DEBUG - 2021-07-17 01:16:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 01:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 01:16:26 --> Parser Class Initialized
INFO - 2021-07-17 01:16:26 --> Form Validation Class Initialized
INFO - 2021-07-17 01:16:26 --> Upload Class Initialized
INFO - 2021-07-17 01:16:26 --> Email Class Initialized
INFO - 2021-07-17 01:16:26 --> MY_Model class loaded
INFO - 2021-07-17 01:16:26 --> Model "Users_model" initialized
INFO - 2021-07-17 01:16:26 --> Model "Settings_model" initialized
INFO - 2021-07-17 01:16:26 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 01:16:26 --> Model "Permissions_model" initialized
INFO - 2021-07-17 01:16:26 --> Model "Roles_model" initialized
INFO - 2021-07-17 01:16:26 --> Model "Activity_model" initialized
INFO - 2021-07-17 01:16:26 --> Model "Templates_model" initialized
INFO - 2021-07-17 01:16:26 --> Database Driver Class Initialized
INFO - 2021-07-17 01:16:26 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 01:16:26 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 01:16:26 --> Controller Class Initialized
INFO - 2021-07-17 01:16:27 --> Config Class Initialized
INFO - 2021-07-17 01:16:27 --> Hooks Class Initialized
DEBUG - 2021-07-17 01:16:27 --> UTF-8 Support Enabled
INFO - 2021-07-17 01:16:27 --> Utf8 Class Initialized
INFO - 2021-07-17 01:16:27 --> URI Class Initialized
INFO - 2021-07-17 01:16:27 --> Router Class Initialized
INFO - 2021-07-17 01:16:27 --> Output Class Initialized
INFO - 2021-07-17 01:16:27 --> Security Class Initialized
DEBUG - 2021-07-17 01:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 01:16:27 --> Input Class Initialized
INFO - 2021-07-17 01:16:27 --> Language Class Initialized
INFO - 2021-07-17 01:16:27 --> Loader Class Initialized
INFO - 2021-07-17 01:16:27 --> Helper loaded: basic_helper
INFO - 2021-07-17 01:16:27 --> Helper loaded: url_helper
INFO - 2021-07-17 01:16:27 --> Helper loaded: file_helper
INFO - 2021-07-17 01:16:27 --> Helper loaded: form_helper
INFO - 2021-07-17 01:16:27 --> Helper loaded: cookie_helper
INFO - 2021-07-17 01:16:27 --> Helper loaded: security_helper
INFO - 2021-07-17 01:16:27 --> Helper loaded: directory_helper
INFO - 2021-07-17 01:16:27 --> Helper loaded: language_helper
INFO - 2021-07-17 01:16:27 --> Helper loaded: general_helper
INFO - 2021-07-17 01:16:27 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 01:16:27 --> Database Driver Class Initialized
DEBUG - 2021-07-17 01:16:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 01:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 01:16:27 --> Parser Class Initialized
INFO - 2021-07-17 01:16:27 --> Form Validation Class Initialized
INFO - 2021-07-17 01:16:27 --> Upload Class Initialized
INFO - 2021-07-17 01:16:27 --> Email Class Initialized
INFO - 2021-07-17 01:16:27 --> MY_Model class loaded
INFO - 2021-07-17 01:16:27 --> Model "Users_model" initialized
INFO - 2021-07-17 01:16:27 --> Model "Settings_model" initialized
INFO - 2021-07-17 01:16:27 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 01:16:27 --> Model "Permissions_model" initialized
INFO - 2021-07-17 01:16:27 --> Model "Roles_model" initialized
INFO - 2021-07-17 01:16:27 --> Config Class Initialized
INFO - 2021-07-17 01:16:27 --> Model "Activity_model" initialized
INFO - 2021-07-17 01:16:27 --> Hooks Class Initialized
INFO - 2021-07-17 01:16:27 --> Model "Templates_model" initialized
DEBUG - 2021-07-17 01:16:27 --> UTF-8 Support Enabled
INFO - 2021-07-17 01:16:27 --> Utf8 Class Initialized
INFO - 2021-07-17 01:16:27 --> Database Driver Class Initialized
INFO - 2021-07-17 01:16:27 --> URI Class Initialized
INFO - 2021-07-17 01:16:27 --> Router Class Initialized
INFO - 2021-07-17 01:16:27 --> Output Class Initialized
INFO - 2021-07-17 01:16:27 --> Security Class Initialized
DEBUG - 2021-07-17 01:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 01:16:27 --> Input Class Initialized
INFO - 2021-07-17 01:16:27 --> Language Class Initialized
ERROR - 2021-07-17 01:16:27 --> 404 Page Not Found: Faviconico/index
INFO - 2021-07-17 01:16:27 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 01:16:27 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 01:16:27 --> Controller Class Initialized
INFO - 2021-07-17 01:16:27 --> File loaded: C:\wamp64\www\crm\application\views\account/login.php
INFO - 2021-07-17 01:16:27 --> Final output sent to browser
DEBUG - 2021-07-17 01:16:27 --> Total execution time: 0.0608
INFO - 2021-07-17 01:16:27 --> Config Class Initialized
INFO - 2021-07-17 01:16:27 --> Hooks Class Initialized
INFO - 2021-07-17 01:16:27 --> Config Class Initialized
INFO - 2021-07-17 01:16:27 --> Hooks Class Initialized
DEBUG - 2021-07-17 01:16:27 --> UTF-8 Support Enabled
INFO - 2021-07-17 01:16:27 --> Utf8 Class Initialized
DEBUG - 2021-07-17 01:16:27 --> UTF-8 Support Enabled
INFO - 2021-07-17 01:16:27 --> Utf8 Class Initialized
INFO - 2021-07-17 01:16:27 --> URI Class Initialized
INFO - 2021-07-17 01:16:27 --> URI Class Initialized
INFO - 2021-07-17 01:16:27 --> Router Class Initialized
INFO - 2021-07-17 01:16:27 --> Router Class Initialized
INFO - 2021-07-17 01:16:27 --> Output Class Initialized
INFO - 2021-07-17 01:16:27 --> Output Class Initialized
INFO - 2021-07-17 01:16:27 --> Security Class Initialized
INFO - 2021-07-17 01:16:27 --> Security Class Initialized
DEBUG - 2021-07-17 01:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 01:16:27 --> Input Class Initialized
DEBUG - 2021-07-17 01:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 01:16:27 --> Language Class Initialized
INFO - 2021-07-17 01:16:27 --> Input Class Initialized
INFO - 2021-07-17 01:16:27 --> Language Class Initialized
ERROR - 2021-07-17 01:16:27 --> 404 Page Not Found: Assets/jquery
ERROR - 2021-07-17 01:16:27 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-17 01:16:27 --> Config Class Initialized
INFO - 2021-07-17 01:16:27 --> Hooks Class Initialized
DEBUG - 2021-07-17 01:16:27 --> UTF-8 Support Enabled
INFO - 2021-07-17 01:16:27 --> Utf8 Class Initialized
INFO - 2021-07-17 01:16:27 --> URI Class Initialized
INFO - 2021-07-17 01:16:27 --> Router Class Initialized
INFO - 2021-07-17 01:16:27 --> Output Class Initialized
INFO - 2021-07-17 01:16:27 --> Security Class Initialized
DEBUG - 2021-07-17 01:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 01:16:27 --> Input Class Initialized
INFO - 2021-07-17 01:16:27 --> Language Class Initialized
ERROR - 2021-07-17 01:16:27 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-17 01:16:34 --> Config Class Initialized
INFO - 2021-07-17 01:16:34 --> Hooks Class Initialized
DEBUG - 2021-07-17 01:16:34 --> UTF-8 Support Enabled
INFO - 2021-07-17 01:16:34 --> Utf8 Class Initialized
INFO - 2021-07-17 01:16:34 --> URI Class Initialized
INFO - 2021-07-17 01:16:34 --> Router Class Initialized
INFO - 2021-07-17 01:16:34 --> Output Class Initialized
INFO - 2021-07-17 01:16:34 --> Security Class Initialized
DEBUG - 2021-07-17 01:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 01:16:34 --> Input Class Initialized
INFO - 2021-07-17 01:16:34 --> Language Class Initialized
INFO - 2021-07-17 01:16:34 --> Loader Class Initialized
INFO - 2021-07-17 01:16:34 --> Helper loaded: basic_helper
INFO - 2021-07-17 01:16:34 --> Helper loaded: url_helper
INFO - 2021-07-17 01:16:34 --> Helper loaded: file_helper
INFO - 2021-07-17 01:16:34 --> Helper loaded: form_helper
INFO - 2021-07-17 01:16:34 --> Helper loaded: cookie_helper
INFO - 2021-07-17 01:16:34 --> Helper loaded: security_helper
INFO - 2021-07-17 01:16:34 --> Helper loaded: directory_helper
INFO - 2021-07-17 01:16:34 --> Helper loaded: language_helper
INFO - 2021-07-17 01:16:34 --> Helper loaded: general_helper
INFO - 2021-07-17 01:16:34 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 01:16:34 --> Database Driver Class Initialized
DEBUG - 2021-07-17 01:16:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 01:16:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 01:16:34 --> Parser Class Initialized
INFO - 2021-07-17 01:16:34 --> Form Validation Class Initialized
INFO - 2021-07-17 01:16:34 --> Upload Class Initialized
INFO - 2021-07-17 01:16:34 --> Email Class Initialized
INFO - 2021-07-17 01:16:34 --> MY_Model class loaded
INFO - 2021-07-17 01:16:34 --> Model "Users_model" initialized
INFO - 2021-07-17 01:16:34 --> Model "Settings_model" initialized
INFO - 2021-07-17 01:16:34 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 01:16:34 --> Model "Permissions_model" initialized
INFO - 2021-07-17 01:16:34 --> Model "Roles_model" initialized
INFO - 2021-07-17 01:16:34 --> Model "Activity_model" initialized
INFO - 2021-07-17 01:16:34 --> Model "Templates_model" initialized
INFO - 2021-07-17 01:16:34 --> Database Driver Class Initialized
INFO - 2021-07-17 01:16:35 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 01:16:35 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 01:16:35 --> Controller Class Initialized
DEBUG - 2021-07-17 01:16:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-17 01:16:35 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2021-07-17 01:16:35 --> Config Class Initialized
INFO - 2021-07-17 01:16:35 --> Hooks Class Initialized
DEBUG - 2021-07-17 01:16:35 --> UTF-8 Support Enabled
INFO - 2021-07-17 01:16:35 --> Utf8 Class Initialized
INFO - 2021-07-17 01:16:35 --> URI Class Initialized
DEBUG - 2021-07-17 01:16:35 --> No URI present. Default controller set.
INFO - 2021-07-17 01:16:35 --> Router Class Initialized
INFO - 2021-07-17 01:16:35 --> Output Class Initialized
INFO - 2021-07-17 01:16:35 --> Security Class Initialized
DEBUG - 2021-07-17 01:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 01:16:35 --> Input Class Initialized
INFO - 2021-07-17 01:16:35 --> Language Class Initialized
INFO - 2021-07-17 01:16:35 --> Loader Class Initialized
INFO - 2021-07-17 01:16:35 --> Helper loaded: basic_helper
INFO - 2021-07-17 01:16:35 --> Helper loaded: url_helper
INFO - 2021-07-17 01:16:35 --> Helper loaded: file_helper
INFO - 2021-07-17 01:16:35 --> Helper loaded: form_helper
INFO - 2021-07-17 01:16:35 --> Helper loaded: cookie_helper
INFO - 2021-07-17 01:16:35 --> Helper loaded: security_helper
INFO - 2021-07-17 01:16:35 --> Helper loaded: directory_helper
INFO - 2021-07-17 01:16:35 --> Helper loaded: language_helper
INFO - 2021-07-17 01:16:35 --> Helper loaded: general_helper
INFO - 2021-07-17 01:16:35 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 01:16:35 --> Database Driver Class Initialized
DEBUG - 2021-07-17 01:16:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 01:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 01:16:35 --> Parser Class Initialized
INFO - 2021-07-17 01:16:35 --> Form Validation Class Initialized
INFO - 2021-07-17 01:16:35 --> Upload Class Initialized
INFO - 2021-07-17 01:16:35 --> Email Class Initialized
INFO - 2021-07-17 01:16:35 --> MY_Model class loaded
INFO - 2021-07-17 01:16:35 --> Model "Users_model" initialized
INFO - 2021-07-17 01:16:35 --> Model "Settings_model" initialized
INFO - 2021-07-17 01:16:35 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 01:16:35 --> Model "Permissions_model" initialized
INFO - 2021-07-17 01:16:35 --> Model "Roles_model" initialized
INFO - 2021-07-17 01:16:35 --> Model "Activity_model" initialized
INFO - 2021-07-17 01:16:35 --> Model "Templates_model" initialized
INFO - 2021-07-17 01:16:35 --> Database Driver Class Initialized
INFO - 2021-07-17 01:16:35 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 01:16:35 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 01:16:35 --> Controller Class Initialized
ERROR - 2021-07-17 01:16:35 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 01:16:35 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-17 01:16:35 --> Final output sent to browser
DEBUG - 2021-07-17 01:16:35 --> Total execution time: 0.0595
INFO - 2021-07-17 01:16:43 --> Config Class Initialized
INFO - 2021-07-17 01:16:43 --> Hooks Class Initialized
DEBUG - 2021-07-17 01:16:43 --> UTF-8 Support Enabled
INFO - 2021-07-17 01:16:43 --> Utf8 Class Initialized
INFO - 2021-07-17 01:16:43 --> URI Class Initialized
INFO - 2021-07-17 01:16:43 --> Router Class Initialized
INFO - 2021-07-17 01:16:43 --> Output Class Initialized
INFO - 2021-07-17 01:16:43 --> Security Class Initialized
DEBUG - 2021-07-17 01:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 01:16:43 --> Input Class Initialized
INFO - 2021-07-17 01:16:43 --> Language Class Initialized
INFO - 2021-07-17 01:16:43 --> Loader Class Initialized
INFO - 2021-07-17 01:16:43 --> Helper loaded: basic_helper
INFO - 2021-07-17 01:16:43 --> Helper loaded: url_helper
INFO - 2021-07-17 01:16:43 --> Helper loaded: file_helper
INFO - 2021-07-17 01:16:43 --> Helper loaded: form_helper
INFO - 2021-07-17 01:16:43 --> Helper loaded: cookie_helper
INFO - 2021-07-17 01:16:43 --> Helper loaded: security_helper
INFO - 2021-07-17 01:16:43 --> Helper loaded: directory_helper
INFO - 2021-07-17 01:16:43 --> Helper loaded: language_helper
INFO - 2021-07-17 01:16:43 --> Helper loaded: general_helper
INFO - 2021-07-17 01:16:43 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 01:16:43 --> Database Driver Class Initialized
DEBUG - 2021-07-17 01:16:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 01:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 01:16:43 --> Parser Class Initialized
INFO - 2021-07-17 01:16:43 --> Form Validation Class Initialized
INFO - 2021-07-17 01:16:43 --> Upload Class Initialized
INFO - 2021-07-17 01:16:43 --> Email Class Initialized
INFO - 2021-07-17 01:16:43 --> MY_Model class loaded
INFO - 2021-07-17 01:16:43 --> Model "Users_model" initialized
INFO - 2021-07-17 01:16:43 --> Model "Settings_model" initialized
INFO - 2021-07-17 01:16:43 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 01:16:43 --> Model "Permissions_model" initialized
INFO - 2021-07-17 01:16:43 --> Model "Roles_model" initialized
INFO - 2021-07-17 01:16:43 --> Model "Activity_model" initialized
INFO - 2021-07-17 01:16:43 --> Model "Templates_model" initialized
INFO - 2021-07-17 01:16:43 --> Database Driver Class Initialized
INFO - 2021-07-17 01:16:43 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 01:16:43 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 01:16:43 --> Controller Class Initialized
ERROR - 2021-07-17 01:16:43 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 01:16:43 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 01:16:43 --> Final output sent to browser
DEBUG - 2021-07-17 01:16:43 --> Total execution time: 0.1273
INFO - 2021-07-17 01:16:56 --> Config Class Initialized
INFO - 2021-07-17 01:16:56 --> Hooks Class Initialized
DEBUG - 2021-07-17 01:16:56 --> UTF-8 Support Enabled
INFO - 2021-07-17 01:16:56 --> Utf8 Class Initialized
INFO - 2021-07-17 01:16:56 --> URI Class Initialized
INFO - 2021-07-17 01:16:56 --> Router Class Initialized
INFO - 2021-07-17 01:16:56 --> Output Class Initialized
INFO - 2021-07-17 01:16:56 --> Security Class Initialized
DEBUG - 2021-07-17 01:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 01:16:56 --> Input Class Initialized
INFO - 2021-07-17 01:16:56 --> Language Class Initialized
INFO - 2021-07-17 01:16:56 --> Loader Class Initialized
INFO - 2021-07-17 01:16:56 --> Helper loaded: basic_helper
INFO - 2021-07-17 01:16:56 --> Helper loaded: url_helper
INFO - 2021-07-17 01:16:56 --> Helper loaded: file_helper
INFO - 2021-07-17 01:16:56 --> Helper loaded: form_helper
INFO - 2021-07-17 01:16:56 --> Helper loaded: cookie_helper
INFO - 2021-07-17 01:16:56 --> Helper loaded: security_helper
INFO - 2021-07-17 01:16:56 --> Helper loaded: directory_helper
INFO - 2021-07-17 01:16:56 --> Helper loaded: language_helper
INFO - 2021-07-17 01:16:56 --> Helper loaded: general_helper
INFO - 2021-07-17 01:16:56 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 01:16:56 --> Database Driver Class Initialized
DEBUG - 2021-07-17 01:16:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 01:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 01:16:56 --> Parser Class Initialized
INFO - 2021-07-17 01:16:56 --> Form Validation Class Initialized
INFO - 2021-07-17 01:16:56 --> Upload Class Initialized
INFO - 2021-07-17 01:16:56 --> Email Class Initialized
INFO - 2021-07-17 01:16:56 --> MY_Model class loaded
INFO - 2021-07-17 01:16:56 --> Model "Users_model" initialized
INFO - 2021-07-17 01:16:56 --> Model "Settings_model" initialized
INFO - 2021-07-17 01:16:56 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 01:16:56 --> Model "Permissions_model" initialized
INFO - 2021-07-17 01:16:56 --> Model "Roles_model" initialized
INFO - 2021-07-17 01:16:56 --> Model "Activity_model" initialized
INFO - 2021-07-17 01:16:56 --> Model "Templates_model" initialized
INFO - 2021-07-17 01:16:56 --> Database Driver Class Initialized
INFO - 2021-07-17 01:16:56 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 01:16:56 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 01:16:56 --> Controller Class Initialized
ERROR - 2021-07-17 01:16:56 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 01:16:56 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 01:16:56 --> Final output sent to browser
DEBUG - 2021-07-17 01:16:56 --> Total execution time: 0.1237
INFO - 2021-07-17 01:17:04 --> Config Class Initialized
INFO - 2021-07-17 01:17:04 --> Hooks Class Initialized
DEBUG - 2021-07-17 01:17:04 --> UTF-8 Support Enabled
INFO - 2021-07-17 01:17:04 --> Utf8 Class Initialized
INFO - 2021-07-17 01:17:04 --> URI Class Initialized
INFO - 2021-07-17 01:17:04 --> Router Class Initialized
INFO - 2021-07-17 01:17:04 --> Output Class Initialized
INFO - 2021-07-17 01:17:04 --> Security Class Initialized
DEBUG - 2021-07-17 01:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 01:17:04 --> Input Class Initialized
INFO - 2021-07-17 01:17:04 --> Language Class Initialized
INFO - 2021-07-17 01:17:04 --> Loader Class Initialized
INFO - 2021-07-17 01:17:04 --> Helper loaded: basic_helper
INFO - 2021-07-17 01:17:04 --> Helper loaded: url_helper
INFO - 2021-07-17 01:17:04 --> Helper loaded: file_helper
INFO - 2021-07-17 01:17:04 --> Helper loaded: form_helper
INFO - 2021-07-17 01:17:04 --> Helper loaded: cookie_helper
INFO - 2021-07-17 01:17:04 --> Helper loaded: security_helper
INFO - 2021-07-17 01:17:04 --> Helper loaded: directory_helper
INFO - 2021-07-17 01:17:04 --> Helper loaded: language_helper
INFO - 2021-07-17 01:17:04 --> Helper loaded: general_helper
INFO - 2021-07-17 01:17:04 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 01:17:04 --> Database Driver Class Initialized
DEBUG - 2021-07-17 01:17:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 01:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 01:17:04 --> Parser Class Initialized
INFO - 2021-07-17 01:17:04 --> Form Validation Class Initialized
INFO - 2021-07-17 01:17:04 --> Upload Class Initialized
INFO - 2021-07-17 01:17:04 --> Email Class Initialized
INFO - 2021-07-17 01:17:04 --> MY_Model class loaded
INFO - 2021-07-17 01:17:04 --> Model "Users_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Settings_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Permissions_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Roles_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Activity_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Templates_model" initialized
INFO - 2021-07-17 01:17:04 --> Database Driver Class Initialized
INFO - 2021-07-17 01:17:04 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 01:17:04 --> Controller Class Initialized
ERROR - 2021-07-17 01:17:04 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 01:17:04 --> File loaded: C:\wamp64\www\crm\application\views\users/list.php
INFO - 2021-07-17 01:17:04 --> Final output sent to browser
DEBUG - 2021-07-17 01:17:04 --> Total execution time: 0.2175
INFO - 2021-07-17 01:17:04 --> Config Class Initialized
INFO - 2021-07-17 01:17:04 --> Hooks Class Initialized
INFO - 2021-07-17 01:17:04 --> Config Class Initialized
INFO - 2021-07-17 01:17:04 --> Hooks Class Initialized
DEBUG - 2021-07-17 01:17:04 --> UTF-8 Support Enabled
INFO - 2021-07-17 01:17:04 --> Utf8 Class Initialized
DEBUG - 2021-07-17 01:17:04 --> UTF-8 Support Enabled
INFO - 2021-07-17 01:17:04 --> Utf8 Class Initialized
INFO - 2021-07-17 01:17:04 --> URI Class Initialized
INFO - 2021-07-17 01:17:04 --> URI Class Initialized
INFO - 2021-07-17 01:17:04 --> Router Class Initialized
INFO - 2021-07-17 01:17:04 --> Router Class Initialized
INFO - 2021-07-17 01:17:04 --> Output Class Initialized
INFO - 2021-07-17 01:17:04 --> Config Class Initialized
INFO - 2021-07-17 01:17:04 --> Output Class Initialized
INFO - 2021-07-17 01:17:04 --> Hooks Class Initialized
INFO - 2021-07-17 01:17:04 --> Security Class Initialized
INFO - 2021-07-17 01:17:04 --> Security Class Initialized
DEBUG - 2021-07-17 01:17:04 --> UTF-8 Support Enabled
DEBUG - 2021-07-17 01:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 01:17:04 --> Utf8 Class Initialized
INFO - 2021-07-17 01:17:04 --> Input Class Initialized
DEBUG - 2021-07-17 01:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 01:17:04 --> URI Class Initialized
INFO - 2021-07-17 01:17:04 --> Input Class Initialized
INFO - 2021-07-17 01:17:04 --> Language Class Initialized
INFO - 2021-07-17 01:17:04 --> Language Class Initialized
INFO - 2021-07-17 01:17:04 --> Router Class Initialized
INFO - 2021-07-17 01:17:04 --> Loader Class Initialized
INFO - 2021-07-17 01:17:04 --> Loader Class Initialized
INFO - 2021-07-17 01:17:04 --> Output Class Initialized
INFO - 2021-07-17 01:17:04 --> Helper loaded: basic_helper
INFO - 2021-07-17 01:17:04 --> Config Class Initialized
INFO - 2021-07-17 01:17:04 --> Security Class Initialized
INFO - 2021-07-17 01:17:04 --> Helper loaded: basic_helper
INFO - 2021-07-17 01:17:04 --> Hooks Class Initialized
INFO - 2021-07-17 01:17:04 --> Helper loaded: url_helper
DEBUG - 2021-07-17 01:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 01:17:04 --> Helper loaded: url_helper
INFO - 2021-07-17 01:17:04 --> Input Class Initialized
DEBUG - 2021-07-17 01:17:04 --> UTF-8 Support Enabled
INFO - 2021-07-17 01:17:04 --> Helper loaded: file_helper
INFO - 2021-07-17 01:17:04 --> Helper loaded: file_helper
INFO - 2021-07-17 01:17:04 --> Config Class Initialized
INFO - 2021-07-17 01:17:04 --> Language Class Initialized
INFO - 2021-07-17 01:17:04 --> Utf8 Class Initialized
INFO - 2021-07-17 01:17:04 --> Hooks Class Initialized
INFO - 2021-07-17 01:17:04 --> Helper loaded: form_helper
INFO - 2021-07-17 01:17:04 --> Helper loaded: form_helper
INFO - 2021-07-17 01:17:04 --> Loader Class Initialized
INFO - 2021-07-17 01:17:04 --> URI Class Initialized
DEBUG - 2021-07-17 01:17:04 --> UTF-8 Support Enabled
INFO - 2021-07-17 01:17:04 --> Helper loaded: cookie_helper
INFO - 2021-07-17 01:17:04 --> Helper loaded: cookie_helper
INFO - 2021-07-17 01:17:04 --> Utf8 Class Initialized
INFO - 2021-07-17 01:17:04 --> Config Class Initialized
INFO - 2021-07-17 01:17:04 --> Helper loaded: basic_helper
INFO - 2021-07-17 01:17:04 --> Helper loaded: security_helper
INFO - 2021-07-17 01:17:04 --> Router Class Initialized
INFO - 2021-07-17 01:17:04 --> Helper loaded: security_helper
INFO - 2021-07-17 01:17:04 --> Hooks Class Initialized
INFO - 2021-07-17 01:17:04 --> URI Class Initialized
INFO - 2021-07-17 01:17:04 --> Helper loaded: directory_helper
INFO - 2021-07-17 01:17:04 --> Helper loaded: url_helper
INFO - 2021-07-17 01:17:04 --> Output Class Initialized
INFO - 2021-07-17 01:17:04 --> Helper loaded: directory_helper
DEBUG - 2021-07-17 01:17:04 --> UTF-8 Support Enabled
INFO - 2021-07-17 01:17:04 --> Helper loaded: language_helper
INFO - 2021-07-17 01:17:04 --> Helper loaded: file_helper
INFO - 2021-07-17 01:17:04 --> Utf8 Class Initialized
INFO - 2021-07-17 01:17:04 --> Router Class Initialized
INFO - 2021-07-17 01:17:04 --> Security Class Initialized
INFO - 2021-07-17 01:17:04 --> Helper loaded: language_helper
INFO - 2021-07-17 01:17:04 --> Helper loaded: general_helper
INFO - 2021-07-17 01:17:04 --> Helper loaded: form_helper
INFO - 2021-07-17 01:17:04 --> URI Class Initialized
DEBUG - 2021-07-17 01:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 01:17:04 --> Output Class Initialized
INFO - 2021-07-17 01:17:04 --> Helper loaded: general_helper
INFO - 2021-07-17 01:17:04 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 01:17:04 --> Input Class Initialized
INFO - 2021-07-17 01:17:04 --> Helper loaded: cookie_helper
INFO - 2021-07-17 01:17:04 --> Security Class Initialized
INFO - 2021-07-17 01:17:04 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 01:17:04 --> Router Class Initialized
INFO - 2021-07-17 01:17:04 --> Language Class Initialized
INFO - 2021-07-17 01:17:04 --> Database Driver Class Initialized
INFO - 2021-07-17 01:17:04 --> Helper loaded: security_helper
DEBUG - 2021-07-17 01:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 01:17:04 --> Output Class Initialized
INFO - 2021-07-17 01:17:04 --> Database Driver Class Initialized
INFO - 2021-07-17 01:17:04 --> Loader Class Initialized
INFO - 2021-07-17 01:17:04 --> Input Class Initialized
INFO - 2021-07-17 01:17:04 --> Helper loaded: directory_helper
INFO - 2021-07-17 01:17:04 --> Security Class Initialized
INFO - 2021-07-17 01:17:04 --> Language Class Initialized
INFO - 2021-07-17 01:17:04 --> Helper loaded: basic_helper
INFO - 2021-07-17 01:17:04 --> Helper loaded: language_helper
DEBUG - 2021-07-17 01:17:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-17 01:17:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 01:17:04 --> Helper loaded: general_helper
INFO - 2021-07-17 01:17:04 --> Input Class Initialized
INFO - 2021-07-17 01:17:04 --> Helper loaded: url_helper
INFO - 2021-07-17 01:17:04 --> Loader Class Initialized
INFO - 2021-07-17 01:17:04 --> Language Class Initialized
INFO - 2021-07-17 01:17:04 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 01:17:04 --> Helper loaded: file_helper
INFO - 2021-07-17 01:17:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2021-07-17 01:17:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 01:17:04 --> Helper loaded: basic_helper
INFO - 2021-07-17 01:17:04 --> Loader Class Initialized
INFO - 2021-07-17 01:17:04 --> Helper loaded: form_helper
INFO - 2021-07-17 01:17:04 --> Database Driver Class Initialized
INFO - 2021-07-17 01:17:04 --> Parser Class Initialized
INFO - 2021-07-17 01:17:04 --> Helper loaded: url_helper
INFO - 2021-07-17 01:17:04 --> Helper loaded: cookie_helper
INFO - 2021-07-17 01:17:04 --> Helper loaded: basic_helper
INFO - 2021-07-17 01:17:04 --> Helper loaded: file_helper
INFO - 2021-07-17 01:17:04 --> Form Validation Class Initialized
INFO - 2021-07-17 01:17:04 --> Helper loaded: security_helper
INFO - 2021-07-17 01:17:04 --> Helper loaded: url_helper
INFO - 2021-07-17 01:17:04 --> Helper loaded: form_helper
INFO - 2021-07-17 01:17:04 --> Helper loaded: directory_helper
INFO - 2021-07-17 01:17:04 --> Helper loaded: file_helper
INFO - 2021-07-17 01:17:04 --> Helper loaded: cookie_helper
INFO - 2021-07-17 01:17:04 --> Upload Class Initialized
DEBUG - 2021-07-17 01:17:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 01:17:04 --> Helper loaded: language_helper
INFO - 2021-07-17 01:17:04 --> Helper loaded: form_helper
INFO - 2021-07-17 01:17:04 --> Helper loaded: security_helper
INFO - 2021-07-17 01:17:04 --> Email Class Initialized
INFO - 2021-07-17 01:17:04 --> Helper loaded: general_helper
INFO - 2021-07-17 01:17:04 --> Helper loaded: cookie_helper
INFO - 2021-07-17 01:17:04 --> Helper loaded: directory_helper
INFO - 2021-07-17 01:17:04 --> MY_Model class loaded
INFO - 2021-07-17 01:17:04 --> Helper loaded: security_helper
INFO - 2021-07-17 01:17:04 --> Helper loaded: language_helper
INFO - 2021-07-17 01:17:04 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 01:17:04 --> Model "Users_model" initialized
INFO - 2021-07-17 01:17:04 --> Helper loaded: directory_helper
INFO - 2021-07-17 01:17:04 --> Helper loaded: general_helper
INFO - 2021-07-17 01:17:04 --> Model "Settings_model" initialized
INFO - 2021-07-17 01:17:04 --> Database Driver Class Initialized
INFO - 2021-07-17 01:17:04 --> Helper loaded: language_helper
INFO - 2021-07-17 01:17:04 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 01:17:04 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 01:17:04 --> Model "Permissions_model" initialized
INFO - 2021-07-17 01:17:04 --> Helper loaded: general_helper
INFO - 2021-07-17 01:17:04 --> Model "Roles_model" initialized
INFO - 2021-07-17 01:17:04 --> Database Driver Class Initialized
INFO - 2021-07-17 01:17:04 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 01:17:04 --> Model "Activity_model" initialized
INFO - 2021-07-17 01:17:04 --> Database Driver Class Initialized
INFO - 2021-07-17 01:17:04 --> Model "Templates_model" initialized
DEBUG - 2021-07-17 01:17:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 01:17:04 --> Database Driver Class Initialized
DEBUG - 2021-07-17 01:17:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-07-17 01:17:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 01:17:04 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 01:17:04 --> Controller Class Initialized
INFO - 2021-07-17 01:17:04 --> Final output sent to browser
DEBUG - 2021-07-17 01:17:04 --> Total execution time: 0.0546
INFO - 2021-07-17 01:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 01:17:04 --> Parser Class Initialized
INFO - 2021-07-17 01:17:04 --> Form Validation Class Initialized
INFO - 2021-07-17 01:17:04 --> Upload Class Initialized
INFO - 2021-07-17 01:17:04 --> Email Class Initialized
INFO - 2021-07-17 01:17:04 --> MY_Model class loaded
INFO - 2021-07-17 01:17:04 --> Model "Users_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Settings_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Permissions_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Roles_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Activity_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Templates_model" initialized
INFO - 2021-07-17 01:17:04 --> Database Driver Class Initialized
INFO - 2021-07-17 01:17:04 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 01:17:04 --> Controller Class Initialized
INFO - 2021-07-17 01:17:04 --> Final output sent to browser
DEBUG - 2021-07-17 01:17:04 --> Total execution time: 0.0874
INFO - 2021-07-17 01:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 01:17:04 --> Parser Class Initialized
INFO - 2021-07-17 01:17:04 --> Form Validation Class Initialized
INFO - 2021-07-17 01:17:04 --> Upload Class Initialized
INFO - 2021-07-17 01:17:04 --> Email Class Initialized
INFO - 2021-07-17 01:17:04 --> MY_Model class loaded
INFO - 2021-07-17 01:17:04 --> Model "Users_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Settings_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Permissions_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Roles_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Activity_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Templates_model" initialized
INFO - 2021-07-17 01:17:04 --> Database Driver Class Initialized
INFO - 2021-07-17 01:17:04 --> Config Class Initialized
INFO - 2021-07-17 01:17:04 --> Hooks Class Initialized
DEBUG - 2021-07-17 01:17:04 --> UTF-8 Support Enabled
INFO - 2021-07-17 01:17:04 --> Utf8 Class Initialized
INFO - 2021-07-17 01:17:04 --> URI Class Initialized
INFO - 2021-07-17 01:17:04 --> Router Class Initialized
INFO - 2021-07-17 01:17:04 --> Output Class Initialized
INFO - 2021-07-17 01:17:04 --> Security Class Initialized
DEBUG - 2021-07-17 01:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 01:17:04 --> Input Class Initialized
INFO - 2021-07-17 01:17:04 --> Language Class Initialized
INFO - 2021-07-17 01:17:04 --> Loader Class Initialized
INFO - 2021-07-17 01:17:04 --> Helper loaded: basic_helper
INFO - 2021-07-17 01:17:04 --> Helper loaded: url_helper
INFO - 2021-07-17 01:17:04 --> Helper loaded: file_helper
INFO - 2021-07-17 01:17:04 --> Helper loaded: form_helper
INFO - 2021-07-17 01:17:04 --> Helper loaded: cookie_helper
INFO - 2021-07-17 01:17:04 --> Helper loaded: security_helper
INFO - 2021-07-17 01:17:04 --> Helper loaded: directory_helper
INFO - 2021-07-17 01:17:04 --> Helper loaded: language_helper
INFO - 2021-07-17 01:17:04 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 01:17:04 --> Helper loaded: general_helper
INFO - 2021-07-17 01:17:04 --> Controller Class Initialized
INFO - 2021-07-17 01:17:04 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 01:17:04 --> Database Driver Class Initialized
INFO - 2021-07-17 01:17:04 --> Final output sent to browser
DEBUG - 2021-07-17 01:17:04 --> Total execution time: 0.1121
INFO - 2021-07-17 01:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 01:17:04 --> Parser Class Initialized
INFO - 2021-07-17 01:17:04 --> Form Validation Class Initialized
INFO - 2021-07-17 01:17:04 --> Upload Class Initialized
INFO - 2021-07-17 01:17:04 --> Email Class Initialized
DEBUG - 2021-07-17 01:17:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 01:17:04 --> MY_Model class loaded
INFO - 2021-07-17 01:17:04 --> Model "Users_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Settings_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Permissions_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Roles_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Activity_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Templates_model" initialized
INFO - 2021-07-17 01:17:04 --> Database Driver Class Initialized
INFO - 2021-07-17 01:17:04 --> Config Class Initialized
INFO - 2021-07-17 01:17:04 --> Hooks Class Initialized
DEBUG - 2021-07-17 01:17:04 --> UTF-8 Support Enabled
INFO - 2021-07-17 01:17:04 --> Utf8 Class Initialized
INFO - 2021-07-17 01:17:04 --> URI Class Initialized
INFO - 2021-07-17 01:17:04 --> Router Class Initialized
INFO - 2021-07-17 01:17:04 --> Output Class Initialized
INFO - 2021-07-17 01:17:04 --> Security Class Initialized
DEBUG - 2021-07-17 01:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 01:17:04 --> Input Class Initialized
INFO - 2021-07-17 01:17:04 --> Language Class Initialized
INFO - 2021-07-17 01:17:04 --> Loader Class Initialized
INFO - 2021-07-17 01:17:04 --> Helper loaded: basic_helper
INFO - 2021-07-17 01:17:04 --> Helper loaded: url_helper
INFO - 2021-07-17 01:17:04 --> Helper loaded: file_helper
INFO - 2021-07-17 01:17:04 --> Helper loaded: form_helper
INFO - 2021-07-17 01:17:04 --> Helper loaded: cookie_helper
INFO - 2021-07-17 01:17:04 --> Helper loaded: security_helper
INFO - 2021-07-17 01:17:04 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 01:17:04 --> Helper loaded: directory_helper
INFO - 2021-07-17 01:17:04 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 01:17:04 --> Controller Class Initialized
INFO - 2021-07-17 01:17:04 --> Helper loaded: language_helper
INFO - 2021-07-17 01:17:04 --> Helper loaded: general_helper
INFO - 2021-07-17 01:17:04 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 01:17:04 --> Final output sent to browser
INFO - 2021-07-17 01:17:04 --> Database Driver Class Initialized
DEBUG - 2021-07-17 01:17:04 --> Total execution time: 0.1369
INFO - 2021-07-17 01:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 01:17:04 --> Parser Class Initialized
DEBUG - 2021-07-17 01:17:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 01:17:04 --> Form Validation Class Initialized
INFO - 2021-07-17 01:17:04 --> Upload Class Initialized
INFO - 2021-07-17 01:17:04 --> Email Class Initialized
INFO - 2021-07-17 01:17:04 --> MY_Model class loaded
INFO - 2021-07-17 01:17:04 --> Model "Users_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Settings_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Permissions_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Roles_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Activity_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Templates_model" initialized
INFO - 2021-07-17 01:17:04 --> Database Driver Class Initialized
INFO - 2021-07-17 01:17:04 --> Config Class Initialized
INFO - 2021-07-17 01:17:04 --> Hooks Class Initialized
DEBUG - 2021-07-17 01:17:04 --> UTF-8 Support Enabled
INFO - 2021-07-17 01:17:04 --> Utf8 Class Initialized
INFO - 2021-07-17 01:17:04 --> URI Class Initialized
INFO - 2021-07-17 01:17:04 --> Router Class Initialized
INFO - 2021-07-17 01:17:04 --> Output Class Initialized
INFO - 2021-07-17 01:17:04 --> Security Class Initialized
DEBUG - 2021-07-17 01:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 01:17:04 --> Input Class Initialized
INFO - 2021-07-17 01:17:04 --> Language Class Initialized
INFO - 2021-07-17 01:17:04 --> Loader Class Initialized
INFO - 2021-07-17 01:17:04 --> Helper loaded: basic_helper
INFO - 2021-07-17 01:17:04 --> Helper loaded: url_helper
INFO - 2021-07-17 01:17:04 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 01:17:04 --> Helper loaded: file_helper
INFO - 2021-07-17 01:17:04 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 01:17:04 --> Controller Class Initialized
INFO - 2021-07-17 01:17:04 --> Helper loaded: form_helper
INFO - 2021-07-17 01:17:04 --> Helper loaded: cookie_helper
INFO - 2021-07-17 01:17:04 --> Helper loaded: security_helper
INFO - 2021-07-17 01:17:04 --> Helper loaded: directory_helper
INFO - 2021-07-17 01:17:04 --> Final output sent to browser
INFO - 2021-07-17 01:17:04 --> Helper loaded: language_helper
DEBUG - 2021-07-17 01:17:04 --> Total execution time: 0.1596
INFO - 2021-07-17 01:17:04 --> Helper loaded: general_helper
INFO - 2021-07-17 01:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 01:17:04 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 01:17:04 --> Parser Class Initialized
INFO - 2021-07-17 01:17:04 --> Database Driver Class Initialized
INFO - 2021-07-17 01:17:04 --> Form Validation Class Initialized
INFO - 2021-07-17 01:17:04 --> Upload Class Initialized
INFO - 2021-07-17 01:17:04 --> Email Class Initialized
DEBUG - 2021-07-17 01:17:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 01:17:04 --> MY_Model class loaded
INFO - 2021-07-17 01:17:04 --> Model "Users_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Settings_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Permissions_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Roles_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Activity_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Templates_model" initialized
INFO - 2021-07-17 01:17:04 --> Database Driver Class Initialized
INFO - 2021-07-17 01:17:04 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 01:17:04 --> Controller Class Initialized
INFO - 2021-07-17 01:17:04 --> Final output sent to browser
DEBUG - 2021-07-17 01:17:04 --> Total execution time: 0.1911
INFO - 2021-07-17 01:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 01:17:04 --> Parser Class Initialized
INFO - 2021-07-17 01:17:04 --> Form Validation Class Initialized
INFO - 2021-07-17 01:17:04 --> Upload Class Initialized
INFO - 2021-07-17 01:17:04 --> Email Class Initialized
INFO - 2021-07-17 01:17:04 --> MY_Model class loaded
INFO - 2021-07-17 01:17:04 --> Model "Users_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Settings_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Permissions_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Roles_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Activity_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Templates_model" initialized
INFO - 2021-07-17 01:17:04 --> Database Driver Class Initialized
INFO - 2021-07-17 01:17:04 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 01:17:04 --> Controller Class Initialized
INFO - 2021-07-17 01:17:04 --> Final output sent to browser
DEBUG - 2021-07-17 01:17:04 --> Total execution time: 0.1305
INFO - 2021-07-17 01:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 01:17:04 --> Parser Class Initialized
INFO - 2021-07-17 01:17:04 --> Form Validation Class Initialized
INFO - 2021-07-17 01:17:04 --> Upload Class Initialized
INFO - 2021-07-17 01:17:04 --> Email Class Initialized
INFO - 2021-07-17 01:17:04 --> MY_Model class loaded
INFO - 2021-07-17 01:17:04 --> Model "Users_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Settings_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Permissions_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Roles_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Activity_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Templates_model" initialized
INFO - 2021-07-17 01:17:04 --> Database Driver Class Initialized
INFO - 2021-07-17 01:17:04 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 01:17:04 --> Controller Class Initialized
INFO - 2021-07-17 01:17:04 --> Final output sent to browser
DEBUG - 2021-07-17 01:17:04 --> Total execution time: 0.1288
INFO - 2021-07-17 01:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 01:17:04 --> Parser Class Initialized
INFO - 2021-07-17 01:17:04 --> Form Validation Class Initialized
INFO - 2021-07-17 01:17:04 --> Upload Class Initialized
INFO - 2021-07-17 01:17:04 --> Email Class Initialized
INFO - 2021-07-17 01:17:04 --> MY_Model class loaded
INFO - 2021-07-17 01:17:04 --> Model "Users_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Settings_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Permissions_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Roles_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Activity_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Templates_model" initialized
INFO - 2021-07-17 01:17:04 --> Database Driver Class Initialized
INFO - 2021-07-17 01:17:04 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 01:17:04 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 01:17:04 --> Controller Class Initialized
INFO - 2021-07-17 01:17:04 --> Final output sent to browser
DEBUG - 2021-07-17 01:17:04 --> Total execution time: 0.1269
INFO - 2021-07-17 01:17:05 --> Config Class Initialized
INFO - 2021-07-17 01:17:05 --> Hooks Class Initialized
DEBUG - 2021-07-17 01:17:05 --> UTF-8 Support Enabled
INFO - 2021-07-17 01:17:05 --> Utf8 Class Initialized
INFO - 2021-07-17 01:17:05 --> URI Class Initialized
INFO - 2021-07-17 01:17:05 --> Router Class Initialized
INFO - 2021-07-17 01:17:05 --> Output Class Initialized
INFO - 2021-07-17 01:17:05 --> Security Class Initialized
DEBUG - 2021-07-17 01:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 01:17:05 --> Input Class Initialized
INFO - 2021-07-17 01:17:05 --> Language Class Initialized
INFO - 2021-07-17 01:17:05 --> Loader Class Initialized
INFO - 2021-07-17 01:17:05 --> Helper loaded: basic_helper
INFO - 2021-07-17 01:17:05 --> Helper loaded: url_helper
INFO - 2021-07-17 01:17:05 --> Helper loaded: file_helper
INFO - 2021-07-17 01:17:05 --> Helper loaded: form_helper
INFO - 2021-07-17 01:17:05 --> Helper loaded: cookie_helper
INFO - 2021-07-17 01:17:05 --> Helper loaded: security_helper
INFO - 2021-07-17 01:17:05 --> Helper loaded: directory_helper
INFO - 2021-07-17 01:17:05 --> Helper loaded: language_helper
INFO - 2021-07-17 01:17:05 --> Helper loaded: general_helper
INFO - 2021-07-17 01:17:05 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 01:17:05 --> Database Driver Class Initialized
DEBUG - 2021-07-17 01:17:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 01:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 01:17:05 --> Parser Class Initialized
INFO - 2021-07-17 01:17:05 --> Form Validation Class Initialized
INFO - 2021-07-17 01:17:05 --> Upload Class Initialized
INFO - 2021-07-17 01:17:05 --> Email Class Initialized
INFO - 2021-07-17 01:17:05 --> MY_Model class loaded
INFO - 2021-07-17 01:17:05 --> Model "Users_model" initialized
INFO - 2021-07-17 01:17:05 --> Model "Settings_model" initialized
INFO - 2021-07-17 01:17:05 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 01:17:05 --> Model "Permissions_model" initialized
INFO - 2021-07-17 01:17:05 --> Model "Roles_model" initialized
INFO - 2021-07-17 01:17:05 --> Model "Activity_model" initialized
INFO - 2021-07-17 01:17:05 --> Model "Templates_model" initialized
INFO - 2021-07-17 01:17:05 --> Database Driver Class Initialized
INFO - 2021-07-17 01:17:05 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 01:17:05 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 01:17:05 --> Controller Class Initialized
ERROR - 2021-07-17 01:17:05 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 01:17:06 --> File loaded: C:\wamp64\www\crm\application\views\activity_logs/list.php
INFO - 2021-07-17 01:17:06 --> Final output sent to browser
DEBUG - 2021-07-17 01:17:06 --> Total execution time: 0.1919
INFO - 2021-07-17 01:17:06 --> Config Class Initialized
INFO - 2021-07-17 01:17:06 --> Hooks Class Initialized
DEBUG - 2021-07-17 01:17:06 --> UTF-8 Support Enabled
INFO - 2021-07-17 01:17:06 --> Utf8 Class Initialized
INFO - 2021-07-17 01:17:06 --> URI Class Initialized
INFO - 2021-07-17 01:17:06 --> Router Class Initialized
INFO - 2021-07-17 01:17:06 --> Output Class Initialized
INFO - 2021-07-17 01:17:06 --> Security Class Initialized
DEBUG - 2021-07-17 01:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 01:17:06 --> Input Class Initialized
INFO - 2021-07-17 01:17:06 --> Language Class Initialized
INFO - 2021-07-17 01:17:06 --> Loader Class Initialized
INFO - 2021-07-17 01:17:06 --> Helper loaded: basic_helper
INFO - 2021-07-17 01:17:06 --> Helper loaded: url_helper
INFO - 2021-07-17 01:17:06 --> Helper loaded: file_helper
INFO - 2021-07-17 01:17:06 --> Helper loaded: form_helper
INFO - 2021-07-17 01:17:06 --> Helper loaded: cookie_helper
INFO - 2021-07-17 01:17:06 --> Helper loaded: security_helper
INFO - 2021-07-17 01:17:06 --> Helper loaded: directory_helper
INFO - 2021-07-17 01:17:06 --> Helper loaded: language_helper
INFO - 2021-07-17 01:17:06 --> Helper loaded: general_helper
INFO - 2021-07-17 01:17:06 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 01:17:06 --> Database Driver Class Initialized
DEBUG - 2021-07-17 01:17:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 01:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 01:17:07 --> Parser Class Initialized
INFO - 2021-07-17 01:17:07 --> Form Validation Class Initialized
INFO - 2021-07-17 01:17:07 --> Upload Class Initialized
INFO - 2021-07-17 01:17:07 --> Email Class Initialized
INFO - 2021-07-17 01:17:07 --> MY_Model class loaded
INFO - 2021-07-17 01:17:07 --> Model "Users_model" initialized
INFO - 2021-07-17 01:17:07 --> Model "Settings_model" initialized
INFO - 2021-07-17 01:17:07 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 01:17:07 --> Model "Permissions_model" initialized
INFO - 2021-07-17 01:17:07 --> Model "Roles_model" initialized
INFO - 2021-07-17 01:17:07 --> Model "Activity_model" initialized
INFO - 2021-07-17 01:17:07 --> Model "Templates_model" initialized
INFO - 2021-07-17 01:17:07 --> Database Driver Class Initialized
INFO - 2021-07-17 01:17:07 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 01:17:07 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 01:17:07 --> Controller Class Initialized
ERROR - 2021-07-17 01:17:07 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 01:17:07 --> File loaded: C:\wamp64\www\crm\application\views\permissions/list.php
INFO - 2021-07-17 01:17:07 --> Final output sent to browser
DEBUG - 2021-07-17 01:17:07 --> Total execution time: 0.1290
INFO - 2021-07-17 01:17:07 --> Config Class Initialized
INFO - 2021-07-17 01:17:07 --> Hooks Class Initialized
DEBUG - 2021-07-17 01:17:07 --> UTF-8 Support Enabled
INFO - 2021-07-17 01:17:07 --> Utf8 Class Initialized
INFO - 2021-07-17 01:17:07 --> URI Class Initialized
INFO - 2021-07-17 01:17:07 --> Router Class Initialized
INFO - 2021-07-17 01:17:07 --> Output Class Initialized
INFO - 2021-07-17 01:17:07 --> Security Class Initialized
DEBUG - 2021-07-17 01:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 01:17:07 --> Input Class Initialized
INFO - 2021-07-17 01:17:07 --> Language Class Initialized
INFO - 2021-07-17 01:17:07 --> Loader Class Initialized
INFO - 2021-07-17 01:17:07 --> Helper loaded: basic_helper
INFO - 2021-07-17 01:17:07 --> Helper loaded: url_helper
INFO - 2021-07-17 01:17:07 --> Helper loaded: file_helper
INFO - 2021-07-17 01:17:07 --> Helper loaded: form_helper
INFO - 2021-07-17 01:17:07 --> Helper loaded: cookie_helper
INFO - 2021-07-17 01:17:07 --> Helper loaded: security_helper
INFO - 2021-07-17 01:17:07 --> Helper loaded: directory_helper
INFO - 2021-07-17 01:17:07 --> Helper loaded: language_helper
INFO - 2021-07-17 01:17:07 --> Helper loaded: general_helper
INFO - 2021-07-17 01:17:07 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 01:17:07 --> Database Driver Class Initialized
DEBUG - 2021-07-17 01:17:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 01:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 01:17:07 --> Parser Class Initialized
INFO - 2021-07-17 01:17:07 --> Form Validation Class Initialized
INFO - 2021-07-17 01:17:07 --> Upload Class Initialized
INFO - 2021-07-17 01:17:07 --> Email Class Initialized
INFO - 2021-07-17 01:17:07 --> MY_Model class loaded
INFO - 2021-07-17 01:17:07 --> Model "Users_model" initialized
INFO - 2021-07-17 01:17:07 --> Model "Settings_model" initialized
INFO - 2021-07-17 01:17:07 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 01:17:07 --> Model "Permissions_model" initialized
INFO - 2021-07-17 01:17:07 --> Model "Roles_model" initialized
INFO - 2021-07-17 01:17:07 --> Model "Activity_model" initialized
INFO - 2021-07-17 01:17:07 --> Model "Templates_model" initialized
INFO - 2021-07-17 01:17:07 --> Database Driver Class Initialized
INFO - 2021-07-17 01:17:07 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 01:17:07 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 01:17:07 --> Controller Class Initialized
ERROR - 2021-07-17 01:17:07 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 01:17:07 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-17 01:17:07 --> Final output sent to browser
DEBUG - 2021-07-17 01:17:07 --> Total execution time: 0.1545
INFO - 2021-07-17 01:22:55 --> Config Class Initialized
INFO - 2021-07-17 01:22:55 --> Hooks Class Initialized
DEBUG - 2021-07-17 01:22:55 --> UTF-8 Support Enabled
INFO - 2021-07-17 01:22:55 --> Utf8 Class Initialized
INFO - 2021-07-17 01:22:55 --> URI Class Initialized
INFO - 2021-07-17 01:22:55 --> Router Class Initialized
INFO - 2021-07-17 01:22:55 --> Output Class Initialized
INFO - 2021-07-17 01:22:55 --> Security Class Initialized
DEBUG - 2021-07-17 01:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 01:22:55 --> Input Class Initialized
INFO - 2021-07-17 01:22:55 --> Language Class Initialized
INFO - 2021-07-17 01:22:55 --> Loader Class Initialized
INFO - 2021-07-17 01:22:55 --> Helper loaded: basic_helper
INFO - 2021-07-17 01:22:55 --> Helper loaded: url_helper
INFO - 2021-07-17 01:22:55 --> Helper loaded: file_helper
INFO - 2021-07-17 01:22:55 --> Helper loaded: form_helper
INFO - 2021-07-17 01:22:55 --> Helper loaded: cookie_helper
INFO - 2021-07-17 01:22:55 --> Helper loaded: security_helper
INFO - 2021-07-17 01:22:55 --> Helper loaded: directory_helper
INFO - 2021-07-17 01:22:55 --> Helper loaded: language_helper
INFO - 2021-07-17 01:22:55 --> Helper loaded: general_helper
INFO - 2021-07-17 01:22:55 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 01:22:55 --> Database Driver Class Initialized
DEBUG - 2021-07-17 01:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 01:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 01:22:55 --> Parser Class Initialized
INFO - 2021-07-17 01:22:55 --> Form Validation Class Initialized
INFO - 2021-07-17 01:22:55 --> Upload Class Initialized
INFO - 2021-07-17 01:22:55 --> Email Class Initialized
INFO - 2021-07-17 01:22:55 --> MY_Model class loaded
INFO - 2021-07-17 01:22:55 --> Model "Users_model" initialized
INFO - 2021-07-17 01:22:55 --> Model "Settings_model" initialized
INFO - 2021-07-17 01:22:55 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 01:22:55 --> Model "Permissions_model" initialized
INFO - 2021-07-17 01:22:55 --> Model "Roles_model" initialized
INFO - 2021-07-17 01:22:55 --> Model "Activity_model" initialized
INFO - 2021-07-17 01:22:55 --> Model "Templates_model" initialized
INFO - 2021-07-17 01:22:55 --> Database Driver Class Initialized
INFO - 2021-07-17 01:22:56 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 01:22:56 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 01:22:56 --> Controller Class Initialized
ERROR - 2021-07-17 01:22:56 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 01:22:56 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-17 01:22:56 --> Final output sent to browser
DEBUG - 2021-07-17 01:22:56 --> Total execution time: 0.5497
INFO - 2021-07-17 01:23:34 --> Config Class Initialized
INFO - 2021-07-17 01:23:34 --> Hooks Class Initialized
DEBUG - 2021-07-17 01:23:34 --> UTF-8 Support Enabled
INFO - 2021-07-17 01:23:34 --> Utf8 Class Initialized
INFO - 2021-07-17 01:23:34 --> URI Class Initialized
INFO - 2021-07-17 01:23:34 --> Router Class Initialized
INFO - 2021-07-17 01:23:34 --> Output Class Initialized
INFO - 2021-07-17 01:23:34 --> Security Class Initialized
DEBUG - 2021-07-17 01:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 01:23:34 --> Input Class Initialized
INFO - 2021-07-17 01:23:34 --> Language Class Initialized
INFO - 2021-07-17 01:23:34 --> Loader Class Initialized
INFO - 2021-07-17 01:23:34 --> Helper loaded: basic_helper
INFO - 2021-07-17 01:23:34 --> Helper loaded: url_helper
INFO - 2021-07-17 01:23:34 --> Helper loaded: file_helper
INFO - 2021-07-17 01:23:34 --> Helper loaded: form_helper
INFO - 2021-07-17 01:23:34 --> Helper loaded: cookie_helper
INFO - 2021-07-17 01:23:34 --> Helper loaded: security_helper
INFO - 2021-07-17 01:23:34 --> Helper loaded: directory_helper
INFO - 2021-07-17 01:23:34 --> Helper loaded: language_helper
INFO - 2021-07-17 01:23:34 --> Helper loaded: general_helper
INFO - 2021-07-17 01:23:34 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 01:23:34 --> Database Driver Class Initialized
DEBUG - 2021-07-17 01:23:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 01:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 01:23:34 --> Parser Class Initialized
INFO - 2021-07-17 01:23:34 --> Form Validation Class Initialized
INFO - 2021-07-17 01:23:34 --> Upload Class Initialized
INFO - 2021-07-17 01:23:34 --> Email Class Initialized
INFO - 2021-07-17 01:23:34 --> MY_Model class loaded
INFO - 2021-07-17 01:23:34 --> Model "Users_model" initialized
INFO - 2021-07-17 01:23:34 --> Model "Settings_model" initialized
INFO - 2021-07-17 01:23:34 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 01:23:34 --> Model "Permissions_model" initialized
INFO - 2021-07-17 01:23:34 --> Model "Roles_model" initialized
INFO - 2021-07-17 01:23:34 --> Model "Activity_model" initialized
INFO - 2021-07-17 01:23:34 --> Model "Templates_model" initialized
INFO - 2021-07-17 01:23:34 --> Database Driver Class Initialized
INFO - 2021-07-17 01:23:34 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 01:23:34 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 01:23:34 --> Controller Class Initialized
ERROR - 2021-07-17 01:23:34 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 01:23:34 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 01:23:34 --> Final output sent to browser
DEBUG - 2021-07-17 01:23:34 --> Total execution time: 0.1223
INFO - 2021-07-17 02:06:38 --> Config Class Initialized
INFO - 2021-07-17 02:06:38 --> Hooks Class Initialized
DEBUG - 2021-07-17 02:06:38 --> UTF-8 Support Enabled
INFO - 2021-07-17 02:06:38 --> Utf8 Class Initialized
INFO - 2021-07-17 02:06:38 --> URI Class Initialized
INFO - 2021-07-17 02:06:38 --> Router Class Initialized
INFO - 2021-07-17 02:06:38 --> Output Class Initialized
INFO - 2021-07-17 02:06:38 --> Security Class Initialized
DEBUG - 2021-07-17 02:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 02:06:38 --> Input Class Initialized
INFO - 2021-07-17 02:06:38 --> Language Class Initialized
INFO - 2021-07-17 02:06:38 --> Loader Class Initialized
INFO - 2021-07-17 02:06:38 --> Helper loaded: basic_helper
INFO - 2021-07-17 02:06:38 --> Helper loaded: url_helper
INFO - 2021-07-17 02:06:38 --> Helper loaded: file_helper
INFO - 2021-07-17 02:06:38 --> Helper loaded: form_helper
INFO - 2021-07-17 02:06:38 --> Helper loaded: cookie_helper
INFO - 2021-07-17 02:06:38 --> Helper loaded: security_helper
INFO - 2021-07-17 02:06:38 --> Helper loaded: directory_helper
INFO - 2021-07-17 02:06:38 --> Helper loaded: language_helper
INFO - 2021-07-17 02:06:38 --> Helper loaded: general_helper
INFO - 2021-07-17 02:06:38 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 02:06:38 --> Database Driver Class Initialized
DEBUG - 2021-07-17 02:06:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 02:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 02:06:38 --> Parser Class Initialized
INFO - 2021-07-17 02:06:38 --> Form Validation Class Initialized
INFO - 2021-07-17 02:06:38 --> Upload Class Initialized
INFO - 2021-07-17 02:06:38 --> Email Class Initialized
INFO - 2021-07-17 02:06:38 --> MY_Model class loaded
INFO - 2021-07-17 02:06:38 --> Model "Users_model" initialized
INFO - 2021-07-17 02:06:38 --> Model "Settings_model" initialized
INFO - 2021-07-17 02:06:38 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 02:06:38 --> Model "Permissions_model" initialized
INFO - 2021-07-17 02:06:38 --> Model "Roles_model" initialized
INFO - 2021-07-17 02:06:38 --> Model "Activity_model" initialized
INFO - 2021-07-17 02:06:38 --> Model "Templates_model" initialized
INFO - 2021-07-17 02:06:38 --> Database Driver Class Initialized
INFO - 2021-07-17 02:06:38 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 02:06:38 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 02:06:38 --> Controller Class Initialized
ERROR - 2021-07-17 02:06:38 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 02:06:38 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-17 02:06:38 --> Final output sent to browser
DEBUG - 2021-07-17 02:06:38 --> Total execution time: 0.1216
INFO - 2021-07-17 09:53:03 --> Config Class Initialized
INFO - 2021-07-17 09:53:03 --> Hooks Class Initialized
DEBUG - 2021-07-17 09:53:03 --> UTF-8 Support Enabled
INFO - 2021-07-17 09:53:03 --> Utf8 Class Initialized
INFO - 2021-07-17 09:53:03 --> URI Class Initialized
DEBUG - 2021-07-17 09:53:03 --> No URI present. Default controller set.
INFO - 2021-07-17 09:53:03 --> Router Class Initialized
INFO - 2021-07-17 09:53:03 --> Output Class Initialized
INFO - 2021-07-17 09:53:03 --> Security Class Initialized
DEBUG - 2021-07-17 09:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 09:53:03 --> Input Class Initialized
INFO - 2021-07-17 09:53:03 --> Language Class Initialized
INFO - 2021-07-17 09:53:03 --> Loader Class Initialized
INFO - 2021-07-17 09:53:03 --> Helper loaded: basic_helper
INFO - 2021-07-17 09:53:03 --> Helper loaded: url_helper
INFO - 2021-07-17 09:53:03 --> Helper loaded: file_helper
INFO - 2021-07-17 09:53:03 --> Helper loaded: form_helper
INFO - 2021-07-17 09:53:03 --> Helper loaded: cookie_helper
INFO - 2021-07-17 09:53:03 --> Helper loaded: security_helper
INFO - 2021-07-17 09:53:03 --> Helper loaded: directory_helper
INFO - 2021-07-17 09:53:03 --> Helper loaded: language_helper
INFO - 2021-07-17 09:53:03 --> Helper loaded: general_helper
INFO - 2021-07-17 09:53:03 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 09:53:03 --> Database Driver Class Initialized
DEBUG - 2021-07-17 09:53:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 09:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 09:53:03 --> Parser Class Initialized
INFO - 2021-07-17 09:53:03 --> Form Validation Class Initialized
INFO - 2021-07-17 09:53:03 --> Upload Class Initialized
INFO - 2021-07-17 09:53:03 --> Email Class Initialized
INFO - 2021-07-17 09:53:03 --> MY_Model class loaded
INFO - 2021-07-17 09:53:03 --> Model "Users_model" initialized
INFO - 2021-07-17 09:53:03 --> Model "Settings_model" initialized
INFO - 2021-07-17 09:53:03 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 09:53:03 --> Model "Permissions_model" initialized
INFO - 2021-07-17 09:53:03 --> Model "Roles_model" initialized
INFO - 2021-07-17 09:53:03 --> Model "Activity_model" initialized
INFO - 2021-07-17 09:53:03 --> Model "Templates_model" initialized
INFO - 2021-07-17 09:53:03 --> Database Driver Class Initialized
INFO - 2021-07-17 09:53:03 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 09:53:03 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 09:53:03 --> Controller Class Initialized
ERROR - 2021-07-17 09:53:03 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 09:53:03 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-17 09:53:03 --> Final output sent to browser
DEBUG - 2021-07-17 09:53:03 --> Total execution time: 0.1741
INFO - 2021-07-17 09:53:05 --> Config Class Initialized
INFO - 2021-07-17 09:53:05 --> Hooks Class Initialized
DEBUG - 2021-07-17 09:53:05 --> UTF-8 Support Enabled
INFO - 2021-07-17 09:53:05 --> Utf8 Class Initialized
INFO - 2021-07-17 09:53:05 --> URI Class Initialized
INFO - 2021-07-17 09:53:05 --> Router Class Initialized
INFO - 2021-07-17 09:53:05 --> Output Class Initialized
INFO - 2021-07-17 09:53:05 --> Security Class Initialized
DEBUG - 2021-07-17 09:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 09:53:05 --> Input Class Initialized
INFO - 2021-07-17 09:53:05 --> Language Class Initialized
ERROR - 2021-07-17 09:53:05 --> 404 Page Not Found: Faviconico/index
INFO - 2021-07-17 09:53:06 --> Config Class Initialized
INFO - 2021-07-17 09:53:06 --> Hooks Class Initialized
DEBUG - 2021-07-17 09:53:06 --> UTF-8 Support Enabled
INFO - 2021-07-17 09:53:06 --> Utf8 Class Initialized
INFO - 2021-07-17 09:53:06 --> URI Class Initialized
INFO - 2021-07-17 09:53:06 --> Router Class Initialized
INFO - 2021-07-17 09:53:06 --> Output Class Initialized
INFO - 2021-07-17 09:53:06 --> Security Class Initialized
DEBUG - 2021-07-17 09:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 09:53:06 --> Input Class Initialized
INFO - 2021-07-17 09:53:06 --> Language Class Initialized
INFO - 2021-07-17 09:53:06 --> Loader Class Initialized
INFO - 2021-07-17 09:53:06 --> Helper loaded: basic_helper
INFO - 2021-07-17 09:53:06 --> Helper loaded: url_helper
INFO - 2021-07-17 09:53:06 --> Helper loaded: file_helper
INFO - 2021-07-17 09:53:06 --> Helper loaded: form_helper
INFO - 2021-07-17 09:53:06 --> Helper loaded: cookie_helper
INFO - 2021-07-17 09:53:06 --> Helper loaded: security_helper
INFO - 2021-07-17 09:53:06 --> Helper loaded: directory_helper
INFO - 2021-07-17 09:53:06 --> Helper loaded: language_helper
INFO - 2021-07-17 09:53:06 --> Helper loaded: general_helper
INFO - 2021-07-17 09:53:06 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 09:53:06 --> Database Driver Class Initialized
DEBUG - 2021-07-17 09:53:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 09:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 09:53:06 --> Parser Class Initialized
INFO - 2021-07-17 09:53:06 --> Form Validation Class Initialized
INFO - 2021-07-17 09:53:06 --> Upload Class Initialized
INFO - 2021-07-17 09:53:06 --> Email Class Initialized
INFO - 2021-07-17 09:53:06 --> MY_Model class loaded
INFO - 2021-07-17 09:53:06 --> Model "Users_model" initialized
INFO - 2021-07-17 09:53:06 --> Model "Settings_model" initialized
INFO - 2021-07-17 09:53:06 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 09:53:06 --> Model "Permissions_model" initialized
INFO - 2021-07-17 09:53:06 --> Model "Roles_model" initialized
INFO - 2021-07-17 09:53:06 --> Model "Activity_model" initialized
INFO - 2021-07-17 09:53:06 --> Model "Templates_model" initialized
INFO - 2021-07-17 09:53:06 --> Database Driver Class Initialized
INFO - 2021-07-17 09:53:06 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 09:53:06 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 09:53:06 --> Controller Class Initialized
ERROR - 2021-07-17 09:53:06 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 09:53:06 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-17 09:53:06 --> Final output sent to browser
DEBUG - 2021-07-17 09:53:06 --> Total execution time: 0.1805
INFO - 2021-07-17 09:53:55 --> Config Class Initialized
INFO - 2021-07-17 09:53:55 --> Hooks Class Initialized
DEBUG - 2021-07-17 09:53:55 --> UTF-8 Support Enabled
INFO - 2021-07-17 09:53:55 --> Utf8 Class Initialized
INFO - 2021-07-17 09:53:55 --> URI Class Initialized
INFO - 2021-07-17 09:53:55 --> Router Class Initialized
INFO - 2021-07-17 09:53:55 --> Output Class Initialized
INFO - 2021-07-17 09:53:55 --> Security Class Initialized
DEBUG - 2021-07-17 09:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 09:53:55 --> Input Class Initialized
INFO - 2021-07-17 09:53:55 --> Language Class Initialized
INFO - 2021-07-17 09:53:55 --> Loader Class Initialized
INFO - 2021-07-17 09:53:55 --> Helper loaded: basic_helper
INFO - 2021-07-17 09:53:55 --> Helper loaded: url_helper
INFO - 2021-07-17 09:53:55 --> Helper loaded: file_helper
INFO - 2021-07-17 09:53:55 --> Helper loaded: form_helper
INFO - 2021-07-17 09:53:55 --> Helper loaded: cookie_helper
INFO - 2021-07-17 09:53:55 --> Helper loaded: security_helper
INFO - 2021-07-17 09:53:55 --> Helper loaded: directory_helper
INFO - 2021-07-17 09:53:55 --> Helper loaded: language_helper
INFO - 2021-07-17 09:53:55 --> Helper loaded: general_helper
INFO - 2021-07-17 09:53:55 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 09:53:55 --> Database Driver Class Initialized
DEBUG - 2021-07-17 09:53:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 09:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 09:53:55 --> Parser Class Initialized
INFO - 2021-07-17 09:53:55 --> Form Validation Class Initialized
INFO - 2021-07-17 09:53:55 --> Upload Class Initialized
INFO - 2021-07-17 09:53:55 --> Email Class Initialized
INFO - 2021-07-17 09:53:55 --> MY_Model class loaded
INFO - 2021-07-17 09:53:55 --> Model "Users_model" initialized
INFO - 2021-07-17 09:53:55 --> Model "Settings_model" initialized
INFO - 2021-07-17 09:53:55 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 09:53:55 --> Model "Permissions_model" initialized
INFO - 2021-07-17 09:53:55 --> Model "Roles_model" initialized
INFO - 2021-07-17 09:53:55 --> Model "Activity_model" initialized
INFO - 2021-07-17 09:53:55 --> Model "Templates_model" initialized
INFO - 2021-07-17 09:53:55 --> Database Driver Class Initialized
INFO - 2021-07-17 09:53:55 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 09:53:55 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 09:53:55 --> Controller Class Initialized
ERROR - 2021-07-17 09:53:55 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 09:53:55 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-17 09:53:55 --> Final output sent to browser
DEBUG - 2021-07-17 09:53:55 --> Total execution time: 0.1390
INFO - 2021-07-17 11:35:18 --> Config Class Initialized
INFO - 2021-07-17 11:35:18 --> Hooks Class Initialized
DEBUG - 2021-07-17 11:35:18 --> UTF-8 Support Enabled
INFO - 2021-07-17 11:35:18 --> Utf8 Class Initialized
INFO - 2021-07-17 11:35:18 --> URI Class Initialized
INFO - 2021-07-17 11:35:18 --> Router Class Initialized
INFO - 2021-07-17 11:35:18 --> Output Class Initialized
INFO - 2021-07-17 11:35:18 --> Security Class Initialized
DEBUG - 2021-07-17 11:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 11:35:18 --> Input Class Initialized
INFO - 2021-07-17 11:35:18 --> Language Class Initialized
INFO - 2021-07-17 11:35:18 --> Loader Class Initialized
INFO - 2021-07-17 11:35:18 --> Helper loaded: basic_helper
INFO - 2021-07-17 11:35:18 --> Helper loaded: url_helper
INFO - 2021-07-17 11:35:18 --> Helper loaded: file_helper
INFO - 2021-07-17 11:35:18 --> Helper loaded: form_helper
INFO - 2021-07-17 11:35:18 --> Helper loaded: cookie_helper
INFO - 2021-07-17 11:35:18 --> Helper loaded: security_helper
INFO - 2021-07-17 11:35:18 --> Helper loaded: directory_helper
INFO - 2021-07-17 11:35:18 --> Helper loaded: language_helper
INFO - 2021-07-17 11:35:18 --> Helper loaded: general_helper
INFO - 2021-07-17 11:35:18 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 11:35:18 --> Database Driver Class Initialized
DEBUG - 2021-07-17 11:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 11:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 11:35:18 --> Parser Class Initialized
INFO - 2021-07-17 11:35:18 --> Form Validation Class Initialized
INFO - 2021-07-17 11:35:18 --> Upload Class Initialized
INFO - 2021-07-17 11:35:18 --> Email Class Initialized
INFO - 2021-07-17 11:35:18 --> MY_Model class loaded
INFO - 2021-07-17 11:35:18 --> Model "Users_model" initialized
INFO - 2021-07-17 11:35:18 --> Model "Settings_model" initialized
INFO - 2021-07-17 11:35:18 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 11:35:18 --> Model "Permissions_model" initialized
INFO - 2021-07-17 11:35:18 --> Model "Roles_model" initialized
INFO - 2021-07-17 11:35:18 --> Model "Activity_model" initialized
INFO - 2021-07-17 11:35:18 --> Model "Templates_model" initialized
INFO - 2021-07-17 11:35:18 --> Database Driver Class Initialized
INFO - 2021-07-17 11:35:18 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 11:35:18 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 11:35:18 --> Controller Class Initialized
INFO - 2021-07-17 11:35:43 --> Config Class Initialized
INFO - 2021-07-17 11:35:43 --> Hooks Class Initialized
DEBUG - 2021-07-17 11:35:43 --> UTF-8 Support Enabled
INFO - 2021-07-17 11:35:43 --> Utf8 Class Initialized
INFO - 2021-07-17 11:35:43 --> URI Class Initialized
INFO - 2021-07-17 11:35:43 --> Router Class Initialized
INFO - 2021-07-17 11:35:43 --> Output Class Initialized
INFO - 2021-07-17 11:35:43 --> Security Class Initialized
DEBUG - 2021-07-17 11:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 11:35:43 --> Input Class Initialized
INFO - 2021-07-17 11:35:43 --> Language Class Initialized
INFO - 2021-07-17 11:35:43 --> Loader Class Initialized
INFO - 2021-07-17 11:35:43 --> Helper loaded: basic_helper
INFO - 2021-07-17 11:35:43 --> Helper loaded: url_helper
INFO - 2021-07-17 11:35:43 --> Helper loaded: file_helper
INFO - 2021-07-17 11:35:43 --> Helper loaded: form_helper
INFO - 2021-07-17 11:35:43 --> Helper loaded: cookie_helper
INFO - 2021-07-17 11:35:43 --> Helper loaded: security_helper
INFO - 2021-07-17 11:35:43 --> Helper loaded: directory_helper
INFO - 2021-07-17 11:35:43 --> Helper loaded: language_helper
INFO - 2021-07-17 11:35:43 --> Helper loaded: general_helper
INFO - 2021-07-17 11:35:43 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 11:35:43 --> Database Driver Class Initialized
DEBUG - 2021-07-17 11:35:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 11:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 11:35:43 --> Parser Class Initialized
INFO - 2021-07-17 11:35:43 --> Form Validation Class Initialized
INFO - 2021-07-17 11:35:43 --> Upload Class Initialized
INFO - 2021-07-17 11:35:43 --> Email Class Initialized
INFO - 2021-07-17 11:35:43 --> MY_Model class loaded
INFO - 2021-07-17 11:35:43 --> Model "Users_model" initialized
INFO - 2021-07-17 11:35:43 --> Model "Settings_model" initialized
INFO - 2021-07-17 11:35:43 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 11:35:43 --> Model "Permissions_model" initialized
INFO - 2021-07-17 11:35:43 --> Model "Roles_model" initialized
INFO - 2021-07-17 11:35:43 --> Model "Activity_model" initialized
INFO - 2021-07-17 11:35:43 --> Model "Templates_model" initialized
INFO - 2021-07-17 11:35:43 --> Database Driver Class Initialized
INFO - 2021-07-17 11:35:43 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 11:35:43 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 11:35:43 --> Controller Class Initialized
INFO - 2021-07-17 11:35:43 --> Config Class Initialized
INFO - 2021-07-17 11:35:43 --> Hooks Class Initialized
DEBUG - 2021-07-17 11:35:43 --> UTF-8 Support Enabled
INFO - 2021-07-17 11:35:43 --> Utf8 Class Initialized
INFO - 2021-07-17 11:35:43 --> URI Class Initialized
INFO - 2021-07-17 11:35:43 --> Router Class Initialized
INFO - 2021-07-17 11:35:43 --> Output Class Initialized
INFO - 2021-07-17 11:35:43 --> Security Class Initialized
DEBUG - 2021-07-17 11:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 11:35:43 --> Input Class Initialized
INFO - 2021-07-17 11:35:43 --> Language Class Initialized
INFO - 2021-07-17 11:35:43 --> Loader Class Initialized
INFO - 2021-07-17 11:35:43 --> Helper loaded: basic_helper
INFO - 2021-07-17 11:35:43 --> Helper loaded: url_helper
INFO - 2021-07-17 11:35:43 --> Helper loaded: file_helper
INFO - 2021-07-17 11:35:43 --> Helper loaded: form_helper
INFO - 2021-07-17 11:35:43 --> Helper loaded: cookie_helper
INFO - 2021-07-17 11:35:44 --> Helper loaded: security_helper
INFO - 2021-07-17 11:35:44 --> Helper loaded: directory_helper
INFO - 2021-07-17 11:35:44 --> Helper loaded: language_helper
INFO - 2021-07-17 11:35:44 --> Helper loaded: general_helper
INFO - 2021-07-17 11:35:44 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 11:35:44 --> Database Driver Class Initialized
DEBUG - 2021-07-17 11:35:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 11:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 11:35:44 --> Parser Class Initialized
INFO - 2021-07-17 11:35:44 --> Form Validation Class Initialized
INFO - 2021-07-17 11:35:44 --> Upload Class Initialized
INFO - 2021-07-17 11:35:44 --> Email Class Initialized
INFO - 2021-07-17 11:35:44 --> MY_Model class loaded
INFO - 2021-07-17 11:35:44 --> Model "Users_model" initialized
INFO - 2021-07-17 11:35:44 --> Model "Settings_model" initialized
INFO - 2021-07-17 11:35:44 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 11:35:44 --> Model "Permissions_model" initialized
INFO - 2021-07-17 11:35:44 --> Model "Roles_model" initialized
INFO - 2021-07-17 11:35:44 --> Model "Activity_model" initialized
INFO - 2021-07-17 11:35:44 --> Model "Templates_model" initialized
INFO - 2021-07-17 11:35:44 --> Database Driver Class Initialized
INFO - 2021-07-17 11:35:44 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 11:35:44 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 11:35:44 --> Controller Class Initialized
INFO - 2021-07-17 11:35:44 --> File loaded: C:\wamp64\www\crm\application\views\account/login.php
INFO - 2021-07-17 11:35:44 --> Final output sent to browser
DEBUG - 2021-07-17 11:35:44 --> Total execution time: 0.0660
INFO - 2021-07-17 11:35:44 --> Config Class Initialized
INFO - 2021-07-17 11:35:44 --> Hooks Class Initialized
DEBUG - 2021-07-17 11:35:44 --> UTF-8 Support Enabled
INFO - 2021-07-17 11:35:44 --> Config Class Initialized
INFO - 2021-07-17 11:35:44 --> Utf8 Class Initialized
INFO - 2021-07-17 11:35:44 --> Hooks Class Initialized
INFO - 2021-07-17 11:35:44 --> URI Class Initialized
DEBUG - 2021-07-17 11:35:44 --> UTF-8 Support Enabled
INFO - 2021-07-17 11:35:44 --> Utf8 Class Initialized
INFO - 2021-07-17 11:35:44 --> Router Class Initialized
INFO - 2021-07-17 11:35:44 --> URI Class Initialized
INFO - 2021-07-17 11:35:44 --> Output Class Initialized
INFO - 2021-07-17 11:35:44 --> Security Class Initialized
INFO - 2021-07-17 11:35:44 --> Router Class Initialized
DEBUG - 2021-07-17 11:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 11:35:44 --> Output Class Initialized
INFO - 2021-07-17 11:35:44 --> Input Class Initialized
INFO - 2021-07-17 11:35:44 --> Language Class Initialized
INFO - 2021-07-17 11:35:44 --> Security Class Initialized
DEBUG - 2021-07-17 11:35:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-07-17 11:35:44 --> 404 Page Not Found: Assets/jquery
INFO - 2021-07-17 11:35:44 --> Input Class Initialized
INFO - 2021-07-17 11:35:44 --> Language Class Initialized
ERROR - 2021-07-17 11:35:44 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-17 11:35:44 --> Config Class Initialized
INFO - 2021-07-17 11:35:44 --> Hooks Class Initialized
DEBUG - 2021-07-17 11:35:44 --> UTF-8 Support Enabled
INFO - 2021-07-17 11:35:44 --> Utf8 Class Initialized
INFO - 2021-07-17 11:35:44 --> URI Class Initialized
INFO - 2021-07-17 11:35:44 --> Router Class Initialized
INFO - 2021-07-17 11:35:44 --> Output Class Initialized
INFO - 2021-07-17 11:35:44 --> Security Class Initialized
DEBUG - 2021-07-17 11:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 11:35:44 --> Input Class Initialized
INFO - 2021-07-17 11:35:44 --> Language Class Initialized
ERROR - 2021-07-17 11:35:44 --> 404 Page Not Found: Assets/jquery
INFO - 2021-07-17 11:35:44 --> Config Class Initialized
INFO - 2021-07-17 11:35:44 --> Hooks Class Initialized
DEBUG - 2021-07-17 11:35:44 --> UTF-8 Support Enabled
INFO - 2021-07-17 11:35:44 --> Utf8 Class Initialized
INFO - 2021-07-17 11:35:44 --> URI Class Initialized
INFO - 2021-07-17 11:35:44 --> Router Class Initialized
INFO - 2021-07-17 11:35:44 --> Output Class Initialized
INFO - 2021-07-17 11:35:44 --> Security Class Initialized
DEBUG - 2021-07-17 11:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 11:35:44 --> Input Class Initialized
INFO - 2021-07-17 11:35:44 --> Language Class Initialized
ERROR - 2021-07-17 11:35:44 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-17 11:35:49 --> Config Class Initialized
INFO - 2021-07-17 11:35:49 --> Hooks Class Initialized
DEBUG - 2021-07-17 11:35:49 --> UTF-8 Support Enabled
INFO - 2021-07-17 11:35:49 --> Utf8 Class Initialized
INFO - 2021-07-17 11:35:49 --> URI Class Initialized
INFO - 2021-07-17 11:35:49 --> Router Class Initialized
INFO - 2021-07-17 11:35:49 --> Output Class Initialized
INFO - 2021-07-17 11:35:49 --> Security Class Initialized
DEBUG - 2021-07-17 11:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 11:35:49 --> Input Class Initialized
INFO - 2021-07-17 11:35:49 --> Language Class Initialized
INFO - 2021-07-17 11:35:49 --> Loader Class Initialized
INFO - 2021-07-17 11:35:49 --> Helper loaded: basic_helper
INFO - 2021-07-17 11:35:49 --> Helper loaded: url_helper
INFO - 2021-07-17 11:35:49 --> Helper loaded: file_helper
INFO - 2021-07-17 11:35:49 --> Helper loaded: form_helper
INFO - 2021-07-17 11:35:49 --> Helper loaded: cookie_helper
INFO - 2021-07-17 11:35:49 --> Helper loaded: security_helper
INFO - 2021-07-17 11:35:49 --> Helper loaded: directory_helper
INFO - 2021-07-17 11:35:49 --> Helper loaded: language_helper
INFO - 2021-07-17 11:35:49 --> Helper loaded: general_helper
INFO - 2021-07-17 11:35:49 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 11:35:49 --> Database Driver Class Initialized
DEBUG - 2021-07-17 11:35:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 11:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 11:35:49 --> Parser Class Initialized
INFO - 2021-07-17 11:35:49 --> Form Validation Class Initialized
INFO - 2021-07-17 11:35:49 --> Upload Class Initialized
INFO - 2021-07-17 11:35:49 --> Email Class Initialized
INFO - 2021-07-17 11:35:49 --> MY_Model class loaded
INFO - 2021-07-17 11:35:49 --> Model "Users_model" initialized
INFO - 2021-07-17 11:35:49 --> Model "Settings_model" initialized
INFO - 2021-07-17 11:35:49 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 11:35:49 --> Model "Permissions_model" initialized
INFO - 2021-07-17 11:35:49 --> Model "Roles_model" initialized
INFO - 2021-07-17 11:35:50 --> Model "Activity_model" initialized
INFO - 2021-07-17 11:35:50 --> Model "Templates_model" initialized
INFO - 2021-07-17 11:35:50 --> Database Driver Class Initialized
INFO - 2021-07-17 11:35:50 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 11:35:50 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 11:35:50 --> Controller Class Initialized
DEBUG - 2021-07-17 11:35:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-17 11:35:50 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2021-07-17 11:35:50 --> Config Class Initialized
INFO - 2021-07-17 11:35:50 --> Hooks Class Initialized
DEBUG - 2021-07-17 11:35:50 --> UTF-8 Support Enabled
INFO - 2021-07-17 11:35:50 --> Utf8 Class Initialized
INFO - 2021-07-17 11:35:50 --> URI Class Initialized
DEBUG - 2021-07-17 11:35:50 --> No URI present. Default controller set.
INFO - 2021-07-17 11:35:50 --> Router Class Initialized
INFO - 2021-07-17 11:35:50 --> Output Class Initialized
INFO - 2021-07-17 11:35:50 --> Security Class Initialized
DEBUG - 2021-07-17 11:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 11:35:50 --> Input Class Initialized
INFO - 2021-07-17 11:35:50 --> Language Class Initialized
INFO - 2021-07-17 11:35:50 --> Loader Class Initialized
INFO - 2021-07-17 11:35:50 --> Helper loaded: basic_helper
INFO - 2021-07-17 11:35:50 --> Helper loaded: url_helper
INFO - 2021-07-17 11:35:50 --> Helper loaded: file_helper
INFO - 2021-07-17 11:35:50 --> Helper loaded: form_helper
INFO - 2021-07-17 11:35:50 --> Helper loaded: cookie_helper
INFO - 2021-07-17 11:35:50 --> Helper loaded: security_helper
INFO - 2021-07-17 11:35:50 --> Helper loaded: directory_helper
INFO - 2021-07-17 11:35:50 --> Helper loaded: language_helper
INFO - 2021-07-17 11:35:50 --> Helper loaded: general_helper
INFO - 2021-07-17 11:35:50 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 11:35:50 --> Database Driver Class Initialized
DEBUG - 2021-07-17 11:35:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 11:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 11:35:50 --> Parser Class Initialized
INFO - 2021-07-17 11:35:50 --> Form Validation Class Initialized
INFO - 2021-07-17 11:35:50 --> Upload Class Initialized
INFO - 2021-07-17 11:35:50 --> Email Class Initialized
INFO - 2021-07-17 11:35:50 --> MY_Model class loaded
INFO - 2021-07-17 11:35:50 --> Model "Users_model" initialized
INFO - 2021-07-17 11:35:50 --> Model "Settings_model" initialized
INFO - 2021-07-17 11:35:50 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 11:35:50 --> Model "Permissions_model" initialized
INFO - 2021-07-17 11:35:50 --> Model "Roles_model" initialized
INFO - 2021-07-17 11:35:50 --> Model "Activity_model" initialized
INFO - 2021-07-17 11:35:50 --> Model "Templates_model" initialized
INFO - 2021-07-17 11:35:50 --> Database Driver Class Initialized
INFO - 2021-07-17 11:35:50 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 11:35:50 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 11:35:50 --> Controller Class Initialized
ERROR - 2021-07-17 11:35:50 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 11:35:50 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-17 11:35:50 --> Final output sent to browser
DEBUG - 2021-07-17 11:35:50 --> Total execution time: 0.0609
INFO - 2021-07-17 11:35:59 --> Config Class Initialized
INFO - 2021-07-17 11:35:59 --> Hooks Class Initialized
DEBUG - 2021-07-17 11:35:59 --> UTF-8 Support Enabled
INFO - 2021-07-17 11:35:59 --> Utf8 Class Initialized
INFO - 2021-07-17 11:35:59 --> URI Class Initialized
INFO - 2021-07-17 11:35:59 --> Router Class Initialized
INFO - 2021-07-17 11:35:59 --> Output Class Initialized
INFO - 2021-07-17 11:35:59 --> Security Class Initialized
DEBUG - 2021-07-17 11:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 11:35:59 --> Input Class Initialized
INFO - 2021-07-17 11:35:59 --> Language Class Initialized
INFO - 2021-07-17 11:35:59 --> Loader Class Initialized
INFO - 2021-07-17 11:35:59 --> Helper loaded: basic_helper
INFO - 2021-07-17 11:35:59 --> Helper loaded: url_helper
INFO - 2021-07-17 11:35:59 --> Helper loaded: file_helper
INFO - 2021-07-17 11:35:59 --> Helper loaded: form_helper
INFO - 2021-07-17 11:35:59 --> Helper loaded: cookie_helper
INFO - 2021-07-17 11:35:59 --> Helper loaded: security_helper
INFO - 2021-07-17 11:35:59 --> Helper loaded: directory_helper
INFO - 2021-07-17 11:35:59 --> Helper loaded: language_helper
INFO - 2021-07-17 11:35:59 --> Helper loaded: general_helper
INFO - 2021-07-17 11:35:59 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 11:35:59 --> Database Driver Class Initialized
DEBUG - 2021-07-17 11:35:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 11:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 11:35:59 --> Parser Class Initialized
INFO - 2021-07-17 11:35:59 --> Form Validation Class Initialized
INFO - 2021-07-17 11:35:59 --> Upload Class Initialized
INFO - 2021-07-17 11:35:59 --> Email Class Initialized
INFO - 2021-07-17 11:35:59 --> MY_Model class loaded
INFO - 2021-07-17 11:35:59 --> Model "Users_model" initialized
INFO - 2021-07-17 11:35:59 --> Model "Settings_model" initialized
INFO - 2021-07-17 11:35:59 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 11:35:59 --> Model "Permissions_model" initialized
INFO - 2021-07-17 11:35:59 --> Model "Roles_model" initialized
INFO - 2021-07-17 11:35:59 --> Model "Activity_model" initialized
INFO - 2021-07-17 11:35:59 --> Model "Templates_model" initialized
INFO - 2021-07-17 11:35:59 --> Database Driver Class Initialized
INFO - 2021-07-17 11:35:59 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 11:35:59 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 11:35:59 --> Controller Class Initialized
ERROR - 2021-07-17 11:35:59 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 11:35:59 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 11:35:59 --> Final output sent to browser
DEBUG - 2021-07-17 11:35:59 --> Total execution time: 0.1269
INFO - 2021-07-17 11:37:47 --> Config Class Initialized
INFO - 2021-07-17 11:37:47 --> Hooks Class Initialized
DEBUG - 2021-07-17 11:37:47 --> UTF-8 Support Enabled
INFO - 2021-07-17 11:37:47 --> Utf8 Class Initialized
INFO - 2021-07-17 11:37:47 --> URI Class Initialized
INFO - 2021-07-17 11:37:47 --> Router Class Initialized
INFO - 2021-07-17 11:37:47 --> Output Class Initialized
INFO - 2021-07-17 11:37:47 --> Security Class Initialized
DEBUG - 2021-07-17 11:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 11:37:47 --> Input Class Initialized
INFO - 2021-07-17 11:37:47 --> Language Class Initialized
INFO - 2021-07-17 11:37:47 --> Loader Class Initialized
INFO - 2021-07-17 11:37:47 --> Helper loaded: basic_helper
INFO - 2021-07-17 11:37:47 --> Helper loaded: url_helper
INFO - 2021-07-17 11:37:47 --> Helper loaded: file_helper
INFO - 2021-07-17 11:37:47 --> Helper loaded: form_helper
INFO - 2021-07-17 11:37:47 --> Helper loaded: cookie_helper
INFO - 2021-07-17 11:37:47 --> Helper loaded: security_helper
INFO - 2021-07-17 11:37:47 --> Helper loaded: directory_helper
INFO - 2021-07-17 11:37:47 --> Helper loaded: language_helper
INFO - 2021-07-17 11:37:47 --> Helper loaded: general_helper
INFO - 2021-07-17 11:37:47 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 11:37:47 --> Database Driver Class Initialized
DEBUG - 2021-07-17 11:37:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 11:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 11:37:47 --> Parser Class Initialized
INFO - 2021-07-17 11:37:47 --> Form Validation Class Initialized
INFO - 2021-07-17 11:37:47 --> Upload Class Initialized
INFO - 2021-07-17 11:37:47 --> Email Class Initialized
INFO - 2021-07-17 11:37:47 --> MY_Model class loaded
INFO - 2021-07-17 11:37:47 --> Model "Users_model" initialized
INFO - 2021-07-17 11:37:47 --> Model "Settings_model" initialized
INFO - 2021-07-17 11:37:47 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 11:37:47 --> Model "Permissions_model" initialized
INFO - 2021-07-17 11:37:47 --> Model "Roles_model" initialized
INFO - 2021-07-17 11:37:47 --> Model "Activity_model" initialized
INFO - 2021-07-17 11:37:47 --> Model "Templates_model" initialized
INFO - 2021-07-17 11:37:47 --> Database Driver Class Initialized
INFO - 2021-07-17 11:37:47 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 11:37:47 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 11:37:47 --> Controller Class Initialized
ERROR - 2021-07-17 11:37:47 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 11:37:47 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 11:37:47 --> Final output sent to browser
DEBUG - 2021-07-17 11:37:47 --> Total execution time: 0.1482
INFO - 2021-07-17 11:37:48 --> Config Class Initialized
INFO - 2021-07-17 11:37:48 --> Hooks Class Initialized
DEBUG - 2021-07-17 11:37:48 --> UTF-8 Support Enabled
INFO - 2021-07-17 11:37:48 --> Utf8 Class Initialized
INFO - 2021-07-17 11:37:48 --> URI Class Initialized
INFO - 2021-07-17 11:37:48 --> Router Class Initialized
INFO - 2021-07-17 11:37:48 --> Output Class Initialized
INFO - 2021-07-17 11:37:48 --> Security Class Initialized
DEBUG - 2021-07-17 11:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 11:37:48 --> Input Class Initialized
INFO - 2021-07-17 11:37:48 --> Language Class Initialized
INFO - 2021-07-17 11:37:48 --> Loader Class Initialized
INFO - 2021-07-17 11:37:48 --> Helper loaded: basic_helper
INFO - 2021-07-17 11:37:48 --> Helper loaded: url_helper
INFO - 2021-07-17 11:37:48 --> Helper loaded: file_helper
INFO - 2021-07-17 11:37:48 --> Helper loaded: form_helper
INFO - 2021-07-17 11:37:48 --> Helper loaded: cookie_helper
INFO - 2021-07-17 11:37:48 --> Helper loaded: security_helper
INFO - 2021-07-17 11:37:48 --> Helper loaded: directory_helper
INFO - 2021-07-17 11:37:48 --> Helper loaded: language_helper
INFO - 2021-07-17 11:37:48 --> Helper loaded: general_helper
INFO - 2021-07-17 11:37:48 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 11:37:48 --> Database Driver Class Initialized
DEBUG - 2021-07-17 11:37:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 11:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 11:37:48 --> Parser Class Initialized
INFO - 2021-07-17 11:37:48 --> Form Validation Class Initialized
INFO - 2021-07-17 11:37:48 --> Upload Class Initialized
INFO - 2021-07-17 11:37:48 --> Email Class Initialized
INFO - 2021-07-17 11:37:48 --> MY_Model class loaded
INFO - 2021-07-17 11:37:48 --> Model "Users_model" initialized
INFO - 2021-07-17 11:37:48 --> Model "Settings_model" initialized
INFO - 2021-07-17 11:37:48 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 11:37:48 --> Model "Permissions_model" initialized
INFO - 2021-07-17 11:37:48 --> Model "Roles_model" initialized
INFO - 2021-07-17 11:37:48 --> Model "Activity_model" initialized
INFO - 2021-07-17 11:37:48 --> Model "Templates_model" initialized
INFO - 2021-07-17 11:37:48 --> Database Driver Class Initialized
INFO - 2021-07-17 11:37:48 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 11:37:48 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 11:37:48 --> Controller Class Initialized
ERROR - 2021-07-17 11:37:48 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 11:37:48 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 11:37:48 --> Final output sent to browser
DEBUG - 2021-07-17 11:37:48 --> Total execution time: 0.0620
INFO - 2021-07-17 11:38:06 --> Config Class Initialized
INFO - 2021-07-17 11:38:06 --> Hooks Class Initialized
DEBUG - 2021-07-17 11:38:06 --> UTF-8 Support Enabled
INFO - 2021-07-17 11:38:06 --> Utf8 Class Initialized
INFO - 2021-07-17 11:38:06 --> URI Class Initialized
INFO - 2021-07-17 11:38:06 --> Router Class Initialized
INFO - 2021-07-17 11:38:06 --> Output Class Initialized
INFO - 2021-07-17 11:38:06 --> Security Class Initialized
DEBUG - 2021-07-17 11:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 11:38:06 --> Input Class Initialized
INFO - 2021-07-17 11:38:06 --> Language Class Initialized
INFO - 2021-07-17 11:38:06 --> Loader Class Initialized
INFO - 2021-07-17 11:38:06 --> Helper loaded: basic_helper
INFO - 2021-07-17 11:38:06 --> Helper loaded: url_helper
INFO - 2021-07-17 11:38:06 --> Helper loaded: file_helper
INFO - 2021-07-17 11:38:06 --> Helper loaded: form_helper
INFO - 2021-07-17 11:38:06 --> Helper loaded: cookie_helper
INFO - 2021-07-17 11:38:06 --> Helper loaded: security_helper
INFO - 2021-07-17 11:38:06 --> Helper loaded: directory_helper
INFO - 2021-07-17 11:38:06 --> Helper loaded: language_helper
INFO - 2021-07-17 11:38:06 --> Helper loaded: general_helper
INFO - 2021-07-17 11:38:06 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 11:38:06 --> Database Driver Class Initialized
DEBUG - 2021-07-17 11:38:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 11:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 11:38:06 --> Parser Class Initialized
INFO - 2021-07-17 11:38:06 --> Form Validation Class Initialized
INFO - 2021-07-17 11:38:06 --> Upload Class Initialized
INFO - 2021-07-17 11:38:06 --> Email Class Initialized
INFO - 2021-07-17 11:38:06 --> MY_Model class loaded
INFO - 2021-07-17 11:38:06 --> Model "Users_model" initialized
INFO - 2021-07-17 11:38:06 --> Model "Settings_model" initialized
INFO - 2021-07-17 11:38:06 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 11:38:06 --> Model "Permissions_model" initialized
INFO - 2021-07-17 11:38:06 --> Model "Roles_model" initialized
INFO - 2021-07-17 11:38:06 --> Model "Activity_model" initialized
INFO - 2021-07-17 11:38:06 --> Model "Templates_model" initialized
INFO - 2021-07-17 11:38:06 --> Database Driver Class Initialized
INFO - 2021-07-17 11:38:06 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 11:38:06 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 11:38:06 --> Controller Class Initialized
ERROR - 2021-07-17 11:38:06 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 11:38:06 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 11:38:06 --> Final output sent to browser
DEBUG - 2021-07-17 11:38:06 --> Total execution time: 0.1242
INFO - 2021-07-17 11:38:07 --> Config Class Initialized
INFO - 2021-07-17 11:38:07 --> Hooks Class Initialized
DEBUG - 2021-07-17 11:38:07 --> UTF-8 Support Enabled
INFO - 2021-07-17 11:38:07 --> Utf8 Class Initialized
INFO - 2021-07-17 11:38:07 --> URI Class Initialized
INFO - 2021-07-17 11:38:07 --> Router Class Initialized
INFO - 2021-07-17 11:38:07 --> Output Class Initialized
INFO - 2021-07-17 11:38:07 --> Security Class Initialized
DEBUG - 2021-07-17 11:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 11:38:07 --> Input Class Initialized
INFO - 2021-07-17 11:38:07 --> Language Class Initialized
ERROR - 2021-07-17 11:38:07 --> 404 Page Not Found: Faviconico/index
INFO - 2021-07-17 11:39:17 --> Config Class Initialized
INFO - 2021-07-17 11:39:17 --> Hooks Class Initialized
DEBUG - 2021-07-17 11:39:17 --> UTF-8 Support Enabled
INFO - 2021-07-17 11:39:17 --> Utf8 Class Initialized
INFO - 2021-07-17 11:39:17 --> URI Class Initialized
INFO - 2021-07-17 11:39:17 --> Router Class Initialized
INFO - 2021-07-17 11:39:17 --> Output Class Initialized
INFO - 2021-07-17 11:39:17 --> Security Class Initialized
DEBUG - 2021-07-17 11:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 11:39:17 --> Input Class Initialized
INFO - 2021-07-17 11:39:17 --> Language Class Initialized
INFO - 2021-07-17 11:39:17 --> Loader Class Initialized
INFO - 2021-07-17 11:39:17 --> Helper loaded: basic_helper
INFO - 2021-07-17 11:39:17 --> Helper loaded: url_helper
INFO - 2021-07-17 11:39:17 --> Helper loaded: file_helper
INFO - 2021-07-17 11:39:17 --> Helper loaded: form_helper
INFO - 2021-07-17 11:39:17 --> Helper loaded: cookie_helper
INFO - 2021-07-17 11:39:17 --> Helper loaded: security_helper
INFO - 2021-07-17 11:39:17 --> Helper loaded: directory_helper
INFO - 2021-07-17 11:39:17 --> Helper loaded: language_helper
INFO - 2021-07-17 11:39:17 --> Helper loaded: general_helper
INFO - 2021-07-17 11:39:17 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 11:39:17 --> Database Driver Class Initialized
DEBUG - 2021-07-17 11:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 11:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 11:39:17 --> Parser Class Initialized
INFO - 2021-07-17 11:39:17 --> Form Validation Class Initialized
INFO - 2021-07-17 11:39:17 --> Upload Class Initialized
INFO - 2021-07-17 11:39:17 --> Email Class Initialized
INFO - 2021-07-17 11:39:17 --> MY_Model class loaded
INFO - 2021-07-17 11:39:17 --> Model "Users_model" initialized
INFO - 2021-07-17 11:39:17 --> Model "Settings_model" initialized
INFO - 2021-07-17 11:39:17 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 11:39:17 --> Model "Permissions_model" initialized
INFO - 2021-07-17 11:39:17 --> Model "Roles_model" initialized
INFO - 2021-07-17 11:39:17 --> Model "Activity_model" initialized
INFO - 2021-07-17 11:39:17 --> Model "Templates_model" initialized
INFO - 2021-07-17 11:39:17 --> Database Driver Class Initialized
INFO - 2021-07-17 11:39:17 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 11:39:17 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 11:39:17 --> Controller Class Initialized
ERROR - 2021-07-17 11:39:17 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 11:39:17 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 11:39:17 --> Final output sent to browser
DEBUG - 2021-07-17 11:39:17 --> Total execution time: 0.5504
INFO - 2021-07-17 11:39:19 --> Config Class Initialized
INFO - 2021-07-17 11:39:19 --> Hooks Class Initialized
DEBUG - 2021-07-17 11:39:19 --> UTF-8 Support Enabled
INFO - 2021-07-17 11:39:19 --> Utf8 Class Initialized
INFO - 2021-07-17 11:39:19 --> URI Class Initialized
INFO - 2021-07-17 11:39:19 --> Router Class Initialized
INFO - 2021-07-17 11:39:19 --> Output Class Initialized
INFO - 2021-07-17 11:39:19 --> Security Class Initialized
DEBUG - 2021-07-17 11:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 11:39:19 --> Input Class Initialized
INFO - 2021-07-17 11:39:19 --> Language Class Initialized
INFO - 2021-07-17 11:39:19 --> Loader Class Initialized
INFO - 2021-07-17 11:39:19 --> Helper loaded: basic_helper
INFO - 2021-07-17 11:39:19 --> Helper loaded: url_helper
INFO - 2021-07-17 11:39:19 --> Helper loaded: file_helper
INFO - 2021-07-17 11:39:19 --> Helper loaded: form_helper
INFO - 2021-07-17 11:39:19 --> Helper loaded: cookie_helper
INFO - 2021-07-17 11:39:19 --> Helper loaded: security_helper
INFO - 2021-07-17 11:39:19 --> Helper loaded: directory_helper
INFO - 2021-07-17 11:39:19 --> Helper loaded: language_helper
INFO - 2021-07-17 11:39:19 --> Helper loaded: general_helper
INFO - 2021-07-17 11:39:19 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 11:39:19 --> Database Driver Class Initialized
DEBUG - 2021-07-17 11:39:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 11:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 11:39:19 --> Parser Class Initialized
INFO - 2021-07-17 11:39:19 --> Form Validation Class Initialized
INFO - 2021-07-17 11:39:19 --> Upload Class Initialized
INFO - 2021-07-17 11:39:19 --> Email Class Initialized
INFO - 2021-07-17 11:39:19 --> MY_Model class loaded
INFO - 2021-07-17 11:39:19 --> Model "Users_model" initialized
INFO - 2021-07-17 11:39:19 --> Model "Settings_model" initialized
INFO - 2021-07-17 11:39:19 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 11:39:19 --> Model "Permissions_model" initialized
INFO - 2021-07-17 11:39:19 --> Model "Roles_model" initialized
INFO - 2021-07-17 11:39:19 --> Model "Activity_model" initialized
INFO - 2021-07-17 11:39:19 --> Model "Templates_model" initialized
INFO - 2021-07-17 11:39:19 --> Database Driver Class Initialized
INFO - 2021-07-17 11:39:19 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 11:39:19 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 11:39:19 --> Controller Class Initialized
ERROR - 2021-07-17 11:39:19 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 11:39:19 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 11:39:19 --> Final output sent to browser
DEBUG - 2021-07-17 11:39:19 --> Total execution time: 0.0592
INFO - 2021-07-17 11:39:43 --> Config Class Initialized
INFO - 2021-07-17 11:39:43 --> Hooks Class Initialized
DEBUG - 2021-07-17 11:39:43 --> UTF-8 Support Enabled
INFO - 2021-07-17 11:39:43 --> Utf8 Class Initialized
INFO - 2021-07-17 11:39:43 --> URI Class Initialized
INFO - 2021-07-17 11:39:43 --> Router Class Initialized
INFO - 2021-07-17 11:39:43 --> Output Class Initialized
INFO - 2021-07-17 11:39:43 --> Security Class Initialized
DEBUG - 2021-07-17 11:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 11:39:43 --> Input Class Initialized
INFO - 2021-07-17 11:39:43 --> Language Class Initialized
INFO - 2021-07-17 11:39:43 --> Loader Class Initialized
INFO - 2021-07-17 11:39:43 --> Helper loaded: basic_helper
INFO - 2021-07-17 11:39:43 --> Helper loaded: url_helper
INFO - 2021-07-17 11:39:43 --> Helper loaded: file_helper
INFO - 2021-07-17 11:39:43 --> Helper loaded: form_helper
INFO - 2021-07-17 11:39:43 --> Helper loaded: cookie_helper
INFO - 2021-07-17 11:39:43 --> Helper loaded: security_helper
INFO - 2021-07-17 11:39:43 --> Helper loaded: directory_helper
INFO - 2021-07-17 11:39:43 --> Helper loaded: language_helper
INFO - 2021-07-17 11:39:43 --> Helper loaded: general_helper
INFO - 2021-07-17 11:39:43 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 11:39:43 --> Database Driver Class Initialized
DEBUG - 2021-07-17 11:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 11:39:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 11:39:43 --> Parser Class Initialized
INFO - 2021-07-17 11:39:43 --> Form Validation Class Initialized
INFO - 2021-07-17 11:39:43 --> Upload Class Initialized
INFO - 2021-07-17 11:39:43 --> Email Class Initialized
INFO - 2021-07-17 11:39:43 --> MY_Model class loaded
INFO - 2021-07-17 11:39:43 --> Model "Users_model" initialized
INFO - 2021-07-17 11:39:43 --> Model "Settings_model" initialized
INFO - 2021-07-17 11:39:43 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 11:39:43 --> Model "Permissions_model" initialized
INFO - 2021-07-17 11:39:43 --> Model "Roles_model" initialized
INFO - 2021-07-17 11:39:43 --> Model "Activity_model" initialized
INFO - 2021-07-17 11:39:43 --> Model "Templates_model" initialized
INFO - 2021-07-17 11:39:43 --> Database Driver Class Initialized
INFO - 2021-07-17 11:39:43 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 11:39:43 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 11:39:43 --> Controller Class Initialized
ERROR - 2021-07-17 11:39:43 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 11:39:43 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 11:39:43 --> Final output sent to browser
DEBUG - 2021-07-17 11:39:43 --> Total execution time: 0.1385
INFO - 2021-07-17 11:39:52 --> Config Class Initialized
INFO - 2021-07-17 11:39:52 --> Hooks Class Initialized
DEBUG - 2021-07-17 11:39:52 --> UTF-8 Support Enabled
INFO - 2021-07-17 11:39:52 --> Utf8 Class Initialized
INFO - 2021-07-17 11:39:52 --> URI Class Initialized
INFO - 2021-07-17 11:39:52 --> Router Class Initialized
INFO - 2021-07-17 11:39:52 --> Output Class Initialized
INFO - 2021-07-17 11:39:52 --> Security Class Initialized
DEBUG - 2021-07-17 11:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 11:39:52 --> Input Class Initialized
INFO - 2021-07-17 11:39:52 --> Language Class Initialized
INFO - 2021-07-17 11:39:52 --> Loader Class Initialized
INFO - 2021-07-17 11:39:52 --> Helper loaded: basic_helper
INFO - 2021-07-17 11:39:52 --> Helper loaded: url_helper
INFO - 2021-07-17 11:39:52 --> Helper loaded: file_helper
INFO - 2021-07-17 11:39:52 --> Helper loaded: form_helper
INFO - 2021-07-17 11:39:52 --> Helper loaded: cookie_helper
INFO - 2021-07-17 11:39:52 --> Helper loaded: security_helper
INFO - 2021-07-17 11:39:52 --> Helper loaded: directory_helper
INFO - 2021-07-17 11:39:52 --> Helper loaded: language_helper
INFO - 2021-07-17 11:39:52 --> Helper loaded: general_helper
INFO - 2021-07-17 11:39:52 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 11:39:52 --> Database Driver Class Initialized
DEBUG - 2021-07-17 11:39:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 11:39:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 11:39:52 --> Parser Class Initialized
INFO - 2021-07-17 11:39:52 --> Form Validation Class Initialized
INFO - 2021-07-17 11:39:52 --> Upload Class Initialized
INFO - 2021-07-17 11:39:52 --> Email Class Initialized
INFO - 2021-07-17 11:39:52 --> MY_Model class loaded
INFO - 2021-07-17 11:39:52 --> Model "Users_model" initialized
INFO - 2021-07-17 11:39:52 --> Model "Settings_model" initialized
INFO - 2021-07-17 11:39:52 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 11:39:52 --> Model "Permissions_model" initialized
INFO - 2021-07-17 11:39:52 --> Model "Roles_model" initialized
INFO - 2021-07-17 11:39:52 --> Model "Activity_model" initialized
INFO - 2021-07-17 11:39:52 --> Model "Templates_model" initialized
INFO - 2021-07-17 11:39:52 --> Database Driver Class Initialized
INFO - 2021-07-17 11:39:52 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 11:39:52 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 11:39:52 --> Controller Class Initialized
ERROR - 2021-07-17 11:39:52 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 11:39:52 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 11:39:52 --> Final output sent to browser
DEBUG - 2021-07-17 11:39:52 --> Total execution time: 0.1329
INFO - 2021-07-17 11:39:56 --> Config Class Initialized
INFO - 2021-07-17 11:39:56 --> Hooks Class Initialized
DEBUG - 2021-07-17 11:39:56 --> UTF-8 Support Enabled
INFO - 2021-07-17 11:39:56 --> Utf8 Class Initialized
INFO - 2021-07-17 11:39:56 --> URI Class Initialized
INFO - 2021-07-17 11:39:56 --> Router Class Initialized
INFO - 2021-07-17 11:39:56 --> Output Class Initialized
INFO - 2021-07-17 11:39:56 --> Security Class Initialized
DEBUG - 2021-07-17 11:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 11:39:56 --> Input Class Initialized
INFO - 2021-07-17 11:39:56 --> Language Class Initialized
INFO - 2021-07-17 11:39:56 --> Loader Class Initialized
INFO - 2021-07-17 11:39:56 --> Helper loaded: basic_helper
INFO - 2021-07-17 11:39:56 --> Helper loaded: url_helper
INFO - 2021-07-17 11:39:56 --> Helper loaded: file_helper
INFO - 2021-07-17 11:39:56 --> Helper loaded: form_helper
INFO - 2021-07-17 11:39:56 --> Helper loaded: cookie_helper
INFO - 2021-07-17 11:39:56 --> Helper loaded: security_helper
INFO - 2021-07-17 11:39:56 --> Helper loaded: directory_helper
INFO - 2021-07-17 11:39:56 --> Helper loaded: language_helper
INFO - 2021-07-17 11:39:56 --> Helper loaded: general_helper
INFO - 2021-07-17 11:39:56 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 11:39:56 --> Database Driver Class Initialized
DEBUG - 2021-07-17 11:39:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 11:39:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 11:39:56 --> Parser Class Initialized
INFO - 2021-07-17 11:39:56 --> Form Validation Class Initialized
INFO - 2021-07-17 11:39:56 --> Upload Class Initialized
INFO - 2021-07-17 11:39:56 --> Email Class Initialized
INFO - 2021-07-17 11:39:56 --> MY_Model class loaded
INFO - 2021-07-17 11:39:56 --> Model "Users_model" initialized
INFO - 2021-07-17 11:39:56 --> Model "Settings_model" initialized
INFO - 2021-07-17 11:39:56 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 11:39:56 --> Model "Permissions_model" initialized
INFO - 2021-07-17 11:39:56 --> Model "Roles_model" initialized
INFO - 2021-07-17 11:39:56 --> Model "Activity_model" initialized
INFO - 2021-07-17 11:39:56 --> Model "Templates_model" initialized
INFO - 2021-07-17 11:39:56 --> Database Driver Class Initialized
INFO - 2021-07-17 11:39:56 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 11:39:56 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 11:39:56 --> Controller Class Initialized
ERROR - 2021-07-17 11:39:56 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 11:39:56 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 11:39:56 --> Final output sent to browser
DEBUG - 2021-07-17 11:39:56 --> Total execution time: 0.0624
INFO - 2021-07-17 11:41:37 --> Config Class Initialized
INFO - 2021-07-17 11:41:37 --> Hooks Class Initialized
DEBUG - 2021-07-17 11:41:37 --> UTF-8 Support Enabled
INFO - 2021-07-17 11:41:37 --> Utf8 Class Initialized
INFO - 2021-07-17 11:41:37 --> URI Class Initialized
INFO - 2021-07-17 11:41:37 --> Router Class Initialized
INFO - 2021-07-17 11:41:37 --> Output Class Initialized
INFO - 2021-07-17 11:41:37 --> Security Class Initialized
DEBUG - 2021-07-17 11:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 11:41:37 --> Input Class Initialized
INFO - 2021-07-17 11:41:37 --> Language Class Initialized
INFO - 2021-07-17 11:41:37 --> Loader Class Initialized
INFO - 2021-07-17 11:41:37 --> Helper loaded: basic_helper
INFO - 2021-07-17 11:41:37 --> Helper loaded: url_helper
INFO - 2021-07-17 11:41:37 --> Helper loaded: file_helper
INFO - 2021-07-17 11:41:37 --> Helper loaded: form_helper
INFO - 2021-07-17 11:41:37 --> Helper loaded: cookie_helper
INFO - 2021-07-17 11:41:37 --> Helper loaded: security_helper
INFO - 2021-07-17 11:41:37 --> Helper loaded: directory_helper
INFO - 2021-07-17 11:41:37 --> Helper loaded: language_helper
INFO - 2021-07-17 11:41:37 --> Helper loaded: general_helper
INFO - 2021-07-17 11:41:37 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 11:41:37 --> Database Driver Class Initialized
DEBUG - 2021-07-17 11:41:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 11:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 11:41:37 --> Parser Class Initialized
INFO - 2021-07-17 11:41:37 --> Form Validation Class Initialized
INFO - 2021-07-17 11:41:37 --> Upload Class Initialized
INFO - 2021-07-17 11:41:37 --> Email Class Initialized
INFO - 2021-07-17 11:41:37 --> MY_Model class loaded
INFO - 2021-07-17 11:41:37 --> Model "Users_model" initialized
INFO - 2021-07-17 11:41:37 --> Model "Settings_model" initialized
INFO - 2021-07-17 11:41:37 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 11:41:37 --> Model "Permissions_model" initialized
INFO - 2021-07-17 11:41:37 --> Model "Roles_model" initialized
INFO - 2021-07-17 11:41:37 --> Model "Activity_model" initialized
INFO - 2021-07-17 11:41:37 --> Model "Templates_model" initialized
INFO - 2021-07-17 11:41:37 --> Database Driver Class Initialized
INFO - 2021-07-17 11:41:37 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 11:41:37 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 11:41:37 --> Controller Class Initialized
ERROR - 2021-07-17 11:41:37 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 11:41:37 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 11:41:37 --> Final output sent to browser
DEBUG - 2021-07-17 11:41:37 --> Total execution time: 0.5369
INFO - 2021-07-17 11:41:38 --> Config Class Initialized
INFO - 2021-07-17 11:41:38 --> Hooks Class Initialized
DEBUG - 2021-07-17 11:41:38 --> UTF-8 Support Enabled
INFO - 2021-07-17 11:41:38 --> Utf8 Class Initialized
INFO - 2021-07-17 11:41:38 --> URI Class Initialized
INFO - 2021-07-17 11:41:38 --> Router Class Initialized
INFO - 2021-07-17 11:41:38 --> Output Class Initialized
INFO - 2021-07-17 11:41:38 --> Security Class Initialized
DEBUG - 2021-07-17 11:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 11:41:38 --> Input Class Initialized
INFO - 2021-07-17 11:41:38 --> Language Class Initialized
INFO - 2021-07-17 11:41:38 --> Loader Class Initialized
INFO - 2021-07-17 11:41:38 --> Helper loaded: basic_helper
INFO - 2021-07-17 11:41:38 --> Helper loaded: url_helper
INFO - 2021-07-17 11:41:38 --> Helper loaded: file_helper
INFO - 2021-07-17 11:41:38 --> Helper loaded: form_helper
INFO - 2021-07-17 11:41:38 --> Helper loaded: cookie_helper
INFO - 2021-07-17 11:41:38 --> Helper loaded: security_helper
INFO - 2021-07-17 11:41:38 --> Helper loaded: directory_helper
INFO - 2021-07-17 11:41:38 --> Helper loaded: language_helper
INFO - 2021-07-17 11:41:38 --> Helper loaded: general_helper
INFO - 2021-07-17 11:41:38 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 11:41:38 --> Database Driver Class Initialized
DEBUG - 2021-07-17 11:41:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 11:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 11:41:38 --> Parser Class Initialized
INFO - 2021-07-17 11:41:38 --> Form Validation Class Initialized
INFO - 2021-07-17 11:41:38 --> Upload Class Initialized
INFO - 2021-07-17 11:41:38 --> Email Class Initialized
INFO - 2021-07-17 11:41:38 --> MY_Model class loaded
INFO - 2021-07-17 11:41:38 --> Model "Users_model" initialized
INFO - 2021-07-17 11:41:38 --> Model "Settings_model" initialized
INFO - 2021-07-17 11:41:38 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 11:41:38 --> Model "Permissions_model" initialized
INFO - 2021-07-17 11:41:38 --> Model "Roles_model" initialized
INFO - 2021-07-17 11:41:38 --> Model "Activity_model" initialized
INFO - 2021-07-17 11:41:38 --> Model "Templates_model" initialized
INFO - 2021-07-17 11:41:38 --> Database Driver Class Initialized
INFO - 2021-07-17 11:41:38 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 11:41:38 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 11:41:38 --> Controller Class Initialized
ERROR - 2021-07-17 11:41:38 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 11:41:38 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 11:41:38 --> Final output sent to browser
DEBUG - 2021-07-17 11:41:38 --> Total execution time: 0.0594
INFO - 2021-07-17 11:42:18 --> Config Class Initialized
INFO - 2021-07-17 11:42:18 --> Hooks Class Initialized
DEBUG - 2021-07-17 11:42:18 --> UTF-8 Support Enabled
INFO - 2021-07-17 11:42:18 --> Utf8 Class Initialized
INFO - 2021-07-17 11:42:18 --> URI Class Initialized
INFO - 2021-07-17 11:42:18 --> Router Class Initialized
INFO - 2021-07-17 11:42:18 --> Output Class Initialized
INFO - 2021-07-17 11:42:18 --> Security Class Initialized
DEBUG - 2021-07-17 11:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 11:42:18 --> Input Class Initialized
INFO - 2021-07-17 11:42:18 --> Language Class Initialized
INFO - 2021-07-17 11:42:18 --> Loader Class Initialized
INFO - 2021-07-17 11:42:18 --> Helper loaded: basic_helper
INFO - 2021-07-17 11:42:18 --> Helper loaded: url_helper
INFO - 2021-07-17 11:42:18 --> Helper loaded: file_helper
INFO - 2021-07-17 11:42:18 --> Helper loaded: form_helper
INFO - 2021-07-17 11:42:18 --> Helper loaded: cookie_helper
INFO - 2021-07-17 11:42:18 --> Helper loaded: security_helper
INFO - 2021-07-17 11:42:18 --> Helper loaded: directory_helper
INFO - 2021-07-17 11:42:18 --> Helper loaded: language_helper
INFO - 2021-07-17 11:42:18 --> Helper loaded: general_helper
INFO - 2021-07-17 11:42:18 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 11:42:18 --> Database Driver Class Initialized
DEBUG - 2021-07-17 11:42:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 11:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 11:42:18 --> Parser Class Initialized
INFO - 2021-07-17 11:42:18 --> Form Validation Class Initialized
INFO - 2021-07-17 11:42:18 --> Upload Class Initialized
INFO - 2021-07-17 11:42:18 --> Email Class Initialized
INFO - 2021-07-17 11:42:18 --> MY_Model class loaded
INFO - 2021-07-17 11:42:18 --> Model "Users_model" initialized
INFO - 2021-07-17 11:42:18 --> Model "Settings_model" initialized
INFO - 2021-07-17 11:42:18 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 11:42:18 --> Model "Permissions_model" initialized
INFO - 2021-07-17 11:42:18 --> Model "Roles_model" initialized
INFO - 2021-07-17 11:42:18 --> Model "Activity_model" initialized
INFO - 2021-07-17 11:42:18 --> Model "Templates_model" initialized
INFO - 2021-07-17 11:42:18 --> Database Driver Class Initialized
INFO - 2021-07-17 11:42:19 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 11:42:19 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 11:42:19 --> Controller Class Initialized
ERROR - 2021-07-17 11:42:19 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 11:42:19 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 11:42:19 --> Final output sent to browser
DEBUG - 2021-07-17 11:42:19 --> Total execution time: 0.1436
INFO - 2021-07-17 11:43:56 --> Config Class Initialized
INFO - 2021-07-17 11:43:56 --> Hooks Class Initialized
DEBUG - 2021-07-17 11:43:56 --> UTF-8 Support Enabled
INFO - 2021-07-17 11:43:56 --> Utf8 Class Initialized
INFO - 2021-07-17 11:43:56 --> URI Class Initialized
INFO - 2021-07-17 11:43:56 --> Router Class Initialized
INFO - 2021-07-17 11:43:56 --> Output Class Initialized
INFO - 2021-07-17 11:43:56 --> Security Class Initialized
DEBUG - 2021-07-17 11:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 11:43:56 --> Input Class Initialized
INFO - 2021-07-17 11:43:56 --> Language Class Initialized
INFO - 2021-07-17 11:43:56 --> Loader Class Initialized
INFO - 2021-07-17 11:43:56 --> Helper loaded: basic_helper
INFO - 2021-07-17 11:43:56 --> Helper loaded: url_helper
INFO - 2021-07-17 11:43:56 --> Helper loaded: file_helper
INFO - 2021-07-17 11:43:56 --> Helper loaded: form_helper
INFO - 2021-07-17 11:43:56 --> Helper loaded: cookie_helper
INFO - 2021-07-17 11:43:56 --> Helper loaded: security_helper
INFO - 2021-07-17 11:43:56 --> Helper loaded: directory_helper
INFO - 2021-07-17 11:43:56 --> Helper loaded: language_helper
INFO - 2021-07-17 11:43:56 --> Helper loaded: general_helper
INFO - 2021-07-17 11:43:56 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 11:43:56 --> Database Driver Class Initialized
DEBUG - 2021-07-17 11:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 11:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 11:43:56 --> Parser Class Initialized
INFO - 2021-07-17 11:43:56 --> Form Validation Class Initialized
INFO - 2021-07-17 11:43:56 --> Upload Class Initialized
INFO - 2021-07-17 11:43:56 --> Email Class Initialized
INFO - 2021-07-17 11:43:56 --> MY_Model class loaded
INFO - 2021-07-17 11:43:56 --> Model "Users_model" initialized
INFO - 2021-07-17 11:43:56 --> Model "Settings_model" initialized
INFO - 2021-07-17 11:43:56 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 11:43:56 --> Model "Permissions_model" initialized
INFO - 2021-07-17 11:43:56 --> Model "Roles_model" initialized
INFO - 2021-07-17 11:43:56 --> Model "Activity_model" initialized
INFO - 2021-07-17 11:43:56 --> Model "Templates_model" initialized
INFO - 2021-07-17 11:43:56 --> Database Driver Class Initialized
INFO - 2021-07-17 11:43:56 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 11:43:56 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 11:43:56 --> Controller Class Initialized
INFO - 2021-07-17 11:43:56 --> Config Class Initialized
INFO - 2021-07-17 11:43:56 --> Hooks Class Initialized
DEBUG - 2021-07-17 11:43:56 --> UTF-8 Support Enabled
INFO - 2021-07-17 11:43:56 --> Utf8 Class Initialized
INFO - 2021-07-17 11:43:56 --> URI Class Initialized
INFO - 2021-07-17 11:43:56 --> Router Class Initialized
INFO - 2021-07-17 11:43:56 --> Output Class Initialized
INFO - 2021-07-17 11:43:56 --> Security Class Initialized
DEBUG - 2021-07-17 11:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 11:43:56 --> Input Class Initialized
INFO - 2021-07-17 11:43:56 --> Language Class Initialized
INFO - 2021-07-17 11:43:56 --> Loader Class Initialized
INFO - 2021-07-17 11:43:56 --> Helper loaded: basic_helper
INFO - 2021-07-17 11:43:56 --> Helper loaded: url_helper
INFO - 2021-07-17 11:43:56 --> Helper loaded: file_helper
INFO - 2021-07-17 11:43:56 --> Helper loaded: form_helper
INFO - 2021-07-17 11:43:56 --> Helper loaded: cookie_helper
INFO - 2021-07-17 11:43:56 --> Helper loaded: security_helper
INFO - 2021-07-17 11:43:56 --> Helper loaded: directory_helper
INFO - 2021-07-17 11:43:56 --> Helper loaded: language_helper
INFO - 2021-07-17 11:43:56 --> Helper loaded: general_helper
INFO - 2021-07-17 11:43:56 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 11:43:56 --> Database Driver Class Initialized
DEBUG - 2021-07-17 11:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 11:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 11:43:56 --> Parser Class Initialized
INFO - 2021-07-17 11:43:56 --> Form Validation Class Initialized
INFO - 2021-07-17 11:43:56 --> Upload Class Initialized
INFO - 2021-07-17 11:43:56 --> Email Class Initialized
INFO - 2021-07-17 11:43:56 --> MY_Model class loaded
INFO - 2021-07-17 11:43:56 --> Model "Users_model" initialized
INFO - 2021-07-17 11:43:56 --> Model "Settings_model" initialized
INFO - 2021-07-17 11:43:56 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 11:43:56 --> Model "Permissions_model" initialized
INFO - 2021-07-17 11:43:56 --> Model "Roles_model" initialized
INFO - 2021-07-17 11:43:56 --> Model "Activity_model" initialized
INFO - 2021-07-17 11:43:56 --> Model "Templates_model" initialized
INFO - 2021-07-17 11:43:56 --> Database Driver Class Initialized
INFO - 2021-07-17 11:43:56 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 11:43:56 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 11:43:56 --> Controller Class Initialized
INFO - 2021-07-17 11:43:56 --> File loaded: C:\wamp64\www\crm\application\views\account/login.php
INFO - 2021-07-17 11:43:56 --> Final output sent to browser
DEBUG - 2021-07-17 11:43:56 --> Total execution time: 0.0484
INFO - 2021-07-17 11:43:56 --> Config Class Initialized
INFO - 2021-07-17 11:43:56 --> Config Class Initialized
INFO - 2021-07-17 11:43:56 --> Hooks Class Initialized
INFO - 2021-07-17 11:43:56 --> Hooks Class Initialized
DEBUG - 2021-07-17 11:43:56 --> UTF-8 Support Enabled
DEBUG - 2021-07-17 11:43:56 --> UTF-8 Support Enabled
INFO - 2021-07-17 11:43:56 --> Utf8 Class Initialized
INFO - 2021-07-17 11:43:56 --> Utf8 Class Initialized
INFO - 2021-07-17 11:43:56 --> URI Class Initialized
INFO - 2021-07-17 11:43:56 --> URI Class Initialized
INFO - 2021-07-17 11:43:56 --> Router Class Initialized
INFO - 2021-07-17 11:43:56 --> Router Class Initialized
INFO - 2021-07-17 11:43:56 --> Output Class Initialized
INFO - 2021-07-17 11:43:56 --> Output Class Initialized
INFO - 2021-07-17 11:43:56 --> Security Class Initialized
INFO - 2021-07-17 11:43:56 --> Security Class Initialized
DEBUG - 2021-07-17 11:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-17 11:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 11:43:56 --> Input Class Initialized
INFO - 2021-07-17 11:43:56 --> Input Class Initialized
INFO - 2021-07-17 11:43:56 --> Language Class Initialized
INFO - 2021-07-17 11:43:56 --> Language Class Initialized
ERROR - 2021-07-17 11:43:56 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-07-17 11:43:56 --> 404 Page Not Found: Assets/jquery
INFO - 2021-07-17 11:43:56 --> Config Class Initialized
INFO - 2021-07-17 11:43:56 --> Hooks Class Initialized
DEBUG - 2021-07-17 11:43:56 --> UTF-8 Support Enabled
INFO - 2021-07-17 11:43:56 --> Utf8 Class Initialized
INFO - 2021-07-17 11:43:56 --> URI Class Initialized
INFO - 2021-07-17 11:43:56 --> Router Class Initialized
INFO - 2021-07-17 11:43:56 --> Output Class Initialized
INFO - 2021-07-17 11:43:56 --> Security Class Initialized
DEBUG - 2021-07-17 11:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 11:43:56 --> Input Class Initialized
INFO - 2021-07-17 11:43:56 --> Language Class Initialized
ERROR - 2021-07-17 11:43:56 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-17 11:43:59 --> Config Class Initialized
INFO - 2021-07-17 11:43:59 --> Hooks Class Initialized
DEBUG - 2021-07-17 11:43:59 --> UTF-8 Support Enabled
INFO - 2021-07-17 11:43:59 --> Utf8 Class Initialized
INFO - 2021-07-17 11:43:59 --> URI Class Initialized
INFO - 2021-07-17 11:43:59 --> Router Class Initialized
INFO - 2021-07-17 11:43:59 --> Output Class Initialized
INFO - 2021-07-17 11:43:59 --> Security Class Initialized
DEBUG - 2021-07-17 11:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 11:43:59 --> Input Class Initialized
INFO - 2021-07-17 11:43:59 --> Language Class Initialized
INFO - 2021-07-17 11:43:59 --> Loader Class Initialized
INFO - 2021-07-17 11:43:59 --> Helper loaded: basic_helper
INFO - 2021-07-17 11:43:59 --> Helper loaded: url_helper
INFO - 2021-07-17 11:43:59 --> Helper loaded: file_helper
INFO - 2021-07-17 11:43:59 --> Helper loaded: form_helper
INFO - 2021-07-17 11:43:59 --> Helper loaded: cookie_helper
INFO - 2021-07-17 11:43:59 --> Helper loaded: security_helper
INFO - 2021-07-17 11:43:59 --> Helper loaded: directory_helper
INFO - 2021-07-17 11:43:59 --> Helper loaded: language_helper
INFO - 2021-07-17 11:43:59 --> Helper loaded: general_helper
INFO - 2021-07-17 11:43:59 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 11:43:59 --> Database Driver Class Initialized
DEBUG - 2021-07-17 11:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 11:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 11:43:59 --> Parser Class Initialized
INFO - 2021-07-17 11:43:59 --> Form Validation Class Initialized
INFO - 2021-07-17 11:43:59 --> Upload Class Initialized
INFO - 2021-07-17 11:43:59 --> Email Class Initialized
INFO - 2021-07-17 11:43:59 --> MY_Model class loaded
INFO - 2021-07-17 11:43:59 --> Model "Users_model" initialized
INFO - 2021-07-17 11:43:59 --> Model "Settings_model" initialized
INFO - 2021-07-17 11:43:59 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 11:43:59 --> Model "Permissions_model" initialized
INFO - 2021-07-17 11:43:59 --> Model "Roles_model" initialized
INFO - 2021-07-17 11:43:59 --> Model "Activity_model" initialized
INFO - 2021-07-17 11:43:59 --> Model "Templates_model" initialized
INFO - 2021-07-17 11:43:59 --> Database Driver Class Initialized
INFO - 2021-07-17 11:43:59 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 11:43:59 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 11:43:59 --> Controller Class Initialized
DEBUG - 2021-07-17 11:43:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-17 11:43:59 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2021-07-17 11:43:59 --> Config Class Initialized
INFO - 2021-07-17 11:43:59 --> Hooks Class Initialized
DEBUG - 2021-07-17 11:43:59 --> UTF-8 Support Enabled
INFO - 2021-07-17 11:43:59 --> Utf8 Class Initialized
INFO - 2021-07-17 11:43:59 --> URI Class Initialized
DEBUG - 2021-07-17 11:43:59 --> No URI present. Default controller set.
INFO - 2021-07-17 11:43:59 --> Router Class Initialized
INFO - 2021-07-17 11:43:59 --> Output Class Initialized
INFO - 2021-07-17 11:43:59 --> Security Class Initialized
DEBUG - 2021-07-17 11:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 11:43:59 --> Input Class Initialized
INFO - 2021-07-17 11:43:59 --> Language Class Initialized
INFO - 2021-07-17 11:43:59 --> Loader Class Initialized
INFO - 2021-07-17 11:43:59 --> Helper loaded: basic_helper
INFO - 2021-07-17 11:43:59 --> Helper loaded: url_helper
INFO - 2021-07-17 11:43:59 --> Helper loaded: file_helper
INFO - 2021-07-17 11:43:59 --> Helper loaded: form_helper
INFO - 2021-07-17 11:43:59 --> Helper loaded: cookie_helper
INFO - 2021-07-17 11:43:59 --> Helper loaded: security_helper
INFO - 2021-07-17 11:43:59 --> Helper loaded: directory_helper
INFO - 2021-07-17 11:43:59 --> Helper loaded: language_helper
INFO - 2021-07-17 11:43:59 --> Helper loaded: general_helper
INFO - 2021-07-17 11:43:59 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 11:43:59 --> Database Driver Class Initialized
DEBUG - 2021-07-17 11:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 11:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 11:43:59 --> Parser Class Initialized
INFO - 2021-07-17 11:43:59 --> Form Validation Class Initialized
INFO - 2021-07-17 11:43:59 --> Upload Class Initialized
INFO - 2021-07-17 11:43:59 --> Email Class Initialized
INFO - 2021-07-17 11:43:59 --> MY_Model class loaded
INFO - 2021-07-17 11:43:59 --> Model "Users_model" initialized
INFO - 2021-07-17 11:43:59 --> Model "Settings_model" initialized
INFO - 2021-07-17 11:43:59 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 11:43:59 --> Model "Permissions_model" initialized
INFO - 2021-07-17 11:43:59 --> Model "Roles_model" initialized
INFO - 2021-07-17 11:43:59 --> Model "Activity_model" initialized
INFO - 2021-07-17 11:43:59 --> Model "Templates_model" initialized
INFO - 2021-07-17 11:43:59 --> Database Driver Class Initialized
INFO - 2021-07-17 11:43:59 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 11:43:59 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 11:43:59 --> Controller Class Initialized
ERROR - 2021-07-17 11:43:59 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 11:43:59 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-17 11:43:59 --> Final output sent to browser
DEBUG - 2021-07-17 11:43:59 --> Total execution time: 0.0804
INFO - 2021-07-17 11:44:05 --> Config Class Initialized
INFO - 2021-07-17 11:44:05 --> Hooks Class Initialized
DEBUG - 2021-07-17 11:44:05 --> UTF-8 Support Enabled
INFO - 2021-07-17 11:44:05 --> Utf8 Class Initialized
INFO - 2021-07-17 11:44:05 --> URI Class Initialized
INFO - 2021-07-17 11:44:05 --> Router Class Initialized
INFO - 2021-07-17 11:44:05 --> Output Class Initialized
INFO - 2021-07-17 11:44:05 --> Security Class Initialized
DEBUG - 2021-07-17 11:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 11:44:05 --> Input Class Initialized
INFO - 2021-07-17 11:44:05 --> Language Class Initialized
INFO - 2021-07-17 11:44:05 --> Loader Class Initialized
INFO - 2021-07-17 11:44:05 --> Helper loaded: basic_helper
INFO - 2021-07-17 11:44:05 --> Helper loaded: url_helper
INFO - 2021-07-17 11:44:05 --> Helper loaded: file_helper
INFO - 2021-07-17 11:44:05 --> Helper loaded: form_helper
INFO - 2021-07-17 11:44:05 --> Helper loaded: cookie_helper
INFO - 2021-07-17 11:44:05 --> Helper loaded: security_helper
INFO - 2021-07-17 11:44:05 --> Helper loaded: directory_helper
INFO - 2021-07-17 11:44:05 --> Helper loaded: language_helper
INFO - 2021-07-17 11:44:05 --> Helper loaded: general_helper
INFO - 2021-07-17 11:44:05 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 11:44:05 --> Database Driver Class Initialized
DEBUG - 2021-07-17 11:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 11:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 11:44:05 --> Parser Class Initialized
INFO - 2021-07-17 11:44:05 --> Form Validation Class Initialized
INFO - 2021-07-17 11:44:05 --> Upload Class Initialized
INFO - 2021-07-17 11:44:05 --> Email Class Initialized
INFO - 2021-07-17 11:44:05 --> MY_Model class loaded
INFO - 2021-07-17 11:44:05 --> Model "Users_model" initialized
INFO - 2021-07-17 11:44:05 --> Model "Settings_model" initialized
INFO - 2021-07-17 11:44:05 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 11:44:05 --> Model "Permissions_model" initialized
INFO - 2021-07-17 11:44:05 --> Model "Roles_model" initialized
INFO - 2021-07-17 11:44:05 --> Model "Activity_model" initialized
INFO - 2021-07-17 11:44:05 --> Model "Templates_model" initialized
INFO - 2021-07-17 11:44:05 --> Database Driver Class Initialized
INFO - 2021-07-17 11:44:05 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 11:44:05 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 11:44:05 --> Controller Class Initialized
ERROR - 2021-07-17 11:44:05 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 11:44:05 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 11:44:05 --> Final output sent to browser
DEBUG - 2021-07-17 11:44:05 --> Total execution time: 0.1285
INFO - 2021-07-17 11:46:48 --> Config Class Initialized
INFO - 2021-07-17 11:46:48 --> Hooks Class Initialized
DEBUG - 2021-07-17 11:46:48 --> UTF-8 Support Enabled
INFO - 2021-07-17 11:46:48 --> Utf8 Class Initialized
INFO - 2021-07-17 11:46:48 --> URI Class Initialized
INFO - 2021-07-17 11:46:48 --> Router Class Initialized
INFO - 2021-07-17 11:46:48 --> Output Class Initialized
INFO - 2021-07-17 11:46:48 --> Security Class Initialized
DEBUG - 2021-07-17 11:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 11:46:48 --> Input Class Initialized
INFO - 2021-07-17 11:46:48 --> Language Class Initialized
INFO - 2021-07-17 11:46:48 --> Loader Class Initialized
INFO - 2021-07-17 11:46:48 --> Helper loaded: basic_helper
INFO - 2021-07-17 11:46:48 --> Helper loaded: url_helper
INFO - 2021-07-17 11:46:48 --> Helper loaded: file_helper
INFO - 2021-07-17 11:46:48 --> Helper loaded: form_helper
INFO - 2021-07-17 11:46:48 --> Helper loaded: cookie_helper
INFO - 2021-07-17 11:46:48 --> Helper loaded: security_helper
INFO - 2021-07-17 11:46:48 --> Helper loaded: directory_helper
INFO - 2021-07-17 11:46:48 --> Helper loaded: language_helper
INFO - 2021-07-17 11:46:48 --> Helper loaded: general_helper
INFO - 2021-07-17 11:46:48 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 11:46:48 --> Database Driver Class Initialized
DEBUG - 2021-07-17 11:46:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 11:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 11:46:48 --> Parser Class Initialized
INFO - 2021-07-17 11:46:48 --> Form Validation Class Initialized
INFO - 2021-07-17 11:46:48 --> Upload Class Initialized
INFO - 2021-07-17 11:46:48 --> Email Class Initialized
INFO - 2021-07-17 11:46:48 --> MY_Model class loaded
INFO - 2021-07-17 11:46:48 --> Model "Users_model" initialized
INFO - 2021-07-17 11:46:48 --> Model "Settings_model" initialized
INFO - 2021-07-17 11:46:48 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 11:46:48 --> Model "Permissions_model" initialized
INFO - 2021-07-17 11:46:48 --> Model "Roles_model" initialized
INFO - 2021-07-17 11:46:48 --> Model "Activity_model" initialized
INFO - 2021-07-17 11:46:48 --> Model "Templates_model" initialized
INFO - 2021-07-17 11:46:48 --> Database Driver Class Initialized
INFO - 2021-07-17 11:46:48 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 11:46:48 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 11:46:48 --> Controller Class Initialized
ERROR - 2021-07-17 11:46:48 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-17 11:46:48 --> Could not find the language line "user_username_taken"
ERROR - 2021-07-17 11:46:48 --> Could not find the language line "confirm)new_password"
INFO - 2021-07-17 11:46:48 --> File loaded: C:\wamp64\www\crm\application\views\account/profile.php
INFO - 2021-07-17 11:46:48 --> Final output sent to browser
DEBUG - 2021-07-17 11:46:48 --> Total execution time: 0.1572
INFO - 2021-07-17 11:46:50 --> Config Class Initialized
INFO - 2021-07-17 11:46:50 --> Hooks Class Initialized
DEBUG - 2021-07-17 11:46:50 --> UTF-8 Support Enabled
INFO - 2021-07-17 11:46:50 --> Utf8 Class Initialized
INFO - 2021-07-17 11:46:50 --> URI Class Initialized
INFO - 2021-07-17 11:46:50 --> Router Class Initialized
INFO - 2021-07-17 11:46:50 --> Output Class Initialized
INFO - 2021-07-17 11:46:50 --> Security Class Initialized
DEBUG - 2021-07-17 11:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 11:46:50 --> Input Class Initialized
INFO - 2021-07-17 11:46:50 --> Language Class Initialized
INFO - 2021-07-17 11:46:50 --> Loader Class Initialized
INFO - 2021-07-17 11:46:50 --> Helper loaded: basic_helper
INFO - 2021-07-17 11:46:50 --> Helper loaded: url_helper
INFO - 2021-07-17 11:46:50 --> Helper loaded: file_helper
INFO - 2021-07-17 11:46:50 --> Helper loaded: form_helper
INFO - 2021-07-17 11:46:50 --> Helper loaded: cookie_helper
INFO - 2021-07-17 11:46:50 --> Helper loaded: security_helper
INFO - 2021-07-17 11:46:50 --> Helper loaded: directory_helper
INFO - 2021-07-17 11:46:50 --> Helper loaded: language_helper
INFO - 2021-07-17 11:46:50 --> Helper loaded: general_helper
INFO - 2021-07-17 11:46:50 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 11:46:50 --> Database Driver Class Initialized
DEBUG - 2021-07-17 11:46:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 11:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 11:46:50 --> Parser Class Initialized
INFO - 2021-07-17 11:46:50 --> Form Validation Class Initialized
INFO - 2021-07-17 11:46:50 --> Upload Class Initialized
INFO - 2021-07-17 11:46:50 --> Email Class Initialized
INFO - 2021-07-17 11:46:50 --> MY_Model class loaded
INFO - 2021-07-17 11:46:50 --> Model "Users_model" initialized
INFO - 2021-07-17 11:46:50 --> Model "Settings_model" initialized
INFO - 2021-07-17 11:46:50 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 11:46:50 --> Model "Permissions_model" initialized
INFO - 2021-07-17 11:46:50 --> Model "Roles_model" initialized
INFO - 2021-07-17 11:46:50 --> Model "Activity_model" initialized
INFO - 2021-07-17 11:46:50 --> Model "Templates_model" initialized
INFO - 2021-07-17 11:46:50 --> Database Driver Class Initialized
INFO - 2021-07-17 11:46:50 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 11:46:50 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 11:46:50 --> Controller Class Initialized
ERROR - 2021-07-17 11:46:50 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-17 11:46:50 --> Could not find the language line "user_username_taken"
ERROR - 2021-07-17 11:46:50 --> Could not find the language line "confirm)new_password"
INFO - 2021-07-17 11:46:50 --> File loaded: C:\wamp64\www\crm\application\views\account/profile.php
INFO - 2021-07-17 11:46:50 --> Final output sent to browser
DEBUG - 2021-07-17 11:46:50 --> Total execution time: 0.0682
INFO - 2021-07-17 11:47:16 --> Config Class Initialized
INFO - 2021-07-17 11:47:16 --> Hooks Class Initialized
DEBUG - 2021-07-17 11:47:16 --> UTF-8 Support Enabled
INFO - 2021-07-17 11:47:16 --> Utf8 Class Initialized
INFO - 2021-07-17 11:47:16 --> URI Class Initialized
INFO - 2021-07-17 11:47:16 --> Router Class Initialized
INFO - 2021-07-17 11:47:16 --> Output Class Initialized
INFO - 2021-07-17 11:47:16 --> Security Class Initialized
DEBUG - 2021-07-17 11:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 11:47:16 --> Input Class Initialized
INFO - 2021-07-17 11:47:16 --> Language Class Initialized
INFO - 2021-07-17 11:47:16 --> Loader Class Initialized
INFO - 2021-07-17 11:47:16 --> Helper loaded: basic_helper
INFO - 2021-07-17 11:47:16 --> Helper loaded: url_helper
INFO - 2021-07-17 11:47:16 --> Helper loaded: file_helper
INFO - 2021-07-17 11:47:16 --> Helper loaded: form_helper
INFO - 2021-07-17 11:47:16 --> Helper loaded: cookie_helper
INFO - 2021-07-17 11:47:16 --> Helper loaded: security_helper
INFO - 2021-07-17 11:47:16 --> Helper loaded: directory_helper
INFO - 2021-07-17 11:47:16 --> Helper loaded: language_helper
INFO - 2021-07-17 11:47:16 --> Helper loaded: general_helper
INFO - 2021-07-17 11:47:16 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 11:47:16 --> Database Driver Class Initialized
DEBUG - 2021-07-17 11:47:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 11:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 11:47:16 --> Parser Class Initialized
INFO - 2021-07-17 11:47:16 --> Form Validation Class Initialized
INFO - 2021-07-17 11:47:16 --> Upload Class Initialized
INFO - 2021-07-17 11:47:16 --> Email Class Initialized
INFO - 2021-07-17 11:47:16 --> MY_Model class loaded
INFO - 2021-07-17 11:47:16 --> Model "Users_model" initialized
INFO - 2021-07-17 11:47:16 --> Model "Settings_model" initialized
INFO - 2021-07-17 11:47:16 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 11:47:16 --> Model "Permissions_model" initialized
INFO - 2021-07-17 11:47:16 --> Model "Roles_model" initialized
INFO - 2021-07-17 11:47:16 --> Model "Activity_model" initialized
INFO - 2021-07-17 11:47:16 --> Model "Templates_model" initialized
INFO - 2021-07-17 11:47:16 --> Database Driver Class Initialized
INFO - 2021-07-17 11:47:16 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 11:47:16 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 11:47:16 --> Controller Class Initialized
INFO - 2021-07-17 11:47:16 --> Config Class Initialized
INFO - 2021-07-17 11:47:16 --> Hooks Class Initialized
DEBUG - 2021-07-17 11:47:16 --> UTF-8 Support Enabled
INFO - 2021-07-17 11:47:16 --> Utf8 Class Initialized
INFO - 2021-07-17 11:47:16 --> URI Class Initialized
INFO - 2021-07-17 11:47:16 --> Router Class Initialized
INFO - 2021-07-17 11:47:16 --> Output Class Initialized
INFO - 2021-07-17 11:47:16 --> Security Class Initialized
DEBUG - 2021-07-17 11:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 11:47:16 --> Input Class Initialized
INFO - 2021-07-17 11:47:16 --> Language Class Initialized
INFO - 2021-07-17 11:47:16 --> Loader Class Initialized
INFO - 2021-07-17 11:47:16 --> Helper loaded: basic_helper
INFO - 2021-07-17 11:47:16 --> Helper loaded: url_helper
INFO - 2021-07-17 11:47:16 --> Helper loaded: file_helper
INFO - 2021-07-17 11:47:16 --> Helper loaded: form_helper
INFO - 2021-07-17 11:47:16 --> Helper loaded: cookie_helper
INFO - 2021-07-17 11:47:16 --> Helper loaded: security_helper
INFO - 2021-07-17 11:47:16 --> Helper loaded: directory_helper
INFO - 2021-07-17 11:47:16 --> Helper loaded: language_helper
INFO - 2021-07-17 11:47:16 --> Helper loaded: general_helper
INFO - 2021-07-17 11:47:16 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 11:47:16 --> Database Driver Class Initialized
DEBUG - 2021-07-17 11:47:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 11:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 11:47:16 --> Parser Class Initialized
INFO - 2021-07-17 11:47:16 --> Form Validation Class Initialized
INFO - 2021-07-17 11:47:16 --> Upload Class Initialized
INFO - 2021-07-17 11:47:16 --> Email Class Initialized
INFO - 2021-07-17 11:47:16 --> MY_Model class loaded
INFO - 2021-07-17 11:47:16 --> Model "Users_model" initialized
INFO - 2021-07-17 11:47:16 --> Model "Settings_model" initialized
INFO - 2021-07-17 11:47:16 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 11:47:16 --> Model "Permissions_model" initialized
INFO - 2021-07-17 11:47:16 --> Model "Roles_model" initialized
INFO - 2021-07-17 11:47:16 --> Model "Activity_model" initialized
INFO - 2021-07-17 11:47:16 --> Model "Templates_model" initialized
INFO - 2021-07-17 11:47:16 --> Database Driver Class Initialized
INFO - 2021-07-17 11:47:16 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 11:47:16 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 11:47:16 --> Controller Class Initialized
INFO - 2021-07-17 11:47:16 --> File loaded: C:\wamp64\www\crm\application\views\account/login.php
INFO - 2021-07-17 11:47:16 --> Final output sent to browser
DEBUG - 2021-07-17 11:47:16 --> Total execution time: 0.0474
INFO - 2021-07-17 11:47:16 --> Config Class Initialized
INFO - 2021-07-17 11:47:16 --> Hooks Class Initialized
INFO - 2021-07-17 11:47:16 --> Config Class Initialized
INFO - 2021-07-17 11:47:16 --> Hooks Class Initialized
DEBUG - 2021-07-17 11:47:16 --> UTF-8 Support Enabled
INFO - 2021-07-17 11:47:16 --> Utf8 Class Initialized
DEBUG - 2021-07-17 11:47:16 --> UTF-8 Support Enabled
INFO - 2021-07-17 11:47:16 --> Utf8 Class Initialized
INFO - 2021-07-17 11:47:16 --> URI Class Initialized
INFO - 2021-07-17 11:47:16 --> URI Class Initialized
INFO - 2021-07-17 11:47:16 --> Router Class Initialized
INFO - 2021-07-17 11:47:16 --> Router Class Initialized
INFO - 2021-07-17 11:47:16 --> Output Class Initialized
INFO - 2021-07-17 11:47:16 --> Output Class Initialized
INFO - 2021-07-17 11:47:16 --> Security Class Initialized
INFO - 2021-07-17 11:47:16 --> Security Class Initialized
DEBUG - 2021-07-17 11:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 11:47:16 --> Input Class Initialized
DEBUG - 2021-07-17 11:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 11:47:16 --> Language Class Initialized
INFO - 2021-07-17 11:47:16 --> Input Class Initialized
INFO - 2021-07-17 11:47:16 --> Language Class Initialized
ERROR - 2021-07-17 11:47:16 --> 404 Page Not Found: Assets/jquery
ERROR - 2021-07-17 11:47:16 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-17 11:47:16 --> Config Class Initialized
INFO - 2021-07-17 11:47:16 --> Hooks Class Initialized
DEBUG - 2021-07-17 11:47:16 --> UTF-8 Support Enabled
INFO - 2021-07-17 11:47:16 --> Utf8 Class Initialized
INFO - 2021-07-17 11:47:16 --> URI Class Initialized
INFO - 2021-07-17 11:47:16 --> Router Class Initialized
INFO - 2021-07-17 11:47:16 --> Output Class Initialized
INFO - 2021-07-17 11:47:16 --> Security Class Initialized
DEBUG - 2021-07-17 11:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 11:47:16 --> Input Class Initialized
INFO - 2021-07-17 11:47:16 --> Language Class Initialized
ERROR - 2021-07-17 11:47:16 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-17 11:47:24 --> Config Class Initialized
INFO - 2021-07-17 11:47:24 --> Hooks Class Initialized
DEBUG - 2021-07-17 11:47:24 --> UTF-8 Support Enabled
INFO - 2021-07-17 11:47:24 --> Utf8 Class Initialized
INFO - 2021-07-17 11:47:24 --> URI Class Initialized
INFO - 2021-07-17 11:47:24 --> Router Class Initialized
INFO - 2021-07-17 11:47:24 --> Output Class Initialized
INFO - 2021-07-17 11:47:24 --> Security Class Initialized
DEBUG - 2021-07-17 11:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 11:47:24 --> Input Class Initialized
INFO - 2021-07-17 11:47:24 --> Language Class Initialized
INFO - 2021-07-17 11:47:24 --> Loader Class Initialized
INFO - 2021-07-17 11:47:24 --> Helper loaded: basic_helper
INFO - 2021-07-17 11:47:24 --> Helper loaded: url_helper
INFO - 2021-07-17 11:47:24 --> Helper loaded: file_helper
INFO - 2021-07-17 11:47:24 --> Helper loaded: form_helper
INFO - 2021-07-17 11:47:24 --> Helper loaded: cookie_helper
INFO - 2021-07-17 11:47:24 --> Helper loaded: security_helper
INFO - 2021-07-17 11:47:24 --> Helper loaded: directory_helper
INFO - 2021-07-17 11:47:24 --> Helper loaded: language_helper
INFO - 2021-07-17 11:47:24 --> Helper loaded: general_helper
INFO - 2021-07-17 11:47:24 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 11:47:24 --> Database Driver Class Initialized
DEBUG - 2021-07-17 11:47:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 11:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 11:47:24 --> Parser Class Initialized
INFO - 2021-07-17 11:47:24 --> Form Validation Class Initialized
INFO - 2021-07-17 11:47:24 --> Upload Class Initialized
INFO - 2021-07-17 11:47:24 --> Email Class Initialized
INFO - 2021-07-17 11:47:24 --> MY_Model class loaded
INFO - 2021-07-17 11:47:24 --> Model "Users_model" initialized
INFO - 2021-07-17 11:47:24 --> Model "Settings_model" initialized
INFO - 2021-07-17 11:47:24 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 11:47:24 --> Model "Permissions_model" initialized
INFO - 2021-07-17 11:47:24 --> Model "Roles_model" initialized
INFO - 2021-07-17 11:47:24 --> Model "Activity_model" initialized
INFO - 2021-07-17 11:47:24 --> Model "Templates_model" initialized
INFO - 2021-07-17 11:47:24 --> Database Driver Class Initialized
INFO - 2021-07-17 11:47:24 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 11:47:24 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 11:47:24 --> Controller Class Initialized
DEBUG - 2021-07-17 11:47:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-17 11:47:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2021-07-17 11:47:24 --> Config Class Initialized
INFO - 2021-07-17 11:47:24 --> Hooks Class Initialized
DEBUG - 2021-07-17 11:47:24 --> UTF-8 Support Enabled
INFO - 2021-07-17 11:47:24 --> Utf8 Class Initialized
INFO - 2021-07-17 11:47:24 --> URI Class Initialized
DEBUG - 2021-07-17 11:47:24 --> No URI present. Default controller set.
INFO - 2021-07-17 11:47:24 --> Router Class Initialized
INFO - 2021-07-17 11:47:24 --> Output Class Initialized
INFO - 2021-07-17 11:47:24 --> Security Class Initialized
DEBUG - 2021-07-17 11:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 11:47:24 --> Input Class Initialized
INFO - 2021-07-17 11:47:24 --> Language Class Initialized
INFO - 2021-07-17 11:47:24 --> Loader Class Initialized
INFO - 2021-07-17 11:47:24 --> Helper loaded: basic_helper
INFO - 2021-07-17 11:47:24 --> Helper loaded: url_helper
INFO - 2021-07-17 11:47:24 --> Helper loaded: file_helper
INFO - 2021-07-17 11:47:24 --> Helper loaded: form_helper
INFO - 2021-07-17 11:47:24 --> Helper loaded: cookie_helper
INFO - 2021-07-17 11:47:24 --> Helper loaded: security_helper
INFO - 2021-07-17 11:47:24 --> Helper loaded: directory_helper
INFO - 2021-07-17 11:47:24 --> Helper loaded: language_helper
INFO - 2021-07-17 11:47:24 --> Helper loaded: general_helper
INFO - 2021-07-17 11:47:24 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 11:47:24 --> Database Driver Class Initialized
DEBUG - 2021-07-17 11:47:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 11:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 11:47:24 --> Parser Class Initialized
INFO - 2021-07-17 11:47:24 --> Form Validation Class Initialized
INFO - 2021-07-17 11:47:24 --> Upload Class Initialized
INFO - 2021-07-17 11:47:24 --> Email Class Initialized
INFO - 2021-07-17 11:47:24 --> MY_Model class loaded
INFO - 2021-07-17 11:47:24 --> Model "Users_model" initialized
INFO - 2021-07-17 11:47:24 --> Model "Settings_model" initialized
INFO - 2021-07-17 11:47:24 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 11:47:24 --> Model "Permissions_model" initialized
INFO - 2021-07-17 11:47:24 --> Model "Roles_model" initialized
INFO - 2021-07-17 11:47:24 --> Model "Activity_model" initialized
INFO - 2021-07-17 11:47:24 --> Model "Templates_model" initialized
INFO - 2021-07-17 11:47:24 --> Database Driver Class Initialized
INFO - 2021-07-17 11:47:24 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 11:47:24 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 11:47:24 --> Controller Class Initialized
ERROR - 2021-07-17 11:47:24 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 11:47:24 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-17 11:47:24 --> Final output sent to browser
DEBUG - 2021-07-17 11:47:24 --> Total execution time: 0.0669
INFO - 2021-07-17 11:47:29 --> Config Class Initialized
INFO - 2021-07-17 11:47:29 --> Hooks Class Initialized
DEBUG - 2021-07-17 11:47:29 --> UTF-8 Support Enabled
INFO - 2021-07-17 11:47:29 --> Utf8 Class Initialized
INFO - 2021-07-17 11:47:29 --> URI Class Initialized
INFO - 2021-07-17 11:47:29 --> Router Class Initialized
INFO - 2021-07-17 11:47:29 --> Output Class Initialized
INFO - 2021-07-17 11:47:29 --> Security Class Initialized
DEBUG - 2021-07-17 11:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 11:47:29 --> Input Class Initialized
INFO - 2021-07-17 11:47:29 --> Language Class Initialized
INFO - 2021-07-17 11:47:29 --> Loader Class Initialized
INFO - 2021-07-17 11:47:29 --> Helper loaded: basic_helper
INFO - 2021-07-17 11:47:29 --> Helper loaded: url_helper
INFO - 2021-07-17 11:47:29 --> Helper loaded: file_helper
INFO - 2021-07-17 11:47:29 --> Helper loaded: form_helper
INFO - 2021-07-17 11:47:29 --> Helper loaded: cookie_helper
INFO - 2021-07-17 11:47:29 --> Helper loaded: security_helper
INFO - 2021-07-17 11:47:29 --> Helper loaded: directory_helper
INFO - 2021-07-17 11:47:29 --> Helper loaded: language_helper
INFO - 2021-07-17 11:47:29 --> Helper loaded: general_helper
INFO - 2021-07-17 11:47:29 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 11:47:29 --> Database Driver Class Initialized
DEBUG - 2021-07-17 11:47:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 11:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 11:47:29 --> Parser Class Initialized
INFO - 2021-07-17 11:47:29 --> Form Validation Class Initialized
INFO - 2021-07-17 11:47:29 --> Upload Class Initialized
INFO - 2021-07-17 11:47:29 --> Email Class Initialized
INFO - 2021-07-17 11:47:29 --> MY_Model class loaded
INFO - 2021-07-17 11:47:29 --> Model "Users_model" initialized
INFO - 2021-07-17 11:47:29 --> Model "Settings_model" initialized
INFO - 2021-07-17 11:47:29 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 11:47:29 --> Model "Permissions_model" initialized
INFO - 2021-07-17 11:47:29 --> Model "Roles_model" initialized
INFO - 2021-07-17 11:47:29 --> Model "Activity_model" initialized
INFO - 2021-07-17 11:47:29 --> Model "Templates_model" initialized
INFO - 2021-07-17 11:47:29 --> Database Driver Class Initialized
INFO - 2021-07-17 11:47:29 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 11:47:29 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 11:47:29 --> Controller Class Initialized
ERROR - 2021-07-17 11:47:29 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 11:47:29 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 11:47:29 --> Final output sent to browser
DEBUG - 2021-07-17 11:47:29 --> Total execution time: 0.1244
INFO - 2021-07-17 11:48:54 --> Config Class Initialized
INFO - 2021-07-17 11:48:54 --> Hooks Class Initialized
DEBUG - 2021-07-17 11:48:54 --> UTF-8 Support Enabled
INFO - 2021-07-17 11:48:54 --> Utf8 Class Initialized
INFO - 2021-07-17 11:48:54 --> URI Class Initialized
INFO - 2021-07-17 11:48:54 --> Router Class Initialized
INFO - 2021-07-17 11:48:54 --> Output Class Initialized
INFO - 2021-07-17 11:48:54 --> Security Class Initialized
DEBUG - 2021-07-17 11:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 11:48:54 --> Input Class Initialized
INFO - 2021-07-17 11:48:54 --> Language Class Initialized
INFO - 2021-07-17 11:48:54 --> Loader Class Initialized
INFO - 2021-07-17 11:48:54 --> Helper loaded: basic_helper
INFO - 2021-07-17 11:48:54 --> Helper loaded: url_helper
INFO - 2021-07-17 11:48:54 --> Helper loaded: file_helper
INFO - 2021-07-17 11:48:54 --> Helper loaded: form_helper
INFO - 2021-07-17 11:48:54 --> Helper loaded: cookie_helper
INFO - 2021-07-17 11:48:54 --> Helper loaded: security_helper
INFO - 2021-07-17 11:48:54 --> Helper loaded: directory_helper
INFO - 2021-07-17 11:48:54 --> Helper loaded: language_helper
INFO - 2021-07-17 11:48:54 --> Helper loaded: general_helper
INFO - 2021-07-17 11:48:54 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 11:48:54 --> Database Driver Class Initialized
DEBUG - 2021-07-17 11:48:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 11:48:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 11:48:54 --> Parser Class Initialized
INFO - 2021-07-17 11:48:54 --> Form Validation Class Initialized
INFO - 2021-07-17 11:48:54 --> Upload Class Initialized
INFO - 2021-07-17 11:48:54 --> Email Class Initialized
INFO - 2021-07-17 11:48:54 --> MY_Model class loaded
INFO - 2021-07-17 11:48:54 --> Model "Users_model" initialized
INFO - 2021-07-17 11:48:54 --> Model "Settings_model" initialized
INFO - 2021-07-17 11:48:54 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 11:48:54 --> Model "Permissions_model" initialized
INFO - 2021-07-17 11:48:54 --> Model "Roles_model" initialized
INFO - 2021-07-17 11:48:54 --> Model "Activity_model" initialized
INFO - 2021-07-17 11:48:54 --> Model "Templates_model" initialized
INFO - 2021-07-17 11:48:54 --> Database Driver Class Initialized
INFO - 2021-07-17 11:48:55 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 11:48:55 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 11:48:55 --> Controller Class Initialized
ERROR - 2021-07-17 11:48:55 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 11:48:55 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 11:48:55 --> Final output sent to browser
DEBUG - 2021-07-17 11:48:55 --> Total execution time: 0.5438
INFO - 2021-07-17 11:49:15 --> Config Class Initialized
INFO - 2021-07-17 11:49:15 --> Hooks Class Initialized
DEBUG - 2021-07-17 11:49:15 --> UTF-8 Support Enabled
INFO - 2021-07-17 11:49:15 --> Utf8 Class Initialized
INFO - 2021-07-17 11:49:15 --> URI Class Initialized
INFO - 2021-07-17 11:49:15 --> Router Class Initialized
INFO - 2021-07-17 11:49:15 --> Output Class Initialized
INFO - 2021-07-17 11:49:15 --> Security Class Initialized
DEBUG - 2021-07-17 11:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 11:49:15 --> Input Class Initialized
INFO - 2021-07-17 11:49:15 --> Language Class Initialized
INFO - 2021-07-17 11:49:15 --> Loader Class Initialized
INFO - 2021-07-17 11:49:15 --> Helper loaded: basic_helper
INFO - 2021-07-17 11:49:15 --> Helper loaded: url_helper
INFO - 2021-07-17 11:49:15 --> Helper loaded: file_helper
INFO - 2021-07-17 11:49:15 --> Helper loaded: form_helper
INFO - 2021-07-17 11:49:15 --> Helper loaded: cookie_helper
INFO - 2021-07-17 11:49:15 --> Helper loaded: security_helper
INFO - 2021-07-17 11:49:15 --> Helper loaded: directory_helper
INFO - 2021-07-17 11:49:15 --> Helper loaded: language_helper
INFO - 2021-07-17 11:49:15 --> Helper loaded: general_helper
INFO - 2021-07-17 11:49:15 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 11:49:15 --> Database Driver Class Initialized
DEBUG - 2021-07-17 11:49:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 11:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 11:49:15 --> Parser Class Initialized
INFO - 2021-07-17 11:49:15 --> Form Validation Class Initialized
INFO - 2021-07-17 11:49:15 --> Upload Class Initialized
INFO - 2021-07-17 11:49:15 --> Email Class Initialized
INFO - 2021-07-17 11:49:15 --> MY_Model class loaded
INFO - 2021-07-17 11:49:15 --> Model "Users_model" initialized
INFO - 2021-07-17 11:49:15 --> Model "Settings_model" initialized
INFO - 2021-07-17 11:49:15 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 11:49:15 --> Model "Permissions_model" initialized
INFO - 2021-07-17 11:49:15 --> Model "Roles_model" initialized
INFO - 2021-07-17 11:49:15 --> Model "Activity_model" initialized
INFO - 2021-07-17 11:49:15 --> Model "Templates_model" initialized
INFO - 2021-07-17 11:49:15 --> Database Driver Class Initialized
INFO - 2021-07-17 11:49:15 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 11:49:15 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 11:49:15 --> Controller Class Initialized
ERROR - 2021-07-17 11:49:15 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 11:49:15 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 11:49:15 --> Final output sent to browser
DEBUG - 2021-07-17 11:49:15 --> Total execution time: 0.1319
INFO - 2021-07-17 11:49:20 --> Config Class Initialized
INFO - 2021-07-17 11:49:20 --> Hooks Class Initialized
DEBUG - 2021-07-17 11:49:20 --> UTF-8 Support Enabled
INFO - 2021-07-17 11:49:20 --> Utf8 Class Initialized
INFO - 2021-07-17 11:49:20 --> URI Class Initialized
INFO - 2021-07-17 11:49:20 --> Router Class Initialized
INFO - 2021-07-17 11:49:20 --> Output Class Initialized
INFO - 2021-07-17 11:49:20 --> Security Class Initialized
DEBUG - 2021-07-17 11:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 11:49:20 --> Input Class Initialized
INFO - 2021-07-17 11:49:20 --> Language Class Initialized
INFO - 2021-07-17 11:49:20 --> Loader Class Initialized
INFO - 2021-07-17 11:49:20 --> Helper loaded: basic_helper
INFO - 2021-07-17 11:49:20 --> Helper loaded: url_helper
INFO - 2021-07-17 11:49:20 --> Helper loaded: file_helper
INFO - 2021-07-17 11:49:20 --> Helper loaded: form_helper
INFO - 2021-07-17 11:49:20 --> Helper loaded: cookie_helper
INFO - 2021-07-17 11:49:20 --> Helper loaded: security_helper
INFO - 2021-07-17 11:49:20 --> Helper loaded: directory_helper
INFO - 2021-07-17 11:49:20 --> Helper loaded: language_helper
INFO - 2021-07-17 11:49:20 --> Helper loaded: general_helper
INFO - 2021-07-17 11:49:20 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 11:49:20 --> Database Driver Class Initialized
DEBUG - 2021-07-17 11:49:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 11:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 11:49:20 --> Parser Class Initialized
INFO - 2021-07-17 11:49:20 --> Form Validation Class Initialized
INFO - 2021-07-17 11:49:20 --> Upload Class Initialized
INFO - 2021-07-17 11:49:20 --> Email Class Initialized
INFO - 2021-07-17 11:49:20 --> MY_Model class loaded
INFO - 2021-07-17 11:49:20 --> Model "Users_model" initialized
INFO - 2021-07-17 11:49:20 --> Model "Settings_model" initialized
INFO - 2021-07-17 11:49:20 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 11:49:20 --> Model "Permissions_model" initialized
INFO - 2021-07-17 11:49:20 --> Model "Roles_model" initialized
INFO - 2021-07-17 11:49:20 --> Model "Activity_model" initialized
INFO - 2021-07-17 11:49:20 --> Model "Templates_model" initialized
INFO - 2021-07-17 11:49:20 --> Database Driver Class Initialized
INFO - 2021-07-17 11:49:20 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 11:49:20 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 11:49:20 --> Controller Class Initialized
ERROR - 2021-07-17 11:49:20 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 11:49:20 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 11:49:20 --> Final output sent to browser
DEBUG - 2021-07-17 11:49:20 --> Total execution time: 0.1349
INFO - 2021-07-17 11:49:22 --> Config Class Initialized
INFO - 2021-07-17 11:49:22 --> Hooks Class Initialized
DEBUG - 2021-07-17 11:49:22 --> UTF-8 Support Enabled
INFO - 2021-07-17 11:49:22 --> Utf8 Class Initialized
INFO - 2021-07-17 11:49:22 --> URI Class Initialized
INFO - 2021-07-17 11:49:22 --> Router Class Initialized
INFO - 2021-07-17 11:49:22 --> Output Class Initialized
INFO - 2021-07-17 11:49:22 --> Security Class Initialized
DEBUG - 2021-07-17 11:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 11:49:22 --> Input Class Initialized
INFO - 2021-07-17 11:49:22 --> Language Class Initialized
INFO - 2021-07-17 11:49:22 --> Loader Class Initialized
INFO - 2021-07-17 11:49:22 --> Helper loaded: basic_helper
INFO - 2021-07-17 11:49:22 --> Helper loaded: url_helper
INFO - 2021-07-17 11:49:22 --> Helper loaded: file_helper
INFO - 2021-07-17 11:49:22 --> Helper loaded: form_helper
INFO - 2021-07-17 11:49:22 --> Helper loaded: cookie_helper
INFO - 2021-07-17 11:49:22 --> Helper loaded: security_helper
INFO - 2021-07-17 11:49:22 --> Helper loaded: directory_helper
INFO - 2021-07-17 11:49:22 --> Helper loaded: language_helper
INFO - 2021-07-17 11:49:22 --> Helper loaded: general_helper
INFO - 2021-07-17 11:49:22 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 11:49:22 --> Database Driver Class Initialized
DEBUG - 2021-07-17 11:49:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 11:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 11:49:22 --> Parser Class Initialized
INFO - 2021-07-17 11:49:22 --> Form Validation Class Initialized
INFO - 2021-07-17 11:49:22 --> Upload Class Initialized
INFO - 2021-07-17 11:49:22 --> Email Class Initialized
INFO - 2021-07-17 11:49:22 --> MY_Model class loaded
INFO - 2021-07-17 11:49:22 --> Model "Users_model" initialized
INFO - 2021-07-17 11:49:22 --> Model "Settings_model" initialized
INFO - 2021-07-17 11:49:22 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 11:49:22 --> Model "Permissions_model" initialized
INFO - 2021-07-17 11:49:22 --> Model "Roles_model" initialized
INFO - 2021-07-17 11:49:22 --> Model "Activity_model" initialized
INFO - 2021-07-17 11:49:22 --> Model "Templates_model" initialized
INFO - 2021-07-17 11:49:22 --> Database Driver Class Initialized
INFO - 2021-07-17 11:49:22 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 11:49:22 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 11:49:22 --> Controller Class Initialized
ERROR - 2021-07-17 11:49:22 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 11:49:22 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 11:49:22 --> Final output sent to browser
DEBUG - 2021-07-17 11:49:22 --> Total execution time: 0.0606
INFO - 2021-07-17 11:49:55 --> Config Class Initialized
INFO - 2021-07-17 11:49:55 --> Hooks Class Initialized
DEBUG - 2021-07-17 11:49:55 --> UTF-8 Support Enabled
INFO - 2021-07-17 11:49:55 --> Utf8 Class Initialized
INFO - 2021-07-17 11:49:55 --> URI Class Initialized
INFO - 2021-07-17 11:49:55 --> Router Class Initialized
INFO - 2021-07-17 11:49:55 --> Output Class Initialized
INFO - 2021-07-17 11:49:55 --> Security Class Initialized
DEBUG - 2021-07-17 11:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 11:49:55 --> Input Class Initialized
INFO - 2021-07-17 11:49:55 --> Language Class Initialized
INFO - 2021-07-17 11:49:55 --> Loader Class Initialized
INFO - 2021-07-17 11:49:55 --> Helper loaded: basic_helper
INFO - 2021-07-17 11:49:55 --> Helper loaded: url_helper
INFO - 2021-07-17 11:49:55 --> Helper loaded: file_helper
INFO - 2021-07-17 11:49:55 --> Helper loaded: form_helper
INFO - 2021-07-17 11:49:55 --> Helper loaded: cookie_helper
INFO - 2021-07-17 11:49:55 --> Helper loaded: security_helper
INFO - 2021-07-17 11:49:55 --> Helper loaded: directory_helper
INFO - 2021-07-17 11:49:55 --> Helper loaded: language_helper
INFO - 2021-07-17 11:49:55 --> Helper loaded: general_helper
INFO - 2021-07-17 11:49:55 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 11:49:55 --> Database Driver Class Initialized
DEBUG - 2021-07-17 11:49:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 11:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 11:49:55 --> Parser Class Initialized
INFO - 2021-07-17 11:49:55 --> Form Validation Class Initialized
INFO - 2021-07-17 11:49:55 --> Upload Class Initialized
INFO - 2021-07-17 11:49:55 --> Email Class Initialized
INFO - 2021-07-17 11:49:55 --> MY_Model class loaded
INFO - 2021-07-17 11:49:55 --> Model "Users_model" initialized
INFO - 2021-07-17 11:49:55 --> Model "Settings_model" initialized
INFO - 2021-07-17 11:49:55 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 11:49:55 --> Model "Permissions_model" initialized
INFO - 2021-07-17 11:49:55 --> Model "Roles_model" initialized
INFO - 2021-07-17 11:49:55 --> Model "Activity_model" initialized
INFO - 2021-07-17 11:49:55 --> Model "Templates_model" initialized
INFO - 2021-07-17 11:49:55 --> Database Driver Class Initialized
INFO - 2021-07-17 11:49:56 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 11:49:56 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 11:49:56 --> Controller Class Initialized
ERROR - 2021-07-17 11:49:56 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 11:49:56 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 11:49:56 --> Final output sent to browser
DEBUG - 2021-07-17 11:49:56 --> Total execution time: 0.1372
INFO - 2021-07-17 11:50:20 --> Config Class Initialized
INFO - 2021-07-17 11:50:20 --> Hooks Class Initialized
DEBUG - 2021-07-17 11:50:20 --> UTF-8 Support Enabled
INFO - 2021-07-17 11:50:20 --> Utf8 Class Initialized
INFO - 2021-07-17 11:50:20 --> URI Class Initialized
DEBUG - 2021-07-17 11:50:20 --> No URI present. Default controller set.
INFO - 2021-07-17 11:50:20 --> Router Class Initialized
INFO - 2021-07-17 11:50:20 --> Output Class Initialized
INFO - 2021-07-17 11:50:20 --> Security Class Initialized
DEBUG - 2021-07-17 11:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 11:50:20 --> Input Class Initialized
INFO - 2021-07-17 11:50:20 --> Language Class Initialized
INFO - 2021-07-17 11:50:20 --> Loader Class Initialized
INFO - 2021-07-17 11:50:20 --> Helper loaded: basic_helper
INFO - 2021-07-17 11:50:20 --> Helper loaded: url_helper
INFO - 2021-07-17 11:50:20 --> Helper loaded: file_helper
INFO - 2021-07-17 11:50:20 --> Helper loaded: form_helper
INFO - 2021-07-17 11:50:20 --> Helper loaded: cookie_helper
INFO - 2021-07-17 11:50:20 --> Helper loaded: security_helper
INFO - 2021-07-17 11:50:20 --> Helper loaded: directory_helper
INFO - 2021-07-17 11:50:20 --> Helper loaded: language_helper
INFO - 2021-07-17 11:50:20 --> Helper loaded: general_helper
INFO - 2021-07-17 11:50:20 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 11:50:20 --> Database Driver Class Initialized
DEBUG - 2021-07-17 11:50:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 11:50:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 11:50:20 --> Parser Class Initialized
INFO - 2021-07-17 11:50:20 --> Form Validation Class Initialized
INFO - 2021-07-17 11:50:20 --> Upload Class Initialized
INFO - 2021-07-17 11:50:20 --> Email Class Initialized
INFO - 2021-07-17 11:50:20 --> MY_Model class loaded
INFO - 2021-07-17 11:50:20 --> Model "Users_model" initialized
INFO - 2021-07-17 11:50:20 --> Model "Settings_model" initialized
INFO - 2021-07-17 11:50:20 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 11:50:20 --> Model "Permissions_model" initialized
INFO - 2021-07-17 11:50:20 --> Model "Roles_model" initialized
INFO - 2021-07-17 11:50:20 --> Model "Activity_model" initialized
INFO - 2021-07-17 11:50:20 --> Model "Templates_model" initialized
INFO - 2021-07-17 11:50:20 --> Database Driver Class Initialized
INFO - 2021-07-17 11:50:20 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 11:50:20 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 11:50:20 --> Controller Class Initialized
INFO - 2021-07-17 11:56:38 --> Config Class Initialized
INFO - 2021-07-17 11:56:38 --> Hooks Class Initialized
DEBUG - 2021-07-17 11:56:38 --> UTF-8 Support Enabled
INFO - 2021-07-17 11:56:38 --> Utf8 Class Initialized
INFO - 2021-07-17 11:56:38 --> URI Class Initialized
INFO - 2021-07-17 11:56:38 --> Router Class Initialized
INFO - 2021-07-17 11:56:38 --> Output Class Initialized
INFO - 2021-07-17 11:56:38 --> Security Class Initialized
DEBUG - 2021-07-17 11:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 11:56:38 --> Input Class Initialized
INFO - 2021-07-17 11:56:38 --> Language Class Initialized
INFO - 2021-07-17 11:56:38 --> Loader Class Initialized
INFO - 2021-07-17 11:56:38 --> Helper loaded: basic_helper
INFO - 2021-07-17 11:56:38 --> Helper loaded: url_helper
INFO - 2021-07-17 11:56:38 --> Helper loaded: file_helper
INFO - 2021-07-17 11:56:38 --> Helper loaded: form_helper
INFO - 2021-07-17 11:56:38 --> Helper loaded: cookie_helper
INFO - 2021-07-17 11:56:38 --> Helper loaded: security_helper
INFO - 2021-07-17 11:56:38 --> Helper loaded: directory_helper
INFO - 2021-07-17 11:56:38 --> Helper loaded: language_helper
INFO - 2021-07-17 11:56:38 --> Helper loaded: general_helper
INFO - 2021-07-17 11:56:38 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 11:56:38 --> Database Driver Class Initialized
DEBUG - 2021-07-17 11:56:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 11:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 11:56:38 --> Parser Class Initialized
INFO - 2021-07-17 11:56:38 --> Form Validation Class Initialized
INFO - 2021-07-17 11:56:38 --> Upload Class Initialized
INFO - 2021-07-17 11:56:38 --> Email Class Initialized
INFO - 2021-07-17 11:56:38 --> MY_Model class loaded
INFO - 2021-07-17 11:56:38 --> Model "Users_model" initialized
INFO - 2021-07-17 11:56:38 --> Model "Settings_model" initialized
INFO - 2021-07-17 11:56:38 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 11:56:38 --> Model "Permissions_model" initialized
INFO - 2021-07-17 11:56:38 --> Model "Roles_model" initialized
INFO - 2021-07-17 11:56:38 --> Model "Activity_model" initialized
INFO - 2021-07-17 11:56:38 --> Model "Templates_model" initialized
INFO - 2021-07-17 11:56:38 --> Database Driver Class Initialized
INFO - 2021-07-17 11:56:39 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 11:56:39 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 11:56:39 --> Controller Class Initialized
ERROR - 2021-07-17 11:56:39 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 11:56:39 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 11:56:39 --> Final output sent to browser
DEBUG - 2021-07-17 11:56:39 --> Total execution time: 0.5361
INFO - 2021-07-17 11:58:15 --> Config Class Initialized
INFO - 2021-07-17 11:58:15 --> Hooks Class Initialized
DEBUG - 2021-07-17 11:58:15 --> UTF-8 Support Enabled
INFO - 2021-07-17 11:58:15 --> Utf8 Class Initialized
INFO - 2021-07-17 11:58:15 --> URI Class Initialized
INFO - 2021-07-17 11:58:15 --> Router Class Initialized
INFO - 2021-07-17 11:58:15 --> Output Class Initialized
INFO - 2021-07-17 11:58:15 --> Security Class Initialized
DEBUG - 2021-07-17 11:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 11:58:15 --> Input Class Initialized
INFO - 2021-07-17 11:58:15 --> Language Class Initialized
INFO - 2021-07-17 11:58:15 --> Loader Class Initialized
INFO - 2021-07-17 11:58:15 --> Helper loaded: basic_helper
INFO - 2021-07-17 11:58:15 --> Helper loaded: url_helper
INFO - 2021-07-17 11:58:15 --> Helper loaded: file_helper
INFO - 2021-07-17 11:58:15 --> Helper loaded: form_helper
INFO - 2021-07-17 11:58:15 --> Helper loaded: cookie_helper
INFO - 2021-07-17 11:58:15 --> Helper loaded: security_helper
INFO - 2021-07-17 11:58:15 --> Helper loaded: directory_helper
INFO - 2021-07-17 11:58:15 --> Helper loaded: language_helper
INFO - 2021-07-17 11:58:15 --> Helper loaded: general_helper
INFO - 2021-07-17 11:58:15 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 11:58:15 --> Database Driver Class Initialized
DEBUG - 2021-07-17 11:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 11:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 11:58:15 --> Parser Class Initialized
INFO - 2021-07-17 11:58:15 --> Form Validation Class Initialized
INFO - 2021-07-17 11:58:15 --> Upload Class Initialized
INFO - 2021-07-17 11:58:15 --> Email Class Initialized
INFO - 2021-07-17 11:58:15 --> MY_Model class loaded
INFO - 2021-07-17 11:58:15 --> Model "Users_model" initialized
INFO - 2021-07-17 11:58:15 --> Model "Settings_model" initialized
INFO - 2021-07-17 11:58:15 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 11:58:15 --> Model "Permissions_model" initialized
INFO - 2021-07-17 11:58:15 --> Model "Roles_model" initialized
INFO - 2021-07-17 11:58:15 --> Model "Activity_model" initialized
INFO - 2021-07-17 11:58:15 --> Model "Templates_model" initialized
INFO - 2021-07-17 11:58:15 --> Database Driver Class Initialized
INFO - 2021-07-17 11:58:15 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 11:58:15 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 11:58:15 --> Controller Class Initialized
ERROR - 2021-07-17 11:58:15 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 11:58:15 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 11:58:15 --> Final output sent to browser
DEBUG - 2021-07-17 11:58:15 --> Total execution time: 0.1379
INFO - 2021-07-17 11:58:25 --> Config Class Initialized
INFO - 2021-07-17 11:58:25 --> Hooks Class Initialized
DEBUG - 2021-07-17 11:58:25 --> UTF-8 Support Enabled
INFO - 2021-07-17 11:58:25 --> Utf8 Class Initialized
INFO - 2021-07-17 11:58:25 --> URI Class Initialized
INFO - 2021-07-17 11:58:25 --> Router Class Initialized
INFO - 2021-07-17 11:58:25 --> Output Class Initialized
INFO - 2021-07-17 11:58:25 --> Security Class Initialized
DEBUG - 2021-07-17 11:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 11:58:25 --> Input Class Initialized
INFO - 2021-07-17 11:58:25 --> Language Class Initialized
INFO - 2021-07-17 11:58:25 --> Loader Class Initialized
INFO - 2021-07-17 11:58:25 --> Helper loaded: basic_helper
INFO - 2021-07-17 11:58:25 --> Helper loaded: url_helper
INFO - 2021-07-17 11:58:25 --> Helper loaded: file_helper
INFO - 2021-07-17 11:58:25 --> Helper loaded: form_helper
INFO - 2021-07-17 11:58:25 --> Helper loaded: cookie_helper
INFO - 2021-07-17 11:58:25 --> Helper loaded: security_helper
INFO - 2021-07-17 11:58:25 --> Helper loaded: directory_helper
INFO - 2021-07-17 11:58:25 --> Helper loaded: language_helper
INFO - 2021-07-17 11:58:25 --> Helper loaded: general_helper
INFO - 2021-07-17 11:58:25 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 11:58:25 --> Database Driver Class Initialized
DEBUG - 2021-07-17 11:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 11:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 11:58:25 --> Parser Class Initialized
INFO - 2021-07-17 11:58:25 --> Form Validation Class Initialized
INFO - 2021-07-17 11:58:25 --> Upload Class Initialized
INFO - 2021-07-17 11:58:25 --> Email Class Initialized
INFO - 2021-07-17 11:58:25 --> MY_Model class loaded
INFO - 2021-07-17 11:58:25 --> Model "Users_model" initialized
INFO - 2021-07-17 11:58:25 --> Model "Settings_model" initialized
INFO - 2021-07-17 11:58:25 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 11:58:25 --> Model "Permissions_model" initialized
INFO - 2021-07-17 11:58:25 --> Model "Roles_model" initialized
INFO - 2021-07-17 11:58:25 --> Model "Activity_model" initialized
INFO - 2021-07-17 11:58:25 --> Model "Templates_model" initialized
INFO - 2021-07-17 11:58:25 --> Database Driver Class Initialized
INFO - 2021-07-17 11:58:25 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 11:58:25 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 11:58:25 --> Controller Class Initialized
ERROR - 2021-07-17 11:58:25 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 11:58:25 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 11:58:25 --> Config Class Initialized
INFO - 2021-07-17 11:58:25 --> Hooks Class Initialized
DEBUG - 2021-07-17 11:58:25 --> UTF-8 Support Enabled
INFO - 2021-07-17 11:58:25 --> Utf8 Class Initialized
INFO - 2021-07-17 11:58:25 --> URI Class Initialized
INFO - 2021-07-17 11:58:25 --> Router Class Initialized
INFO - 2021-07-17 11:58:25 --> Output Class Initialized
INFO - 2021-07-17 11:58:25 --> Security Class Initialized
DEBUG - 2021-07-17 11:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 11:58:25 --> Input Class Initialized
INFO - 2021-07-17 11:58:25 --> Language Class Initialized
INFO - 2021-07-17 11:58:25 --> Loader Class Initialized
INFO - 2021-07-17 11:58:25 --> Helper loaded: basic_helper
INFO - 2021-07-17 11:58:25 --> Helper loaded: url_helper
INFO - 2021-07-17 11:58:25 --> Helper loaded: file_helper
INFO - 2021-07-17 11:58:25 --> Helper loaded: form_helper
INFO - 2021-07-17 11:58:25 --> Helper loaded: cookie_helper
INFO - 2021-07-17 11:58:25 --> Helper loaded: security_helper
INFO - 2021-07-17 11:58:25 --> Helper loaded: directory_helper
INFO - 2021-07-17 11:58:25 --> Helper loaded: language_helper
INFO - 2021-07-17 11:58:25 --> Helper loaded: general_helper
INFO - 2021-07-17 11:58:25 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 11:58:25 --> Database Driver Class Initialized
DEBUG - 2021-07-17 11:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 11:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 11:58:25 --> Parser Class Initialized
INFO - 2021-07-17 11:58:25 --> Form Validation Class Initialized
INFO - 2021-07-17 11:58:25 --> Upload Class Initialized
INFO - 2021-07-17 11:58:25 --> Email Class Initialized
INFO - 2021-07-17 11:58:25 --> MY_Model class loaded
INFO - 2021-07-17 11:58:25 --> Model "Users_model" initialized
INFO - 2021-07-17 11:58:25 --> Model "Settings_model" initialized
INFO - 2021-07-17 11:58:25 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 11:58:25 --> Model "Permissions_model" initialized
INFO - 2021-07-17 11:58:25 --> Model "Roles_model" initialized
INFO - 2021-07-17 11:58:25 --> Model "Activity_model" initialized
INFO - 2021-07-17 11:58:25 --> Model "Templates_model" initialized
INFO - 2021-07-17 11:58:25 --> Database Driver Class Initialized
INFO - 2021-07-17 11:58:25 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 11:58:25 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 11:58:25 --> Controller Class Initialized
ERROR - 2021-07-17 11:58:25 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 11:58:25 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 11:58:25 --> Final output sent to browser
DEBUG - 2021-07-17 11:58:25 --> Total execution time: 0.0623
INFO - 2021-07-17 12:03:06 --> Config Class Initialized
INFO - 2021-07-17 12:03:06 --> Hooks Class Initialized
DEBUG - 2021-07-17 12:03:06 --> UTF-8 Support Enabled
INFO - 2021-07-17 12:03:06 --> Utf8 Class Initialized
INFO - 2021-07-17 12:03:06 --> URI Class Initialized
INFO - 2021-07-17 12:03:06 --> Router Class Initialized
INFO - 2021-07-17 12:03:06 --> Output Class Initialized
INFO - 2021-07-17 12:03:06 --> Security Class Initialized
DEBUG - 2021-07-17 12:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 12:03:06 --> Input Class Initialized
INFO - 2021-07-17 12:03:06 --> Language Class Initialized
INFO - 2021-07-17 12:03:06 --> Loader Class Initialized
INFO - 2021-07-17 12:03:06 --> Helper loaded: basic_helper
INFO - 2021-07-17 12:03:06 --> Helper loaded: url_helper
INFO - 2021-07-17 12:03:06 --> Helper loaded: file_helper
INFO - 2021-07-17 12:03:06 --> Helper loaded: form_helper
INFO - 2021-07-17 12:03:06 --> Helper loaded: cookie_helper
INFO - 2021-07-17 12:03:06 --> Helper loaded: security_helper
INFO - 2021-07-17 12:03:06 --> Helper loaded: directory_helper
INFO - 2021-07-17 12:03:06 --> Helper loaded: language_helper
INFO - 2021-07-17 12:03:06 --> Helper loaded: general_helper
INFO - 2021-07-17 12:03:06 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 12:03:06 --> Database Driver Class Initialized
DEBUG - 2021-07-17 12:03:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 12:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 12:03:06 --> Parser Class Initialized
INFO - 2021-07-17 12:03:06 --> Form Validation Class Initialized
INFO - 2021-07-17 12:03:06 --> Upload Class Initialized
INFO - 2021-07-17 12:03:06 --> Email Class Initialized
INFO - 2021-07-17 12:03:06 --> MY_Model class loaded
INFO - 2021-07-17 12:03:06 --> Model "Users_model" initialized
INFO - 2021-07-17 12:03:06 --> Model "Settings_model" initialized
INFO - 2021-07-17 12:03:06 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 12:03:06 --> Model "Permissions_model" initialized
INFO - 2021-07-17 12:03:06 --> Model "Roles_model" initialized
INFO - 2021-07-17 12:03:06 --> Model "Activity_model" initialized
INFO - 2021-07-17 12:03:06 --> Model "Templates_model" initialized
INFO - 2021-07-17 12:03:06 --> Database Driver Class Initialized
INFO - 2021-07-17 12:03:06 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 12:03:06 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 12:03:06 --> Controller Class Initialized
ERROR - 2021-07-17 12:03:06 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 12:03:06 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-17 12:03:06 --> Final output sent to browser
DEBUG - 2021-07-17 12:03:06 --> Total execution time: 0.5650
INFO - 2021-07-17 12:03:14 --> Config Class Initialized
INFO - 2021-07-17 12:03:14 --> Hooks Class Initialized
DEBUG - 2021-07-17 12:03:14 --> UTF-8 Support Enabled
INFO - 2021-07-17 12:03:14 --> Utf8 Class Initialized
INFO - 2021-07-17 12:03:14 --> URI Class Initialized
INFO - 2021-07-17 12:03:14 --> Router Class Initialized
INFO - 2021-07-17 12:03:14 --> Output Class Initialized
INFO - 2021-07-17 12:03:14 --> Security Class Initialized
DEBUG - 2021-07-17 12:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 12:03:14 --> Input Class Initialized
INFO - 2021-07-17 12:03:14 --> Language Class Initialized
INFO - 2021-07-17 12:03:14 --> Loader Class Initialized
INFO - 2021-07-17 12:03:14 --> Helper loaded: basic_helper
INFO - 2021-07-17 12:03:14 --> Helper loaded: url_helper
INFO - 2021-07-17 12:03:14 --> Helper loaded: file_helper
INFO - 2021-07-17 12:03:14 --> Helper loaded: form_helper
INFO - 2021-07-17 12:03:14 --> Helper loaded: cookie_helper
INFO - 2021-07-17 12:03:14 --> Helper loaded: security_helper
INFO - 2021-07-17 12:03:14 --> Helper loaded: directory_helper
INFO - 2021-07-17 12:03:14 --> Helper loaded: language_helper
INFO - 2021-07-17 12:03:14 --> Helper loaded: general_helper
INFO - 2021-07-17 12:03:14 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 12:03:14 --> Database Driver Class Initialized
DEBUG - 2021-07-17 12:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 12:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 12:03:14 --> Parser Class Initialized
INFO - 2021-07-17 12:03:14 --> Form Validation Class Initialized
INFO - 2021-07-17 12:03:14 --> Upload Class Initialized
INFO - 2021-07-17 12:03:14 --> Email Class Initialized
INFO - 2021-07-17 12:03:14 --> MY_Model class loaded
INFO - 2021-07-17 12:03:14 --> Model "Users_model" initialized
INFO - 2021-07-17 12:03:14 --> Model "Settings_model" initialized
INFO - 2021-07-17 12:03:14 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 12:03:14 --> Model "Permissions_model" initialized
INFO - 2021-07-17 12:03:14 --> Model "Roles_model" initialized
INFO - 2021-07-17 12:03:14 --> Model "Activity_model" initialized
INFO - 2021-07-17 12:03:14 --> Model "Templates_model" initialized
INFO - 2021-07-17 12:03:14 --> Database Driver Class Initialized
INFO - 2021-07-17 12:03:14 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 12:03:14 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 12:03:14 --> Controller Class Initialized
ERROR - 2021-07-17 12:03:14 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 12:03:14 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 12:03:14 --> Final output sent to browser
DEBUG - 2021-07-17 12:03:14 --> Total execution time: 0.1309
INFO - 2021-07-17 12:16:52 --> Config Class Initialized
INFO - 2021-07-17 12:16:52 --> Hooks Class Initialized
DEBUG - 2021-07-17 12:16:52 --> UTF-8 Support Enabled
INFO - 2021-07-17 12:16:52 --> Utf8 Class Initialized
INFO - 2021-07-17 12:16:52 --> URI Class Initialized
INFO - 2021-07-17 12:16:52 --> Router Class Initialized
INFO - 2021-07-17 12:16:52 --> Output Class Initialized
INFO - 2021-07-17 12:16:52 --> Security Class Initialized
DEBUG - 2021-07-17 12:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 12:16:52 --> Input Class Initialized
INFO - 2021-07-17 12:16:52 --> Language Class Initialized
INFO - 2021-07-17 12:16:52 --> Loader Class Initialized
INFO - 2021-07-17 12:16:52 --> Helper loaded: basic_helper
INFO - 2021-07-17 12:16:52 --> Helper loaded: url_helper
INFO - 2021-07-17 12:16:52 --> Helper loaded: file_helper
INFO - 2021-07-17 12:16:52 --> Helper loaded: form_helper
INFO - 2021-07-17 12:16:52 --> Helper loaded: cookie_helper
INFO - 2021-07-17 12:16:52 --> Helper loaded: security_helper
INFO - 2021-07-17 12:16:52 --> Helper loaded: directory_helper
INFO - 2021-07-17 12:16:52 --> Helper loaded: language_helper
INFO - 2021-07-17 12:16:52 --> Helper loaded: general_helper
INFO - 2021-07-17 12:16:52 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 12:16:52 --> Database Driver Class Initialized
DEBUG - 2021-07-17 12:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 12:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 12:16:52 --> Parser Class Initialized
INFO - 2021-07-17 12:16:52 --> Form Validation Class Initialized
INFO - 2021-07-17 12:16:52 --> Upload Class Initialized
INFO - 2021-07-17 12:16:52 --> Email Class Initialized
INFO - 2021-07-17 12:16:52 --> MY_Model class loaded
INFO - 2021-07-17 12:16:52 --> Model "Users_model" initialized
INFO - 2021-07-17 12:16:52 --> Model "Settings_model" initialized
INFO - 2021-07-17 12:16:52 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 12:16:52 --> Model "Permissions_model" initialized
INFO - 2021-07-17 12:16:52 --> Model "Roles_model" initialized
INFO - 2021-07-17 12:16:52 --> Model "Activity_model" initialized
INFO - 2021-07-17 12:16:52 --> Model "Templates_model" initialized
INFO - 2021-07-17 12:16:52 --> Database Driver Class Initialized
INFO - 2021-07-17 12:16:52 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 12:16:52 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 12:16:52 --> Controller Class Initialized
ERROR - 2021-07-17 12:16:52 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 12:16:52 --> File loaded: C:\wamp64\www\crm\application\views\settings/general.php
INFO - 2021-07-17 12:16:52 --> Final output sent to browser
DEBUG - 2021-07-17 12:16:52 --> Total execution time: 0.2622
INFO - 2021-07-17 12:17:06 --> Config Class Initialized
INFO - 2021-07-17 12:17:06 --> Hooks Class Initialized
DEBUG - 2021-07-17 12:17:06 --> UTF-8 Support Enabled
INFO - 2021-07-17 12:17:06 --> Utf8 Class Initialized
INFO - 2021-07-17 12:17:06 --> URI Class Initialized
INFO - 2021-07-17 12:17:06 --> Router Class Initialized
INFO - 2021-07-17 12:17:06 --> Output Class Initialized
INFO - 2021-07-17 12:17:06 --> Security Class Initialized
DEBUG - 2021-07-17 12:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 12:17:06 --> Input Class Initialized
INFO - 2021-07-17 12:17:06 --> Language Class Initialized
INFO - 2021-07-17 12:17:06 --> Loader Class Initialized
INFO - 2021-07-17 12:17:06 --> Helper loaded: basic_helper
INFO - 2021-07-17 12:17:06 --> Helper loaded: url_helper
INFO - 2021-07-17 12:17:06 --> Helper loaded: file_helper
INFO - 2021-07-17 12:17:06 --> Helper loaded: form_helper
INFO - 2021-07-17 12:17:06 --> Helper loaded: cookie_helper
INFO - 2021-07-17 12:17:06 --> Helper loaded: security_helper
INFO - 2021-07-17 12:17:06 --> Helper loaded: directory_helper
INFO - 2021-07-17 12:17:06 --> Helper loaded: language_helper
INFO - 2021-07-17 12:17:06 --> Helper loaded: general_helper
INFO - 2021-07-17 12:17:06 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 12:17:06 --> Database Driver Class Initialized
DEBUG - 2021-07-17 12:17:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 12:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 12:17:06 --> Parser Class Initialized
INFO - 2021-07-17 12:17:06 --> Form Validation Class Initialized
INFO - 2021-07-17 12:17:06 --> Upload Class Initialized
INFO - 2021-07-17 12:17:06 --> Email Class Initialized
INFO - 2021-07-17 12:17:06 --> MY_Model class loaded
INFO - 2021-07-17 12:17:06 --> Model "Users_model" initialized
INFO - 2021-07-17 12:17:06 --> Model "Settings_model" initialized
INFO - 2021-07-17 12:17:06 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 12:17:06 --> Model "Permissions_model" initialized
INFO - 2021-07-17 12:17:06 --> Model "Roles_model" initialized
INFO - 2021-07-17 12:17:06 --> Model "Activity_model" initialized
INFO - 2021-07-17 12:17:06 --> Model "Templates_model" initialized
INFO - 2021-07-17 12:17:06 --> Database Driver Class Initialized
INFO - 2021-07-17 12:17:06 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 12:17:06 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 12:17:06 --> Controller Class Initialized
ERROR - 2021-07-17 12:17:06 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 12:17:06 --> File loaded: C:\wamp64\www\crm\application\views\settings/company.php
INFO - 2021-07-17 12:17:06 --> Final output sent to browser
DEBUG - 2021-07-17 12:17:06 --> Total execution time: 0.1314
INFO - 2021-07-17 12:17:08 --> Config Class Initialized
INFO - 2021-07-17 12:17:08 --> Hooks Class Initialized
DEBUG - 2021-07-17 12:17:08 --> UTF-8 Support Enabled
INFO - 2021-07-17 12:17:08 --> Utf8 Class Initialized
INFO - 2021-07-17 12:17:08 --> URI Class Initialized
INFO - 2021-07-17 12:17:08 --> Router Class Initialized
INFO - 2021-07-17 12:17:08 --> Output Class Initialized
INFO - 2021-07-17 12:17:08 --> Security Class Initialized
DEBUG - 2021-07-17 12:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 12:17:08 --> Input Class Initialized
INFO - 2021-07-17 12:17:08 --> Language Class Initialized
INFO - 2021-07-17 12:17:08 --> Loader Class Initialized
INFO - 2021-07-17 12:17:08 --> Helper loaded: basic_helper
INFO - 2021-07-17 12:17:08 --> Helper loaded: url_helper
INFO - 2021-07-17 12:17:08 --> Helper loaded: file_helper
INFO - 2021-07-17 12:17:08 --> Helper loaded: form_helper
INFO - 2021-07-17 12:17:08 --> Helper loaded: cookie_helper
INFO - 2021-07-17 12:17:08 --> Helper loaded: security_helper
INFO - 2021-07-17 12:17:08 --> Helper loaded: directory_helper
INFO - 2021-07-17 12:17:08 --> Helper loaded: language_helper
INFO - 2021-07-17 12:17:08 --> Helper loaded: general_helper
INFO - 2021-07-17 12:17:08 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 12:17:08 --> Database Driver Class Initialized
DEBUG - 2021-07-17 12:17:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 12:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 12:17:08 --> Parser Class Initialized
INFO - 2021-07-17 12:17:08 --> Form Validation Class Initialized
INFO - 2021-07-17 12:17:08 --> Upload Class Initialized
INFO - 2021-07-17 12:17:08 --> Email Class Initialized
INFO - 2021-07-17 12:17:08 --> MY_Model class loaded
INFO - 2021-07-17 12:17:08 --> Model "Users_model" initialized
INFO - 2021-07-17 12:17:08 --> Model "Settings_model" initialized
INFO - 2021-07-17 12:17:08 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 12:17:08 --> Model "Permissions_model" initialized
INFO - 2021-07-17 12:17:08 --> Model "Roles_model" initialized
INFO - 2021-07-17 12:17:08 --> Model "Activity_model" initialized
INFO - 2021-07-17 12:17:08 --> Model "Templates_model" initialized
INFO - 2021-07-17 12:17:08 --> Database Driver Class Initialized
INFO - 2021-07-17 12:17:08 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 12:17:08 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 12:17:08 --> Controller Class Initialized
ERROR - 2021-07-17 12:17:08 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 12:17:08 --> File loaded: C:\wamp64\www\crm\application\views\settings/email_templates/list.php
INFO - 2021-07-17 12:17:08 --> Final output sent to browser
DEBUG - 2021-07-17 12:17:08 --> Total execution time: 0.0678
INFO - 2021-07-17 12:18:11 --> Config Class Initialized
INFO - 2021-07-17 12:18:11 --> Hooks Class Initialized
DEBUG - 2021-07-17 12:18:11 --> UTF-8 Support Enabled
INFO - 2021-07-17 12:18:11 --> Utf8 Class Initialized
INFO - 2021-07-17 12:18:11 --> URI Class Initialized
INFO - 2021-07-17 12:18:11 --> Router Class Initialized
INFO - 2021-07-17 12:18:11 --> Output Class Initialized
INFO - 2021-07-17 12:18:11 --> Security Class Initialized
DEBUG - 2021-07-17 12:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 12:18:11 --> Input Class Initialized
INFO - 2021-07-17 12:18:11 --> Language Class Initialized
INFO - 2021-07-17 12:18:11 --> Loader Class Initialized
INFO - 2021-07-17 12:18:11 --> Helper loaded: basic_helper
INFO - 2021-07-17 12:18:11 --> Helper loaded: url_helper
INFO - 2021-07-17 12:18:11 --> Helper loaded: file_helper
INFO - 2021-07-17 12:18:11 --> Helper loaded: form_helper
INFO - 2021-07-17 12:18:11 --> Helper loaded: cookie_helper
INFO - 2021-07-17 12:18:11 --> Helper loaded: security_helper
INFO - 2021-07-17 12:18:11 --> Helper loaded: directory_helper
INFO - 2021-07-17 12:18:11 --> Helper loaded: language_helper
INFO - 2021-07-17 12:18:11 --> Helper loaded: general_helper
INFO - 2021-07-17 12:18:11 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 12:18:11 --> Database Driver Class Initialized
DEBUG - 2021-07-17 12:18:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 12:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 12:18:11 --> Parser Class Initialized
INFO - 2021-07-17 12:18:11 --> Form Validation Class Initialized
INFO - 2021-07-17 12:18:11 --> Upload Class Initialized
INFO - 2021-07-17 12:18:11 --> Email Class Initialized
INFO - 2021-07-17 12:18:11 --> MY_Model class loaded
INFO - 2021-07-17 12:18:11 --> Model "Users_model" initialized
INFO - 2021-07-17 12:18:11 --> Model "Settings_model" initialized
INFO - 2021-07-17 12:18:11 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 12:18:11 --> Model "Permissions_model" initialized
INFO - 2021-07-17 12:18:11 --> Model "Roles_model" initialized
INFO - 2021-07-17 12:18:11 --> Model "Activity_model" initialized
INFO - 2021-07-17 12:18:11 --> Model "Templates_model" initialized
INFO - 2021-07-17 12:18:11 --> Database Driver Class Initialized
INFO - 2021-07-17 12:18:11 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 12:18:11 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 12:18:11 --> Controller Class Initialized
ERROR - 2021-07-17 12:18:11 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 12:18:11 --> File loaded: C:\wamp64\www\crm\application\views\settings/company.php
INFO - 2021-07-17 12:18:11 --> Final output sent to browser
DEBUG - 2021-07-17 12:18:11 --> Total execution time: 0.1462
INFO - 2021-07-17 12:18:13 --> Config Class Initialized
INFO - 2021-07-17 12:18:13 --> Hooks Class Initialized
DEBUG - 2021-07-17 12:18:13 --> UTF-8 Support Enabled
INFO - 2021-07-17 12:18:13 --> Utf8 Class Initialized
INFO - 2021-07-17 12:18:13 --> URI Class Initialized
INFO - 2021-07-17 12:18:13 --> Router Class Initialized
INFO - 2021-07-17 12:18:13 --> Output Class Initialized
INFO - 2021-07-17 12:18:13 --> Security Class Initialized
DEBUG - 2021-07-17 12:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 12:18:13 --> Input Class Initialized
INFO - 2021-07-17 12:18:13 --> Language Class Initialized
INFO - 2021-07-17 12:18:13 --> Loader Class Initialized
INFO - 2021-07-17 12:18:13 --> Helper loaded: basic_helper
INFO - 2021-07-17 12:18:13 --> Helper loaded: url_helper
INFO - 2021-07-17 12:18:13 --> Helper loaded: file_helper
INFO - 2021-07-17 12:18:13 --> Helper loaded: form_helper
INFO - 2021-07-17 12:18:13 --> Helper loaded: cookie_helper
INFO - 2021-07-17 12:18:13 --> Helper loaded: security_helper
INFO - 2021-07-17 12:18:13 --> Helper loaded: directory_helper
INFO - 2021-07-17 12:18:13 --> Helper loaded: language_helper
INFO - 2021-07-17 12:18:13 --> Helper loaded: general_helper
INFO - 2021-07-17 12:18:13 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 12:18:13 --> Database Driver Class Initialized
DEBUG - 2021-07-17 12:18:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 12:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 12:18:13 --> Parser Class Initialized
INFO - 2021-07-17 12:18:13 --> Form Validation Class Initialized
INFO - 2021-07-17 12:18:13 --> Upload Class Initialized
INFO - 2021-07-17 12:18:13 --> Email Class Initialized
INFO - 2021-07-17 12:18:13 --> MY_Model class loaded
INFO - 2021-07-17 12:18:13 --> Model "Users_model" initialized
INFO - 2021-07-17 12:18:13 --> Model "Settings_model" initialized
INFO - 2021-07-17 12:18:13 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 12:18:13 --> Model "Permissions_model" initialized
INFO - 2021-07-17 12:18:13 --> Model "Roles_model" initialized
INFO - 2021-07-17 12:18:13 --> Model "Activity_model" initialized
INFO - 2021-07-17 12:18:13 --> Model "Templates_model" initialized
INFO - 2021-07-17 12:18:13 --> Database Driver Class Initialized
INFO - 2021-07-17 12:18:13 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 12:18:13 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 12:18:13 --> Controller Class Initialized
ERROR - 2021-07-17 12:18:13 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 12:18:13 --> File loaded: C:\wamp64\www\crm\application\views\settings/general.php
INFO - 2021-07-17 12:18:13 --> Final output sent to browser
DEBUG - 2021-07-17 12:18:13 --> Total execution time: 0.1927
INFO - 2021-07-17 12:18:25 --> Config Class Initialized
INFO - 2021-07-17 12:18:25 --> Hooks Class Initialized
DEBUG - 2021-07-17 12:18:25 --> UTF-8 Support Enabled
INFO - 2021-07-17 12:18:25 --> Utf8 Class Initialized
INFO - 2021-07-17 12:18:25 --> URI Class Initialized
INFO - 2021-07-17 12:18:25 --> Router Class Initialized
INFO - 2021-07-17 12:18:25 --> Output Class Initialized
INFO - 2021-07-17 12:18:25 --> Security Class Initialized
DEBUG - 2021-07-17 12:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 12:18:25 --> Input Class Initialized
INFO - 2021-07-17 12:18:25 --> Language Class Initialized
INFO - 2021-07-17 12:18:25 --> Loader Class Initialized
INFO - 2021-07-17 12:18:25 --> Helper loaded: basic_helper
INFO - 2021-07-17 12:18:25 --> Helper loaded: url_helper
INFO - 2021-07-17 12:18:25 --> Helper loaded: file_helper
INFO - 2021-07-17 12:18:25 --> Helper loaded: form_helper
INFO - 2021-07-17 12:18:25 --> Helper loaded: cookie_helper
INFO - 2021-07-17 12:18:25 --> Helper loaded: security_helper
INFO - 2021-07-17 12:18:25 --> Helper loaded: directory_helper
INFO - 2021-07-17 12:18:25 --> Helper loaded: language_helper
INFO - 2021-07-17 12:18:25 --> Helper loaded: general_helper
INFO - 2021-07-17 12:18:25 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 12:18:25 --> Database Driver Class Initialized
DEBUG - 2021-07-17 12:18:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 12:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 12:18:25 --> Parser Class Initialized
INFO - 2021-07-17 12:18:25 --> Form Validation Class Initialized
INFO - 2021-07-17 12:18:25 --> Upload Class Initialized
INFO - 2021-07-17 12:18:25 --> Email Class Initialized
INFO - 2021-07-17 12:18:25 --> MY_Model class loaded
INFO - 2021-07-17 12:18:25 --> Model "Users_model" initialized
INFO - 2021-07-17 12:18:25 --> Model "Settings_model" initialized
INFO - 2021-07-17 12:18:25 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 12:18:25 --> Model "Permissions_model" initialized
INFO - 2021-07-17 12:18:25 --> Model "Roles_model" initialized
INFO - 2021-07-17 12:18:25 --> Model "Activity_model" initialized
INFO - 2021-07-17 12:18:25 --> Model "Templates_model" initialized
INFO - 2021-07-17 12:18:25 --> Database Driver Class Initialized
INFO - 2021-07-17 12:18:25 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 12:18:25 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 12:18:25 --> Controller Class Initialized
ERROR - 2021-07-17 12:18:25 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 12:18:25 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 12:18:25 --> Final output sent to browser
DEBUG - 2021-07-17 12:18:25 --> Total execution time: 0.1463
INFO - 2021-07-17 12:19:33 --> Config Class Initialized
INFO - 2021-07-17 12:19:33 --> Hooks Class Initialized
DEBUG - 2021-07-17 12:19:33 --> UTF-8 Support Enabled
INFO - 2021-07-17 12:19:33 --> Utf8 Class Initialized
INFO - 2021-07-17 12:19:33 --> URI Class Initialized
INFO - 2021-07-17 12:19:33 --> Router Class Initialized
INFO - 2021-07-17 12:19:33 --> Output Class Initialized
INFO - 2021-07-17 12:19:33 --> Security Class Initialized
DEBUG - 2021-07-17 12:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 12:19:33 --> Input Class Initialized
INFO - 2021-07-17 12:19:33 --> Language Class Initialized
INFO - 2021-07-17 12:19:33 --> Loader Class Initialized
INFO - 2021-07-17 12:19:33 --> Helper loaded: basic_helper
INFO - 2021-07-17 12:19:33 --> Helper loaded: url_helper
INFO - 2021-07-17 12:19:33 --> Helper loaded: file_helper
INFO - 2021-07-17 12:19:33 --> Helper loaded: form_helper
INFO - 2021-07-17 12:19:33 --> Helper loaded: cookie_helper
INFO - 2021-07-17 12:19:33 --> Helper loaded: security_helper
INFO - 2021-07-17 12:19:33 --> Helper loaded: directory_helper
INFO - 2021-07-17 12:19:33 --> Helper loaded: language_helper
INFO - 2021-07-17 12:19:33 --> Helper loaded: general_helper
INFO - 2021-07-17 12:19:33 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 12:19:33 --> Database Driver Class Initialized
DEBUG - 2021-07-17 12:19:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 12:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 12:19:33 --> Parser Class Initialized
INFO - 2021-07-17 12:19:33 --> Form Validation Class Initialized
INFO - 2021-07-17 12:19:33 --> Upload Class Initialized
INFO - 2021-07-17 12:19:33 --> Email Class Initialized
INFO - 2021-07-17 12:19:33 --> MY_Model class loaded
INFO - 2021-07-17 12:19:33 --> Model "Users_model" initialized
INFO - 2021-07-17 12:19:33 --> Model "Settings_model" initialized
INFO - 2021-07-17 12:19:33 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 12:19:33 --> Model "Permissions_model" initialized
INFO - 2021-07-17 12:19:33 --> Model "Roles_model" initialized
INFO - 2021-07-17 12:19:33 --> Model "Activity_model" initialized
INFO - 2021-07-17 12:19:33 --> Model "Templates_model" initialized
INFO - 2021-07-17 12:19:33 --> Database Driver Class Initialized
INFO - 2021-07-17 12:19:33 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 12:19:33 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 12:19:33 --> Controller Class Initialized
ERROR - 2021-07-17 12:19:33 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 12:19:33 --> File loaded: C:\wamp64\www\crm\application\views\settings/general.php
INFO - 2021-07-17 12:19:33 --> Final output sent to browser
DEBUG - 2021-07-17 12:19:33 --> Total execution time: 0.2488
INFO - 2021-07-17 12:19:45 --> Config Class Initialized
INFO - 2021-07-17 12:19:45 --> Hooks Class Initialized
DEBUG - 2021-07-17 12:19:45 --> UTF-8 Support Enabled
INFO - 2021-07-17 12:19:45 --> Utf8 Class Initialized
INFO - 2021-07-17 12:19:45 --> URI Class Initialized
INFO - 2021-07-17 12:19:45 --> Router Class Initialized
INFO - 2021-07-17 12:19:45 --> Output Class Initialized
INFO - 2021-07-17 12:19:45 --> Security Class Initialized
DEBUG - 2021-07-17 12:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 12:19:45 --> Input Class Initialized
INFO - 2021-07-17 12:19:45 --> Language Class Initialized
INFO - 2021-07-17 12:19:45 --> Loader Class Initialized
INFO - 2021-07-17 12:19:45 --> Helper loaded: basic_helper
INFO - 2021-07-17 12:19:45 --> Helper loaded: url_helper
INFO - 2021-07-17 12:19:45 --> Helper loaded: file_helper
INFO - 2021-07-17 12:19:45 --> Helper loaded: form_helper
INFO - 2021-07-17 12:19:45 --> Helper loaded: cookie_helper
INFO - 2021-07-17 12:19:45 --> Helper loaded: security_helper
INFO - 2021-07-17 12:19:45 --> Helper loaded: directory_helper
INFO - 2021-07-17 12:19:45 --> Helper loaded: language_helper
INFO - 2021-07-17 12:19:45 --> Helper loaded: general_helper
INFO - 2021-07-17 12:19:45 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 12:19:45 --> Database Driver Class Initialized
DEBUG - 2021-07-17 12:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 12:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 12:19:45 --> Parser Class Initialized
INFO - 2021-07-17 12:19:45 --> Form Validation Class Initialized
INFO - 2021-07-17 12:19:45 --> Upload Class Initialized
INFO - 2021-07-17 12:19:45 --> Email Class Initialized
INFO - 2021-07-17 12:19:45 --> MY_Model class loaded
INFO - 2021-07-17 12:19:45 --> Model "Users_model" initialized
INFO - 2021-07-17 12:19:45 --> Model "Settings_model" initialized
INFO - 2021-07-17 12:19:45 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 12:19:45 --> Model "Permissions_model" initialized
INFO - 2021-07-17 12:19:45 --> Model "Roles_model" initialized
INFO - 2021-07-17 12:19:45 --> Model "Activity_model" initialized
INFO - 2021-07-17 12:19:45 --> Model "Templates_model" initialized
INFO - 2021-07-17 12:19:45 --> Database Driver Class Initialized
INFO - 2021-07-17 12:19:45 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 12:19:45 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 12:19:45 --> Controller Class Initialized
ERROR - 2021-07-17 12:19:45 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 12:19:45 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 12:19:45 --> Final output sent to browser
DEBUG - 2021-07-17 12:19:45 --> Total execution time: 0.1268
INFO - 2021-07-17 12:21:03 --> Config Class Initialized
INFO - 2021-07-17 12:21:03 --> Hooks Class Initialized
DEBUG - 2021-07-17 12:21:03 --> UTF-8 Support Enabled
INFO - 2021-07-17 12:21:03 --> Utf8 Class Initialized
INFO - 2021-07-17 12:21:03 --> URI Class Initialized
INFO - 2021-07-17 12:21:03 --> Router Class Initialized
INFO - 2021-07-17 12:21:03 --> Output Class Initialized
INFO - 2021-07-17 12:21:03 --> Security Class Initialized
DEBUG - 2021-07-17 12:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 12:21:03 --> Input Class Initialized
INFO - 2021-07-17 12:21:03 --> Language Class Initialized
INFO - 2021-07-17 12:21:03 --> Loader Class Initialized
INFO - 2021-07-17 12:21:03 --> Helper loaded: basic_helper
INFO - 2021-07-17 12:21:03 --> Helper loaded: url_helper
INFO - 2021-07-17 12:21:03 --> Helper loaded: file_helper
INFO - 2021-07-17 12:21:03 --> Helper loaded: form_helper
INFO - 2021-07-17 12:21:03 --> Helper loaded: cookie_helper
INFO - 2021-07-17 12:21:03 --> Helper loaded: security_helper
INFO - 2021-07-17 12:21:03 --> Helper loaded: directory_helper
INFO - 2021-07-17 12:21:03 --> Helper loaded: language_helper
INFO - 2021-07-17 12:21:03 --> Helper loaded: general_helper
INFO - 2021-07-17 12:21:03 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 12:21:03 --> Database Driver Class Initialized
DEBUG - 2021-07-17 12:21:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 12:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 12:21:03 --> Parser Class Initialized
INFO - 2021-07-17 12:21:03 --> Form Validation Class Initialized
INFO - 2021-07-17 12:21:03 --> Upload Class Initialized
INFO - 2021-07-17 12:21:03 --> Email Class Initialized
INFO - 2021-07-17 12:21:03 --> MY_Model class loaded
INFO - 2021-07-17 12:21:03 --> Model "Users_model" initialized
INFO - 2021-07-17 12:21:03 --> Model "Settings_model" initialized
INFO - 2021-07-17 12:21:03 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 12:21:03 --> Model "Permissions_model" initialized
INFO - 2021-07-17 12:21:03 --> Model "Roles_model" initialized
INFO - 2021-07-17 12:21:03 --> Model "Activity_model" initialized
INFO - 2021-07-17 12:21:03 --> Model "Templates_model" initialized
INFO - 2021-07-17 12:21:03 --> Database Driver Class Initialized
INFO - 2021-07-17 12:21:04 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 12:21:04 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 12:21:04 --> Controller Class Initialized
ERROR - 2021-07-17 12:21:04 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 12:21:04 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 12:21:04 --> Final output sent to browser
DEBUG - 2021-07-17 12:21:04 --> Total execution time: 0.5417
INFO - 2021-07-17 12:29:12 --> Config Class Initialized
INFO - 2021-07-17 12:29:12 --> Hooks Class Initialized
DEBUG - 2021-07-17 12:29:12 --> UTF-8 Support Enabled
INFO - 2021-07-17 12:29:12 --> Utf8 Class Initialized
INFO - 2021-07-17 12:29:12 --> URI Class Initialized
INFO - 2021-07-17 12:29:12 --> Router Class Initialized
INFO - 2021-07-17 12:29:13 --> Output Class Initialized
INFO - 2021-07-17 12:29:13 --> Security Class Initialized
DEBUG - 2021-07-17 12:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 12:29:13 --> Input Class Initialized
INFO - 2021-07-17 12:29:13 --> Language Class Initialized
INFO - 2021-07-17 12:29:13 --> Loader Class Initialized
INFO - 2021-07-17 12:29:13 --> Helper loaded: basic_helper
INFO - 2021-07-17 12:29:13 --> Helper loaded: url_helper
INFO - 2021-07-17 12:29:13 --> Helper loaded: file_helper
INFO - 2021-07-17 12:29:13 --> Helper loaded: form_helper
INFO - 2021-07-17 12:29:13 --> Helper loaded: cookie_helper
INFO - 2021-07-17 12:29:13 --> Helper loaded: security_helper
INFO - 2021-07-17 12:29:13 --> Helper loaded: directory_helper
INFO - 2021-07-17 12:29:13 --> Helper loaded: language_helper
INFO - 2021-07-17 12:29:13 --> Helper loaded: general_helper
INFO - 2021-07-17 12:29:13 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 12:29:13 --> Database Driver Class Initialized
DEBUG - 2021-07-17 12:29:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 12:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 12:29:13 --> Parser Class Initialized
INFO - 2021-07-17 12:29:13 --> Form Validation Class Initialized
INFO - 2021-07-17 12:29:13 --> Upload Class Initialized
INFO - 2021-07-17 12:29:13 --> Email Class Initialized
INFO - 2021-07-17 12:29:13 --> MY_Model class loaded
INFO - 2021-07-17 12:29:13 --> Model "Users_model" initialized
INFO - 2021-07-17 12:29:13 --> Model "Settings_model" initialized
INFO - 2021-07-17 12:29:13 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 12:29:13 --> Model "Permissions_model" initialized
INFO - 2021-07-17 12:29:13 --> Model "Roles_model" initialized
INFO - 2021-07-17 12:29:13 --> Model "Activity_model" initialized
INFO - 2021-07-17 12:29:13 --> Model "Templates_model" initialized
INFO - 2021-07-17 12:29:13 --> Database Driver Class Initialized
INFO - 2021-07-17 12:29:13 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 12:29:13 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 12:29:13 --> Controller Class Initialized
ERROR - 2021-07-17 12:29:13 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 12:29:13 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 12:29:13 --> Final output sent to browser
DEBUG - 2021-07-17 12:29:13 --> Total execution time: 0.1326
INFO - 2021-07-17 12:29:45 --> Config Class Initialized
INFO - 2021-07-17 12:29:45 --> Hooks Class Initialized
DEBUG - 2021-07-17 12:29:45 --> UTF-8 Support Enabled
INFO - 2021-07-17 12:29:45 --> Utf8 Class Initialized
INFO - 2021-07-17 12:29:45 --> URI Class Initialized
INFO - 2021-07-17 12:29:45 --> Router Class Initialized
INFO - 2021-07-17 12:29:45 --> Output Class Initialized
INFO - 2021-07-17 12:29:45 --> Security Class Initialized
DEBUG - 2021-07-17 12:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 12:29:45 --> Input Class Initialized
INFO - 2021-07-17 12:29:45 --> Language Class Initialized
INFO - 2021-07-17 12:29:45 --> Loader Class Initialized
INFO - 2021-07-17 12:29:45 --> Helper loaded: basic_helper
INFO - 2021-07-17 12:29:45 --> Helper loaded: url_helper
INFO - 2021-07-17 12:29:45 --> Helper loaded: file_helper
INFO - 2021-07-17 12:29:45 --> Helper loaded: form_helper
INFO - 2021-07-17 12:29:45 --> Helper loaded: cookie_helper
INFO - 2021-07-17 12:29:45 --> Helper loaded: security_helper
INFO - 2021-07-17 12:29:45 --> Helper loaded: directory_helper
INFO - 2021-07-17 12:29:45 --> Helper loaded: language_helper
INFO - 2021-07-17 12:29:45 --> Helper loaded: general_helper
INFO - 2021-07-17 12:29:45 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 12:29:45 --> Database Driver Class Initialized
DEBUG - 2021-07-17 12:29:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 12:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 12:29:45 --> Parser Class Initialized
INFO - 2021-07-17 12:29:45 --> Form Validation Class Initialized
INFO - 2021-07-17 12:29:45 --> Upload Class Initialized
INFO - 2021-07-17 12:29:45 --> Email Class Initialized
INFO - 2021-07-17 12:29:45 --> MY_Model class loaded
INFO - 2021-07-17 12:29:45 --> Model "Users_model" initialized
INFO - 2021-07-17 12:29:45 --> Model "Settings_model" initialized
INFO - 2021-07-17 12:29:45 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 12:29:45 --> Model "Permissions_model" initialized
INFO - 2021-07-17 12:29:45 --> Model "Roles_model" initialized
INFO - 2021-07-17 12:29:45 --> Model "Activity_model" initialized
INFO - 2021-07-17 12:29:45 --> Model "Templates_model" initialized
INFO - 2021-07-17 12:29:45 --> Database Driver Class Initialized
INFO - 2021-07-17 12:29:45 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 12:29:45 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 12:29:45 --> Controller Class Initialized
ERROR - 2021-07-17 12:29:45 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 12:29:45 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 12:29:45 --> Config Class Initialized
INFO - 2021-07-17 12:29:45 --> Hooks Class Initialized
DEBUG - 2021-07-17 12:29:45 --> UTF-8 Support Enabled
INFO - 2021-07-17 12:29:45 --> Utf8 Class Initialized
INFO - 2021-07-17 12:29:45 --> URI Class Initialized
INFO - 2021-07-17 12:29:45 --> Router Class Initialized
INFO - 2021-07-17 12:29:45 --> Output Class Initialized
INFO - 2021-07-17 12:29:45 --> Security Class Initialized
DEBUG - 2021-07-17 12:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 12:29:45 --> Input Class Initialized
INFO - 2021-07-17 12:29:45 --> Language Class Initialized
INFO - 2021-07-17 12:29:45 --> Loader Class Initialized
INFO - 2021-07-17 12:29:45 --> Helper loaded: basic_helper
INFO - 2021-07-17 12:29:45 --> Helper loaded: url_helper
INFO - 2021-07-17 12:29:45 --> Helper loaded: file_helper
INFO - 2021-07-17 12:29:45 --> Helper loaded: form_helper
INFO - 2021-07-17 12:29:45 --> Helper loaded: cookie_helper
INFO - 2021-07-17 12:29:45 --> Helper loaded: security_helper
INFO - 2021-07-17 12:29:45 --> Helper loaded: directory_helper
INFO - 2021-07-17 12:29:45 --> Helper loaded: language_helper
INFO - 2021-07-17 12:29:45 --> Helper loaded: general_helper
INFO - 2021-07-17 12:29:45 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 12:29:45 --> Database Driver Class Initialized
DEBUG - 2021-07-17 12:29:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 12:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 12:29:45 --> Parser Class Initialized
INFO - 2021-07-17 12:29:45 --> Form Validation Class Initialized
INFO - 2021-07-17 12:29:45 --> Upload Class Initialized
INFO - 2021-07-17 12:29:45 --> Email Class Initialized
INFO - 2021-07-17 12:29:45 --> MY_Model class loaded
INFO - 2021-07-17 12:29:45 --> Model "Users_model" initialized
INFO - 2021-07-17 12:29:45 --> Model "Settings_model" initialized
INFO - 2021-07-17 12:29:45 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 12:29:45 --> Model "Permissions_model" initialized
INFO - 2021-07-17 12:29:45 --> Model "Roles_model" initialized
INFO - 2021-07-17 12:29:45 --> Model "Activity_model" initialized
INFO - 2021-07-17 12:29:45 --> Model "Templates_model" initialized
INFO - 2021-07-17 12:29:45 --> Database Driver Class Initialized
INFO - 2021-07-17 12:29:45 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 12:29:45 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 12:29:45 --> Controller Class Initialized
ERROR - 2021-07-17 12:29:45 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 12:29:45 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 12:29:45 --> Final output sent to browser
DEBUG - 2021-07-17 12:29:45 --> Total execution time: 0.0651
INFO - 2021-07-17 12:29:52 --> Config Class Initialized
INFO - 2021-07-17 12:29:52 --> Hooks Class Initialized
DEBUG - 2021-07-17 12:29:52 --> UTF-8 Support Enabled
INFO - 2021-07-17 12:29:52 --> Utf8 Class Initialized
INFO - 2021-07-17 12:29:52 --> URI Class Initialized
INFO - 2021-07-17 12:29:52 --> Router Class Initialized
INFO - 2021-07-17 12:29:52 --> Output Class Initialized
INFO - 2021-07-17 12:29:52 --> Security Class Initialized
DEBUG - 2021-07-17 12:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 12:29:52 --> Input Class Initialized
INFO - 2021-07-17 12:29:52 --> Language Class Initialized
ERROR - 2021-07-17 12:29:52 --> 404 Page Not Found: DevMgmt/DiscoveryTree.xml
INFO - 2021-07-17 12:30:09 --> Config Class Initialized
INFO - 2021-07-17 12:30:09 --> Hooks Class Initialized
DEBUG - 2021-07-17 12:30:09 --> UTF-8 Support Enabled
INFO - 2021-07-17 12:30:09 --> Utf8 Class Initialized
INFO - 2021-07-17 12:30:09 --> URI Class Initialized
INFO - 2021-07-17 12:30:09 --> Router Class Initialized
INFO - 2021-07-17 12:30:09 --> Output Class Initialized
INFO - 2021-07-17 12:30:09 --> Security Class Initialized
DEBUG - 2021-07-17 12:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 12:30:09 --> Input Class Initialized
INFO - 2021-07-17 12:30:09 --> Language Class Initialized
INFO - 2021-07-17 12:30:09 --> Loader Class Initialized
INFO - 2021-07-17 12:30:09 --> Helper loaded: basic_helper
INFO - 2021-07-17 12:30:09 --> Helper loaded: url_helper
INFO - 2021-07-17 12:30:09 --> Helper loaded: file_helper
INFO - 2021-07-17 12:30:09 --> Helper loaded: form_helper
INFO - 2021-07-17 12:30:09 --> Helper loaded: cookie_helper
INFO - 2021-07-17 12:30:09 --> Helper loaded: security_helper
INFO - 2021-07-17 12:30:09 --> Helper loaded: directory_helper
INFO - 2021-07-17 12:30:09 --> Helper loaded: language_helper
INFO - 2021-07-17 12:30:09 --> Helper loaded: general_helper
INFO - 2021-07-17 12:30:09 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 12:30:09 --> Database Driver Class Initialized
DEBUG - 2021-07-17 12:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 12:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 12:30:09 --> Parser Class Initialized
INFO - 2021-07-17 12:30:09 --> Form Validation Class Initialized
INFO - 2021-07-17 12:30:09 --> Upload Class Initialized
INFO - 2021-07-17 12:30:09 --> Email Class Initialized
INFO - 2021-07-17 12:30:09 --> MY_Model class loaded
INFO - 2021-07-17 12:30:09 --> Model "Users_model" initialized
INFO - 2021-07-17 12:30:09 --> Model "Settings_model" initialized
INFO - 2021-07-17 12:30:09 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 12:30:09 --> Model "Permissions_model" initialized
INFO - 2021-07-17 12:30:09 --> Model "Roles_model" initialized
INFO - 2021-07-17 12:30:09 --> Model "Activity_model" initialized
INFO - 2021-07-17 12:30:09 --> Model "Templates_model" initialized
INFO - 2021-07-17 12:30:09 --> Database Driver Class Initialized
INFO - 2021-07-17 12:30:09 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 12:30:09 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 12:30:09 --> Controller Class Initialized
ERROR - 2021-07-17 12:30:09 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 12:30:09 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 12:30:09 --> Config Class Initialized
INFO - 2021-07-17 12:30:09 --> Hooks Class Initialized
DEBUG - 2021-07-17 12:30:09 --> UTF-8 Support Enabled
INFO - 2021-07-17 12:30:09 --> Utf8 Class Initialized
INFO - 2021-07-17 12:30:09 --> URI Class Initialized
INFO - 2021-07-17 12:30:09 --> Router Class Initialized
INFO - 2021-07-17 12:30:09 --> Output Class Initialized
INFO - 2021-07-17 12:30:09 --> Security Class Initialized
DEBUG - 2021-07-17 12:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 12:30:09 --> Input Class Initialized
INFO - 2021-07-17 12:30:09 --> Language Class Initialized
INFO - 2021-07-17 12:30:09 --> Loader Class Initialized
INFO - 2021-07-17 12:30:09 --> Helper loaded: basic_helper
INFO - 2021-07-17 12:30:09 --> Helper loaded: url_helper
INFO - 2021-07-17 12:30:09 --> Helper loaded: file_helper
INFO - 2021-07-17 12:30:09 --> Helper loaded: form_helper
INFO - 2021-07-17 12:30:09 --> Helper loaded: cookie_helper
INFO - 2021-07-17 12:30:09 --> Helper loaded: security_helper
INFO - 2021-07-17 12:30:09 --> Helper loaded: directory_helper
INFO - 2021-07-17 12:30:09 --> Helper loaded: language_helper
INFO - 2021-07-17 12:30:09 --> Helper loaded: general_helper
INFO - 2021-07-17 12:30:09 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 12:30:09 --> Database Driver Class Initialized
DEBUG - 2021-07-17 12:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 12:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 12:30:09 --> Parser Class Initialized
INFO - 2021-07-17 12:30:09 --> Form Validation Class Initialized
INFO - 2021-07-17 12:30:09 --> Upload Class Initialized
INFO - 2021-07-17 12:30:09 --> Email Class Initialized
INFO - 2021-07-17 12:30:09 --> MY_Model class loaded
INFO - 2021-07-17 12:30:09 --> Model "Users_model" initialized
INFO - 2021-07-17 12:30:09 --> Model "Settings_model" initialized
INFO - 2021-07-17 12:30:09 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 12:30:09 --> Model "Permissions_model" initialized
INFO - 2021-07-17 12:30:09 --> Model "Roles_model" initialized
INFO - 2021-07-17 12:30:09 --> Model "Activity_model" initialized
INFO - 2021-07-17 12:30:09 --> Model "Templates_model" initialized
INFO - 2021-07-17 12:30:09 --> Database Driver Class Initialized
INFO - 2021-07-17 12:30:09 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 12:30:09 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 12:30:09 --> Controller Class Initialized
ERROR - 2021-07-17 12:30:09 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 12:30:09 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 12:30:09 --> Final output sent to browser
DEBUG - 2021-07-17 12:30:09 --> Total execution time: 0.0765
INFO - 2021-07-17 12:31:39 --> Config Class Initialized
INFO - 2021-07-17 12:31:39 --> Hooks Class Initialized
DEBUG - 2021-07-17 12:31:39 --> UTF-8 Support Enabled
INFO - 2021-07-17 12:31:39 --> Utf8 Class Initialized
INFO - 2021-07-17 12:31:39 --> URI Class Initialized
INFO - 2021-07-17 12:31:39 --> Router Class Initialized
INFO - 2021-07-17 12:31:39 --> Output Class Initialized
INFO - 2021-07-17 12:31:39 --> Security Class Initialized
DEBUG - 2021-07-17 12:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 12:31:39 --> Input Class Initialized
INFO - 2021-07-17 12:31:39 --> Language Class Initialized
INFO - 2021-07-17 12:31:39 --> Loader Class Initialized
INFO - 2021-07-17 12:31:39 --> Helper loaded: basic_helper
INFO - 2021-07-17 12:31:39 --> Helper loaded: url_helper
INFO - 2021-07-17 12:31:39 --> Helper loaded: file_helper
INFO - 2021-07-17 12:31:39 --> Helper loaded: form_helper
INFO - 2021-07-17 12:31:39 --> Helper loaded: cookie_helper
INFO - 2021-07-17 12:31:39 --> Helper loaded: security_helper
INFO - 2021-07-17 12:31:39 --> Helper loaded: directory_helper
INFO - 2021-07-17 12:31:39 --> Helper loaded: language_helper
INFO - 2021-07-17 12:31:39 --> Helper loaded: general_helper
INFO - 2021-07-17 12:31:39 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 12:31:39 --> Database Driver Class Initialized
DEBUG - 2021-07-17 12:31:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 12:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 12:31:39 --> Parser Class Initialized
INFO - 2021-07-17 12:31:39 --> Form Validation Class Initialized
INFO - 2021-07-17 12:31:39 --> Upload Class Initialized
INFO - 2021-07-17 12:31:39 --> Email Class Initialized
INFO - 2021-07-17 12:31:39 --> MY_Model class loaded
INFO - 2021-07-17 12:31:39 --> Model "Users_model" initialized
INFO - 2021-07-17 12:31:39 --> Model "Settings_model" initialized
INFO - 2021-07-17 12:31:39 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 12:31:39 --> Model "Permissions_model" initialized
INFO - 2021-07-17 12:31:39 --> Model "Roles_model" initialized
INFO - 2021-07-17 12:31:39 --> Model "Activity_model" initialized
INFO - 2021-07-17 12:31:39 --> Model "Templates_model" initialized
INFO - 2021-07-17 12:31:39 --> Database Driver Class Initialized
INFO - 2021-07-17 12:31:39 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 12:31:39 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 12:31:39 --> Controller Class Initialized
ERROR - 2021-07-17 12:31:39 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 12:31:39 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 12:31:39 --> Final output sent to browser
DEBUG - 2021-07-17 12:31:39 --> Total execution time: 0.5433
INFO - 2021-07-17 12:45:55 --> Config Class Initialized
INFO - 2021-07-17 12:45:55 --> Hooks Class Initialized
DEBUG - 2021-07-17 12:45:55 --> UTF-8 Support Enabled
INFO - 2021-07-17 12:45:55 --> Utf8 Class Initialized
INFO - 2021-07-17 12:45:55 --> URI Class Initialized
INFO - 2021-07-17 12:45:55 --> Router Class Initialized
INFO - 2021-07-17 12:45:55 --> Output Class Initialized
INFO - 2021-07-17 12:45:55 --> Security Class Initialized
DEBUG - 2021-07-17 12:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 12:45:55 --> Input Class Initialized
INFO - 2021-07-17 12:45:55 --> Language Class Initialized
INFO - 2021-07-17 12:45:55 --> Loader Class Initialized
INFO - 2021-07-17 12:45:55 --> Helper loaded: basic_helper
INFO - 2021-07-17 12:45:55 --> Helper loaded: url_helper
INFO - 2021-07-17 12:45:55 --> Helper loaded: file_helper
INFO - 2021-07-17 12:45:55 --> Helper loaded: form_helper
INFO - 2021-07-17 12:45:55 --> Helper loaded: cookie_helper
INFO - 2021-07-17 12:45:55 --> Helper loaded: security_helper
INFO - 2021-07-17 12:45:55 --> Helper loaded: directory_helper
INFO - 2021-07-17 12:45:55 --> Helper loaded: language_helper
INFO - 2021-07-17 12:45:55 --> Helper loaded: general_helper
INFO - 2021-07-17 12:45:55 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 12:45:55 --> Database Driver Class Initialized
DEBUG - 2021-07-17 12:45:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 12:45:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 12:45:55 --> Parser Class Initialized
INFO - 2021-07-17 12:45:55 --> Form Validation Class Initialized
INFO - 2021-07-17 12:45:55 --> Upload Class Initialized
INFO - 2021-07-17 12:45:55 --> Email Class Initialized
INFO - 2021-07-17 12:45:55 --> MY_Model class loaded
INFO - 2021-07-17 12:45:55 --> Model "Users_model" initialized
INFO - 2021-07-17 12:45:55 --> Model "Settings_model" initialized
INFO - 2021-07-17 12:45:55 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 12:45:55 --> Model "Permissions_model" initialized
INFO - 2021-07-17 12:45:55 --> Model "Roles_model" initialized
INFO - 2021-07-17 12:45:55 --> Model "Activity_model" initialized
INFO - 2021-07-17 12:45:55 --> Model "Templates_model" initialized
INFO - 2021-07-17 12:45:55 --> Database Driver Class Initialized
INFO - 2021-07-17 12:45:55 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 12:45:55 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 12:45:55 --> Controller Class Initialized
ERROR - 2021-07-17 12:45:55 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 12:45:55 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 12:45:55 --> Final output sent to browser
DEBUG - 2021-07-17 12:45:55 --> Total execution time: 0.1300
INFO - 2021-07-17 12:47:06 --> Config Class Initialized
INFO - 2021-07-17 12:47:06 --> Hooks Class Initialized
DEBUG - 2021-07-17 12:47:06 --> UTF-8 Support Enabled
INFO - 2021-07-17 12:47:06 --> Utf8 Class Initialized
INFO - 2021-07-17 12:47:06 --> URI Class Initialized
INFO - 2021-07-17 12:47:06 --> Router Class Initialized
INFO - 2021-07-17 12:47:06 --> Output Class Initialized
INFO - 2021-07-17 12:47:06 --> Security Class Initialized
DEBUG - 2021-07-17 12:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 12:47:06 --> Input Class Initialized
INFO - 2021-07-17 12:47:06 --> Language Class Initialized
INFO - 2021-07-17 12:47:06 --> Loader Class Initialized
INFO - 2021-07-17 12:47:06 --> Helper loaded: basic_helper
INFO - 2021-07-17 12:47:06 --> Helper loaded: url_helper
INFO - 2021-07-17 12:47:06 --> Helper loaded: file_helper
INFO - 2021-07-17 12:47:06 --> Helper loaded: form_helper
INFO - 2021-07-17 12:47:06 --> Helper loaded: cookie_helper
INFO - 2021-07-17 12:47:06 --> Helper loaded: security_helper
INFO - 2021-07-17 12:47:06 --> Helper loaded: directory_helper
INFO - 2021-07-17 12:47:06 --> Helper loaded: language_helper
INFO - 2021-07-17 12:47:06 --> Helper loaded: general_helper
INFO - 2021-07-17 12:47:06 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 12:47:06 --> Database Driver Class Initialized
DEBUG - 2021-07-17 12:47:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 12:47:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 12:47:06 --> Parser Class Initialized
INFO - 2021-07-17 12:47:06 --> Form Validation Class Initialized
INFO - 2021-07-17 12:47:06 --> Upload Class Initialized
INFO - 2021-07-17 12:47:06 --> Email Class Initialized
INFO - 2021-07-17 12:47:06 --> MY_Model class loaded
INFO - 2021-07-17 12:47:06 --> Model "Users_model" initialized
INFO - 2021-07-17 12:47:06 --> Model "Settings_model" initialized
INFO - 2021-07-17 12:47:06 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 12:47:06 --> Model "Permissions_model" initialized
INFO - 2021-07-17 12:47:06 --> Model "Roles_model" initialized
INFO - 2021-07-17 12:47:06 --> Model "Activity_model" initialized
INFO - 2021-07-17 12:47:06 --> Model "Templates_model" initialized
INFO - 2021-07-17 12:47:06 --> Database Driver Class Initialized
INFO - 2021-07-17 12:47:07 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 12:47:07 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 12:47:07 --> Controller Class Initialized
ERROR - 2021-07-17 12:47:07 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 12:47:07 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 12:47:07 --> Final output sent to browser
DEBUG - 2021-07-17 12:47:07 --> Total execution time: 0.5770
INFO - 2021-07-17 12:50:23 --> Config Class Initialized
INFO - 2021-07-17 12:50:23 --> Hooks Class Initialized
DEBUG - 2021-07-17 12:50:23 --> UTF-8 Support Enabled
INFO - 2021-07-17 12:50:23 --> Utf8 Class Initialized
INFO - 2021-07-17 12:50:23 --> URI Class Initialized
DEBUG - 2021-07-17 12:50:23 --> No URI present. Default controller set.
INFO - 2021-07-17 12:50:23 --> Router Class Initialized
INFO - 2021-07-17 12:50:23 --> Output Class Initialized
INFO - 2021-07-17 12:50:23 --> Security Class Initialized
DEBUG - 2021-07-17 12:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 12:50:23 --> Input Class Initialized
INFO - 2021-07-17 12:50:23 --> Language Class Initialized
INFO - 2021-07-17 12:50:23 --> Loader Class Initialized
INFO - 2021-07-17 12:50:23 --> Helper loaded: basic_helper
INFO - 2021-07-17 12:50:23 --> Helper loaded: url_helper
INFO - 2021-07-17 12:50:23 --> Helper loaded: file_helper
INFO - 2021-07-17 12:50:23 --> Helper loaded: form_helper
INFO - 2021-07-17 12:50:23 --> Helper loaded: cookie_helper
INFO - 2021-07-17 12:50:23 --> Helper loaded: security_helper
INFO - 2021-07-17 12:50:23 --> Helper loaded: directory_helper
INFO - 2021-07-17 12:50:23 --> Helper loaded: language_helper
INFO - 2021-07-17 12:50:23 --> Helper loaded: general_helper
INFO - 2021-07-17 12:50:23 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 12:50:23 --> Database Driver Class Initialized
DEBUG - 2021-07-17 12:50:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 12:50:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 12:50:23 --> Parser Class Initialized
INFO - 2021-07-17 12:50:23 --> Form Validation Class Initialized
INFO - 2021-07-17 12:50:23 --> Upload Class Initialized
INFO - 2021-07-17 12:50:23 --> Email Class Initialized
INFO - 2021-07-17 12:50:23 --> MY_Model class loaded
INFO - 2021-07-17 12:50:23 --> Model "Users_model" initialized
INFO - 2021-07-17 12:50:23 --> Model "Settings_model" initialized
INFO - 2021-07-17 12:50:23 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 12:50:23 --> Model "Permissions_model" initialized
INFO - 2021-07-17 12:50:23 --> Model "Roles_model" initialized
INFO - 2021-07-17 12:50:23 --> Model "Activity_model" initialized
INFO - 2021-07-17 12:50:23 --> Model "Templates_model" initialized
INFO - 2021-07-17 12:50:23 --> Database Driver Class Initialized
INFO - 2021-07-17 12:50:24 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 12:50:24 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 12:50:24 --> Controller Class Initialized
INFO - 2021-07-17 13:41:01 --> Config Class Initialized
INFO - 2021-07-17 13:41:01 --> Hooks Class Initialized
DEBUG - 2021-07-17 13:41:01 --> UTF-8 Support Enabled
INFO - 2021-07-17 13:41:01 --> Utf8 Class Initialized
INFO - 2021-07-17 13:41:01 --> URI Class Initialized
INFO - 2021-07-17 13:41:01 --> Router Class Initialized
INFO - 2021-07-17 13:41:01 --> Output Class Initialized
INFO - 2021-07-17 13:41:01 --> Security Class Initialized
DEBUG - 2021-07-17 13:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 13:41:01 --> Input Class Initialized
INFO - 2021-07-17 13:41:01 --> Language Class Initialized
INFO - 2021-07-17 13:41:01 --> Loader Class Initialized
INFO - 2021-07-17 13:41:01 --> Helper loaded: basic_helper
INFO - 2021-07-17 13:41:01 --> Helper loaded: url_helper
INFO - 2021-07-17 13:41:01 --> Helper loaded: file_helper
INFO - 2021-07-17 13:41:01 --> Helper loaded: form_helper
INFO - 2021-07-17 13:41:01 --> Helper loaded: cookie_helper
INFO - 2021-07-17 13:41:01 --> Helper loaded: security_helper
INFO - 2021-07-17 13:41:01 --> Helper loaded: directory_helper
INFO - 2021-07-17 13:41:01 --> Helper loaded: language_helper
INFO - 2021-07-17 13:41:01 --> Helper loaded: general_helper
INFO - 2021-07-17 13:41:01 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 13:41:01 --> Database Driver Class Initialized
DEBUG - 2021-07-17 13:41:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 13:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 13:41:01 --> Parser Class Initialized
INFO - 2021-07-17 13:41:01 --> Form Validation Class Initialized
INFO - 2021-07-17 13:41:01 --> Upload Class Initialized
INFO - 2021-07-17 13:41:01 --> Email Class Initialized
INFO - 2021-07-17 13:41:01 --> MY_Model class loaded
INFO - 2021-07-17 13:41:01 --> Model "Users_model" initialized
INFO - 2021-07-17 13:41:01 --> Model "Settings_model" initialized
INFO - 2021-07-17 13:41:01 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 13:41:01 --> Model "Permissions_model" initialized
INFO - 2021-07-17 13:41:01 --> Model "Roles_model" initialized
INFO - 2021-07-17 13:41:01 --> Model "Activity_model" initialized
INFO - 2021-07-17 13:41:01 --> Model "Templates_model" initialized
INFO - 2021-07-17 13:41:01 --> Database Driver Class Initialized
INFO - 2021-07-17 13:41:01 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 13:41:01 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 13:41:01 --> Controller Class Initialized
ERROR - 2021-07-17 13:41:01 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 13:41:01 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-17 13:41:01 --> Final output sent to browser
DEBUG - 2021-07-17 13:41:01 --> Total execution time: 0.1296
INFO - 2021-07-17 13:42:22 --> Config Class Initialized
INFO - 2021-07-17 13:42:22 --> Hooks Class Initialized
DEBUG - 2021-07-17 13:42:22 --> UTF-8 Support Enabled
INFO - 2021-07-17 13:42:22 --> Utf8 Class Initialized
INFO - 2021-07-17 13:42:22 --> URI Class Initialized
INFO - 2021-07-17 13:42:22 --> Router Class Initialized
INFO - 2021-07-17 13:42:22 --> Output Class Initialized
INFO - 2021-07-17 13:42:22 --> Security Class Initialized
DEBUG - 2021-07-17 13:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 13:42:22 --> Input Class Initialized
INFO - 2021-07-17 13:42:22 --> Language Class Initialized
INFO - 2021-07-17 13:42:22 --> Loader Class Initialized
INFO - 2021-07-17 13:42:22 --> Helper loaded: basic_helper
INFO - 2021-07-17 13:42:22 --> Helper loaded: url_helper
INFO - 2021-07-17 13:42:22 --> Helper loaded: file_helper
INFO - 2021-07-17 13:42:22 --> Helper loaded: form_helper
INFO - 2021-07-17 13:42:22 --> Helper loaded: cookie_helper
INFO - 2021-07-17 13:42:22 --> Helper loaded: security_helper
INFO - 2021-07-17 13:42:22 --> Helper loaded: directory_helper
INFO - 2021-07-17 13:42:22 --> Helper loaded: language_helper
INFO - 2021-07-17 13:42:22 --> Helper loaded: general_helper
INFO - 2021-07-17 13:42:22 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 13:42:22 --> Database Driver Class Initialized
DEBUG - 2021-07-17 13:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 13:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 13:42:22 --> Parser Class Initialized
INFO - 2021-07-17 13:42:22 --> Form Validation Class Initialized
INFO - 2021-07-17 13:42:22 --> Upload Class Initialized
INFO - 2021-07-17 13:42:22 --> Email Class Initialized
INFO - 2021-07-17 13:42:22 --> MY_Model class loaded
INFO - 2021-07-17 13:42:22 --> Model "Users_model" initialized
INFO - 2021-07-17 13:42:22 --> Model "Settings_model" initialized
INFO - 2021-07-17 13:42:22 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 13:42:22 --> Model "Permissions_model" initialized
INFO - 2021-07-17 13:42:22 --> Model "Roles_model" initialized
INFO - 2021-07-17 13:42:22 --> Model "Activity_model" initialized
INFO - 2021-07-17 13:42:22 --> Model "Templates_model" initialized
INFO - 2021-07-17 13:42:22 --> Database Driver Class Initialized
INFO - 2021-07-17 13:42:23 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 13:42:23 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 13:42:23 --> Controller Class Initialized
ERROR - 2021-07-17 13:42:23 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 13:42:23 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 13:42:23 --> Final output sent to browser
DEBUG - 2021-07-17 13:42:23 --> Total execution time: 0.5635
INFO - 2021-07-17 13:42:26 --> Config Class Initialized
INFO - 2021-07-17 13:42:26 --> Hooks Class Initialized
DEBUG - 2021-07-17 13:42:26 --> UTF-8 Support Enabled
INFO - 2021-07-17 13:42:26 --> Utf8 Class Initialized
INFO - 2021-07-17 13:42:26 --> URI Class Initialized
DEBUG - 2021-07-17 13:42:26 --> No URI present. Default controller set.
INFO - 2021-07-17 13:42:26 --> Router Class Initialized
INFO - 2021-07-17 13:42:26 --> Output Class Initialized
INFO - 2021-07-17 13:42:26 --> Security Class Initialized
DEBUG - 2021-07-17 13:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 13:42:26 --> Input Class Initialized
INFO - 2021-07-17 13:42:26 --> Language Class Initialized
INFO - 2021-07-17 13:42:26 --> Loader Class Initialized
INFO - 2021-07-17 13:42:26 --> Helper loaded: basic_helper
INFO - 2021-07-17 13:42:26 --> Helper loaded: url_helper
INFO - 2021-07-17 13:42:26 --> Helper loaded: file_helper
INFO - 2021-07-17 13:42:26 --> Helper loaded: form_helper
INFO - 2021-07-17 13:42:26 --> Helper loaded: cookie_helper
INFO - 2021-07-17 13:42:26 --> Helper loaded: security_helper
INFO - 2021-07-17 13:42:26 --> Helper loaded: directory_helper
INFO - 2021-07-17 13:42:26 --> Helper loaded: language_helper
INFO - 2021-07-17 13:42:26 --> Helper loaded: general_helper
INFO - 2021-07-17 13:42:26 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 13:42:26 --> Database Driver Class Initialized
DEBUG - 2021-07-17 13:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 13:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 13:42:26 --> Parser Class Initialized
INFO - 2021-07-17 13:42:26 --> Form Validation Class Initialized
INFO - 2021-07-17 13:42:26 --> Upload Class Initialized
INFO - 2021-07-17 13:42:26 --> Email Class Initialized
INFO - 2021-07-17 13:42:26 --> MY_Model class loaded
INFO - 2021-07-17 13:42:26 --> Model "Users_model" initialized
INFO - 2021-07-17 13:42:26 --> Model "Settings_model" initialized
INFO - 2021-07-17 13:42:26 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 13:42:26 --> Model "Permissions_model" initialized
INFO - 2021-07-17 13:42:26 --> Model "Roles_model" initialized
INFO - 2021-07-17 13:42:26 --> Model "Activity_model" initialized
INFO - 2021-07-17 13:42:26 --> Model "Templates_model" initialized
INFO - 2021-07-17 13:42:26 --> Database Driver Class Initialized
INFO - 2021-07-17 13:42:26 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 13:42:26 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 13:42:26 --> Controller Class Initialized
ERROR - 2021-07-17 13:42:26 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 13:42:26 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-17 13:42:26 --> Final output sent to browser
DEBUG - 2021-07-17 13:42:26 --> Total execution time: 0.0783
INFO - 2021-07-17 13:42:40 --> Config Class Initialized
INFO - 2021-07-17 13:42:40 --> Hooks Class Initialized
DEBUG - 2021-07-17 13:42:40 --> UTF-8 Support Enabled
INFO - 2021-07-17 13:42:40 --> Utf8 Class Initialized
INFO - 2021-07-17 13:42:40 --> URI Class Initialized
INFO - 2021-07-17 13:42:40 --> Router Class Initialized
INFO - 2021-07-17 13:42:40 --> Output Class Initialized
INFO - 2021-07-17 13:42:40 --> Security Class Initialized
DEBUG - 2021-07-17 13:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 13:42:40 --> Input Class Initialized
INFO - 2021-07-17 13:42:40 --> Language Class Initialized
INFO - 2021-07-17 13:42:40 --> Loader Class Initialized
INFO - 2021-07-17 13:42:40 --> Helper loaded: basic_helper
INFO - 2021-07-17 13:42:40 --> Helper loaded: url_helper
INFO - 2021-07-17 13:42:40 --> Helper loaded: file_helper
INFO - 2021-07-17 13:42:40 --> Helper loaded: form_helper
INFO - 2021-07-17 13:42:40 --> Helper loaded: cookie_helper
INFO - 2021-07-17 13:42:40 --> Helper loaded: security_helper
INFO - 2021-07-17 13:42:40 --> Helper loaded: directory_helper
INFO - 2021-07-17 13:42:40 --> Helper loaded: language_helper
INFO - 2021-07-17 13:42:40 --> Helper loaded: general_helper
INFO - 2021-07-17 13:42:40 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 13:42:40 --> Database Driver Class Initialized
DEBUG - 2021-07-17 13:42:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 13:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 13:42:40 --> Parser Class Initialized
INFO - 2021-07-17 13:42:40 --> Form Validation Class Initialized
INFO - 2021-07-17 13:42:40 --> Upload Class Initialized
INFO - 2021-07-17 13:42:40 --> Email Class Initialized
INFO - 2021-07-17 13:42:40 --> MY_Model class loaded
INFO - 2021-07-17 13:42:40 --> Model "Users_model" initialized
INFO - 2021-07-17 13:42:40 --> Model "Settings_model" initialized
INFO - 2021-07-17 13:42:40 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 13:42:40 --> Model "Permissions_model" initialized
INFO - 2021-07-17 13:42:40 --> Model "Roles_model" initialized
INFO - 2021-07-17 13:42:40 --> Model "Activity_model" initialized
INFO - 2021-07-17 13:42:40 --> Model "Templates_model" initialized
INFO - 2021-07-17 13:42:40 --> Database Driver Class Initialized
INFO - 2021-07-17 13:42:40 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 13:42:40 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 13:42:40 --> Controller Class Initialized
ERROR - 2021-07-17 13:42:40 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 13:42:40 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 13:42:40 --> Final output sent to browser
DEBUG - 2021-07-17 13:42:40 --> Total execution time: 0.1430
INFO - 2021-07-17 13:44:58 --> Config Class Initialized
INFO - 2021-07-17 13:44:58 --> Hooks Class Initialized
DEBUG - 2021-07-17 13:44:58 --> UTF-8 Support Enabled
INFO - 2021-07-17 13:44:58 --> Utf8 Class Initialized
INFO - 2021-07-17 13:44:58 --> URI Class Initialized
INFO - 2021-07-17 13:44:58 --> Router Class Initialized
INFO - 2021-07-17 13:44:58 --> Output Class Initialized
INFO - 2021-07-17 13:44:58 --> Security Class Initialized
DEBUG - 2021-07-17 13:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 13:44:58 --> Input Class Initialized
INFO - 2021-07-17 13:44:58 --> Language Class Initialized
INFO - 2021-07-17 13:44:58 --> Loader Class Initialized
INFO - 2021-07-17 13:44:58 --> Helper loaded: basic_helper
INFO - 2021-07-17 13:44:58 --> Helper loaded: url_helper
INFO - 2021-07-17 13:44:58 --> Helper loaded: file_helper
INFO - 2021-07-17 13:44:58 --> Helper loaded: form_helper
INFO - 2021-07-17 13:44:58 --> Helper loaded: cookie_helper
INFO - 2021-07-17 13:44:58 --> Helper loaded: security_helper
INFO - 2021-07-17 13:44:58 --> Helper loaded: directory_helper
INFO - 2021-07-17 13:44:58 --> Helper loaded: language_helper
INFO - 2021-07-17 13:44:58 --> Helper loaded: general_helper
INFO - 2021-07-17 13:44:58 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 13:44:58 --> Database Driver Class Initialized
DEBUG - 2021-07-17 13:44:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 13:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 13:44:58 --> Parser Class Initialized
INFO - 2021-07-17 13:44:58 --> Form Validation Class Initialized
INFO - 2021-07-17 13:44:58 --> Upload Class Initialized
INFO - 2021-07-17 13:44:58 --> Email Class Initialized
INFO - 2021-07-17 13:44:58 --> MY_Model class loaded
INFO - 2021-07-17 13:44:58 --> Model "Users_model" initialized
INFO - 2021-07-17 13:44:58 --> Model "Settings_model" initialized
INFO - 2021-07-17 13:44:58 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 13:44:58 --> Model "Permissions_model" initialized
INFO - 2021-07-17 13:44:58 --> Model "Roles_model" initialized
INFO - 2021-07-17 13:44:58 --> Model "Activity_model" initialized
INFO - 2021-07-17 13:44:58 --> Model "Templates_model" initialized
INFO - 2021-07-17 13:44:58 --> Database Driver Class Initialized
INFO - 2021-07-17 13:44:58 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 13:44:58 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 13:44:58 --> Controller Class Initialized
ERROR - 2021-07-17 13:44:58 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 13:44:58 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 13:44:58 --> Final output sent to browser
DEBUG - 2021-07-17 13:44:58 --> Total execution time: 0.1355
INFO - 2021-07-17 13:57:29 --> Config Class Initialized
INFO - 2021-07-17 13:57:29 --> Hooks Class Initialized
DEBUG - 2021-07-17 13:57:29 --> UTF-8 Support Enabled
INFO - 2021-07-17 13:57:29 --> Utf8 Class Initialized
INFO - 2021-07-17 13:57:29 --> URI Class Initialized
INFO - 2021-07-17 13:57:29 --> Router Class Initialized
INFO - 2021-07-17 13:57:29 --> Output Class Initialized
INFO - 2021-07-17 13:57:29 --> Security Class Initialized
DEBUG - 2021-07-17 13:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 13:57:29 --> Input Class Initialized
INFO - 2021-07-17 13:57:29 --> Language Class Initialized
INFO - 2021-07-17 13:57:29 --> Loader Class Initialized
INFO - 2021-07-17 13:57:29 --> Helper loaded: basic_helper
INFO - 2021-07-17 13:57:29 --> Helper loaded: url_helper
INFO - 2021-07-17 13:57:29 --> Helper loaded: file_helper
INFO - 2021-07-17 13:57:29 --> Helper loaded: form_helper
INFO - 2021-07-17 13:57:29 --> Helper loaded: cookie_helper
INFO - 2021-07-17 13:57:29 --> Helper loaded: security_helper
INFO - 2021-07-17 13:57:29 --> Helper loaded: directory_helper
INFO - 2021-07-17 13:57:29 --> Helper loaded: language_helper
INFO - 2021-07-17 13:57:29 --> Helper loaded: general_helper
INFO - 2021-07-17 13:57:29 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 13:57:29 --> Database Driver Class Initialized
DEBUG - 2021-07-17 13:57:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 13:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 13:57:29 --> Parser Class Initialized
INFO - 2021-07-17 13:57:29 --> Form Validation Class Initialized
INFO - 2021-07-17 13:57:29 --> Upload Class Initialized
INFO - 2021-07-17 13:57:29 --> Email Class Initialized
INFO - 2021-07-17 13:57:29 --> MY_Model class loaded
INFO - 2021-07-17 13:57:29 --> Model "Users_model" initialized
INFO - 2021-07-17 13:57:29 --> Model "Settings_model" initialized
INFO - 2021-07-17 13:57:29 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 13:57:29 --> Model "Permissions_model" initialized
INFO - 2021-07-17 13:57:30 --> Model "Roles_model" initialized
INFO - 2021-07-17 13:57:30 --> Model "Activity_model" initialized
INFO - 2021-07-17 13:57:30 --> Model "Templates_model" initialized
INFO - 2021-07-17 13:57:30 --> Database Driver Class Initialized
INFO - 2021-07-17 13:57:30 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 13:57:30 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 13:57:30 --> Controller Class Initialized
INFO - 2021-07-17 13:57:30 --> Config Class Initialized
INFO - 2021-07-17 13:57:30 --> Hooks Class Initialized
DEBUG - 2021-07-17 13:57:30 --> UTF-8 Support Enabled
INFO - 2021-07-17 13:57:30 --> Utf8 Class Initialized
INFO - 2021-07-17 13:57:30 --> URI Class Initialized
INFO - 2021-07-17 13:57:30 --> Router Class Initialized
INFO - 2021-07-17 13:57:30 --> Output Class Initialized
INFO - 2021-07-17 13:57:30 --> Security Class Initialized
DEBUG - 2021-07-17 13:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 13:57:30 --> Input Class Initialized
INFO - 2021-07-17 13:57:30 --> Language Class Initialized
INFO - 2021-07-17 13:57:30 --> Loader Class Initialized
INFO - 2021-07-17 13:57:30 --> Helper loaded: basic_helper
INFO - 2021-07-17 13:57:30 --> Helper loaded: url_helper
INFO - 2021-07-17 13:57:30 --> Helper loaded: file_helper
INFO - 2021-07-17 13:57:30 --> Helper loaded: form_helper
INFO - 2021-07-17 13:57:30 --> Helper loaded: cookie_helper
INFO - 2021-07-17 13:57:30 --> Helper loaded: security_helper
INFO - 2021-07-17 13:57:30 --> Helper loaded: directory_helper
INFO - 2021-07-17 13:57:30 --> Helper loaded: language_helper
INFO - 2021-07-17 13:57:30 --> Helper loaded: general_helper
INFO - 2021-07-17 13:57:30 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 13:57:30 --> Database Driver Class Initialized
DEBUG - 2021-07-17 13:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 13:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 13:57:30 --> Parser Class Initialized
INFO - 2021-07-17 13:57:30 --> Form Validation Class Initialized
INFO - 2021-07-17 13:57:30 --> Upload Class Initialized
INFO - 2021-07-17 13:57:30 --> Email Class Initialized
INFO - 2021-07-17 13:57:30 --> MY_Model class loaded
INFO - 2021-07-17 13:57:30 --> Model "Users_model" initialized
INFO - 2021-07-17 13:57:30 --> Model "Settings_model" initialized
INFO - 2021-07-17 13:57:30 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 13:57:30 --> Model "Permissions_model" initialized
INFO - 2021-07-17 13:57:30 --> Model "Roles_model" initialized
INFO - 2021-07-17 13:57:30 --> Model "Activity_model" initialized
INFO - 2021-07-17 13:57:30 --> Model "Templates_model" initialized
INFO - 2021-07-17 13:57:30 --> Database Driver Class Initialized
INFO - 2021-07-17 13:57:30 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 13:57:30 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 13:57:30 --> Controller Class Initialized
INFO - 2021-07-17 13:57:30 --> File loaded: C:\wamp64\www\crm\application\views\account/login.php
INFO - 2021-07-17 13:57:30 --> Final output sent to browser
DEBUG - 2021-07-17 13:57:30 --> Total execution time: 0.0470
INFO - 2021-07-17 13:57:30 --> Config Class Initialized
INFO - 2021-07-17 13:57:30 --> Hooks Class Initialized
INFO - 2021-07-17 13:57:30 --> Config Class Initialized
INFO - 2021-07-17 13:57:30 --> Hooks Class Initialized
DEBUG - 2021-07-17 13:57:30 --> UTF-8 Support Enabled
DEBUG - 2021-07-17 13:57:30 --> UTF-8 Support Enabled
INFO - 2021-07-17 13:57:30 --> Utf8 Class Initialized
INFO - 2021-07-17 13:57:30 --> Utf8 Class Initialized
INFO - 2021-07-17 13:57:30 --> URI Class Initialized
INFO - 2021-07-17 13:57:30 --> URI Class Initialized
INFO - 2021-07-17 13:57:30 --> Router Class Initialized
INFO - 2021-07-17 13:57:30 --> Router Class Initialized
INFO - 2021-07-17 13:57:30 --> Output Class Initialized
INFO - 2021-07-17 13:57:30 --> Output Class Initialized
INFO - 2021-07-17 13:57:30 --> Security Class Initialized
INFO - 2021-07-17 13:57:30 --> Security Class Initialized
DEBUG - 2021-07-17 13:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-17 13:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 13:57:30 --> Input Class Initialized
INFO - 2021-07-17 13:57:30 --> Input Class Initialized
INFO - 2021-07-17 13:57:30 --> Language Class Initialized
INFO - 2021-07-17 13:57:30 --> Language Class Initialized
ERROR - 2021-07-17 13:57:30 --> 404 Page Not Found: Assets/jquery
ERROR - 2021-07-17 13:57:30 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-17 13:57:30 --> Config Class Initialized
INFO - 2021-07-17 13:57:30 --> Hooks Class Initialized
DEBUG - 2021-07-17 13:57:30 --> UTF-8 Support Enabled
INFO - 2021-07-17 13:57:30 --> Utf8 Class Initialized
INFO - 2021-07-17 13:57:30 --> URI Class Initialized
INFO - 2021-07-17 13:57:30 --> Router Class Initialized
INFO - 2021-07-17 13:57:30 --> Output Class Initialized
INFO - 2021-07-17 13:57:30 --> Security Class Initialized
DEBUG - 2021-07-17 13:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 13:57:30 --> Input Class Initialized
INFO - 2021-07-17 13:57:30 --> Language Class Initialized
ERROR - 2021-07-17 13:57:30 --> 404 Page Not Found: Assets/jquery
INFO - 2021-07-17 13:57:30 --> Config Class Initialized
INFO - 2021-07-17 13:57:30 --> Hooks Class Initialized
DEBUG - 2021-07-17 13:57:30 --> UTF-8 Support Enabled
INFO - 2021-07-17 13:57:30 --> Utf8 Class Initialized
INFO - 2021-07-17 13:57:30 --> URI Class Initialized
INFO - 2021-07-17 13:57:30 --> Router Class Initialized
INFO - 2021-07-17 13:57:30 --> Output Class Initialized
INFO - 2021-07-17 13:57:30 --> Security Class Initialized
DEBUG - 2021-07-17 13:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 13:57:30 --> Input Class Initialized
INFO - 2021-07-17 13:57:30 --> Language Class Initialized
ERROR - 2021-07-17 13:57:30 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-17 13:57:38 --> Config Class Initialized
INFO - 2021-07-17 13:57:38 --> Hooks Class Initialized
DEBUG - 2021-07-17 13:57:38 --> UTF-8 Support Enabled
INFO - 2021-07-17 13:57:38 --> Utf8 Class Initialized
INFO - 2021-07-17 13:57:38 --> URI Class Initialized
INFO - 2021-07-17 13:57:38 --> Router Class Initialized
INFO - 2021-07-17 13:57:38 --> Output Class Initialized
INFO - 2021-07-17 13:57:38 --> Security Class Initialized
DEBUG - 2021-07-17 13:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 13:57:38 --> Input Class Initialized
INFO - 2021-07-17 13:57:38 --> Language Class Initialized
INFO - 2021-07-17 13:57:38 --> Loader Class Initialized
INFO - 2021-07-17 13:57:38 --> Helper loaded: basic_helper
INFO - 2021-07-17 13:57:38 --> Helper loaded: url_helper
INFO - 2021-07-17 13:57:38 --> Helper loaded: file_helper
INFO - 2021-07-17 13:57:38 --> Helper loaded: form_helper
INFO - 2021-07-17 13:57:38 --> Helper loaded: cookie_helper
INFO - 2021-07-17 13:57:38 --> Helper loaded: security_helper
INFO - 2021-07-17 13:57:38 --> Helper loaded: directory_helper
INFO - 2021-07-17 13:57:38 --> Helper loaded: language_helper
INFO - 2021-07-17 13:57:38 --> Helper loaded: general_helper
INFO - 2021-07-17 13:57:38 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 13:57:38 --> Database Driver Class Initialized
DEBUG - 2021-07-17 13:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 13:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 13:57:38 --> Parser Class Initialized
INFO - 2021-07-17 13:57:38 --> Form Validation Class Initialized
INFO - 2021-07-17 13:57:38 --> Upload Class Initialized
INFO - 2021-07-17 13:57:38 --> Email Class Initialized
INFO - 2021-07-17 13:57:38 --> MY_Model class loaded
INFO - 2021-07-17 13:57:38 --> Model "Users_model" initialized
INFO - 2021-07-17 13:57:38 --> Model "Settings_model" initialized
INFO - 2021-07-17 13:57:38 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 13:57:38 --> Model "Permissions_model" initialized
INFO - 2021-07-17 13:57:38 --> Model "Roles_model" initialized
INFO - 2021-07-17 13:57:38 --> Model "Activity_model" initialized
INFO - 2021-07-17 13:57:38 --> Model "Templates_model" initialized
INFO - 2021-07-17 13:57:38 --> Database Driver Class Initialized
INFO - 2021-07-17 13:57:38 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 13:57:38 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 13:57:38 --> Controller Class Initialized
DEBUG - 2021-07-17 13:57:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-17 13:57:38 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2021-07-17 13:57:38 --> Config Class Initialized
INFO - 2021-07-17 13:57:38 --> Hooks Class Initialized
DEBUG - 2021-07-17 13:57:38 --> UTF-8 Support Enabled
INFO - 2021-07-17 13:57:38 --> Utf8 Class Initialized
INFO - 2021-07-17 13:57:38 --> URI Class Initialized
DEBUG - 2021-07-17 13:57:38 --> No URI present. Default controller set.
INFO - 2021-07-17 13:57:38 --> Router Class Initialized
INFO - 2021-07-17 13:57:38 --> Output Class Initialized
INFO - 2021-07-17 13:57:38 --> Security Class Initialized
DEBUG - 2021-07-17 13:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 13:57:38 --> Input Class Initialized
INFO - 2021-07-17 13:57:38 --> Language Class Initialized
INFO - 2021-07-17 13:57:38 --> Loader Class Initialized
INFO - 2021-07-17 13:57:38 --> Helper loaded: basic_helper
INFO - 2021-07-17 13:57:38 --> Helper loaded: url_helper
INFO - 2021-07-17 13:57:38 --> Helper loaded: file_helper
INFO - 2021-07-17 13:57:38 --> Helper loaded: form_helper
INFO - 2021-07-17 13:57:38 --> Helper loaded: cookie_helper
INFO - 2021-07-17 13:57:38 --> Helper loaded: security_helper
INFO - 2021-07-17 13:57:38 --> Helper loaded: directory_helper
INFO - 2021-07-17 13:57:38 --> Helper loaded: language_helper
INFO - 2021-07-17 13:57:38 --> Helper loaded: general_helper
INFO - 2021-07-17 13:57:38 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 13:57:38 --> Database Driver Class Initialized
DEBUG - 2021-07-17 13:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 13:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 13:57:38 --> Parser Class Initialized
INFO - 2021-07-17 13:57:38 --> Form Validation Class Initialized
INFO - 2021-07-17 13:57:38 --> Upload Class Initialized
INFO - 2021-07-17 13:57:38 --> Email Class Initialized
INFO - 2021-07-17 13:57:38 --> MY_Model class loaded
INFO - 2021-07-17 13:57:38 --> Model "Users_model" initialized
INFO - 2021-07-17 13:57:38 --> Model "Settings_model" initialized
INFO - 2021-07-17 13:57:38 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 13:57:38 --> Model "Permissions_model" initialized
INFO - 2021-07-17 13:57:38 --> Model "Roles_model" initialized
INFO - 2021-07-17 13:57:38 --> Model "Activity_model" initialized
INFO - 2021-07-17 13:57:38 --> Model "Templates_model" initialized
INFO - 2021-07-17 13:57:38 --> Database Driver Class Initialized
INFO - 2021-07-17 13:57:38 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 13:57:38 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 13:57:38 --> Controller Class Initialized
ERROR - 2021-07-17 13:57:38 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 13:57:38 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-17 13:57:38 --> Final output sent to browser
DEBUG - 2021-07-17 13:57:38 --> Total execution time: 0.0605
INFO - 2021-07-17 13:57:41 --> Config Class Initialized
INFO - 2021-07-17 13:57:41 --> Hooks Class Initialized
DEBUG - 2021-07-17 13:57:41 --> UTF-8 Support Enabled
INFO - 2021-07-17 13:57:41 --> Utf8 Class Initialized
INFO - 2021-07-17 13:57:41 --> URI Class Initialized
INFO - 2021-07-17 13:57:41 --> Router Class Initialized
INFO - 2021-07-17 13:57:41 --> Output Class Initialized
INFO - 2021-07-17 13:57:41 --> Security Class Initialized
DEBUG - 2021-07-17 13:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 13:57:41 --> Input Class Initialized
INFO - 2021-07-17 13:57:41 --> Language Class Initialized
INFO - 2021-07-17 13:57:41 --> Loader Class Initialized
INFO - 2021-07-17 13:57:41 --> Helper loaded: basic_helper
INFO - 2021-07-17 13:57:41 --> Helper loaded: url_helper
INFO - 2021-07-17 13:57:41 --> Helper loaded: file_helper
INFO - 2021-07-17 13:57:41 --> Helper loaded: form_helper
INFO - 2021-07-17 13:57:41 --> Helper loaded: cookie_helper
INFO - 2021-07-17 13:57:41 --> Helper loaded: security_helper
INFO - 2021-07-17 13:57:41 --> Helper loaded: directory_helper
INFO - 2021-07-17 13:57:41 --> Helper loaded: language_helper
INFO - 2021-07-17 13:57:41 --> Helper loaded: general_helper
INFO - 2021-07-17 13:57:41 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 13:57:41 --> Database Driver Class Initialized
DEBUG - 2021-07-17 13:57:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 13:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 13:57:41 --> Parser Class Initialized
INFO - 2021-07-17 13:57:41 --> Form Validation Class Initialized
INFO - 2021-07-17 13:57:41 --> Upload Class Initialized
INFO - 2021-07-17 13:57:41 --> Email Class Initialized
INFO - 2021-07-17 13:57:41 --> MY_Model class loaded
INFO - 2021-07-17 13:57:41 --> Model "Users_model" initialized
INFO - 2021-07-17 13:57:41 --> Model "Settings_model" initialized
INFO - 2021-07-17 13:57:41 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 13:57:41 --> Model "Permissions_model" initialized
INFO - 2021-07-17 13:57:41 --> Model "Roles_model" initialized
INFO - 2021-07-17 13:57:41 --> Model "Activity_model" initialized
INFO - 2021-07-17 13:57:41 --> Model "Templates_model" initialized
INFO - 2021-07-17 13:57:41 --> Database Driver Class Initialized
INFO - 2021-07-17 13:57:41 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 13:57:41 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 13:57:41 --> Controller Class Initialized
ERROR - 2021-07-17 13:57:41 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 13:57:41 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 13:57:41 --> Final output sent to browser
DEBUG - 2021-07-17 13:57:41 --> Total execution time: 0.0669
INFO - 2021-07-17 14:02:28 --> Config Class Initialized
INFO - 2021-07-17 14:02:28 --> Hooks Class Initialized
DEBUG - 2021-07-17 14:02:28 --> UTF-8 Support Enabled
INFO - 2021-07-17 14:02:28 --> Utf8 Class Initialized
INFO - 2021-07-17 14:02:28 --> URI Class Initialized
DEBUG - 2021-07-17 14:02:28 --> No URI present. Default controller set.
INFO - 2021-07-17 14:02:28 --> Router Class Initialized
INFO - 2021-07-17 14:02:28 --> Output Class Initialized
INFO - 2021-07-17 14:02:28 --> Security Class Initialized
DEBUG - 2021-07-17 14:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 14:02:28 --> Input Class Initialized
INFO - 2021-07-17 14:02:28 --> Language Class Initialized
INFO - 2021-07-17 14:02:28 --> Loader Class Initialized
INFO - 2021-07-17 14:02:28 --> Helper loaded: basic_helper
INFO - 2021-07-17 14:02:28 --> Helper loaded: url_helper
INFO - 2021-07-17 14:02:28 --> Helper loaded: file_helper
INFO - 2021-07-17 14:02:28 --> Helper loaded: form_helper
INFO - 2021-07-17 14:02:28 --> Helper loaded: cookie_helper
INFO - 2021-07-17 14:02:28 --> Helper loaded: security_helper
INFO - 2021-07-17 14:02:28 --> Helper loaded: directory_helper
INFO - 2021-07-17 14:02:28 --> Helper loaded: language_helper
INFO - 2021-07-17 14:02:28 --> Helper loaded: general_helper
INFO - 2021-07-17 14:02:28 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 14:02:28 --> Database Driver Class Initialized
DEBUG - 2021-07-17 14:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 14:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 14:02:28 --> Parser Class Initialized
INFO - 2021-07-17 14:02:28 --> Form Validation Class Initialized
INFO - 2021-07-17 14:02:28 --> Upload Class Initialized
INFO - 2021-07-17 14:02:28 --> Email Class Initialized
INFO - 2021-07-17 14:02:28 --> MY_Model class loaded
INFO - 2021-07-17 14:02:28 --> Model "Users_model" initialized
INFO - 2021-07-17 14:02:28 --> Model "Settings_model" initialized
INFO - 2021-07-17 14:02:28 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 14:02:28 --> Model "Permissions_model" initialized
INFO - 2021-07-17 14:02:28 --> Model "Roles_model" initialized
INFO - 2021-07-17 14:02:28 --> Model "Activity_model" initialized
INFO - 2021-07-17 14:02:28 --> Model "Templates_model" initialized
INFO - 2021-07-17 14:02:28 --> Database Driver Class Initialized
INFO - 2021-07-17 14:02:29 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 14:02:29 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 14:02:29 --> Controller Class Initialized
INFO - 2021-07-17 14:12:22 --> Config Class Initialized
INFO - 2021-07-17 14:12:22 --> Hooks Class Initialized
DEBUG - 2021-07-17 14:12:22 --> UTF-8 Support Enabled
INFO - 2021-07-17 14:12:22 --> Utf8 Class Initialized
INFO - 2021-07-17 14:12:22 --> URI Class Initialized
INFO - 2021-07-17 14:12:22 --> Router Class Initialized
INFO - 2021-07-17 14:12:22 --> Output Class Initialized
INFO - 2021-07-17 14:12:22 --> Security Class Initialized
DEBUG - 2021-07-17 14:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 14:12:22 --> Input Class Initialized
INFO - 2021-07-17 14:12:22 --> Language Class Initialized
INFO - 2021-07-17 14:12:22 --> Loader Class Initialized
INFO - 2021-07-17 14:12:22 --> Helper loaded: basic_helper
INFO - 2021-07-17 14:12:22 --> Helper loaded: url_helper
INFO - 2021-07-17 14:12:22 --> Helper loaded: file_helper
INFO - 2021-07-17 14:12:22 --> Helper loaded: form_helper
INFO - 2021-07-17 14:12:22 --> Helper loaded: cookie_helper
INFO - 2021-07-17 14:12:22 --> Helper loaded: security_helper
INFO - 2021-07-17 14:12:22 --> Helper loaded: directory_helper
INFO - 2021-07-17 14:12:22 --> Helper loaded: language_helper
INFO - 2021-07-17 14:12:22 --> Helper loaded: general_helper
INFO - 2021-07-17 14:12:22 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 14:12:22 --> Database Driver Class Initialized
DEBUG - 2021-07-17 14:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 14:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 14:12:22 --> Parser Class Initialized
INFO - 2021-07-17 14:12:22 --> Form Validation Class Initialized
INFO - 2021-07-17 14:12:22 --> Upload Class Initialized
INFO - 2021-07-17 14:12:22 --> Email Class Initialized
INFO - 2021-07-17 14:12:22 --> MY_Model class loaded
INFO - 2021-07-17 14:12:22 --> Model "Users_model" initialized
INFO - 2021-07-17 14:12:22 --> Model "Settings_model" initialized
INFO - 2021-07-17 14:12:22 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 14:12:22 --> Model "Permissions_model" initialized
INFO - 2021-07-17 14:12:22 --> Model "Roles_model" initialized
INFO - 2021-07-17 14:12:22 --> Model "Activity_model" initialized
INFO - 2021-07-17 14:12:22 --> Model "Templates_model" initialized
INFO - 2021-07-17 14:12:22 --> Database Driver Class Initialized
INFO - 2021-07-17 14:12:22 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 14:12:22 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 14:12:22 --> Controller Class Initialized
ERROR - 2021-07-17 14:12:22 --> Severity: error --> Exception: Too few arguments to function Car_activity_model::getCarInfo(), 0 passed in C:\wamp64\www\crm\application\controllers\Car.php on line 17 and exactly 1 expected C:\wamp64\www\crm\application\models\Car_activity_model.php 109
INFO - 2021-07-17 14:12:37 --> Config Class Initialized
INFO - 2021-07-17 14:12:37 --> Hooks Class Initialized
DEBUG - 2021-07-17 14:12:37 --> UTF-8 Support Enabled
INFO - 2021-07-17 14:12:37 --> Utf8 Class Initialized
INFO - 2021-07-17 14:12:37 --> URI Class Initialized
INFO - 2021-07-17 14:12:37 --> Router Class Initialized
INFO - 2021-07-17 14:12:37 --> Output Class Initialized
INFO - 2021-07-17 14:12:37 --> Security Class Initialized
DEBUG - 2021-07-17 14:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 14:12:37 --> Input Class Initialized
INFO - 2021-07-17 14:12:37 --> Language Class Initialized
INFO - 2021-07-17 14:12:37 --> Loader Class Initialized
INFO - 2021-07-17 14:12:37 --> Helper loaded: basic_helper
INFO - 2021-07-17 14:12:37 --> Helper loaded: url_helper
INFO - 2021-07-17 14:12:37 --> Helper loaded: file_helper
INFO - 2021-07-17 14:12:37 --> Helper loaded: form_helper
INFO - 2021-07-17 14:12:37 --> Helper loaded: cookie_helper
INFO - 2021-07-17 14:12:37 --> Helper loaded: security_helper
INFO - 2021-07-17 14:12:37 --> Helper loaded: directory_helper
INFO - 2021-07-17 14:12:37 --> Helper loaded: language_helper
INFO - 2021-07-17 14:12:37 --> Helper loaded: general_helper
INFO - 2021-07-17 14:12:37 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 14:12:37 --> Database Driver Class Initialized
DEBUG - 2021-07-17 14:12:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 14:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 14:12:37 --> Parser Class Initialized
INFO - 2021-07-17 14:12:37 --> Form Validation Class Initialized
INFO - 2021-07-17 14:12:37 --> Upload Class Initialized
INFO - 2021-07-17 14:12:37 --> Email Class Initialized
INFO - 2021-07-17 14:12:37 --> MY_Model class loaded
INFO - 2021-07-17 14:12:37 --> Model "Users_model" initialized
INFO - 2021-07-17 14:12:37 --> Model "Settings_model" initialized
INFO - 2021-07-17 14:12:37 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 14:12:37 --> Model "Permissions_model" initialized
INFO - 2021-07-17 14:12:37 --> Model "Roles_model" initialized
INFO - 2021-07-17 14:12:37 --> Model "Activity_model" initialized
INFO - 2021-07-17 14:12:37 --> Model "Templates_model" initialized
INFO - 2021-07-17 14:12:37 --> Database Driver Class Initialized
INFO - 2021-07-17 14:12:37 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 14:12:37 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 14:12:37 --> Controller Class Initialized
ERROR - 2021-07-17 14:12:37 --> Severity: error --> Exception: Too few arguments to function Car_activity_model::getCarInfo(), 0 passed in C:\wamp64\www\crm\application\controllers\Car.php on line 17 and exactly 1 expected C:\wamp64\www\crm\application\models\Car_activity_model.php 109
INFO - 2021-07-17 14:12:38 --> Config Class Initialized
INFO - 2021-07-17 14:12:38 --> Hooks Class Initialized
DEBUG - 2021-07-17 14:12:38 --> UTF-8 Support Enabled
INFO - 2021-07-17 14:12:38 --> Utf8 Class Initialized
INFO - 2021-07-17 14:12:38 --> URI Class Initialized
INFO - 2021-07-17 14:12:38 --> Router Class Initialized
INFO - 2021-07-17 14:12:38 --> Output Class Initialized
INFO - 2021-07-17 14:12:38 --> Security Class Initialized
DEBUG - 2021-07-17 14:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 14:12:38 --> Input Class Initialized
INFO - 2021-07-17 14:12:38 --> Language Class Initialized
INFO - 2021-07-17 14:12:38 --> Loader Class Initialized
INFO - 2021-07-17 14:12:38 --> Helper loaded: basic_helper
INFO - 2021-07-17 14:12:38 --> Helper loaded: url_helper
INFO - 2021-07-17 14:12:38 --> Helper loaded: file_helper
INFO - 2021-07-17 14:12:38 --> Helper loaded: form_helper
INFO - 2021-07-17 14:12:38 --> Helper loaded: cookie_helper
INFO - 2021-07-17 14:12:38 --> Helper loaded: security_helper
INFO - 2021-07-17 14:12:38 --> Helper loaded: directory_helper
INFO - 2021-07-17 14:12:38 --> Helper loaded: language_helper
INFO - 2021-07-17 14:12:38 --> Helper loaded: general_helper
INFO - 2021-07-17 14:12:38 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 14:12:38 --> Database Driver Class Initialized
DEBUG - 2021-07-17 14:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 14:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 14:12:38 --> Parser Class Initialized
INFO - 2021-07-17 14:12:38 --> Form Validation Class Initialized
INFO - 2021-07-17 14:12:38 --> Upload Class Initialized
INFO - 2021-07-17 14:12:38 --> Email Class Initialized
INFO - 2021-07-17 14:12:38 --> MY_Model class loaded
INFO - 2021-07-17 14:12:38 --> Model "Users_model" initialized
INFO - 2021-07-17 14:12:38 --> Model "Settings_model" initialized
INFO - 2021-07-17 14:12:38 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 14:12:38 --> Model "Permissions_model" initialized
INFO - 2021-07-17 14:12:38 --> Model "Roles_model" initialized
INFO - 2021-07-17 14:12:38 --> Model "Activity_model" initialized
INFO - 2021-07-17 14:12:38 --> Model "Templates_model" initialized
INFO - 2021-07-17 14:12:38 --> Database Driver Class Initialized
INFO - 2021-07-17 14:12:38 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 14:12:38 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 14:12:38 --> Controller Class Initialized
ERROR - 2021-07-17 14:12:38 --> Severity: error --> Exception: Too few arguments to function Car_activity_model::getCarInfo(), 0 passed in C:\wamp64\www\crm\application\controllers\Car.php on line 17 and exactly 1 expected C:\wamp64\www\crm\application\models\Car_activity_model.php 109
INFO - 2021-07-17 14:13:26 --> Config Class Initialized
INFO - 2021-07-17 14:13:26 --> Hooks Class Initialized
DEBUG - 2021-07-17 14:13:26 --> UTF-8 Support Enabled
INFO - 2021-07-17 14:13:26 --> Utf8 Class Initialized
INFO - 2021-07-17 14:13:26 --> URI Class Initialized
INFO - 2021-07-17 14:13:26 --> Router Class Initialized
INFO - 2021-07-17 14:13:26 --> Output Class Initialized
INFO - 2021-07-17 14:13:26 --> Security Class Initialized
DEBUG - 2021-07-17 14:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 14:13:26 --> Input Class Initialized
INFO - 2021-07-17 14:13:26 --> Language Class Initialized
INFO - 2021-07-17 14:13:26 --> Loader Class Initialized
INFO - 2021-07-17 14:13:26 --> Helper loaded: basic_helper
INFO - 2021-07-17 14:13:26 --> Helper loaded: url_helper
INFO - 2021-07-17 14:13:26 --> Helper loaded: file_helper
INFO - 2021-07-17 14:13:26 --> Helper loaded: form_helper
INFO - 2021-07-17 14:13:26 --> Helper loaded: cookie_helper
INFO - 2021-07-17 14:13:26 --> Helper loaded: security_helper
INFO - 2021-07-17 14:13:26 --> Helper loaded: directory_helper
INFO - 2021-07-17 14:13:26 --> Helper loaded: language_helper
INFO - 2021-07-17 14:13:26 --> Helper loaded: general_helper
INFO - 2021-07-17 14:13:26 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 14:13:26 --> Database Driver Class Initialized
DEBUG - 2021-07-17 14:13:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 14:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 14:13:26 --> Parser Class Initialized
INFO - 2021-07-17 14:13:26 --> Form Validation Class Initialized
INFO - 2021-07-17 14:13:26 --> Upload Class Initialized
INFO - 2021-07-17 14:13:26 --> Email Class Initialized
INFO - 2021-07-17 14:13:26 --> MY_Model class loaded
INFO - 2021-07-17 14:13:26 --> Model "Users_model" initialized
INFO - 2021-07-17 14:13:26 --> Model "Settings_model" initialized
INFO - 2021-07-17 14:13:26 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 14:13:26 --> Model "Permissions_model" initialized
INFO - 2021-07-17 14:13:26 --> Model "Roles_model" initialized
INFO - 2021-07-17 14:13:26 --> Model "Activity_model" initialized
INFO - 2021-07-17 14:13:26 --> Model "Templates_model" initialized
INFO - 2021-07-17 14:13:26 --> Database Driver Class Initialized
INFO - 2021-07-17 14:13:26 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 14:13:26 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 14:13:26 --> Controller Class Initialized
ERROR - 2021-07-17 14:13:26 --> Severity: Warning --> Use of undefined constant carid - assumed 'carid' (this will throw an Error in a future version of PHP) C:\wamp64\www\crm\application\controllers\Car.php 34
ERROR - 2021-07-17 14:13:26 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 14:13:26 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 14:13:26 --> Final output sent to browser
DEBUG - 2021-07-17 14:13:26 --> Total execution time: 0.1435
INFO - 2021-07-17 14:13:30 --> Config Class Initialized
INFO - 2021-07-17 14:13:30 --> Hooks Class Initialized
DEBUG - 2021-07-17 14:13:30 --> UTF-8 Support Enabled
INFO - 2021-07-17 14:13:30 --> Utf8 Class Initialized
INFO - 2021-07-17 14:13:30 --> URI Class Initialized
INFO - 2021-07-17 14:13:30 --> Router Class Initialized
INFO - 2021-07-17 14:13:30 --> Output Class Initialized
INFO - 2021-07-17 14:13:30 --> Security Class Initialized
DEBUG - 2021-07-17 14:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 14:13:30 --> Input Class Initialized
INFO - 2021-07-17 14:13:30 --> Language Class Initialized
INFO - 2021-07-17 14:13:30 --> Loader Class Initialized
INFO - 2021-07-17 14:13:30 --> Helper loaded: basic_helper
INFO - 2021-07-17 14:13:30 --> Helper loaded: url_helper
INFO - 2021-07-17 14:13:30 --> Helper loaded: file_helper
INFO - 2021-07-17 14:13:30 --> Helper loaded: form_helper
INFO - 2021-07-17 14:13:30 --> Helper loaded: cookie_helper
INFO - 2021-07-17 14:13:30 --> Helper loaded: security_helper
INFO - 2021-07-17 14:13:30 --> Helper loaded: directory_helper
INFO - 2021-07-17 14:13:30 --> Helper loaded: language_helper
INFO - 2021-07-17 14:13:30 --> Helper loaded: general_helper
INFO - 2021-07-17 14:13:30 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 14:13:30 --> Database Driver Class Initialized
DEBUG - 2021-07-17 14:13:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 14:13:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 14:13:30 --> Parser Class Initialized
INFO - 2021-07-17 14:13:30 --> Form Validation Class Initialized
INFO - 2021-07-17 14:13:30 --> Upload Class Initialized
INFO - 2021-07-17 14:13:30 --> Email Class Initialized
INFO - 2021-07-17 14:13:30 --> MY_Model class loaded
INFO - 2021-07-17 14:13:30 --> Model "Users_model" initialized
INFO - 2021-07-17 14:13:30 --> Model "Settings_model" initialized
INFO - 2021-07-17 14:13:30 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 14:13:30 --> Model "Permissions_model" initialized
INFO - 2021-07-17 14:13:30 --> Model "Roles_model" initialized
INFO - 2021-07-17 14:13:30 --> Model "Activity_model" initialized
INFO - 2021-07-17 14:13:30 --> Model "Templates_model" initialized
INFO - 2021-07-17 14:13:30 --> Database Driver Class Initialized
INFO - 2021-07-17 14:13:30 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 14:13:30 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 14:13:30 --> Controller Class Initialized
ERROR - 2021-07-17 14:13:30 --> Severity: Warning --> Use of undefined constant carid - assumed 'carid' (this will throw an Error in a future version of PHP) C:\wamp64\www\crm\application\controllers\Car.php 34
ERROR - 2021-07-17 14:13:30 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 14:13:30 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 14:13:30 --> Final output sent to browser
DEBUG - 2021-07-17 14:13:30 --> Total execution time: 0.0704
INFO - 2021-07-17 14:13:45 --> Config Class Initialized
INFO - 2021-07-17 14:13:45 --> Hooks Class Initialized
DEBUG - 2021-07-17 14:13:45 --> UTF-8 Support Enabled
INFO - 2021-07-17 14:13:45 --> Utf8 Class Initialized
INFO - 2021-07-17 14:13:45 --> URI Class Initialized
INFO - 2021-07-17 14:13:45 --> Router Class Initialized
INFO - 2021-07-17 14:13:45 --> Output Class Initialized
INFO - 2021-07-17 14:13:45 --> Security Class Initialized
DEBUG - 2021-07-17 14:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 14:13:45 --> Input Class Initialized
INFO - 2021-07-17 14:13:45 --> Language Class Initialized
INFO - 2021-07-17 14:13:45 --> Loader Class Initialized
INFO - 2021-07-17 14:13:45 --> Helper loaded: basic_helper
INFO - 2021-07-17 14:13:45 --> Helper loaded: url_helper
INFO - 2021-07-17 14:13:45 --> Helper loaded: file_helper
INFO - 2021-07-17 14:13:45 --> Helper loaded: form_helper
INFO - 2021-07-17 14:13:45 --> Helper loaded: cookie_helper
INFO - 2021-07-17 14:13:45 --> Helper loaded: security_helper
INFO - 2021-07-17 14:13:45 --> Helper loaded: directory_helper
INFO - 2021-07-17 14:13:45 --> Helper loaded: language_helper
INFO - 2021-07-17 14:13:45 --> Helper loaded: general_helper
INFO - 2021-07-17 14:13:45 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 14:13:45 --> Database Driver Class Initialized
DEBUG - 2021-07-17 14:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 14:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 14:13:45 --> Parser Class Initialized
INFO - 2021-07-17 14:13:45 --> Form Validation Class Initialized
INFO - 2021-07-17 14:13:45 --> Upload Class Initialized
INFO - 2021-07-17 14:13:45 --> Email Class Initialized
INFO - 2021-07-17 14:13:45 --> MY_Model class loaded
INFO - 2021-07-17 14:13:45 --> Model "Users_model" initialized
INFO - 2021-07-17 14:13:45 --> Model "Settings_model" initialized
INFO - 2021-07-17 14:13:45 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 14:13:45 --> Model "Permissions_model" initialized
INFO - 2021-07-17 14:13:45 --> Model "Roles_model" initialized
INFO - 2021-07-17 14:13:45 --> Model "Activity_model" initialized
INFO - 2021-07-17 14:13:45 --> Model "Templates_model" initialized
INFO - 2021-07-17 14:13:45 --> Database Driver Class Initialized
INFO - 2021-07-17 14:13:45 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 14:13:45 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 14:13:45 --> Controller Class Initialized
ERROR - 2021-07-17 14:13:45 --> Severity: Warning --> Use of undefined constant carid - assumed 'carid' (this will throw an Error in a future version of PHP) C:\wamp64\www\crm\application\controllers\Car.php 34
ERROR - 2021-07-17 14:13:45 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 14:13:45 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 14:13:45 --> Final output sent to browser
DEBUG - 2021-07-17 14:13:45 --> Total execution time: 0.2059
INFO - 2021-07-17 14:13:54 --> Config Class Initialized
INFO - 2021-07-17 14:13:54 --> Hooks Class Initialized
DEBUG - 2021-07-17 14:13:54 --> UTF-8 Support Enabled
INFO - 2021-07-17 14:13:54 --> Utf8 Class Initialized
INFO - 2021-07-17 14:13:54 --> URI Class Initialized
INFO - 2021-07-17 14:13:54 --> Router Class Initialized
INFO - 2021-07-17 14:13:54 --> Output Class Initialized
INFO - 2021-07-17 14:13:54 --> Security Class Initialized
DEBUG - 2021-07-17 14:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 14:13:54 --> Input Class Initialized
INFO - 2021-07-17 14:13:54 --> Language Class Initialized
INFO - 2021-07-17 14:13:54 --> Loader Class Initialized
INFO - 2021-07-17 14:13:54 --> Helper loaded: basic_helper
INFO - 2021-07-17 14:13:54 --> Helper loaded: url_helper
INFO - 2021-07-17 14:13:54 --> Helper loaded: file_helper
INFO - 2021-07-17 14:13:54 --> Helper loaded: form_helper
INFO - 2021-07-17 14:13:54 --> Helper loaded: cookie_helper
INFO - 2021-07-17 14:13:54 --> Helper loaded: security_helper
INFO - 2021-07-17 14:13:54 --> Helper loaded: directory_helper
INFO - 2021-07-17 14:13:54 --> Helper loaded: language_helper
INFO - 2021-07-17 14:13:54 --> Helper loaded: general_helper
INFO - 2021-07-17 14:13:54 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 14:13:54 --> Database Driver Class Initialized
DEBUG - 2021-07-17 14:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 14:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 14:13:54 --> Parser Class Initialized
INFO - 2021-07-17 14:13:54 --> Form Validation Class Initialized
INFO - 2021-07-17 14:13:54 --> Upload Class Initialized
INFO - 2021-07-17 14:13:54 --> Email Class Initialized
INFO - 2021-07-17 14:13:54 --> MY_Model class loaded
INFO - 2021-07-17 14:13:54 --> Model "Users_model" initialized
INFO - 2021-07-17 14:13:54 --> Model "Settings_model" initialized
INFO - 2021-07-17 14:13:54 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 14:13:54 --> Model "Permissions_model" initialized
INFO - 2021-07-17 14:13:54 --> Model "Roles_model" initialized
INFO - 2021-07-17 14:13:54 --> Model "Activity_model" initialized
INFO - 2021-07-17 14:13:54 --> Model "Templates_model" initialized
INFO - 2021-07-17 14:13:54 --> Database Driver Class Initialized
INFO - 2021-07-17 14:13:54 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 14:13:54 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 14:13:54 --> Controller Class Initialized
ERROR - 2021-07-17 14:13:54 --> Severity: Warning --> Use of undefined constant carid - assumed 'carid' (this will throw an Error in a future version of PHP) C:\wamp64\www\crm\application\controllers\Car.php 34
ERROR - 2021-07-17 14:13:54 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 14:13:54 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 14:13:54 --> Final output sent to browser
DEBUG - 2021-07-17 14:13:54 --> Total execution time: 0.1425
INFO - 2021-07-17 14:33:50 --> Config Class Initialized
INFO - 2021-07-17 14:33:50 --> Hooks Class Initialized
DEBUG - 2021-07-17 14:33:50 --> UTF-8 Support Enabled
INFO - 2021-07-17 14:33:50 --> Utf8 Class Initialized
INFO - 2021-07-17 14:33:50 --> URI Class Initialized
INFO - 2021-07-17 14:33:50 --> Router Class Initialized
INFO - 2021-07-17 14:33:50 --> Output Class Initialized
INFO - 2021-07-17 14:33:50 --> Security Class Initialized
DEBUG - 2021-07-17 14:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 14:33:50 --> Input Class Initialized
INFO - 2021-07-17 14:33:50 --> Language Class Initialized
INFO - 2021-07-17 14:33:50 --> Loader Class Initialized
INFO - 2021-07-17 14:33:50 --> Helper loaded: basic_helper
INFO - 2021-07-17 14:33:50 --> Helper loaded: url_helper
INFO - 2021-07-17 14:33:50 --> Helper loaded: file_helper
INFO - 2021-07-17 14:33:50 --> Helper loaded: form_helper
INFO - 2021-07-17 14:33:50 --> Helper loaded: cookie_helper
INFO - 2021-07-17 14:33:50 --> Helper loaded: security_helper
INFO - 2021-07-17 14:33:50 --> Helper loaded: directory_helper
INFO - 2021-07-17 14:33:50 --> Helper loaded: language_helper
INFO - 2021-07-17 14:33:50 --> Helper loaded: general_helper
INFO - 2021-07-17 14:33:50 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 14:33:50 --> Database Driver Class Initialized
DEBUG - 2021-07-17 14:33:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 14:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 14:33:50 --> Parser Class Initialized
INFO - 2021-07-17 14:33:50 --> Form Validation Class Initialized
INFO - 2021-07-17 14:33:50 --> Upload Class Initialized
INFO - 2021-07-17 14:33:50 --> Email Class Initialized
INFO - 2021-07-17 14:33:50 --> MY_Model class loaded
INFO - 2021-07-17 14:33:50 --> Model "Users_model" initialized
INFO - 2021-07-17 14:33:50 --> Model "Settings_model" initialized
INFO - 2021-07-17 14:33:50 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 14:33:50 --> Model "Permissions_model" initialized
INFO - 2021-07-17 14:33:50 --> Model "Roles_model" initialized
INFO - 2021-07-17 14:33:50 --> Model "Activity_model" initialized
INFO - 2021-07-17 14:33:50 --> Model "Templates_model" initialized
INFO - 2021-07-17 14:33:50 --> Database Driver Class Initialized
INFO - 2021-07-17 14:33:50 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 14:33:50 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 14:33:50 --> Controller Class Initialized
ERROR - 2021-07-17 14:33:50 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 14:33:50 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 14:33:50 --> Final output sent to browser
DEBUG - 2021-07-17 14:33:50 --> Total execution time: 0.1286
INFO - 2021-07-17 14:33:53 --> Config Class Initialized
INFO - 2021-07-17 14:33:53 --> Hooks Class Initialized
DEBUG - 2021-07-17 14:33:53 --> UTF-8 Support Enabled
INFO - 2021-07-17 14:33:53 --> Utf8 Class Initialized
INFO - 2021-07-17 14:33:53 --> URI Class Initialized
INFO - 2021-07-17 14:33:53 --> Router Class Initialized
INFO - 2021-07-17 14:33:53 --> Output Class Initialized
INFO - 2021-07-17 14:33:53 --> Security Class Initialized
DEBUG - 2021-07-17 14:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 14:33:53 --> Input Class Initialized
INFO - 2021-07-17 14:33:53 --> Language Class Initialized
INFO - 2021-07-17 14:33:53 --> Loader Class Initialized
INFO - 2021-07-17 14:33:53 --> Helper loaded: basic_helper
INFO - 2021-07-17 14:33:53 --> Helper loaded: url_helper
INFO - 2021-07-17 14:33:53 --> Helper loaded: file_helper
INFO - 2021-07-17 14:33:53 --> Helper loaded: form_helper
INFO - 2021-07-17 14:33:53 --> Helper loaded: cookie_helper
INFO - 2021-07-17 14:33:53 --> Helper loaded: security_helper
INFO - 2021-07-17 14:33:53 --> Helper loaded: directory_helper
INFO - 2021-07-17 14:33:53 --> Helper loaded: language_helper
INFO - 2021-07-17 14:33:53 --> Helper loaded: general_helper
INFO - 2021-07-17 14:33:53 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 14:33:53 --> Database Driver Class Initialized
DEBUG - 2021-07-17 14:33:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 14:33:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 14:33:53 --> Parser Class Initialized
INFO - 2021-07-17 14:33:53 --> Form Validation Class Initialized
INFO - 2021-07-17 14:33:53 --> Upload Class Initialized
INFO - 2021-07-17 14:33:53 --> Email Class Initialized
INFO - 2021-07-17 14:33:53 --> MY_Model class loaded
INFO - 2021-07-17 14:33:53 --> Model "Users_model" initialized
INFO - 2021-07-17 14:33:53 --> Model "Settings_model" initialized
INFO - 2021-07-17 14:33:53 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 14:33:53 --> Model "Permissions_model" initialized
INFO - 2021-07-17 14:33:53 --> Model "Roles_model" initialized
INFO - 2021-07-17 14:33:53 --> Model "Activity_model" initialized
INFO - 2021-07-17 14:33:53 --> Model "Templates_model" initialized
INFO - 2021-07-17 14:33:53 --> Database Driver Class Initialized
INFO - 2021-07-17 14:33:53 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 14:33:53 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 14:33:53 --> Controller Class Initialized
ERROR - 2021-07-17 14:33:53 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 14:33:53 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 14:33:53 --> Final output sent to browser
DEBUG - 2021-07-17 14:33:53 --> Total execution time: 0.0693
INFO - 2021-07-17 14:33:54 --> Config Class Initialized
INFO - 2021-07-17 14:33:54 --> Hooks Class Initialized
DEBUG - 2021-07-17 14:33:54 --> UTF-8 Support Enabled
INFO - 2021-07-17 14:33:54 --> Utf8 Class Initialized
INFO - 2021-07-17 14:33:54 --> URI Class Initialized
INFO - 2021-07-17 14:33:54 --> Router Class Initialized
INFO - 2021-07-17 14:33:54 --> Output Class Initialized
INFO - 2021-07-17 14:33:54 --> Security Class Initialized
DEBUG - 2021-07-17 14:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 14:33:54 --> Input Class Initialized
INFO - 2021-07-17 14:33:54 --> Language Class Initialized
INFO - 2021-07-17 14:33:54 --> Loader Class Initialized
INFO - 2021-07-17 14:33:54 --> Helper loaded: basic_helper
INFO - 2021-07-17 14:33:54 --> Helper loaded: url_helper
INFO - 2021-07-17 14:33:54 --> Helper loaded: file_helper
INFO - 2021-07-17 14:33:54 --> Helper loaded: form_helper
INFO - 2021-07-17 14:33:54 --> Helper loaded: cookie_helper
INFO - 2021-07-17 14:33:54 --> Helper loaded: security_helper
INFO - 2021-07-17 14:33:54 --> Helper loaded: directory_helper
INFO - 2021-07-17 14:33:54 --> Helper loaded: language_helper
INFO - 2021-07-17 14:33:54 --> Helper loaded: general_helper
INFO - 2021-07-17 14:33:54 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 14:33:54 --> Database Driver Class Initialized
DEBUG - 2021-07-17 14:33:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 14:33:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 14:33:54 --> Parser Class Initialized
INFO - 2021-07-17 14:33:54 --> Form Validation Class Initialized
INFO - 2021-07-17 14:33:54 --> Upload Class Initialized
INFO - 2021-07-17 14:33:54 --> Email Class Initialized
INFO - 2021-07-17 14:33:54 --> MY_Model class loaded
INFO - 2021-07-17 14:33:54 --> Model "Users_model" initialized
INFO - 2021-07-17 14:33:54 --> Model "Settings_model" initialized
INFO - 2021-07-17 14:33:54 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 14:33:54 --> Model "Permissions_model" initialized
INFO - 2021-07-17 14:33:54 --> Model "Roles_model" initialized
INFO - 2021-07-17 14:33:54 --> Model "Activity_model" initialized
INFO - 2021-07-17 14:33:54 --> Model "Templates_model" initialized
INFO - 2021-07-17 14:33:54 --> Database Driver Class Initialized
INFO - 2021-07-17 14:33:54 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 14:33:54 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 14:33:54 --> Controller Class Initialized
ERROR - 2021-07-17 14:33:54 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 14:33:54 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 14:33:54 --> Final output sent to browser
DEBUG - 2021-07-17 14:33:54 --> Total execution time: 0.0613
INFO - 2021-07-17 14:33:55 --> Config Class Initialized
INFO - 2021-07-17 14:33:55 --> Hooks Class Initialized
DEBUG - 2021-07-17 14:33:55 --> UTF-8 Support Enabled
INFO - 2021-07-17 14:33:55 --> Utf8 Class Initialized
INFO - 2021-07-17 14:33:55 --> URI Class Initialized
INFO - 2021-07-17 14:33:55 --> Router Class Initialized
INFO - 2021-07-17 14:33:55 --> Output Class Initialized
INFO - 2021-07-17 14:33:55 --> Security Class Initialized
DEBUG - 2021-07-17 14:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 14:33:55 --> Input Class Initialized
INFO - 2021-07-17 14:33:55 --> Language Class Initialized
INFO - 2021-07-17 14:33:55 --> Loader Class Initialized
INFO - 2021-07-17 14:33:55 --> Helper loaded: basic_helper
INFO - 2021-07-17 14:33:55 --> Helper loaded: url_helper
INFO - 2021-07-17 14:33:55 --> Helper loaded: file_helper
INFO - 2021-07-17 14:33:55 --> Helper loaded: form_helper
INFO - 2021-07-17 14:33:55 --> Helper loaded: cookie_helper
INFO - 2021-07-17 14:33:55 --> Helper loaded: security_helper
INFO - 2021-07-17 14:33:55 --> Helper loaded: directory_helper
INFO - 2021-07-17 14:33:55 --> Helper loaded: language_helper
INFO - 2021-07-17 14:33:55 --> Helper loaded: general_helper
INFO - 2021-07-17 14:33:55 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 14:33:55 --> Database Driver Class Initialized
DEBUG - 2021-07-17 14:33:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 14:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 14:33:55 --> Parser Class Initialized
INFO - 2021-07-17 14:33:55 --> Form Validation Class Initialized
INFO - 2021-07-17 14:33:55 --> Upload Class Initialized
INFO - 2021-07-17 14:33:55 --> Email Class Initialized
INFO - 2021-07-17 14:33:55 --> MY_Model class loaded
INFO - 2021-07-17 14:33:55 --> Model "Users_model" initialized
INFO - 2021-07-17 14:33:55 --> Model "Settings_model" initialized
INFO - 2021-07-17 14:33:55 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 14:33:55 --> Model "Permissions_model" initialized
INFO - 2021-07-17 14:33:55 --> Model "Roles_model" initialized
INFO - 2021-07-17 14:33:55 --> Model "Activity_model" initialized
INFO - 2021-07-17 14:33:55 --> Model "Templates_model" initialized
INFO - 2021-07-17 14:33:55 --> Database Driver Class Initialized
INFO - 2021-07-17 14:33:55 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 14:33:55 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 14:33:55 --> Controller Class Initialized
ERROR - 2021-07-17 14:33:55 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 14:33:55 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 14:33:55 --> Final output sent to browser
DEBUG - 2021-07-17 14:33:55 --> Total execution time: 0.1253
INFO - 2021-07-17 14:36:13 --> Config Class Initialized
INFO - 2021-07-17 14:36:13 --> Hooks Class Initialized
DEBUG - 2021-07-17 14:36:13 --> UTF-8 Support Enabled
INFO - 2021-07-17 14:36:13 --> Utf8 Class Initialized
INFO - 2021-07-17 14:36:13 --> URI Class Initialized
INFO - 2021-07-17 14:36:13 --> Router Class Initialized
INFO - 2021-07-17 14:36:13 --> Output Class Initialized
INFO - 2021-07-17 14:36:13 --> Security Class Initialized
DEBUG - 2021-07-17 14:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 14:36:13 --> Input Class Initialized
INFO - 2021-07-17 14:36:13 --> Language Class Initialized
INFO - 2021-07-17 14:36:13 --> Loader Class Initialized
INFO - 2021-07-17 14:36:13 --> Helper loaded: basic_helper
INFO - 2021-07-17 14:36:13 --> Helper loaded: url_helper
INFO - 2021-07-17 14:36:13 --> Helper loaded: file_helper
INFO - 2021-07-17 14:36:13 --> Helper loaded: form_helper
INFO - 2021-07-17 14:36:13 --> Helper loaded: cookie_helper
INFO - 2021-07-17 14:36:13 --> Helper loaded: security_helper
INFO - 2021-07-17 14:36:13 --> Helper loaded: directory_helper
INFO - 2021-07-17 14:36:13 --> Helper loaded: language_helper
INFO - 2021-07-17 14:36:13 --> Helper loaded: general_helper
INFO - 2021-07-17 14:36:13 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 14:36:13 --> Database Driver Class Initialized
DEBUG - 2021-07-17 14:36:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 14:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 14:36:13 --> Parser Class Initialized
INFO - 2021-07-17 14:36:13 --> Form Validation Class Initialized
INFO - 2021-07-17 14:36:13 --> Upload Class Initialized
INFO - 2021-07-17 14:36:13 --> Email Class Initialized
INFO - 2021-07-17 14:36:13 --> MY_Model class loaded
INFO - 2021-07-17 14:36:13 --> Model "Users_model" initialized
INFO - 2021-07-17 14:36:13 --> Model "Settings_model" initialized
INFO - 2021-07-17 14:36:13 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 14:36:13 --> Model "Permissions_model" initialized
INFO - 2021-07-17 14:36:13 --> Model "Roles_model" initialized
INFO - 2021-07-17 14:36:13 --> Model "Activity_model" initialized
INFO - 2021-07-17 14:36:13 --> Model "Templates_model" initialized
INFO - 2021-07-17 14:36:13 --> Database Driver Class Initialized
INFO - 2021-07-17 14:36:13 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 14:36:13 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 14:36:13 --> Controller Class Initialized
ERROR - 2021-07-17 14:36:13 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 14:36:13 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 14:36:13 --> Final output sent to browser
DEBUG - 2021-07-17 14:36:13 --> Total execution time: 0.5558
INFO - 2021-07-17 14:53:18 --> Config Class Initialized
INFO - 2021-07-17 14:53:18 --> Hooks Class Initialized
DEBUG - 2021-07-17 14:53:18 --> UTF-8 Support Enabled
INFO - 2021-07-17 14:53:18 --> Utf8 Class Initialized
INFO - 2021-07-17 14:53:18 --> URI Class Initialized
INFO - 2021-07-17 14:53:18 --> Router Class Initialized
INFO - 2021-07-17 14:53:18 --> Output Class Initialized
INFO - 2021-07-17 14:53:18 --> Security Class Initialized
DEBUG - 2021-07-17 14:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 14:53:18 --> Input Class Initialized
INFO - 2021-07-17 14:53:18 --> Language Class Initialized
INFO - 2021-07-17 14:53:18 --> Loader Class Initialized
INFO - 2021-07-17 14:53:18 --> Helper loaded: basic_helper
INFO - 2021-07-17 14:53:18 --> Helper loaded: url_helper
INFO - 2021-07-17 14:53:18 --> Helper loaded: file_helper
INFO - 2021-07-17 14:53:18 --> Helper loaded: form_helper
INFO - 2021-07-17 14:53:18 --> Helper loaded: cookie_helper
INFO - 2021-07-17 14:53:18 --> Helper loaded: security_helper
INFO - 2021-07-17 14:53:18 --> Helper loaded: directory_helper
INFO - 2021-07-17 14:53:18 --> Helper loaded: language_helper
INFO - 2021-07-17 14:53:18 --> Helper loaded: general_helper
INFO - 2021-07-17 14:53:18 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 14:53:18 --> Database Driver Class Initialized
DEBUG - 2021-07-17 14:53:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 14:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 14:53:18 --> Parser Class Initialized
INFO - 2021-07-17 14:53:18 --> Form Validation Class Initialized
INFO - 2021-07-17 14:53:18 --> Upload Class Initialized
INFO - 2021-07-17 14:53:18 --> Email Class Initialized
INFO - 2021-07-17 14:53:18 --> MY_Model class loaded
INFO - 2021-07-17 14:53:18 --> Model "Users_model" initialized
INFO - 2021-07-17 14:53:18 --> Model "Settings_model" initialized
INFO - 2021-07-17 14:53:18 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 14:53:18 --> Model "Permissions_model" initialized
INFO - 2021-07-17 14:53:18 --> Model "Roles_model" initialized
INFO - 2021-07-17 14:53:18 --> Model "Activity_model" initialized
INFO - 2021-07-17 14:53:18 --> Model "Templates_model" initialized
INFO - 2021-07-17 14:53:18 --> Database Driver Class Initialized
INFO - 2021-07-17 14:53:18 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 14:53:18 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 14:53:18 --> Controller Class Initialized
ERROR - 2021-07-17 14:53:18 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 14:53:18 --> File loaded: C:\wamp64\www\crm\application\views\activity_logs/list.php
INFO - 2021-07-17 14:53:18 --> Final output sent to browser
DEBUG - 2021-07-17 14:53:18 --> Total execution time: 0.2766
INFO - 2021-07-17 14:53:20 --> Config Class Initialized
INFO - 2021-07-17 14:53:20 --> Hooks Class Initialized
DEBUG - 2021-07-17 14:53:20 --> UTF-8 Support Enabled
INFO - 2021-07-17 14:53:20 --> Utf8 Class Initialized
INFO - 2021-07-17 14:53:20 --> URI Class Initialized
INFO - 2021-07-17 14:53:20 --> Router Class Initialized
INFO - 2021-07-17 14:53:20 --> Output Class Initialized
INFO - 2021-07-17 14:53:20 --> Security Class Initialized
DEBUG - 2021-07-17 14:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 14:53:20 --> Input Class Initialized
INFO - 2021-07-17 14:53:20 --> Language Class Initialized
INFO - 2021-07-17 14:53:20 --> Loader Class Initialized
INFO - 2021-07-17 14:53:20 --> Helper loaded: basic_helper
INFO - 2021-07-17 14:53:20 --> Helper loaded: url_helper
INFO - 2021-07-17 14:53:20 --> Helper loaded: file_helper
INFO - 2021-07-17 14:53:20 --> Helper loaded: form_helper
INFO - 2021-07-17 14:53:20 --> Helper loaded: cookie_helper
INFO - 2021-07-17 14:53:20 --> Helper loaded: security_helper
INFO - 2021-07-17 14:53:20 --> Helper loaded: directory_helper
INFO - 2021-07-17 14:53:20 --> Helper loaded: language_helper
INFO - 2021-07-17 14:53:20 --> Helper loaded: general_helper
INFO - 2021-07-17 14:53:20 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 14:53:20 --> Database Driver Class Initialized
DEBUG - 2021-07-17 14:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 14:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 14:53:20 --> Parser Class Initialized
INFO - 2021-07-17 14:53:20 --> Form Validation Class Initialized
INFO - 2021-07-17 14:53:20 --> Upload Class Initialized
INFO - 2021-07-17 14:53:20 --> Email Class Initialized
INFO - 2021-07-17 14:53:20 --> MY_Model class loaded
INFO - 2021-07-17 14:53:20 --> Model "Users_model" initialized
INFO - 2021-07-17 14:53:20 --> Model "Settings_model" initialized
INFO - 2021-07-17 14:53:20 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 14:53:20 --> Model "Permissions_model" initialized
INFO - 2021-07-17 14:53:20 --> Model "Roles_model" initialized
INFO - 2021-07-17 14:53:20 --> Model "Activity_model" initialized
INFO - 2021-07-17 14:53:20 --> Model "Templates_model" initialized
INFO - 2021-07-17 14:53:20 --> Database Driver Class Initialized
INFO - 2021-07-17 14:53:20 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 14:53:20 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 14:53:20 --> Controller Class Initialized
ERROR - 2021-07-17 14:53:20 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 14:53:20 --> File loaded: C:\wamp64\www\crm\application\views\users/list.php
INFO - 2021-07-17 14:53:20 --> Final output sent to browser
DEBUG - 2021-07-17 14:53:20 --> Total execution time: 0.1238
INFO - 2021-07-17 14:53:20 --> Config Class Initialized
INFO - 2021-07-17 14:53:20 --> Hooks Class Initialized
DEBUG - 2021-07-17 14:53:20 --> UTF-8 Support Enabled
INFO - 2021-07-17 14:53:20 --> Utf8 Class Initialized
INFO - 2021-07-17 14:53:20 --> URI Class Initialized
INFO - 2021-07-17 14:53:20 --> Router Class Initialized
INFO - 2021-07-17 14:53:20 --> Output Class Initialized
INFO - 2021-07-17 14:53:20 --> Security Class Initialized
INFO - 2021-07-17 14:53:20 --> Config Class Initialized
INFO - 2021-07-17 14:53:20 --> Hooks Class Initialized
DEBUG - 2021-07-17 14:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 14:53:20 --> Input Class Initialized
DEBUG - 2021-07-17 14:53:20 --> UTF-8 Support Enabled
INFO - 2021-07-17 14:53:20 --> Language Class Initialized
INFO - 2021-07-17 14:53:20 --> Utf8 Class Initialized
INFO - 2021-07-17 14:53:20 --> URI Class Initialized
INFO - 2021-07-17 14:53:20 --> Loader Class Initialized
INFO - 2021-07-17 14:53:20 --> Config Class Initialized
INFO - 2021-07-17 14:53:20 --> Hooks Class Initialized
INFO - 2021-07-17 14:53:20 --> Router Class Initialized
INFO - 2021-07-17 14:53:20 --> Helper loaded: basic_helper
DEBUG - 2021-07-17 14:53:20 --> UTF-8 Support Enabled
INFO - 2021-07-17 14:53:20 --> Output Class Initialized
INFO - 2021-07-17 14:53:20 --> Helper loaded: url_helper
INFO - 2021-07-17 14:53:20 --> Utf8 Class Initialized
INFO - 2021-07-17 14:53:20 --> Security Class Initialized
INFO - 2021-07-17 14:53:20 --> Helper loaded: file_helper
INFO - 2021-07-17 14:53:20 --> URI Class Initialized
DEBUG - 2021-07-17 14:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 14:53:20 --> Helper loaded: form_helper
INFO - 2021-07-17 14:53:20 --> Input Class Initialized
INFO - 2021-07-17 14:53:20 --> Router Class Initialized
INFO - 2021-07-17 14:53:20 --> Helper loaded: cookie_helper
INFO - 2021-07-17 14:53:20 --> Language Class Initialized
INFO - 2021-07-17 14:53:20 --> Output Class Initialized
INFO - 2021-07-17 14:53:20 --> Helper loaded: security_helper
INFO - 2021-07-17 14:53:20 --> Loader Class Initialized
INFO - 2021-07-17 14:53:20 --> Config Class Initialized
INFO - 2021-07-17 14:53:20 --> Security Class Initialized
INFO - 2021-07-17 14:53:20 --> Helper loaded: directory_helper
INFO - 2021-07-17 14:53:20 --> Hooks Class Initialized
INFO - 2021-07-17 14:53:20 --> Helper loaded: basic_helper
DEBUG - 2021-07-17 14:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 14:53:20 --> Helper loaded: language_helper
DEBUG - 2021-07-17 14:53:20 --> UTF-8 Support Enabled
INFO - 2021-07-17 14:53:20 --> Helper loaded: url_helper
INFO - 2021-07-17 14:53:20 --> Input Class Initialized
INFO - 2021-07-17 14:53:20 --> Utf8 Class Initialized
INFO - 2021-07-17 14:53:20 --> Helper loaded: general_helper
INFO - 2021-07-17 14:53:20 --> Helper loaded: file_helper
INFO - 2021-07-17 14:53:20 --> Language Class Initialized
INFO - 2021-07-17 14:53:20 --> URI Class Initialized
INFO - 2021-07-17 14:53:20 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 14:53:20 --> Helper loaded: form_helper
INFO - 2021-07-17 14:53:20 --> Loader Class Initialized
INFO - 2021-07-17 14:53:20 --> Database Driver Class Initialized
INFO - 2021-07-17 14:53:20 --> Router Class Initialized
INFO - 2021-07-17 14:53:20 --> Helper loaded: cookie_helper
INFO - 2021-07-17 14:53:20 --> Config Class Initialized
INFO - 2021-07-17 14:53:20 --> Helper loaded: basic_helper
INFO - 2021-07-17 14:53:20 --> Hooks Class Initialized
INFO - 2021-07-17 14:53:20 --> Output Class Initialized
INFO - 2021-07-17 14:53:20 --> Helper loaded: security_helper
INFO - 2021-07-17 14:53:20 --> Helper loaded: url_helper
INFO - 2021-07-17 14:53:20 --> Security Class Initialized
INFO - 2021-07-17 14:53:20 --> Helper loaded: directory_helper
DEBUG - 2021-07-17 14:53:20 --> UTF-8 Support Enabled
INFO - 2021-07-17 14:53:20 --> Helper loaded: file_helper
INFO - 2021-07-17 14:53:20 --> Config Class Initialized
INFO - 2021-07-17 14:53:20 --> Utf8 Class Initialized
DEBUG - 2021-07-17 14:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 14:53:20 --> Helper loaded: language_helper
INFO - 2021-07-17 14:53:20 --> Hooks Class Initialized
DEBUG - 2021-07-17 14:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 14:53:20 --> Helper loaded: form_helper
INFO - 2021-07-17 14:53:20 --> Input Class Initialized
INFO - 2021-07-17 14:53:20 --> URI Class Initialized
INFO - 2021-07-17 14:53:20 --> Helper loaded: general_helper
DEBUG - 2021-07-17 14:53:20 --> UTF-8 Support Enabled
INFO - 2021-07-17 14:53:20 --> Language Class Initialized
INFO - 2021-07-17 14:53:20 --> Helper loaded: cookie_helper
INFO - 2021-07-17 14:53:20 --> Utf8 Class Initialized
INFO - 2021-07-17 14:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 14:53:20 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 14:53:20 --> Router Class Initialized
INFO - 2021-07-17 14:53:20 --> Helper loaded: security_helper
INFO - 2021-07-17 14:53:20 --> Loader Class Initialized
INFO - 2021-07-17 14:53:20 --> URI Class Initialized
INFO - 2021-07-17 14:53:20 --> Parser Class Initialized
INFO - 2021-07-17 14:53:20 --> Output Class Initialized
INFO - 2021-07-17 14:53:20 --> Helper loaded: directory_helper
INFO - 2021-07-17 14:53:20 --> Database Driver Class Initialized
INFO - 2021-07-17 14:53:20 --> Helper loaded: basic_helper
INFO - 2021-07-17 14:53:20 --> Security Class Initialized
INFO - 2021-07-17 14:53:20 --> Router Class Initialized
INFO - 2021-07-17 14:53:20 --> Helper loaded: language_helper
INFO - 2021-07-17 14:53:20 --> Form Validation Class Initialized
INFO - 2021-07-17 14:53:20 --> Helper loaded: url_helper
DEBUG - 2021-07-17 14:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 14:53:20 --> Helper loaded: general_helper
INFO - 2021-07-17 14:53:20 --> Output Class Initialized
INFO - 2021-07-17 14:53:20 --> Input Class Initialized
INFO - 2021-07-17 14:53:20 --> Helper loaded: file_helper
INFO - 2021-07-17 14:53:20 --> Upload Class Initialized
INFO - 2021-07-17 14:53:20 --> Security Class Initialized
INFO - 2021-07-17 14:53:20 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 14:53:20 --> Language Class Initialized
INFO - 2021-07-17 14:53:20 --> Helper loaded: form_helper
DEBUG - 2021-07-17 14:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 14:53:20 --> Email Class Initialized
DEBUG - 2021-07-17 14:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 14:53:20 --> Database Driver Class Initialized
INFO - 2021-07-17 14:53:20 --> Helper loaded: cookie_helper
INFO - 2021-07-17 14:53:20 --> Input Class Initialized
INFO - 2021-07-17 14:53:20 --> Loader Class Initialized
INFO - 2021-07-17 14:53:20 --> MY_Model class loaded
INFO - 2021-07-17 14:53:20 --> Helper loaded: security_helper
INFO - 2021-07-17 14:53:20 --> Language Class Initialized
INFO - 2021-07-17 14:53:20 --> Model "Users_model" initialized
INFO - 2021-07-17 14:53:20 --> Helper loaded: basic_helper
INFO - 2021-07-17 14:53:20 --> Helper loaded: directory_helper
INFO - 2021-07-17 14:53:20 --> Model "Settings_model" initialized
INFO - 2021-07-17 14:53:20 --> Loader Class Initialized
INFO - 2021-07-17 14:53:20 --> Helper loaded: url_helper
INFO - 2021-07-17 14:53:20 --> Helper loaded: language_helper
INFO - 2021-07-17 14:53:20 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 14:53:20 --> Helper loaded: basic_helper
INFO - 2021-07-17 14:53:20 --> Helper loaded: file_helper
INFO - 2021-07-17 14:53:20 --> Model "Permissions_model" initialized
INFO - 2021-07-17 14:53:20 --> Helper loaded: general_helper
DEBUG - 2021-07-17 14:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 14:53:20 --> Helper loaded: url_helper
INFO - 2021-07-17 14:53:20 --> Model "Roles_model" initialized
INFO - 2021-07-17 14:53:20 --> Helper loaded: form_helper
INFO - 2021-07-17 14:53:20 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 14:53:20 --> Model "Activity_model" initialized
INFO - 2021-07-17 14:53:20 --> Helper loaded: file_helper
INFO - 2021-07-17 14:53:20 --> Helper loaded: cookie_helper
INFO - 2021-07-17 14:53:20 --> Database Driver Class Initialized
INFO - 2021-07-17 14:53:20 --> Model "Templates_model" initialized
INFO - 2021-07-17 14:53:20 --> Helper loaded: form_helper
INFO - 2021-07-17 14:53:20 --> Helper loaded: security_helper
INFO - 2021-07-17 14:53:20 --> Helper loaded: cookie_helper
INFO - 2021-07-17 14:53:20 --> Database Driver Class Initialized
INFO - 2021-07-17 14:53:20 --> Helper loaded: directory_helper
INFO - 2021-07-17 14:53:20 --> Helper loaded: security_helper
INFO - 2021-07-17 14:53:20 --> Helper loaded: language_helper
INFO - 2021-07-17 14:53:20 --> Helper loaded: directory_helper
INFO - 2021-07-17 14:53:20 --> Helper loaded: general_helper
INFO - 2021-07-17 14:53:20 --> Helper loaded: language_helper
DEBUG - 2021-07-17 14:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 14:53:20 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 14:53:20 --> Helper loaded: general_helper
INFO - 2021-07-17 14:53:20 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 14:53:20 --> Database Driver Class Initialized
INFO - 2021-07-17 14:53:20 --> Database Driver Class Initialized
DEBUG - 2021-07-17 14:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-07-17 14:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 14:53:20 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 14:53:20 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 14:53:20 --> Controller Class Initialized
INFO - 2021-07-17 14:53:20 --> Final output sent to browser
DEBUG - 2021-07-17 14:53:20 --> Total execution time: 0.0633
INFO - 2021-07-17 14:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 14:53:20 --> Parser Class Initialized
INFO - 2021-07-17 14:53:20 --> Form Validation Class Initialized
INFO - 2021-07-17 14:53:20 --> Upload Class Initialized
INFO - 2021-07-17 14:53:20 --> Email Class Initialized
INFO - 2021-07-17 14:53:20 --> MY_Model class loaded
INFO - 2021-07-17 14:53:20 --> Model "Users_model" initialized
INFO - 2021-07-17 14:53:20 --> Model "Settings_model" initialized
INFO - 2021-07-17 14:53:20 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 14:53:20 --> Model "Permissions_model" initialized
INFO - 2021-07-17 14:53:20 --> Model "Roles_model" initialized
INFO - 2021-07-17 14:53:20 --> Model "Activity_model" initialized
INFO - 2021-07-17 14:53:20 --> Model "Templates_model" initialized
INFO - 2021-07-17 14:53:20 --> Config Class Initialized
INFO - 2021-07-17 14:53:20 --> Database Driver Class Initialized
INFO - 2021-07-17 14:53:20 --> Hooks Class Initialized
DEBUG - 2021-07-17 14:53:20 --> UTF-8 Support Enabled
INFO - 2021-07-17 14:53:20 --> Utf8 Class Initialized
INFO - 2021-07-17 14:53:20 --> URI Class Initialized
INFO - 2021-07-17 14:53:20 --> Router Class Initialized
INFO - 2021-07-17 14:53:20 --> Output Class Initialized
INFO - 2021-07-17 14:53:20 --> Security Class Initialized
DEBUG - 2021-07-17 14:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 14:53:20 --> Input Class Initialized
INFO - 2021-07-17 14:53:20 --> Language Class Initialized
INFO - 2021-07-17 14:53:20 --> Loader Class Initialized
INFO - 2021-07-17 14:53:20 --> Helper loaded: basic_helper
INFO - 2021-07-17 14:53:20 --> Helper loaded: url_helper
INFO - 2021-07-17 14:53:20 --> Helper loaded: file_helper
INFO - 2021-07-17 14:53:20 --> Helper loaded: form_helper
INFO - 2021-07-17 14:53:20 --> Helper loaded: cookie_helper
INFO - 2021-07-17 14:53:20 --> Helper loaded: security_helper
INFO - 2021-07-17 14:53:20 --> Helper loaded: directory_helper
INFO - 2021-07-17 14:53:20 --> Helper loaded: language_helper
INFO - 2021-07-17 14:53:20 --> Helper loaded: general_helper
INFO - 2021-07-17 14:53:20 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 14:53:20 --> Database Driver Class Initialized
INFO - 2021-07-17 14:53:20 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 14:53:20 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 14:53:20 --> Controller Class Initialized
INFO - 2021-07-17 14:53:20 --> Final output sent to browser
DEBUG - 2021-07-17 14:53:20 --> Total execution time: 0.0983
INFO - 2021-07-17 14:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 14:53:20 --> Parser Class Initialized
INFO - 2021-07-17 14:53:20 --> Form Validation Class Initialized
INFO - 2021-07-17 14:53:20 --> Upload Class Initialized
INFO - 2021-07-17 14:53:20 --> Email Class Initialized
INFO - 2021-07-17 14:53:20 --> MY_Model class loaded
DEBUG - 2021-07-17 14:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 14:53:20 --> Model "Users_model" initialized
INFO - 2021-07-17 14:53:20 --> Model "Settings_model" initialized
INFO - 2021-07-17 14:53:20 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 14:53:20 --> Model "Permissions_model" initialized
INFO - 2021-07-17 14:53:20 --> Config Class Initialized
INFO - 2021-07-17 14:53:20 --> Model "Roles_model" initialized
INFO - 2021-07-17 14:53:20 --> Hooks Class Initialized
INFO - 2021-07-17 14:53:20 --> Model "Activity_model" initialized
DEBUG - 2021-07-17 14:53:20 --> UTF-8 Support Enabled
INFO - 2021-07-17 14:53:20 --> Model "Templates_model" initialized
INFO - 2021-07-17 14:53:20 --> Utf8 Class Initialized
INFO - 2021-07-17 14:53:20 --> Database Driver Class Initialized
INFO - 2021-07-17 14:53:20 --> URI Class Initialized
INFO - 2021-07-17 14:53:20 --> Router Class Initialized
INFO - 2021-07-17 14:53:20 --> Output Class Initialized
INFO - 2021-07-17 14:53:20 --> Security Class Initialized
DEBUG - 2021-07-17 14:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 14:53:20 --> Input Class Initialized
INFO - 2021-07-17 14:53:20 --> Language Class Initialized
INFO - 2021-07-17 14:53:20 --> Loader Class Initialized
INFO - 2021-07-17 14:53:20 --> Helper loaded: basic_helper
INFO - 2021-07-17 14:53:20 --> Helper loaded: url_helper
INFO - 2021-07-17 14:53:20 --> Helper loaded: file_helper
INFO - 2021-07-17 14:53:20 --> Helper loaded: form_helper
INFO - 2021-07-17 14:53:20 --> Helper loaded: cookie_helper
INFO - 2021-07-17 14:53:20 --> Helper loaded: security_helper
INFO - 2021-07-17 14:53:20 --> Helper loaded: directory_helper
INFO - 2021-07-17 14:53:20 --> Helper loaded: language_helper
INFO - 2021-07-17 14:53:20 --> Helper loaded: general_helper
INFO - 2021-07-17 14:53:20 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 14:53:20 --> Database Driver Class Initialized
DEBUG - 2021-07-17 14:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 14:53:20 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 14:53:20 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 14:53:20 --> Controller Class Initialized
INFO - 2021-07-17 14:53:20 --> Final output sent to browser
DEBUG - 2021-07-17 14:53:20 --> Total execution time: 0.1255
INFO - 2021-07-17 14:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 14:53:20 --> Parser Class Initialized
INFO - 2021-07-17 14:53:20 --> Form Validation Class Initialized
INFO - 2021-07-17 14:53:20 --> Upload Class Initialized
INFO - 2021-07-17 14:53:20 --> Email Class Initialized
INFO - 2021-07-17 14:53:20 --> MY_Model class loaded
INFO - 2021-07-17 14:53:20 --> Model "Users_model" initialized
INFO - 2021-07-17 14:53:20 --> Model "Settings_model" initialized
INFO - 2021-07-17 14:53:20 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 14:53:20 --> Model "Permissions_model" initialized
INFO - 2021-07-17 14:53:20 --> Model "Roles_model" initialized
INFO - 2021-07-17 14:53:20 --> Config Class Initialized
INFO - 2021-07-17 14:53:20 --> Model "Activity_model" initialized
INFO - 2021-07-17 14:53:20 --> Hooks Class Initialized
INFO - 2021-07-17 14:53:20 --> Model "Templates_model" initialized
DEBUG - 2021-07-17 14:53:20 --> UTF-8 Support Enabled
INFO - 2021-07-17 14:53:20 --> Utf8 Class Initialized
INFO - 2021-07-17 14:53:20 --> Database Driver Class Initialized
INFO - 2021-07-17 14:53:20 --> URI Class Initialized
INFO - 2021-07-17 14:53:20 --> Router Class Initialized
INFO - 2021-07-17 14:53:20 --> Output Class Initialized
INFO - 2021-07-17 14:53:20 --> Security Class Initialized
DEBUG - 2021-07-17 14:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 14:53:20 --> Input Class Initialized
INFO - 2021-07-17 14:53:20 --> Language Class Initialized
INFO - 2021-07-17 14:53:20 --> Loader Class Initialized
INFO - 2021-07-17 14:53:20 --> Helper loaded: basic_helper
INFO - 2021-07-17 14:53:20 --> Helper loaded: url_helper
INFO - 2021-07-17 14:53:20 --> Helper loaded: file_helper
INFO - 2021-07-17 14:53:20 --> Helper loaded: form_helper
INFO - 2021-07-17 14:53:20 --> Helper loaded: cookie_helper
INFO - 2021-07-17 14:53:20 --> Helper loaded: security_helper
INFO - 2021-07-17 14:53:20 --> Helper loaded: directory_helper
INFO - 2021-07-17 14:53:20 --> Helper loaded: language_helper
INFO - 2021-07-17 14:53:20 --> Helper loaded: general_helper
INFO - 2021-07-17 14:53:20 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 14:53:20 --> Database Driver Class Initialized
DEBUG - 2021-07-17 14:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 14:53:20 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 14:53:20 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 14:53:20 --> Controller Class Initialized
INFO - 2021-07-17 14:53:20 --> Final output sent to browser
DEBUG - 2021-07-17 14:53:20 --> Total execution time: 0.1491
INFO - 2021-07-17 14:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 14:53:20 --> Parser Class Initialized
INFO - 2021-07-17 14:53:20 --> Form Validation Class Initialized
INFO - 2021-07-17 14:53:20 --> Upload Class Initialized
INFO - 2021-07-17 14:53:20 --> Email Class Initialized
INFO - 2021-07-17 14:53:20 --> MY_Model class loaded
INFO - 2021-07-17 14:53:20 --> Model "Users_model" initialized
INFO - 2021-07-17 14:53:20 --> Model "Settings_model" initialized
INFO - 2021-07-17 14:53:20 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 14:53:20 --> Model "Permissions_model" initialized
INFO - 2021-07-17 14:53:20 --> Model "Roles_model" initialized
INFO - 2021-07-17 14:53:20 --> Model "Activity_model" initialized
INFO - 2021-07-17 14:53:20 --> Model "Templates_model" initialized
INFO - 2021-07-17 14:53:20 --> Database Driver Class Initialized
INFO - 2021-07-17 14:53:21 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 14:53:21 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 14:53:21 --> Controller Class Initialized
INFO - 2021-07-17 14:53:21 --> Final output sent to browser
DEBUG - 2021-07-17 14:53:21 --> Total execution time: 0.1731
INFO - 2021-07-17 14:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 14:53:21 --> Parser Class Initialized
INFO - 2021-07-17 14:53:21 --> Form Validation Class Initialized
INFO - 2021-07-17 14:53:21 --> Upload Class Initialized
INFO - 2021-07-17 14:53:21 --> Email Class Initialized
INFO - 2021-07-17 14:53:21 --> MY_Model class loaded
INFO - 2021-07-17 14:53:21 --> Model "Users_model" initialized
INFO - 2021-07-17 14:53:21 --> Model "Settings_model" initialized
INFO - 2021-07-17 14:53:21 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 14:53:21 --> Model "Permissions_model" initialized
INFO - 2021-07-17 14:53:21 --> Model "Roles_model" initialized
INFO - 2021-07-17 14:53:21 --> Model "Activity_model" initialized
INFO - 2021-07-17 14:53:21 --> Model "Templates_model" initialized
INFO - 2021-07-17 14:53:21 --> Database Driver Class Initialized
INFO - 2021-07-17 14:53:21 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 14:53:21 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 14:53:21 --> Controller Class Initialized
INFO - 2021-07-17 14:53:21 --> Final output sent to browser
DEBUG - 2021-07-17 14:53:21 --> Total execution time: 0.1991
INFO - 2021-07-17 14:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 14:53:21 --> Parser Class Initialized
INFO - 2021-07-17 14:53:21 --> Form Validation Class Initialized
INFO - 2021-07-17 14:53:21 --> Upload Class Initialized
INFO - 2021-07-17 14:53:21 --> Email Class Initialized
INFO - 2021-07-17 14:53:21 --> MY_Model class loaded
INFO - 2021-07-17 14:53:21 --> Model "Users_model" initialized
INFO - 2021-07-17 14:53:21 --> Model "Settings_model" initialized
INFO - 2021-07-17 14:53:21 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 14:53:21 --> Model "Permissions_model" initialized
INFO - 2021-07-17 14:53:21 --> Model "Roles_model" initialized
INFO - 2021-07-17 14:53:21 --> Model "Activity_model" initialized
INFO - 2021-07-17 14:53:21 --> Model "Templates_model" initialized
INFO - 2021-07-17 14:53:21 --> Database Driver Class Initialized
INFO - 2021-07-17 14:53:21 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 14:53:21 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 14:53:21 --> Controller Class Initialized
INFO - 2021-07-17 14:53:21 --> Final output sent to browser
DEBUG - 2021-07-17 14:53:21 --> Total execution time: 0.1779
INFO - 2021-07-17 14:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 14:53:21 --> Parser Class Initialized
INFO - 2021-07-17 14:53:21 --> Form Validation Class Initialized
INFO - 2021-07-17 14:53:21 --> Upload Class Initialized
INFO - 2021-07-17 14:53:21 --> Email Class Initialized
INFO - 2021-07-17 14:53:21 --> MY_Model class loaded
INFO - 2021-07-17 14:53:21 --> Model "Users_model" initialized
INFO - 2021-07-17 14:53:21 --> Model "Settings_model" initialized
INFO - 2021-07-17 14:53:21 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 14:53:21 --> Model "Permissions_model" initialized
INFO - 2021-07-17 14:53:21 --> Model "Roles_model" initialized
INFO - 2021-07-17 14:53:21 --> Model "Activity_model" initialized
INFO - 2021-07-17 14:53:21 --> Model "Templates_model" initialized
INFO - 2021-07-17 14:53:21 --> Database Driver Class Initialized
INFO - 2021-07-17 14:53:21 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 14:53:21 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 14:53:21 --> Controller Class Initialized
INFO - 2021-07-17 14:53:21 --> Final output sent to browser
DEBUG - 2021-07-17 14:53:21 --> Total execution time: 0.1669
INFO - 2021-07-17 14:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 14:53:21 --> Parser Class Initialized
INFO - 2021-07-17 14:53:21 --> Form Validation Class Initialized
INFO - 2021-07-17 14:53:21 --> Upload Class Initialized
INFO - 2021-07-17 14:53:21 --> Email Class Initialized
INFO - 2021-07-17 14:53:21 --> MY_Model class loaded
INFO - 2021-07-17 14:53:21 --> Model "Users_model" initialized
INFO - 2021-07-17 14:53:21 --> Model "Settings_model" initialized
INFO - 2021-07-17 14:53:21 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 14:53:21 --> Model "Permissions_model" initialized
INFO - 2021-07-17 14:53:21 --> Model "Roles_model" initialized
INFO - 2021-07-17 14:53:21 --> Model "Activity_model" initialized
INFO - 2021-07-17 14:53:21 --> Model "Templates_model" initialized
INFO - 2021-07-17 14:53:21 --> Database Driver Class Initialized
INFO - 2021-07-17 14:53:21 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 14:53:21 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 14:53:21 --> Controller Class Initialized
INFO - 2021-07-17 14:53:21 --> Final output sent to browser
DEBUG - 2021-07-17 14:53:21 --> Total execution time: 0.1646
INFO - 2021-07-17 14:53:22 --> Config Class Initialized
INFO - 2021-07-17 14:53:22 --> Hooks Class Initialized
DEBUG - 2021-07-17 14:53:22 --> UTF-8 Support Enabled
INFO - 2021-07-17 14:53:22 --> Utf8 Class Initialized
INFO - 2021-07-17 14:53:22 --> URI Class Initialized
INFO - 2021-07-17 14:53:22 --> Router Class Initialized
INFO - 2021-07-17 14:53:22 --> Output Class Initialized
INFO - 2021-07-17 14:53:22 --> Security Class Initialized
DEBUG - 2021-07-17 14:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 14:53:22 --> Input Class Initialized
INFO - 2021-07-17 14:53:22 --> Language Class Initialized
INFO - 2021-07-17 14:53:22 --> Loader Class Initialized
INFO - 2021-07-17 14:53:22 --> Helper loaded: basic_helper
INFO - 2021-07-17 14:53:22 --> Helper loaded: url_helper
INFO - 2021-07-17 14:53:22 --> Helper loaded: file_helper
INFO - 2021-07-17 14:53:22 --> Helper loaded: form_helper
INFO - 2021-07-17 14:53:22 --> Helper loaded: cookie_helper
INFO - 2021-07-17 14:53:22 --> Helper loaded: security_helper
INFO - 2021-07-17 14:53:22 --> Helper loaded: directory_helper
INFO - 2021-07-17 14:53:22 --> Helper loaded: language_helper
INFO - 2021-07-17 14:53:22 --> Helper loaded: general_helper
INFO - 2021-07-17 14:53:22 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 14:53:22 --> Database Driver Class Initialized
DEBUG - 2021-07-17 14:53:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 14:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 14:53:22 --> Parser Class Initialized
INFO - 2021-07-17 14:53:22 --> Form Validation Class Initialized
INFO - 2021-07-17 14:53:22 --> Upload Class Initialized
INFO - 2021-07-17 14:53:22 --> Email Class Initialized
INFO - 2021-07-17 14:53:22 --> MY_Model class loaded
INFO - 2021-07-17 14:53:22 --> Model "Users_model" initialized
INFO - 2021-07-17 14:53:22 --> Model "Settings_model" initialized
INFO - 2021-07-17 14:53:22 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 14:53:22 --> Model "Permissions_model" initialized
INFO - 2021-07-17 14:53:22 --> Model "Roles_model" initialized
INFO - 2021-07-17 14:53:22 --> Model "Activity_model" initialized
INFO - 2021-07-17 14:53:22 --> Model "Templates_model" initialized
INFO - 2021-07-17 14:53:22 --> Database Driver Class Initialized
INFO - 2021-07-17 14:53:22 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 14:53:22 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 14:53:22 --> Controller Class Initialized
ERROR - 2021-07-17 14:53:22 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 14:53:22 --> File loaded: C:\wamp64\www\crm\application\views\roles/list.php
INFO - 2021-07-17 14:53:22 --> Final output sent to browser
DEBUG - 2021-07-17 14:53:22 --> Total execution time: 0.0841
INFO - 2021-07-17 14:53:23 --> Config Class Initialized
INFO - 2021-07-17 14:53:23 --> Hooks Class Initialized
DEBUG - 2021-07-17 14:53:23 --> UTF-8 Support Enabled
INFO - 2021-07-17 14:53:23 --> Utf8 Class Initialized
INFO - 2021-07-17 14:53:23 --> URI Class Initialized
INFO - 2021-07-17 14:53:23 --> Router Class Initialized
INFO - 2021-07-17 14:53:23 --> Output Class Initialized
INFO - 2021-07-17 14:53:23 --> Security Class Initialized
DEBUG - 2021-07-17 14:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 14:53:23 --> Input Class Initialized
INFO - 2021-07-17 14:53:23 --> Language Class Initialized
INFO - 2021-07-17 14:53:23 --> Loader Class Initialized
INFO - 2021-07-17 14:53:23 --> Helper loaded: basic_helper
INFO - 2021-07-17 14:53:23 --> Helper loaded: url_helper
INFO - 2021-07-17 14:53:23 --> Helper loaded: file_helper
INFO - 2021-07-17 14:53:23 --> Helper loaded: form_helper
INFO - 2021-07-17 14:53:23 --> Helper loaded: cookie_helper
INFO - 2021-07-17 14:53:23 --> Helper loaded: security_helper
INFO - 2021-07-17 14:53:23 --> Helper loaded: directory_helper
INFO - 2021-07-17 14:53:23 --> Helper loaded: language_helper
INFO - 2021-07-17 14:53:23 --> Helper loaded: general_helper
INFO - 2021-07-17 14:53:23 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 14:53:23 --> Database Driver Class Initialized
DEBUG - 2021-07-17 14:53:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 14:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 14:53:23 --> Parser Class Initialized
INFO - 2021-07-17 14:53:23 --> Form Validation Class Initialized
INFO - 2021-07-17 14:53:23 --> Upload Class Initialized
INFO - 2021-07-17 14:53:23 --> Email Class Initialized
INFO - 2021-07-17 14:53:23 --> MY_Model class loaded
INFO - 2021-07-17 14:53:23 --> Model "Users_model" initialized
INFO - 2021-07-17 14:53:23 --> Model "Settings_model" initialized
INFO - 2021-07-17 14:53:23 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 14:53:23 --> Model "Permissions_model" initialized
INFO - 2021-07-17 14:53:23 --> Model "Roles_model" initialized
INFO - 2021-07-17 14:53:23 --> Model "Activity_model" initialized
INFO - 2021-07-17 14:53:23 --> Model "Templates_model" initialized
INFO - 2021-07-17 14:53:23 --> Database Driver Class Initialized
INFO - 2021-07-17 14:53:23 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 14:53:23 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 14:53:23 --> Controller Class Initialized
ERROR - 2021-07-17 14:53:23 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 14:53:23 --> File loaded: C:\wamp64\www\crm\application\views\permissions/list.php
INFO - 2021-07-17 14:53:23 --> Final output sent to browser
DEBUG - 2021-07-17 14:53:23 --> Total execution time: 0.1702
INFO - 2021-07-17 14:53:25 --> Config Class Initialized
INFO - 2021-07-17 14:53:25 --> Hooks Class Initialized
DEBUG - 2021-07-17 14:53:25 --> UTF-8 Support Enabled
INFO - 2021-07-17 14:53:25 --> Utf8 Class Initialized
INFO - 2021-07-17 14:53:25 --> URI Class Initialized
INFO - 2021-07-17 14:53:25 --> Router Class Initialized
INFO - 2021-07-17 14:53:25 --> Output Class Initialized
INFO - 2021-07-17 14:53:25 --> Security Class Initialized
DEBUG - 2021-07-17 14:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 14:53:25 --> Input Class Initialized
INFO - 2021-07-17 14:53:25 --> Language Class Initialized
INFO - 2021-07-17 14:53:25 --> Loader Class Initialized
INFO - 2021-07-17 14:53:25 --> Helper loaded: basic_helper
INFO - 2021-07-17 14:53:25 --> Helper loaded: url_helper
INFO - 2021-07-17 14:53:25 --> Helper loaded: file_helper
INFO - 2021-07-17 14:53:25 --> Helper loaded: form_helper
INFO - 2021-07-17 14:53:25 --> Helper loaded: cookie_helper
INFO - 2021-07-17 14:53:25 --> Helper loaded: security_helper
INFO - 2021-07-17 14:53:25 --> Helper loaded: directory_helper
INFO - 2021-07-17 14:53:25 --> Helper loaded: language_helper
INFO - 2021-07-17 14:53:25 --> Helper loaded: general_helper
INFO - 2021-07-17 14:53:25 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 14:53:25 --> Database Driver Class Initialized
DEBUG - 2021-07-17 14:53:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 14:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 14:53:25 --> Parser Class Initialized
INFO - 2021-07-17 14:53:25 --> Form Validation Class Initialized
INFO - 2021-07-17 14:53:25 --> Upload Class Initialized
INFO - 2021-07-17 14:53:25 --> Email Class Initialized
INFO - 2021-07-17 14:53:25 --> MY_Model class loaded
INFO - 2021-07-17 14:53:25 --> Model "Users_model" initialized
INFO - 2021-07-17 14:53:25 --> Model "Settings_model" initialized
INFO - 2021-07-17 14:53:25 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 14:53:25 --> Model "Permissions_model" initialized
INFO - 2021-07-17 14:53:25 --> Model "Roles_model" initialized
INFO - 2021-07-17 14:53:25 --> Model "Activity_model" initialized
INFO - 2021-07-17 14:53:25 --> Model "Templates_model" initialized
INFO - 2021-07-17 14:53:25 --> Database Driver Class Initialized
INFO - 2021-07-17 14:53:25 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 14:53:25 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 14:53:25 --> Controller Class Initialized
ERROR - 2021-07-17 14:53:25 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 14:53:25 --> File loaded: C:\wamp64\www\crm\application\views\settings/general.php
INFO - 2021-07-17 14:53:25 --> Final output sent to browser
DEBUG - 2021-07-17 14:53:25 --> Total execution time: 0.1784
INFO - 2021-07-17 14:53:28 --> Config Class Initialized
INFO - 2021-07-17 14:53:28 --> Hooks Class Initialized
DEBUG - 2021-07-17 14:53:28 --> UTF-8 Support Enabled
INFO - 2021-07-17 14:53:28 --> Utf8 Class Initialized
INFO - 2021-07-17 14:53:28 --> URI Class Initialized
INFO - 2021-07-17 14:53:28 --> Router Class Initialized
INFO - 2021-07-17 14:53:28 --> Output Class Initialized
INFO - 2021-07-17 14:53:28 --> Security Class Initialized
DEBUG - 2021-07-17 14:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 14:53:28 --> Input Class Initialized
INFO - 2021-07-17 14:53:28 --> Language Class Initialized
INFO - 2021-07-17 14:53:28 --> Loader Class Initialized
INFO - 2021-07-17 14:53:28 --> Helper loaded: basic_helper
INFO - 2021-07-17 14:53:28 --> Helper loaded: url_helper
INFO - 2021-07-17 14:53:28 --> Helper loaded: file_helper
INFO - 2021-07-17 14:53:28 --> Helper loaded: form_helper
INFO - 2021-07-17 14:53:28 --> Helper loaded: cookie_helper
INFO - 2021-07-17 14:53:28 --> Helper loaded: security_helper
INFO - 2021-07-17 14:53:28 --> Helper loaded: directory_helper
INFO - 2021-07-17 14:53:28 --> Helper loaded: language_helper
INFO - 2021-07-17 14:53:28 --> Helper loaded: general_helper
INFO - 2021-07-17 14:53:28 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 14:53:28 --> Database Driver Class Initialized
DEBUG - 2021-07-17 14:53:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 14:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 14:53:28 --> Parser Class Initialized
INFO - 2021-07-17 14:53:28 --> Form Validation Class Initialized
INFO - 2021-07-17 14:53:28 --> Upload Class Initialized
INFO - 2021-07-17 14:53:28 --> Email Class Initialized
INFO - 2021-07-17 14:53:28 --> MY_Model class loaded
INFO - 2021-07-17 14:53:28 --> Model "Users_model" initialized
INFO - 2021-07-17 14:53:28 --> Model "Settings_model" initialized
INFO - 2021-07-17 14:53:28 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 14:53:28 --> Model "Permissions_model" initialized
INFO - 2021-07-17 14:53:28 --> Model "Roles_model" initialized
INFO - 2021-07-17 14:53:28 --> Model "Activity_model" initialized
INFO - 2021-07-17 14:53:28 --> Model "Templates_model" initialized
INFO - 2021-07-17 14:53:28 --> Database Driver Class Initialized
INFO - 2021-07-17 14:53:28 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 14:53:28 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 14:53:28 --> Controller Class Initialized
ERROR - 2021-07-17 14:53:28 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 14:53:28 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 14:53:28 --> Final output sent to browser
DEBUG - 2021-07-17 14:53:28 --> Total execution time: 0.1424
INFO - 2021-07-17 15:01:31 --> Config Class Initialized
INFO - 2021-07-17 15:01:31 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:01:31 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:01:31 --> Utf8 Class Initialized
INFO - 2021-07-17 15:01:31 --> URI Class Initialized
INFO - 2021-07-17 15:01:31 --> Router Class Initialized
INFO - 2021-07-17 15:01:31 --> Output Class Initialized
INFO - 2021-07-17 15:01:31 --> Security Class Initialized
DEBUG - 2021-07-17 15:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:01:31 --> Input Class Initialized
INFO - 2021-07-17 15:01:31 --> Language Class Initialized
INFO - 2021-07-17 15:01:31 --> Loader Class Initialized
INFO - 2021-07-17 15:01:31 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:01:31 --> Helper loaded: url_helper
INFO - 2021-07-17 15:01:31 --> Helper loaded: file_helper
INFO - 2021-07-17 15:01:31 --> Helper loaded: form_helper
INFO - 2021-07-17 15:01:31 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:01:31 --> Helper loaded: security_helper
INFO - 2021-07-17 15:01:31 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:01:31 --> Helper loaded: language_helper
INFO - 2021-07-17 15:01:31 --> Helper loaded: general_helper
INFO - 2021-07-17 15:01:31 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:01:31 --> Database Driver Class Initialized
DEBUG - 2021-07-17 15:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:01:31 --> Parser Class Initialized
INFO - 2021-07-17 15:01:31 --> Form Validation Class Initialized
INFO - 2021-07-17 15:01:31 --> Upload Class Initialized
INFO - 2021-07-17 15:01:31 --> Email Class Initialized
INFO - 2021-07-17 15:01:31 --> MY_Model class loaded
INFO - 2021-07-17 15:01:31 --> Model "Users_model" initialized
INFO - 2021-07-17 15:01:31 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:01:31 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:01:31 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:01:31 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:01:31 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:01:31 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:01:31 --> Database Driver Class Initialized
INFO - 2021-07-17 15:01:31 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:01:31 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:01:31 --> Controller Class Initialized
INFO - 2021-07-17 15:01:31 --> File loaded: C:\wamp64\www\crm\application\views\account/login.php
INFO - 2021-07-17 15:01:31 --> Final output sent to browser
DEBUG - 2021-07-17 15:01:31 --> Total execution time: 0.1259
INFO - 2021-07-17 15:01:32 --> Config Class Initialized
INFO - 2021-07-17 15:01:32 --> Hooks Class Initialized
INFO - 2021-07-17 15:01:32 --> Config Class Initialized
INFO - 2021-07-17 15:01:32 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:01:32 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:01:32 --> Utf8 Class Initialized
DEBUG - 2021-07-17 15:01:32 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:01:32 --> URI Class Initialized
INFO - 2021-07-17 15:01:32 --> Utf8 Class Initialized
INFO - 2021-07-17 15:01:32 --> URI Class Initialized
INFO - 2021-07-17 15:01:32 --> Router Class Initialized
INFO - 2021-07-17 15:01:32 --> Output Class Initialized
INFO - 2021-07-17 15:01:32 --> Router Class Initialized
INFO - 2021-07-17 15:01:32 --> Security Class Initialized
INFO - 2021-07-17 15:01:32 --> Output Class Initialized
DEBUG - 2021-07-17 15:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:01:32 --> Security Class Initialized
INFO - 2021-07-17 15:01:32 --> Input Class Initialized
DEBUG - 2021-07-17 15:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:01:32 --> Language Class Initialized
INFO - 2021-07-17 15:01:32 --> Input Class Initialized
ERROR - 2021-07-17 15:01:32 --> 404 Page Not Found: Assets/jquery
INFO - 2021-07-17 15:01:32 --> Language Class Initialized
ERROR - 2021-07-17 15:01:32 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-17 15:01:33 --> Config Class Initialized
INFO - 2021-07-17 15:01:33 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:01:33 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:01:33 --> Utf8 Class Initialized
INFO - 2021-07-17 15:01:33 --> URI Class Initialized
INFO - 2021-07-17 15:01:33 --> Router Class Initialized
INFO - 2021-07-17 15:01:33 --> Output Class Initialized
INFO - 2021-07-17 15:01:33 --> Security Class Initialized
DEBUG - 2021-07-17 15:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:01:33 --> Input Class Initialized
INFO - 2021-07-17 15:01:33 --> Language Class Initialized
ERROR - 2021-07-17 15:01:33 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-17 15:01:33 --> Config Class Initialized
INFO - 2021-07-17 15:01:33 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:01:33 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:01:33 --> Utf8 Class Initialized
INFO - 2021-07-17 15:01:33 --> URI Class Initialized
INFO - 2021-07-17 15:01:33 --> Router Class Initialized
INFO - 2021-07-17 15:01:33 --> Output Class Initialized
INFO - 2021-07-17 15:01:33 --> Security Class Initialized
DEBUG - 2021-07-17 15:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:01:33 --> Input Class Initialized
INFO - 2021-07-17 15:01:33 --> Language Class Initialized
ERROR - 2021-07-17 15:01:33 --> 404 Page Not Found: Faviconico/index
INFO - 2021-07-17 15:01:37 --> Config Class Initialized
INFO - 2021-07-17 15:01:37 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:01:37 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:01:37 --> Utf8 Class Initialized
INFO - 2021-07-17 15:01:37 --> URI Class Initialized
INFO - 2021-07-17 15:01:37 --> Router Class Initialized
INFO - 2021-07-17 15:01:37 --> Output Class Initialized
INFO - 2021-07-17 15:01:37 --> Security Class Initialized
DEBUG - 2021-07-17 15:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:01:37 --> Input Class Initialized
INFO - 2021-07-17 15:01:37 --> Language Class Initialized
INFO - 2021-07-17 15:01:37 --> Loader Class Initialized
INFO - 2021-07-17 15:01:37 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:01:37 --> Helper loaded: url_helper
INFO - 2021-07-17 15:01:37 --> Helper loaded: file_helper
INFO - 2021-07-17 15:01:37 --> Helper loaded: form_helper
INFO - 2021-07-17 15:01:37 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:01:37 --> Helper loaded: security_helper
INFO - 2021-07-17 15:01:37 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:01:37 --> Helper loaded: language_helper
INFO - 2021-07-17 15:01:37 --> Helper loaded: general_helper
INFO - 2021-07-17 15:01:37 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:01:37 --> Database Driver Class Initialized
DEBUG - 2021-07-17 15:01:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:01:37 --> Parser Class Initialized
INFO - 2021-07-17 15:01:37 --> Form Validation Class Initialized
INFO - 2021-07-17 15:01:37 --> Upload Class Initialized
INFO - 2021-07-17 15:01:37 --> Email Class Initialized
INFO - 2021-07-17 15:01:37 --> MY_Model class loaded
INFO - 2021-07-17 15:01:37 --> Model "Users_model" initialized
INFO - 2021-07-17 15:01:37 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:01:37 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:01:37 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:01:37 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:01:37 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:01:37 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:01:37 --> Database Driver Class Initialized
INFO - 2021-07-17 15:01:37 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:01:37 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:01:37 --> Controller Class Initialized
DEBUG - 2021-07-17 15:01:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-17 15:01:37 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2021-07-17 15:01:37 --> Config Class Initialized
INFO - 2021-07-17 15:01:37 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:01:37 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:01:37 --> Utf8 Class Initialized
INFO - 2021-07-17 15:01:37 --> URI Class Initialized
DEBUG - 2021-07-17 15:01:37 --> No URI present. Default controller set.
INFO - 2021-07-17 15:01:37 --> Router Class Initialized
INFO - 2021-07-17 15:01:37 --> Output Class Initialized
INFO - 2021-07-17 15:01:37 --> Security Class Initialized
DEBUG - 2021-07-17 15:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:01:37 --> Input Class Initialized
INFO - 2021-07-17 15:01:37 --> Language Class Initialized
INFO - 2021-07-17 15:01:37 --> Loader Class Initialized
INFO - 2021-07-17 15:01:37 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:01:37 --> Helper loaded: url_helper
INFO - 2021-07-17 15:01:37 --> Helper loaded: file_helper
INFO - 2021-07-17 15:01:37 --> Helper loaded: form_helper
INFO - 2021-07-17 15:01:37 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:01:37 --> Helper loaded: security_helper
INFO - 2021-07-17 15:01:37 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:01:37 --> Helper loaded: language_helper
INFO - 2021-07-17 15:01:37 --> Helper loaded: general_helper
INFO - 2021-07-17 15:01:37 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:01:37 --> Database Driver Class Initialized
DEBUG - 2021-07-17 15:01:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:01:37 --> Parser Class Initialized
INFO - 2021-07-17 15:01:37 --> Form Validation Class Initialized
INFO - 2021-07-17 15:01:37 --> Upload Class Initialized
INFO - 2021-07-17 15:01:37 --> Email Class Initialized
INFO - 2021-07-17 15:01:37 --> MY_Model class loaded
INFO - 2021-07-17 15:01:37 --> Model "Users_model" initialized
INFO - 2021-07-17 15:01:37 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:01:37 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:01:37 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:01:37 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:01:37 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:01:37 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:01:37 --> Database Driver Class Initialized
INFO - 2021-07-17 15:01:37 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:01:37 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:01:37 --> Controller Class Initialized
ERROR - 2021-07-17 15:01:37 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 15:01:37 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-17 15:01:37 --> Final output sent to browser
DEBUG - 2021-07-17 15:01:37 --> Total execution time: 0.0626
INFO - 2021-07-17 15:01:40 --> Config Class Initialized
INFO - 2021-07-17 15:01:40 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:01:40 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:01:40 --> Utf8 Class Initialized
INFO - 2021-07-17 15:01:40 --> URI Class Initialized
INFO - 2021-07-17 15:01:40 --> Router Class Initialized
INFO - 2021-07-17 15:01:40 --> Output Class Initialized
INFO - 2021-07-17 15:01:40 --> Security Class Initialized
DEBUG - 2021-07-17 15:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:01:40 --> Input Class Initialized
INFO - 2021-07-17 15:01:40 --> Language Class Initialized
INFO - 2021-07-17 15:01:40 --> Loader Class Initialized
INFO - 2021-07-17 15:01:40 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:01:40 --> Helper loaded: url_helper
INFO - 2021-07-17 15:01:40 --> Helper loaded: file_helper
INFO - 2021-07-17 15:01:40 --> Helper loaded: form_helper
INFO - 2021-07-17 15:01:40 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:01:40 --> Helper loaded: security_helper
INFO - 2021-07-17 15:01:40 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:01:40 --> Helper loaded: language_helper
INFO - 2021-07-17 15:01:40 --> Helper loaded: general_helper
INFO - 2021-07-17 15:01:40 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:01:40 --> Database Driver Class Initialized
DEBUG - 2021-07-17 15:01:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:01:40 --> Parser Class Initialized
INFO - 2021-07-17 15:01:40 --> Form Validation Class Initialized
INFO - 2021-07-17 15:01:40 --> Upload Class Initialized
INFO - 2021-07-17 15:01:40 --> Email Class Initialized
INFO - 2021-07-17 15:01:40 --> MY_Model class loaded
INFO - 2021-07-17 15:01:40 --> Model "Users_model" initialized
INFO - 2021-07-17 15:01:40 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:01:40 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:01:40 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:01:40 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:01:40 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:01:40 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:01:40 --> Database Driver Class Initialized
INFO - 2021-07-17 15:01:40 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:01:40 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:01:40 --> Controller Class Initialized
ERROR - 2021-07-17 15:01:40 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 15:01:40 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-17 15:01:40 --> Final output sent to browser
DEBUG - 2021-07-17 15:01:40 --> Total execution time: 0.0996
INFO - 2021-07-17 15:02:08 --> Config Class Initialized
INFO - 2021-07-17 15:02:08 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:02:08 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:02:08 --> Utf8 Class Initialized
INFO - 2021-07-17 15:02:08 --> URI Class Initialized
DEBUG - 2021-07-17 15:02:08 --> No URI present. Default controller set.
INFO - 2021-07-17 15:02:08 --> Router Class Initialized
INFO - 2021-07-17 15:02:08 --> Output Class Initialized
INFO - 2021-07-17 15:02:08 --> Security Class Initialized
DEBUG - 2021-07-17 15:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:02:08 --> Input Class Initialized
INFO - 2021-07-17 15:02:08 --> Language Class Initialized
INFO - 2021-07-17 15:02:08 --> Loader Class Initialized
INFO - 2021-07-17 15:02:08 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:02:08 --> Helper loaded: url_helper
INFO - 2021-07-17 15:02:08 --> Helper loaded: file_helper
INFO - 2021-07-17 15:02:08 --> Helper loaded: form_helper
INFO - 2021-07-17 15:02:08 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:02:08 --> Helper loaded: security_helper
INFO - 2021-07-17 15:02:08 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:02:08 --> Helper loaded: language_helper
INFO - 2021-07-17 15:02:08 --> Helper loaded: general_helper
INFO - 2021-07-17 15:02:08 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:02:08 --> Database Driver Class Initialized
DEBUG - 2021-07-17 15:02:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:02:08 --> Parser Class Initialized
INFO - 2021-07-17 15:02:08 --> Form Validation Class Initialized
INFO - 2021-07-17 15:02:08 --> Upload Class Initialized
INFO - 2021-07-17 15:02:08 --> Email Class Initialized
INFO - 2021-07-17 15:02:08 --> MY_Model class loaded
INFO - 2021-07-17 15:02:08 --> Model "Users_model" initialized
INFO - 2021-07-17 15:02:08 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:02:08 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:02:08 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:02:08 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:02:08 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:02:08 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:02:08 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:08 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:02:08 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:02:08 --> Controller Class Initialized
INFO - 2021-07-17 15:02:08 --> Config Class Initialized
INFO - 2021-07-17 15:02:08 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:02:08 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:02:08 --> Utf8 Class Initialized
INFO - 2021-07-17 15:02:08 --> URI Class Initialized
INFO - 2021-07-17 15:02:08 --> Router Class Initialized
INFO - 2021-07-17 15:02:08 --> Output Class Initialized
INFO - 2021-07-17 15:02:08 --> Security Class Initialized
DEBUG - 2021-07-17 15:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:02:08 --> Input Class Initialized
INFO - 2021-07-17 15:02:08 --> Language Class Initialized
INFO - 2021-07-17 15:02:08 --> Loader Class Initialized
INFO - 2021-07-17 15:02:08 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:02:08 --> Helper loaded: url_helper
INFO - 2021-07-17 15:02:08 --> Helper loaded: file_helper
INFO - 2021-07-17 15:02:08 --> Helper loaded: form_helper
INFO - 2021-07-17 15:02:08 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:02:08 --> Helper loaded: security_helper
INFO - 2021-07-17 15:02:08 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:02:08 --> Helper loaded: language_helper
INFO - 2021-07-17 15:02:08 --> Helper loaded: general_helper
INFO - 2021-07-17 15:02:08 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:02:08 --> Database Driver Class Initialized
DEBUG - 2021-07-17 15:02:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:02:08 --> Parser Class Initialized
INFO - 2021-07-17 15:02:08 --> Form Validation Class Initialized
INFO - 2021-07-17 15:02:08 --> Upload Class Initialized
INFO - 2021-07-17 15:02:08 --> Email Class Initialized
INFO - 2021-07-17 15:02:08 --> MY_Model class loaded
INFO - 2021-07-17 15:02:08 --> Model "Users_model" initialized
INFO - 2021-07-17 15:02:08 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:02:08 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:02:08 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:02:08 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:02:08 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:02:08 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:02:08 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:08 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:02:08 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:02:08 --> Controller Class Initialized
INFO - 2021-07-17 15:02:08 --> File loaded: C:\wamp64\www\crm\application\views\account/login.php
INFO - 2021-07-17 15:02:08 --> Final output sent to browser
DEBUG - 2021-07-17 15:02:08 --> Total execution time: 0.0434
INFO - 2021-07-17 15:02:08 --> Config Class Initialized
INFO - 2021-07-17 15:02:08 --> Config Class Initialized
INFO - 2021-07-17 15:02:08 --> Hooks Class Initialized
INFO - 2021-07-17 15:02:08 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:02:08 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:02:08 --> Utf8 Class Initialized
DEBUG - 2021-07-17 15:02:08 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:02:08 --> Utf8 Class Initialized
INFO - 2021-07-17 15:02:08 --> URI Class Initialized
INFO - 2021-07-17 15:02:08 --> URI Class Initialized
INFO - 2021-07-17 15:02:08 --> Router Class Initialized
INFO - 2021-07-17 15:02:08 --> Router Class Initialized
INFO - 2021-07-17 15:02:08 --> Output Class Initialized
INFO - 2021-07-17 15:02:08 --> Output Class Initialized
INFO - 2021-07-17 15:02:08 --> Security Class Initialized
INFO - 2021-07-17 15:02:08 --> Security Class Initialized
DEBUG - 2021-07-17 15:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-17 15:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:02:08 --> Input Class Initialized
INFO - 2021-07-17 15:02:08 --> Input Class Initialized
INFO - 2021-07-17 15:02:08 --> Language Class Initialized
INFO - 2021-07-17 15:02:08 --> Language Class Initialized
ERROR - 2021-07-17 15:02:08 --> 404 Page Not Found: Assets/jquery
ERROR - 2021-07-17 15:02:08 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-17 15:02:09 --> Config Class Initialized
INFO - 2021-07-17 15:02:09 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:02:09 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:02:09 --> Utf8 Class Initialized
INFO - 2021-07-17 15:02:09 --> URI Class Initialized
DEBUG - 2021-07-17 15:02:09 --> No URI present. Default controller set.
INFO - 2021-07-17 15:02:09 --> Router Class Initialized
INFO - 2021-07-17 15:02:09 --> Output Class Initialized
INFO - 2021-07-17 15:02:09 --> Security Class Initialized
DEBUG - 2021-07-17 15:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:02:09 --> Input Class Initialized
INFO - 2021-07-17 15:02:09 --> Language Class Initialized
INFO - 2021-07-17 15:02:09 --> Loader Class Initialized
INFO - 2021-07-17 15:02:09 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:02:09 --> Helper loaded: url_helper
INFO - 2021-07-17 15:02:09 --> Helper loaded: file_helper
INFO - 2021-07-17 15:02:09 --> Helper loaded: form_helper
INFO - 2021-07-17 15:02:09 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:02:09 --> Helper loaded: security_helper
INFO - 2021-07-17 15:02:09 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:02:09 --> Helper loaded: language_helper
INFO - 2021-07-17 15:02:09 --> Helper loaded: general_helper
INFO - 2021-07-17 15:02:09 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:02:09 --> Database Driver Class Initialized
DEBUG - 2021-07-17 15:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:02:09 --> Parser Class Initialized
INFO - 2021-07-17 15:02:09 --> Form Validation Class Initialized
INFO - 2021-07-17 15:02:09 --> Upload Class Initialized
INFO - 2021-07-17 15:02:09 --> Email Class Initialized
INFO - 2021-07-17 15:02:09 --> MY_Model class loaded
INFO - 2021-07-17 15:02:09 --> Model "Users_model" initialized
INFO - 2021-07-17 15:02:09 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:02:09 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:02:09 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:02:09 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:02:09 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:02:09 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:02:09 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:09 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:02:09 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:02:09 --> Controller Class Initialized
INFO - 2021-07-17 15:02:09 --> Config Class Initialized
INFO - 2021-07-17 15:02:09 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:02:09 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:02:09 --> Utf8 Class Initialized
INFO - 2021-07-17 15:02:09 --> URI Class Initialized
INFO - 2021-07-17 15:02:09 --> Router Class Initialized
INFO - 2021-07-17 15:02:09 --> Output Class Initialized
INFO - 2021-07-17 15:02:09 --> Security Class Initialized
DEBUG - 2021-07-17 15:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:02:09 --> Input Class Initialized
INFO - 2021-07-17 15:02:09 --> Language Class Initialized
INFO - 2021-07-17 15:02:09 --> Loader Class Initialized
INFO - 2021-07-17 15:02:09 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:02:09 --> Helper loaded: url_helper
INFO - 2021-07-17 15:02:09 --> Helper loaded: file_helper
INFO - 2021-07-17 15:02:09 --> Helper loaded: form_helper
INFO - 2021-07-17 15:02:09 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:02:09 --> Helper loaded: security_helper
INFO - 2021-07-17 15:02:09 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:02:09 --> Helper loaded: language_helper
INFO - 2021-07-17 15:02:09 --> Helper loaded: general_helper
INFO - 2021-07-17 15:02:09 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:02:09 --> Database Driver Class Initialized
DEBUG - 2021-07-17 15:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:02:09 --> Parser Class Initialized
INFO - 2021-07-17 15:02:09 --> Form Validation Class Initialized
INFO - 2021-07-17 15:02:09 --> Upload Class Initialized
INFO - 2021-07-17 15:02:09 --> Email Class Initialized
INFO - 2021-07-17 15:02:09 --> MY_Model class loaded
INFO - 2021-07-17 15:02:09 --> Model "Users_model" initialized
INFO - 2021-07-17 15:02:09 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:02:09 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:02:09 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:02:09 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:02:09 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:02:09 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:02:09 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:09 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:02:09 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:02:09 --> Controller Class Initialized
INFO - 2021-07-17 15:02:09 --> File loaded: C:\wamp64\www\crm\application\views\account/login.php
INFO - 2021-07-17 15:02:09 --> Final output sent to browser
DEBUG - 2021-07-17 15:02:09 --> Total execution time: 0.0436
INFO - 2021-07-17 15:02:09 --> Config Class Initialized
INFO - 2021-07-17 15:02:09 --> Config Class Initialized
INFO - 2021-07-17 15:02:09 --> Hooks Class Initialized
INFO - 2021-07-17 15:02:09 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:02:09 --> UTF-8 Support Enabled
DEBUG - 2021-07-17 15:02:09 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:02:09 --> Utf8 Class Initialized
INFO - 2021-07-17 15:02:09 --> Utf8 Class Initialized
INFO - 2021-07-17 15:02:09 --> URI Class Initialized
INFO - 2021-07-17 15:02:09 --> URI Class Initialized
INFO - 2021-07-17 15:02:09 --> Router Class Initialized
INFO - 2021-07-17 15:02:09 --> Router Class Initialized
INFO - 2021-07-17 15:02:09 --> Output Class Initialized
INFO - 2021-07-17 15:02:09 --> Output Class Initialized
INFO - 2021-07-17 15:02:09 --> Security Class Initialized
INFO - 2021-07-17 15:02:09 --> Security Class Initialized
DEBUG - 2021-07-17 15:02:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-17 15:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:02:09 --> Input Class Initialized
INFO - 2021-07-17 15:02:09 --> Input Class Initialized
INFO - 2021-07-17 15:02:09 --> Language Class Initialized
INFO - 2021-07-17 15:02:09 --> Language Class Initialized
ERROR - 2021-07-17 15:02:09 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-07-17 15:02:09 --> 404 Page Not Found: Assets/jquery
INFO - 2021-07-17 15:02:19 --> Config Class Initialized
INFO - 2021-07-17 15:02:19 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:02:19 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:02:19 --> Utf8 Class Initialized
INFO - 2021-07-17 15:02:19 --> URI Class Initialized
INFO - 2021-07-17 15:02:19 --> Router Class Initialized
INFO - 2021-07-17 15:02:19 --> Output Class Initialized
INFO - 2021-07-17 15:02:19 --> Security Class Initialized
DEBUG - 2021-07-17 15:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:02:19 --> Input Class Initialized
INFO - 2021-07-17 15:02:19 --> Language Class Initialized
INFO - 2021-07-17 15:02:19 --> Loader Class Initialized
INFO - 2021-07-17 15:02:19 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:02:19 --> Helper loaded: url_helper
INFO - 2021-07-17 15:02:19 --> Helper loaded: file_helper
INFO - 2021-07-17 15:02:19 --> Helper loaded: form_helper
INFO - 2021-07-17 15:02:19 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:02:19 --> Helper loaded: security_helper
INFO - 2021-07-17 15:02:19 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:02:19 --> Helper loaded: language_helper
INFO - 2021-07-17 15:02:19 --> Helper loaded: general_helper
INFO - 2021-07-17 15:02:19 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:02:19 --> Database Driver Class Initialized
DEBUG - 2021-07-17 15:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:02:19 --> Parser Class Initialized
INFO - 2021-07-17 15:02:19 --> Form Validation Class Initialized
INFO - 2021-07-17 15:02:19 --> Upload Class Initialized
INFO - 2021-07-17 15:02:19 --> Email Class Initialized
INFO - 2021-07-17 15:02:19 --> MY_Model class loaded
INFO - 2021-07-17 15:02:19 --> Model "Users_model" initialized
INFO - 2021-07-17 15:02:19 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:02:19 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:02:19 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:02:19 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:02:19 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:02:19 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:02:19 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:19 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:02:19 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:02:19 --> Controller Class Initialized
ERROR - 2021-07-17 15:02:19 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 15:02:19 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-17 15:02:19 --> Final output sent to browser
DEBUG - 2021-07-17 15:02:19 --> Total execution time: 0.2157
INFO - 2021-07-17 15:02:20 --> Config Class Initialized
INFO - 2021-07-17 15:02:20 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:02:20 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:02:20 --> Utf8 Class Initialized
INFO - 2021-07-17 15:02:20 --> URI Class Initialized
INFO - 2021-07-17 15:02:20 --> Router Class Initialized
INFO - 2021-07-17 15:02:20 --> Output Class Initialized
INFO - 2021-07-17 15:02:20 --> Security Class Initialized
DEBUG - 2021-07-17 15:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:02:20 --> Input Class Initialized
INFO - 2021-07-17 15:02:20 --> Language Class Initialized
INFO - 2021-07-17 15:02:20 --> Loader Class Initialized
INFO - 2021-07-17 15:02:20 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:02:20 --> Helper loaded: url_helper
INFO - 2021-07-17 15:02:20 --> Helper loaded: file_helper
INFO - 2021-07-17 15:02:20 --> Helper loaded: form_helper
INFO - 2021-07-17 15:02:20 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:02:20 --> Helper loaded: security_helper
INFO - 2021-07-17 15:02:20 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:02:20 --> Helper loaded: language_helper
INFO - 2021-07-17 15:02:20 --> Helper loaded: general_helper
INFO - 2021-07-17 15:02:20 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:02:20 --> Database Driver Class Initialized
DEBUG - 2021-07-17 15:02:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:02:20 --> Parser Class Initialized
INFO - 2021-07-17 15:02:20 --> Form Validation Class Initialized
INFO - 2021-07-17 15:02:20 --> Upload Class Initialized
INFO - 2021-07-17 15:02:20 --> Email Class Initialized
INFO - 2021-07-17 15:02:20 --> MY_Model class loaded
INFO - 2021-07-17 15:02:20 --> Model "Users_model" initialized
INFO - 2021-07-17 15:02:20 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:02:20 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:02:20 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:02:20 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:02:20 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:02:20 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:02:20 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:20 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:02:20 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:02:20 --> Controller Class Initialized
DEBUG - 2021-07-17 15:02:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-17 15:02:20 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2021-07-17 15:02:21 --> Config Class Initialized
INFO - 2021-07-17 15:02:21 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:02:21 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:02:21 --> Utf8 Class Initialized
INFO - 2021-07-17 15:02:21 --> URI Class Initialized
DEBUG - 2021-07-17 15:02:21 --> No URI present. Default controller set.
INFO - 2021-07-17 15:02:21 --> Router Class Initialized
INFO - 2021-07-17 15:02:21 --> Output Class Initialized
INFO - 2021-07-17 15:02:21 --> Security Class Initialized
DEBUG - 2021-07-17 15:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:02:21 --> Input Class Initialized
INFO - 2021-07-17 15:02:21 --> Language Class Initialized
INFO - 2021-07-17 15:02:21 --> Loader Class Initialized
INFO - 2021-07-17 15:02:21 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:02:21 --> Helper loaded: url_helper
INFO - 2021-07-17 15:02:21 --> Helper loaded: file_helper
INFO - 2021-07-17 15:02:21 --> Helper loaded: form_helper
INFO - 2021-07-17 15:02:21 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:02:21 --> Helper loaded: security_helper
INFO - 2021-07-17 15:02:21 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:02:21 --> Helper loaded: language_helper
INFO - 2021-07-17 15:02:21 --> Helper loaded: general_helper
INFO - 2021-07-17 15:02:21 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:02:21 --> Database Driver Class Initialized
DEBUG - 2021-07-17 15:02:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:02:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:02:21 --> Parser Class Initialized
INFO - 2021-07-17 15:02:21 --> Form Validation Class Initialized
INFO - 2021-07-17 15:02:21 --> Upload Class Initialized
INFO - 2021-07-17 15:02:21 --> Email Class Initialized
INFO - 2021-07-17 15:02:21 --> MY_Model class loaded
INFO - 2021-07-17 15:02:21 --> Model "Users_model" initialized
INFO - 2021-07-17 15:02:21 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:02:21 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:02:21 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:02:21 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:02:21 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:02:21 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:02:21 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:21 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:02:21 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:02:21 --> Controller Class Initialized
ERROR - 2021-07-17 15:02:21 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 15:02:21 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-17 15:02:21 --> Final output sent to browser
DEBUG - 2021-07-17 15:02:21 --> Total execution time: 0.0604
INFO - 2021-07-17 15:02:27 --> Config Class Initialized
INFO - 2021-07-17 15:02:27 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:02:27 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:02:27 --> Utf8 Class Initialized
INFO - 2021-07-17 15:02:27 --> URI Class Initialized
INFO - 2021-07-17 15:02:27 --> Router Class Initialized
INFO - 2021-07-17 15:02:27 --> Output Class Initialized
INFO - 2021-07-17 15:02:27 --> Security Class Initialized
DEBUG - 2021-07-17 15:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:02:27 --> Input Class Initialized
INFO - 2021-07-17 15:02:27 --> Language Class Initialized
INFO - 2021-07-17 15:02:27 --> Loader Class Initialized
INFO - 2021-07-17 15:02:27 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: url_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: file_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: form_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: security_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: language_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: general_helper
INFO - 2021-07-17 15:02:27 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:02:27 --> Database Driver Class Initialized
DEBUG - 2021-07-17 15:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:02:27 --> Parser Class Initialized
INFO - 2021-07-17 15:02:27 --> Form Validation Class Initialized
INFO - 2021-07-17 15:02:27 --> Upload Class Initialized
INFO - 2021-07-17 15:02:27 --> Email Class Initialized
INFO - 2021-07-17 15:02:27 --> MY_Model class loaded
INFO - 2021-07-17 15:02:27 --> Model "Users_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:02:27 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:27 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:02:27 --> Controller Class Initialized
ERROR - 2021-07-17 15:02:27 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 15:02:27 --> File loaded: C:\wamp64\www\crm\application\views\users/list.php
INFO - 2021-07-17 15:02:27 --> Final output sent to browser
DEBUG - 2021-07-17 15:02:27 --> Total execution time: 0.1787
INFO - 2021-07-17 15:02:27 --> Config Class Initialized
INFO - 2021-07-17 15:02:27 --> Config Class Initialized
INFO - 2021-07-17 15:02:27 --> Config Class Initialized
INFO - 2021-07-17 15:02:27 --> Hooks Class Initialized
INFO - 2021-07-17 15:02:27 --> Hooks Class Initialized
INFO - 2021-07-17 15:02:27 --> Hooks Class Initialized
INFO - 2021-07-17 15:02:27 --> Config Class Initialized
INFO - 2021-07-17 15:02:27 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:02:27 --> UTF-8 Support Enabled
DEBUG - 2021-07-17 15:02:27 --> UTF-8 Support Enabled
DEBUG - 2021-07-17 15:02:27 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:02:27 --> Utf8 Class Initialized
INFO - 2021-07-17 15:02:27 --> Utf8 Class Initialized
DEBUG - 2021-07-17 15:02:27 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:02:27 --> Utf8 Class Initialized
INFO - 2021-07-17 15:02:27 --> URI Class Initialized
INFO - 2021-07-17 15:02:27 --> URI Class Initialized
INFO - 2021-07-17 15:02:27 --> Utf8 Class Initialized
INFO - 2021-07-17 15:02:27 --> URI Class Initialized
INFO - 2021-07-17 15:02:27 --> URI Class Initialized
INFO - 2021-07-17 15:02:27 --> Router Class Initialized
INFO - 2021-07-17 15:02:27 --> Router Class Initialized
INFO - 2021-07-17 15:02:27 --> Router Class Initialized
INFO - 2021-07-17 15:02:27 --> Output Class Initialized
INFO - 2021-07-17 15:02:27 --> Output Class Initialized
INFO - 2021-07-17 15:02:27 --> Router Class Initialized
INFO - 2021-07-17 15:02:27 --> Security Class Initialized
INFO - 2021-07-17 15:02:27 --> Output Class Initialized
INFO - 2021-07-17 15:02:27 --> Security Class Initialized
INFO - 2021-07-17 15:02:27 --> Output Class Initialized
DEBUG - 2021-07-17 15:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:02:27 --> Security Class Initialized
DEBUG - 2021-07-17 15:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:02:27 --> Input Class Initialized
INFO - 2021-07-17 15:02:27 --> Security Class Initialized
INFO - 2021-07-17 15:02:27 --> Input Class Initialized
DEBUG - 2021-07-17 15:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:02:27 --> Language Class Initialized
DEBUG - 2021-07-17 15:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:02:27 --> Input Class Initialized
INFO - 2021-07-17 15:02:27 --> Language Class Initialized
INFO - 2021-07-17 15:02:27 --> Input Class Initialized
INFO - 2021-07-17 15:02:27 --> Loader Class Initialized
INFO - 2021-07-17 15:02:27 --> Language Class Initialized
INFO - 2021-07-17 15:02:27 --> Language Class Initialized
INFO - 2021-07-17 15:02:27 --> Loader Class Initialized
INFO - 2021-07-17 15:02:27 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:02:27 --> Loader Class Initialized
INFO - 2021-07-17 15:02:27 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:02:27 --> Loader Class Initialized
INFO - 2021-07-17 15:02:27 --> Helper loaded: url_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: url_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: file_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: file_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: url_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: form_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: url_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: form_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: file_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: file_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: form_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: security_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: form_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: security_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: security_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: language_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: security_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: language_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: general_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: general_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: language_helper
INFO - 2021-07-17 15:02:27 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:02:27 --> Helper loaded: language_helper
INFO - 2021-07-17 15:02:27 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:02:27 --> Helper loaded: general_helper
INFO - 2021-07-17 15:02:27 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:27 --> Helper loaded: general_helper
INFO - 2021-07-17 15:02:27 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:02:27 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:27 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:02:27 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:27 --> Database Driver Class Initialized
DEBUG - 2021-07-17 15:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-07-17 15:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-07-17 15:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:02:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2021-07-17 15:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:02:27 --> Parser Class Initialized
INFO - 2021-07-17 15:02:27 --> Form Validation Class Initialized
INFO - 2021-07-17 15:02:27 --> Upload Class Initialized
INFO - 2021-07-17 15:02:27 --> Email Class Initialized
INFO - 2021-07-17 15:02:27 --> MY_Model class loaded
INFO - 2021-07-17 15:02:27 --> Model "Users_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:02:27 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:27 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:02:27 --> Controller Class Initialized
INFO - 2021-07-17 15:02:27 --> Final output sent to browser
DEBUG - 2021-07-17 15:02:27 --> Total execution time: 0.0496
INFO - 2021-07-17 15:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:02:27 --> Parser Class Initialized
INFO - 2021-07-17 15:02:27 --> Form Validation Class Initialized
INFO - 2021-07-17 15:02:27 --> Upload Class Initialized
INFO - 2021-07-17 15:02:27 --> Email Class Initialized
INFO - 2021-07-17 15:02:27 --> MY_Model class loaded
INFO - 2021-07-17 15:02:27 --> Model "Users_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:02:27 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:27 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:02:27 --> Controller Class Initialized
INFO - 2021-07-17 15:02:27 --> Final output sent to browser
DEBUG - 2021-07-17 15:02:27 --> Total execution time: 0.0761
INFO - 2021-07-17 15:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:02:27 --> Parser Class Initialized
INFO - 2021-07-17 15:02:27 --> Form Validation Class Initialized
INFO - 2021-07-17 15:02:27 --> Upload Class Initialized
INFO - 2021-07-17 15:02:27 --> Email Class Initialized
INFO - 2021-07-17 15:02:27 --> MY_Model class loaded
INFO - 2021-07-17 15:02:27 --> Model "Users_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:02:27 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:27 --> Config Class Initialized
INFO - 2021-07-17 15:02:27 --> Config Class Initialized
INFO - 2021-07-17 15:02:27 --> Hooks Class Initialized
INFO - 2021-07-17 15:02:27 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:02:27 --> UTF-8 Support Enabled
DEBUG - 2021-07-17 15:02:27 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:02:27 --> Utf8 Class Initialized
INFO - 2021-07-17 15:02:27 --> Utf8 Class Initialized
INFO - 2021-07-17 15:02:27 --> URI Class Initialized
INFO - 2021-07-17 15:02:27 --> URI Class Initialized
INFO - 2021-07-17 15:02:27 --> Router Class Initialized
INFO - 2021-07-17 15:02:27 --> Router Class Initialized
INFO - 2021-07-17 15:02:27 --> Output Class Initialized
INFO - 2021-07-17 15:02:27 --> Output Class Initialized
INFO - 2021-07-17 15:02:27 --> Security Class Initialized
INFO - 2021-07-17 15:02:27 --> Security Class Initialized
DEBUG - 2021-07-17 15:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-17 15:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:02:27 --> Input Class Initialized
INFO - 2021-07-17 15:02:27 --> Input Class Initialized
INFO - 2021-07-17 15:02:27 --> Language Class Initialized
INFO - 2021-07-17 15:02:27 --> Language Class Initialized
INFO - 2021-07-17 15:02:27 --> Loader Class Initialized
INFO - 2021-07-17 15:02:27 --> Loader Class Initialized
INFO - 2021-07-17 15:02:27 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:02:27 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:02:27 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: url_helper
INFO - 2021-07-17 15:02:27 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:02:27 --> Helper loaded: url_helper
INFO - 2021-07-17 15:02:27 --> Controller Class Initialized
INFO - 2021-07-17 15:02:27 --> Helper loaded: file_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: file_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: form_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: form_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: security_helper
INFO - 2021-07-17 15:02:27 --> Final output sent to browser
INFO - 2021-07-17 15:02:27 --> Helper loaded: security_helper
DEBUG - 2021-07-17 15:02:27 --> Total execution time: 0.1036
INFO - 2021-07-17 15:02:27 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: language_helper
INFO - 2021-07-17 15:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:02:27 --> Helper loaded: language_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: general_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: general_helper
INFO - 2021-07-17 15:02:27 --> Parser Class Initialized
INFO - 2021-07-17 15:02:27 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:02:27 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:02:27 --> Form Validation Class Initialized
INFO - 2021-07-17 15:02:27 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:27 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:27 --> Upload Class Initialized
INFO - 2021-07-17 15:02:27 --> Email Class Initialized
INFO - 2021-07-17 15:02:27 --> MY_Model class loaded
DEBUG - 2021-07-17 15:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-07-17 15:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:02:27 --> Model "Users_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:02:27 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:27 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:02:27 --> Controller Class Initialized
INFO - 2021-07-17 15:02:27 --> Final output sent to browser
DEBUG - 2021-07-17 15:02:27 --> Total execution time: 0.1323
INFO - 2021-07-17 15:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:02:27 --> Parser Class Initialized
INFO - 2021-07-17 15:02:27 --> Form Validation Class Initialized
INFO - 2021-07-17 15:02:27 --> Upload Class Initialized
INFO - 2021-07-17 15:02:27 --> Email Class Initialized
INFO - 2021-07-17 15:02:27 --> MY_Model class loaded
INFO - 2021-07-17 15:02:27 --> Model "Users_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:02:27 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:27 --> Config Class Initialized
INFO - 2021-07-17 15:02:27 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:02:27 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:02:27 --> Utf8 Class Initialized
INFO - 2021-07-17 15:02:27 --> URI Class Initialized
INFO - 2021-07-17 15:02:27 --> Router Class Initialized
INFO - 2021-07-17 15:02:27 --> Output Class Initialized
INFO - 2021-07-17 15:02:27 --> Security Class Initialized
DEBUG - 2021-07-17 15:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:02:27 --> Input Class Initialized
INFO - 2021-07-17 15:02:27 --> Language Class Initialized
INFO - 2021-07-17 15:02:27 --> Loader Class Initialized
INFO - 2021-07-17 15:02:27 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: url_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: file_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: form_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: security_helper
INFO - 2021-07-17 15:02:27 --> Config Class Initialized
INFO - 2021-07-17 15:02:27 --> Hooks Class Initialized
INFO - 2021-07-17 15:02:27 --> Helper loaded: directory_helper
DEBUG - 2021-07-17 15:02:27 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:02:27 --> Helper loaded: language_helper
INFO - 2021-07-17 15:02:27 --> Utf8 Class Initialized
INFO - 2021-07-17 15:02:27 --> Helper loaded: general_helper
INFO - 2021-07-17 15:02:27 --> URI Class Initialized
INFO - 2021-07-17 15:02:27 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:02:27 --> Router Class Initialized
INFO - 2021-07-17 15:02:27 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:27 --> Output Class Initialized
INFO - 2021-07-17 15:02:27 --> Security Class Initialized
DEBUG - 2021-07-17 15:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:02:27 --> Input Class Initialized
DEBUG - 2021-07-17 15:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:02:27 --> Language Class Initialized
INFO - 2021-07-17 15:02:27 --> Loader Class Initialized
INFO - 2021-07-17 15:02:27 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: url_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: file_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: form_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: security_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:02:27 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:02:27 --> Helper loaded: language_helper
INFO - 2021-07-17 15:02:27 --> Controller Class Initialized
INFO - 2021-07-17 15:02:27 --> Helper loaded: general_helper
INFO - 2021-07-17 15:02:27 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:02:27 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:27 --> Final output sent to browser
DEBUG - 2021-07-17 15:02:27 --> Total execution time: 0.0793
INFO - 2021-07-17 15:02:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2021-07-17 15:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:02:27 --> Parser Class Initialized
INFO - 2021-07-17 15:02:27 --> Form Validation Class Initialized
INFO - 2021-07-17 15:02:27 --> Upload Class Initialized
INFO - 2021-07-17 15:02:27 --> Email Class Initialized
INFO - 2021-07-17 15:02:27 --> MY_Model class loaded
INFO - 2021-07-17 15:02:27 --> Model "Users_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:02:27 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:27 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:02:27 --> Controller Class Initialized
INFO - 2021-07-17 15:02:27 --> Final output sent to browser
DEBUG - 2021-07-17 15:02:27 --> Total execution time: 0.1072
INFO - 2021-07-17 15:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:02:27 --> Parser Class Initialized
INFO - 2021-07-17 15:02:27 --> Form Validation Class Initialized
INFO - 2021-07-17 15:02:27 --> Upload Class Initialized
INFO - 2021-07-17 15:02:27 --> Email Class Initialized
INFO - 2021-07-17 15:02:27 --> MY_Model class loaded
INFO - 2021-07-17 15:02:27 --> Model "Users_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:02:27 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:27 --> Config Class Initialized
INFO - 2021-07-17 15:02:27 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:02:27 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:02:27 --> Utf8 Class Initialized
INFO - 2021-07-17 15:02:27 --> URI Class Initialized
INFO - 2021-07-17 15:02:27 --> Router Class Initialized
INFO - 2021-07-17 15:02:27 --> Output Class Initialized
INFO - 2021-07-17 15:02:27 --> Security Class Initialized
DEBUG - 2021-07-17 15:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:02:27 --> Input Class Initialized
INFO - 2021-07-17 15:02:27 --> Language Class Initialized
INFO - 2021-07-17 15:02:27 --> Loader Class Initialized
INFO - 2021-07-17 15:02:27 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: url_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: file_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: form_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:02:27 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:02:27 --> Helper loaded: security_helper
INFO - 2021-07-17 15:02:27 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:02:27 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:02:27 --> Controller Class Initialized
INFO - 2021-07-17 15:02:27 --> Helper loaded: language_helper
INFO - 2021-07-17 15:02:27 --> Helper loaded: general_helper
INFO - 2021-07-17 15:02:27 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:02:27 --> Final output sent to browser
DEBUG - 2021-07-17 15:02:27 --> Total execution time: 0.0833
INFO - 2021-07-17 15:02:27 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:02:27 --> Parser Class Initialized
INFO - 2021-07-17 15:02:27 --> Form Validation Class Initialized
DEBUG - 2021-07-17 15:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:02:27 --> Upload Class Initialized
INFO - 2021-07-17 15:02:27 --> Email Class Initialized
INFO - 2021-07-17 15:02:27 --> MY_Model class loaded
INFO - 2021-07-17 15:02:27 --> Model "Users_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:02:27 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:27 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:02:27 --> Controller Class Initialized
INFO - 2021-07-17 15:02:27 --> Final output sent to browser
DEBUG - 2021-07-17 15:02:27 --> Total execution time: 0.1013
INFO - 2021-07-17 15:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:02:27 --> Parser Class Initialized
INFO - 2021-07-17 15:02:27 --> Form Validation Class Initialized
INFO - 2021-07-17 15:02:27 --> Upload Class Initialized
INFO - 2021-07-17 15:02:27 --> Email Class Initialized
INFO - 2021-07-17 15:02:27 --> MY_Model class loaded
INFO - 2021-07-17 15:02:27 --> Model "Users_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:02:27 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:27 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:02:27 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:02:27 --> Controller Class Initialized
INFO - 2021-07-17 15:02:27 --> Final output sent to browser
DEBUG - 2021-07-17 15:02:27 --> Total execution time: 0.0718
INFO - 2021-07-17 15:02:28 --> Config Class Initialized
INFO - 2021-07-17 15:02:28 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:02:28 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:02:28 --> Utf8 Class Initialized
INFO - 2021-07-17 15:02:28 --> URI Class Initialized
DEBUG - 2021-07-17 15:02:28 --> No URI present. Default controller set.
INFO - 2021-07-17 15:02:28 --> Router Class Initialized
INFO - 2021-07-17 15:02:28 --> Output Class Initialized
INFO - 2021-07-17 15:02:28 --> Security Class Initialized
DEBUG - 2021-07-17 15:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:02:28 --> Input Class Initialized
INFO - 2021-07-17 15:02:28 --> Language Class Initialized
INFO - 2021-07-17 15:02:28 --> Loader Class Initialized
INFO - 2021-07-17 15:02:28 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:02:28 --> Helper loaded: url_helper
INFO - 2021-07-17 15:02:28 --> Helper loaded: file_helper
INFO - 2021-07-17 15:02:28 --> Helper loaded: form_helper
INFO - 2021-07-17 15:02:28 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:02:28 --> Helper loaded: security_helper
INFO - 2021-07-17 15:02:28 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:02:28 --> Helper loaded: language_helper
INFO - 2021-07-17 15:02:28 --> Helper loaded: general_helper
INFO - 2021-07-17 15:02:28 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:02:28 --> Database Driver Class Initialized
DEBUG - 2021-07-17 15:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:02:28 --> Parser Class Initialized
INFO - 2021-07-17 15:02:28 --> Form Validation Class Initialized
INFO - 2021-07-17 15:02:28 --> Upload Class Initialized
INFO - 2021-07-17 15:02:28 --> Email Class Initialized
INFO - 2021-07-17 15:02:28 --> MY_Model class loaded
INFO - 2021-07-17 15:02:28 --> Model "Users_model" initialized
INFO - 2021-07-17 15:02:28 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:02:28 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:02:28 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:02:28 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:02:28 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:02:28 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:02:28 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:28 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:02:28 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:02:28 --> Controller Class Initialized
ERROR - 2021-07-17 15:02:28 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 15:02:28 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-17 15:02:28 --> Final output sent to browser
DEBUG - 2021-07-17 15:02:28 --> Total execution time: 0.0649
INFO - 2021-07-17 15:02:30 --> Config Class Initialized
INFO - 2021-07-17 15:02:30 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:02:30 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:02:30 --> Utf8 Class Initialized
INFO - 2021-07-17 15:02:30 --> URI Class Initialized
INFO - 2021-07-17 15:02:30 --> Router Class Initialized
INFO - 2021-07-17 15:02:30 --> Output Class Initialized
INFO - 2021-07-17 15:02:30 --> Security Class Initialized
DEBUG - 2021-07-17 15:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:02:30 --> Input Class Initialized
INFO - 2021-07-17 15:02:30 --> Language Class Initialized
ERROR - 2021-07-17 15:02:30 --> 404 Page Not Found: Faviconico/index
INFO - 2021-07-17 15:02:31 --> Config Class Initialized
INFO - 2021-07-17 15:02:31 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:02:31 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:02:31 --> Utf8 Class Initialized
INFO - 2021-07-17 15:02:31 --> URI Class Initialized
INFO - 2021-07-17 15:02:31 --> Router Class Initialized
INFO - 2021-07-17 15:02:31 --> Output Class Initialized
INFO - 2021-07-17 15:02:31 --> Security Class Initialized
DEBUG - 2021-07-17 15:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:02:31 --> Input Class Initialized
INFO - 2021-07-17 15:02:31 --> Language Class Initialized
INFO - 2021-07-17 15:02:31 --> Loader Class Initialized
INFO - 2021-07-17 15:02:31 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:02:31 --> Helper loaded: url_helper
INFO - 2021-07-17 15:02:31 --> Helper loaded: file_helper
INFO - 2021-07-17 15:02:31 --> Helper loaded: form_helper
INFO - 2021-07-17 15:02:31 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:02:31 --> Helper loaded: security_helper
INFO - 2021-07-17 15:02:31 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:02:31 --> Helper loaded: language_helper
INFO - 2021-07-17 15:02:31 --> Helper loaded: general_helper
INFO - 2021-07-17 15:02:31 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:02:31 --> Database Driver Class Initialized
DEBUG - 2021-07-17 15:02:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:02:31 --> Parser Class Initialized
INFO - 2021-07-17 15:02:31 --> Form Validation Class Initialized
INFO - 2021-07-17 15:02:31 --> Upload Class Initialized
INFO - 2021-07-17 15:02:31 --> Email Class Initialized
INFO - 2021-07-17 15:02:31 --> MY_Model class loaded
INFO - 2021-07-17 15:02:31 --> Model "Users_model" initialized
INFO - 2021-07-17 15:02:31 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:02:31 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:02:31 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:02:31 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:02:31 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:02:31 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:02:31 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:32 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:02:32 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:02:32 --> Controller Class Initialized
ERROR - 2021-07-17 15:02:32 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 15:02:32 --> File loaded: C:\wamp64\www\crm\application\views\users/list.php
INFO - 2021-07-17 15:02:32 --> Final output sent to browser
DEBUG - 2021-07-17 15:02:32 --> Total execution time: 0.1918
INFO - 2021-07-17 15:02:32 --> Config Class Initialized
INFO - 2021-07-17 15:02:32 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:02:32 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:02:32 --> Utf8 Class Initialized
INFO - 2021-07-17 15:02:32 --> Config Class Initialized
INFO - 2021-07-17 15:02:32 --> URI Class Initialized
INFO - 2021-07-17 15:02:32 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:02:32 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:02:32 --> Router Class Initialized
INFO - 2021-07-17 15:02:32 --> Utf8 Class Initialized
INFO - 2021-07-17 15:02:32 --> Output Class Initialized
INFO - 2021-07-17 15:02:32 --> URI Class Initialized
INFO - 2021-07-17 15:02:32 --> Security Class Initialized
DEBUG - 2021-07-17 15:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:02:32 --> Router Class Initialized
INFO - 2021-07-17 15:02:32 --> Input Class Initialized
INFO - 2021-07-17 15:02:32 --> Output Class Initialized
INFO - 2021-07-17 15:02:32 --> Language Class Initialized
INFO - 2021-07-17 15:02:32 --> Security Class Initialized
INFO - 2021-07-17 15:02:32 --> Loader Class Initialized
DEBUG - 2021-07-17 15:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:02:32 --> Input Class Initialized
INFO - 2021-07-17 15:02:32 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:02:32 --> Language Class Initialized
INFO - 2021-07-17 15:02:32 --> Helper loaded: url_helper
INFO - 2021-07-17 15:02:32 --> Helper loaded: file_helper
INFO - 2021-07-17 15:02:32 --> Loader Class Initialized
INFO - 2021-07-17 15:02:32 --> Helper loaded: form_helper
INFO - 2021-07-17 15:02:32 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:02:32 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:02:32 --> Helper loaded: url_helper
INFO - 2021-07-17 15:02:32 --> Config Class Initialized
INFO - 2021-07-17 15:02:32 --> Helper loaded: security_helper
INFO - 2021-07-17 15:02:32 --> Helper loaded: file_helper
INFO - 2021-07-17 15:02:32 --> Hooks Class Initialized
INFO - 2021-07-17 15:02:32 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:02:32 --> Helper loaded: form_helper
DEBUG - 2021-07-17 15:02:32 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:02:32 --> Helper loaded: language_helper
INFO - 2021-07-17 15:02:32 --> Utf8 Class Initialized
INFO - 2021-07-17 15:02:32 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:02:32 --> Helper loaded: general_helper
INFO - 2021-07-17 15:02:32 --> URI Class Initialized
INFO - 2021-07-17 15:02:32 --> Helper loaded: security_helper
INFO - 2021-07-17 15:02:32 --> Config Class Initialized
INFO - 2021-07-17 15:02:32 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:02:32 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:02:32 --> Hooks Class Initialized
INFO - 2021-07-17 15:02:32 --> Router Class Initialized
INFO - 2021-07-17 15:02:32 --> Helper loaded: language_helper
INFO - 2021-07-17 15:02:32 --> Database Driver Class Initialized
DEBUG - 2021-07-17 15:02:32 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:02:32 --> Output Class Initialized
INFO - 2021-07-17 15:02:32 --> Utf8 Class Initialized
INFO - 2021-07-17 15:02:32 --> Helper loaded: general_helper
INFO - 2021-07-17 15:02:32 --> Config Class Initialized
INFO - 2021-07-17 15:02:32 --> Security Class Initialized
INFO - 2021-07-17 15:02:32 --> URI Class Initialized
INFO - 2021-07-17 15:02:32 --> Hooks Class Initialized
INFO - 2021-07-17 15:02:32 --> Language file loaded: language/en/basic_lang.php
DEBUG - 2021-07-17 15:02:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-17 15:02:32 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:02:32 --> Input Class Initialized
INFO - 2021-07-17 15:02:32 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:32 --> Router Class Initialized
DEBUG - 2021-07-17 15:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:02:32 --> Utf8 Class Initialized
INFO - 2021-07-17 15:02:32 --> Language Class Initialized
INFO - 2021-07-17 15:02:32 --> Output Class Initialized
INFO - 2021-07-17 15:02:32 --> URI Class Initialized
INFO - 2021-07-17 15:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:02:32 --> Loader Class Initialized
INFO - 2021-07-17 15:02:32 --> Security Class Initialized
INFO - 2021-07-17 15:02:32 --> Parser Class Initialized
INFO - 2021-07-17 15:02:32 --> Router Class Initialized
INFO - 2021-07-17 15:02:32 --> Helper loaded: basic_helper
DEBUG - 2021-07-17 15:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:02:32 --> Input Class Initialized
INFO - 2021-07-17 15:02:32 --> Form Validation Class Initialized
INFO - 2021-07-17 15:02:32 --> Output Class Initialized
INFO - 2021-07-17 15:02:32 --> Helper loaded: url_helper
INFO - 2021-07-17 15:02:32 --> Config Class Initialized
INFO - 2021-07-17 15:02:32 --> Language Class Initialized
INFO - 2021-07-17 15:02:32 --> Hooks Class Initialized
INFO - 2021-07-17 15:02:32 --> Security Class Initialized
INFO - 2021-07-17 15:02:32 --> Helper loaded: file_helper
INFO - 2021-07-17 15:02:32 --> Upload Class Initialized
DEBUG - 2021-07-17 15:02:32 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:02:32 --> Loader Class Initialized
DEBUG - 2021-07-17 15:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:02:32 --> Helper loaded: form_helper
INFO - 2021-07-17 15:02:32 --> Utf8 Class Initialized
INFO - 2021-07-17 15:02:32 --> Email Class Initialized
INFO - 2021-07-17 15:02:32 --> Input Class Initialized
DEBUG - 2021-07-17 15:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:02:32 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:02:32 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:02:32 --> URI Class Initialized
INFO - 2021-07-17 15:02:32 --> MY_Model class loaded
INFO - 2021-07-17 15:02:32 --> Language Class Initialized
INFO - 2021-07-17 15:02:32 --> Helper loaded: url_helper
INFO - 2021-07-17 15:02:32 --> Helper loaded: security_helper
INFO - 2021-07-17 15:02:32 --> Model "Users_model" initialized
INFO - 2021-07-17 15:02:32 --> Router Class Initialized
INFO - 2021-07-17 15:02:32 --> Helper loaded: file_helper
INFO - 2021-07-17 15:02:32 --> Loader Class Initialized
INFO - 2021-07-17 15:02:32 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:02:32 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:02:32 --> Output Class Initialized
INFO - 2021-07-17 15:02:32 --> Helper loaded: form_helper
INFO - 2021-07-17 15:02:32 --> Helper loaded: language_helper
INFO - 2021-07-17 15:02:32 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:02:32 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:02:32 --> Security Class Initialized
INFO - 2021-07-17 15:02:32 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:02:32 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:02:32 --> Helper loaded: general_helper
INFO - 2021-07-17 15:02:32 --> Helper loaded: url_helper
DEBUG - 2021-07-17 15:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:02:32 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:02:32 --> Helper loaded: security_helper
INFO - 2021-07-17 15:02:32 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:02:32 --> Input Class Initialized
INFO - 2021-07-17 15:02:32 --> Helper loaded: file_helper
INFO - 2021-07-17 15:02:32 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:02:32 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:02:32 --> Language Class Initialized
INFO - 2021-07-17 15:02:32 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:02:32 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:32 --> Helper loaded: form_helper
INFO - 2021-07-17 15:02:32 --> Helper loaded: language_helper
INFO - 2021-07-17 15:02:32 --> Loader Class Initialized
INFO - 2021-07-17 15:02:32 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:32 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:02:32 --> Helper loaded: general_helper
INFO - 2021-07-17 15:02:32 --> Helper loaded: security_helper
INFO - 2021-07-17 15:02:32 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:02:32 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:02:32 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:02:32 --> Helper loaded: url_helper
DEBUG - 2021-07-17 15:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:02:32 --> Helper loaded: language_helper
INFO - 2021-07-17 15:02:32 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:32 --> Helper loaded: file_helper
INFO - 2021-07-17 15:02:32 --> Helper loaded: general_helper
INFO - 2021-07-17 15:02:32 --> Helper loaded: form_helper
INFO - 2021-07-17 15:02:32 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:02:32 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:02:32 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:32 --> Helper loaded: security_helper
DEBUG - 2021-07-17 15:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:02:32 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:02:32 --> Helper loaded: language_helper
INFO - 2021-07-17 15:02:32 --> Helper loaded: general_helper
DEBUG - 2021-07-17 15:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:02:32 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:02:32 --> Database Driver Class Initialized
DEBUG - 2021-07-17 15:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:02:32 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:02:32 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:02:32 --> Controller Class Initialized
INFO - 2021-07-17 15:02:32 --> Final output sent to browser
DEBUG - 2021-07-17 15:02:32 --> Total execution time: 0.0544
INFO - 2021-07-17 15:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:02:32 --> Parser Class Initialized
INFO - 2021-07-17 15:02:32 --> Form Validation Class Initialized
INFO - 2021-07-17 15:02:32 --> Upload Class Initialized
INFO - 2021-07-17 15:02:32 --> Email Class Initialized
INFO - 2021-07-17 15:02:32 --> MY_Model class loaded
INFO - 2021-07-17 15:02:32 --> Model "Users_model" initialized
INFO - 2021-07-17 15:02:32 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:02:32 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:02:32 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:02:32 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:02:32 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:02:32 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:02:32 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:32 --> Config Class Initialized
INFO - 2021-07-17 15:02:32 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:02:32 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:02:32 --> Utf8 Class Initialized
INFO - 2021-07-17 15:02:32 --> URI Class Initialized
INFO - 2021-07-17 15:02:32 --> Router Class Initialized
INFO - 2021-07-17 15:02:32 --> Output Class Initialized
INFO - 2021-07-17 15:02:32 --> Security Class Initialized
DEBUG - 2021-07-17 15:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:02:32 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:02:32 --> Input Class Initialized
INFO - 2021-07-17 15:02:32 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:02:32 --> Controller Class Initialized
INFO - 2021-07-17 15:02:32 --> Language Class Initialized
INFO - 2021-07-17 15:02:32 --> Loader Class Initialized
INFO - 2021-07-17 15:02:32 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:02:32 --> Final output sent to browser
INFO - 2021-07-17 15:02:32 --> Helper loaded: url_helper
DEBUG - 2021-07-17 15:02:32 --> Total execution time: 0.0796
INFO - 2021-07-17 15:02:32 --> Helper loaded: file_helper
INFO - 2021-07-17 15:02:32 --> Helper loaded: form_helper
INFO - 2021-07-17 15:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:02:32 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:02:32 --> Parser Class Initialized
INFO - 2021-07-17 15:02:32 --> Helper loaded: security_helper
INFO - 2021-07-17 15:02:32 --> Form Validation Class Initialized
INFO - 2021-07-17 15:02:32 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:02:32 --> Helper loaded: language_helper
INFO - 2021-07-17 15:02:32 --> Upload Class Initialized
INFO - 2021-07-17 15:02:32 --> Helper loaded: general_helper
INFO - 2021-07-17 15:02:32 --> Email Class Initialized
INFO - 2021-07-17 15:02:32 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:02:32 --> MY_Model class loaded
INFO - 2021-07-17 15:02:32 --> Model "Users_model" initialized
INFO - 2021-07-17 15:02:32 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:32 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:02:32 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:02:32 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:02:32 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:02:32 --> Model "Activity_model" initialized
DEBUG - 2021-07-17 15:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:02:32 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:02:32 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:32 --> Config Class Initialized
INFO - 2021-07-17 15:02:32 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:02:32 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:02:32 --> Utf8 Class Initialized
INFO - 2021-07-17 15:02:32 --> URI Class Initialized
INFO - 2021-07-17 15:02:32 --> Router Class Initialized
INFO - 2021-07-17 15:02:32 --> Output Class Initialized
INFO - 2021-07-17 15:02:32 --> Security Class Initialized
DEBUG - 2021-07-17 15:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:02:32 --> Input Class Initialized
INFO - 2021-07-17 15:02:32 --> Language Class Initialized
INFO - 2021-07-17 15:02:32 --> Loader Class Initialized
INFO - 2021-07-17 15:02:32 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:02:32 --> Helper loaded: url_helper
INFO - 2021-07-17 15:02:32 --> Helper loaded: file_helper
INFO - 2021-07-17 15:02:32 --> Helper loaded: form_helper
INFO - 2021-07-17 15:02:32 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:02:32 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:02:32 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:02:32 --> Helper loaded: security_helper
INFO - 2021-07-17 15:02:32 --> Controller Class Initialized
INFO - 2021-07-17 15:02:32 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:02:32 --> Helper loaded: language_helper
INFO - 2021-07-17 15:02:32 --> Helper loaded: general_helper
INFO - 2021-07-17 15:02:32 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:02:32 --> Final output sent to browser
INFO - 2021-07-17 15:02:32 --> Database Driver Class Initialized
DEBUG - 2021-07-17 15:02:32 --> Total execution time: 0.1002
INFO - 2021-07-17 15:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:02:32 --> Parser Class Initialized
DEBUG - 2021-07-17 15:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:02:32 --> Form Validation Class Initialized
INFO - 2021-07-17 15:02:32 --> Upload Class Initialized
INFO - 2021-07-17 15:02:32 --> Email Class Initialized
INFO - 2021-07-17 15:02:32 --> MY_Model class loaded
INFO - 2021-07-17 15:02:32 --> Model "Users_model" initialized
INFO - 2021-07-17 15:02:32 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:02:32 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:02:32 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:02:32 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:02:32 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:02:32 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:02:32 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:32 --> Config Class Initialized
INFO - 2021-07-17 15:02:32 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:02:32 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:02:32 --> Utf8 Class Initialized
INFO - 2021-07-17 15:02:32 --> URI Class Initialized
INFO - 2021-07-17 15:02:32 --> Router Class Initialized
INFO - 2021-07-17 15:02:32 --> Output Class Initialized
INFO - 2021-07-17 15:02:32 --> Security Class Initialized
DEBUG - 2021-07-17 15:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:02:32 --> Input Class Initialized
INFO - 2021-07-17 15:02:32 --> Language Class Initialized
INFO - 2021-07-17 15:02:32 --> Loader Class Initialized
INFO - 2021-07-17 15:02:32 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:02:32 --> Helper loaded: url_helper
INFO - 2021-07-17 15:02:32 --> Helper loaded: file_helper
INFO - 2021-07-17 15:02:32 --> Helper loaded: form_helper
INFO - 2021-07-17 15:02:32 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:02:32 --> Helper loaded: security_helper
INFO - 2021-07-17 15:02:32 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:02:32 --> Helper loaded: language_helper
INFO - 2021-07-17 15:02:32 --> Helper loaded: general_helper
INFO - 2021-07-17 15:02:32 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:02:32 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:02:32 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:32 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:02:32 --> Controller Class Initialized
DEBUG - 2021-07-17 15:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:02:32 --> Final output sent to browser
DEBUG - 2021-07-17 15:02:32 --> Total execution time: 0.1259
INFO - 2021-07-17 15:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:02:32 --> Parser Class Initialized
INFO - 2021-07-17 15:02:32 --> Form Validation Class Initialized
INFO - 2021-07-17 15:02:32 --> Upload Class Initialized
INFO - 2021-07-17 15:02:32 --> Email Class Initialized
INFO - 2021-07-17 15:02:32 --> MY_Model class loaded
INFO - 2021-07-17 15:02:32 --> Model "Users_model" initialized
INFO - 2021-07-17 15:02:32 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:02:32 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:02:32 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:02:32 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:02:32 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:02:32 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:02:32 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:32 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:02:32 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:02:32 --> Controller Class Initialized
INFO - 2021-07-17 15:02:32 --> Final output sent to browser
DEBUG - 2021-07-17 15:02:32 --> Total execution time: 0.1527
INFO - 2021-07-17 15:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:02:32 --> Parser Class Initialized
INFO - 2021-07-17 15:02:32 --> Form Validation Class Initialized
INFO - 2021-07-17 15:02:32 --> Upload Class Initialized
INFO - 2021-07-17 15:02:32 --> Email Class Initialized
INFO - 2021-07-17 15:02:32 --> MY_Model class loaded
INFO - 2021-07-17 15:02:32 --> Model "Users_model" initialized
INFO - 2021-07-17 15:02:32 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:02:32 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:02:32 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:02:32 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:02:32 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:02:32 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:02:32 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:32 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:02:32 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:02:32 --> Controller Class Initialized
INFO - 2021-07-17 15:02:32 --> Final output sent to browser
DEBUG - 2021-07-17 15:02:32 --> Total execution time: 0.1740
INFO - 2021-07-17 15:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:02:32 --> Parser Class Initialized
INFO - 2021-07-17 15:02:32 --> Form Validation Class Initialized
INFO - 2021-07-17 15:02:32 --> Upload Class Initialized
INFO - 2021-07-17 15:02:32 --> Email Class Initialized
INFO - 2021-07-17 15:02:32 --> MY_Model class loaded
INFO - 2021-07-17 15:02:32 --> Model "Users_model" initialized
INFO - 2021-07-17 15:02:32 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:02:32 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:02:32 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:02:32 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:02:32 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:02:32 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:02:32 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:32 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:02:32 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:02:32 --> Controller Class Initialized
INFO - 2021-07-17 15:02:32 --> Final output sent to browser
DEBUG - 2021-07-17 15:02:32 --> Total execution time: 0.1523
INFO - 2021-07-17 15:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:02:32 --> Parser Class Initialized
INFO - 2021-07-17 15:02:32 --> Form Validation Class Initialized
INFO - 2021-07-17 15:02:32 --> Upload Class Initialized
INFO - 2021-07-17 15:02:32 --> Email Class Initialized
INFO - 2021-07-17 15:02:32 --> MY_Model class loaded
INFO - 2021-07-17 15:02:32 --> Model "Users_model" initialized
INFO - 2021-07-17 15:02:32 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:02:32 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:02:32 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:02:32 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:02:32 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:02:32 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:02:32 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:32 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:02:32 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:02:32 --> Controller Class Initialized
INFO - 2021-07-17 15:02:32 --> Final output sent to browser
DEBUG - 2021-07-17 15:02:32 --> Total execution time: 0.1548
INFO - 2021-07-17 15:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:02:32 --> Parser Class Initialized
INFO - 2021-07-17 15:02:32 --> Form Validation Class Initialized
INFO - 2021-07-17 15:02:32 --> Upload Class Initialized
INFO - 2021-07-17 15:02:32 --> Email Class Initialized
INFO - 2021-07-17 15:02:32 --> MY_Model class loaded
INFO - 2021-07-17 15:02:32 --> Model "Users_model" initialized
INFO - 2021-07-17 15:02:32 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:02:32 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:02:32 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:02:32 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:02:32 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:02:32 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:02:32 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:32 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:02:32 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:02:32 --> Controller Class Initialized
INFO - 2021-07-17 15:02:32 --> Final output sent to browser
DEBUG - 2021-07-17 15:02:32 --> Total execution time: 0.1561
INFO - 2021-07-17 15:02:36 --> Config Class Initialized
INFO - 2021-07-17 15:02:36 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:02:36 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:02:36 --> Utf8 Class Initialized
INFO - 2021-07-17 15:02:36 --> URI Class Initialized
INFO - 2021-07-17 15:02:36 --> Router Class Initialized
INFO - 2021-07-17 15:02:36 --> Output Class Initialized
INFO - 2021-07-17 15:02:36 --> Security Class Initialized
DEBUG - 2021-07-17 15:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:02:36 --> Input Class Initialized
INFO - 2021-07-17 15:02:36 --> Language Class Initialized
INFO - 2021-07-17 15:02:36 --> Loader Class Initialized
INFO - 2021-07-17 15:02:36 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:02:36 --> Helper loaded: url_helper
INFO - 2021-07-17 15:02:36 --> Helper loaded: file_helper
INFO - 2021-07-17 15:02:36 --> Helper loaded: form_helper
INFO - 2021-07-17 15:02:36 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:02:36 --> Helper loaded: security_helper
INFO - 2021-07-17 15:02:36 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:02:36 --> Helper loaded: language_helper
INFO - 2021-07-17 15:02:36 --> Helper loaded: general_helper
INFO - 2021-07-17 15:02:36 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:02:36 --> Database Driver Class Initialized
DEBUG - 2021-07-17 15:02:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:02:36 --> Parser Class Initialized
INFO - 2021-07-17 15:02:36 --> Form Validation Class Initialized
INFO - 2021-07-17 15:02:36 --> Upload Class Initialized
INFO - 2021-07-17 15:02:36 --> Email Class Initialized
INFO - 2021-07-17 15:02:36 --> MY_Model class loaded
INFO - 2021-07-17 15:02:36 --> Model "Users_model" initialized
INFO - 2021-07-17 15:02:36 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:02:36 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:02:36 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:02:36 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:02:36 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:02:36 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:02:36 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:37 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:02:37 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:02:37 --> Controller Class Initialized
ERROR - 2021-07-17 15:02:37 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 15:02:37 --> File loaded: C:\wamp64\www\crm\application\views\users/edit.php
INFO - 2021-07-17 15:02:37 --> Final output sent to browser
DEBUG - 2021-07-17 15:02:37 --> Total execution time: 0.1266
INFO - 2021-07-17 15:02:40 --> Config Class Initialized
INFO - 2021-07-17 15:02:40 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:02:40 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:02:40 --> Utf8 Class Initialized
INFO - 2021-07-17 15:02:40 --> URI Class Initialized
INFO - 2021-07-17 15:02:40 --> Router Class Initialized
INFO - 2021-07-17 15:02:40 --> Output Class Initialized
INFO - 2021-07-17 15:02:40 --> Security Class Initialized
DEBUG - 2021-07-17 15:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:02:40 --> Input Class Initialized
INFO - 2021-07-17 15:02:40 --> Language Class Initialized
INFO - 2021-07-17 15:02:40 --> Loader Class Initialized
INFO - 2021-07-17 15:02:40 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:02:40 --> Helper loaded: url_helper
INFO - 2021-07-17 15:02:40 --> Helper loaded: file_helper
INFO - 2021-07-17 15:02:40 --> Helper loaded: form_helper
INFO - 2021-07-17 15:02:40 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:02:40 --> Helper loaded: security_helper
INFO - 2021-07-17 15:02:40 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:02:40 --> Helper loaded: language_helper
INFO - 2021-07-17 15:02:40 --> Helper loaded: general_helper
INFO - 2021-07-17 15:02:40 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:02:40 --> Database Driver Class Initialized
DEBUG - 2021-07-17 15:02:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:02:40 --> Parser Class Initialized
INFO - 2021-07-17 15:02:40 --> Form Validation Class Initialized
INFO - 2021-07-17 15:02:40 --> Upload Class Initialized
INFO - 2021-07-17 15:02:40 --> Email Class Initialized
INFO - 2021-07-17 15:02:40 --> MY_Model class loaded
INFO - 2021-07-17 15:02:40 --> Model "Users_model" initialized
INFO - 2021-07-17 15:02:40 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:02:40 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:02:40 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:02:40 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:02:40 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:02:40 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:02:40 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:40 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:02:40 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:02:40 --> Controller Class Initialized
ERROR - 2021-07-17 15:02:40 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 15:02:40 --> File loaded: C:\wamp64\www\crm\application\views\users/edit.php
INFO - 2021-07-17 15:02:40 --> Final output sent to browser
DEBUG - 2021-07-17 15:02:40 --> Total execution time: 0.0663
INFO - 2021-07-17 15:02:56 --> Config Class Initialized
INFO - 2021-07-17 15:02:56 --> Config Class Initialized
INFO - 2021-07-17 15:02:56 --> Hooks Class Initialized
INFO - 2021-07-17 15:02:56 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:02:56 --> UTF-8 Support Enabled
DEBUG - 2021-07-17 15:02:56 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:02:56 --> Utf8 Class Initialized
INFO - 2021-07-17 15:02:56 --> Utf8 Class Initialized
INFO - 2021-07-17 15:02:56 --> URI Class Initialized
INFO - 2021-07-17 15:02:56 --> URI Class Initialized
INFO - 2021-07-17 15:02:56 --> Router Class Initialized
INFO - 2021-07-17 15:02:56 --> Router Class Initialized
INFO - 2021-07-17 15:02:56 --> Output Class Initialized
INFO - 2021-07-17 15:02:56 --> Output Class Initialized
INFO - 2021-07-17 15:02:56 --> Security Class Initialized
INFO - 2021-07-17 15:02:56 --> Security Class Initialized
DEBUG - 2021-07-17 15:02:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-17 15:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:02:56 --> Input Class Initialized
INFO - 2021-07-17 15:02:56 --> Input Class Initialized
INFO - 2021-07-17 15:02:56 --> Language Class Initialized
INFO - 2021-07-17 15:02:56 --> Language Class Initialized
INFO - 2021-07-17 15:02:56 --> Loader Class Initialized
INFO - 2021-07-17 15:02:56 --> Loader Class Initialized
INFO - 2021-07-17 15:02:56 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: url_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: url_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: file_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: file_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: form_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: form_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: security_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: security_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: language_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: language_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: general_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: general_helper
INFO - 2021-07-17 15:02:56 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:02:56 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:02:56 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:56 --> Database Driver Class Initialized
DEBUG - 2021-07-17 15:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-07-17 15:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:02:56 --> Parser Class Initialized
INFO - 2021-07-17 15:02:56 --> Form Validation Class Initialized
INFO - 2021-07-17 15:02:56 --> Upload Class Initialized
INFO - 2021-07-17 15:02:56 --> Email Class Initialized
INFO - 2021-07-17 15:02:56 --> MY_Model class loaded
INFO - 2021-07-17 15:02:56 --> Model "Users_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:02:56 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:56 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:02:56 --> Controller Class Initialized
INFO - 2021-07-17 15:02:56 --> Final output sent to browser
DEBUG - 2021-07-17 15:02:56 --> Total execution time: 0.1237
INFO - 2021-07-17 15:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:02:56 --> Parser Class Initialized
INFO - 2021-07-17 15:02:56 --> Form Validation Class Initialized
INFO - 2021-07-17 15:02:56 --> Upload Class Initialized
INFO - 2021-07-17 15:02:56 --> Email Class Initialized
INFO - 2021-07-17 15:02:56 --> MY_Model class loaded
INFO - 2021-07-17 15:02:56 --> Model "Users_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:02:56 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:56 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:02:56 --> Controller Class Initialized
INFO - 2021-07-17 15:02:56 --> Final output sent to browser
DEBUG - 2021-07-17 15:02:56 --> Total execution time: 0.1524
INFO - 2021-07-17 15:02:56 --> Config Class Initialized
INFO - 2021-07-17 15:02:56 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:02:56 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:02:56 --> Utf8 Class Initialized
INFO - 2021-07-17 15:02:56 --> URI Class Initialized
INFO - 2021-07-17 15:02:56 --> Router Class Initialized
INFO - 2021-07-17 15:02:56 --> Output Class Initialized
INFO - 2021-07-17 15:02:56 --> Security Class Initialized
DEBUG - 2021-07-17 15:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:02:56 --> Input Class Initialized
INFO - 2021-07-17 15:02:56 --> Language Class Initialized
INFO - 2021-07-17 15:02:56 --> Loader Class Initialized
INFO - 2021-07-17 15:02:56 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: url_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: file_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: form_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: security_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: language_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: general_helper
INFO - 2021-07-17 15:02:56 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:02:56 --> Database Driver Class Initialized
DEBUG - 2021-07-17 15:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:02:56 --> Parser Class Initialized
INFO - 2021-07-17 15:02:56 --> Form Validation Class Initialized
INFO - 2021-07-17 15:02:56 --> Upload Class Initialized
INFO - 2021-07-17 15:02:56 --> Email Class Initialized
INFO - 2021-07-17 15:02:56 --> MY_Model class loaded
INFO - 2021-07-17 15:02:56 --> Model "Users_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:02:56 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:56 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:02:56 --> Controller Class Initialized
INFO - 2021-07-17 15:02:56 --> Config Class Initialized
INFO - 2021-07-17 15:02:56 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:02:56 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:02:56 --> Utf8 Class Initialized
INFO - 2021-07-17 15:02:56 --> URI Class Initialized
INFO - 2021-07-17 15:02:56 --> Router Class Initialized
INFO - 2021-07-17 15:02:56 --> Output Class Initialized
INFO - 2021-07-17 15:02:56 --> Security Class Initialized
DEBUG - 2021-07-17 15:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:02:56 --> Input Class Initialized
INFO - 2021-07-17 15:02:56 --> Language Class Initialized
INFO - 2021-07-17 15:02:56 --> Loader Class Initialized
INFO - 2021-07-17 15:02:56 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: url_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: file_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: form_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: security_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: language_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: general_helper
INFO - 2021-07-17 15:02:56 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:02:56 --> Database Driver Class Initialized
DEBUG - 2021-07-17 15:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:02:56 --> Parser Class Initialized
INFO - 2021-07-17 15:02:56 --> Form Validation Class Initialized
INFO - 2021-07-17 15:02:56 --> Upload Class Initialized
INFO - 2021-07-17 15:02:56 --> Email Class Initialized
INFO - 2021-07-17 15:02:56 --> MY_Model class loaded
INFO - 2021-07-17 15:02:56 --> Model "Users_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:02:56 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:56 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:02:56 --> Controller Class Initialized
ERROR - 2021-07-17 15:02:56 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 15:02:56 --> File loaded: C:\wamp64\www\crm\application\views\users/list.php
INFO - 2021-07-17 15:02:56 --> Final output sent to browser
DEBUG - 2021-07-17 15:02:56 --> Total execution time: 0.1173
INFO - 2021-07-17 15:02:56 --> Config Class Initialized
INFO - 2021-07-17 15:02:56 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:02:56 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:02:56 --> Utf8 Class Initialized
INFO - 2021-07-17 15:02:56 --> URI Class Initialized
INFO - 2021-07-17 15:02:56 --> Router Class Initialized
INFO - 2021-07-17 15:02:56 --> Output Class Initialized
INFO - 2021-07-17 15:02:56 --> Security Class Initialized
DEBUG - 2021-07-17 15:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:02:56 --> Input Class Initialized
INFO - 2021-07-17 15:02:56 --> Language Class Initialized
INFO - 2021-07-17 15:02:56 --> Loader Class Initialized
INFO - 2021-07-17 15:02:56 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: url_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: file_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: form_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: security_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: language_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: general_helper
INFO - 2021-07-17 15:02:56 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:02:56 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:56 --> Config Class Initialized
INFO - 2021-07-17 15:02:56 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:02:56 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:02:56 --> Utf8 Class Initialized
INFO - 2021-07-17 15:02:56 --> URI Class Initialized
INFO - 2021-07-17 15:02:56 --> Router Class Initialized
INFO - 2021-07-17 15:02:56 --> Config Class Initialized
INFO - 2021-07-17 15:02:56 --> Output Class Initialized
INFO - 2021-07-17 15:02:56 --> Hooks Class Initialized
INFO - 2021-07-17 15:02:56 --> Security Class Initialized
DEBUG - 2021-07-17 15:02:56 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:02:56 --> Utf8 Class Initialized
DEBUG - 2021-07-17 15:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:02:56 --> Input Class Initialized
INFO - 2021-07-17 15:02:56 --> URI Class Initialized
INFO - 2021-07-17 15:02:56 --> Language Class Initialized
INFO - 2021-07-17 15:02:56 --> Router Class Initialized
INFO - 2021-07-17 15:02:56 --> Loader Class Initialized
INFO - 2021-07-17 15:02:56 --> Output Class Initialized
DEBUG - 2021-07-17 15:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:02:56 --> Security Class Initialized
INFO - 2021-07-17 15:02:56 --> Config Class Initialized
INFO - 2021-07-17 15:02:56 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:02:56 --> Hooks Class Initialized
INFO - 2021-07-17 15:02:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2021-07-17 15:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:02:56 --> Helper loaded: url_helper
DEBUG - 2021-07-17 15:02:56 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:02:56 --> Input Class Initialized
INFO - 2021-07-17 15:02:56 --> Parser Class Initialized
INFO - 2021-07-17 15:02:56 --> Helper loaded: file_helper
INFO - 2021-07-17 15:02:56 --> Utf8 Class Initialized
INFO - 2021-07-17 15:02:56 --> Language Class Initialized
INFO - 2021-07-17 15:02:56 --> Helper loaded: form_helper
INFO - 2021-07-17 15:02:56 --> Form Validation Class Initialized
INFO - 2021-07-17 15:02:56 --> URI Class Initialized
INFO - 2021-07-17 15:02:56 --> Loader Class Initialized
INFO - 2021-07-17 15:02:56 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:02:56 --> Upload Class Initialized
INFO - 2021-07-17 15:02:56 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: security_helper
INFO - 2021-07-17 15:02:56 --> Router Class Initialized
INFO - 2021-07-17 15:02:56 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: url_helper
INFO - 2021-07-17 15:02:56 --> Email Class Initialized
INFO - 2021-07-17 15:02:56 --> Output Class Initialized
INFO - 2021-07-17 15:02:56 --> Helper loaded: language_helper
INFO - 2021-07-17 15:02:56 --> MY_Model class loaded
INFO - 2021-07-17 15:02:56 --> Helper loaded: file_helper
INFO - 2021-07-17 15:02:56 --> Security Class Initialized
INFO - 2021-07-17 15:02:56 --> Helper loaded: general_helper
INFO - 2021-07-17 15:02:56 --> Model "Users_model" initialized
INFO - 2021-07-17 15:02:56 --> Helper loaded: form_helper
INFO - 2021-07-17 15:02:56 --> Model "Settings_model" initialized
DEBUG - 2021-07-17 15:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:02:56 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:02:56 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:02:56 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:02:56 --> Input Class Initialized
INFO - 2021-07-17 15:02:56 --> Config Class Initialized
INFO - 2021-07-17 15:02:56 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:02:56 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:56 --> Helper loaded: security_helper
INFO - 2021-07-17 15:02:56 --> Language Class Initialized
INFO - 2021-07-17 15:02:56 --> Hooks Class Initialized
INFO - 2021-07-17 15:02:56 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:02:56 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:02:56 --> Loader Class Initialized
INFO - 2021-07-17 15:02:56 --> Model "Activity_model" initialized
DEBUG - 2021-07-17 15:02:56 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:02:56 --> Helper loaded: language_helper
INFO - 2021-07-17 15:02:56 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:02:56 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:02:56 --> Utf8 Class Initialized
INFO - 2021-07-17 15:02:56 --> Helper loaded: general_helper
INFO - 2021-07-17 15:02:56 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:56 --> Helper loaded: url_helper
DEBUG - 2021-07-17 15:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:02:56 --> Config Class Initialized
INFO - 2021-07-17 15:02:56 --> URI Class Initialized
INFO - 2021-07-17 15:02:56 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:02:56 --> Hooks Class Initialized
INFO - 2021-07-17 15:02:56 --> Helper loaded: file_helper
INFO - 2021-07-17 15:02:56 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:56 --> Router Class Initialized
INFO - 2021-07-17 15:02:56 --> Helper loaded: form_helper
DEBUG - 2021-07-17 15:02:56 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:02:56 --> Utf8 Class Initialized
INFO - 2021-07-17 15:02:56 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:02:56 --> Output Class Initialized
INFO - 2021-07-17 15:02:56 --> URI Class Initialized
INFO - 2021-07-17 15:02:56 --> Helper loaded: security_helper
INFO - 2021-07-17 15:02:56 --> Security Class Initialized
INFO - 2021-07-17 15:02:56 --> Helper loaded: directory_helper
DEBUG - 2021-07-17 15:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:02:56 --> Router Class Initialized
DEBUG - 2021-07-17 15:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:02:56 --> Helper loaded: language_helper
INFO - 2021-07-17 15:02:56 --> Input Class Initialized
INFO - 2021-07-17 15:02:56 --> Output Class Initialized
INFO - 2021-07-17 15:02:56 --> Helper loaded: general_helper
INFO - 2021-07-17 15:02:56 --> Language Class Initialized
INFO - 2021-07-17 15:02:56 --> Security Class Initialized
INFO - 2021-07-17 15:02:56 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:02:56 --> Loader Class Initialized
DEBUG - 2021-07-17 15:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:02:56 --> Input Class Initialized
INFO - 2021-07-17 15:02:56 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:56 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:02:56 --> Language Class Initialized
INFO - 2021-07-17 15:02:56 --> Helper loaded: url_helper
INFO - 2021-07-17 15:02:56 --> Loader Class Initialized
INFO - 2021-07-17 15:02:56 --> Helper loaded: file_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: form_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: url_helper
DEBUG - 2021-07-17 15:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:02:56 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: file_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: security_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: form_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: language_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: security_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: general_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:02:56 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:02:56 --> Helper loaded: language_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: general_helper
INFO - 2021-07-17 15:02:56 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:56 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:02:56 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:02:56 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:56 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:02:56 --> Controller Class Initialized
DEBUG - 2021-07-17 15:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-07-17 15:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:02:56 --> Final output sent to browser
DEBUG - 2021-07-17 15:02:56 --> Total execution time: 0.0560
INFO - 2021-07-17 15:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:02:56 --> Parser Class Initialized
INFO - 2021-07-17 15:02:56 --> Form Validation Class Initialized
INFO - 2021-07-17 15:02:56 --> Upload Class Initialized
INFO - 2021-07-17 15:02:56 --> Email Class Initialized
INFO - 2021-07-17 15:02:56 --> MY_Model class loaded
INFO - 2021-07-17 15:02:56 --> Model "Users_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:02:56 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:56 --> Config Class Initialized
INFO - 2021-07-17 15:02:56 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:02:56 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:02:56 --> Utf8 Class Initialized
INFO - 2021-07-17 15:02:56 --> URI Class Initialized
INFO - 2021-07-17 15:02:56 --> Router Class Initialized
INFO - 2021-07-17 15:02:56 --> Output Class Initialized
INFO - 2021-07-17 15:02:56 --> Security Class Initialized
DEBUG - 2021-07-17 15:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:02:56 --> Input Class Initialized
INFO - 2021-07-17 15:02:56 --> Language Class Initialized
INFO - 2021-07-17 15:02:56 --> Loader Class Initialized
INFO - 2021-07-17 15:02:56 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: url_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: file_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: form_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: security_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:02:56 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:02:56 --> Helper loaded: language_helper
INFO - 2021-07-17 15:02:56 --> Controller Class Initialized
INFO - 2021-07-17 15:02:56 --> Helper loaded: general_helper
INFO - 2021-07-17 15:02:56 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:02:56 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:56 --> Final output sent to browser
DEBUG - 2021-07-17 15:02:56 --> Total execution time: 0.0690
INFO - 2021-07-17 15:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:02:56 --> Parser Class Initialized
INFO - 2021-07-17 15:02:56 --> Form Validation Class Initialized
INFO - 2021-07-17 15:02:56 --> Upload Class Initialized
INFO - 2021-07-17 15:02:56 --> Email Class Initialized
INFO - 2021-07-17 15:02:56 --> MY_Model class loaded
INFO - 2021-07-17 15:02:56 --> Model "Users_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:02:56 --> Database Driver Class Initialized
DEBUG - 2021-07-17 15:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:02:56 --> Config Class Initialized
INFO - 2021-07-17 15:02:56 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:02:56 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:02:56 --> Utf8 Class Initialized
INFO - 2021-07-17 15:02:56 --> URI Class Initialized
INFO - 2021-07-17 15:02:56 --> Router Class Initialized
INFO - 2021-07-17 15:02:56 --> Output Class Initialized
INFO - 2021-07-17 15:02:56 --> Security Class Initialized
DEBUG - 2021-07-17 15:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:02:56 --> Input Class Initialized
INFO - 2021-07-17 15:02:56 --> Language Class Initialized
INFO - 2021-07-17 15:02:56 --> Loader Class Initialized
INFO - 2021-07-17 15:02:56 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: url_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: file_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: form_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: security_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: language_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: general_helper
INFO - 2021-07-17 15:02:56 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:02:56 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:56 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:02:56 --> Controller Class Initialized
DEBUG - 2021-07-17 15:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:02:56 --> Final output sent to browser
DEBUG - 2021-07-17 15:02:56 --> Total execution time: 0.0938
INFO - 2021-07-17 15:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:02:56 --> Parser Class Initialized
INFO - 2021-07-17 15:02:56 --> Form Validation Class Initialized
INFO - 2021-07-17 15:02:56 --> Upload Class Initialized
INFO - 2021-07-17 15:02:56 --> Email Class Initialized
INFO - 2021-07-17 15:02:56 --> MY_Model class loaded
INFO - 2021-07-17 15:02:56 --> Model "Users_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:02:56 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:56 --> Config Class Initialized
INFO - 2021-07-17 15:02:56 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:02:56 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:02:56 --> Utf8 Class Initialized
INFO - 2021-07-17 15:02:56 --> URI Class Initialized
INFO - 2021-07-17 15:02:56 --> Router Class Initialized
INFO - 2021-07-17 15:02:56 --> Output Class Initialized
INFO - 2021-07-17 15:02:56 --> Security Class Initialized
DEBUG - 2021-07-17 15:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:02:56 --> Input Class Initialized
INFO - 2021-07-17 15:02:56 --> Language Class Initialized
INFO - 2021-07-17 15:02:56 --> Loader Class Initialized
INFO - 2021-07-17 15:02:56 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: url_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: file_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: form_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: security_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: language_helper
INFO - 2021-07-17 15:02:56 --> Helper loaded: general_helper
INFO - 2021-07-17 15:02:56 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:02:56 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:02:56 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:02:56 --> Controller Class Initialized
INFO - 2021-07-17 15:02:56 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:56 --> Final output sent to browser
DEBUG - 2021-07-17 15:02:56 --> Total execution time: 0.1165
INFO - 2021-07-17 15:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:02:56 --> Parser Class Initialized
INFO - 2021-07-17 15:02:56 --> Form Validation Class Initialized
INFO - 2021-07-17 15:02:56 --> Upload Class Initialized
INFO - 2021-07-17 15:02:56 --> Email Class Initialized
INFO - 2021-07-17 15:02:56 --> MY_Model class loaded
INFO - 2021-07-17 15:02:56 --> Model "Users_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Role_permissions_model" initialized
DEBUG - 2021-07-17 15:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:02:56 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:02:56 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:56 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:02:56 --> Controller Class Initialized
INFO - 2021-07-17 15:02:56 --> Final output sent to browser
DEBUG - 2021-07-17 15:02:56 --> Total execution time: 0.1365
INFO - 2021-07-17 15:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:02:56 --> Parser Class Initialized
INFO - 2021-07-17 15:02:56 --> Form Validation Class Initialized
INFO - 2021-07-17 15:02:56 --> Upload Class Initialized
INFO - 2021-07-17 15:02:56 --> Email Class Initialized
INFO - 2021-07-17 15:02:56 --> MY_Model class loaded
INFO - 2021-07-17 15:02:56 --> Model "Users_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:02:56 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:56 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:02:56 --> Controller Class Initialized
INFO - 2021-07-17 15:02:56 --> Final output sent to browser
DEBUG - 2021-07-17 15:02:56 --> Total execution time: 0.1600
INFO - 2021-07-17 15:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:02:56 --> Parser Class Initialized
INFO - 2021-07-17 15:02:56 --> Form Validation Class Initialized
INFO - 2021-07-17 15:02:56 --> Upload Class Initialized
INFO - 2021-07-17 15:02:56 --> Email Class Initialized
INFO - 2021-07-17 15:02:56 --> MY_Model class loaded
INFO - 2021-07-17 15:02:56 --> Model "Users_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:02:56 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:56 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:02:56 --> Controller Class Initialized
INFO - 2021-07-17 15:02:56 --> Final output sent to browser
DEBUG - 2021-07-17 15:02:56 --> Total execution time: 0.1546
INFO - 2021-07-17 15:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:02:56 --> Parser Class Initialized
INFO - 2021-07-17 15:02:56 --> Form Validation Class Initialized
INFO - 2021-07-17 15:02:56 --> Upload Class Initialized
INFO - 2021-07-17 15:02:56 --> Email Class Initialized
INFO - 2021-07-17 15:02:56 --> MY_Model class loaded
INFO - 2021-07-17 15:02:56 --> Model "Users_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:02:56 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:56 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:02:56 --> Controller Class Initialized
INFO - 2021-07-17 15:02:56 --> Final output sent to browser
DEBUG - 2021-07-17 15:02:56 --> Total execution time: 0.1605
INFO - 2021-07-17 15:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:02:56 --> Parser Class Initialized
INFO - 2021-07-17 15:02:56 --> Form Validation Class Initialized
INFO - 2021-07-17 15:02:56 --> Upload Class Initialized
INFO - 2021-07-17 15:02:56 --> Email Class Initialized
INFO - 2021-07-17 15:02:56 --> MY_Model class loaded
INFO - 2021-07-17 15:02:56 --> Model "Users_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:02:56 --> Database Driver Class Initialized
INFO - 2021-07-17 15:02:56 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:02:56 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:02:56 --> Controller Class Initialized
INFO - 2021-07-17 15:02:56 --> Final output sent to browser
DEBUG - 2021-07-17 15:02:56 --> Total execution time: 0.1604
INFO - 2021-07-17 15:04:51 --> Config Class Initialized
INFO - 2021-07-17 15:04:51 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:04:51 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:04:51 --> Utf8 Class Initialized
INFO - 2021-07-17 15:04:51 --> URI Class Initialized
INFO - 2021-07-17 15:04:51 --> Router Class Initialized
INFO - 2021-07-17 15:04:51 --> Output Class Initialized
INFO - 2021-07-17 15:04:51 --> Security Class Initialized
DEBUG - 2021-07-17 15:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:04:51 --> Input Class Initialized
INFO - 2021-07-17 15:04:51 --> Language Class Initialized
INFO - 2021-07-17 15:04:51 --> Loader Class Initialized
INFO - 2021-07-17 15:04:51 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:04:51 --> Helper loaded: url_helper
INFO - 2021-07-17 15:04:51 --> Helper loaded: file_helper
INFO - 2021-07-17 15:04:51 --> Helper loaded: form_helper
INFO - 2021-07-17 15:04:51 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:04:51 --> Helper loaded: security_helper
INFO - 2021-07-17 15:04:51 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:04:51 --> Helper loaded: language_helper
INFO - 2021-07-17 15:04:51 --> Helper loaded: general_helper
INFO - 2021-07-17 15:04:51 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:04:51 --> Database Driver Class Initialized
DEBUG - 2021-07-17 15:04:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:04:51 --> Parser Class Initialized
INFO - 2021-07-17 15:04:51 --> Form Validation Class Initialized
INFO - 2021-07-17 15:04:51 --> Upload Class Initialized
INFO - 2021-07-17 15:04:51 --> Email Class Initialized
INFO - 2021-07-17 15:04:51 --> MY_Model class loaded
INFO - 2021-07-17 15:04:51 --> Model "Users_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:04:51 --> Database Driver Class Initialized
INFO - 2021-07-17 15:04:51 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:04:51 --> Controller Class Initialized
ERROR - 2021-07-17 15:04:51 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 15:04:51 --> File loaded: C:\wamp64\www\crm\application\views\users/list.php
INFO - 2021-07-17 15:04:51 --> Final output sent to browser
DEBUG - 2021-07-17 15:04:51 --> Total execution time: 0.1837
INFO - 2021-07-17 15:04:51 --> Config Class Initialized
INFO - 2021-07-17 15:04:51 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:04:51 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:04:51 --> Utf8 Class Initialized
INFO - 2021-07-17 15:04:51 --> URI Class Initialized
INFO - 2021-07-17 15:04:51 --> Router Class Initialized
INFO - 2021-07-17 15:04:51 --> Output Class Initialized
INFO - 2021-07-17 15:04:51 --> Security Class Initialized
DEBUG - 2021-07-17 15:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:04:51 --> Input Class Initialized
INFO - 2021-07-17 15:04:51 --> Language Class Initialized
INFO - 2021-07-17 15:04:51 --> Loader Class Initialized
INFO - 2021-07-17 15:04:51 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:04:51 --> Helper loaded: url_helper
INFO - 2021-07-17 15:04:51 --> Helper loaded: file_helper
INFO - 2021-07-17 15:04:51 --> Helper loaded: form_helper
INFO - 2021-07-17 15:04:51 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:04:51 --> Helper loaded: security_helper
INFO - 2021-07-17 15:04:51 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:04:51 --> Helper loaded: language_helper
INFO - 2021-07-17 15:04:51 --> Config Class Initialized
INFO - 2021-07-17 15:04:51 --> Hooks Class Initialized
INFO - 2021-07-17 15:04:51 --> Helper loaded: general_helper
DEBUG - 2021-07-17 15:04:51 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:04:51 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:04:51 --> Utf8 Class Initialized
INFO - 2021-07-17 15:04:51 --> Database Driver Class Initialized
INFO - 2021-07-17 15:04:51 --> URI Class Initialized
INFO - 2021-07-17 15:04:51 --> Router Class Initialized
INFO - 2021-07-17 15:04:51 --> Output Class Initialized
INFO - 2021-07-17 15:04:51 --> Security Class Initialized
DEBUG - 2021-07-17 15:04:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-07-17 15:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:04:51 --> Input Class Initialized
INFO - 2021-07-17 15:04:51 --> Config Class Initialized
INFO - 2021-07-17 15:04:51 --> Language Class Initialized
INFO - 2021-07-17 15:04:51 --> Parser Class Initialized
INFO - 2021-07-17 15:04:51 --> Hooks Class Initialized
INFO - 2021-07-17 15:04:51 --> Loader Class Initialized
INFO - 2021-07-17 15:04:51 --> Form Validation Class Initialized
DEBUG - 2021-07-17 15:04:51 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:04:51 --> Utf8 Class Initialized
INFO - 2021-07-17 15:04:51 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:04:51 --> Upload Class Initialized
INFO - 2021-07-17 15:04:51 --> URI Class Initialized
INFO - 2021-07-17 15:04:51 --> Helper loaded: url_helper
INFO - 2021-07-17 15:04:51 --> Email Class Initialized
INFO - 2021-07-17 15:04:51 --> Helper loaded: file_helper
INFO - 2021-07-17 15:04:51 --> Router Class Initialized
INFO - 2021-07-17 15:04:51 --> MY_Model class loaded
INFO - 2021-07-17 15:04:51 --> Helper loaded: form_helper
INFO - 2021-07-17 15:04:51 --> Model "Users_model" initialized
INFO - 2021-07-17 15:04:51 --> Output Class Initialized
INFO - 2021-07-17 15:04:51 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:04:51 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:04:51 --> Security Class Initialized
INFO - 2021-07-17 15:04:51 --> Config Class Initialized
INFO - 2021-07-17 15:04:51 --> Helper loaded: security_helper
INFO - 2021-07-17 15:04:51 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:04:51 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:04:51 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:04:51 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:04:51 --> Input Class Initialized
DEBUG - 2021-07-17 15:04:51 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:04:51 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:04:51 --> Helper loaded: language_helper
INFO - 2021-07-17 15:04:51 --> Language Class Initialized
INFO - 2021-07-17 15:04:51 --> Utf8 Class Initialized
INFO - 2021-07-17 15:04:51 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:04:51 --> Helper loaded: general_helper
INFO - 2021-07-17 15:04:51 --> URI Class Initialized
INFO - 2021-07-17 15:04:51 --> Loader Class Initialized
INFO - 2021-07-17 15:04:51 --> Database Driver Class Initialized
INFO - 2021-07-17 15:04:51 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:04:51 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:04:51 --> Router Class Initialized
INFO - 2021-07-17 15:04:51 --> Database Driver Class Initialized
INFO - 2021-07-17 15:04:51 --> Helper loaded: url_helper
INFO - 2021-07-17 15:04:51 --> Output Class Initialized
INFO - 2021-07-17 15:04:51 --> Helper loaded: file_helper
INFO - 2021-07-17 15:04:51 --> Config Class Initialized
INFO - 2021-07-17 15:04:51 --> Security Class Initialized
INFO - 2021-07-17 15:04:51 --> Hooks Class Initialized
INFO - 2021-07-17 15:04:51 --> Helper loaded: form_helper
DEBUG - 2021-07-17 15:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:04:51 --> Helper loaded: cookie_helper
DEBUG - 2021-07-17 15:04:51 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:04:51 --> Input Class Initialized
DEBUG - 2021-07-17 15:04:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:04:51 --> Utf8 Class Initialized
INFO - 2021-07-17 15:04:51 --> Helper loaded: security_helper
INFO - 2021-07-17 15:04:51 --> Language Class Initialized
INFO - 2021-07-17 15:04:51 --> URI Class Initialized
INFO - 2021-07-17 15:04:51 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:04:51 --> Loader Class Initialized
INFO - 2021-07-17 15:04:51 --> Router Class Initialized
INFO - 2021-07-17 15:04:51 --> Helper loaded: language_helper
INFO - 2021-07-17 15:04:51 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:04:51 --> Output Class Initialized
INFO - 2021-07-17 15:04:51 --> Helper loaded: general_helper
INFO - 2021-07-17 15:04:51 --> Helper loaded: url_helper
INFO - 2021-07-17 15:04:51 --> Config Class Initialized
INFO - 2021-07-17 15:04:51 --> Security Class Initialized
INFO - 2021-07-17 15:04:51 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:04:51 --> Helper loaded: file_helper
INFO - 2021-07-17 15:04:51 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:04:51 --> Helper loaded: form_helper
INFO - 2021-07-17 15:04:51 --> Database Driver Class Initialized
INFO - 2021-07-17 15:04:51 --> Input Class Initialized
DEBUG - 2021-07-17 15:04:51 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:04:51 --> Utf8 Class Initialized
INFO - 2021-07-17 15:04:51 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:04:51 --> Language Class Initialized
INFO - 2021-07-17 15:04:51 --> URI Class Initialized
INFO - 2021-07-17 15:04:51 --> Helper loaded: security_helper
INFO - 2021-07-17 15:04:51 --> Loader Class Initialized
INFO - 2021-07-17 15:04:51 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:04:51 --> Router Class Initialized
INFO - 2021-07-17 15:04:51 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:04:51 --> Helper loaded: language_helper
DEBUG - 2021-07-17 15:04:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:04:51 --> Output Class Initialized
INFO - 2021-07-17 15:04:51 --> Helper loaded: general_helper
INFO - 2021-07-17 15:04:51 --> Helper loaded: url_helper
INFO - 2021-07-17 15:04:51 --> Security Class Initialized
INFO - 2021-07-17 15:04:51 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:04:51 --> Helper loaded: file_helper
DEBUG - 2021-07-17 15:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:04:51 --> Input Class Initialized
INFO - 2021-07-17 15:04:51 --> Helper loaded: form_helper
INFO - 2021-07-17 15:04:51 --> Database Driver Class Initialized
INFO - 2021-07-17 15:04:51 --> Language Class Initialized
INFO - 2021-07-17 15:04:51 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:04:51 --> Loader Class Initialized
INFO - 2021-07-17 15:04:51 --> Helper loaded: security_helper
INFO - 2021-07-17 15:04:51 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:04:51 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:04:51 --> Model "Hesaplar_model" initialized
DEBUG - 2021-07-17 15:04:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:04:51 --> Helper loaded: language_helper
INFO - 2021-07-17 15:04:51 --> Helper loaded: url_helper
INFO - 2021-07-17 15:04:51 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:04:51 --> Helper loaded: general_helper
INFO - 2021-07-17 15:04:51 --> Controller Class Initialized
INFO - 2021-07-17 15:04:51 --> Helper loaded: file_helper
INFO - 2021-07-17 15:04:51 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:04:51 --> Helper loaded: form_helper
INFO - 2021-07-17 15:04:51 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:04:51 --> Database Driver Class Initialized
INFO - 2021-07-17 15:04:51 --> Helper loaded: security_helper
INFO - 2021-07-17 15:04:51 --> Final output sent to browser
INFO - 2021-07-17 15:04:51 --> Helper loaded: directory_helper
DEBUG - 2021-07-17 15:04:51 --> Total execution time: 0.0503
INFO - 2021-07-17 15:04:51 --> Helper loaded: language_helper
INFO - 2021-07-17 15:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:04:51 --> Helper loaded: general_helper
DEBUG - 2021-07-17 15:04:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:04:51 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:04:51 --> Parser Class Initialized
INFO - 2021-07-17 15:04:51 --> Database Driver Class Initialized
INFO - 2021-07-17 15:04:51 --> Form Validation Class Initialized
INFO - 2021-07-17 15:04:51 --> Upload Class Initialized
INFO - 2021-07-17 15:04:51 --> Email Class Initialized
INFO - 2021-07-17 15:04:51 --> MY_Model class loaded
INFO - 2021-07-17 15:04:51 --> Model "Users_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:04:51 --> Database Driver Class Initialized
INFO - 2021-07-17 15:04:51 --> Config Class Initialized
INFO - 2021-07-17 15:04:51 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:04:51 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:04:51 --> Utf8 Class Initialized
INFO - 2021-07-17 15:04:51 --> URI Class Initialized
DEBUG - 2021-07-17 15:04:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:04:51 --> Router Class Initialized
INFO - 2021-07-17 15:04:51 --> Output Class Initialized
INFO - 2021-07-17 15:04:51 --> Security Class Initialized
DEBUG - 2021-07-17 15:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:04:51 --> Input Class Initialized
INFO - 2021-07-17 15:04:51 --> Language Class Initialized
INFO - 2021-07-17 15:04:51 --> Loader Class Initialized
INFO - 2021-07-17 15:04:51 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:04:51 --> Helper loaded: url_helper
INFO - 2021-07-17 15:04:51 --> Helper loaded: file_helper
INFO - 2021-07-17 15:04:51 --> Helper loaded: form_helper
INFO - 2021-07-17 15:04:51 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:04:51 --> Helper loaded: security_helper
INFO - 2021-07-17 15:04:51 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:04:51 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:04:51 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:04:51 --> Helper loaded: language_helper
INFO - 2021-07-17 15:04:51 --> Controller Class Initialized
INFO - 2021-07-17 15:04:51 --> Helper loaded: general_helper
INFO - 2021-07-17 15:04:51 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:04:51 --> Database Driver Class Initialized
INFO - 2021-07-17 15:04:51 --> Final output sent to browser
DEBUG - 2021-07-17 15:04:51 --> Total execution time: 0.0667
INFO - 2021-07-17 15:04:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2021-07-17 15:04:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:04:51 --> Parser Class Initialized
INFO - 2021-07-17 15:04:51 --> Form Validation Class Initialized
INFO - 2021-07-17 15:04:51 --> Upload Class Initialized
INFO - 2021-07-17 15:04:51 --> Email Class Initialized
INFO - 2021-07-17 15:04:51 --> MY_Model class loaded
INFO - 2021-07-17 15:04:51 --> Model "Users_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:04:51 --> Database Driver Class Initialized
INFO - 2021-07-17 15:04:51 --> Config Class Initialized
INFO - 2021-07-17 15:04:51 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:04:51 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:04:51 --> Utf8 Class Initialized
INFO - 2021-07-17 15:04:51 --> URI Class Initialized
INFO - 2021-07-17 15:04:51 --> Router Class Initialized
INFO - 2021-07-17 15:04:51 --> Output Class Initialized
INFO - 2021-07-17 15:04:51 --> Security Class Initialized
DEBUG - 2021-07-17 15:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:04:51 --> Input Class Initialized
INFO - 2021-07-17 15:04:51 --> Language Class Initialized
INFO - 2021-07-17 15:04:51 --> Loader Class Initialized
INFO - 2021-07-17 15:04:51 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:04:51 --> Helper loaded: url_helper
INFO - 2021-07-17 15:04:51 --> Helper loaded: file_helper
INFO - 2021-07-17 15:04:51 --> Helper loaded: form_helper
INFO - 2021-07-17 15:04:51 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:04:51 --> Helper loaded: security_helper
INFO - 2021-07-17 15:04:51 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:04:51 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:04:51 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:04:51 --> Controller Class Initialized
INFO - 2021-07-17 15:04:51 --> Helper loaded: language_helper
INFO - 2021-07-17 15:04:51 --> Helper loaded: general_helper
INFO - 2021-07-17 15:04:51 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:04:51 --> Database Driver Class Initialized
INFO - 2021-07-17 15:04:51 --> Final output sent to browser
DEBUG - 2021-07-17 15:04:51 --> Total execution time: 0.0889
INFO - 2021-07-17 15:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:04:51 --> Parser Class Initialized
DEBUG - 2021-07-17 15:04:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:04:51 --> Form Validation Class Initialized
INFO - 2021-07-17 15:04:51 --> Upload Class Initialized
INFO - 2021-07-17 15:04:51 --> Email Class Initialized
INFO - 2021-07-17 15:04:51 --> MY_Model class loaded
INFO - 2021-07-17 15:04:51 --> Model "Users_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:04:51 --> Database Driver Class Initialized
INFO - 2021-07-17 15:04:51 --> Config Class Initialized
INFO - 2021-07-17 15:04:51 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:04:51 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:04:51 --> Utf8 Class Initialized
INFO - 2021-07-17 15:04:51 --> URI Class Initialized
INFO - 2021-07-17 15:04:51 --> Router Class Initialized
INFO - 2021-07-17 15:04:51 --> Output Class Initialized
INFO - 2021-07-17 15:04:51 --> Security Class Initialized
DEBUG - 2021-07-17 15:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:04:51 --> Input Class Initialized
INFO - 2021-07-17 15:04:51 --> Language Class Initialized
INFO - 2021-07-17 15:04:51 --> Loader Class Initialized
INFO - 2021-07-17 15:04:51 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:04:51 --> Helper loaded: url_helper
INFO - 2021-07-17 15:04:51 --> Helper loaded: file_helper
INFO - 2021-07-17 15:04:51 --> Helper loaded: form_helper
INFO - 2021-07-17 15:04:51 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:04:51 --> Helper loaded: security_helper
INFO - 2021-07-17 15:04:51 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:04:51 --> Helper loaded: language_helper
INFO - 2021-07-17 15:04:51 --> Helper loaded: general_helper
INFO - 2021-07-17 15:04:51 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:04:51 --> Database Driver Class Initialized
INFO - 2021-07-17 15:04:51 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:04:51 --> Controller Class Initialized
DEBUG - 2021-07-17 15:04:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:04:51 --> Final output sent to browser
DEBUG - 2021-07-17 15:04:51 --> Total execution time: 0.1108
INFO - 2021-07-17 15:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:04:51 --> Parser Class Initialized
INFO - 2021-07-17 15:04:51 --> Form Validation Class Initialized
INFO - 2021-07-17 15:04:51 --> Upload Class Initialized
INFO - 2021-07-17 15:04:51 --> Email Class Initialized
INFO - 2021-07-17 15:04:51 --> MY_Model class loaded
INFO - 2021-07-17 15:04:51 --> Model "Users_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:04:51 --> Database Driver Class Initialized
INFO - 2021-07-17 15:04:51 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:04:51 --> Controller Class Initialized
INFO - 2021-07-17 15:04:51 --> Final output sent to browser
DEBUG - 2021-07-17 15:04:51 --> Total execution time: 0.1338
INFO - 2021-07-17 15:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:04:51 --> Parser Class Initialized
INFO - 2021-07-17 15:04:51 --> Form Validation Class Initialized
INFO - 2021-07-17 15:04:51 --> Upload Class Initialized
INFO - 2021-07-17 15:04:51 --> Email Class Initialized
INFO - 2021-07-17 15:04:51 --> MY_Model class loaded
INFO - 2021-07-17 15:04:51 --> Model "Users_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:04:51 --> Database Driver Class Initialized
INFO - 2021-07-17 15:04:51 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:04:51 --> Controller Class Initialized
INFO - 2021-07-17 15:04:51 --> Final output sent to browser
DEBUG - 2021-07-17 15:04:51 --> Total execution time: 0.1565
INFO - 2021-07-17 15:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:04:51 --> Parser Class Initialized
INFO - 2021-07-17 15:04:51 --> Form Validation Class Initialized
INFO - 2021-07-17 15:04:51 --> Upload Class Initialized
INFO - 2021-07-17 15:04:51 --> Email Class Initialized
INFO - 2021-07-17 15:04:51 --> MY_Model class loaded
INFO - 2021-07-17 15:04:51 --> Model "Users_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:04:51 --> Database Driver Class Initialized
INFO - 2021-07-17 15:04:51 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:04:51 --> Controller Class Initialized
INFO - 2021-07-17 15:04:51 --> Final output sent to browser
DEBUG - 2021-07-17 15:04:51 --> Total execution time: 0.1580
INFO - 2021-07-17 15:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:04:51 --> Parser Class Initialized
INFO - 2021-07-17 15:04:51 --> Form Validation Class Initialized
INFO - 2021-07-17 15:04:51 --> Upload Class Initialized
INFO - 2021-07-17 15:04:51 --> Email Class Initialized
INFO - 2021-07-17 15:04:51 --> MY_Model class loaded
INFO - 2021-07-17 15:04:51 --> Model "Users_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:04:51 --> Database Driver Class Initialized
INFO - 2021-07-17 15:04:51 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:04:51 --> Controller Class Initialized
INFO - 2021-07-17 15:04:51 --> Final output sent to browser
DEBUG - 2021-07-17 15:04:51 --> Total execution time: 0.1584
INFO - 2021-07-17 15:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:04:51 --> Parser Class Initialized
INFO - 2021-07-17 15:04:51 --> Form Validation Class Initialized
INFO - 2021-07-17 15:04:51 --> Upload Class Initialized
INFO - 2021-07-17 15:04:51 --> Email Class Initialized
INFO - 2021-07-17 15:04:51 --> MY_Model class loaded
INFO - 2021-07-17 15:04:51 --> Model "Users_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:04:51 --> Database Driver Class Initialized
INFO - 2021-07-17 15:04:51 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:04:51 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:04:51 --> Controller Class Initialized
INFO - 2021-07-17 15:04:51 --> Final output sent to browser
DEBUG - 2021-07-17 15:04:51 --> Total execution time: 0.1609
INFO - 2021-07-17 15:04:54 --> Config Class Initialized
INFO - 2021-07-17 15:04:54 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:04:54 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:04:54 --> Utf8 Class Initialized
INFO - 2021-07-17 15:04:54 --> URI Class Initialized
INFO - 2021-07-17 15:04:54 --> Router Class Initialized
INFO - 2021-07-17 15:04:54 --> Output Class Initialized
INFO - 2021-07-17 15:04:54 --> Security Class Initialized
DEBUG - 2021-07-17 15:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:04:54 --> Input Class Initialized
INFO - 2021-07-17 15:04:54 --> Language Class Initialized
INFO - 2021-07-17 15:04:54 --> Loader Class Initialized
INFO - 2021-07-17 15:04:54 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:04:54 --> Helper loaded: url_helper
INFO - 2021-07-17 15:04:54 --> Helper loaded: file_helper
INFO - 2021-07-17 15:04:54 --> Helper loaded: form_helper
INFO - 2021-07-17 15:04:54 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:04:54 --> Helper loaded: security_helper
INFO - 2021-07-17 15:04:54 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:04:54 --> Helper loaded: language_helper
INFO - 2021-07-17 15:04:54 --> Helper loaded: general_helper
INFO - 2021-07-17 15:04:54 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:04:54 --> Database Driver Class Initialized
DEBUG - 2021-07-17 15:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:04:54 --> Parser Class Initialized
INFO - 2021-07-17 15:04:54 --> Form Validation Class Initialized
INFO - 2021-07-17 15:04:54 --> Upload Class Initialized
INFO - 2021-07-17 15:04:54 --> Email Class Initialized
INFO - 2021-07-17 15:04:54 --> MY_Model class loaded
INFO - 2021-07-17 15:04:54 --> Model "Users_model" initialized
INFO - 2021-07-17 15:04:54 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:04:54 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:04:54 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:04:54 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:04:54 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:04:54 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:04:54 --> Database Driver Class Initialized
INFO - 2021-07-17 15:04:54 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:04:54 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:04:54 --> Controller Class Initialized
ERROR - 2021-07-17 15:04:54 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 15:04:54 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-17 15:04:55 --> Final output sent to browser
DEBUG - 2021-07-17 15:04:55 --> Total execution time: 0.2485
INFO - 2021-07-17 15:14:24 --> Config Class Initialized
INFO - 2021-07-17 15:14:24 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:14:24 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:14:24 --> Utf8 Class Initialized
INFO - 2021-07-17 15:14:24 --> URI Class Initialized
DEBUG - 2021-07-17 15:14:24 --> No URI present. Default controller set.
INFO - 2021-07-17 15:14:24 --> Router Class Initialized
INFO - 2021-07-17 15:14:24 --> Output Class Initialized
INFO - 2021-07-17 15:14:24 --> Security Class Initialized
DEBUG - 2021-07-17 15:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:14:24 --> Input Class Initialized
INFO - 2021-07-17 15:14:24 --> Language Class Initialized
INFO - 2021-07-17 15:14:24 --> Loader Class Initialized
INFO - 2021-07-17 15:14:24 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:14:24 --> Helper loaded: url_helper
INFO - 2021-07-17 15:14:24 --> Helper loaded: file_helper
INFO - 2021-07-17 15:14:24 --> Helper loaded: form_helper
INFO - 2021-07-17 15:14:24 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:14:24 --> Helper loaded: security_helper
INFO - 2021-07-17 15:14:24 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:14:24 --> Helper loaded: language_helper
INFO - 2021-07-17 15:14:24 --> Helper loaded: general_helper
INFO - 2021-07-17 15:14:24 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:14:24 --> Database Driver Class Initialized
DEBUG - 2021-07-17 15:14:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:14:24 --> Parser Class Initialized
INFO - 2021-07-17 15:14:24 --> Form Validation Class Initialized
INFO - 2021-07-17 15:14:24 --> Upload Class Initialized
INFO - 2021-07-17 15:14:24 --> Email Class Initialized
INFO - 2021-07-17 15:14:24 --> MY_Model class loaded
INFO - 2021-07-17 15:14:24 --> Model "Users_model" initialized
INFO - 2021-07-17 15:14:24 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:14:24 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:14:24 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:14:24 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:14:24 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:14:24 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:14:24 --> Database Driver Class Initialized
INFO - 2021-07-17 15:14:24 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:14:24 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:14:24 --> Controller Class Initialized
INFO - 2021-07-17 15:22:08 --> Config Class Initialized
INFO - 2021-07-17 15:22:08 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:22:08 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:22:08 --> Utf8 Class Initialized
INFO - 2021-07-17 15:22:08 --> URI Class Initialized
INFO - 2021-07-17 15:22:08 --> Router Class Initialized
INFO - 2021-07-17 15:22:08 --> Output Class Initialized
INFO - 2021-07-17 15:22:08 --> Security Class Initialized
DEBUG - 2021-07-17 15:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:22:08 --> Input Class Initialized
INFO - 2021-07-17 15:22:08 --> Language Class Initialized
INFO - 2021-07-17 15:22:08 --> Loader Class Initialized
INFO - 2021-07-17 15:22:08 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:22:08 --> Helper loaded: url_helper
INFO - 2021-07-17 15:22:08 --> Helper loaded: file_helper
INFO - 2021-07-17 15:22:08 --> Helper loaded: form_helper
INFO - 2021-07-17 15:22:08 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:22:08 --> Helper loaded: security_helper
INFO - 2021-07-17 15:22:08 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:22:08 --> Helper loaded: language_helper
INFO - 2021-07-17 15:22:08 --> Helper loaded: general_helper
INFO - 2021-07-17 15:22:08 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:22:08 --> Database Driver Class Initialized
DEBUG - 2021-07-17 15:22:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:22:08 --> Parser Class Initialized
INFO - 2021-07-17 15:22:08 --> Form Validation Class Initialized
INFO - 2021-07-17 15:22:08 --> Upload Class Initialized
INFO - 2021-07-17 15:22:08 --> Email Class Initialized
INFO - 2021-07-17 15:22:08 --> MY_Model class loaded
INFO - 2021-07-17 15:22:08 --> Model "Users_model" initialized
INFO - 2021-07-17 15:22:08 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:22:08 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:22:08 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:22:08 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:22:08 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:22:08 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:22:08 --> Database Driver Class Initialized
INFO - 2021-07-17 15:22:08 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:22:08 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:22:08 --> Controller Class Initialized
ERROR - 2021-07-17 15:22:08 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 15:22:08 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-17 15:22:08 --> Final output sent to browser
DEBUG - 2021-07-17 15:22:08 --> Total execution time: 0.1234
INFO - 2021-07-17 15:22:18 --> Config Class Initialized
INFO - 2021-07-17 15:22:18 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:22:18 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:22:18 --> Utf8 Class Initialized
INFO - 2021-07-17 15:22:18 --> URI Class Initialized
INFO - 2021-07-17 15:22:18 --> Router Class Initialized
INFO - 2021-07-17 15:22:18 --> Output Class Initialized
INFO - 2021-07-17 15:22:18 --> Security Class Initialized
DEBUG - 2021-07-17 15:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:22:18 --> Input Class Initialized
INFO - 2021-07-17 15:22:18 --> Language Class Initialized
INFO - 2021-07-17 15:22:18 --> Loader Class Initialized
INFO - 2021-07-17 15:22:18 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:22:18 --> Helper loaded: url_helper
INFO - 2021-07-17 15:22:18 --> Helper loaded: file_helper
INFO - 2021-07-17 15:22:18 --> Helper loaded: form_helper
INFO - 2021-07-17 15:22:18 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:22:18 --> Helper loaded: security_helper
INFO - 2021-07-17 15:22:18 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:22:18 --> Helper loaded: language_helper
INFO - 2021-07-17 15:22:18 --> Helper loaded: general_helper
INFO - 2021-07-17 15:22:18 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:22:18 --> Database Driver Class Initialized
DEBUG - 2021-07-17 15:22:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:22:18 --> Parser Class Initialized
INFO - 2021-07-17 15:22:18 --> Form Validation Class Initialized
INFO - 2021-07-17 15:22:18 --> Upload Class Initialized
INFO - 2021-07-17 15:22:18 --> Email Class Initialized
INFO - 2021-07-17 15:22:18 --> MY_Model class loaded
INFO - 2021-07-17 15:22:18 --> Model "Users_model" initialized
INFO - 2021-07-17 15:22:18 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:22:18 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:22:18 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:22:18 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:22:18 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:22:18 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:22:18 --> Database Driver Class Initialized
INFO - 2021-07-17 15:22:19 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:22:19 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:22:19 --> Controller Class Initialized
ERROR - 2021-07-17 15:22:19 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 15:22:19 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-17 15:22:19 --> Final output sent to browser
DEBUG - 2021-07-17 15:22:19 --> Total execution time: 0.2535
INFO - 2021-07-17 15:27:30 --> Config Class Initialized
INFO - 2021-07-17 15:27:30 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:27:30 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:27:30 --> Utf8 Class Initialized
INFO - 2021-07-17 15:27:30 --> URI Class Initialized
INFO - 2021-07-17 15:27:30 --> Router Class Initialized
INFO - 2021-07-17 15:27:30 --> Output Class Initialized
INFO - 2021-07-17 15:27:30 --> Security Class Initialized
DEBUG - 2021-07-17 15:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:27:30 --> Input Class Initialized
INFO - 2021-07-17 15:27:30 --> Language Class Initialized
INFO - 2021-07-17 15:27:30 --> Loader Class Initialized
INFO - 2021-07-17 15:27:30 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:27:30 --> Helper loaded: url_helper
INFO - 2021-07-17 15:27:30 --> Helper loaded: file_helper
INFO - 2021-07-17 15:27:30 --> Helper loaded: form_helper
INFO - 2021-07-17 15:27:30 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:27:30 --> Helper loaded: security_helper
INFO - 2021-07-17 15:27:30 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:27:30 --> Helper loaded: language_helper
INFO - 2021-07-17 15:27:30 --> Helper loaded: general_helper
INFO - 2021-07-17 15:27:30 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:27:30 --> Database Driver Class Initialized
DEBUG - 2021-07-17 15:27:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:27:30 --> Parser Class Initialized
INFO - 2021-07-17 15:27:30 --> Form Validation Class Initialized
INFO - 2021-07-17 15:27:30 --> Upload Class Initialized
INFO - 2021-07-17 15:27:30 --> Email Class Initialized
INFO - 2021-07-17 15:27:30 --> MY_Model class loaded
INFO - 2021-07-17 15:27:30 --> Model "Users_model" initialized
INFO - 2021-07-17 15:27:30 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:27:30 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:27:30 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:27:30 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:27:30 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:27:30 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:27:30 --> Database Driver Class Initialized
INFO - 2021-07-17 15:27:31 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:27:31 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:27:31 --> Controller Class Initialized
ERROR - 2021-07-17 15:27:31 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 15:27:31 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-17 15:27:31 --> Final output sent to browser
DEBUG - 2021-07-17 15:27:31 --> Total execution time: 0.6044
INFO - 2021-07-17 15:27:33 --> Config Class Initialized
INFO - 2021-07-17 15:27:33 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:27:33 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:27:33 --> Utf8 Class Initialized
INFO - 2021-07-17 15:27:33 --> URI Class Initialized
INFO - 2021-07-17 15:27:33 --> Router Class Initialized
INFO - 2021-07-17 15:27:33 --> Output Class Initialized
INFO - 2021-07-17 15:27:33 --> Security Class Initialized
DEBUG - 2021-07-17 15:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:27:33 --> Input Class Initialized
INFO - 2021-07-17 15:27:33 --> Language Class Initialized
INFO - 2021-07-17 15:27:33 --> Loader Class Initialized
INFO - 2021-07-17 15:27:33 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:27:33 --> Helper loaded: url_helper
INFO - 2021-07-17 15:27:33 --> Helper loaded: file_helper
INFO - 2021-07-17 15:27:33 --> Helper loaded: form_helper
INFO - 2021-07-17 15:27:33 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:27:33 --> Helper loaded: security_helper
INFO - 2021-07-17 15:27:33 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:27:33 --> Helper loaded: language_helper
INFO - 2021-07-17 15:27:33 --> Helper loaded: general_helper
INFO - 2021-07-17 15:27:33 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:27:33 --> Database Driver Class Initialized
DEBUG - 2021-07-17 15:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:27:33 --> Parser Class Initialized
INFO - 2021-07-17 15:27:33 --> Form Validation Class Initialized
INFO - 2021-07-17 15:27:33 --> Upload Class Initialized
INFO - 2021-07-17 15:27:33 --> Email Class Initialized
INFO - 2021-07-17 15:27:33 --> MY_Model class loaded
INFO - 2021-07-17 15:27:33 --> Model "Users_model" initialized
INFO - 2021-07-17 15:27:33 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:27:33 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:27:33 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:27:33 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:27:33 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:27:33 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:27:33 --> Database Driver Class Initialized
INFO - 2021-07-17 15:27:33 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:27:33 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:27:33 --> Controller Class Initialized
ERROR - 2021-07-17 15:27:33 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 15:27:33 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-17 15:27:33 --> Final output sent to browser
DEBUG - 2021-07-17 15:27:33 --> Total execution time: 0.0636
INFO - 2021-07-17 15:27:38 --> Config Class Initialized
INFO - 2021-07-17 15:27:38 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:27:38 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:27:38 --> Utf8 Class Initialized
INFO - 2021-07-17 15:27:38 --> URI Class Initialized
INFO - 2021-07-17 15:27:38 --> Router Class Initialized
INFO - 2021-07-17 15:27:38 --> Output Class Initialized
INFO - 2021-07-17 15:27:38 --> Security Class Initialized
DEBUG - 2021-07-17 15:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:27:38 --> Input Class Initialized
INFO - 2021-07-17 15:27:38 --> Language Class Initialized
INFO - 2021-07-17 15:27:38 --> Loader Class Initialized
INFO - 2021-07-17 15:27:38 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:27:38 --> Helper loaded: url_helper
INFO - 2021-07-17 15:27:38 --> Helper loaded: file_helper
INFO - 2021-07-17 15:27:38 --> Helper loaded: form_helper
INFO - 2021-07-17 15:27:38 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:27:38 --> Helper loaded: security_helper
INFO - 2021-07-17 15:27:38 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:27:38 --> Helper loaded: language_helper
INFO - 2021-07-17 15:27:38 --> Helper loaded: general_helper
INFO - 2021-07-17 15:27:38 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:27:38 --> Database Driver Class Initialized
DEBUG - 2021-07-17 15:27:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:27:38 --> Parser Class Initialized
INFO - 2021-07-17 15:27:38 --> Form Validation Class Initialized
INFO - 2021-07-17 15:27:38 --> Upload Class Initialized
INFO - 2021-07-17 15:27:38 --> Email Class Initialized
INFO - 2021-07-17 15:27:38 --> MY_Model class loaded
INFO - 2021-07-17 15:27:38 --> Model "Users_model" initialized
INFO - 2021-07-17 15:27:38 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:27:38 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:27:38 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:27:38 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:27:38 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:27:38 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:27:38 --> Database Driver Class Initialized
INFO - 2021-07-17 15:27:38 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:27:38 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:27:38 --> Controller Class Initialized
ERROR - 2021-07-17 15:27:38 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 15:27:38 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-17 15:27:38 --> Final output sent to browser
DEBUG - 2021-07-17 15:27:38 --> Total execution time: 0.2344
INFO - 2021-07-17 15:27:41 --> Config Class Initialized
INFO - 2021-07-17 15:27:41 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:27:41 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:27:41 --> Utf8 Class Initialized
INFO - 2021-07-17 15:27:41 --> URI Class Initialized
INFO - 2021-07-17 15:27:41 --> Router Class Initialized
INFO - 2021-07-17 15:27:41 --> Output Class Initialized
INFO - 2021-07-17 15:27:41 --> Security Class Initialized
DEBUG - 2021-07-17 15:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:27:41 --> Input Class Initialized
INFO - 2021-07-17 15:27:41 --> Language Class Initialized
INFO - 2021-07-17 15:27:41 --> Loader Class Initialized
INFO - 2021-07-17 15:27:41 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:27:41 --> Helper loaded: url_helper
INFO - 2021-07-17 15:27:41 --> Helper loaded: file_helper
INFO - 2021-07-17 15:27:41 --> Helper loaded: form_helper
INFO - 2021-07-17 15:27:41 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:27:41 --> Helper loaded: security_helper
INFO - 2021-07-17 15:27:41 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:27:41 --> Helper loaded: language_helper
INFO - 2021-07-17 15:27:41 --> Helper loaded: general_helper
INFO - 2021-07-17 15:27:41 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:27:41 --> Database Driver Class Initialized
DEBUG - 2021-07-17 15:27:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:27:41 --> Parser Class Initialized
INFO - 2021-07-17 15:27:41 --> Form Validation Class Initialized
INFO - 2021-07-17 15:27:41 --> Upload Class Initialized
INFO - 2021-07-17 15:27:41 --> Email Class Initialized
INFO - 2021-07-17 15:27:41 --> MY_Model class loaded
INFO - 2021-07-17 15:27:41 --> Model "Users_model" initialized
INFO - 2021-07-17 15:27:41 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:27:41 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:27:41 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:27:41 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:27:41 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:27:41 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:27:41 --> Database Driver Class Initialized
INFO - 2021-07-17 15:27:41 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:27:41 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:27:41 --> Controller Class Initialized
ERROR - 2021-07-17 15:27:41 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 15:27:41 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-17 15:27:41 --> Final output sent to browser
DEBUG - 2021-07-17 15:27:41 --> Total execution time: 0.0805
INFO - 2021-07-17 15:27:47 --> Config Class Initialized
INFO - 2021-07-17 15:27:47 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:27:47 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:27:47 --> Utf8 Class Initialized
INFO - 2021-07-17 15:27:47 --> URI Class Initialized
INFO - 2021-07-17 15:27:47 --> Router Class Initialized
INFO - 2021-07-17 15:27:47 --> Output Class Initialized
INFO - 2021-07-17 15:27:47 --> Security Class Initialized
DEBUG - 2021-07-17 15:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:27:47 --> Input Class Initialized
INFO - 2021-07-17 15:27:47 --> Language Class Initialized
INFO - 2021-07-17 15:27:47 --> Loader Class Initialized
INFO - 2021-07-17 15:27:47 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:27:47 --> Helper loaded: url_helper
INFO - 2021-07-17 15:27:47 --> Helper loaded: file_helper
INFO - 2021-07-17 15:27:47 --> Helper loaded: form_helper
INFO - 2021-07-17 15:27:47 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:27:47 --> Helper loaded: security_helper
INFO - 2021-07-17 15:27:47 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:27:47 --> Helper loaded: language_helper
INFO - 2021-07-17 15:27:47 --> Helper loaded: general_helper
INFO - 2021-07-17 15:27:47 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:27:47 --> Database Driver Class Initialized
DEBUG - 2021-07-17 15:27:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:27:47 --> Parser Class Initialized
INFO - 2021-07-17 15:27:47 --> Form Validation Class Initialized
INFO - 2021-07-17 15:27:47 --> Upload Class Initialized
INFO - 2021-07-17 15:27:47 --> Email Class Initialized
INFO - 2021-07-17 15:27:47 --> MY_Model class loaded
INFO - 2021-07-17 15:27:47 --> Model "Users_model" initialized
INFO - 2021-07-17 15:27:47 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:27:47 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:27:47 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:27:47 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:27:47 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:27:47 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:27:47 --> Database Driver Class Initialized
INFO - 2021-07-17 15:27:47 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:27:47 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:27:47 --> Controller Class Initialized
ERROR - 2021-07-17 15:27:47 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 15:27:47 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-17 15:27:47 --> Final output sent to browser
DEBUG - 2021-07-17 15:27:47 --> Total execution time: 0.3213
INFO - 2021-07-17 15:27:49 --> Config Class Initialized
INFO - 2021-07-17 15:27:49 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:27:49 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:27:49 --> Utf8 Class Initialized
INFO - 2021-07-17 15:27:49 --> URI Class Initialized
INFO - 2021-07-17 15:27:49 --> Router Class Initialized
INFO - 2021-07-17 15:27:49 --> Output Class Initialized
INFO - 2021-07-17 15:27:49 --> Security Class Initialized
DEBUG - 2021-07-17 15:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:27:49 --> Input Class Initialized
INFO - 2021-07-17 15:27:49 --> Language Class Initialized
INFO - 2021-07-17 15:27:49 --> Loader Class Initialized
INFO - 2021-07-17 15:27:49 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:27:49 --> Helper loaded: url_helper
INFO - 2021-07-17 15:27:49 --> Helper loaded: file_helper
INFO - 2021-07-17 15:27:49 --> Helper loaded: form_helper
INFO - 2021-07-17 15:27:49 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:27:49 --> Helper loaded: security_helper
INFO - 2021-07-17 15:27:49 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:27:49 --> Helper loaded: language_helper
INFO - 2021-07-17 15:27:49 --> Helper loaded: general_helper
INFO - 2021-07-17 15:27:49 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:27:49 --> Database Driver Class Initialized
DEBUG - 2021-07-17 15:27:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:27:49 --> Parser Class Initialized
INFO - 2021-07-17 15:27:49 --> Form Validation Class Initialized
INFO - 2021-07-17 15:27:49 --> Upload Class Initialized
INFO - 2021-07-17 15:27:49 --> Email Class Initialized
INFO - 2021-07-17 15:27:49 --> MY_Model class loaded
INFO - 2021-07-17 15:27:49 --> Model "Users_model" initialized
INFO - 2021-07-17 15:27:49 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:27:49 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:27:49 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:27:49 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:27:49 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:27:49 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:27:49 --> Database Driver Class Initialized
INFO - 2021-07-17 15:27:49 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:27:49 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:27:49 --> Controller Class Initialized
ERROR - 2021-07-17 15:27:49 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 15:27:50 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-17 15:27:50 --> Final output sent to browser
DEBUG - 2021-07-17 15:27:50 --> Total execution time: 0.0696
INFO - 2021-07-17 15:28:01 --> Config Class Initialized
INFO - 2021-07-17 15:28:01 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:28:01 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:28:01 --> Utf8 Class Initialized
INFO - 2021-07-17 15:28:01 --> URI Class Initialized
INFO - 2021-07-17 15:28:01 --> Router Class Initialized
INFO - 2021-07-17 15:28:01 --> Output Class Initialized
INFO - 2021-07-17 15:28:01 --> Security Class Initialized
DEBUG - 2021-07-17 15:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:28:01 --> Input Class Initialized
INFO - 2021-07-17 15:28:01 --> Language Class Initialized
INFO - 2021-07-17 15:28:01 --> Loader Class Initialized
INFO - 2021-07-17 15:28:01 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:28:01 --> Helper loaded: url_helper
INFO - 2021-07-17 15:28:01 --> Helper loaded: file_helper
INFO - 2021-07-17 15:28:01 --> Helper loaded: form_helper
INFO - 2021-07-17 15:28:01 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:28:01 --> Helper loaded: security_helper
INFO - 2021-07-17 15:28:01 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:28:01 --> Helper loaded: language_helper
INFO - 2021-07-17 15:28:01 --> Helper loaded: general_helper
INFO - 2021-07-17 15:28:01 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:28:01 --> Database Driver Class Initialized
DEBUG - 2021-07-17 15:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:28:01 --> Parser Class Initialized
INFO - 2021-07-17 15:28:01 --> Form Validation Class Initialized
INFO - 2021-07-17 15:28:01 --> Upload Class Initialized
INFO - 2021-07-17 15:28:01 --> Email Class Initialized
INFO - 2021-07-17 15:28:01 --> MY_Model class loaded
INFO - 2021-07-17 15:28:01 --> Model "Users_model" initialized
INFO - 2021-07-17 15:28:01 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:28:01 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:28:01 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:28:01 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:28:01 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:28:01 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:28:01 --> Database Driver Class Initialized
INFO - 2021-07-17 15:28:01 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:28:01 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:28:01 --> Controller Class Initialized
ERROR - 2021-07-17 15:28:01 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 15:28:01 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/musteri_bilgi_guncelleme.php
INFO - 2021-07-17 15:28:01 --> Final output sent to browser
DEBUG - 2021-07-17 15:28:01 --> Total execution time: 0.1237
INFO - 2021-07-17 15:28:07 --> Config Class Initialized
INFO - 2021-07-17 15:28:07 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:28:07 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:28:07 --> Utf8 Class Initialized
INFO - 2021-07-17 15:28:07 --> URI Class Initialized
INFO - 2021-07-17 15:28:07 --> Router Class Initialized
INFO - 2021-07-17 15:28:07 --> Output Class Initialized
INFO - 2021-07-17 15:28:07 --> Security Class Initialized
DEBUG - 2021-07-17 15:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:28:07 --> Input Class Initialized
INFO - 2021-07-17 15:28:07 --> Language Class Initialized
INFO - 2021-07-17 15:28:07 --> Loader Class Initialized
INFO - 2021-07-17 15:28:07 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:28:07 --> Helper loaded: url_helper
INFO - 2021-07-17 15:28:07 --> Helper loaded: file_helper
INFO - 2021-07-17 15:28:07 --> Helper loaded: form_helper
INFO - 2021-07-17 15:28:07 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:28:07 --> Helper loaded: security_helper
INFO - 2021-07-17 15:28:07 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:28:07 --> Helper loaded: language_helper
INFO - 2021-07-17 15:28:07 --> Helper loaded: general_helper
INFO - 2021-07-17 15:28:07 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:28:07 --> Database Driver Class Initialized
DEBUG - 2021-07-17 15:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:28:07 --> Parser Class Initialized
INFO - 2021-07-17 15:28:07 --> Form Validation Class Initialized
INFO - 2021-07-17 15:28:07 --> Upload Class Initialized
INFO - 2021-07-17 15:28:07 --> Email Class Initialized
INFO - 2021-07-17 15:28:07 --> MY_Model class loaded
INFO - 2021-07-17 15:28:07 --> Model "Users_model" initialized
INFO - 2021-07-17 15:28:07 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:28:07 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:28:07 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:28:07 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:28:07 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:28:07 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:28:07 --> Database Driver Class Initialized
INFO - 2021-07-17 15:28:07 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:28:07 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:28:07 --> Controller Class Initialized
ERROR - 2021-07-17 15:28:07 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 15:28:07 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-17 15:28:07 --> Final output sent to browser
DEBUG - 2021-07-17 15:28:07 --> Total execution time: 0.2999
INFO - 2021-07-17 15:36:28 --> Config Class Initialized
INFO - 2021-07-17 15:36:28 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:36:28 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:36:28 --> Utf8 Class Initialized
INFO - 2021-07-17 15:36:28 --> URI Class Initialized
INFO - 2021-07-17 15:36:28 --> Router Class Initialized
INFO - 2021-07-17 15:36:28 --> Output Class Initialized
INFO - 2021-07-17 15:36:28 --> Security Class Initialized
DEBUG - 2021-07-17 15:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:36:28 --> Input Class Initialized
INFO - 2021-07-17 15:36:28 --> Language Class Initialized
INFO - 2021-07-17 15:36:28 --> Loader Class Initialized
INFO - 2021-07-17 15:36:28 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:36:28 --> Helper loaded: url_helper
INFO - 2021-07-17 15:36:28 --> Helper loaded: file_helper
INFO - 2021-07-17 15:36:28 --> Helper loaded: form_helper
INFO - 2021-07-17 15:36:28 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:36:28 --> Helper loaded: security_helper
INFO - 2021-07-17 15:36:28 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:36:28 --> Helper loaded: language_helper
INFO - 2021-07-17 15:36:28 --> Helper loaded: general_helper
INFO - 2021-07-17 15:36:28 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:36:28 --> Database Driver Class Initialized
DEBUG - 2021-07-17 15:36:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:36:28 --> Parser Class Initialized
INFO - 2021-07-17 15:36:28 --> Form Validation Class Initialized
INFO - 2021-07-17 15:36:28 --> Upload Class Initialized
INFO - 2021-07-17 15:36:28 --> Email Class Initialized
INFO - 2021-07-17 15:36:28 --> MY_Model class loaded
INFO - 2021-07-17 15:36:28 --> Model "Users_model" initialized
INFO - 2021-07-17 15:36:28 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:36:28 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:36:28 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:36:28 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:36:28 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:36:28 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:36:28 --> Database Driver Class Initialized
INFO - 2021-07-17 15:36:28 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:36:28 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:36:28 --> Controller Class Initialized
ERROR - 2021-07-17 15:36:28 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 15:36:28 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-17 15:36:28 --> Final output sent to browser
DEBUG - 2021-07-17 15:36:28 --> Total execution time: 0.2861
INFO - 2021-07-17 15:37:32 --> Config Class Initialized
INFO - 2021-07-17 15:37:32 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:37:32 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:37:32 --> Utf8 Class Initialized
INFO - 2021-07-17 15:37:32 --> URI Class Initialized
INFO - 2021-07-17 15:37:32 --> Router Class Initialized
INFO - 2021-07-17 15:37:32 --> Output Class Initialized
INFO - 2021-07-17 15:37:32 --> Security Class Initialized
DEBUG - 2021-07-17 15:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:37:32 --> Input Class Initialized
INFO - 2021-07-17 15:37:32 --> Language Class Initialized
INFO - 2021-07-17 15:37:32 --> Loader Class Initialized
INFO - 2021-07-17 15:37:32 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:37:32 --> Helper loaded: url_helper
INFO - 2021-07-17 15:37:32 --> Helper loaded: file_helper
INFO - 2021-07-17 15:37:32 --> Helper loaded: form_helper
INFO - 2021-07-17 15:37:32 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:37:32 --> Helper loaded: security_helper
INFO - 2021-07-17 15:37:32 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:37:32 --> Helper loaded: language_helper
INFO - 2021-07-17 15:37:32 --> Helper loaded: general_helper
INFO - 2021-07-17 15:37:32 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:37:32 --> Database Driver Class Initialized
DEBUG - 2021-07-17 15:37:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:37:32 --> Parser Class Initialized
INFO - 2021-07-17 15:37:32 --> Form Validation Class Initialized
INFO - 2021-07-17 15:37:32 --> Upload Class Initialized
INFO - 2021-07-17 15:37:32 --> Email Class Initialized
INFO - 2021-07-17 15:37:32 --> MY_Model class loaded
INFO - 2021-07-17 15:37:32 --> Model "Users_model" initialized
INFO - 2021-07-17 15:37:32 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:37:32 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:37:32 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:37:32 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:37:32 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:37:32 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:37:32 --> Database Driver Class Initialized
INFO - 2021-07-17 15:37:32 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:37:32 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:37:32 --> Controller Class Initialized
INFO - 2021-07-17 15:37:32 --> Config Class Initialized
INFO - 2021-07-17 15:37:32 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:37:32 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:37:32 --> Utf8 Class Initialized
INFO - 2021-07-17 15:37:32 --> URI Class Initialized
INFO - 2021-07-17 15:37:32 --> Router Class Initialized
INFO - 2021-07-17 15:37:32 --> Output Class Initialized
INFO - 2021-07-17 15:37:32 --> Security Class Initialized
DEBUG - 2021-07-17 15:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:37:32 --> Input Class Initialized
INFO - 2021-07-17 15:37:32 --> Language Class Initialized
ERROR - 2021-07-17 15:37:32 --> 404 Page Not Found: Faviconico/index
INFO - 2021-07-17 15:37:32 --> Config Class Initialized
INFO - 2021-07-17 15:37:32 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:37:32 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:37:32 --> Utf8 Class Initialized
INFO - 2021-07-17 15:37:32 --> URI Class Initialized
INFO - 2021-07-17 15:37:32 --> Router Class Initialized
INFO - 2021-07-17 15:37:32 --> Output Class Initialized
INFO - 2021-07-17 15:37:32 --> Security Class Initialized
DEBUG - 2021-07-17 15:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:37:32 --> Input Class Initialized
INFO - 2021-07-17 15:37:32 --> Language Class Initialized
INFO - 2021-07-17 15:37:32 --> Loader Class Initialized
INFO - 2021-07-17 15:37:32 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:37:32 --> Helper loaded: url_helper
INFO - 2021-07-17 15:37:32 --> Helper loaded: file_helper
INFO - 2021-07-17 15:37:32 --> Helper loaded: form_helper
INFO - 2021-07-17 15:37:32 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:37:32 --> Helper loaded: security_helper
INFO - 2021-07-17 15:37:32 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:37:32 --> Helper loaded: language_helper
INFO - 2021-07-17 15:37:32 --> Helper loaded: general_helper
INFO - 2021-07-17 15:37:32 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:37:32 --> Database Driver Class Initialized
DEBUG - 2021-07-17 15:37:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:37:32 --> Parser Class Initialized
INFO - 2021-07-17 15:37:32 --> Form Validation Class Initialized
INFO - 2021-07-17 15:37:32 --> Upload Class Initialized
INFO - 2021-07-17 15:37:32 --> Email Class Initialized
INFO - 2021-07-17 15:37:32 --> MY_Model class loaded
INFO - 2021-07-17 15:37:32 --> Model "Users_model" initialized
INFO - 2021-07-17 15:37:32 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:37:32 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:37:32 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:37:32 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:37:32 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:37:32 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:37:32 --> Database Driver Class Initialized
INFO - 2021-07-17 15:37:32 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:37:32 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:37:32 --> Controller Class Initialized
INFO - 2021-07-17 15:37:32 --> File loaded: C:\wamp64\www\crm\application\views\account/login.php
INFO - 2021-07-17 15:37:32 --> Final output sent to browser
DEBUG - 2021-07-17 15:37:32 --> Total execution time: 0.0456
INFO - 2021-07-17 15:37:32 --> Config Class Initialized
INFO - 2021-07-17 15:37:32 --> Hooks Class Initialized
INFO - 2021-07-17 15:37:32 --> Config Class Initialized
DEBUG - 2021-07-17 15:37:32 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:37:32 --> Hooks Class Initialized
INFO - 2021-07-17 15:37:32 --> Utf8 Class Initialized
INFO - 2021-07-17 15:37:32 --> URI Class Initialized
DEBUG - 2021-07-17 15:37:32 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:37:32 --> Utf8 Class Initialized
INFO - 2021-07-17 15:37:32 --> Router Class Initialized
INFO - 2021-07-17 15:37:32 --> URI Class Initialized
INFO - 2021-07-17 15:37:32 --> Output Class Initialized
INFO - 2021-07-17 15:37:32 --> Security Class Initialized
INFO - 2021-07-17 15:37:32 --> Router Class Initialized
DEBUG - 2021-07-17 15:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:37:32 --> Output Class Initialized
INFO - 2021-07-17 15:37:32 --> Input Class Initialized
INFO - 2021-07-17 15:37:32 --> Language Class Initialized
INFO - 2021-07-17 15:37:32 --> Security Class Initialized
DEBUG - 2021-07-17 15:37:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-07-17 15:37:32 --> 404 Page Not Found: Assets/jquery
INFO - 2021-07-17 15:37:32 --> Input Class Initialized
INFO - 2021-07-17 15:37:32 --> Language Class Initialized
ERROR - 2021-07-17 15:37:32 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-17 15:37:34 --> Config Class Initialized
INFO - 2021-07-17 15:37:34 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:37:34 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:37:34 --> Utf8 Class Initialized
INFO - 2021-07-17 15:37:34 --> URI Class Initialized
INFO - 2021-07-17 15:37:34 --> Router Class Initialized
INFO - 2021-07-17 15:37:34 --> Output Class Initialized
INFO - 2021-07-17 15:37:34 --> Security Class Initialized
DEBUG - 2021-07-17 15:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:37:34 --> Input Class Initialized
INFO - 2021-07-17 15:37:34 --> Language Class Initialized
INFO - 2021-07-17 15:37:34 --> Loader Class Initialized
INFO - 2021-07-17 15:37:34 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:37:34 --> Helper loaded: url_helper
INFO - 2021-07-17 15:37:34 --> Helper loaded: file_helper
INFO - 2021-07-17 15:37:34 --> Helper loaded: form_helper
INFO - 2021-07-17 15:37:34 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:37:34 --> Helper loaded: security_helper
INFO - 2021-07-17 15:37:34 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:37:34 --> Helper loaded: language_helper
INFO - 2021-07-17 15:37:34 --> Helper loaded: general_helper
INFO - 2021-07-17 15:37:34 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:37:34 --> Database Driver Class Initialized
DEBUG - 2021-07-17 15:37:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:37:34 --> Parser Class Initialized
INFO - 2021-07-17 15:37:34 --> Form Validation Class Initialized
INFO - 2021-07-17 15:37:34 --> Upload Class Initialized
INFO - 2021-07-17 15:37:34 --> Email Class Initialized
INFO - 2021-07-17 15:37:34 --> MY_Model class loaded
INFO - 2021-07-17 15:37:34 --> Model "Users_model" initialized
INFO - 2021-07-17 15:37:34 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:37:34 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:37:34 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:37:34 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:37:34 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:37:34 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:37:34 --> Database Driver Class Initialized
INFO - 2021-07-17 15:37:34 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:37:34 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:37:34 --> Controller Class Initialized
DEBUG - 2021-07-17 15:37:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-17 15:37:34 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2021-07-17 15:37:34 --> File loaded: C:\wamp64\www\crm\application\views\account/login.php
INFO - 2021-07-17 15:37:34 --> Final output sent to browser
DEBUG - 2021-07-17 15:37:34 --> Total execution time: 0.0496
INFO - 2021-07-17 15:37:34 --> Config Class Initialized
INFO - 2021-07-17 15:37:34 --> Hooks Class Initialized
INFO - 2021-07-17 15:37:34 --> Config Class Initialized
DEBUG - 2021-07-17 15:37:34 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:37:34 --> Hooks Class Initialized
INFO - 2021-07-17 15:37:34 --> Utf8 Class Initialized
DEBUG - 2021-07-17 15:37:34 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:37:34 --> URI Class Initialized
INFO - 2021-07-17 15:37:34 --> Utf8 Class Initialized
INFO - 2021-07-17 15:37:34 --> URI Class Initialized
INFO - 2021-07-17 15:37:34 --> Router Class Initialized
INFO - 2021-07-17 15:37:34 --> Output Class Initialized
INFO - 2021-07-17 15:37:34 --> Router Class Initialized
INFO - 2021-07-17 15:37:34 --> Security Class Initialized
INFO - 2021-07-17 15:37:34 --> Output Class Initialized
DEBUG - 2021-07-17 15:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:37:34 --> Input Class Initialized
INFO - 2021-07-17 15:37:34 --> Security Class Initialized
INFO - 2021-07-17 15:37:34 --> Language Class Initialized
DEBUG - 2021-07-17 15:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:37:34 --> Input Class Initialized
ERROR - 2021-07-17 15:37:34 --> 404 Page Not Found: Assets/jquery
INFO - 2021-07-17 15:37:34 --> Language Class Initialized
ERROR - 2021-07-17 15:37:34 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-17 15:38:16 --> Config Class Initialized
INFO - 2021-07-17 15:38:16 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:38:16 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:38:16 --> Utf8 Class Initialized
INFO - 2021-07-17 15:38:16 --> URI Class Initialized
INFO - 2021-07-17 15:38:16 --> Router Class Initialized
INFO - 2021-07-17 15:38:16 --> Output Class Initialized
INFO - 2021-07-17 15:38:16 --> Security Class Initialized
DEBUG - 2021-07-17 15:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:38:16 --> Input Class Initialized
INFO - 2021-07-17 15:38:16 --> Language Class Initialized
INFO - 2021-07-17 15:38:16 --> Loader Class Initialized
INFO - 2021-07-17 15:38:16 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:38:16 --> Helper loaded: url_helper
INFO - 2021-07-17 15:38:16 --> Helper loaded: file_helper
INFO - 2021-07-17 15:38:16 --> Helper loaded: form_helper
INFO - 2021-07-17 15:38:16 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:38:16 --> Helper loaded: security_helper
INFO - 2021-07-17 15:38:16 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:38:16 --> Helper loaded: language_helper
INFO - 2021-07-17 15:38:16 --> Helper loaded: general_helper
INFO - 2021-07-17 15:38:16 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:38:16 --> Database Driver Class Initialized
DEBUG - 2021-07-17 15:38:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:38:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:38:16 --> Parser Class Initialized
INFO - 2021-07-17 15:38:16 --> Form Validation Class Initialized
INFO - 2021-07-17 15:38:16 --> Upload Class Initialized
INFO - 2021-07-17 15:38:16 --> Email Class Initialized
INFO - 2021-07-17 15:38:16 --> MY_Model class loaded
INFO - 2021-07-17 15:38:16 --> Model "Users_model" initialized
INFO - 2021-07-17 15:38:16 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:38:16 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:38:16 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:38:16 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:38:16 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:38:16 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:38:16 --> Database Driver Class Initialized
INFO - 2021-07-17 15:38:16 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:38:16 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:38:16 --> Controller Class Initialized
ERROR - 2021-07-17 15:38:16 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 15:38:16 --> File loaded: C:\wamp64\www\crm\application\views\settings/general.php
INFO - 2021-07-17 15:38:16 --> Final output sent to browser
DEBUG - 2021-07-17 15:38:16 --> Total execution time: 0.2633
INFO - 2021-07-17 15:38:20 --> Config Class Initialized
INFO - 2021-07-17 15:38:20 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:38:20 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:38:20 --> Utf8 Class Initialized
INFO - 2021-07-17 15:38:20 --> URI Class Initialized
INFO - 2021-07-17 15:38:20 --> Router Class Initialized
INFO - 2021-07-17 15:38:20 --> Output Class Initialized
INFO - 2021-07-17 15:38:20 --> Security Class Initialized
DEBUG - 2021-07-17 15:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:38:20 --> Input Class Initialized
INFO - 2021-07-17 15:38:20 --> Language Class Initialized
INFO - 2021-07-17 15:38:20 --> Loader Class Initialized
INFO - 2021-07-17 15:38:20 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:38:20 --> Helper loaded: url_helper
INFO - 2021-07-17 15:38:20 --> Helper loaded: file_helper
INFO - 2021-07-17 15:38:20 --> Helper loaded: form_helper
INFO - 2021-07-17 15:38:20 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:38:20 --> Helper loaded: security_helper
INFO - 2021-07-17 15:38:20 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:38:20 --> Helper loaded: language_helper
INFO - 2021-07-17 15:38:20 --> Helper loaded: general_helper
INFO - 2021-07-17 15:38:20 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:38:20 --> Database Driver Class Initialized
DEBUG - 2021-07-17 15:38:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:38:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:38:20 --> Parser Class Initialized
INFO - 2021-07-17 15:38:20 --> Form Validation Class Initialized
INFO - 2021-07-17 15:38:20 --> Upload Class Initialized
INFO - 2021-07-17 15:38:20 --> Email Class Initialized
INFO - 2021-07-17 15:38:20 --> MY_Model class loaded
INFO - 2021-07-17 15:38:20 --> Model "Users_model" initialized
INFO - 2021-07-17 15:38:20 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:38:20 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:38:20 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:38:20 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:38:20 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:38:20 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:38:20 --> Database Driver Class Initialized
INFO - 2021-07-17 15:38:20 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:38:20 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:38:20 --> Controller Class Initialized
ERROR - 2021-07-17 15:38:20 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 15:38:20 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-17 15:38:20 --> Final output sent to browser
DEBUG - 2021-07-17 15:38:20 --> Total execution time: 0.2050
INFO - 2021-07-17 15:38:23 --> Config Class Initialized
INFO - 2021-07-17 15:38:23 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:38:23 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:38:23 --> Utf8 Class Initialized
INFO - 2021-07-17 15:38:23 --> URI Class Initialized
INFO - 2021-07-17 15:38:23 --> Router Class Initialized
INFO - 2021-07-17 15:38:23 --> Output Class Initialized
INFO - 2021-07-17 15:38:23 --> Security Class Initialized
DEBUG - 2021-07-17 15:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:38:23 --> Input Class Initialized
INFO - 2021-07-17 15:38:23 --> Language Class Initialized
INFO - 2021-07-17 15:38:23 --> Loader Class Initialized
INFO - 2021-07-17 15:38:23 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:38:23 --> Helper loaded: url_helper
INFO - 2021-07-17 15:38:23 --> Helper loaded: file_helper
INFO - 2021-07-17 15:38:23 --> Helper loaded: form_helper
INFO - 2021-07-17 15:38:23 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:38:23 --> Helper loaded: security_helper
INFO - 2021-07-17 15:38:23 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:38:23 --> Helper loaded: language_helper
INFO - 2021-07-17 15:38:23 --> Helper loaded: general_helper
INFO - 2021-07-17 15:38:23 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:38:23 --> Database Driver Class Initialized
DEBUG - 2021-07-17 15:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:38:23 --> Parser Class Initialized
INFO - 2021-07-17 15:38:23 --> Form Validation Class Initialized
INFO - 2021-07-17 15:38:23 --> Upload Class Initialized
INFO - 2021-07-17 15:38:23 --> Email Class Initialized
INFO - 2021-07-17 15:38:23 --> MY_Model class loaded
INFO - 2021-07-17 15:38:23 --> Model "Users_model" initialized
INFO - 2021-07-17 15:38:23 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:38:23 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:38:23 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:38:23 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:38:23 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:38:23 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:38:23 --> Database Driver Class Initialized
INFO - 2021-07-17 15:38:23 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:38:23 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:38:23 --> Controller Class Initialized
ERROR - 2021-07-17 15:38:23 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 15:38:23 --> File loaded: C:\wamp64\www\crm\application\views\users/list.php
INFO - 2021-07-17 15:38:23 --> Final output sent to browser
DEBUG - 2021-07-17 15:38:23 --> Total execution time: 0.1815
INFO - 2021-07-17 15:38:24 --> Config Class Initialized
INFO - 2021-07-17 15:38:24 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:38:24 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:38:24 --> Utf8 Class Initialized
INFO - 2021-07-17 15:38:24 --> URI Class Initialized
INFO - 2021-07-17 15:38:24 --> Router Class Initialized
INFO - 2021-07-17 15:38:24 --> Config Class Initialized
INFO - 2021-07-17 15:38:24 --> Hooks Class Initialized
INFO - 2021-07-17 15:38:24 --> Output Class Initialized
DEBUG - 2021-07-17 15:38:24 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:38:24 --> Utf8 Class Initialized
INFO - 2021-07-17 15:38:24 --> Security Class Initialized
INFO - 2021-07-17 15:38:24 --> URI Class Initialized
DEBUG - 2021-07-17 15:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:38:24 --> Input Class Initialized
INFO - 2021-07-17 15:38:24 --> Router Class Initialized
INFO - 2021-07-17 15:38:24 --> Language Class Initialized
INFO - 2021-07-17 15:38:24 --> Output Class Initialized
INFO - 2021-07-17 15:38:24 --> Config Class Initialized
INFO - 2021-07-17 15:38:24 --> Hooks Class Initialized
INFO - 2021-07-17 15:38:24 --> Security Class Initialized
INFO - 2021-07-17 15:38:24 --> Loader Class Initialized
DEBUG - 2021-07-17 15:38:24 --> UTF-8 Support Enabled
DEBUG - 2021-07-17 15:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:38:24 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:38:24 --> Utf8 Class Initialized
INFO - 2021-07-17 15:38:24 --> Input Class Initialized
INFO - 2021-07-17 15:38:24 --> Helper loaded: url_helper
INFO - 2021-07-17 15:38:24 --> Language Class Initialized
INFO - 2021-07-17 15:38:24 --> URI Class Initialized
INFO - 2021-07-17 15:38:24 --> Helper loaded: file_helper
INFO - 2021-07-17 15:38:24 --> Loader Class Initialized
INFO - 2021-07-17 15:38:24 --> Helper loaded: form_helper
INFO - 2021-07-17 15:38:24 --> Router Class Initialized
INFO - 2021-07-17 15:38:24 --> Config Class Initialized
INFO - 2021-07-17 15:38:24 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:38:24 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:38:24 --> Hooks Class Initialized
INFO - 2021-07-17 15:38:24 --> Output Class Initialized
INFO - 2021-07-17 15:38:24 --> Helper loaded: url_helper
INFO - 2021-07-17 15:38:24 --> Helper loaded: security_helper
INFO - 2021-07-17 15:38:24 --> Security Class Initialized
DEBUG - 2021-07-17 15:38:24 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:38:24 --> Helper loaded: file_helper
INFO - 2021-07-17 15:38:24 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:38:24 --> Utf8 Class Initialized
DEBUG - 2021-07-17 15:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:38:24 --> Helper loaded: form_helper
INFO - 2021-07-17 15:38:24 --> Input Class Initialized
INFO - 2021-07-17 15:38:24 --> Helper loaded: language_helper
INFO - 2021-07-17 15:38:24 --> URI Class Initialized
INFO - 2021-07-17 15:38:24 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:38:24 --> Language Class Initialized
INFO - 2021-07-17 15:38:24 --> Helper loaded: general_helper
INFO - 2021-07-17 15:38:24 --> Helper loaded: security_helper
INFO - 2021-07-17 15:38:24 --> Config Class Initialized
INFO - 2021-07-17 15:38:24 --> Router Class Initialized
INFO - 2021-07-17 15:38:24 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:38:24 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:38:24 --> Hooks Class Initialized
INFO - 2021-07-17 15:38:24 --> Loader Class Initialized
INFO - 2021-07-17 15:38:24 --> Output Class Initialized
INFO - 2021-07-17 15:38:24 --> Helper loaded: language_helper
INFO - 2021-07-17 15:38:24 --> Database Driver Class Initialized
DEBUG - 2021-07-17 15:38:24 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:38:24 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:38:24 --> Security Class Initialized
INFO - 2021-07-17 15:38:24 --> Helper loaded: general_helper
INFO - 2021-07-17 15:38:24 --> Utf8 Class Initialized
DEBUG - 2021-07-17 15:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:38:24 --> Helper loaded: url_helper
INFO - 2021-07-17 15:38:24 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:38:24 --> URI Class Initialized
INFO - 2021-07-17 15:38:24 --> Input Class Initialized
INFO - 2021-07-17 15:38:24 --> Config Class Initialized
INFO - 2021-07-17 15:38:24 --> Helper loaded: file_helper
INFO - 2021-07-17 15:38:24 --> Hooks Class Initialized
INFO - 2021-07-17 15:38:24 --> Language Class Initialized
INFO - 2021-07-17 15:38:24 --> Database Driver Class Initialized
DEBUG - 2021-07-17 15:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:38:24 --> Router Class Initialized
INFO - 2021-07-17 15:38:24 --> Helper loaded: form_helper
DEBUG - 2021-07-17 15:38:24 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:38:24 --> Loader Class Initialized
INFO - 2021-07-17 15:38:24 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:38:24 --> Output Class Initialized
INFO - 2021-07-17 15:38:24 --> Utf8 Class Initialized
INFO - 2021-07-17 15:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:38:24 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:38:24 --> Helper loaded: security_helper
INFO - 2021-07-17 15:38:24 --> Security Class Initialized
INFO - 2021-07-17 15:38:24 --> URI Class Initialized
INFO - 2021-07-17 15:38:24 --> Parser Class Initialized
INFO - 2021-07-17 15:38:24 --> Helper loaded: url_helper
INFO - 2021-07-17 15:38:24 --> Helper loaded: directory_helper
DEBUG - 2021-07-17 15:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:38:24 --> Form Validation Class Initialized
INFO - 2021-07-17 15:38:24 --> Helper loaded: file_helper
DEBUG - 2021-07-17 15:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:38:24 --> Router Class Initialized
INFO - 2021-07-17 15:38:24 --> Input Class Initialized
INFO - 2021-07-17 15:38:24 --> Helper loaded: language_helper
INFO - 2021-07-17 15:38:24 --> Helper loaded: form_helper
INFO - 2021-07-17 15:38:24 --> Language Class Initialized
INFO - 2021-07-17 15:38:24 --> Output Class Initialized
INFO - 2021-07-17 15:38:24 --> Upload Class Initialized
INFO - 2021-07-17 15:38:24 --> Helper loaded: general_helper
INFO - 2021-07-17 15:38:24 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:38:24 --> Security Class Initialized
INFO - 2021-07-17 15:38:24 --> Loader Class Initialized
INFO - 2021-07-17 15:38:24 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:38:24 --> Email Class Initialized
INFO - 2021-07-17 15:38:24 --> Helper loaded: security_helper
DEBUG - 2021-07-17 15:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:38:24 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:38:24 --> MY_Model class loaded
INFO - 2021-07-17 15:38:24 --> Input Class Initialized
INFO - 2021-07-17 15:38:24 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:38:24 --> Database Driver Class Initialized
INFO - 2021-07-17 15:38:24 --> Model "Users_model" initialized
INFO - 2021-07-17 15:38:24 --> Helper loaded: url_helper
INFO - 2021-07-17 15:38:24 --> Language Class Initialized
INFO - 2021-07-17 15:38:24 --> Helper loaded: language_helper
INFO - 2021-07-17 15:38:24 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:38:24 --> Helper loaded: file_helper
INFO - 2021-07-17 15:38:24 --> Helper loaded: general_helper
INFO - 2021-07-17 15:38:24 --> Loader Class Initialized
INFO - 2021-07-17 15:38:24 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:38:24 --> Helper loaded: form_helper
INFO - 2021-07-17 15:38:24 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:38:24 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:38:24 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:38:24 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:38:24 --> Model "Roles_model" initialized
DEBUG - 2021-07-17 15:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:38:24 --> Database Driver Class Initialized
INFO - 2021-07-17 15:38:24 --> Helper loaded: security_helper
INFO - 2021-07-17 15:38:24 --> Helper loaded: url_helper
INFO - 2021-07-17 15:38:24 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:38:24 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:38:24 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:38:24 --> Helper loaded: file_helper
INFO - 2021-07-17 15:38:24 --> Helper loaded: language_helper
INFO - 2021-07-17 15:38:24 --> Database Driver Class Initialized
INFO - 2021-07-17 15:38:24 --> Helper loaded: form_helper
INFO - 2021-07-17 15:38:24 --> Helper loaded: general_helper
INFO - 2021-07-17 15:38:24 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:38:24 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:38:24 --> Helper loaded: security_helper
DEBUG - 2021-07-17 15:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:38:24 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:38:24 --> Database Driver Class Initialized
INFO - 2021-07-17 15:38:24 --> Helper loaded: language_helper
INFO - 2021-07-17 15:38:24 --> Helper loaded: general_helper
INFO - 2021-07-17 15:38:24 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:38:24 --> Database Driver Class Initialized
DEBUG - 2021-07-17 15:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-07-17 15:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:38:24 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:38:24 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:38:24 --> Controller Class Initialized
INFO - 2021-07-17 15:38:24 --> Final output sent to browser
DEBUG - 2021-07-17 15:38:24 --> Total execution time: 0.0633
INFO - 2021-07-17 15:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:38:24 --> Parser Class Initialized
INFO - 2021-07-17 15:38:24 --> Form Validation Class Initialized
INFO - 2021-07-17 15:38:24 --> Upload Class Initialized
INFO - 2021-07-17 15:38:24 --> Email Class Initialized
INFO - 2021-07-17 15:38:24 --> MY_Model class loaded
INFO - 2021-07-17 15:38:24 --> Model "Users_model" initialized
INFO - 2021-07-17 15:38:24 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:38:24 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:38:24 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:38:24 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:38:24 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:38:24 --> Config Class Initialized
INFO - 2021-07-17 15:38:24 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:38:24 --> Hooks Class Initialized
INFO - 2021-07-17 15:38:24 --> Database Driver Class Initialized
DEBUG - 2021-07-17 15:38:24 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:38:24 --> Utf8 Class Initialized
INFO - 2021-07-17 15:38:24 --> URI Class Initialized
INFO - 2021-07-17 15:38:24 --> Router Class Initialized
INFO - 2021-07-17 15:38:24 --> Output Class Initialized
INFO - 2021-07-17 15:38:24 --> Security Class Initialized
DEBUG - 2021-07-17 15:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:38:24 --> Input Class Initialized
INFO - 2021-07-17 15:38:24 --> Language Class Initialized
INFO - 2021-07-17 15:38:24 --> Loader Class Initialized
INFO - 2021-07-17 15:38:24 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:38:24 --> Helper loaded: url_helper
INFO - 2021-07-17 15:38:24 --> Helper loaded: file_helper
INFO - 2021-07-17 15:38:24 --> Helper loaded: form_helper
INFO - 2021-07-17 15:38:24 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:38:24 --> Helper loaded: security_helper
INFO - 2021-07-17 15:38:24 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:38:24 --> Helper loaded: language_helper
INFO - 2021-07-17 15:38:24 --> Helper loaded: general_helper
INFO - 2021-07-17 15:38:24 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:38:24 --> Database Driver Class Initialized
INFO - 2021-07-17 15:38:24 --> Model "Hesaplar_model" initialized
DEBUG - 2021-07-17 15:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:38:24 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:38:24 --> Controller Class Initialized
INFO - 2021-07-17 15:38:24 --> Final output sent to browser
DEBUG - 2021-07-17 15:38:24 --> Total execution time: 0.0889
INFO - 2021-07-17 15:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:38:24 --> Parser Class Initialized
INFO - 2021-07-17 15:38:24 --> Form Validation Class Initialized
INFO - 2021-07-17 15:38:24 --> Upload Class Initialized
INFO - 2021-07-17 15:38:24 --> Email Class Initialized
INFO - 2021-07-17 15:38:24 --> MY_Model class loaded
INFO - 2021-07-17 15:38:24 --> Model "Users_model" initialized
INFO - 2021-07-17 15:38:24 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:38:24 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:38:24 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:38:24 --> Config Class Initialized
INFO - 2021-07-17 15:38:24 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:38:24 --> Hooks Class Initialized
INFO - 2021-07-17 15:38:24 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:38:24 --> Model "Templates_model" initialized
DEBUG - 2021-07-17 15:38:24 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:38:24 --> Utf8 Class Initialized
INFO - 2021-07-17 15:38:24 --> Database Driver Class Initialized
INFO - 2021-07-17 15:38:24 --> URI Class Initialized
INFO - 2021-07-17 15:38:24 --> Router Class Initialized
INFO - 2021-07-17 15:38:24 --> Output Class Initialized
INFO - 2021-07-17 15:38:24 --> Security Class Initialized
DEBUG - 2021-07-17 15:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:38:24 --> Input Class Initialized
INFO - 2021-07-17 15:38:24 --> Language Class Initialized
INFO - 2021-07-17 15:38:24 --> Loader Class Initialized
INFO - 2021-07-17 15:38:24 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:38:24 --> Helper loaded: url_helper
INFO - 2021-07-17 15:38:24 --> Helper loaded: file_helper
INFO - 2021-07-17 15:38:24 --> Helper loaded: form_helper
INFO - 2021-07-17 15:38:24 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:38:24 --> Helper loaded: security_helper
INFO - 2021-07-17 15:38:24 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:38:24 --> Helper loaded: language_helper
INFO - 2021-07-17 15:38:24 --> Helper loaded: general_helper
INFO - 2021-07-17 15:38:24 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:38:24 --> Database Driver Class Initialized
DEBUG - 2021-07-17 15:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:38:24 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:38:24 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:38:24 --> Controller Class Initialized
INFO - 2021-07-17 15:38:24 --> Final output sent to browser
DEBUG - 2021-07-17 15:38:24 --> Total execution time: 0.1140
INFO - 2021-07-17 15:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:38:24 --> Parser Class Initialized
INFO - 2021-07-17 15:38:24 --> Form Validation Class Initialized
INFO - 2021-07-17 15:38:24 --> Upload Class Initialized
INFO - 2021-07-17 15:38:24 --> Email Class Initialized
INFO - 2021-07-17 15:38:24 --> MY_Model class loaded
INFO - 2021-07-17 15:38:24 --> Model "Users_model" initialized
INFO - 2021-07-17 15:38:24 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:38:24 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:38:24 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:38:24 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:38:24 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:38:24 --> Config Class Initialized
INFO - 2021-07-17 15:38:24 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:38:24 --> Hooks Class Initialized
INFO - 2021-07-17 15:38:24 --> Database Driver Class Initialized
DEBUG - 2021-07-17 15:38:24 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:38:24 --> Utf8 Class Initialized
INFO - 2021-07-17 15:38:24 --> URI Class Initialized
INFO - 2021-07-17 15:38:24 --> Router Class Initialized
INFO - 2021-07-17 15:38:24 --> Output Class Initialized
INFO - 2021-07-17 15:38:24 --> Security Class Initialized
DEBUG - 2021-07-17 15:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:38:24 --> Input Class Initialized
INFO - 2021-07-17 15:38:24 --> Language Class Initialized
INFO - 2021-07-17 15:38:24 --> Loader Class Initialized
INFO - 2021-07-17 15:38:24 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:38:24 --> Helper loaded: url_helper
INFO - 2021-07-17 15:38:24 --> Helper loaded: file_helper
INFO - 2021-07-17 15:38:24 --> Helper loaded: form_helper
INFO - 2021-07-17 15:38:24 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:38:24 --> Helper loaded: security_helper
INFO - 2021-07-17 15:38:24 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:38:24 --> Helper loaded: language_helper
INFO - 2021-07-17 15:38:24 --> Helper loaded: general_helper
INFO - 2021-07-17 15:38:24 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:38:24 --> Database Driver Class Initialized
DEBUG - 2021-07-17 15:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:38:24 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:38:24 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:38:24 --> Controller Class Initialized
INFO - 2021-07-17 15:38:24 --> Final output sent to browser
DEBUG - 2021-07-17 15:38:24 --> Total execution time: 0.1387
INFO - 2021-07-17 15:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:38:24 --> Parser Class Initialized
INFO - 2021-07-17 15:38:24 --> Form Validation Class Initialized
INFO - 2021-07-17 15:38:24 --> Upload Class Initialized
INFO - 2021-07-17 15:38:24 --> Email Class Initialized
INFO - 2021-07-17 15:38:24 --> MY_Model class loaded
INFO - 2021-07-17 15:38:24 --> Model "Users_model" initialized
INFO - 2021-07-17 15:38:24 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:38:24 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:38:24 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:38:24 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:38:24 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:38:24 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:38:24 --> Database Driver Class Initialized
INFO - 2021-07-17 15:38:24 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:38:24 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:38:24 --> Controller Class Initialized
INFO - 2021-07-17 15:38:24 --> Final output sent to browser
DEBUG - 2021-07-17 15:38:24 --> Total execution time: 0.1629
INFO - 2021-07-17 15:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:38:24 --> Parser Class Initialized
INFO - 2021-07-17 15:38:24 --> Form Validation Class Initialized
INFO - 2021-07-17 15:38:24 --> Upload Class Initialized
INFO - 2021-07-17 15:38:24 --> Email Class Initialized
INFO - 2021-07-17 15:38:24 --> MY_Model class loaded
INFO - 2021-07-17 15:38:24 --> Model "Users_model" initialized
INFO - 2021-07-17 15:38:24 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:38:24 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:38:24 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:38:24 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:38:24 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:38:24 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:38:24 --> Database Driver Class Initialized
INFO - 2021-07-17 15:38:24 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:38:24 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:38:24 --> Controller Class Initialized
INFO - 2021-07-17 15:38:24 --> Final output sent to browser
DEBUG - 2021-07-17 15:38:24 --> Total execution time: 0.1855
INFO - 2021-07-17 15:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:38:24 --> Parser Class Initialized
INFO - 2021-07-17 15:38:24 --> Form Validation Class Initialized
INFO - 2021-07-17 15:38:24 --> Upload Class Initialized
INFO - 2021-07-17 15:38:24 --> Email Class Initialized
INFO - 2021-07-17 15:38:24 --> MY_Model class loaded
INFO - 2021-07-17 15:38:24 --> Model "Users_model" initialized
INFO - 2021-07-17 15:38:24 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:38:24 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:38:24 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:38:24 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:38:24 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:38:24 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:38:24 --> Database Driver Class Initialized
INFO - 2021-07-17 15:38:24 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:38:24 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:38:24 --> Controller Class Initialized
INFO - 2021-07-17 15:38:24 --> Final output sent to browser
DEBUG - 2021-07-17 15:38:24 --> Total execution time: 0.1665
INFO - 2021-07-17 15:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:38:24 --> Parser Class Initialized
INFO - 2021-07-17 15:38:24 --> Form Validation Class Initialized
INFO - 2021-07-17 15:38:24 --> Upload Class Initialized
INFO - 2021-07-17 15:38:24 --> Email Class Initialized
INFO - 2021-07-17 15:38:24 --> MY_Model class loaded
INFO - 2021-07-17 15:38:24 --> Model "Users_model" initialized
INFO - 2021-07-17 15:38:24 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:38:24 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:38:24 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:38:24 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:38:24 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:38:24 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:38:24 --> Database Driver Class Initialized
INFO - 2021-07-17 15:38:24 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:38:24 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:38:24 --> Controller Class Initialized
INFO - 2021-07-17 15:38:24 --> Final output sent to browser
DEBUG - 2021-07-17 15:38:24 --> Total execution time: 0.1641
INFO - 2021-07-17 15:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:38:24 --> Parser Class Initialized
INFO - 2021-07-17 15:38:24 --> Form Validation Class Initialized
INFO - 2021-07-17 15:38:24 --> Upload Class Initialized
INFO - 2021-07-17 15:38:24 --> Email Class Initialized
INFO - 2021-07-17 15:38:24 --> MY_Model class loaded
INFO - 2021-07-17 15:38:24 --> Model "Users_model" initialized
INFO - 2021-07-17 15:38:24 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:38:24 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:38:24 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:38:24 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:38:24 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:38:24 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:38:24 --> Database Driver Class Initialized
INFO - 2021-07-17 15:38:24 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:38:24 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:38:24 --> Controller Class Initialized
INFO - 2021-07-17 15:38:24 --> Final output sent to browser
DEBUG - 2021-07-17 15:38:24 --> Total execution time: 0.1627
INFO - 2021-07-17 15:38:25 --> Config Class Initialized
INFO - 2021-07-17 15:38:25 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:38:25 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:38:25 --> Utf8 Class Initialized
INFO - 2021-07-17 15:38:25 --> URI Class Initialized
INFO - 2021-07-17 15:38:25 --> Router Class Initialized
INFO - 2021-07-17 15:38:25 --> Output Class Initialized
INFO - 2021-07-17 15:38:25 --> Security Class Initialized
DEBUG - 2021-07-17 15:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:38:25 --> Input Class Initialized
INFO - 2021-07-17 15:38:25 --> Language Class Initialized
INFO - 2021-07-17 15:38:25 --> Loader Class Initialized
INFO - 2021-07-17 15:38:25 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:38:25 --> Helper loaded: url_helper
INFO - 2021-07-17 15:38:25 --> Helper loaded: file_helper
INFO - 2021-07-17 15:38:25 --> Helper loaded: form_helper
INFO - 2021-07-17 15:38:25 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:38:25 --> Helper loaded: security_helper
INFO - 2021-07-17 15:38:25 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:38:25 --> Helper loaded: language_helper
INFO - 2021-07-17 15:38:25 --> Helper loaded: general_helper
INFO - 2021-07-17 15:38:25 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:38:25 --> Database Driver Class Initialized
DEBUG - 2021-07-17 15:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:38:25 --> Parser Class Initialized
INFO - 2021-07-17 15:38:25 --> Form Validation Class Initialized
INFO - 2021-07-17 15:38:25 --> Upload Class Initialized
INFO - 2021-07-17 15:38:25 --> Email Class Initialized
INFO - 2021-07-17 15:38:25 --> MY_Model class loaded
INFO - 2021-07-17 15:38:25 --> Model "Users_model" initialized
INFO - 2021-07-17 15:38:25 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:38:25 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:38:25 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:38:25 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:38:25 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:38:25 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:38:25 --> Database Driver Class Initialized
INFO - 2021-07-17 15:38:25 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:38:25 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:38:25 --> Controller Class Initialized
ERROR - 2021-07-17 15:38:25 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 15:38:26 --> File loaded: C:\wamp64\www\crm\application\views\activity_logs/list.php
INFO - 2021-07-17 15:38:26 --> Final output sent to browser
DEBUG - 2021-07-17 15:38:26 --> Total execution time: 0.2020
INFO - 2021-07-17 15:38:52 --> Config Class Initialized
INFO - 2021-07-17 15:38:52 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:38:52 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:38:52 --> Utf8 Class Initialized
INFO - 2021-07-17 15:38:52 --> URI Class Initialized
INFO - 2021-07-17 15:38:52 --> Router Class Initialized
INFO - 2021-07-17 15:38:52 --> Output Class Initialized
INFO - 2021-07-17 15:38:52 --> Security Class Initialized
DEBUG - 2021-07-17 15:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:38:52 --> Input Class Initialized
INFO - 2021-07-17 15:38:52 --> Language Class Initialized
INFO - 2021-07-17 15:38:52 --> Loader Class Initialized
INFO - 2021-07-17 15:38:52 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:38:52 --> Helper loaded: url_helper
INFO - 2021-07-17 15:38:52 --> Helper loaded: file_helper
INFO - 2021-07-17 15:38:52 --> Helper loaded: form_helper
INFO - 2021-07-17 15:38:52 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:38:52 --> Helper loaded: security_helper
INFO - 2021-07-17 15:38:52 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:38:52 --> Helper loaded: language_helper
INFO - 2021-07-17 15:38:52 --> Helper loaded: general_helper
INFO - 2021-07-17 15:38:52 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:38:52 --> Database Driver Class Initialized
DEBUG - 2021-07-17 15:38:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:38:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:38:52 --> Parser Class Initialized
INFO - 2021-07-17 15:38:52 --> Form Validation Class Initialized
INFO - 2021-07-17 15:38:52 --> Upload Class Initialized
INFO - 2021-07-17 15:38:52 --> Email Class Initialized
INFO - 2021-07-17 15:38:52 --> MY_Model class loaded
INFO - 2021-07-17 15:38:52 --> Model "Users_model" initialized
INFO - 2021-07-17 15:38:52 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:38:52 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:38:52 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:38:52 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:38:52 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:38:52 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:38:52 --> Database Driver Class Initialized
INFO - 2021-07-17 15:38:52 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:38:52 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:38:52 --> Controller Class Initialized
INFO - 2021-07-17 15:38:52 --> File loaded: C:\wamp64\www\crm\application\views\account/login.php
INFO - 2021-07-17 15:38:52 --> Final output sent to browser
DEBUG - 2021-07-17 15:38:52 --> Total execution time: 0.1097
INFO - 2021-07-17 15:38:52 --> Config Class Initialized
INFO - 2021-07-17 15:38:52 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:38:52 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:38:52 --> Utf8 Class Initialized
INFO - 2021-07-17 15:38:52 --> URI Class Initialized
INFO - 2021-07-17 15:38:52 --> Config Class Initialized
INFO - 2021-07-17 15:38:52 --> Hooks Class Initialized
INFO - 2021-07-17 15:38:52 --> Router Class Initialized
DEBUG - 2021-07-17 15:38:52 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:38:52 --> Output Class Initialized
INFO - 2021-07-17 15:38:52 --> Utf8 Class Initialized
INFO - 2021-07-17 15:38:52 --> Security Class Initialized
INFO - 2021-07-17 15:38:52 --> URI Class Initialized
DEBUG - 2021-07-17 15:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:38:52 --> Input Class Initialized
INFO - 2021-07-17 15:38:52 --> Router Class Initialized
INFO - 2021-07-17 15:38:52 --> Language Class Initialized
INFO - 2021-07-17 15:38:52 --> Output Class Initialized
ERROR - 2021-07-17 15:38:52 --> 404 Page Not Found: Assets/jquery
INFO - 2021-07-17 15:38:52 --> Security Class Initialized
DEBUG - 2021-07-17 15:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:38:52 --> Input Class Initialized
INFO - 2021-07-17 15:38:52 --> Language Class Initialized
ERROR - 2021-07-17 15:38:52 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-17 15:38:53 --> Config Class Initialized
INFO - 2021-07-17 15:38:53 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:38:53 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:38:53 --> Utf8 Class Initialized
INFO - 2021-07-17 15:38:53 --> URI Class Initialized
INFO - 2021-07-17 15:38:53 --> Router Class Initialized
INFO - 2021-07-17 15:38:53 --> Output Class Initialized
INFO - 2021-07-17 15:38:53 --> Security Class Initialized
DEBUG - 2021-07-17 15:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:38:53 --> Input Class Initialized
INFO - 2021-07-17 15:38:53 --> Language Class Initialized
ERROR - 2021-07-17 15:38:53 --> 404 Page Not Found: Assets/jquery
INFO - 2021-07-17 15:38:53 --> Config Class Initialized
INFO - 2021-07-17 15:38:53 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:38:53 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:38:53 --> Utf8 Class Initialized
INFO - 2021-07-17 15:38:53 --> URI Class Initialized
INFO - 2021-07-17 15:38:53 --> Router Class Initialized
INFO - 2021-07-17 15:38:53 --> Output Class Initialized
INFO - 2021-07-17 15:38:53 --> Security Class Initialized
DEBUG - 2021-07-17 15:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:38:53 --> Input Class Initialized
INFO - 2021-07-17 15:38:53 --> Language Class Initialized
ERROR - 2021-07-17 15:38:53 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-17 15:42:51 --> Config Class Initialized
INFO - 2021-07-17 15:42:51 --> Hooks Class Initialized
DEBUG - 2021-07-17 15:42:51 --> UTF-8 Support Enabled
INFO - 2021-07-17 15:42:51 --> Utf8 Class Initialized
INFO - 2021-07-17 15:42:51 --> URI Class Initialized
INFO - 2021-07-17 15:42:51 --> Router Class Initialized
INFO - 2021-07-17 15:42:51 --> Output Class Initialized
INFO - 2021-07-17 15:42:51 --> Security Class Initialized
DEBUG - 2021-07-17 15:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 15:42:51 --> Input Class Initialized
INFO - 2021-07-17 15:42:51 --> Language Class Initialized
INFO - 2021-07-17 15:42:51 --> Loader Class Initialized
INFO - 2021-07-17 15:42:51 --> Helper loaded: basic_helper
INFO - 2021-07-17 15:42:51 --> Helper loaded: url_helper
INFO - 2021-07-17 15:42:51 --> Helper loaded: file_helper
INFO - 2021-07-17 15:42:51 --> Helper loaded: form_helper
INFO - 2021-07-17 15:42:51 --> Helper loaded: cookie_helper
INFO - 2021-07-17 15:42:51 --> Helper loaded: security_helper
INFO - 2021-07-17 15:42:51 --> Helper loaded: directory_helper
INFO - 2021-07-17 15:42:51 --> Helper loaded: language_helper
INFO - 2021-07-17 15:42:51 --> Helper loaded: general_helper
INFO - 2021-07-17 15:42:51 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 15:42:51 --> Database Driver Class Initialized
DEBUG - 2021-07-17 15:42:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 15:42:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 15:42:51 --> Parser Class Initialized
INFO - 2021-07-17 15:42:51 --> Form Validation Class Initialized
INFO - 2021-07-17 15:42:51 --> Upload Class Initialized
INFO - 2021-07-17 15:42:51 --> Email Class Initialized
INFO - 2021-07-17 15:42:51 --> MY_Model class loaded
INFO - 2021-07-17 15:42:51 --> Model "Users_model" initialized
INFO - 2021-07-17 15:42:51 --> Model "Settings_model" initialized
INFO - 2021-07-17 15:42:51 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 15:42:51 --> Model "Permissions_model" initialized
INFO - 2021-07-17 15:42:51 --> Model "Roles_model" initialized
INFO - 2021-07-17 15:42:51 --> Model "Activity_model" initialized
INFO - 2021-07-17 15:42:51 --> Model "Templates_model" initialized
INFO - 2021-07-17 15:42:51 --> Database Driver Class Initialized
INFO - 2021-07-17 15:42:52 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 15:42:52 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 15:42:52 --> Controller Class Initialized
ERROR - 2021-07-17 15:42:52 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 15:42:52 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-17 15:42:52 --> Final output sent to browser
DEBUG - 2021-07-17 15:42:52 --> Total execution time: 0.5545
INFO - 2021-07-17 16:05:13 --> Config Class Initialized
INFO - 2021-07-17 16:05:13 --> Hooks Class Initialized
DEBUG - 2021-07-17 16:05:13 --> UTF-8 Support Enabled
INFO - 2021-07-17 16:05:13 --> Utf8 Class Initialized
INFO - 2021-07-17 16:05:13 --> URI Class Initialized
INFO - 2021-07-17 16:05:13 --> Router Class Initialized
INFO - 2021-07-17 16:05:13 --> Output Class Initialized
INFO - 2021-07-17 16:05:13 --> Security Class Initialized
DEBUG - 2021-07-17 16:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 16:05:13 --> Input Class Initialized
INFO - 2021-07-17 16:05:13 --> Language Class Initialized
INFO - 2021-07-17 16:05:13 --> Loader Class Initialized
INFO - 2021-07-17 16:05:13 --> Helper loaded: basic_helper
INFO - 2021-07-17 16:05:13 --> Helper loaded: url_helper
INFO - 2021-07-17 16:05:13 --> Helper loaded: file_helper
INFO - 2021-07-17 16:05:13 --> Helper loaded: form_helper
INFO - 2021-07-17 16:05:13 --> Helper loaded: cookie_helper
INFO - 2021-07-17 16:05:13 --> Helper loaded: security_helper
INFO - 2021-07-17 16:05:13 --> Helper loaded: directory_helper
INFO - 2021-07-17 16:05:13 --> Helper loaded: language_helper
INFO - 2021-07-17 16:05:13 --> Helper loaded: general_helper
INFO - 2021-07-17 16:05:13 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 16:05:13 --> Database Driver Class Initialized
DEBUG - 2021-07-17 16:05:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 16:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 16:05:13 --> Parser Class Initialized
INFO - 2021-07-17 16:05:13 --> Form Validation Class Initialized
INFO - 2021-07-17 16:05:13 --> Upload Class Initialized
INFO - 2021-07-17 16:05:13 --> Email Class Initialized
INFO - 2021-07-17 16:05:13 --> MY_Model class loaded
INFO - 2021-07-17 16:05:13 --> Model "Users_model" initialized
INFO - 2021-07-17 16:05:13 --> Model "Settings_model" initialized
INFO - 2021-07-17 16:05:13 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 16:05:13 --> Model "Permissions_model" initialized
INFO - 2021-07-17 16:05:13 --> Model "Roles_model" initialized
INFO - 2021-07-17 16:05:13 --> Model "Activity_model" initialized
INFO - 2021-07-17 16:05:13 --> Model "Templates_model" initialized
INFO - 2021-07-17 16:05:13 --> Database Driver Class Initialized
INFO - 2021-07-17 16:05:13 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 16:05:13 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 16:05:13 --> Controller Class Initialized
ERROR - 2021-07-17 16:05:13 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 16:05:14 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-17 16:05:14 --> Final output sent to browser
DEBUG - 2021-07-17 16:05:14 --> Total execution time: 0.1456
INFO - 2021-07-17 16:26:19 --> Config Class Initialized
INFO - 2021-07-17 16:26:19 --> Hooks Class Initialized
DEBUG - 2021-07-17 16:26:19 --> UTF-8 Support Enabled
INFO - 2021-07-17 16:26:19 --> Utf8 Class Initialized
INFO - 2021-07-17 16:26:19 --> URI Class Initialized
DEBUG - 2021-07-17 16:26:19 --> No URI present. Default controller set.
INFO - 2021-07-17 16:26:19 --> Router Class Initialized
INFO - 2021-07-17 16:26:19 --> Output Class Initialized
INFO - 2021-07-17 16:26:19 --> Security Class Initialized
DEBUG - 2021-07-17 16:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 16:26:19 --> Input Class Initialized
INFO - 2021-07-17 16:26:19 --> Language Class Initialized
INFO - 2021-07-17 16:26:19 --> Loader Class Initialized
INFO - 2021-07-17 16:26:19 --> Helper loaded: basic_helper
INFO - 2021-07-17 16:26:19 --> Helper loaded: url_helper
INFO - 2021-07-17 16:26:19 --> Helper loaded: file_helper
INFO - 2021-07-17 16:26:19 --> Helper loaded: form_helper
INFO - 2021-07-17 16:26:19 --> Helper loaded: cookie_helper
INFO - 2021-07-17 16:26:19 --> Helper loaded: security_helper
INFO - 2021-07-17 16:26:19 --> Helper loaded: directory_helper
INFO - 2021-07-17 16:26:19 --> Helper loaded: language_helper
INFO - 2021-07-17 16:26:19 --> Helper loaded: general_helper
INFO - 2021-07-17 16:26:19 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 16:26:19 --> Database Driver Class Initialized
DEBUG - 2021-07-17 16:26:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 16:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 16:26:19 --> Parser Class Initialized
INFO - 2021-07-17 16:26:19 --> Form Validation Class Initialized
INFO - 2021-07-17 16:26:19 --> Upload Class Initialized
INFO - 2021-07-17 16:26:19 --> Email Class Initialized
INFO - 2021-07-17 16:26:19 --> MY_Model class loaded
INFO - 2021-07-17 16:26:19 --> Model "Users_model" initialized
INFO - 2021-07-17 16:26:19 --> Model "Settings_model" initialized
INFO - 2021-07-17 16:26:19 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 16:26:19 --> Model "Permissions_model" initialized
INFO - 2021-07-17 16:26:19 --> Model "Roles_model" initialized
INFO - 2021-07-17 16:26:19 --> Model "Activity_model" initialized
INFO - 2021-07-17 16:26:19 --> Model "Templates_model" initialized
INFO - 2021-07-17 16:26:19 --> Database Driver Class Initialized
INFO - 2021-07-17 16:26:19 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 16:26:19 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 16:26:19 --> Controller Class Initialized
INFO - 2021-07-17 17:08:54 --> Config Class Initialized
INFO - 2021-07-17 17:08:54 --> Hooks Class Initialized
DEBUG - 2021-07-17 17:08:54 --> UTF-8 Support Enabled
INFO - 2021-07-17 17:08:54 --> Utf8 Class Initialized
INFO - 2021-07-17 17:08:54 --> URI Class Initialized
DEBUG - 2021-07-17 17:08:54 --> No URI present. Default controller set.
INFO - 2021-07-17 17:08:54 --> Router Class Initialized
INFO - 2021-07-17 17:08:54 --> Output Class Initialized
INFO - 2021-07-17 17:08:54 --> Security Class Initialized
DEBUG - 2021-07-17 17:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 17:08:54 --> Input Class Initialized
INFO - 2021-07-17 17:08:54 --> Language Class Initialized
INFO - 2021-07-17 17:08:54 --> Loader Class Initialized
INFO - 2021-07-17 17:08:54 --> Helper loaded: basic_helper
INFO - 2021-07-17 17:08:54 --> Helper loaded: url_helper
INFO - 2021-07-17 17:08:54 --> Helper loaded: file_helper
INFO - 2021-07-17 17:08:54 --> Helper loaded: form_helper
INFO - 2021-07-17 17:08:54 --> Helper loaded: cookie_helper
INFO - 2021-07-17 17:08:54 --> Helper loaded: security_helper
INFO - 2021-07-17 17:08:54 --> Helper loaded: directory_helper
INFO - 2021-07-17 17:08:54 --> Helper loaded: language_helper
INFO - 2021-07-17 17:08:54 --> Helper loaded: general_helper
INFO - 2021-07-17 17:08:54 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 17:08:54 --> Database Driver Class Initialized
DEBUG - 2021-07-17 17:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 17:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 17:08:54 --> Parser Class Initialized
INFO - 2021-07-17 17:08:54 --> Form Validation Class Initialized
INFO - 2021-07-17 17:08:54 --> Upload Class Initialized
INFO - 2021-07-17 17:08:54 --> Email Class Initialized
INFO - 2021-07-17 17:08:54 --> MY_Model class loaded
INFO - 2021-07-17 17:08:54 --> Model "Users_model" initialized
INFO - 2021-07-17 17:08:54 --> Model "Settings_model" initialized
INFO - 2021-07-17 17:08:54 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 17:08:54 --> Model "Permissions_model" initialized
INFO - 2021-07-17 17:08:54 --> Model "Roles_model" initialized
INFO - 2021-07-17 17:08:54 --> Model "Activity_model" initialized
INFO - 2021-07-17 17:08:54 --> Model "Templates_model" initialized
INFO - 2021-07-17 17:08:54 --> Database Driver Class Initialized
INFO - 2021-07-17 17:08:54 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 17:08:54 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 17:08:54 --> Controller Class Initialized
ERROR - 2021-07-17 17:08:54 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 17:08:54 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-17 17:08:54 --> Final output sent to browser
DEBUG - 2021-07-17 17:08:54 --> Total execution time: 0.1352
INFO - 2021-07-17 17:08:55 --> Config Class Initialized
INFO - 2021-07-17 17:08:55 --> Hooks Class Initialized
DEBUG - 2021-07-17 17:08:55 --> UTF-8 Support Enabled
INFO - 2021-07-17 17:08:55 --> Utf8 Class Initialized
INFO - 2021-07-17 17:08:55 --> URI Class Initialized
INFO - 2021-07-17 17:08:55 --> Router Class Initialized
INFO - 2021-07-17 17:08:55 --> Output Class Initialized
INFO - 2021-07-17 17:08:55 --> Security Class Initialized
DEBUG - 2021-07-17 17:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 17:08:55 --> Input Class Initialized
INFO - 2021-07-17 17:08:55 --> Language Class Initialized
ERROR - 2021-07-17 17:08:55 --> 404 Page Not Found: Faviconico/index
INFO - 2021-07-17 17:08:59 --> Config Class Initialized
INFO - 2021-07-17 17:08:59 --> Hooks Class Initialized
DEBUG - 2021-07-17 17:08:59 --> UTF-8 Support Enabled
INFO - 2021-07-17 17:08:59 --> Utf8 Class Initialized
INFO - 2021-07-17 17:08:59 --> URI Class Initialized
INFO - 2021-07-17 17:08:59 --> Router Class Initialized
INFO - 2021-07-17 17:08:59 --> Output Class Initialized
INFO - 2021-07-17 17:08:59 --> Security Class Initialized
DEBUG - 2021-07-17 17:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 17:08:59 --> Input Class Initialized
INFO - 2021-07-17 17:08:59 --> Language Class Initialized
INFO - 2021-07-17 17:08:59 --> Loader Class Initialized
INFO - 2021-07-17 17:08:59 --> Helper loaded: basic_helper
INFO - 2021-07-17 17:08:59 --> Helper loaded: url_helper
INFO - 2021-07-17 17:08:59 --> Helper loaded: file_helper
INFO - 2021-07-17 17:08:59 --> Helper loaded: form_helper
INFO - 2021-07-17 17:08:59 --> Helper loaded: cookie_helper
INFO - 2021-07-17 17:08:59 --> Helper loaded: security_helper
INFO - 2021-07-17 17:08:59 --> Helper loaded: directory_helper
INFO - 2021-07-17 17:08:59 --> Helper loaded: language_helper
INFO - 2021-07-17 17:08:59 --> Helper loaded: general_helper
INFO - 2021-07-17 17:08:59 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 17:08:59 --> Database Driver Class Initialized
DEBUG - 2021-07-17 17:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 17:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 17:08:59 --> Parser Class Initialized
INFO - 2021-07-17 17:08:59 --> Form Validation Class Initialized
INFO - 2021-07-17 17:08:59 --> Upload Class Initialized
INFO - 2021-07-17 17:08:59 --> Email Class Initialized
INFO - 2021-07-17 17:08:59 --> MY_Model class loaded
INFO - 2021-07-17 17:08:59 --> Model "Users_model" initialized
INFO - 2021-07-17 17:08:59 --> Model "Settings_model" initialized
INFO - 2021-07-17 17:08:59 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 17:08:59 --> Model "Permissions_model" initialized
INFO - 2021-07-17 17:08:59 --> Model "Roles_model" initialized
INFO - 2021-07-17 17:08:59 --> Model "Activity_model" initialized
INFO - 2021-07-17 17:08:59 --> Model "Templates_model" initialized
INFO - 2021-07-17 17:08:59 --> Database Driver Class Initialized
INFO - 2021-07-17 17:08:59 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 17:08:59 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 17:08:59 --> Controller Class Initialized
ERROR - 2021-07-17 17:08:59 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 17:08:59 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 17:08:59 --> Final output sent to browser
DEBUG - 2021-07-17 17:08:59 --> Total execution time: 0.1270
INFO - 2021-07-17 17:14:30 --> Config Class Initialized
INFO - 2021-07-17 17:14:30 --> Hooks Class Initialized
DEBUG - 2021-07-17 17:14:30 --> UTF-8 Support Enabled
INFO - 2021-07-17 17:14:30 --> Utf8 Class Initialized
INFO - 2021-07-17 17:14:30 --> URI Class Initialized
INFO - 2021-07-17 17:14:30 --> Router Class Initialized
INFO - 2021-07-17 17:14:30 --> Output Class Initialized
INFO - 2021-07-17 17:14:30 --> Security Class Initialized
DEBUG - 2021-07-17 17:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 17:14:30 --> Input Class Initialized
INFO - 2021-07-17 17:14:30 --> Language Class Initialized
INFO - 2021-07-17 17:14:30 --> Loader Class Initialized
INFO - 2021-07-17 17:14:30 --> Helper loaded: basic_helper
INFO - 2021-07-17 17:14:30 --> Helper loaded: url_helper
INFO - 2021-07-17 17:14:30 --> Helper loaded: file_helper
INFO - 2021-07-17 17:14:30 --> Helper loaded: form_helper
INFO - 2021-07-17 17:14:30 --> Helper loaded: cookie_helper
INFO - 2021-07-17 17:14:30 --> Helper loaded: security_helper
INFO - 2021-07-17 17:14:30 --> Helper loaded: directory_helper
INFO - 2021-07-17 17:14:30 --> Helper loaded: language_helper
INFO - 2021-07-17 17:14:30 --> Helper loaded: general_helper
INFO - 2021-07-17 17:14:30 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 17:14:30 --> Database Driver Class Initialized
DEBUG - 2021-07-17 17:14:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 17:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 17:14:30 --> Parser Class Initialized
INFO - 2021-07-17 17:14:30 --> Form Validation Class Initialized
INFO - 2021-07-17 17:14:30 --> Upload Class Initialized
INFO - 2021-07-17 17:14:30 --> Email Class Initialized
INFO - 2021-07-17 17:14:30 --> MY_Model class loaded
INFO - 2021-07-17 17:14:30 --> Model "Users_model" initialized
INFO - 2021-07-17 17:14:30 --> Model "Settings_model" initialized
INFO - 2021-07-17 17:14:30 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 17:14:30 --> Model "Permissions_model" initialized
INFO - 2021-07-17 17:14:30 --> Model "Roles_model" initialized
INFO - 2021-07-17 17:14:30 --> Model "Activity_model" initialized
INFO - 2021-07-17 17:14:30 --> Model "Templates_model" initialized
INFO - 2021-07-17 17:14:30 --> Database Driver Class Initialized
INFO - 2021-07-17 17:14:31 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 17:14:31 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 17:14:31 --> Controller Class Initialized
ERROR - 2021-07-17 17:14:31 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 17:14:31 --> File loaded: C:\wamp64\www\crm\application\views\export.php
INFO - 2021-07-17 17:14:31 --> Final output sent to browser
DEBUG - 2021-07-17 17:14:31 --> Total execution time: 0.1282
INFO - 2021-07-17 17:14:32 --> Config Class Initialized
INFO - 2021-07-17 17:14:32 --> Hooks Class Initialized
DEBUG - 2021-07-17 17:14:32 --> UTF-8 Support Enabled
INFO - 2021-07-17 17:14:32 --> Utf8 Class Initialized
INFO - 2021-07-17 17:14:32 --> URI Class Initialized
INFO - 2021-07-17 17:14:32 --> Router Class Initialized
INFO - 2021-07-17 17:14:32 --> Output Class Initialized
INFO - 2021-07-17 17:14:32 --> Security Class Initialized
DEBUG - 2021-07-17 17:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 17:14:32 --> Input Class Initialized
INFO - 2021-07-17 17:14:32 --> Language Class Initialized
INFO - 2021-07-17 17:14:32 --> Loader Class Initialized
INFO - 2021-07-17 17:14:32 --> Helper loaded: basic_helper
INFO - 2021-07-17 17:14:32 --> Helper loaded: url_helper
INFO - 2021-07-17 17:14:32 --> Helper loaded: file_helper
INFO - 2021-07-17 17:14:32 --> Helper loaded: form_helper
INFO - 2021-07-17 17:14:32 --> Helper loaded: cookie_helper
INFO - 2021-07-17 17:14:32 --> Helper loaded: security_helper
INFO - 2021-07-17 17:14:32 --> Helper loaded: directory_helper
INFO - 2021-07-17 17:14:32 --> Helper loaded: language_helper
INFO - 2021-07-17 17:14:32 --> Helper loaded: general_helper
INFO - 2021-07-17 17:14:32 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 17:14:32 --> Database Driver Class Initialized
DEBUG - 2021-07-17 17:14:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 17:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 17:14:32 --> Parser Class Initialized
INFO - 2021-07-17 17:14:32 --> Form Validation Class Initialized
INFO - 2021-07-17 17:14:32 --> Upload Class Initialized
INFO - 2021-07-17 17:14:32 --> Email Class Initialized
INFO - 2021-07-17 17:14:32 --> MY_Model class loaded
INFO - 2021-07-17 17:14:32 --> Model "Users_model" initialized
INFO - 2021-07-17 17:14:32 --> Model "Settings_model" initialized
INFO - 2021-07-17 17:14:32 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 17:14:32 --> Model "Permissions_model" initialized
INFO - 2021-07-17 17:14:32 --> Model "Roles_model" initialized
INFO - 2021-07-17 17:14:32 --> Model "Activity_model" initialized
INFO - 2021-07-17 17:14:32 --> Model "Templates_model" initialized
INFO - 2021-07-17 17:14:32 --> Database Driver Class Initialized
INFO - 2021-07-17 17:14:32 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 17:14:32 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 17:14:32 --> Controller Class Initialized
ERROR - 2021-07-17 17:14:32 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 17:14:32 --> File loaded: C:\wamp64\www\crm\application\views\permissions/list.php
INFO - 2021-07-17 17:14:32 --> Final output sent to browser
DEBUG - 2021-07-17 17:14:32 --> Total execution time: 0.1162
INFO - 2021-07-17 17:14:33 --> Config Class Initialized
INFO - 2021-07-17 17:14:33 --> Hooks Class Initialized
DEBUG - 2021-07-17 17:14:33 --> UTF-8 Support Enabled
INFO - 2021-07-17 17:14:33 --> Utf8 Class Initialized
INFO - 2021-07-17 17:14:33 --> URI Class Initialized
INFO - 2021-07-17 17:14:33 --> Router Class Initialized
INFO - 2021-07-17 17:14:33 --> Output Class Initialized
INFO - 2021-07-17 17:14:33 --> Security Class Initialized
DEBUG - 2021-07-17 17:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 17:14:33 --> Input Class Initialized
INFO - 2021-07-17 17:14:33 --> Language Class Initialized
INFO - 2021-07-17 17:14:33 --> Loader Class Initialized
INFO - 2021-07-17 17:14:33 --> Helper loaded: basic_helper
INFO - 2021-07-17 17:14:33 --> Helper loaded: url_helper
INFO - 2021-07-17 17:14:33 --> Helper loaded: file_helper
INFO - 2021-07-17 17:14:33 --> Helper loaded: form_helper
INFO - 2021-07-17 17:14:33 --> Helper loaded: cookie_helper
INFO - 2021-07-17 17:14:33 --> Helper loaded: security_helper
INFO - 2021-07-17 17:14:33 --> Helper loaded: directory_helper
INFO - 2021-07-17 17:14:33 --> Helper loaded: language_helper
INFO - 2021-07-17 17:14:33 --> Helper loaded: general_helper
INFO - 2021-07-17 17:14:33 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 17:14:33 --> Database Driver Class Initialized
DEBUG - 2021-07-17 17:14:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 17:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 17:14:33 --> Parser Class Initialized
INFO - 2021-07-17 17:14:33 --> Form Validation Class Initialized
INFO - 2021-07-17 17:14:33 --> Upload Class Initialized
INFO - 2021-07-17 17:14:33 --> Email Class Initialized
INFO - 2021-07-17 17:14:33 --> MY_Model class loaded
INFO - 2021-07-17 17:14:33 --> Model "Users_model" initialized
INFO - 2021-07-17 17:14:33 --> Model "Settings_model" initialized
INFO - 2021-07-17 17:14:33 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 17:14:33 --> Model "Permissions_model" initialized
INFO - 2021-07-17 17:14:33 --> Model "Roles_model" initialized
INFO - 2021-07-17 17:14:33 --> Model "Activity_model" initialized
INFO - 2021-07-17 17:14:33 --> Model "Templates_model" initialized
INFO - 2021-07-17 17:14:33 --> Database Driver Class Initialized
INFO - 2021-07-17 17:14:33 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 17:14:33 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 17:14:33 --> Controller Class Initialized
ERROR - 2021-07-17 17:14:33 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 17:14:33 --> File loaded: C:\wamp64\www\crm\application\views\roles/list.php
INFO - 2021-07-17 17:14:33 --> Final output sent to browser
DEBUG - 2021-07-17 17:14:33 --> Total execution time: 0.0827
INFO - 2021-07-17 17:14:34 --> Config Class Initialized
INFO - 2021-07-17 17:14:34 --> Hooks Class Initialized
DEBUG - 2021-07-17 17:14:34 --> UTF-8 Support Enabled
INFO - 2021-07-17 17:14:34 --> Utf8 Class Initialized
INFO - 2021-07-17 17:14:34 --> URI Class Initialized
INFO - 2021-07-17 17:14:34 --> Router Class Initialized
INFO - 2021-07-17 17:14:34 --> Output Class Initialized
INFO - 2021-07-17 17:14:34 --> Security Class Initialized
DEBUG - 2021-07-17 17:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 17:14:34 --> Input Class Initialized
INFO - 2021-07-17 17:14:34 --> Language Class Initialized
INFO - 2021-07-17 17:14:34 --> Loader Class Initialized
INFO - 2021-07-17 17:14:34 --> Helper loaded: basic_helper
INFO - 2021-07-17 17:14:34 --> Helper loaded: url_helper
INFO - 2021-07-17 17:14:34 --> Helper loaded: file_helper
INFO - 2021-07-17 17:14:34 --> Helper loaded: form_helper
INFO - 2021-07-17 17:14:34 --> Helper loaded: cookie_helper
INFO - 2021-07-17 17:14:34 --> Helper loaded: security_helper
INFO - 2021-07-17 17:14:34 --> Helper loaded: directory_helper
INFO - 2021-07-17 17:14:34 --> Helper loaded: language_helper
INFO - 2021-07-17 17:14:34 --> Helper loaded: general_helper
INFO - 2021-07-17 17:14:34 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 17:14:34 --> Database Driver Class Initialized
DEBUG - 2021-07-17 17:14:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 17:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 17:14:34 --> Parser Class Initialized
INFO - 2021-07-17 17:14:34 --> Form Validation Class Initialized
INFO - 2021-07-17 17:14:34 --> Upload Class Initialized
INFO - 2021-07-17 17:14:34 --> Email Class Initialized
INFO - 2021-07-17 17:14:34 --> MY_Model class loaded
INFO - 2021-07-17 17:14:34 --> Model "Users_model" initialized
INFO - 2021-07-17 17:14:34 --> Model "Settings_model" initialized
INFO - 2021-07-17 17:14:34 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 17:14:34 --> Model "Permissions_model" initialized
INFO - 2021-07-17 17:14:34 --> Model "Roles_model" initialized
INFO - 2021-07-17 17:14:34 --> Model "Activity_model" initialized
INFO - 2021-07-17 17:14:34 --> Model "Templates_model" initialized
INFO - 2021-07-17 17:14:34 --> Database Driver Class Initialized
INFO - 2021-07-17 17:14:34 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 17:14:34 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 17:14:34 --> Controller Class Initialized
ERROR - 2021-07-17 17:14:34 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 17:14:34 --> File loaded: C:\wamp64\www\crm\application\views\activity_logs/list.php
INFO - 2021-07-17 17:14:34 --> Final output sent to browser
DEBUG - 2021-07-17 17:14:34 --> Total execution time: 0.2194
INFO - 2021-07-17 17:15:09 --> Config Class Initialized
INFO - 2021-07-17 17:15:09 --> Hooks Class Initialized
DEBUG - 2021-07-17 17:15:09 --> UTF-8 Support Enabled
INFO - 2021-07-17 17:15:09 --> Utf8 Class Initialized
INFO - 2021-07-17 17:15:09 --> URI Class Initialized
INFO - 2021-07-17 17:15:09 --> Router Class Initialized
INFO - 2021-07-17 17:15:09 --> Output Class Initialized
INFO - 2021-07-17 17:15:09 --> Security Class Initialized
DEBUG - 2021-07-17 17:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 17:15:09 --> Input Class Initialized
INFO - 2021-07-17 17:15:09 --> Language Class Initialized
INFO - 2021-07-17 17:15:09 --> Loader Class Initialized
INFO - 2021-07-17 17:15:09 --> Helper loaded: basic_helper
INFO - 2021-07-17 17:15:09 --> Helper loaded: url_helper
INFO - 2021-07-17 17:15:09 --> Helper loaded: file_helper
INFO - 2021-07-17 17:15:09 --> Helper loaded: form_helper
INFO - 2021-07-17 17:15:09 --> Helper loaded: cookie_helper
INFO - 2021-07-17 17:15:09 --> Helper loaded: security_helper
INFO - 2021-07-17 17:15:09 --> Helper loaded: directory_helper
INFO - 2021-07-17 17:15:09 --> Helper loaded: language_helper
INFO - 2021-07-17 17:15:09 --> Helper loaded: general_helper
INFO - 2021-07-17 17:15:09 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 17:15:09 --> Database Driver Class Initialized
DEBUG - 2021-07-17 17:15:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 17:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 17:15:09 --> Parser Class Initialized
INFO - 2021-07-17 17:15:09 --> Form Validation Class Initialized
INFO - 2021-07-17 17:15:09 --> Upload Class Initialized
INFO - 2021-07-17 17:15:09 --> Email Class Initialized
INFO - 2021-07-17 17:15:09 --> MY_Model class loaded
INFO - 2021-07-17 17:15:09 --> Model "Users_model" initialized
INFO - 2021-07-17 17:15:09 --> Model "Settings_model" initialized
INFO - 2021-07-17 17:15:09 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 17:15:09 --> Model "Permissions_model" initialized
INFO - 2021-07-17 17:15:09 --> Model "Roles_model" initialized
INFO - 2021-07-17 17:15:09 --> Model "Activity_model" initialized
INFO - 2021-07-17 17:15:09 --> Model "Templates_model" initialized
INFO - 2021-07-17 17:15:09 --> Database Driver Class Initialized
INFO - 2021-07-17 17:15:09 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 17:15:09 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 17:15:09 --> Controller Class Initialized
ERROR - 2021-07-17 17:15:09 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 17:15:09 --> File loaded: C:\wamp64\www\crm\application\views\activity_logs/view.php
INFO - 2021-07-17 17:15:09 --> Final output sent to browser
DEBUG - 2021-07-17 17:15:09 --> Total execution time: 0.2027
INFO - 2021-07-17 17:15:10 --> Config Class Initialized
INFO - 2021-07-17 17:15:10 --> Hooks Class Initialized
DEBUG - 2021-07-17 17:15:10 --> UTF-8 Support Enabled
INFO - 2021-07-17 17:15:10 --> Utf8 Class Initialized
INFO - 2021-07-17 17:15:10 --> URI Class Initialized
INFO - 2021-07-17 17:15:10 --> Router Class Initialized
INFO - 2021-07-17 17:15:10 --> Output Class Initialized
INFO - 2021-07-17 17:15:10 --> Security Class Initialized
DEBUG - 2021-07-17 17:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 17:15:10 --> Input Class Initialized
INFO - 2021-07-17 17:15:10 --> Language Class Initialized
INFO - 2021-07-17 17:15:10 --> Loader Class Initialized
INFO - 2021-07-17 17:15:10 --> Helper loaded: basic_helper
INFO - 2021-07-17 17:15:10 --> Helper loaded: url_helper
INFO - 2021-07-17 17:15:10 --> Helper loaded: file_helper
INFO - 2021-07-17 17:15:10 --> Helper loaded: form_helper
INFO - 2021-07-17 17:15:10 --> Helper loaded: cookie_helper
INFO - 2021-07-17 17:15:10 --> Helper loaded: security_helper
INFO - 2021-07-17 17:15:10 --> Helper loaded: directory_helper
INFO - 2021-07-17 17:15:10 --> Helper loaded: language_helper
INFO - 2021-07-17 17:15:10 --> Helper loaded: general_helper
INFO - 2021-07-17 17:15:10 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 17:15:10 --> Database Driver Class Initialized
DEBUG - 2021-07-17 17:15:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 17:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 17:15:10 --> Parser Class Initialized
INFO - 2021-07-17 17:15:10 --> Form Validation Class Initialized
INFO - 2021-07-17 17:15:10 --> Upload Class Initialized
INFO - 2021-07-17 17:15:11 --> Email Class Initialized
INFO - 2021-07-17 17:15:11 --> MY_Model class loaded
INFO - 2021-07-17 17:15:11 --> Model "Users_model" initialized
INFO - 2021-07-17 17:15:11 --> Model "Settings_model" initialized
INFO - 2021-07-17 17:15:11 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 17:15:11 --> Model "Permissions_model" initialized
INFO - 2021-07-17 17:15:11 --> Model "Roles_model" initialized
INFO - 2021-07-17 17:15:11 --> Model "Activity_model" initialized
INFO - 2021-07-17 17:15:11 --> Model "Templates_model" initialized
INFO - 2021-07-17 17:15:11 --> Database Driver Class Initialized
INFO - 2021-07-17 17:15:11 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 17:15:11 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 17:15:11 --> Controller Class Initialized
ERROR - 2021-07-17 17:15:11 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 17:15:11 --> File loaded: C:\wamp64\www\crm\application\views\users/view.php
INFO - 2021-07-17 17:15:11 --> Final output sent to browser
DEBUG - 2021-07-17 17:15:11 --> Total execution time: 0.0676
INFO - 2021-07-17 17:15:13 --> Config Class Initialized
INFO - 2021-07-17 17:15:13 --> Hooks Class Initialized
DEBUG - 2021-07-17 17:15:13 --> UTF-8 Support Enabled
INFO - 2021-07-17 17:15:13 --> Utf8 Class Initialized
INFO - 2021-07-17 17:15:13 --> URI Class Initialized
INFO - 2021-07-17 17:15:13 --> Router Class Initialized
INFO - 2021-07-17 17:15:13 --> Output Class Initialized
INFO - 2021-07-17 17:15:13 --> Security Class Initialized
DEBUG - 2021-07-17 17:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 17:15:13 --> Input Class Initialized
INFO - 2021-07-17 17:15:13 --> Language Class Initialized
INFO - 2021-07-17 17:15:13 --> Loader Class Initialized
INFO - 2021-07-17 17:15:13 --> Helper loaded: basic_helper
INFO - 2021-07-17 17:15:13 --> Helper loaded: url_helper
INFO - 2021-07-17 17:15:13 --> Helper loaded: file_helper
INFO - 2021-07-17 17:15:13 --> Helper loaded: form_helper
INFO - 2021-07-17 17:15:13 --> Helper loaded: cookie_helper
INFO - 2021-07-17 17:15:13 --> Helper loaded: security_helper
INFO - 2021-07-17 17:15:13 --> Helper loaded: directory_helper
INFO - 2021-07-17 17:15:13 --> Helper loaded: language_helper
INFO - 2021-07-17 17:15:13 --> Helper loaded: general_helper
INFO - 2021-07-17 17:15:13 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 17:15:13 --> Database Driver Class Initialized
DEBUG - 2021-07-17 17:15:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 17:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 17:15:13 --> Parser Class Initialized
INFO - 2021-07-17 17:15:13 --> Form Validation Class Initialized
INFO - 2021-07-17 17:15:13 --> Upload Class Initialized
INFO - 2021-07-17 17:15:13 --> Email Class Initialized
INFO - 2021-07-17 17:15:13 --> MY_Model class loaded
INFO - 2021-07-17 17:15:13 --> Model "Users_model" initialized
INFO - 2021-07-17 17:15:13 --> Model "Settings_model" initialized
INFO - 2021-07-17 17:15:13 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 17:15:13 --> Model "Permissions_model" initialized
INFO - 2021-07-17 17:15:13 --> Model "Roles_model" initialized
INFO - 2021-07-17 17:15:13 --> Model "Activity_model" initialized
INFO - 2021-07-17 17:15:13 --> Model "Templates_model" initialized
INFO - 2021-07-17 17:15:13 --> Database Driver Class Initialized
INFO - 2021-07-17 17:15:13 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 17:15:13 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 17:15:13 --> Controller Class Initialized
ERROR - 2021-07-17 17:15:13 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 17:15:13 --> File loaded: C:\wamp64\www\crm\application\views\users/view.php
INFO - 2021-07-17 17:15:13 --> Final output sent to browser
DEBUG - 2021-07-17 17:15:13 --> Total execution time: 0.2394
INFO - 2021-07-17 17:15:17 --> Config Class Initialized
INFO - 2021-07-17 17:15:17 --> Hooks Class Initialized
DEBUG - 2021-07-17 17:15:17 --> UTF-8 Support Enabled
INFO - 2021-07-17 17:15:17 --> Utf8 Class Initialized
INFO - 2021-07-17 17:15:17 --> URI Class Initialized
INFO - 2021-07-17 17:15:17 --> Router Class Initialized
INFO - 2021-07-17 17:15:17 --> Output Class Initialized
INFO - 2021-07-17 17:15:17 --> Security Class Initialized
DEBUG - 2021-07-17 17:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 17:15:17 --> Input Class Initialized
INFO - 2021-07-17 17:15:17 --> Language Class Initialized
INFO - 2021-07-17 17:15:17 --> Loader Class Initialized
INFO - 2021-07-17 17:15:17 --> Helper loaded: basic_helper
INFO - 2021-07-17 17:15:17 --> Helper loaded: url_helper
INFO - 2021-07-17 17:15:17 --> Helper loaded: file_helper
INFO - 2021-07-17 17:15:17 --> Helper loaded: form_helper
INFO - 2021-07-17 17:15:17 --> Helper loaded: cookie_helper
INFO - 2021-07-17 17:15:17 --> Helper loaded: security_helper
INFO - 2021-07-17 17:15:17 --> Helper loaded: directory_helper
INFO - 2021-07-17 17:15:17 --> Helper loaded: language_helper
INFO - 2021-07-17 17:15:17 --> Helper loaded: general_helper
INFO - 2021-07-17 17:15:17 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 17:15:17 --> Database Driver Class Initialized
DEBUG - 2021-07-17 17:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 17:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 17:15:17 --> Parser Class Initialized
INFO - 2021-07-17 17:15:17 --> Form Validation Class Initialized
INFO - 2021-07-17 17:15:17 --> Upload Class Initialized
INFO - 2021-07-17 17:15:17 --> Email Class Initialized
INFO - 2021-07-17 17:15:17 --> MY_Model class loaded
INFO - 2021-07-17 17:15:17 --> Model "Users_model" initialized
INFO - 2021-07-17 17:15:17 --> Model "Settings_model" initialized
INFO - 2021-07-17 17:15:17 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 17:15:17 --> Model "Permissions_model" initialized
INFO - 2021-07-17 17:15:17 --> Model "Roles_model" initialized
INFO - 2021-07-17 17:15:17 --> Model "Activity_model" initialized
INFO - 2021-07-17 17:15:17 --> Model "Templates_model" initialized
INFO - 2021-07-17 17:15:17 --> Database Driver Class Initialized
INFO - 2021-07-17 17:15:17 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 17:15:17 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 17:15:17 --> Controller Class Initialized
ERROR - 2021-07-17 17:15:17 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 17:15:17 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 17:15:17 --> Final output sent to browser
DEBUG - 2021-07-17 17:15:17 --> Total execution time: 0.0640
INFO - 2021-07-17 17:20:24 --> Config Class Initialized
INFO - 2021-07-17 17:20:24 --> Hooks Class Initialized
DEBUG - 2021-07-17 17:20:24 --> UTF-8 Support Enabled
INFO - 2021-07-17 17:20:24 --> Utf8 Class Initialized
INFO - 2021-07-17 17:20:24 --> URI Class Initialized
INFO - 2021-07-17 17:20:24 --> Router Class Initialized
INFO - 2021-07-17 17:20:24 --> Output Class Initialized
INFO - 2021-07-17 17:20:24 --> Security Class Initialized
DEBUG - 2021-07-17 17:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 17:20:24 --> Input Class Initialized
INFO - 2021-07-17 17:20:24 --> Language Class Initialized
INFO - 2021-07-17 17:20:24 --> Loader Class Initialized
INFO - 2021-07-17 17:20:24 --> Helper loaded: basic_helper
INFO - 2021-07-17 17:20:24 --> Helper loaded: url_helper
INFO - 2021-07-17 17:20:24 --> Helper loaded: file_helper
INFO - 2021-07-17 17:20:24 --> Helper loaded: form_helper
INFO - 2021-07-17 17:20:24 --> Helper loaded: cookie_helper
INFO - 2021-07-17 17:20:24 --> Helper loaded: security_helper
INFO - 2021-07-17 17:20:24 --> Helper loaded: directory_helper
INFO - 2021-07-17 17:20:24 --> Helper loaded: language_helper
INFO - 2021-07-17 17:20:24 --> Helper loaded: general_helper
INFO - 2021-07-17 17:20:24 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 17:20:24 --> Database Driver Class Initialized
DEBUG - 2021-07-17 17:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 17:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 17:20:24 --> Parser Class Initialized
INFO - 2021-07-17 17:20:24 --> Form Validation Class Initialized
INFO - 2021-07-17 17:20:24 --> Upload Class Initialized
INFO - 2021-07-17 17:20:24 --> Email Class Initialized
INFO - 2021-07-17 17:20:24 --> MY_Model class loaded
INFO - 2021-07-17 17:20:24 --> Model "Users_model" initialized
INFO - 2021-07-17 17:20:24 --> Model "Settings_model" initialized
INFO - 2021-07-17 17:20:24 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 17:20:24 --> Model "Permissions_model" initialized
INFO - 2021-07-17 17:20:24 --> Model "Roles_model" initialized
INFO - 2021-07-17 17:20:24 --> Model "Activity_model" initialized
INFO - 2021-07-17 17:20:24 --> Model "Templates_model" initialized
INFO - 2021-07-17 17:20:24 --> Database Driver Class Initialized
INFO - 2021-07-17 17:20:24 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 17:20:24 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 17:20:24 --> Controller Class Initialized
ERROR - 2021-07-17 17:20:24 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 17:20:24 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 17:20:24 --> Final output sent to browser
DEBUG - 2021-07-17 17:20:24 --> Total execution time: 0.1276
INFO - 2021-07-17 17:20:57 --> Config Class Initialized
INFO - 2021-07-17 17:20:57 --> Hooks Class Initialized
DEBUG - 2021-07-17 17:20:57 --> UTF-8 Support Enabled
INFO - 2021-07-17 17:20:57 --> Utf8 Class Initialized
INFO - 2021-07-17 17:20:57 --> URI Class Initialized
INFO - 2021-07-17 17:20:57 --> Router Class Initialized
INFO - 2021-07-17 17:20:57 --> Output Class Initialized
INFO - 2021-07-17 17:20:57 --> Security Class Initialized
DEBUG - 2021-07-17 17:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 17:20:57 --> Input Class Initialized
INFO - 2021-07-17 17:20:57 --> Language Class Initialized
INFO - 2021-07-17 17:20:57 --> Loader Class Initialized
INFO - 2021-07-17 17:20:57 --> Helper loaded: basic_helper
INFO - 2021-07-17 17:20:57 --> Helper loaded: url_helper
INFO - 2021-07-17 17:20:57 --> Helper loaded: file_helper
INFO - 2021-07-17 17:20:57 --> Helper loaded: form_helper
INFO - 2021-07-17 17:20:57 --> Helper loaded: cookie_helper
INFO - 2021-07-17 17:20:57 --> Helper loaded: security_helper
INFO - 2021-07-17 17:20:57 --> Helper loaded: directory_helper
INFO - 2021-07-17 17:20:57 --> Helper loaded: language_helper
INFO - 2021-07-17 17:20:57 --> Helper loaded: general_helper
INFO - 2021-07-17 17:20:57 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 17:20:57 --> Database Driver Class Initialized
DEBUG - 2021-07-17 17:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 17:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 17:20:57 --> Parser Class Initialized
INFO - 2021-07-17 17:20:57 --> Form Validation Class Initialized
INFO - 2021-07-17 17:20:57 --> Upload Class Initialized
INFO - 2021-07-17 17:20:57 --> Email Class Initialized
INFO - 2021-07-17 17:20:57 --> MY_Model class loaded
INFO - 2021-07-17 17:20:57 --> Model "Users_model" initialized
INFO - 2021-07-17 17:20:57 --> Model "Settings_model" initialized
INFO - 2021-07-17 17:20:57 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 17:20:57 --> Model "Permissions_model" initialized
INFO - 2021-07-17 17:20:57 --> Model "Roles_model" initialized
INFO - 2021-07-17 17:20:57 --> Model "Activity_model" initialized
INFO - 2021-07-17 17:20:57 --> Model "Templates_model" initialized
INFO - 2021-07-17 17:20:57 --> Database Driver Class Initialized
INFO - 2021-07-17 17:20:57 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 17:20:57 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 17:20:57 --> Controller Class Initialized
ERROR - 2021-07-17 17:20:57 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 17:20:57 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 17:20:57 --> Config Class Initialized
INFO - 2021-07-17 17:20:57 --> Hooks Class Initialized
DEBUG - 2021-07-17 17:20:57 --> UTF-8 Support Enabled
INFO - 2021-07-17 17:20:57 --> Utf8 Class Initialized
INFO - 2021-07-17 17:20:57 --> URI Class Initialized
INFO - 2021-07-17 17:20:57 --> Router Class Initialized
INFO - 2021-07-17 17:20:57 --> Output Class Initialized
INFO - 2021-07-17 17:20:57 --> Security Class Initialized
DEBUG - 2021-07-17 17:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 17:20:57 --> Input Class Initialized
INFO - 2021-07-17 17:20:57 --> Language Class Initialized
INFO - 2021-07-17 17:20:57 --> Loader Class Initialized
INFO - 2021-07-17 17:20:57 --> Helper loaded: basic_helper
INFO - 2021-07-17 17:20:57 --> Helper loaded: url_helper
INFO - 2021-07-17 17:20:57 --> Helper loaded: file_helper
INFO - 2021-07-17 17:20:57 --> Helper loaded: form_helper
INFO - 2021-07-17 17:20:57 --> Helper loaded: cookie_helper
INFO - 2021-07-17 17:20:57 --> Helper loaded: security_helper
INFO - 2021-07-17 17:20:57 --> Helper loaded: directory_helper
INFO - 2021-07-17 17:20:57 --> Helper loaded: language_helper
INFO - 2021-07-17 17:20:57 --> Helper loaded: general_helper
INFO - 2021-07-17 17:20:57 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 17:20:57 --> Database Driver Class Initialized
DEBUG - 2021-07-17 17:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 17:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 17:20:57 --> Parser Class Initialized
INFO - 2021-07-17 17:20:57 --> Form Validation Class Initialized
INFO - 2021-07-17 17:20:57 --> Upload Class Initialized
INFO - 2021-07-17 17:20:57 --> Email Class Initialized
INFO - 2021-07-17 17:20:57 --> MY_Model class loaded
INFO - 2021-07-17 17:20:57 --> Model "Users_model" initialized
INFO - 2021-07-17 17:20:57 --> Model "Settings_model" initialized
INFO - 2021-07-17 17:20:57 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 17:20:57 --> Model "Permissions_model" initialized
INFO - 2021-07-17 17:20:57 --> Model "Roles_model" initialized
INFO - 2021-07-17 17:20:57 --> Model "Activity_model" initialized
INFO - 2021-07-17 17:20:57 --> Model "Templates_model" initialized
INFO - 2021-07-17 17:20:57 --> Database Driver Class Initialized
INFO - 2021-07-17 17:20:57 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 17:20:57 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 17:20:57 --> Controller Class Initialized
ERROR - 2021-07-17 17:20:57 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 17:20:57 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 17:20:57 --> Final output sent to browser
DEBUG - 2021-07-17 17:20:57 --> Total execution time: 0.0630
INFO - 2021-07-17 17:22:28 --> Config Class Initialized
INFO - 2021-07-17 17:22:28 --> Hooks Class Initialized
DEBUG - 2021-07-17 17:22:28 --> UTF-8 Support Enabled
INFO - 2021-07-17 17:22:28 --> Utf8 Class Initialized
INFO - 2021-07-17 17:22:28 --> URI Class Initialized
INFO - 2021-07-17 17:22:28 --> Router Class Initialized
INFO - 2021-07-17 17:22:28 --> Output Class Initialized
INFO - 2021-07-17 17:22:28 --> Security Class Initialized
DEBUG - 2021-07-17 17:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 17:22:28 --> Input Class Initialized
INFO - 2021-07-17 17:22:28 --> Language Class Initialized
INFO - 2021-07-17 17:22:28 --> Loader Class Initialized
INFO - 2021-07-17 17:22:28 --> Helper loaded: basic_helper
INFO - 2021-07-17 17:22:28 --> Helper loaded: url_helper
INFO - 2021-07-17 17:22:28 --> Helper loaded: file_helper
INFO - 2021-07-17 17:22:28 --> Helper loaded: form_helper
INFO - 2021-07-17 17:22:28 --> Helper loaded: cookie_helper
INFO - 2021-07-17 17:22:28 --> Helper loaded: security_helper
INFO - 2021-07-17 17:22:28 --> Helper loaded: directory_helper
INFO - 2021-07-17 17:22:28 --> Helper loaded: language_helper
INFO - 2021-07-17 17:22:28 --> Helper loaded: general_helper
INFO - 2021-07-17 17:22:28 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 17:22:28 --> Database Driver Class Initialized
DEBUG - 2021-07-17 17:22:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 17:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 17:22:28 --> Parser Class Initialized
INFO - 2021-07-17 17:22:28 --> Form Validation Class Initialized
INFO - 2021-07-17 17:22:28 --> Upload Class Initialized
INFO - 2021-07-17 17:22:28 --> Email Class Initialized
INFO - 2021-07-17 17:22:28 --> MY_Model class loaded
INFO - 2021-07-17 17:22:28 --> Model "Users_model" initialized
INFO - 2021-07-17 17:22:28 --> Model "Settings_model" initialized
INFO - 2021-07-17 17:22:28 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 17:22:28 --> Model "Permissions_model" initialized
INFO - 2021-07-17 17:22:28 --> Model "Roles_model" initialized
INFO - 2021-07-17 17:22:28 --> Model "Activity_model" initialized
INFO - 2021-07-17 17:22:28 --> Model "Templates_model" initialized
INFO - 2021-07-17 17:22:28 --> Database Driver Class Initialized
INFO - 2021-07-17 17:22:28 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 17:22:28 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 17:22:28 --> Controller Class Initialized
ERROR - 2021-07-17 17:22:28 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 17:22:28 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 17:22:28 --> Final output sent to browser
DEBUG - 2021-07-17 17:22:28 --> Total execution time: 0.5450
INFO - 2021-07-17 17:26:20 --> Config Class Initialized
INFO - 2021-07-17 17:26:20 --> Hooks Class Initialized
DEBUG - 2021-07-17 17:26:20 --> UTF-8 Support Enabled
INFO - 2021-07-17 17:26:20 --> Utf8 Class Initialized
INFO - 2021-07-17 17:26:20 --> URI Class Initialized
DEBUG - 2021-07-17 17:26:20 --> No URI present. Default controller set.
INFO - 2021-07-17 17:26:20 --> Router Class Initialized
INFO - 2021-07-17 17:26:20 --> Output Class Initialized
INFO - 2021-07-17 17:26:20 --> Security Class Initialized
DEBUG - 2021-07-17 17:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 17:26:20 --> Input Class Initialized
INFO - 2021-07-17 17:26:20 --> Language Class Initialized
INFO - 2021-07-17 17:26:20 --> Loader Class Initialized
INFO - 2021-07-17 17:26:20 --> Helper loaded: basic_helper
INFO - 2021-07-17 17:26:20 --> Helper loaded: url_helper
INFO - 2021-07-17 17:26:20 --> Helper loaded: file_helper
INFO - 2021-07-17 17:26:20 --> Helper loaded: form_helper
INFO - 2021-07-17 17:26:20 --> Helper loaded: cookie_helper
INFO - 2021-07-17 17:26:20 --> Helper loaded: security_helper
INFO - 2021-07-17 17:26:20 --> Helper loaded: directory_helper
INFO - 2021-07-17 17:26:20 --> Helper loaded: language_helper
INFO - 2021-07-17 17:26:20 --> Helper loaded: general_helper
INFO - 2021-07-17 17:26:20 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 17:26:20 --> Database Driver Class Initialized
DEBUG - 2021-07-17 17:26:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 17:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 17:26:20 --> Parser Class Initialized
INFO - 2021-07-17 17:26:20 --> Form Validation Class Initialized
INFO - 2021-07-17 17:26:20 --> Upload Class Initialized
INFO - 2021-07-17 17:26:20 --> Email Class Initialized
INFO - 2021-07-17 17:26:20 --> MY_Model class loaded
INFO - 2021-07-17 17:26:20 --> Model "Users_model" initialized
INFO - 2021-07-17 17:26:20 --> Model "Settings_model" initialized
INFO - 2021-07-17 17:26:20 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 17:26:20 --> Model "Permissions_model" initialized
INFO - 2021-07-17 17:26:20 --> Model "Roles_model" initialized
INFO - 2021-07-17 17:26:20 --> Model "Activity_model" initialized
INFO - 2021-07-17 17:26:20 --> Model "Templates_model" initialized
INFO - 2021-07-17 17:26:20 --> Database Driver Class Initialized
INFO - 2021-07-17 17:26:20 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 17:26:20 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 17:26:20 --> Controller Class Initialized
INFO - 2021-07-17 17:27:49 --> Config Class Initialized
INFO - 2021-07-17 17:27:49 --> Hooks Class Initialized
DEBUG - 2021-07-17 17:27:49 --> UTF-8 Support Enabled
INFO - 2021-07-17 17:27:49 --> Utf8 Class Initialized
INFO - 2021-07-17 17:27:49 --> URI Class Initialized
INFO - 2021-07-17 17:27:49 --> Router Class Initialized
INFO - 2021-07-17 17:27:49 --> Output Class Initialized
INFO - 2021-07-17 17:27:49 --> Security Class Initialized
DEBUG - 2021-07-17 17:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 17:27:49 --> Input Class Initialized
INFO - 2021-07-17 17:27:49 --> Language Class Initialized
INFO - 2021-07-17 17:27:49 --> Loader Class Initialized
INFO - 2021-07-17 17:27:49 --> Helper loaded: basic_helper
INFO - 2021-07-17 17:27:49 --> Helper loaded: url_helper
INFO - 2021-07-17 17:27:49 --> Helper loaded: file_helper
INFO - 2021-07-17 17:27:49 --> Helper loaded: form_helper
INFO - 2021-07-17 17:27:49 --> Helper loaded: cookie_helper
INFO - 2021-07-17 17:27:49 --> Helper loaded: security_helper
INFO - 2021-07-17 17:27:49 --> Helper loaded: directory_helper
INFO - 2021-07-17 17:27:49 --> Helper loaded: language_helper
INFO - 2021-07-17 17:27:49 --> Helper loaded: general_helper
INFO - 2021-07-17 17:27:49 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 17:27:49 --> Database Driver Class Initialized
DEBUG - 2021-07-17 17:27:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 17:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 17:27:49 --> Parser Class Initialized
INFO - 2021-07-17 17:27:49 --> Form Validation Class Initialized
INFO - 2021-07-17 17:27:49 --> Upload Class Initialized
INFO - 2021-07-17 17:27:49 --> Email Class Initialized
INFO - 2021-07-17 17:27:49 --> MY_Model class loaded
INFO - 2021-07-17 17:27:49 --> Model "Users_model" initialized
INFO - 2021-07-17 17:27:49 --> Model "Settings_model" initialized
INFO - 2021-07-17 17:27:49 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 17:27:49 --> Model "Permissions_model" initialized
INFO - 2021-07-17 17:27:49 --> Model "Roles_model" initialized
INFO - 2021-07-17 17:27:49 --> Model "Activity_model" initialized
INFO - 2021-07-17 17:27:49 --> Model "Templates_model" initialized
INFO - 2021-07-17 17:27:49 --> Database Driver Class Initialized
INFO - 2021-07-17 17:27:49 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 17:27:49 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 17:27:49 --> Controller Class Initialized
ERROR - 2021-07-17 17:27:49 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 17:27:49 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 17:27:49 --> Final output sent to browser
DEBUG - 2021-07-17 17:27:49 --> Total execution time: 0.6387
INFO - 2021-07-17 17:28:58 --> Config Class Initialized
INFO - 2021-07-17 17:28:58 --> Hooks Class Initialized
DEBUG - 2021-07-17 17:28:58 --> UTF-8 Support Enabled
INFO - 2021-07-17 17:28:58 --> Utf8 Class Initialized
INFO - 2021-07-17 17:28:58 --> URI Class Initialized
INFO - 2021-07-17 17:28:58 --> Router Class Initialized
INFO - 2021-07-17 17:28:58 --> Output Class Initialized
INFO - 2021-07-17 17:28:58 --> Security Class Initialized
DEBUG - 2021-07-17 17:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 17:28:58 --> Input Class Initialized
INFO - 2021-07-17 17:28:58 --> Language Class Initialized
INFO - 2021-07-17 17:28:58 --> Loader Class Initialized
INFO - 2021-07-17 17:28:58 --> Helper loaded: basic_helper
INFO - 2021-07-17 17:28:58 --> Helper loaded: url_helper
INFO - 2021-07-17 17:28:58 --> Helper loaded: file_helper
INFO - 2021-07-17 17:28:58 --> Helper loaded: form_helper
INFO - 2021-07-17 17:28:58 --> Helper loaded: cookie_helper
INFO - 2021-07-17 17:28:58 --> Helper loaded: security_helper
INFO - 2021-07-17 17:28:58 --> Helper loaded: directory_helper
INFO - 2021-07-17 17:28:58 --> Helper loaded: language_helper
INFO - 2021-07-17 17:28:58 --> Helper loaded: general_helper
INFO - 2021-07-17 17:28:58 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 17:28:58 --> Database Driver Class Initialized
DEBUG - 2021-07-17 17:28:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 17:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 17:28:58 --> Parser Class Initialized
INFO - 2021-07-17 17:28:58 --> Form Validation Class Initialized
INFO - 2021-07-17 17:28:58 --> Upload Class Initialized
INFO - 2021-07-17 17:28:58 --> Email Class Initialized
INFO - 2021-07-17 17:28:58 --> MY_Model class loaded
INFO - 2021-07-17 17:28:58 --> Model "Users_model" initialized
INFO - 2021-07-17 17:28:58 --> Model "Settings_model" initialized
INFO - 2021-07-17 17:28:58 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 17:28:58 --> Model "Permissions_model" initialized
INFO - 2021-07-17 17:28:58 --> Model "Roles_model" initialized
INFO - 2021-07-17 17:28:58 --> Model "Activity_model" initialized
INFO - 2021-07-17 17:28:58 --> Model "Templates_model" initialized
INFO - 2021-07-17 17:28:58 --> Database Driver Class Initialized
INFO - 2021-07-17 17:28:58 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 17:28:58 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 17:28:58 --> Controller Class Initialized
ERROR - 2021-07-17 17:28:58 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 17:28:58 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 17:28:58 --> Final output sent to browser
DEBUG - 2021-07-17 17:28:58 --> Total execution time: 0.5365
INFO - 2021-07-17 17:29:13 --> Config Class Initialized
INFO - 2021-07-17 17:29:13 --> Hooks Class Initialized
DEBUG - 2021-07-17 17:29:13 --> UTF-8 Support Enabled
INFO - 2021-07-17 17:29:13 --> Utf8 Class Initialized
INFO - 2021-07-17 17:29:13 --> URI Class Initialized
INFO - 2021-07-17 17:29:13 --> Router Class Initialized
INFO - 2021-07-17 17:29:13 --> Output Class Initialized
INFO - 2021-07-17 17:29:13 --> Security Class Initialized
DEBUG - 2021-07-17 17:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 17:29:13 --> Input Class Initialized
INFO - 2021-07-17 17:29:13 --> Language Class Initialized
INFO - 2021-07-17 17:29:13 --> Loader Class Initialized
INFO - 2021-07-17 17:29:13 --> Helper loaded: basic_helper
INFO - 2021-07-17 17:29:13 --> Helper loaded: url_helper
INFO - 2021-07-17 17:29:13 --> Helper loaded: file_helper
INFO - 2021-07-17 17:29:13 --> Helper loaded: form_helper
INFO - 2021-07-17 17:29:13 --> Helper loaded: cookie_helper
INFO - 2021-07-17 17:29:13 --> Helper loaded: security_helper
INFO - 2021-07-17 17:29:13 --> Helper loaded: directory_helper
INFO - 2021-07-17 17:29:13 --> Helper loaded: language_helper
INFO - 2021-07-17 17:29:13 --> Helper loaded: general_helper
INFO - 2021-07-17 17:29:13 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 17:29:13 --> Database Driver Class Initialized
DEBUG - 2021-07-17 17:29:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 17:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 17:29:13 --> Parser Class Initialized
INFO - 2021-07-17 17:29:13 --> Form Validation Class Initialized
INFO - 2021-07-17 17:29:13 --> Upload Class Initialized
INFO - 2021-07-17 17:29:13 --> Email Class Initialized
INFO - 2021-07-17 17:29:13 --> MY_Model class loaded
INFO - 2021-07-17 17:29:13 --> Model "Users_model" initialized
INFO - 2021-07-17 17:29:13 --> Model "Settings_model" initialized
INFO - 2021-07-17 17:29:13 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 17:29:13 --> Model "Permissions_model" initialized
INFO - 2021-07-17 17:29:13 --> Model "Roles_model" initialized
INFO - 2021-07-17 17:29:13 --> Model "Activity_model" initialized
INFO - 2021-07-17 17:29:13 --> Model "Templates_model" initialized
INFO - 2021-07-17 17:29:13 --> Database Driver Class Initialized
INFO - 2021-07-17 17:29:13 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 17:29:13 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 17:29:13 --> Controller Class Initialized
ERROR - 2021-07-17 17:29:13 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 17:29:13 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 17:29:13 --> Final output sent to browser
DEBUG - 2021-07-17 17:29:13 --> Total execution time: 0.1254
INFO - 2021-07-17 17:29:25 --> Config Class Initialized
INFO - 2021-07-17 17:29:25 --> Hooks Class Initialized
DEBUG - 2021-07-17 17:29:25 --> UTF-8 Support Enabled
INFO - 2021-07-17 17:29:25 --> Utf8 Class Initialized
INFO - 2021-07-17 17:29:25 --> URI Class Initialized
INFO - 2021-07-17 17:29:25 --> Router Class Initialized
INFO - 2021-07-17 17:29:25 --> Output Class Initialized
INFO - 2021-07-17 17:29:25 --> Security Class Initialized
DEBUG - 2021-07-17 17:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 17:29:25 --> Input Class Initialized
INFO - 2021-07-17 17:29:25 --> Language Class Initialized
INFO - 2021-07-17 17:29:25 --> Loader Class Initialized
INFO - 2021-07-17 17:29:25 --> Helper loaded: basic_helper
INFO - 2021-07-17 17:29:25 --> Helper loaded: url_helper
INFO - 2021-07-17 17:29:25 --> Helper loaded: file_helper
INFO - 2021-07-17 17:29:25 --> Helper loaded: form_helper
INFO - 2021-07-17 17:29:25 --> Helper loaded: cookie_helper
INFO - 2021-07-17 17:29:25 --> Helper loaded: security_helper
INFO - 2021-07-17 17:29:25 --> Helper loaded: directory_helper
INFO - 2021-07-17 17:29:25 --> Helper loaded: language_helper
INFO - 2021-07-17 17:29:25 --> Helper loaded: general_helper
INFO - 2021-07-17 17:29:25 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 17:29:25 --> Database Driver Class Initialized
DEBUG - 2021-07-17 17:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 17:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 17:29:25 --> Parser Class Initialized
INFO - 2021-07-17 17:29:25 --> Form Validation Class Initialized
INFO - 2021-07-17 17:29:25 --> Upload Class Initialized
INFO - 2021-07-17 17:29:25 --> Email Class Initialized
INFO - 2021-07-17 17:29:25 --> MY_Model class loaded
INFO - 2021-07-17 17:29:25 --> Model "Users_model" initialized
INFO - 2021-07-17 17:29:25 --> Model "Settings_model" initialized
INFO - 2021-07-17 17:29:25 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 17:29:25 --> Model "Permissions_model" initialized
INFO - 2021-07-17 17:29:25 --> Model "Roles_model" initialized
INFO - 2021-07-17 17:29:25 --> Model "Activity_model" initialized
INFO - 2021-07-17 17:29:25 --> Model "Templates_model" initialized
INFO - 2021-07-17 17:29:25 --> Database Driver Class Initialized
INFO - 2021-07-17 17:29:25 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 17:29:25 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 17:29:25 --> Controller Class Initialized
ERROR - 2021-07-17 17:29:25 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 17:29:25 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 17:29:25 --> Final output sent to browser
DEBUG - 2021-07-17 17:29:25 --> Total execution time: 0.1353
INFO - 2021-07-17 17:31:53 --> Config Class Initialized
INFO - 2021-07-17 17:31:53 --> Hooks Class Initialized
DEBUG - 2021-07-17 17:31:53 --> UTF-8 Support Enabled
INFO - 2021-07-17 17:31:53 --> Utf8 Class Initialized
INFO - 2021-07-17 17:31:53 --> URI Class Initialized
INFO - 2021-07-17 17:31:53 --> Router Class Initialized
INFO - 2021-07-17 17:31:53 --> Output Class Initialized
INFO - 2021-07-17 17:31:53 --> Security Class Initialized
DEBUG - 2021-07-17 17:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 17:31:53 --> Input Class Initialized
INFO - 2021-07-17 17:31:53 --> Language Class Initialized
INFO - 2021-07-17 17:31:53 --> Loader Class Initialized
INFO - 2021-07-17 17:31:53 --> Helper loaded: basic_helper
INFO - 2021-07-17 17:31:53 --> Helper loaded: url_helper
INFO - 2021-07-17 17:31:53 --> Helper loaded: file_helper
INFO - 2021-07-17 17:31:53 --> Helper loaded: form_helper
INFO - 2021-07-17 17:31:53 --> Helper loaded: cookie_helper
INFO - 2021-07-17 17:31:53 --> Helper loaded: security_helper
INFO - 2021-07-17 17:31:53 --> Helper loaded: directory_helper
INFO - 2021-07-17 17:31:53 --> Helper loaded: language_helper
INFO - 2021-07-17 17:31:53 --> Helper loaded: general_helper
INFO - 2021-07-17 17:31:53 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 17:31:53 --> Database Driver Class Initialized
DEBUG - 2021-07-17 17:31:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 17:31:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 17:31:53 --> Parser Class Initialized
INFO - 2021-07-17 17:31:53 --> Form Validation Class Initialized
INFO - 2021-07-17 17:31:53 --> Upload Class Initialized
INFO - 2021-07-17 17:31:53 --> Email Class Initialized
INFO - 2021-07-17 17:31:53 --> MY_Model class loaded
INFO - 2021-07-17 17:31:53 --> Model "Users_model" initialized
INFO - 2021-07-17 17:31:53 --> Model "Settings_model" initialized
INFO - 2021-07-17 17:31:53 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 17:31:53 --> Model "Permissions_model" initialized
INFO - 2021-07-17 17:31:53 --> Model "Roles_model" initialized
INFO - 2021-07-17 17:31:53 --> Model "Activity_model" initialized
INFO - 2021-07-17 17:31:53 --> Model "Templates_model" initialized
INFO - 2021-07-17 17:31:53 --> Database Driver Class Initialized
INFO - 2021-07-17 17:31:53 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 17:31:53 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 17:31:53 --> Controller Class Initialized
ERROR - 2021-07-17 17:31:53 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 17:31:53 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 17:31:53 --> Config Class Initialized
INFO - 2021-07-17 17:31:53 --> Hooks Class Initialized
DEBUG - 2021-07-17 17:31:53 --> UTF-8 Support Enabled
INFO - 2021-07-17 17:31:53 --> Utf8 Class Initialized
INFO - 2021-07-17 17:31:53 --> URI Class Initialized
INFO - 2021-07-17 17:31:53 --> Router Class Initialized
INFO - 2021-07-17 17:31:53 --> Output Class Initialized
INFO - 2021-07-17 17:31:53 --> Security Class Initialized
DEBUG - 2021-07-17 17:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 17:31:53 --> Input Class Initialized
INFO - 2021-07-17 17:31:53 --> Language Class Initialized
INFO - 2021-07-17 17:31:53 --> Loader Class Initialized
INFO - 2021-07-17 17:31:53 --> Helper loaded: basic_helper
INFO - 2021-07-17 17:31:53 --> Helper loaded: url_helper
INFO - 2021-07-17 17:31:53 --> Helper loaded: file_helper
INFO - 2021-07-17 17:31:53 --> Helper loaded: form_helper
INFO - 2021-07-17 17:31:53 --> Helper loaded: cookie_helper
INFO - 2021-07-17 17:31:53 --> Helper loaded: security_helper
INFO - 2021-07-17 17:31:53 --> Helper loaded: directory_helper
INFO - 2021-07-17 17:31:53 --> Helper loaded: language_helper
INFO - 2021-07-17 17:31:53 --> Helper loaded: general_helper
INFO - 2021-07-17 17:31:53 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 17:31:53 --> Database Driver Class Initialized
DEBUG - 2021-07-17 17:31:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 17:31:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 17:31:53 --> Parser Class Initialized
INFO - 2021-07-17 17:31:53 --> Form Validation Class Initialized
INFO - 2021-07-17 17:31:53 --> Upload Class Initialized
INFO - 2021-07-17 17:31:53 --> Email Class Initialized
INFO - 2021-07-17 17:31:53 --> MY_Model class loaded
INFO - 2021-07-17 17:31:53 --> Model "Users_model" initialized
INFO - 2021-07-17 17:31:53 --> Model "Settings_model" initialized
INFO - 2021-07-17 17:31:53 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 17:31:53 --> Model "Permissions_model" initialized
INFO - 2021-07-17 17:31:53 --> Model "Roles_model" initialized
INFO - 2021-07-17 17:31:53 --> Model "Activity_model" initialized
INFO - 2021-07-17 17:31:53 --> Model "Templates_model" initialized
INFO - 2021-07-17 17:31:53 --> Database Driver Class Initialized
INFO - 2021-07-17 17:31:53 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 17:31:53 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 17:31:53 --> Controller Class Initialized
ERROR - 2021-07-17 17:31:53 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 17:31:53 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 17:31:53 --> Final output sent to browser
DEBUG - 2021-07-17 17:31:53 --> Total execution time: 0.0595
INFO - 2021-07-17 17:33:08 --> Config Class Initialized
INFO - 2021-07-17 17:33:08 --> Hooks Class Initialized
DEBUG - 2021-07-17 17:33:08 --> UTF-8 Support Enabled
INFO - 2021-07-17 17:33:08 --> Utf8 Class Initialized
INFO - 2021-07-17 17:33:08 --> URI Class Initialized
INFO - 2021-07-17 17:33:08 --> Router Class Initialized
INFO - 2021-07-17 17:33:08 --> Output Class Initialized
INFO - 2021-07-17 17:33:08 --> Security Class Initialized
DEBUG - 2021-07-17 17:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 17:33:08 --> Input Class Initialized
INFO - 2021-07-17 17:33:08 --> Language Class Initialized
INFO - 2021-07-17 17:33:08 --> Loader Class Initialized
INFO - 2021-07-17 17:33:08 --> Helper loaded: basic_helper
INFO - 2021-07-17 17:33:08 --> Helper loaded: url_helper
INFO - 2021-07-17 17:33:08 --> Helper loaded: file_helper
INFO - 2021-07-17 17:33:08 --> Helper loaded: form_helper
INFO - 2021-07-17 17:33:08 --> Helper loaded: cookie_helper
INFO - 2021-07-17 17:33:08 --> Helper loaded: security_helper
INFO - 2021-07-17 17:33:08 --> Helper loaded: directory_helper
INFO - 2021-07-17 17:33:08 --> Helper loaded: language_helper
INFO - 2021-07-17 17:33:08 --> Helper loaded: general_helper
INFO - 2021-07-17 17:33:08 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 17:33:08 --> Database Driver Class Initialized
DEBUG - 2021-07-17 17:33:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 17:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 17:33:08 --> Parser Class Initialized
INFO - 2021-07-17 17:33:08 --> Form Validation Class Initialized
INFO - 2021-07-17 17:33:08 --> Upload Class Initialized
INFO - 2021-07-17 17:33:08 --> Email Class Initialized
INFO - 2021-07-17 17:33:08 --> MY_Model class loaded
INFO - 2021-07-17 17:33:08 --> Model "Users_model" initialized
INFO - 2021-07-17 17:33:08 --> Model "Settings_model" initialized
INFO - 2021-07-17 17:33:08 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 17:33:08 --> Model "Permissions_model" initialized
INFO - 2021-07-17 17:33:08 --> Model "Roles_model" initialized
INFO - 2021-07-17 17:33:08 --> Model "Activity_model" initialized
INFO - 2021-07-17 17:33:08 --> Model "Templates_model" initialized
INFO - 2021-07-17 17:33:08 --> Database Driver Class Initialized
INFO - 2021-07-17 17:33:09 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 17:33:09 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 17:33:09 --> Controller Class Initialized
ERROR - 2021-07-17 17:33:09 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 17:33:09 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 17:33:09 --> Config Class Initialized
INFO - 2021-07-17 17:33:09 --> Hooks Class Initialized
DEBUG - 2021-07-17 17:33:09 --> UTF-8 Support Enabled
INFO - 2021-07-17 17:33:09 --> Utf8 Class Initialized
INFO - 2021-07-17 17:33:09 --> URI Class Initialized
INFO - 2021-07-17 17:33:09 --> Router Class Initialized
INFO - 2021-07-17 17:33:09 --> Output Class Initialized
INFO - 2021-07-17 17:33:09 --> Security Class Initialized
DEBUG - 2021-07-17 17:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 17:33:09 --> Input Class Initialized
INFO - 2021-07-17 17:33:09 --> Language Class Initialized
INFO - 2021-07-17 17:33:09 --> Loader Class Initialized
INFO - 2021-07-17 17:33:09 --> Helper loaded: basic_helper
INFO - 2021-07-17 17:33:09 --> Helper loaded: url_helper
INFO - 2021-07-17 17:33:09 --> Helper loaded: file_helper
INFO - 2021-07-17 17:33:09 --> Helper loaded: form_helper
INFO - 2021-07-17 17:33:09 --> Helper loaded: cookie_helper
INFO - 2021-07-17 17:33:09 --> Helper loaded: security_helper
INFO - 2021-07-17 17:33:09 --> Helper loaded: directory_helper
INFO - 2021-07-17 17:33:09 --> Helper loaded: language_helper
INFO - 2021-07-17 17:33:09 --> Helper loaded: general_helper
INFO - 2021-07-17 17:33:09 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 17:33:09 --> Database Driver Class Initialized
DEBUG - 2021-07-17 17:33:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 17:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 17:33:09 --> Parser Class Initialized
INFO - 2021-07-17 17:33:09 --> Form Validation Class Initialized
INFO - 2021-07-17 17:33:09 --> Upload Class Initialized
INFO - 2021-07-17 17:33:09 --> Email Class Initialized
INFO - 2021-07-17 17:33:09 --> MY_Model class loaded
INFO - 2021-07-17 17:33:09 --> Model "Users_model" initialized
INFO - 2021-07-17 17:33:09 --> Model "Settings_model" initialized
INFO - 2021-07-17 17:33:09 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 17:33:09 --> Model "Permissions_model" initialized
INFO - 2021-07-17 17:33:09 --> Model "Roles_model" initialized
INFO - 2021-07-17 17:33:09 --> Model "Activity_model" initialized
INFO - 2021-07-17 17:33:09 --> Model "Templates_model" initialized
INFO - 2021-07-17 17:33:09 --> Database Driver Class Initialized
INFO - 2021-07-17 17:33:09 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 17:33:09 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 17:33:09 --> Controller Class Initialized
ERROR - 2021-07-17 17:33:09 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 17:33:09 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 17:33:09 --> Final output sent to browser
DEBUG - 2021-07-17 17:33:09 --> Total execution time: 0.0755
INFO - 2021-07-17 17:33:53 --> Config Class Initialized
INFO - 2021-07-17 17:33:53 --> Hooks Class Initialized
DEBUG - 2021-07-17 17:33:53 --> UTF-8 Support Enabled
INFO - 2021-07-17 17:33:53 --> Utf8 Class Initialized
INFO - 2021-07-17 17:33:53 --> URI Class Initialized
INFO - 2021-07-17 17:33:53 --> Router Class Initialized
INFO - 2021-07-17 17:33:53 --> Output Class Initialized
INFO - 2021-07-17 17:33:53 --> Security Class Initialized
DEBUG - 2021-07-17 17:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 17:33:53 --> Input Class Initialized
INFO - 2021-07-17 17:33:53 --> Language Class Initialized
INFO - 2021-07-17 17:33:53 --> Loader Class Initialized
INFO - 2021-07-17 17:33:53 --> Helper loaded: basic_helper
INFO - 2021-07-17 17:33:53 --> Helper loaded: url_helper
INFO - 2021-07-17 17:33:53 --> Helper loaded: file_helper
INFO - 2021-07-17 17:33:53 --> Helper loaded: form_helper
INFO - 2021-07-17 17:33:53 --> Helper loaded: cookie_helper
INFO - 2021-07-17 17:33:53 --> Helper loaded: security_helper
INFO - 2021-07-17 17:33:53 --> Helper loaded: directory_helper
INFO - 2021-07-17 17:33:53 --> Helper loaded: language_helper
INFO - 2021-07-17 17:33:53 --> Helper loaded: general_helper
INFO - 2021-07-17 17:33:53 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 17:33:53 --> Database Driver Class Initialized
DEBUG - 2021-07-17 17:33:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 17:33:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 17:33:53 --> Parser Class Initialized
INFO - 2021-07-17 17:33:53 --> Form Validation Class Initialized
INFO - 2021-07-17 17:33:53 --> Upload Class Initialized
INFO - 2021-07-17 17:33:53 --> Email Class Initialized
INFO - 2021-07-17 17:33:53 --> MY_Model class loaded
INFO - 2021-07-17 17:33:53 --> Model "Users_model" initialized
INFO - 2021-07-17 17:33:53 --> Model "Settings_model" initialized
INFO - 2021-07-17 17:33:53 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 17:33:53 --> Model "Permissions_model" initialized
INFO - 2021-07-17 17:33:53 --> Model "Roles_model" initialized
INFO - 2021-07-17 17:33:53 --> Model "Activity_model" initialized
INFO - 2021-07-17 17:33:53 --> Model "Templates_model" initialized
INFO - 2021-07-17 17:33:53 --> Database Driver Class Initialized
INFO - 2021-07-17 17:33:53 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 17:33:53 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 17:33:53 --> Controller Class Initialized
ERROR - 2021-07-17 17:33:53 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 17:33:53 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 17:33:53 --> Final output sent to browser
DEBUG - 2021-07-17 17:33:53 --> Total execution time: 0.1362
INFO - 2021-07-17 17:35:16 --> Config Class Initialized
INFO - 2021-07-17 17:35:16 --> Hooks Class Initialized
DEBUG - 2021-07-17 17:35:16 --> UTF-8 Support Enabled
INFO - 2021-07-17 17:35:16 --> Utf8 Class Initialized
INFO - 2021-07-17 17:35:16 --> URI Class Initialized
INFO - 2021-07-17 17:35:16 --> Router Class Initialized
INFO - 2021-07-17 17:35:16 --> Output Class Initialized
INFO - 2021-07-17 17:35:16 --> Security Class Initialized
DEBUG - 2021-07-17 17:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 17:35:16 --> Input Class Initialized
INFO - 2021-07-17 17:35:16 --> Language Class Initialized
INFO - 2021-07-17 17:35:16 --> Loader Class Initialized
INFO - 2021-07-17 17:35:16 --> Helper loaded: basic_helper
INFO - 2021-07-17 17:35:16 --> Helper loaded: url_helper
INFO - 2021-07-17 17:35:16 --> Helper loaded: file_helper
INFO - 2021-07-17 17:35:16 --> Helper loaded: form_helper
INFO - 2021-07-17 17:35:16 --> Helper loaded: cookie_helper
INFO - 2021-07-17 17:35:16 --> Helper loaded: security_helper
INFO - 2021-07-17 17:35:16 --> Helper loaded: directory_helper
INFO - 2021-07-17 17:35:16 --> Helper loaded: language_helper
INFO - 2021-07-17 17:35:16 --> Helper loaded: general_helper
INFO - 2021-07-17 17:35:16 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 17:35:16 --> Database Driver Class Initialized
DEBUG - 2021-07-17 17:35:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 17:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 17:35:16 --> Parser Class Initialized
INFO - 2021-07-17 17:35:16 --> Form Validation Class Initialized
INFO - 2021-07-17 17:35:16 --> Upload Class Initialized
INFO - 2021-07-17 17:35:16 --> Email Class Initialized
INFO - 2021-07-17 17:35:16 --> MY_Model class loaded
INFO - 2021-07-17 17:35:16 --> Model "Users_model" initialized
INFO - 2021-07-17 17:35:16 --> Model "Settings_model" initialized
INFO - 2021-07-17 17:35:16 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 17:35:16 --> Model "Permissions_model" initialized
INFO - 2021-07-17 17:35:16 --> Model "Roles_model" initialized
INFO - 2021-07-17 17:35:16 --> Model "Activity_model" initialized
INFO - 2021-07-17 17:35:16 --> Model "Templates_model" initialized
INFO - 2021-07-17 17:35:16 --> Database Driver Class Initialized
INFO - 2021-07-17 17:35:17 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 17:35:17 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 17:35:17 --> Controller Class Initialized
ERROR - 2021-07-17 17:35:17 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 17:35:17 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 17:35:17 --> Final output sent to browser
DEBUG - 2021-07-17 17:35:17 --> Total execution time: 0.5404
INFO - 2021-07-17 17:35:24 --> Config Class Initialized
INFO - 2021-07-17 17:35:24 --> Hooks Class Initialized
DEBUG - 2021-07-17 17:35:24 --> UTF-8 Support Enabled
INFO - 2021-07-17 17:35:24 --> Utf8 Class Initialized
INFO - 2021-07-17 17:35:24 --> URI Class Initialized
INFO - 2021-07-17 17:35:24 --> Router Class Initialized
INFO - 2021-07-17 17:35:24 --> Output Class Initialized
INFO - 2021-07-17 17:35:24 --> Security Class Initialized
DEBUG - 2021-07-17 17:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 17:35:24 --> Input Class Initialized
INFO - 2021-07-17 17:35:24 --> Language Class Initialized
INFO - 2021-07-17 17:35:24 --> Loader Class Initialized
INFO - 2021-07-17 17:35:24 --> Helper loaded: basic_helper
INFO - 2021-07-17 17:35:24 --> Helper loaded: url_helper
INFO - 2021-07-17 17:35:24 --> Helper loaded: file_helper
INFO - 2021-07-17 17:35:24 --> Helper loaded: form_helper
INFO - 2021-07-17 17:35:24 --> Helper loaded: cookie_helper
INFO - 2021-07-17 17:35:24 --> Helper loaded: security_helper
INFO - 2021-07-17 17:35:24 --> Helper loaded: directory_helper
INFO - 2021-07-17 17:35:24 --> Helper loaded: language_helper
INFO - 2021-07-17 17:35:24 --> Helper loaded: general_helper
INFO - 2021-07-17 17:35:24 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 17:35:24 --> Database Driver Class Initialized
DEBUG - 2021-07-17 17:35:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 17:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 17:35:24 --> Parser Class Initialized
INFO - 2021-07-17 17:35:24 --> Form Validation Class Initialized
INFO - 2021-07-17 17:35:24 --> Upload Class Initialized
INFO - 2021-07-17 17:35:24 --> Email Class Initialized
INFO - 2021-07-17 17:35:24 --> MY_Model class loaded
INFO - 2021-07-17 17:35:24 --> Model "Users_model" initialized
INFO - 2021-07-17 17:35:24 --> Model "Settings_model" initialized
INFO - 2021-07-17 17:35:24 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 17:35:24 --> Model "Permissions_model" initialized
INFO - 2021-07-17 17:35:24 --> Model "Roles_model" initialized
INFO - 2021-07-17 17:35:24 --> Model "Activity_model" initialized
INFO - 2021-07-17 17:35:24 --> Model "Templates_model" initialized
INFO - 2021-07-17 17:35:24 --> Database Driver Class Initialized
INFO - 2021-07-17 17:35:25 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 17:35:25 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 17:35:25 --> Controller Class Initialized
ERROR - 2021-07-17 17:35:25 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 17:35:25 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 17:35:25 --> Config Class Initialized
INFO - 2021-07-17 17:35:25 --> Hooks Class Initialized
DEBUG - 2021-07-17 17:35:25 --> UTF-8 Support Enabled
INFO - 2021-07-17 17:35:25 --> Utf8 Class Initialized
INFO - 2021-07-17 17:35:25 --> URI Class Initialized
INFO - 2021-07-17 17:35:25 --> Router Class Initialized
INFO - 2021-07-17 17:35:25 --> Output Class Initialized
INFO - 2021-07-17 17:35:25 --> Security Class Initialized
DEBUG - 2021-07-17 17:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 17:35:25 --> Input Class Initialized
INFO - 2021-07-17 17:35:25 --> Language Class Initialized
INFO - 2021-07-17 17:35:25 --> Loader Class Initialized
INFO - 2021-07-17 17:35:25 --> Helper loaded: basic_helper
INFO - 2021-07-17 17:35:25 --> Helper loaded: url_helper
INFO - 2021-07-17 17:35:25 --> Helper loaded: file_helper
INFO - 2021-07-17 17:35:25 --> Helper loaded: form_helper
INFO - 2021-07-17 17:35:25 --> Helper loaded: cookie_helper
INFO - 2021-07-17 17:35:25 --> Helper loaded: security_helper
INFO - 2021-07-17 17:35:25 --> Helper loaded: directory_helper
INFO - 2021-07-17 17:35:25 --> Helper loaded: language_helper
INFO - 2021-07-17 17:35:25 --> Helper loaded: general_helper
INFO - 2021-07-17 17:35:25 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 17:35:25 --> Database Driver Class Initialized
DEBUG - 2021-07-17 17:35:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 17:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 17:35:25 --> Parser Class Initialized
INFO - 2021-07-17 17:35:25 --> Form Validation Class Initialized
INFO - 2021-07-17 17:35:25 --> Upload Class Initialized
INFO - 2021-07-17 17:35:25 --> Email Class Initialized
INFO - 2021-07-17 17:35:25 --> MY_Model class loaded
INFO - 2021-07-17 17:35:25 --> Model "Users_model" initialized
INFO - 2021-07-17 17:35:25 --> Model "Settings_model" initialized
INFO - 2021-07-17 17:35:25 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 17:35:25 --> Model "Permissions_model" initialized
INFO - 2021-07-17 17:35:25 --> Model "Roles_model" initialized
INFO - 2021-07-17 17:35:25 --> Model "Activity_model" initialized
INFO - 2021-07-17 17:35:25 --> Model "Templates_model" initialized
INFO - 2021-07-17 17:35:25 --> Database Driver Class Initialized
INFO - 2021-07-17 17:35:25 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 17:35:25 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 17:35:25 --> Controller Class Initialized
ERROR - 2021-07-17 17:35:25 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 17:35:25 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 17:35:25 --> Final output sent to browser
DEBUG - 2021-07-17 17:35:25 --> Total execution time: 0.0705
INFO - 2021-07-17 17:35:45 --> Config Class Initialized
INFO - 2021-07-17 17:35:45 --> Hooks Class Initialized
DEBUG - 2021-07-17 17:35:45 --> UTF-8 Support Enabled
INFO - 2021-07-17 17:35:45 --> Utf8 Class Initialized
INFO - 2021-07-17 17:35:45 --> URI Class Initialized
INFO - 2021-07-17 17:35:46 --> Router Class Initialized
INFO - 2021-07-17 17:35:46 --> Output Class Initialized
INFO - 2021-07-17 17:35:46 --> Security Class Initialized
DEBUG - 2021-07-17 17:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 17:35:46 --> Input Class Initialized
INFO - 2021-07-17 17:35:46 --> Language Class Initialized
INFO - 2021-07-17 17:35:46 --> Loader Class Initialized
INFO - 2021-07-17 17:35:46 --> Helper loaded: basic_helper
INFO - 2021-07-17 17:35:46 --> Helper loaded: url_helper
INFO - 2021-07-17 17:35:46 --> Helper loaded: file_helper
INFO - 2021-07-17 17:35:46 --> Helper loaded: form_helper
INFO - 2021-07-17 17:35:46 --> Helper loaded: cookie_helper
INFO - 2021-07-17 17:35:46 --> Helper loaded: security_helper
INFO - 2021-07-17 17:35:46 --> Helper loaded: directory_helper
INFO - 2021-07-17 17:35:46 --> Helper loaded: language_helper
INFO - 2021-07-17 17:35:46 --> Helper loaded: general_helper
INFO - 2021-07-17 17:35:46 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 17:35:46 --> Database Driver Class Initialized
DEBUG - 2021-07-17 17:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 17:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 17:35:46 --> Parser Class Initialized
INFO - 2021-07-17 17:35:46 --> Form Validation Class Initialized
INFO - 2021-07-17 17:35:46 --> Upload Class Initialized
INFO - 2021-07-17 17:35:46 --> Email Class Initialized
INFO - 2021-07-17 17:35:46 --> MY_Model class loaded
INFO - 2021-07-17 17:35:46 --> Model "Users_model" initialized
INFO - 2021-07-17 17:35:46 --> Model "Settings_model" initialized
INFO - 2021-07-17 17:35:46 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 17:35:46 --> Model "Permissions_model" initialized
INFO - 2021-07-17 17:35:46 --> Model "Roles_model" initialized
INFO - 2021-07-17 17:35:46 --> Model "Activity_model" initialized
INFO - 2021-07-17 17:35:46 --> Model "Templates_model" initialized
INFO - 2021-07-17 17:35:46 --> Database Driver Class Initialized
INFO - 2021-07-17 17:35:46 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 17:35:46 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 17:35:46 --> Controller Class Initialized
ERROR - 2021-07-17 17:35:46 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 17:35:46 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 17:35:46 --> Config Class Initialized
INFO - 2021-07-17 17:35:46 --> Hooks Class Initialized
DEBUG - 2021-07-17 17:35:46 --> UTF-8 Support Enabled
INFO - 2021-07-17 17:35:46 --> Utf8 Class Initialized
INFO - 2021-07-17 17:35:46 --> URI Class Initialized
INFO - 2021-07-17 17:35:46 --> Router Class Initialized
INFO - 2021-07-17 17:35:46 --> Output Class Initialized
INFO - 2021-07-17 17:35:46 --> Security Class Initialized
DEBUG - 2021-07-17 17:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 17:35:46 --> Input Class Initialized
INFO - 2021-07-17 17:35:46 --> Language Class Initialized
INFO - 2021-07-17 17:35:46 --> Loader Class Initialized
INFO - 2021-07-17 17:35:46 --> Helper loaded: basic_helper
INFO - 2021-07-17 17:35:46 --> Helper loaded: url_helper
INFO - 2021-07-17 17:35:46 --> Helper loaded: file_helper
INFO - 2021-07-17 17:35:46 --> Helper loaded: form_helper
INFO - 2021-07-17 17:35:46 --> Helper loaded: cookie_helper
INFO - 2021-07-17 17:35:46 --> Helper loaded: security_helper
INFO - 2021-07-17 17:35:46 --> Helper loaded: directory_helper
INFO - 2021-07-17 17:35:46 --> Helper loaded: language_helper
INFO - 2021-07-17 17:35:46 --> Helper loaded: general_helper
INFO - 2021-07-17 17:35:46 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 17:35:46 --> Database Driver Class Initialized
DEBUG - 2021-07-17 17:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 17:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 17:35:46 --> Parser Class Initialized
INFO - 2021-07-17 17:35:46 --> Form Validation Class Initialized
INFO - 2021-07-17 17:35:46 --> Upload Class Initialized
INFO - 2021-07-17 17:35:46 --> Email Class Initialized
INFO - 2021-07-17 17:35:46 --> MY_Model class loaded
INFO - 2021-07-17 17:35:46 --> Model "Users_model" initialized
INFO - 2021-07-17 17:35:46 --> Model "Settings_model" initialized
INFO - 2021-07-17 17:35:46 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 17:35:46 --> Model "Permissions_model" initialized
INFO - 2021-07-17 17:35:46 --> Model "Roles_model" initialized
INFO - 2021-07-17 17:35:46 --> Model "Activity_model" initialized
INFO - 2021-07-17 17:35:46 --> Model "Templates_model" initialized
INFO - 2021-07-17 17:35:46 --> Database Driver Class Initialized
INFO - 2021-07-17 17:35:46 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 17:35:46 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 17:35:46 --> Controller Class Initialized
ERROR - 2021-07-17 17:35:46 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 17:35:46 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 17:35:46 --> Final output sent to browser
DEBUG - 2021-07-17 17:35:46 --> Total execution time: 0.0593
INFO - 2021-07-17 17:38:40 --> Config Class Initialized
INFO - 2021-07-17 17:38:40 --> Hooks Class Initialized
DEBUG - 2021-07-17 17:38:40 --> UTF-8 Support Enabled
INFO - 2021-07-17 17:38:40 --> Utf8 Class Initialized
INFO - 2021-07-17 17:38:40 --> URI Class Initialized
INFO - 2021-07-17 17:38:40 --> Router Class Initialized
INFO - 2021-07-17 17:38:40 --> Output Class Initialized
INFO - 2021-07-17 17:38:40 --> Security Class Initialized
DEBUG - 2021-07-17 17:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 17:38:40 --> Input Class Initialized
INFO - 2021-07-17 17:38:40 --> Language Class Initialized
INFO - 2021-07-17 17:38:40 --> Loader Class Initialized
INFO - 2021-07-17 17:38:40 --> Helper loaded: basic_helper
INFO - 2021-07-17 17:38:40 --> Helper loaded: url_helper
INFO - 2021-07-17 17:38:40 --> Helper loaded: file_helper
INFO - 2021-07-17 17:38:40 --> Helper loaded: form_helper
INFO - 2021-07-17 17:38:40 --> Helper loaded: cookie_helper
INFO - 2021-07-17 17:38:40 --> Helper loaded: security_helper
INFO - 2021-07-17 17:38:40 --> Helper loaded: directory_helper
INFO - 2021-07-17 17:38:40 --> Helper loaded: language_helper
INFO - 2021-07-17 17:38:40 --> Helper loaded: general_helper
INFO - 2021-07-17 17:38:40 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 17:38:40 --> Database Driver Class Initialized
DEBUG - 2021-07-17 17:38:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 17:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 17:38:40 --> Parser Class Initialized
INFO - 2021-07-17 17:38:40 --> Form Validation Class Initialized
INFO - 2021-07-17 17:38:40 --> Upload Class Initialized
INFO - 2021-07-17 17:38:40 --> Email Class Initialized
INFO - 2021-07-17 17:38:40 --> MY_Model class loaded
INFO - 2021-07-17 17:38:40 --> Model "Users_model" initialized
INFO - 2021-07-17 17:38:40 --> Model "Settings_model" initialized
INFO - 2021-07-17 17:38:40 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 17:38:40 --> Model "Permissions_model" initialized
INFO - 2021-07-17 17:38:40 --> Model "Roles_model" initialized
INFO - 2021-07-17 17:38:40 --> Model "Activity_model" initialized
INFO - 2021-07-17 17:38:40 --> Model "Templates_model" initialized
INFO - 2021-07-17 17:38:40 --> Database Driver Class Initialized
INFO - 2021-07-17 17:38:40 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 17:38:40 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 17:38:40 --> Controller Class Initialized
ERROR - 2021-07-17 17:38:40 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 17:38:40 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 17:38:40 --> Final output sent to browser
DEBUG - 2021-07-17 17:38:40 --> Total execution time: 0.6304
INFO - 2021-07-17 17:39:04 --> Config Class Initialized
INFO - 2021-07-17 17:39:04 --> Hooks Class Initialized
DEBUG - 2021-07-17 17:39:04 --> UTF-8 Support Enabled
INFO - 2021-07-17 17:39:04 --> Utf8 Class Initialized
INFO - 2021-07-17 17:39:04 --> URI Class Initialized
INFO - 2021-07-17 17:39:04 --> Router Class Initialized
INFO - 2021-07-17 17:39:04 --> Output Class Initialized
INFO - 2021-07-17 17:39:04 --> Security Class Initialized
DEBUG - 2021-07-17 17:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 17:39:04 --> Input Class Initialized
INFO - 2021-07-17 17:39:04 --> Language Class Initialized
INFO - 2021-07-17 17:39:04 --> Loader Class Initialized
INFO - 2021-07-17 17:39:04 --> Helper loaded: basic_helper
INFO - 2021-07-17 17:39:04 --> Helper loaded: url_helper
INFO - 2021-07-17 17:39:04 --> Helper loaded: file_helper
INFO - 2021-07-17 17:39:04 --> Helper loaded: form_helper
INFO - 2021-07-17 17:39:04 --> Helper loaded: cookie_helper
INFO - 2021-07-17 17:39:04 --> Helper loaded: security_helper
INFO - 2021-07-17 17:39:04 --> Helper loaded: directory_helper
INFO - 2021-07-17 17:39:04 --> Helper loaded: language_helper
INFO - 2021-07-17 17:39:04 --> Helper loaded: general_helper
INFO - 2021-07-17 17:39:04 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 17:39:04 --> Database Driver Class Initialized
DEBUG - 2021-07-17 17:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 17:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 17:39:04 --> Parser Class Initialized
INFO - 2021-07-17 17:39:04 --> Form Validation Class Initialized
INFO - 2021-07-17 17:39:04 --> Upload Class Initialized
INFO - 2021-07-17 17:39:04 --> Email Class Initialized
INFO - 2021-07-17 17:39:04 --> MY_Model class loaded
INFO - 2021-07-17 17:39:04 --> Model "Users_model" initialized
INFO - 2021-07-17 17:39:04 --> Model "Settings_model" initialized
INFO - 2021-07-17 17:39:04 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 17:39:04 --> Model "Permissions_model" initialized
INFO - 2021-07-17 17:39:04 --> Model "Roles_model" initialized
INFO - 2021-07-17 17:39:04 --> Model "Activity_model" initialized
INFO - 2021-07-17 17:39:04 --> Model "Templates_model" initialized
INFO - 2021-07-17 17:39:04 --> Database Driver Class Initialized
INFO - 2021-07-17 17:39:04 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 17:39:04 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 17:39:04 --> Controller Class Initialized
ERROR - 2021-07-17 17:39:04 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 17:39:04 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 17:39:04 --> Config Class Initialized
INFO - 2021-07-17 17:39:04 --> Hooks Class Initialized
DEBUG - 2021-07-17 17:39:04 --> UTF-8 Support Enabled
INFO - 2021-07-17 17:39:04 --> Utf8 Class Initialized
INFO - 2021-07-17 17:39:04 --> URI Class Initialized
INFO - 2021-07-17 17:39:04 --> Router Class Initialized
INFO - 2021-07-17 17:39:04 --> Output Class Initialized
INFO - 2021-07-17 17:39:04 --> Security Class Initialized
DEBUG - 2021-07-17 17:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 17:39:04 --> Input Class Initialized
INFO - 2021-07-17 17:39:04 --> Language Class Initialized
INFO - 2021-07-17 17:39:04 --> Loader Class Initialized
INFO - 2021-07-17 17:39:04 --> Helper loaded: basic_helper
INFO - 2021-07-17 17:39:04 --> Helper loaded: url_helper
INFO - 2021-07-17 17:39:04 --> Helper loaded: file_helper
INFO - 2021-07-17 17:39:04 --> Helper loaded: form_helper
INFO - 2021-07-17 17:39:04 --> Helper loaded: cookie_helper
INFO - 2021-07-17 17:39:04 --> Helper loaded: security_helper
INFO - 2021-07-17 17:39:04 --> Helper loaded: directory_helper
INFO - 2021-07-17 17:39:04 --> Helper loaded: language_helper
INFO - 2021-07-17 17:39:04 --> Helper loaded: general_helper
INFO - 2021-07-17 17:39:04 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 17:39:04 --> Database Driver Class Initialized
DEBUG - 2021-07-17 17:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 17:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 17:39:04 --> Parser Class Initialized
INFO - 2021-07-17 17:39:04 --> Form Validation Class Initialized
INFO - 2021-07-17 17:39:04 --> Upload Class Initialized
INFO - 2021-07-17 17:39:04 --> Email Class Initialized
INFO - 2021-07-17 17:39:04 --> MY_Model class loaded
INFO - 2021-07-17 17:39:04 --> Model "Users_model" initialized
INFO - 2021-07-17 17:39:04 --> Model "Settings_model" initialized
INFO - 2021-07-17 17:39:04 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 17:39:04 --> Model "Permissions_model" initialized
INFO - 2021-07-17 17:39:04 --> Model "Roles_model" initialized
INFO - 2021-07-17 17:39:04 --> Model "Activity_model" initialized
INFO - 2021-07-17 17:39:04 --> Model "Templates_model" initialized
INFO - 2021-07-17 17:39:04 --> Database Driver Class Initialized
INFO - 2021-07-17 17:39:04 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 17:39:04 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 17:39:04 --> Controller Class Initialized
ERROR - 2021-07-17 17:39:04 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 17:39:04 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 17:39:04 --> Final output sent to browser
DEBUG - 2021-07-17 17:39:04 --> Total execution time: 0.0797
INFO - 2021-07-17 17:39:08 --> Config Class Initialized
INFO - 2021-07-17 17:39:08 --> Hooks Class Initialized
DEBUG - 2021-07-17 17:39:08 --> UTF-8 Support Enabled
INFO - 2021-07-17 17:39:08 --> Utf8 Class Initialized
INFO - 2021-07-17 17:39:08 --> URI Class Initialized
INFO - 2021-07-17 17:39:08 --> Router Class Initialized
INFO - 2021-07-17 17:39:08 --> Output Class Initialized
INFO - 2021-07-17 17:39:08 --> Security Class Initialized
DEBUG - 2021-07-17 17:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 17:39:08 --> Input Class Initialized
INFO - 2021-07-17 17:39:08 --> Language Class Initialized
INFO - 2021-07-17 17:39:08 --> Loader Class Initialized
INFO - 2021-07-17 17:39:08 --> Helper loaded: basic_helper
INFO - 2021-07-17 17:39:08 --> Helper loaded: url_helper
INFO - 2021-07-17 17:39:08 --> Helper loaded: file_helper
INFO - 2021-07-17 17:39:08 --> Helper loaded: form_helper
INFO - 2021-07-17 17:39:08 --> Helper loaded: cookie_helper
INFO - 2021-07-17 17:39:08 --> Helper loaded: security_helper
INFO - 2021-07-17 17:39:08 --> Helper loaded: directory_helper
INFO - 2021-07-17 17:39:08 --> Helper loaded: language_helper
INFO - 2021-07-17 17:39:08 --> Helper loaded: general_helper
INFO - 2021-07-17 17:39:08 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 17:39:08 --> Database Driver Class Initialized
DEBUG - 2021-07-17 17:39:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 17:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 17:39:08 --> Parser Class Initialized
INFO - 2021-07-17 17:39:08 --> Form Validation Class Initialized
INFO - 2021-07-17 17:39:08 --> Upload Class Initialized
INFO - 2021-07-17 17:39:08 --> Email Class Initialized
INFO - 2021-07-17 17:39:08 --> MY_Model class loaded
INFO - 2021-07-17 17:39:08 --> Model "Users_model" initialized
INFO - 2021-07-17 17:39:08 --> Model "Settings_model" initialized
INFO - 2021-07-17 17:39:08 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 17:39:08 --> Model "Permissions_model" initialized
INFO - 2021-07-17 17:39:08 --> Model "Roles_model" initialized
INFO - 2021-07-17 17:39:08 --> Model "Activity_model" initialized
INFO - 2021-07-17 17:39:08 --> Model "Templates_model" initialized
INFO - 2021-07-17 17:39:08 --> Database Driver Class Initialized
INFO - 2021-07-17 17:39:08 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 17:39:08 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 17:39:08 --> Controller Class Initialized
ERROR - 2021-07-17 17:39:08 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 17:39:08 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 17:39:08 --> Config Class Initialized
INFO - 2021-07-17 17:39:08 --> Hooks Class Initialized
DEBUG - 2021-07-17 17:39:08 --> UTF-8 Support Enabled
INFO - 2021-07-17 17:39:08 --> Utf8 Class Initialized
INFO - 2021-07-17 17:39:08 --> URI Class Initialized
INFO - 2021-07-17 17:39:08 --> Router Class Initialized
INFO - 2021-07-17 17:39:08 --> Output Class Initialized
INFO - 2021-07-17 17:39:08 --> Security Class Initialized
DEBUG - 2021-07-17 17:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 17:39:08 --> Input Class Initialized
INFO - 2021-07-17 17:39:08 --> Language Class Initialized
INFO - 2021-07-17 17:39:08 --> Loader Class Initialized
INFO - 2021-07-17 17:39:08 --> Helper loaded: basic_helper
INFO - 2021-07-17 17:39:08 --> Helper loaded: url_helper
INFO - 2021-07-17 17:39:08 --> Helper loaded: file_helper
INFO - 2021-07-17 17:39:08 --> Helper loaded: form_helper
INFO - 2021-07-17 17:39:08 --> Helper loaded: cookie_helper
INFO - 2021-07-17 17:39:08 --> Helper loaded: security_helper
INFO - 2021-07-17 17:39:08 --> Helper loaded: directory_helper
INFO - 2021-07-17 17:39:08 --> Helper loaded: language_helper
INFO - 2021-07-17 17:39:08 --> Helper loaded: general_helper
INFO - 2021-07-17 17:39:08 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 17:39:08 --> Database Driver Class Initialized
DEBUG - 2021-07-17 17:39:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 17:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 17:39:08 --> Parser Class Initialized
INFO - 2021-07-17 17:39:08 --> Form Validation Class Initialized
INFO - 2021-07-17 17:39:08 --> Upload Class Initialized
INFO - 2021-07-17 17:39:08 --> Email Class Initialized
INFO - 2021-07-17 17:39:08 --> MY_Model class loaded
INFO - 2021-07-17 17:39:08 --> Model "Users_model" initialized
INFO - 2021-07-17 17:39:08 --> Model "Settings_model" initialized
INFO - 2021-07-17 17:39:08 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 17:39:08 --> Model "Permissions_model" initialized
INFO - 2021-07-17 17:39:08 --> Model "Roles_model" initialized
INFO - 2021-07-17 17:39:08 --> Model "Activity_model" initialized
INFO - 2021-07-17 17:39:08 --> Model "Templates_model" initialized
INFO - 2021-07-17 17:39:08 --> Database Driver Class Initialized
INFO - 2021-07-17 17:39:08 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 17:39:08 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 17:39:08 --> Controller Class Initialized
ERROR - 2021-07-17 17:39:08 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 17:39:08 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 17:39:08 --> Final output sent to browser
DEBUG - 2021-07-17 17:39:08 --> Total execution time: 0.0603
INFO - 2021-07-17 17:39:11 --> Config Class Initialized
INFO - 2021-07-17 17:39:11 --> Hooks Class Initialized
DEBUG - 2021-07-17 17:39:11 --> UTF-8 Support Enabled
INFO - 2021-07-17 17:39:11 --> Utf8 Class Initialized
INFO - 2021-07-17 17:39:11 --> URI Class Initialized
INFO - 2021-07-17 17:39:11 --> Router Class Initialized
INFO - 2021-07-17 17:39:11 --> Output Class Initialized
INFO - 2021-07-17 17:39:11 --> Security Class Initialized
DEBUG - 2021-07-17 17:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 17:39:11 --> Input Class Initialized
INFO - 2021-07-17 17:39:11 --> Language Class Initialized
INFO - 2021-07-17 17:39:11 --> Loader Class Initialized
INFO - 2021-07-17 17:39:11 --> Helper loaded: basic_helper
INFO - 2021-07-17 17:39:11 --> Helper loaded: url_helper
INFO - 2021-07-17 17:39:11 --> Helper loaded: file_helper
INFO - 2021-07-17 17:39:11 --> Helper loaded: form_helper
INFO - 2021-07-17 17:39:11 --> Helper loaded: cookie_helper
INFO - 2021-07-17 17:39:11 --> Helper loaded: security_helper
INFO - 2021-07-17 17:39:11 --> Helper loaded: directory_helper
INFO - 2021-07-17 17:39:11 --> Helper loaded: language_helper
INFO - 2021-07-17 17:39:11 --> Helper loaded: general_helper
INFO - 2021-07-17 17:39:11 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 17:39:11 --> Database Driver Class Initialized
DEBUG - 2021-07-17 17:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 17:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 17:39:11 --> Parser Class Initialized
INFO - 2021-07-17 17:39:11 --> Form Validation Class Initialized
INFO - 2021-07-17 17:39:11 --> Upload Class Initialized
INFO - 2021-07-17 17:39:11 --> Email Class Initialized
INFO - 2021-07-17 17:39:11 --> MY_Model class loaded
INFO - 2021-07-17 17:39:11 --> Model "Users_model" initialized
INFO - 2021-07-17 17:39:11 --> Model "Settings_model" initialized
INFO - 2021-07-17 17:39:11 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 17:39:11 --> Model "Permissions_model" initialized
INFO - 2021-07-17 17:39:11 --> Model "Roles_model" initialized
INFO - 2021-07-17 17:39:11 --> Model "Activity_model" initialized
INFO - 2021-07-17 17:39:11 --> Model "Templates_model" initialized
INFO - 2021-07-17 17:39:11 --> Database Driver Class Initialized
INFO - 2021-07-17 17:39:11 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 17:39:11 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 17:39:11 --> Controller Class Initialized
ERROR - 2021-07-17 17:39:11 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 17:39:11 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 17:39:11 --> Config Class Initialized
INFO - 2021-07-17 17:39:11 --> Hooks Class Initialized
DEBUG - 2021-07-17 17:39:11 --> UTF-8 Support Enabled
INFO - 2021-07-17 17:39:11 --> Utf8 Class Initialized
INFO - 2021-07-17 17:39:11 --> URI Class Initialized
INFO - 2021-07-17 17:39:11 --> Router Class Initialized
INFO - 2021-07-17 17:39:11 --> Output Class Initialized
INFO - 2021-07-17 17:39:11 --> Security Class Initialized
DEBUG - 2021-07-17 17:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 17:39:11 --> Input Class Initialized
INFO - 2021-07-17 17:39:11 --> Language Class Initialized
INFO - 2021-07-17 17:39:11 --> Loader Class Initialized
INFO - 2021-07-17 17:39:11 --> Helper loaded: basic_helper
INFO - 2021-07-17 17:39:11 --> Helper loaded: url_helper
INFO - 2021-07-17 17:39:11 --> Helper loaded: file_helper
INFO - 2021-07-17 17:39:11 --> Helper loaded: form_helper
INFO - 2021-07-17 17:39:11 --> Helper loaded: cookie_helper
INFO - 2021-07-17 17:39:11 --> Helper loaded: security_helper
INFO - 2021-07-17 17:39:11 --> Helper loaded: directory_helper
INFO - 2021-07-17 17:39:11 --> Helper loaded: language_helper
INFO - 2021-07-17 17:39:11 --> Helper loaded: general_helper
INFO - 2021-07-17 17:39:11 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 17:39:11 --> Database Driver Class Initialized
DEBUG - 2021-07-17 17:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 17:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 17:39:11 --> Parser Class Initialized
INFO - 2021-07-17 17:39:11 --> Form Validation Class Initialized
INFO - 2021-07-17 17:39:11 --> Upload Class Initialized
INFO - 2021-07-17 17:39:11 --> Email Class Initialized
INFO - 2021-07-17 17:39:11 --> MY_Model class loaded
INFO - 2021-07-17 17:39:11 --> Model "Users_model" initialized
INFO - 2021-07-17 17:39:11 --> Model "Settings_model" initialized
INFO - 2021-07-17 17:39:11 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 17:39:11 --> Model "Permissions_model" initialized
INFO - 2021-07-17 17:39:11 --> Model "Roles_model" initialized
INFO - 2021-07-17 17:39:11 --> Model "Activity_model" initialized
INFO - 2021-07-17 17:39:11 --> Model "Templates_model" initialized
INFO - 2021-07-17 17:39:11 --> Database Driver Class Initialized
INFO - 2021-07-17 17:39:11 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 17:39:11 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 17:39:11 --> Controller Class Initialized
ERROR - 2021-07-17 17:39:11 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 17:39:11 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 17:39:11 --> Final output sent to browser
DEBUG - 2021-07-17 17:39:11 --> Total execution time: 0.0592
INFO - 2021-07-17 17:43:21 --> Config Class Initialized
INFO - 2021-07-17 17:43:21 --> Hooks Class Initialized
DEBUG - 2021-07-17 17:43:21 --> UTF-8 Support Enabled
INFO - 2021-07-17 17:43:21 --> Utf8 Class Initialized
INFO - 2021-07-17 17:43:21 --> URI Class Initialized
INFO - 2021-07-17 17:43:21 --> Router Class Initialized
INFO - 2021-07-17 17:43:21 --> Output Class Initialized
INFO - 2021-07-17 17:43:21 --> Security Class Initialized
DEBUG - 2021-07-17 17:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 17:43:21 --> Input Class Initialized
INFO - 2021-07-17 17:43:21 --> Language Class Initialized
INFO - 2021-07-17 17:43:21 --> Loader Class Initialized
INFO - 2021-07-17 17:43:21 --> Helper loaded: basic_helper
INFO - 2021-07-17 17:43:21 --> Helper loaded: url_helper
INFO - 2021-07-17 17:43:21 --> Helper loaded: file_helper
INFO - 2021-07-17 17:43:21 --> Helper loaded: form_helper
INFO - 2021-07-17 17:43:21 --> Helper loaded: cookie_helper
INFO - 2021-07-17 17:43:21 --> Helper loaded: security_helper
INFO - 2021-07-17 17:43:21 --> Helper loaded: directory_helper
INFO - 2021-07-17 17:43:21 --> Helper loaded: language_helper
INFO - 2021-07-17 17:43:21 --> Helper loaded: general_helper
INFO - 2021-07-17 17:43:21 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 17:43:21 --> Database Driver Class Initialized
DEBUG - 2021-07-17 17:43:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 17:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 17:43:21 --> Parser Class Initialized
INFO - 2021-07-17 17:43:21 --> Form Validation Class Initialized
INFO - 2021-07-17 17:43:21 --> Upload Class Initialized
INFO - 2021-07-17 17:43:21 --> Email Class Initialized
INFO - 2021-07-17 17:43:21 --> MY_Model class loaded
INFO - 2021-07-17 17:43:21 --> Model "Users_model" initialized
INFO - 2021-07-17 17:43:21 --> Model "Settings_model" initialized
INFO - 2021-07-17 17:43:21 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 17:43:21 --> Model "Permissions_model" initialized
INFO - 2021-07-17 17:43:21 --> Model "Roles_model" initialized
INFO - 2021-07-17 17:43:21 --> Model "Activity_model" initialized
INFO - 2021-07-17 17:43:21 --> Model "Templates_model" initialized
INFO - 2021-07-17 17:43:21 --> Database Driver Class Initialized
INFO - 2021-07-17 17:43:21 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 17:43:21 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 17:43:21 --> Controller Class Initialized
ERROR - 2021-07-17 17:43:21 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 17:43:21 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 17:43:21 --> Final output sent to browser
DEBUG - 2021-07-17 17:43:21 --> Total execution time: 0.1243
INFO - 2021-07-17 17:43:23 --> Config Class Initialized
INFO - 2021-07-17 17:43:23 --> Hooks Class Initialized
DEBUG - 2021-07-17 17:43:23 --> UTF-8 Support Enabled
INFO - 2021-07-17 17:43:23 --> Utf8 Class Initialized
INFO - 2021-07-17 17:43:23 --> URI Class Initialized
INFO - 2021-07-17 17:43:23 --> Router Class Initialized
INFO - 2021-07-17 17:43:23 --> Output Class Initialized
INFO - 2021-07-17 17:43:23 --> Security Class Initialized
DEBUG - 2021-07-17 17:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 17:43:23 --> Input Class Initialized
INFO - 2021-07-17 17:43:23 --> Language Class Initialized
INFO - 2021-07-17 17:43:23 --> Loader Class Initialized
INFO - 2021-07-17 17:43:23 --> Helper loaded: basic_helper
INFO - 2021-07-17 17:43:23 --> Helper loaded: url_helper
INFO - 2021-07-17 17:43:23 --> Helper loaded: file_helper
INFO - 2021-07-17 17:43:23 --> Helper loaded: form_helper
INFO - 2021-07-17 17:43:23 --> Helper loaded: cookie_helper
INFO - 2021-07-17 17:43:23 --> Helper loaded: security_helper
INFO - 2021-07-17 17:43:23 --> Helper loaded: directory_helper
INFO - 2021-07-17 17:43:23 --> Helper loaded: language_helper
INFO - 2021-07-17 17:43:23 --> Helper loaded: general_helper
INFO - 2021-07-17 17:43:23 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 17:43:23 --> Database Driver Class Initialized
DEBUG - 2021-07-17 17:43:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 17:43:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 17:43:23 --> Parser Class Initialized
INFO - 2021-07-17 17:43:23 --> Form Validation Class Initialized
INFO - 2021-07-17 17:43:23 --> Upload Class Initialized
INFO - 2021-07-17 17:43:23 --> Email Class Initialized
INFO - 2021-07-17 17:43:23 --> MY_Model class loaded
INFO - 2021-07-17 17:43:23 --> Model "Users_model" initialized
INFO - 2021-07-17 17:43:23 --> Model "Settings_model" initialized
INFO - 2021-07-17 17:43:23 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 17:43:23 --> Model "Permissions_model" initialized
INFO - 2021-07-17 17:43:23 --> Model "Roles_model" initialized
INFO - 2021-07-17 17:43:23 --> Model "Activity_model" initialized
INFO - 2021-07-17 17:43:23 --> Model "Templates_model" initialized
INFO - 2021-07-17 17:43:23 --> Database Driver Class Initialized
INFO - 2021-07-17 17:43:23 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 17:43:23 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 17:43:23 --> Controller Class Initialized
ERROR - 2021-07-17 17:43:23 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 17:43:23 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 17:43:23 --> Final output sent to browser
DEBUG - 2021-07-17 17:43:23 --> Total execution time: 0.0636
INFO - 2021-07-17 17:43:47 --> Config Class Initialized
INFO - 2021-07-17 17:43:47 --> Hooks Class Initialized
DEBUG - 2021-07-17 17:43:47 --> UTF-8 Support Enabled
INFO - 2021-07-17 17:43:47 --> Utf8 Class Initialized
INFO - 2021-07-17 17:43:47 --> URI Class Initialized
INFO - 2021-07-17 17:43:47 --> Router Class Initialized
INFO - 2021-07-17 17:43:47 --> Output Class Initialized
INFO - 2021-07-17 17:43:47 --> Security Class Initialized
DEBUG - 2021-07-17 17:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 17:43:47 --> Input Class Initialized
INFO - 2021-07-17 17:43:47 --> Language Class Initialized
INFO - 2021-07-17 17:43:47 --> Loader Class Initialized
INFO - 2021-07-17 17:43:47 --> Helper loaded: basic_helper
INFO - 2021-07-17 17:43:47 --> Helper loaded: url_helper
INFO - 2021-07-17 17:43:47 --> Helper loaded: file_helper
INFO - 2021-07-17 17:43:47 --> Helper loaded: form_helper
INFO - 2021-07-17 17:43:47 --> Helper loaded: cookie_helper
INFO - 2021-07-17 17:43:47 --> Helper loaded: security_helper
INFO - 2021-07-17 17:43:47 --> Helper loaded: directory_helper
INFO - 2021-07-17 17:43:47 --> Helper loaded: language_helper
INFO - 2021-07-17 17:43:47 --> Helper loaded: general_helper
INFO - 2021-07-17 17:43:47 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 17:43:47 --> Database Driver Class Initialized
DEBUG - 2021-07-17 17:43:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 17:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 17:43:47 --> Parser Class Initialized
INFO - 2021-07-17 17:43:47 --> Form Validation Class Initialized
INFO - 2021-07-17 17:43:47 --> Upload Class Initialized
INFO - 2021-07-17 17:43:47 --> Email Class Initialized
INFO - 2021-07-17 17:43:47 --> MY_Model class loaded
INFO - 2021-07-17 17:43:47 --> Model "Users_model" initialized
INFO - 2021-07-17 17:43:47 --> Model "Settings_model" initialized
INFO - 2021-07-17 17:43:47 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 17:43:47 --> Model "Permissions_model" initialized
INFO - 2021-07-17 17:43:47 --> Model "Roles_model" initialized
INFO - 2021-07-17 17:43:47 --> Model "Activity_model" initialized
INFO - 2021-07-17 17:43:47 --> Model "Templates_model" initialized
INFO - 2021-07-17 17:43:47 --> Database Driver Class Initialized
INFO - 2021-07-17 17:43:47 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 17:43:47 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 17:43:47 --> Controller Class Initialized
ERROR - 2021-07-17 17:43:47 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 17:43:47 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 17:43:47 --> Final output sent to browser
DEBUG - 2021-07-17 17:43:47 --> Total execution time: 0.1234
INFO - 2021-07-17 17:45:29 --> Config Class Initialized
INFO - 2021-07-17 17:45:29 --> Hooks Class Initialized
DEBUG - 2021-07-17 17:45:29 --> UTF-8 Support Enabled
INFO - 2021-07-17 17:45:29 --> Utf8 Class Initialized
INFO - 2021-07-17 17:45:29 --> URI Class Initialized
INFO - 2021-07-17 17:45:29 --> Router Class Initialized
INFO - 2021-07-17 17:45:29 --> Output Class Initialized
INFO - 2021-07-17 17:45:29 --> Security Class Initialized
DEBUG - 2021-07-17 17:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 17:45:29 --> Input Class Initialized
INFO - 2021-07-17 17:45:29 --> Language Class Initialized
INFO - 2021-07-17 17:45:29 --> Loader Class Initialized
INFO - 2021-07-17 17:45:29 --> Helper loaded: basic_helper
INFO - 2021-07-17 17:45:29 --> Helper loaded: url_helper
INFO - 2021-07-17 17:45:29 --> Helper loaded: file_helper
INFO - 2021-07-17 17:45:29 --> Helper loaded: form_helper
INFO - 2021-07-17 17:45:29 --> Helper loaded: cookie_helper
INFO - 2021-07-17 17:45:29 --> Helper loaded: security_helper
INFO - 2021-07-17 17:45:29 --> Helper loaded: directory_helper
INFO - 2021-07-17 17:45:29 --> Helper loaded: language_helper
INFO - 2021-07-17 17:45:29 --> Helper loaded: general_helper
INFO - 2021-07-17 17:45:29 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 17:45:29 --> Database Driver Class Initialized
DEBUG - 2021-07-17 17:45:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 17:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 17:45:29 --> Parser Class Initialized
INFO - 2021-07-17 17:45:29 --> Form Validation Class Initialized
INFO - 2021-07-17 17:45:29 --> Upload Class Initialized
INFO - 2021-07-17 17:45:29 --> Email Class Initialized
INFO - 2021-07-17 17:45:29 --> MY_Model class loaded
INFO - 2021-07-17 17:45:29 --> Model "Users_model" initialized
INFO - 2021-07-17 17:45:29 --> Model "Settings_model" initialized
INFO - 2021-07-17 17:45:29 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 17:45:29 --> Model "Permissions_model" initialized
INFO - 2021-07-17 17:45:29 --> Model "Roles_model" initialized
INFO - 2021-07-17 17:45:29 --> Model "Activity_model" initialized
INFO - 2021-07-17 17:45:29 --> Model "Templates_model" initialized
INFO - 2021-07-17 17:45:29 --> Database Driver Class Initialized
INFO - 2021-07-17 17:45:30 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 17:45:30 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 17:45:30 --> Controller Class Initialized
ERROR - 2021-07-17 17:45:30 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 17:45:30 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 17:45:30 --> Final output sent to browser
DEBUG - 2021-07-17 17:45:30 --> Total execution time: 0.5689
INFO - 2021-07-17 17:46:41 --> Config Class Initialized
INFO - 2021-07-17 17:46:41 --> Hooks Class Initialized
DEBUG - 2021-07-17 17:46:41 --> UTF-8 Support Enabled
INFO - 2021-07-17 17:46:41 --> Utf8 Class Initialized
INFO - 2021-07-17 17:46:41 --> URI Class Initialized
INFO - 2021-07-17 17:46:41 --> Router Class Initialized
INFO - 2021-07-17 17:46:41 --> Output Class Initialized
INFO - 2021-07-17 17:46:41 --> Security Class Initialized
DEBUG - 2021-07-17 17:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-17 17:46:41 --> Input Class Initialized
INFO - 2021-07-17 17:46:41 --> Language Class Initialized
INFO - 2021-07-17 17:46:41 --> Loader Class Initialized
INFO - 2021-07-17 17:46:41 --> Helper loaded: basic_helper
INFO - 2021-07-17 17:46:41 --> Helper loaded: url_helper
INFO - 2021-07-17 17:46:41 --> Helper loaded: file_helper
INFO - 2021-07-17 17:46:41 --> Helper loaded: form_helper
INFO - 2021-07-17 17:46:41 --> Helper loaded: cookie_helper
INFO - 2021-07-17 17:46:41 --> Helper loaded: security_helper
INFO - 2021-07-17 17:46:41 --> Helper loaded: directory_helper
INFO - 2021-07-17 17:46:41 --> Helper loaded: language_helper
INFO - 2021-07-17 17:46:41 --> Helper loaded: general_helper
INFO - 2021-07-17 17:46:41 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-17 17:46:41 --> Database Driver Class Initialized
DEBUG - 2021-07-17 17:46:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-17 17:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-17 17:46:41 --> Parser Class Initialized
INFO - 2021-07-17 17:46:41 --> Form Validation Class Initialized
INFO - 2021-07-17 17:46:41 --> Upload Class Initialized
INFO - 2021-07-17 17:46:41 --> Email Class Initialized
INFO - 2021-07-17 17:46:41 --> MY_Model class loaded
INFO - 2021-07-17 17:46:41 --> Model "Users_model" initialized
INFO - 2021-07-17 17:46:41 --> Model "Settings_model" initialized
INFO - 2021-07-17 17:46:41 --> Model "Role_permissions_model" initialized
INFO - 2021-07-17 17:46:41 --> Model "Permissions_model" initialized
INFO - 2021-07-17 17:46:41 --> Model "Roles_model" initialized
INFO - 2021-07-17 17:46:41 --> Model "Activity_model" initialized
INFO - 2021-07-17 17:46:41 --> Model "Templates_model" initialized
INFO - 2021-07-17 17:46:41 --> Database Driver Class Initialized
INFO - 2021-07-17 17:46:42 --> Model "Hesaplar_model" initialized
INFO - 2021-07-17 17:46:42 --> Model "Car_activity_model" initialized
INFO - 2021-07-17 17:46:42 --> Controller Class Initialized
ERROR - 2021-07-17 17:46:42 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-17 17:46:42 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-17 17:46:42 --> Final output sent to browser
DEBUG - 2021-07-17 17:46:42 --> Total execution time: 0.5559
