<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-07-02 08:22:19 --> Config Class Initialized
INFO - 2021-07-02 08:22:19 --> Hooks Class Initialized
DEBUG - 2021-07-02 08:22:19 --> UTF-8 Support Enabled
INFO - 2021-07-02 08:22:19 --> Utf8 Class Initialized
INFO - 2021-07-02 08:22:19 --> URI Class Initialized
DEBUG - 2021-07-02 08:22:19 --> No URI present. Default controller set.
INFO - 2021-07-02 08:22:19 --> Router Class Initialized
INFO - 2021-07-02 08:22:19 --> Output Class Initialized
INFO - 2021-07-02 08:22:19 --> Security Class Initialized
DEBUG - 2021-07-02 08:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 08:22:19 --> Input Class Initialized
INFO - 2021-07-02 08:22:19 --> Language Class Initialized
INFO - 2021-07-02 08:22:19 --> Loader Class Initialized
INFO - 2021-07-02 08:22:19 --> Helper loaded: basic_helper
INFO - 2021-07-02 08:22:19 --> Helper loaded: url_helper
INFO - 2021-07-02 08:22:19 --> Helper loaded: file_helper
INFO - 2021-07-02 08:22:19 --> Helper loaded: form_helper
INFO - 2021-07-02 08:22:19 --> Helper loaded: cookie_helper
INFO - 2021-07-02 08:22:19 --> Helper loaded: security_helper
INFO - 2021-07-02 08:22:19 --> Helper loaded: directory_helper
INFO - 2021-07-02 08:22:19 --> Helper loaded: language_helper
INFO - 2021-07-02 08:22:19 --> Helper loaded: general_helper
INFO - 2021-07-02 08:22:19 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-02 08:22:19 --> Database Driver Class Initialized
DEBUG - 2021-07-02 08:22:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-02 08:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-02 08:22:19 --> Parser Class Initialized
INFO - 2021-07-02 08:22:19 --> Form Validation Class Initialized
INFO - 2021-07-02 08:22:19 --> Upload Class Initialized
INFO - 2021-07-02 08:22:19 --> Email Class Initialized
INFO - 2021-07-02 08:22:19 --> MY_Model class loaded
INFO - 2021-07-02 08:22:19 --> Model "Users_model" initialized
INFO - 2021-07-02 08:22:19 --> Model "Settings_model" initialized
INFO - 2021-07-02 08:22:19 --> Model "Role_permissions_model" initialized
INFO - 2021-07-02 08:22:19 --> Model "Permissions_model" initialized
INFO - 2021-07-02 08:22:19 --> Model "Roles_model" initialized
INFO - 2021-07-02 08:22:19 --> Model "Activity_model" initialized
INFO - 2021-07-02 08:22:19 --> Model "Templates_model" initialized
INFO - 2021-07-02 08:22:19 --> Database Driver Class Initialized
INFO - 2021-07-02 08:22:19 --> Model "Hesaplar_model" initialized
INFO - 2021-07-02 08:22:19 --> Controller Class Initialized
INFO - 2021-07-02 08:57:47 --> Config Class Initialized
INFO - 2021-07-02 08:57:47 --> Hooks Class Initialized
DEBUG - 2021-07-02 08:57:47 --> UTF-8 Support Enabled
INFO - 2021-07-02 08:57:47 --> Utf8 Class Initialized
INFO - 2021-07-02 08:57:47 --> URI Class Initialized
INFO - 2021-07-02 08:57:47 --> Router Class Initialized
INFO - 2021-07-02 08:57:47 --> Output Class Initialized
INFO - 2021-07-02 08:57:47 --> Security Class Initialized
DEBUG - 2021-07-02 08:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 08:57:47 --> Input Class Initialized
INFO - 2021-07-02 08:57:47 --> Language Class Initialized
INFO - 2021-07-02 08:57:47 --> Loader Class Initialized
INFO - 2021-07-02 08:57:47 --> Helper loaded: basic_helper
INFO - 2021-07-02 08:57:47 --> Helper loaded: url_helper
INFO - 2021-07-02 08:57:47 --> Helper loaded: file_helper
INFO - 2021-07-02 08:57:47 --> Helper loaded: form_helper
INFO - 2021-07-02 08:57:47 --> Helper loaded: cookie_helper
INFO - 2021-07-02 08:57:47 --> Helper loaded: security_helper
INFO - 2021-07-02 08:57:47 --> Helper loaded: directory_helper
INFO - 2021-07-02 08:57:47 --> Helper loaded: language_helper
INFO - 2021-07-02 08:57:47 --> Helper loaded: general_helper
INFO - 2021-07-02 08:57:47 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-02 08:57:47 --> Database Driver Class Initialized
DEBUG - 2021-07-02 08:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-02 08:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-02 08:57:47 --> Parser Class Initialized
INFO - 2021-07-02 08:57:47 --> Form Validation Class Initialized
INFO - 2021-07-02 08:57:47 --> Upload Class Initialized
INFO - 2021-07-02 08:57:47 --> Email Class Initialized
INFO - 2021-07-02 08:57:47 --> MY_Model class loaded
INFO - 2021-07-02 08:57:47 --> Model "Users_model" initialized
INFO - 2021-07-02 08:57:47 --> Model "Settings_model" initialized
INFO - 2021-07-02 08:57:47 --> Model "Role_permissions_model" initialized
INFO - 2021-07-02 08:57:47 --> Model "Permissions_model" initialized
INFO - 2021-07-02 08:57:47 --> Model "Roles_model" initialized
INFO - 2021-07-02 08:57:47 --> Model "Activity_model" initialized
INFO - 2021-07-02 08:57:47 --> Model "Templates_model" initialized
INFO - 2021-07-02 08:57:47 --> Database Driver Class Initialized
INFO - 2021-07-02 08:57:48 --> Model "Hesaplar_model" initialized
INFO - 2021-07-02 08:57:48 --> Controller Class Initialized
INFO - 2021-07-02 08:57:48 --> Config Class Initialized
INFO - 2021-07-02 08:57:48 --> Hooks Class Initialized
DEBUG - 2021-07-02 08:57:48 --> UTF-8 Support Enabled
INFO - 2021-07-02 08:57:48 --> Utf8 Class Initialized
INFO - 2021-07-02 08:57:48 --> URI Class Initialized
INFO - 2021-07-02 08:57:48 --> Router Class Initialized
INFO - 2021-07-02 08:57:48 --> Output Class Initialized
INFO - 2021-07-02 08:57:48 --> Security Class Initialized
DEBUG - 2021-07-02 08:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 08:57:48 --> Input Class Initialized
INFO - 2021-07-02 08:57:48 --> Language Class Initialized
INFO - 2021-07-02 08:57:48 --> Loader Class Initialized
INFO - 2021-07-02 08:57:48 --> Helper loaded: basic_helper
INFO - 2021-07-02 08:57:48 --> Helper loaded: url_helper
INFO - 2021-07-02 08:57:48 --> Helper loaded: file_helper
INFO - 2021-07-02 08:57:48 --> Helper loaded: form_helper
INFO - 2021-07-02 08:57:48 --> Helper loaded: cookie_helper
INFO - 2021-07-02 08:57:48 --> Helper loaded: security_helper
INFO - 2021-07-02 08:57:48 --> Helper loaded: directory_helper
INFO - 2021-07-02 08:57:48 --> Helper loaded: language_helper
INFO - 2021-07-02 08:57:48 --> Helper loaded: general_helper
INFO - 2021-07-02 08:57:48 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-02 08:57:48 --> Database Driver Class Initialized
DEBUG - 2021-07-02 08:57:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-02 08:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-02 08:57:48 --> Parser Class Initialized
INFO - 2021-07-02 08:57:48 --> Form Validation Class Initialized
INFO - 2021-07-02 08:57:48 --> Upload Class Initialized
INFO - 2021-07-02 08:57:48 --> Email Class Initialized
INFO - 2021-07-02 08:57:48 --> MY_Model class loaded
INFO - 2021-07-02 08:57:48 --> Model "Users_model" initialized
INFO - 2021-07-02 08:57:48 --> Model "Settings_model" initialized
INFO - 2021-07-02 08:57:48 --> Model "Role_permissions_model" initialized
INFO - 2021-07-02 08:57:48 --> Model "Permissions_model" initialized
INFO - 2021-07-02 08:57:48 --> Model "Roles_model" initialized
INFO - 2021-07-02 08:57:48 --> Model "Activity_model" initialized
INFO - 2021-07-02 08:57:48 --> Model "Templates_model" initialized
INFO - 2021-07-02 08:57:48 --> Database Driver Class Initialized
INFO - 2021-07-02 08:57:48 --> Model "Hesaplar_model" initialized
INFO - 2021-07-02 08:57:48 --> Controller Class Initialized
INFO - 2021-07-02 11:57:48 --> File loaded: C:\wamp64\www\crm\application\views\account/login.php
INFO - 2021-07-02 11:57:48 --> Final output sent to browser
DEBUG - 2021-07-02 11:57:48 --> Total execution time: 0.0548
INFO - 2021-07-02 08:57:48 --> Config Class Initialized
INFO - 2021-07-02 08:57:48 --> Config Class Initialized
INFO - 2021-07-02 08:57:48 --> Hooks Class Initialized
INFO - 2021-07-02 08:57:48 --> Hooks Class Initialized
DEBUG - 2021-07-02 08:57:48 --> UTF-8 Support Enabled
DEBUG - 2021-07-02 08:57:48 --> UTF-8 Support Enabled
INFO - 2021-07-02 08:57:48 --> Utf8 Class Initialized
INFO - 2021-07-02 08:57:48 --> Utf8 Class Initialized
INFO - 2021-07-02 08:57:48 --> URI Class Initialized
INFO - 2021-07-02 08:57:48 --> URI Class Initialized
INFO - 2021-07-02 08:57:48 --> Router Class Initialized
INFO - 2021-07-02 08:57:48 --> Router Class Initialized
INFO - 2021-07-02 08:57:48 --> Output Class Initialized
INFO - 2021-07-02 08:57:48 --> Output Class Initialized
INFO - 2021-07-02 08:57:48 --> Security Class Initialized
INFO - 2021-07-02 08:57:48 --> Security Class Initialized
DEBUG - 2021-07-02 08:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-02 08:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 08:57:48 --> Input Class Initialized
INFO - 2021-07-02 08:57:48 --> Input Class Initialized
INFO - 2021-07-02 08:57:48 --> Language Class Initialized
INFO - 2021-07-02 08:57:48 --> Language Class Initialized
ERROR - 2021-07-02 08:57:48 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-07-02 08:57:48 --> 404 Page Not Found: Assets/jquery
INFO - 2021-07-02 08:57:48 --> Config Class Initialized
INFO - 2021-07-02 08:57:48 --> Hooks Class Initialized
DEBUG - 2021-07-02 08:57:48 --> UTF-8 Support Enabled
INFO - 2021-07-02 08:57:48 --> Utf8 Class Initialized
INFO - 2021-07-02 08:57:48 --> URI Class Initialized
INFO - 2021-07-02 08:57:48 --> Router Class Initialized
INFO - 2021-07-02 08:57:48 --> Output Class Initialized
INFO - 2021-07-02 08:57:48 --> Security Class Initialized
DEBUG - 2021-07-02 08:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 08:57:48 --> Input Class Initialized
INFO - 2021-07-02 08:57:48 --> Language Class Initialized
ERROR - 2021-07-02 08:57:48 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-02 08:57:56 --> Config Class Initialized
INFO - 2021-07-02 08:57:56 --> Hooks Class Initialized
DEBUG - 2021-07-02 08:57:56 --> UTF-8 Support Enabled
INFO - 2021-07-02 08:57:56 --> Utf8 Class Initialized
INFO - 2021-07-02 08:57:56 --> URI Class Initialized
INFO - 2021-07-02 08:57:56 --> Router Class Initialized
INFO - 2021-07-02 08:57:56 --> Output Class Initialized
INFO - 2021-07-02 08:57:56 --> Security Class Initialized
DEBUG - 2021-07-02 08:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 08:57:56 --> Input Class Initialized
INFO - 2021-07-02 08:57:56 --> Language Class Initialized
INFO - 2021-07-02 08:57:56 --> Loader Class Initialized
INFO - 2021-07-02 08:57:56 --> Helper loaded: basic_helper
INFO - 2021-07-02 08:57:56 --> Helper loaded: url_helper
INFO - 2021-07-02 08:57:56 --> Helper loaded: file_helper
INFO - 2021-07-02 08:57:56 --> Helper loaded: form_helper
INFO - 2021-07-02 08:57:56 --> Helper loaded: cookie_helper
INFO - 2021-07-02 08:57:56 --> Helper loaded: security_helper
INFO - 2021-07-02 08:57:56 --> Helper loaded: directory_helper
INFO - 2021-07-02 08:57:56 --> Helper loaded: language_helper
INFO - 2021-07-02 08:57:56 --> Helper loaded: general_helper
INFO - 2021-07-02 08:57:56 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-02 08:57:56 --> Database Driver Class Initialized
DEBUG - 2021-07-02 08:57:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-02 08:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-02 08:57:56 --> Parser Class Initialized
INFO - 2021-07-02 08:57:56 --> Form Validation Class Initialized
INFO - 2021-07-02 08:57:56 --> Upload Class Initialized
INFO - 2021-07-02 08:57:56 --> Email Class Initialized
INFO - 2021-07-02 08:57:56 --> MY_Model class loaded
INFO - 2021-07-02 08:57:56 --> Model "Users_model" initialized
INFO - 2021-07-02 08:57:56 --> Model "Settings_model" initialized
INFO - 2021-07-02 08:57:56 --> Model "Role_permissions_model" initialized
INFO - 2021-07-02 08:57:56 --> Model "Permissions_model" initialized
INFO - 2021-07-02 08:57:56 --> Model "Roles_model" initialized
INFO - 2021-07-02 08:57:56 --> Model "Activity_model" initialized
INFO - 2021-07-02 08:57:56 --> Model "Templates_model" initialized
INFO - 2021-07-02 08:57:56 --> Database Driver Class Initialized
INFO - 2021-07-02 08:57:56 --> Model "Hesaplar_model" initialized
INFO - 2021-07-02 08:57:56 --> Controller Class Initialized
DEBUG - 2021-07-02 11:57:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-02 11:57:56 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2021-07-02 08:57:56 --> Config Class Initialized
INFO - 2021-07-02 08:57:56 --> Hooks Class Initialized
DEBUG - 2021-07-02 08:57:56 --> UTF-8 Support Enabled
INFO - 2021-07-02 08:57:56 --> Utf8 Class Initialized
INFO - 2021-07-02 08:57:56 --> URI Class Initialized
DEBUG - 2021-07-02 08:57:56 --> No URI present. Default controller set.
INFO - 2021-07-02 08:57:56 --> Router Class Initialized
INFO - 2021-07-02 08:57:56 --> Output Class Initialized
INFO - 2021-07-02 08:57:56 --> Security Class Initialized
DEBUG - 2021-07-02 08:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 08:57:56 --> Input Class Initialized
INFO - 2021-07-02 08:57:56 --> Language Class Initialized
INFO - 2021-07-02 08:57:56 --> Loader Class Initialized
INFO - 2021-07-02 08:57:56 --> Helper loaded: basic_helper
INFO - 2021-07-02 08:57:56 --> Helper loaded: url_helper
INFO - 2021-07-02 08:57:56 --> Helper loaded: file_helper
INFO - 2021-07-02 08:57:56 --> Helper loaded: form_helper
INFO - 2021-07-02 08:57:56 --> Helper loaded: cookie_helper
INFO - 2021-07-02 08:57:56 --> Helper loaded: security_helper
INFO - 2021-07-02 08:57:56 --> Helper loaded: directory_helper
INFO - 2021-07-02 08:57:56 --> Helper loaded: language_helper
INFO - 2021-07-02 08:57:56 --> Helper loaded: general_helper
INFO - 2021-07-02 08:57:56 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-02 08:57:56 --> Database Driver Class Initialized
DEBUG - 2021-07-02 08:57:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-02 08:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-02 08:57:56 --> Parser Class Initialized
INFO - 2021-07-02 08:57:56 --> Form Validation Class Initialized
INFO - 2021-07-02 08:57:56 --> Upload Class Initialized
INFO - 2021-07-02 08:57:56 --> Email Class Initialized
INFO - 2021-07-02 08:57:56 --> MY_Model class loaded
INFO - 2021-07-02 08:57:56 --> Model "Users_model" initialized
INFO - 2021-07-02 08:57:56 --> Model "Settings_model" initialized
INFO - 2021-07-02 08:57:56 --> Model "Role_permissions_model" initialized
INFO - 2021-07-02 08:57:56 --> Model "Permissions_model" initialized
INFO - 2021-07-02 08:57:56 --> Model "Roles_model" initialized
INFO - 2021-07-02 08:57:56 --> Model "Activity_model" initialized
INFO - 2021-07-02 08:57:56 --> Model "Templates_model" initialized
INFO - 2021-07-02 08:57:56 --> Database Driver Class Initialized
INFO - 2021-07-02 08:57:56 --> Model "Hesaplar_model" initialized
INFO - 2021-07-02 08:57:56 --> Controller Class Initialized
ERROR - 2021-07-02 11:57:56 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-02 11:57:56 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-02 11:57:56 --> Final output sent to browser
DEBUG - 2021-07-02 11:57:56 --> Total execution time: 0.0619
INFO - 2021-07-02 08:57:59 --> Config Class Initialized
INFO - 2021-07-02 08:57:59 --> Hooks Class Initialized
DEBUG - 2021-07-02 08:57:59 --> UTF-8 Support Enabled
INFO - 2021-07-02 08:57:59 --> Utf8 Class Initialized
INFO - 2021-07-02 08:57:59 --> URI Class Initialized
INFO - 2021-07-02 08:57:59 --> Router Class Initialized
INFO - 2021-07-02 08:57:59 --> Output Class Initialized
INFO - 2021-07-02 08:57:59 --> Security Class Initialized
DEBUG - 2021-07-02 08:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 08:57:59 --> Input Class Initialized
INFO - 2021-07-02 08:57:59 --> Language Class Initialized
INFO - 2021-07-02 08:57:59 --> Loader Class Initialized
INFO - 2021-07-02 08:57:59 --> Helper loaded: basic_helper
INFO - 2021-07-02 08:57:59 --> Helper loaded: url_helper
INFO - 2021-07-02 08:57:59 --> Helper loaded: file_helper
INFO - 2021-07-02 08:57:59 --> Helper loaded: form_helper
INFO - 2021-07-02 08:57:59 --> Helper loaded: cookie_helper
INFO - 2021-07-02 08:57:59 --> Helper loaded: security_helper
INFO - 2021-07-02 08:57:59 --> Helper loaded: directory_helper
INFO - 2021-07-02 08:57:59 --> Helper loaded: language_helper
INFO - 2021-07-02 08:57:59 --> Helper loaded: general_helper
INFO - 2021-07-02 08:57:59 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-02 08:57:59 --> Database Driver Class Initialized
DEBUG - 2021-07-02 08:57:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-02 08:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-02 08:57:59 --> Parser Class Initialized
INFO - 2021-07-02 08:57:59 --> Form Validation Class Initialized
INFO - 2021-07-02 08:57:59 --> Upload Class Initialized
INFO - 2021-07-02 08:57:59 --> Email Class Initialized
INFO - 2021-07-02 08:57:59 --> MY_Model class loaded
INFO - 2021-07-02 08:57:59 --> Model "Users_model" initialized
INFO - 2021-07-02 08:57:59 --> Model "Settings_model" initialized
INFO - 2021-07-02 08:57:59 --> Model "Role_permissions_model" initialized
INFO - 2021-07-02 08:57:59 --> Model "Permissions_model" initialized
INFO - 2021-07-02 08:57:59 --> Model "Roles_model" initialized
INFO - 2021-07-02 08:57:59 --> Model "Activity_model" initialized
INFO - 2021-07-02 08:57:59 --> Model "Templates_model" initialized
INFO - 2021-07-02 08:57:59 --> Database Driver Class Initialized
INFO - 2021-07-02 08:57:59 --> Model "Hesaplar_model" initialized
INFO - 2021-07-02 08:57:59 --> Controller Class Initialized
ERROR - 2021-07-02 11:57:59 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-02 11:57:59 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-02 11:57:59 --> Final output sent to browser
DEBUG - 2021-07-02 11:57:59 --> Total execution time: 0.2837
INFO - 2021-07-02 08:58:01 --> Config Class Initialized
INFO - 2021-07-02 08:58:01 --> Hooks Class Initialized
DEBUG - 2021-07-02 08:58:01 --> UTF-8 Support Enabled
INFO - 2021-07-02 08:58:01 --> Utf8 Class Initialized
INFO - 2021-07-02 08:58:01 --> URI Class Initialized
INFO - 2021-07-02 08:58:01 --> Router Class Initialized
INFO - 2021-07-02 08:58:01 --> Output Class Initialized
INFO - 2021-07-02 08:58:01 --> Security Class Initialized
DEBUG - 2021-07-02 08:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 08:58:01 --> Input Class Initialized
INFO - 2021-07-02 08:58:01 --> Language Class Initialized
INFO - 2021-07-02 08:58:01 --> Loader Class Initialized
INFO - 2021-07-02 08:58:01 --> Helper loaded: basic_helper
INFO - 2021-07-02 08:58:01 --> Helper loaded: url_helper
INFO - 2021-07-02 08:58:01 --> Helper loaded: file_helper
INFO - 2021-07-02 08:58:01 --> Helper loaded: form_helper
INFO - 2021-07-02 08:58:01 --> Helper loaded: cookie_helper
INFO - 2021-07-02 08:58:01 --> Helper loaded: security_helper
INFO - 2021-07-02 08:58:01 --> Helper loaded: directory_helper
INFO - 2021-07-02 08:58:01 --> Helper loaded: language_helper
INFO - 2021-07-02 08:58:01 --> Helper loaded: general_helper
INFO - 2021-07-02 08:58:01 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-02 08:58:01 --> Database Driver Class Initialized
DEBUG - 2021-07-02 08:58:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-02 08:58:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-02 08:58:01 --> Parser Class Initialized
INFO - 2021-07-02 08:58:01 --> Form Validation Class Initialized
INFO - 2021-07-02 08:58:01 --> Upload Class Initialized
INFO - 2021-07-02 08:58:01 --> Email Class Initialized
INFO - 2021-07-02 08:58:01 --> MY_Model class loaded
INFO - 2021-07-02 08:58:01 --> Model "Users_model" initialized
INFO - 2021-07-02 08:58:01 --> Model "Settings_model" initialized
INFO - 2021-07-02 08:58:01 --> Model "Role_permissions_model" initialized
INFO - 2021-07-02 08:58:01 --> Model "Permissions_model" initialized
INFO - 2021-07-02 08:58:01 --> Model "Roles_model" initialized
INFO - 2021-07-02 08:58:01 --> Model "Activity_model" initialized
INFO - 2021-07-02 08:58:01 --> Model "Templates_model" initialized
INFO - 2021-07-02 08:58:01 --> Database Driver Class Initialized
INFO - 2021-07-02 08:58:01 --> Model "Hesaplar_model" initialized
INFO - 2021-07-02 08:58:01 --> Controller Class Initialized
ERROR - 2021-07-02 11:58:01 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-02 11:58:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\crm\application\views\hesaplar\rapor_ayrinti.php 30
INFO - 2021-07-02 11:58:01 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-02 11:58:01 --> Final output sent to browser
DEBUG - 2021-07-02 11:58:01 --> Total execution time: 0.1283
INFO - 2021-07-02 08:58:03 --> Config Class Initialized
INFO - 2021-07-02 08:58:03 --> Hooks Class Initialized
DEBUG - 2021-07-02 08:58:03 --> UTF-8 Support Enabled
INFO - 2021-07-02 08:58:03 --> Utf8 Class Initialized
INFO - 2021-07-02 08:58:03 --> URI Class Initialized
INFO - 2021-07-02 08:58:03 --> Router Class Initialized
INFO - 2021-07-02 08:58:03 --> Output Class Initialized
INFO - 2021-07-02 08:58:03 --> Security Class Initialized
DEBUG - 2021-07-02 08:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 08:58:03 --> Input Class Initialized
INFO - 2021-07-02 08:58:03 --> Language Class Initialized
INFO - 2021-07-02 08:58:03 --> Loader Class Initialized
INFO - 2021-07-02 08:58:03 --> Helper loaded: basic_helper
INFO - 2021-07-02 08:58:03 --> Helper loaded: url_helper
INFO - 2021-07-02 08:58:03 --> Helper loaded: file_helper
INFO - 2021-07-02 08:58:03 --> Helper loaded: form_helper
INFO - 2021-07-02 08:58:03 --> Helper loaded: cookie_helper
INFO - 2021-07-02 08:58:03 --> Helper loaded: security_helper
INFO - 2021-07-02 08:58:03 --> Helper loaded: directory_helper
INFO - 2021-07-02 08:58:03 --> Helper loaded: language_helper
INFO - 2021-07-02 08:58:03 --> Helper loaded: general_helper
INFO - 2021-07-02 08:58:03 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-02 08:58:03 --> Database Driver Class Initialized
DEBUG - 2021-07-02 08:58:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-02 08:58:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-02 08:58:03 --> Parser Class Initialized
INFO - 2021-07-02 08:58:03 --> Form Validation Class Initialized
INFO - 2021-07-02 08:58:03 --> Upload Class Initialized
INFO - 2021-07-02 08:58:03 --> Email Class Initialized
INFO - 2021-07-02 08:58:03 --> MY_Model class loaded
INFO - 2021-07-02 08:58:03 --> Model "Users_model" initialized
INFO - 2021-07-02 08:58:03 --> Model "Settings_model" initialized
INFO - 2021-07-02 08:58:03 --> Model "Role_permissions_model" initialized
INFO - 2021-07-02 08:58:03 --> Model "Permissions_model" initialized
INFO - 2021-07-02 08:58:03 --> Model "Roles_model" initialized
INFO - 2021-07-02 08:58:03 --> Model "Activity_model" initialized
INFO - 2021-07-02 08:58:03 --> Model "Templates_model" initialized
INFO - 2021-07-02 08:58:03 --> Database Driver Class Initialized
INFO - 2021-07-02 08:58:03 --> Model "Hesaplar_model" initialized
INFO - 2021-07-02 08:58:03 --> Controller Class Initialized
ERROR - 2021-07-02 11:58:03 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-02 11:58:03 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-02 11:58:03 --> Final output sent to browser
DEBUG - 2021-07-02 11:58:03 --> Total execution time: 0.2049
INFO - 2021-07-02 09:03:19 --> Config Class Initialized
INFO - 2021-07-02 09:03:19 --> Hooks Class Initialized
DEBUG - 2021-07-02 09:03:19 --> UTF-8 Support Enabled
INFO - 2021-07-02 09:03:19 --> Utf8 Class Initialized
INFO - 2021-07-02 09:03:19 --> URI Class Initialized
INFO - 2021-07-02 09:03:19 --> Router Class Initialized
INFO - 2021-07-02 09:03:19 --> Output Class Initialized
INFO - 2021-07-02 09:03:19 --> Security Class Initialized
DEBUG - 2021-07-02 09:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 09:03:19 --> Input Class Initialized
INFO - 2021-07-02 09:03:19 --> Language Class Initialized
INFO - 2021-07-02 09:03:19 --> Loader Class Initialized
INFO - 2021-07-02 09:03:19 --> Helper loaded: basic_helper
INFO - 2021-07-02 09:03:19 --> Helper loaded: url_helper
INFO - 2021-07-02 09:03:19 --> Helper loaded: file_helper
INFO - 2021-07-02 09:03:19 --> Helper loaded: form_helper
INFO - 2021-07-02 09:03:19 --> Helper loaded: cookie_helper
INFO - 2021-07-02 09:03:19 --> Helper loaded: security_helper
INFO - 2021-07-02 09:03:19 --> Helper loaded: directory_helper
INFO - 2021-07-02 09:03:19 --> Helper loaded: language_helper
INFO - 2021-07-02 09:03:19 --> Helper loaded: general_helper
INFO - 2021-07-02 09:03:19 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-02 09:03:19 --> Database Driver Class Initialized
DEBUG - 2021-07-02 09:03:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-02 09:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-02 09:03:19 --> Parser Class Initialized
INFO - 2021-07-02 09:03:19 --> Form Validation Class Initialized
INFO - 2021-07-02 09:03:19 --> Upload Class Initialized
INFO - 2021-07-02 09:03:19 --> Email Class Initialized
INFO - 2021-07-02 09:03:19 --> MY_Model class loaded
INFO - 2021-07-02 09:03:19 --> Model "Users_model" initialized
INFO - 2021-07-02 09:03:19 --> Model "Settings_model" initialized
INFO - 2021-07-02 09:03:19 --> Model "Role_permissions_model" initialized
INFO - 2021-07-02 09:03:19 --> Model "Permissions_model" initialized
INFO - 2021-07-02 09:03:19 --> Model "Roles_model" initialized
INFO - 2021-07-02 09:03:19 --> Model "Activity_model" initialized
INFO - 2021-07-02 09:03:19 --> Model "Templates_model" initialized
INFO - 2021-07-02 09:03:19 --> Database Driver Class Initialized
INFO - 2021-07-02 09:03:19 --> Model "Hesaplar_model" initialized
INFO - 2021-07-02 09:03:19 --> Controller Class Initialized
ERROR - 2021-07-02 12:03:19 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-02 12:03:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\crm\application\views\hesaplar\rapor_ayrinti.php 30
INFO - 2021-07-02 12:03:19 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-02 12:03:19 --> Final output sent to browser
DEBUG - 2021-07-02 12:03:19 --> Total execution time: 0.1304
INFO - 2021-07-02 09:03:24 --> Config Class Initialized
INFO - 2021-07-02 09:03:24 --> Hooks Class Initialized
DEBUG - 2021-07-02 09:03:24 --> UTF-8 Support Enabled
INFO - 2021-07-02 09:03:24 --> Utf8 Class Initialized
INFO - 2021-07-02 09:03:24 --> URI Class Initialized
INFO - 2021-07-02 09:03:24 --> Router Class Initialized
INFO - 2021-07-02 09:03:24 --> Output Class Initialized
INFO - 2021-07-02 09:03:24 --> Security Class Initialized
DEBUG - 2021-07-02 09:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 09:03:24 --> Input Class Initialized
INFO - 2021-07-02 09:03:24 --> Language Class Initialized
INFO - 2021-07-02 09:03:24 --> Loader Class Initialized
INFO - 2021-07-02 09:03:24 --> Helper loaded: basic_helper
INFO - 2021-07-02 09:03:24 --> Helper loaded: url_helper
INFO - 2021-07-02 09:03:24 --> Helper loaded: file_helper
INFO - 2021-07-02 09:03:24 --> Helper loaded: form_helper
INFO - 2021-07-02 09:03:24 --> Helper loaded: cookie_helper
INFO - 2021-07-02 09:03:24 --> Helper loaded: security_helper
INFO - 2021-07-02 09:03:24 --> Helper loaded: directory_helper
INFO - 2021-07-02 09:03:24 --> Helper loaded: language_helper
INFO - 2021-07-02 09:03:24 --> Helper loaded: general_helper
INFO - 2021-07-02 09:03:24 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-02 09:03:24 --> Database Driver Class Initialized
DEBUG - 2021-07-02 09:03:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-02 09:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-02 09:03:24 --> Parser Class Initialized
INFO - 2021-07-02 09:03:24 --> Form Validation Class Initialized
INFO - 2021-07-02 09:03:24 --> Upload Class Initialized
INFO - 2021-07-02 09:03:24 --> Email Class Initialized
INFO - 2021-07-02 09:03:24 --> MY_Model class loaded
INFO - 2021-07-02 09:03:24 --> Model "Users_model" initialized
INFO - 2021-07-02 09:03:24 --> Model "Settings_model" initialized
INFO - 2021-07-02 09:03:24 --> Model "Role_permissions_model" initialized
INFO - 2021-07-02 09:03:24 --> Model "Permissions_model" initialized
INFO - 2021-07-02 09:03:24 --> Model "Roles_model" initialized
INFO - 2021-07-02 09:03:24 --> Model "Activity_model" initialized
INFO - 2021-07-02 09:03:24 --> Model "Templates_model" initialized
INFO - 2021-07-02 09:03:24 --> Database Driver Class Initialized
INFO - 2021-07-02 09:03:24 --> Model "Hesaplar_model" initialized
INFO - 2021-07-02 09:03:24 --> Controller Class Initialized
ERROR - 2021-07-02 12:03:24 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-02 12:03:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\crm\application\views\hesaplar\rapor_ayrinti.php 30
INFO - 2021-07-02 12:03:24 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-02 12:03:24 --> Final output sent to browser
DEBUG - 2021-07-02 12:03:24 --> Total execution time: 0.1227
INFO - 2021-07-02 09:12:11 --> Config Class Initialized
INFO - 2021-07-02 09:12:11 --> Hooks Class Initialized
DEBUG - 2021-07-02 09:12:11 --> UTF-8 Support Enabled
INFO - 2021-07-02 09:12:11 --> Utf8 Class Initialized
INFO - 2021-07-02 09:12:11 --> URI Class Initialized
INFO - 2021-07-02 09:12:11 --> Router Class Initialized
INFO - 2021-07-02 09:12:11 --> Output Class Initialized
INFO - 2021-07-02 09:12:11 --> Security Class Initialized
DEBUG - 2021-07-02 09:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 09:12:11 --> Input Class Initialized
INFO - 2021-07-02 09:12:11 --> Language Class Initialized
INFO - 2021-07-02 09:12:11 --> Loader Class Initialized
INFO - 2021-07-02 09:12:11 --> Helper loaded: basic_helper
INFO - 2021-07-02 09:12:11 --> Helper loaded: url_helper
INFO - 2021-07-02 09:12:11 --> Helper loaded: file_helper
INFO - 2021-07-02 09:12:11 --> Helper loaded: form_helper
INFO - 2021-07-02 09:12:11 --> Helper loaded: cookie_helper
INFO - 2021-07-02 09:12:11 --> Helper loaded: security_helper
INFO - 2021-07-02 09:12:11 --> Helper loaded: directory_helper
INFO - 2021-07-02 09:12:11 --> Helper loaded: language_helper
INFO - 2021-07-02 09:12:11 --> Helper loaded: general_helper
INFO - 2021-07-02 09:12:11 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-02 09:12:11 --> Database Driver Class Initialized
DEBUG - 2021-07-02 09:12:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-02 09:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-02 09:12:11 --> Parser Class Initialized
INFO - 2021-07-02 09:12:11 --> Form Validation Class Initialized
INFO - 2021-07-02 09:12:11 --> Upload Class Initialized
INFO - 2021-07-02 09:12:11 --> Email Class Initialized
INFO - 2021-07-02 09:12:11 --> MY_Model class loaded
INFO - 2021-07-02 09:12:11 --> Model "Users_model" initialized
INFO - 2021-07-02 09:12:11 --> Model "Settings_model" initialized
INFO - 2021-07-02 09:12:11 --> Model "Role_permissions_model" initialized
INFO - 2021-07-02 09:12:11 --> Model "Permissions_model" initialized
INFO - 2021-07-02 09:12:11 --> Model "Roles_model" initialized
INFO - 2021-07-02 09:12:11 --> Model "Activity_model" initialized
INFO - 2021-07-02 09:12:11 --> Model "Templates_model" initialized
INFO - 2021-07-02 09:12:11 --> Database Driver Class Initialized
INFO - 2021-07-02 09:12:11 --> Model "Hesaplar_model" initialized
INFO - 2021-07-02 09:12:11 --> Controller Class Initialized
ERROR - 2021-07-02 12:12:11 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-02 12:12:11 --> File loaded: C:\wamp64\www\crm\application\views\permissions/list.php
INFO - 2021-07-02 12:12:11 --> Final output sent to browser
DEBUG - 2021-07-02 12:12:11 --> Total execution time: 0.1912
INFO - 2021-07-02 09:12:14 --> Config Class Initialized
INFO - 2021-07-02 09:12:14 --> Hooks Class Initialized
DEBUG - 2021-07-02 09:12:14 --> UTF-8 Support Enabled
INFO - 2021-07-02 09:12:14 --> Utf8 Class Initialized
INFO - 2021-07-02 09:12:14 --> URI Class Initialized
INFO - 2021-07-02 09:12:14 --> Router Class Initialized
INFO - 2021-07-02 09:12:14 --> Output Class Initialized
INFO - 2021-07-02 09:12:14 --> Security Class Initialized
DEBUG - 2021-07-02 09:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 09:12:14 --> Input Class Initialized
INFO - 2021-07-02 09:12:14 --> Language Class Initialized
INFO - 2021-07-02 09:12:14 --> Loader Class Initialized
INFO - 2021-07-02 09:12:14 --> Helper loaded: basic_helper
INFO - 2021-07-02 09:12:14 --> Helper loaded: url_helper
INFO - 2021-07-02 09:12:14 --> Helper loaded: file_helper
INFO - 2021-07-02 09:12:14 --> Helper loaded: form_helper
INFO - 2021-07-02 09:12:14 --> Helper loaded: cookie_helper
INFO - 2021-07-02 09:12:14 --> Helper loaded: security_helper
INFO - 2021-07-02 09:12:14 --> Helper loaded: directory_helper
INFO - 2021-07-02 09:12:14 --> Helper loaded: language_helper
INFO - 2021-07-02 09:12:14 --> Helper loaded: general_helper
INFO - 2021-07-02 09:12:14 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-02 09:12:14 --> Database Driver Class Initialized
DEBUG - 2021-07-02 09:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-02 09:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-02 09:12:14 --> Parser Class Initialized
INFO - 2021-07-02 09:12:14 --> Form Validation Class Initialized
INFO - 2021-07-02 09:12:14 --> Upload Class Initialized
INFO - 2021-07-02 09:12:14 --> Email Class Initialized
INFO - 2021-07-02 09:12:14 --> MY_Model class loaded
INFO - 2021-07-02 09:12:14 --> Model "Users_model" initialized
INFO - 2021-07-02 09:12:14 --> Model "Settings_model" initialized
INFO - 2021-07-02 09:12:14 --> Model "Role_permissions_model" initialized
INFO - 2021-07-02 09:12:14 --> Model "Permissions_model" initialized
INFO - 2021-07-02 09:12:14 --> Model "Roles_model" initialized
INFO - 2021-07-02 09:12:14 --> Model "Activity_model" initialized
INFO - 2021-07-02 09:12:14 --> Model "Templates_model" initialized
INFO - 2021-07-02 09:12:14 --> Database Driver Class Initialized
INFO - 2021-07-02 09:12:14 --> Model "Hesaplar_model" initialized
INFO - 2021-07-02 09:12:14 --> Controller Class Initialized
ERROR - 2021-07-02 12:12:14 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-02 12:12:14 --> File loaded: C:\wamp64\www\crm\application\views\permissions/add.php
INFO - 2021-07-02 12:12:14 --> Final output sent to browser
DEBUG - 2021-07-02 12:12:14 --> Total execution time: 0.0652
INFO - 2021-07-02 09:12:45 --> Config Class Initialized
INFO - 2021-07-02 09:12:45 --> Hooks Class Initialized
DEBUG - 2021-07-02 09:12:45 --> UTF-8 Support Enabled
INFO - 2021-07-02 09:12:45 --> Utf8 Class Initialized
INFO - 2021-07-02 09:12:45 --> URI Class Initialized
INFO - 2021-07-02 09:12:45 --> Router Class Initialized
INFO - 2021-07-02 09:12:45 --> Output Class Initialized
INFO - 2021-07-02 09:12:45 --> Security Class Initialized
DEBUG - 2021-07-02 09:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 09:12:45 --> Input Class Initialized
INFO - 2021-07-02 09:12:45 --> Language Class Initialized
INFO - 2021-07-02 09:12:45 --> Loader Class Initialized
INFO - 2021-07-02 09:12:45 --> Helper loaded: basic_helper
INFO - 2021-07-02 09:12:45 --> Helper loaded: url_helper
INFO - 2021-07-02 09:12:45 --> Helper loaded: file_helper
INFO - 2021-07-02 09:12:45 --> Helper loaded: form_helper
INFO - 2021-07-02 09:12:45 --> Helper loaded: cookie_helper
INFO - 2021-07-02 09:12:45 --> Helper loaded: security_helper
INFO - 2021-07-02 09:12:45 --> Helper loaded: directory_helper
INFO - 2021-07-02 09:12:45 --> Helper loaded: language_helper
INFO - 2021-07-02 09:12:45 --> Helper loaded: general_helper
INFO - 2021-07-02 09:12:45 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-02 09:12:45 --> Database Driver Class Initialized
DEBUG - 2021-07-02 09:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-02 09:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-02 09:12:45 --> Parser Class Initialized
INFO - 2021-07-02 09:12:45 --> Form Validation Class Initialized
INFO - 2021-07-02 09:12:45 --> Upload Class Initialized
INFO - 2021-07-02 09:12:45 --> Email Class Initialized
INFO - 2021-07-02 09:12:45 --> MY_Model class loaded
INFO - 2021-07-02 09:12:45 --> Model "Users_model" initialized
INFO - 2021-07-02 09:12:45 --> Model "Settings_model" initialized
INFO - 2021-07-02 09:12:45 --> Model "Role_permissions_model" initialized
INFO - 2021-07-02 09:12:45 --> Model "Permissions_model" initialized
INFO - 2021-07-02 09:12:45 --> Model "Roles_model" initialized
INFO - 2021-07-02 09:12:45 --> Model "Activity_model" initialized
INFO - 2021-07-02 09:12:45 --> Model "Templates_model" initialized
INFO - 2021-07-02 09:12:45 --> Database Driver Class Initialized
INFO - 2021-07-02 09:12:45 --> Model "Hesaplar_model" initialized
INFO - 2021-07-02 09:12:45 --> Controller Class Initialized
INFO - 2021-07-02 09:12:45 --> Config Class Initialized
INFO - 2021-07-02 09:12:45 --> Hooks Class Initialized
DEBUG - 2021-07-02 09:12:45 --> UTF-8 Support Enabled
INFO - 2021-07-02 09:12:45 --> Utf8 Class Initialized
INFO - 2021-07-02 09:12:45 --> URI Class Initialized
INFO - 2021-07-02 09:12:45 --> Router Class Initialized
INFO - 2021-07-02 09:12:45 --> Output Class Initialized
INFO - 2021-07-02 09:12:45 --> Security Class Initialized
DEBUG - 2021-07-02 09:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 09:12:45 --> Input Class Initialized
INFO - 2021-07-02 09:12:45 --> Language Class Initialized
INFO - 2021-07-02 09:12:45 --> Loader Class Initialized
INFO - 2021-07-02 09:12:45 --> Helper loaded: basic_helper
INFO - 2021-07-02 09:12:45 --> Helper loaded: url_helper
INFO - 2021-07-02 09:12:45 --> Helper loaded: file_helper
INFO - 2021-07-02 09:12:45 --> Helper loaded: form_helper
INFO - 2021-07-02 09:12:45 --> Helper loaded: cookie_helper
INFO - 2021-07-02 09:12:45 --> Helper loaded: security_helper
INFO - 2021-07-02 09:12:45 --> Helper loaded: directory_helper
INFO - 2021-07-02 09:12:45 --> Helper loaded: language_helper
INFO - 2021-07-02 09:12:45 --> Helper loaded: general_helper
INFO - 2021-07-02 09:12:45 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-02 09:12:45 --> Database Driver Class Initialized
DEBUG - 2021-07-02 09:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-02 09:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-02 09:12:45 --> Parser Class Initialized
INFO - 2021-07-02 09:12:45 --> Form Validation Class Initialized
INFO - 2021-07-02 09:12:45 --> Upload Class Initialized
INFO - 2021-07-02 09:12:45 --> Email Class Initialized
INFO - 2021-07-02 09:12:45 --> MY_Model class loaded
INFO - 2021-07-02 09:12:45 --> Model "Users_model" initialized
INFO - 2021-07-02 09:12:45 --> Model "Settings_model" initialized
INFO - 2021-07-02 09:12:45 --> Model "Role_permissions_model" initialized
INFO - 2021-07-02 09:12:45 --> Model "Permissions_model" initialized
INFO - 2021-07-02 09:12:45 --> Model "Roles_model" initialized
INFO - 2021-07-02 09:12:45 --> Model "Activity_model" initialized
INFO - 2021-07-02 09:12:45 --> Model "Templates_model" initialized
INFO - 2021-07-02 09:12:45 --> Database Driver Class Initialized
INFO - 2021-07-02 09:12:45 --> Model "Hesaplar_model" initialized
INFO - 2021-07-02 09:12:45 --> Controller Class Initialized
INFO - 2021-07-02 09:12:45 --> Config Class Initialized
INFO - 2021-07-02 09:12:45 --> Hooks Class Initialized
DEBUG - 2021-07-02 09:12:45 --> UTF-8 Support Enabled
INFO - 2021-07-02 09:12:45 --> Utf8 Class Initialized
INFO - 2021-07-02 09:12:45 --> URI Class Initialized
INFO - 2021-07-02 09:12:45 --> Router Class Initialized
INFO - 2021-07-02 09:12:45 --> Output Class Initialized
INFO - 2021-07-02 09:12:45 --> Security Class Initialized
DEBUG - 2021-07-02 09:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 09:12:45 --> Input Class Initialized
INFO - 2021-07-02 09:12:45 --> Language Class Initialized
INFO - 2021-07-02 09:12:45 --> Loader Class Initialized
INFO - 2021-07-02 09:12:45 --> Helper loaded: basic_helper
INFO - 2021-07-02 09:12:45 --> Helper loaded: url_helper
INFO - 2021-07-02 09:12:45 --> Helper loaded: file_helper
INFO - 2021-07-02 09:12:45 --> Helper loaded: form_helper
INFO - 2021-07-02 09:12:45 --> Helper loaded: cookie_helper
INFO - 2021-07-02 09:12:45 --> Helper loaded: security_helper
INFO - 2021-07-02 09:12:45 --> Helper loaded: directory_helper
INFO - 2021-07-02 09:12:45 --> Helper loaded: language_helper
INFO - 2021-07-02 09:12:45 --> Helper loaded: general_helper
INFO - 2021-07-02 09:12:45 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-02 09:12:45 --> Database Driver Class Initialized
DEBUG - 2021-07-02 09:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-02 09:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-02 09:12:45 --> Parser Class Initialized
INFO - 2021-07-02 09:12:45 --> Form Validation Class Initialized
INFO - 2021-07-02 09:12:45 --> Upload Class Initialized
INFO - 2021-07-02 09:12:45 --> Email Class Initialized
INFO - 2021-07-02 09:12:45 --> MY_Model class loaded
INFO - 2021-07-02 09:12:45 --> Model "Users_model" initialized
INFO - 2021-07-02 09:12:45 --> Model "Settings_model" initialized
INFO - 2021-07-02 09:12:45 --> Model "Role_permissions_model" initialized
INFO - 2021-07-02 09:12:45 --> Model "Permissions_model" initialized
INFO - 2021-07-02 09:12:45 --> Model "Roles_model" initialized
INFO - 2021-07-02 09:12:45 --> Model "Activity_model" initialized
INFO - 2021-07-02 09:12:45 --> Model "Templates_model" initialized
INFO - 2021-07-02 09:12:45 --> Database Driver Class Initialized
INFO - 2021-07-02 09:12:45 --> Model "Hesaplar_model" initialized
INFO - 2021-07-02 09:12:45 --> Controller Class Initialized
ERROR - 2021-07-02 12:12:45 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-02 12:12:45 --> File loaded: C:\wamp64\www\crm\application\views\permissions/list.php
INFO - 2021-07-02 12:12:45 --> Final output sent to browser
DEBUG - 2021-07-02 12:12:45 --> Total execution time: 0.1002
INFO - 2021-07-02 09:13:24 --> Config Class Initialized
INFO - 2021-07-02 09:13:24 --> Hooks Class Initialized
DEBUG - 2021-07-02 09:13:24 --> UTF-8 Support Enabled
INFO - 2021-07-02 09:13:24 --> Utf8 Class Initialized
INFO - 2021-07-02 09:13:24 --> URI Class Initialized
INFO - 2021-07-02 09:13:24 --> Router Class Initialized
INFO - 2021-07-02 09:13:24 --> Output Class Initialized
INFO - 2021-07-02 09:13:24 --> Security Class Initialized
DEBUG - 2021-07-02 09:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 09:13:24 --> Input Class Initialized
INFO - 2021-07-02 09:13:24 --> Language Class Initialized
INFO - 2021-07-02 09:13:24 --> Loader Class Initialized
INFO - 2021-07-02 09:13:24 --> Helper loaded: basic_helper
INFO - 2021-07-02 09:13:24 --> Helper loaded: url_helper
INFO - 2021-07-02 09:13:24 --> Helper loaded: file_helper
INFO - 2021-07-02 09:13:24 --> Helper loaded: form_helper
INFO - 2021-07-02 09:13:24 --> Helper loaded: cookie_helper
INFO - 2021-07-02 09:13:24 --> Helper loaded: security_helper
INFO - 2021-07-02 09:13:24 --> Helper loaded: directory_helper
INFO - 2021-07-02 09:13:24 --> Helper loaded: language_helper
INFO - 2021-07-02 09:13:24 --> Helper loaded: general_helper
INFO - 2021-07-02 09:13:24 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-02 09:13:24 --> Database Driver Class Initialized
DEBUG - 2021-07-02 09:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-02 09:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-02 09:13:24 --> Parser Class Initialized
INFO - 2021-07-02 09:13:24 --> Form Validation Class Initialized
INFO - 2021-07-02 09:13:24 --> Upload Class Initialized
INFO - 2021-07-02 09:13:24 --> Email Class Initialized
INFO - 2021-07-02 09:13:24 --> MY_Model class loaded
INFO - 2021-07-02 09:13:24 --> Model "Users_model" initialized
INFO - 2021-07-02 09:13:24 --> Model "Settings_model" initialized
INFO - 2021-07-02 09:13:24 --> Model "Role_permissions_model" initialized
INFO - 2021-07-02 09:13:24 --> Model "Permissions_model" initialized
INFO - 2021-07-02 09:13:24 --> Model "Roles_model" initialized
INFO - 2021-07-02 09:13:24 --> Model "Activity_model" initialized
INFO - 2021-07-02 09:13:24 --> Model "Templates_model" initialized
INFO - 2021-07-02 09:13:24 --> Database Driver Class Initialized
INFO - 2021-07-02 09:13:24 --> Model "Hesaplar_model" initialized
INFO - 2021-07-02 09:13:24 --> Controller Class Initialized
ERROR - 2021-07-02 12:13:24 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-02 12:13:24 --> File loaded: C:\wamp64\www\crm\application\views\permissions/add.php
INFO - 2021-07-02 12:13:24 --> Final output sent to browser
DEBUG - 2021-07-02 12:13:24 --> Total execution time: 0.1223
INFO - 2021-07-02 09:13:34 --> Config Class Initialized
INFO - 2021-07-02 09:13:34 --> Hooks Class Initialized
DEBUG - 2021-07-02 09:13:34 --> UTF-8 Support Enabled
INFO - 2021-07-02 09:13:34 --> Utf8 Class Initialized
INFO - 2021-07-02 09:13:34 --> URI Class Initialized
INFO - 2021-07-02 09:13:34 --> Router Class Initialized
INFO - 2021-07-02 09:13:34 --> Output Class Initialized
INFO - 2021-07-02 09:13:34 --> Security Class Initialized
DEBUG - 2021-07-02 09:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 09:13:34 --> Input Class Initialized
INFO - 2021-07-02 09:13:34 --> Language Class Initialized
INFO - 2021-07-02 09:13:34 --> Loader Class Initialized
INFO - 2021-07-02 09:13:34 --> Helper loaded: basic_helper
INFO - 2021-07-02 09:13:34 --> Helper loaded: url_helper
INFO - 2021-07-02 09:13:34 --> Helper loaded: file_helper
INFO - 2021-07-02 09:13:34 --> Helper loaded: form_helper
INFO - 2021-07-02 09:13:34 --> Helper loaded: cookie_helper
INFO - 2021-07-02 09:13:34 --> Helper loaded: security_helper
INFO - 2021-07-02 09:13:34 --> Helper loaded: directory_helper
INFO - 2021-07-02 09:13:34 --> Helper loaded: language_helper
INFO - 2021-07-02 09:13:34 --> Helper loaded: general_helper
INFO - 2021-07-02 09:13:34 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-02 09:13:34 --> Database Driver Class Initialized
DEBUG - 2021-07-02 09:13:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-02 09:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-02 09:13:34 --> Parser Class Initialized
INFO - 2021-07-02 09:13:34 --> Form Validation Class Initialized
INFO - 2021-07-02 09:13:34 --> Upload Class Initialized
INFO - 2021-07-02 09:13:34 --> Email Class Initialized
INFO - 2021-07-02 09:13:34 --> MY_Model class loaded
INFO - 2021-07-02 09:13:34 --> Model "Users_model" initialized
INFO - 2021-07-02 09:13:34 --> Model "Settings_model" initialized
INFO - 2021-07-02 09:13:34 --> Model "Role_permissions_model" initialized
INFO - 2021-07-02 09:13:34 --> Model "Permissions_model" initialized
INFO - 2021-07-02 09:13:34 --> Model "Roles_model" initialized
INFO - 2021-07-02 09:13:34 --> Model "Activity_model" initialized
INFO - 2021-07-02 09:13:34 --> Model "Templates_model" initialized
INFO - 2021-07-02 09:13:34 --> Database Driver Class Initialized
INFO - 2021-07-02 09:13:34 --> Model "Hesaplar_model" initialized
INFO - 2021-07-02 09:13:34 --> Controller Class Initialized
INFO - 2021-07-02 09:13:35 --> Config Class Initialized
INFO - 2021-07-02 09:13:35 --> Hooks Class Initialized
DEBUG - 2021-07-02 09:13:35 --> UTF-8 Support Enabled
INFO - 2021-07-02 09:13:35 --> Utf8 Class Initialized
INFO - 2021-07-02 09:13:35 --> URI Class Initialized
INFO - 2021-07-02 09:13:35 --> Router Class Initialized
INFO - 2021-07-02 09:13:35 --> Output Class Initialized
INFO - 2021-07-02 09:13:35 --> Security Class Initialized
DEBUG - 2021-07-02 09:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 09:13:35 --> Input Class Initialized
INFO - 2021-07-02 09:13:35 --> Language Class Initialized
INFO - 2021-07-02 09:13:35 --> Loader Class Initialized
INFO - 2021-07-02 09:13:35 --> Helper loaded: basic_helper
INFO - 2021-07-02 09:13:35 --> Helper loaded: url_helper
INFO - 2021-07-02 09:13:35 --> Helper loaded: file_helper
INFO - 2021-07-02 09:13:35 --> Helper loaded: form_helper
INFO - 2021-07-02 09:13:35 --> Helper loaded: cookie_helper
INFO - 2021-07-02 09:13:35 --> Helper loaded: security_helper
INFO - 2021-07-02 09:13:35 --> Helper loaded: directory_helper
INFO - 2021-07-02 09:13:35 --> Helper loaded: language_helper
INFO - 2021-07-02 09:13:35 --> Helper loaded: general_helper
INFO - 2021-07-02 09:13:35 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-02 09:13:35 --> Database Driver Class Initialized
DEBUG - 2021-07-02 09:13:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-02 09:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-02 09:13:35 --> Parser Class Initialized
INFO - 2021-07-02 09:13:35 --> Form Validation Class Initialized
INFO - 2021-07-02 09:13:35 --> Upload Class Initialized
INFO - 2021-07-02 09:13:35 --> Email Class Initialized
INFO - 2021-07-02 09:13:35 --> MY_Model class loaded
INFO - 2021-07-02 09:13:35 --> Model "Users_model" initialized
INFO - 2021-07-02 09:13:35 --> Model "Settings_model" initialized
INFO - 2021-07-02 09:13:35 --> Model "Role_permissions_model" initialized
INFO - 2021-07-02 09:13:35 --> Model "Permissions_model" initialized
INFO - 2021-07-02 09:13:35 --> Model "Roles_model" initialized
INFO - 2021-07-02 09:13:35 --> Model "Activity_model" initialized
INFO - 2021-07-02 09:13:35 --> Model "Templates_model" initialized
INFO - 2021-07-02 09:13:35 --> Database Driver Class Initialized
INFO - 2021-07-02 09:13:35 --> Model "Hesaplar_model" initialized
INFO - 2021-07-02 09:13:35 --> Controller Class Initialized
INFO - 2021-07-02 09:13:35 --> Config Class Initialized
INFO - 2021-07-02 09:13:35 --> Hooks Class Initialized
DEBUG - 2021-07-02 09:13:35 --> UTF-8 Support Enabled
INFO - 2021-07-02 09:13:35 --> Utf8 Class Initialized
INFO - 2021-07-02 09:13:35 --> URI Class Initialized
INFO - 2021-07-02 09:13:35 --> Router Class Initialized
INFO - 2021-07-02 09:13:35 --> Output Class Initialized
INFO - 2021-07-02 09:13:35 --> Security Class Initialized
DEBUG - 2021-07-02 09:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 09:13:35 --> Input Class Initialized
INFO - 2021-07-02 09:13:35 --> Language Class Initialized
INFO - 2021-07-02 09:13:35 --> Loader Class Initialized
INFO - 2021-07-02 09:13:35 --> Helper loaded: basic_helper
INFO - 2021-07-02 09:13:35 --> Helper loaded: url_helper
INFO - 2021-07-02 09:13:35 --> Helper loaded: file_helper
INFO - 2021-07-02 09:13:35 --> Helper loaded: form_helper
INFO - 2021-07-02 09:13:35 --> Helper loaded: cookie_helper
INFO - 2021-07-02 09:13:35 --> Helper loaded: security_helper
INFO - 2021-07-02 09:13:35 --> Helper loaded: directory_helper
INFO - 2021-07-02 09:13:35 --> Helper loaded: language_helper
INFO - 2021-07-02 09:13:35 --> Helper loaded: general_helper
INFO - 2021-07-02 09:13:35 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-02 09:13:35 --> Database Driver Class Initialized
DEBUG - 2021-07-02 09:13:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-02 09:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-02 09:13:35 --> Parser Class Initialized
INFO - 2021-07-02 09:13:35 --> Form Validation Class Initialized
INFO - 2021-07-02 09:13:35 --> Upload Class Initialized
INFO - 2021-07-02 09:13:35 --> Email Class Initialized
INFO - 2021-07-02 09:13:35 --> MY_Model class loaded
INFO - 2021-07-02 09:13:35 --> Model "Users_model" initialized
INFO - 2021-07-02 09:13:35 --> Model "Settings_model" initialized
INFO - 2021-07-02 09:13:35 --> Model "Role_permissions_model" initialized
INFO - 2021-07-02 09:13:35 --> Model "Permissions_model" initialized
INFO - 2021-07-02 09:13:35 --> Model "Roles_model" initialized
INFO - 2021-07-02 09:13:35 --> Model "Activity_model" initialized
INFO - 2021-07-02 09:13:35 --> Model "Templates_model" initialized
INFO - 2021-07-02 09:13:35 --> Database Driver Class Initialized
INFO - 2021-07-02 09:13:35 --> Model "Hesaplar_model" initialized
INFO - 2021-07-02 09:13:35 --> Controller Class Initialized
ERROR - 2021-07-02 12:13:35 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-02 12:13:35 --> File loaded: C:\wamp64\www\crm\application\views\permissions/list.php
INFO - 2021-07-02 12:13:35 --> Final output sent to browser
DEBUG - 2021-07-02 12:13:35 --> Total execution time: 0.1006
INFO - 2021-07-02 09:13:38 --> Config Class Initialized
INFO - 2021-07-02 09:13:38 --> Hooks Class Initialized
DEBUG - 2021-07-02 09:13:38 --> UTF-8 Support Enabled
INFO - 2021-07-02 09:13:38 --> Utf8 Class Initialized
INFO - 2021-07-02 09:13:38 --> URI Class Initialized
INFO - 2021-07-02 09:13:38 --> Router Class Initialized
INFO - 2021-07-02 09:13:38 --> Output Class Initialized
INFO - 2021-07-02 09:13:38 --> Security Class Initialized
DEBUG - 2021-07-02 09:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 09:13:38 --> Input Class Initialized
INFO - 2021-07-02 09:13:38 --> Language Class Initialized
INFO - 2021-07-02 09:13:38 --> Loader Class Initialized
INFO - 2021-07-02 09:13:38 --> Helper loaded: basic_helper
INFO - 2021-07-02 09:13:38 --> Helper loaded: url_helper
INFO - 2021-07-02 09:13:38 --> Helper loaded: file_helper
INFO - 2021-07-02 09:13:38 --> Helper loaded: form_helper
INFO - 2021-07-02 09:13:38 --> Helper loaded: cookie_helper
INFO - 2021-07-02 09:13:38 --> Helper loaded: security_helper
INFO - 2021-07-02 09:13:38 --> Helper loaded: directory_helper
INFO - 2021-07-02 09:13:38 --> Helper loaded: language_helper
INFO - 2021-07-02 09:13:38 --> Helper loaded: general_helper
INFO - 2021-07-02 09:13:38 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-02 09:13:38 --> Database Driver Class Initialized
DEBUG - 2021-07-02 09:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-02 09:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-02 09:13:38 --> Parser Class Initialized
INFO - 2021-07-02 09:13:38 --> Form Validation Class Initialized
INFO - 2021-07-02 09:13:38 --> Upload Class Initialized
INFO - 2021-07-02 09:13:38 --> Email Class Initialized
INFO - 2021-07-02 09:13:38 --> MY_Model class loaded
INFO - 2021-07-02 09:13:38 --> Model "Users_model" initialized
INFO - 2021-07-02 09:13:38 --> Model "Settings_model" initialized
INFO - 2021-07-02 09:13:38 --> Model "Role_permissions_model" initialized
INFO - 2021-07-02 09:13:38 --> Model "Permissions_model" initialized
INFO - 2021-07-02 09:13:38 --> Model "Roles_model" initialized
INFO - 2021-07-02 09:13:38 --> Model "Activity_model" initialized
INFO - 2021-07-02 09:13:38 --> Model "Templates_model" initialized
INFO - 2021-07-02 09:13:38 --> Database Driver Class Initialized
INFO - 2021-07-02 09:13:38 --> Model "Hesaplar_model" initialized
INFO - 2021-07-02 09:13:38 --> Controller Class Initialized
ERROR - 2021-07-02 12:13:38 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-02 12:13:38 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-02 12:13:38 --> Final output sent to browser
DEBUG - 2021-07-02 12:13:38 --> Total execution time: 0.2256
INFO - 2021-07-02 09:19:48 --> Config Class Initialized
INFO - 2021-07-02 09:19:48 --> Hooks Class Initialized
DEBUG - 2021-07-02 09:19:48 --> UTF-8 Support Enabled
INFO - 2021-07-02 09:19:48 --> Utf8 Class Initialized
INFO - 2021-07-02 09:19:48 --> URI Class Initialized
INFO - 2021-07-02 09:19:48 --> Router Class Initialized
INFO - 2021-07-02 09:19:48 --> Output Class Initialized
INFO - 2021-07-02 09:19:48 --> Security Class Initialized
DEBUG - 2021-07-02 09:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 09:19:48 --> Input Class Initialized
INFO - 2021-07-02 09:19:48 --> Language Class Initialized
INFO - 2021-07-02 09:19:48 --> Loader Class Initialized
INFO - 2021-07-02 09:19:48 --> Helper loaded: basic_helper
INFO - 2021-07-02 09:19:48 --> Helper loaded: url_helper
INFO - 2021-07-02 09:19:48 --> Helper loaded: file_helper
INFO - 2021-07-02 09:19:48 --> Helper loaded: form_helper
INFO - 2021-07-02 09:19:48 --> Helper loaded: cookie_helper
INFO - 2021-07-02 09:19:48 --> Helper loaded: security_helper
INFO - 2021-07-02 09:19:48 --> Helper loaded: directory_helper
INFO - 2021-07-02 09:19:48 --> Helper loaded: language_helper
INFO - 2021-07-02 09:19:48 --> Helper loaded: general_helper
INFO - 2021-07-02 09:19:48 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-02 09:19:48 --> Database Driver Class Initialized
DEBUG - 2021-07-02 09:19:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-02 09:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-02 09:19:48 --> Parser Class Initialized
INFO - 2021-07-02 09:19:48 --> Form Validation Class Initialized
INFO - 2021-07-02 09:19:48 --> Upload Class Initialized
INFO - 2021-07-02 09:19:48 --> Email Class Initialized
INFO - 2021-07-02 09:19:48 --> MY_Model class loaded
INFO - 2021-07-02 09:19:48 --> Model "Users_model" initialized
INFO - 2021-07-02 09:19:48 --> Model "Settings_model" initialized
INFO - 2021-07-02 09:19:48 --> Model "Role_permissions_model" initialized
INFO - 2021-07-02 09:19:48 --> Model "Permissions_model" initialized
INFO - 2021-07-02 09:19:48 --> Model "Roles_model" initialized
INFO - 2021-07-02 09:19:48 --> Model "Activity_model" initialized
INFO - 2021-07-02 09:19:48 --> Model "Templates_model" initialized
INFO - 2021-07-02 09:19:48 --> Database Driver Class Initialized
INFO - 2021-07-02 09:19:49 --> Model "Hesaplar_model" initialized
INFO - 2021-07-02 09:19:49 --> Controller Class Initialized
ERROR - 2021-07-02 12:19:49 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-02 12:19:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\crm\application\views\hesaplar\rapor_ayrinti.php 30
INFO - 2021-07-02 12:19:49 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-02 12:19:49 --> Final output sent to browser
DEBUG - 2021-07-02 12:19:49 --> Total execution time: 0.5506
INFO - 2021-07-02 09:26:06 --> Config Class Initialized
INFO - 2021-07-02 09:26:06 --> Hooks Class Initialized
DEBUG - 2021-07-02 09:26:06 --> UTF-8 Support Enabled
INFO - 2021-07-02 09:26:06 --> Utf8 Class Initialized
INFO - 2021-07-02 09:26:06 --> URI Class Initialized
DEBUG - 2021-07-02 09:26:06 --> No URI present. Default controller set.
INFO - 2021-07-02 09:26:06 --> Router Class Initialized
INFO - 2021-07-02 09:26:06 --> Output Class Initialized
INFO - 2021-07-02 09:26:06 --> Security Class Initialized
DEBUG - 2021-07-02 09:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 09:26:06 --> Input Class Initialized
INFO - 2021-07-02 09:26:06 --> Language Class Initialized
INFO - 2021-07-02 09:26:06 --> Loader Class Initialized
INFO - 2021-07-02 09:26:06 --> Helper loaded: basic_helper
INFO - 2021-07-02 09:26:06 --> Helper loaded: url_helper
INFO - 2021-07-02 09:26:06 --> Helper loaded: file_helper
INFO - 2021-07-02 09:26:06 --> Helper loaded: form_helper
INFO - 2021-07-02 09:26:06 --> Helper loaded: cookie_helper
INFO - 2021-07-02 09:26:06 --> Helper loaded: security_helper
INFO - 2021-07-02 09:26:06 --> Helper loaded: directory_helper
INFO - 2021-07-02 09:26:06 --> Helper loaded: language_helper
INFO - 2021-07-02 09:26:06 --> Helper loaded: general_helper
INFO - 2021-07-02 09:26:06 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-02 09:26:06 --> Database Driver Class Initialized
DEBUG - 2021-07-02 09:26:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-02 09:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-02 09:26:06 --> Parser Class Initialized
INFO - 2021-07-02 09:26:06 --> Form Validation Class Initialized
INFO - 2021-07-02 09:26:06 --> Upload Class Initialized
INFO - 2021-07-02 09:26:06 --> Email Class Initialized
INFO - 2021-07-02 09:26:06 --> MY_Model class loaded
INFO - 2021-07-02 09:26:06 --> Model "Users_model" initialized
INFO - 2021-07-02 09:26:06 --> Model "Settings_model" initialized
INFO - 2021-07-02 09:26:06 --> Model "Role_permissions_model" initialized
INFO - 2021-07-02 09:26:06 --> Model "Permissions_model" initialized
INFO - 2021-07-02 09:26:06 --> Model "Roles_model" initialized
INFO - 2021-07-02 09:26:06 --> Model "Activity_model" initialized
INFO - 2021-07-02 09:26:06 --> Model "Templates_model" initialized
INFO - 2021-07-02 09:26:06 --> Database Driver Class Initialized
INFO - 2021-07-02 09:26:06 --> Model "Hesaplar_model" initialized
INFO - 2021-07-02 09:26:06 --> Controller Class Initialized
INFO - 2021-07-02 09:39:08 --> Config Class Initialized
INFO - 2021-07-02 09:39:08 --> Hooks Class Initialized
DEBUG - 2021-07-02 09:39:08 --> UTF-8 Support Enabled
INFO - 2021-07-02 09:39:08 --> Utf8 Class Initialized
INFO - 2021-07-02 09:39:08 --> URI Class Initialized
INFO - 2021-07-02 09:39:08 --> Router Class Initialized
INFO - 2021-07-02 09:39:08 --> Output Class Initialized
INFO - 2021-07-02 09:39:08 --> Security Class Initialized
DEBUG - 2021-07-02 09:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 09:39:08 --> Input Class Initialized
INFO - 2021-07-02 09:39:08 --> Language Class Initialized
INFO - 2021-07-02 09:39:08 --> Loader Class Initialized
INFO - 2021-07-02 09:39:08 --> Helper loaded: basic_helper
INFO - 2021-07-02 09:39:08 --> Helper loaded: url_helper
INFO - 2021-07-02 09:39:08 --> Helper loaded: file_helper
INFO - 2021-07-02 09:39:08 --> Helper loaded: form_helper
INFO - 2021-07-02 09:39:08 --> Helper loaded: cookie_helper
INFO - 2021-07-02 09:39:08 --> Helper loaded: security_helper
INFO - 2021-07-02 09:39:08 --> Helper loaded: directory_helper
INFO - 2021-07-02 09:39:08 --> Helper loaded: language_helper
INFO - 2021-07-02 09:39:08 --> Helper loaded: general_helper
INFO - 2021-07-02 09:39:08 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-02 09:39:08 --> Database Driver Class Initialized
DEBUG - 2021-07-02 09:39:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-02 09:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-02 09:39:08 --> Parser Class Initialized
INFO - 2021-07-02 09:39:08 --> Form Validation Class Initialized
INFO - 2021-07-02 09:39:08 --> Upload Class Initialized
INFO - 2021-07-02 09:39:08 --> Email Class Initialized
INFO - 2021-07-02 09:39:08 --> MY_Model class loaded
INFO - 2021-07-02 09:39:08 --> Model "Users_model" initialized
INFO - 2021-07-02 09:39:08 --> Model "Settings_model" initialized
INFO - 2021-07-02 09:39:08 --> Model "Role_permissions_model" initialized
INFO - 2021-07-02 09:39:08 --> Model "Permissions_model" initialized
INFO - 2021-07-02 09:39:08 --> Model "Roles_model" initialized
INFO - 2021-07-02 09:39:08 --> Model "Activity_model" initialized
INFO - 2021-07-02 09:39:08 --> Model "Templates_model" initialized
INFO - 2021-07-02 09:39:08 --> Database Driver Class Initialized
INFO - 2021-07-02 09:39:08 --> Model "Hesaplar_model" initialized
INFO - 2021-07-02 09:39:08 --> Controller Class Initialized
ERROR - 2021-07-02 12:39:08 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-02 12:39:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\crm\application\views\hesaplar\rapor_ayrinti.php 53
INFO - 2021-07-02 12:39:08 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-02 12:39:08 --> Final output sent to browser
DEBUG - 2021-07-02 12:39:08 --> Total execution time: 0.1282
INFO - 2021-07-02 09:39:11 --> Config Class Initialized
INFO - 2021-07-02 09:39:11 --> Hooks Class Initialized
DEBUG - 2021-07-02 09:39:11 --> UTF-8 Support Enabled
INFO - 2021-07-02 09:39:11 --> Utf8 Class Initialized
INFO - 2021-07-02 09:39:11 --> URI Class Initialized
INFO - 2021-07-02 09:39:11 --> Router Class Initialized
INFO - 2021-07-02 09:39:11 --> Output Class Initialized
INFO - 2021-07-02 09:39:11 --> Security Class Initialized
DEBUG - 2021-07-02 09:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 09:39:11 --> Input Class Initialized
INFO - 2021-07-02 09:39:11 --> Language Class Initialized
INFO - 2021-07-02 09:39:11 --> Loader Class Initialized
INFO - 2021-07-02 09:39:11 --> Helper loaded: basic_helper
INFO - 2021-07-02 09:39:11 --> Helper loaded: url_helper
INFO - 2021-07-02 09:39:11 --> Helper loaded: file_helper
INFO - 2021-07-02 09:39:11 --> Helper loaded: form_helper
INFO - 2021-07-02 09:39:11 --> Helper loaded: cookie_helper
INFO - 2021-07-02 09:39:11 --> Helper loaded: security_helper
INFO - 2021-07-02 09:39:11 --> Helper loaded: directory_helper
INFO - 2021-07-02 09:39:11 --> Helper loaded: language_helper
INFO - 2021-07-02 09:39:11 --> Helper loaded: general_helper
INFO - 2021-07-02 09:39:11 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-02 09:39:11 --> Database Driver Class Initialized
DEBUG - 2021-07-02 09:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-02 09:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-02 09:39:11 --> Parser Class Initialized
INFO - 2021-07-02 09:39:11 --> Form Validation Class Initialized
INFO - 2021-07-02 09:39:11 --> Upload Class Initialized
INFO - 2021-07-02 09:39:11 --> Email Class Initialized
INFO - 2021-07-02 09:39:11 --> MY_Model class loaded
INFO - 2021-07-02 09:39:11 --> Model "Users_model" initialized
INFO - 2021-07-02 09:39:11 --> Model "Settings_model" initialized
INFO - 2021-07-02 09:39:11 --> Model "Role_permissions_model" initialized
INFO - 2021-07-02 09:39:11 --> Model "Permissions_model" initialized
INFO - 2021-07-02 09:39:11 --> Model "Roles_model" initialized
INFO - 2021-07-02 09:39:11 --> Model "Activity_model" initialized
INFO - 2021-07-02 09:39:11 --> Model "Templates_model" initialized
INFO - 2021-07-02 09:39:11 --> Database Driver Class Initialized
INFO - 2021-07-02 09:39:11 --> Model "Hesaplar_model" initialized
INFO - 2021-07-02 09:39:11 --> Controller Class Initialized
ERROR - 2021-07-02 12:39:11 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-02 12:39:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\crm\application\views\hesaplar\rapor_ayrinti.php 53
INFO - 2021-07-02 12:39:11 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-02 12:39:11 --> Final output sent to browser
DEBUG - 2021-07-02 12:39:11 --> Total execution time: 0.0866
INFO - 2021-07-02 09:40:09 --> Config Class Initialized
INFO - 2021-07-02 09:40:09 --> Hooks Class Initialized
DEBUG - 2021-07-02 09:40:09 --> UTF-8 Support Enabled
INFO - 2021-07-02 09:40:09 --> Utf8 Class Initialized
INFO - 2021-07-02 09:40:09 --> URI Class Initialized
INFO - 2021-07-02 09:40:09 --> Router Class Initialized
INFO - 2021-07-02 09:40:09 --> Output Class Initialized
INFO - 2021-07-02 09:40:09 --> Security Class Initialized
DEBUG - 2021-07-02 09:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 09:40:09 --> Input Class Initialized
INFO - 2021-07-02 09:40:09 --> Language Class Initialized
INFO - 2021-07-02 09:40:09 --> Loader Class Initialized
INFO - 2021-07-02 09:40:09 --> Helper loaded: basic_helper
INFO - 2021-07-02 09:40:09 --> Helper loaded: url_helper
INFO - 2021-07-02 09:40:09 --> Helper loaded: file_helper
INFO - 2021-07-02 09:40:09 --> Helper loaded: form_helper
INFO - 2021-07-02 09:40:09 --> Helper loaded: cookie_helper
INFO - 2021-07-02 09:40:09 --> Helper loaded: security_helper
INFO - 2021-07-02 09:40:09 --> Helper loaded: directory_helper
INFO - 2021-07-02 09:40:09 --> Helper loaded: language_helper
INFO - 2021-07-02 09:40:09 --> Helper loaded: general_helper
INFO - 2021-07-02 09:40:09 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-02 09:40:09 --> Database Driver Class Initialized
DEBUG - 2021-07-02 09:40:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-02 09:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-02 09:40:09 --> Parser Class Initialized
INFO - 2021-07-02 09:40:09 --> Form Validation Class Initialized
INFO - 2021-07-02 09:40:09 --> Upload Class Initialized
INFO - 2021-07-02 09:40:09 --> Email Class Initialized
INFO - 2021-07-02 09:40:09 --> MY_Model class loaded
INFO - 2021-07-02 09:40:09 --> Model "Users_model" initialized
INFO - 2021-07-02 09:40:09 --> Model "Settings_model" initialized
INFO - 2021-07-02 09:40:09 --> Model "Role_permissions_model" initialized
INFO - 2021-07-02 09:40:09 --> Model "Permissions_model" initialized
INFO - 2021-07-02 09:40:09 --> Model "Roles_model" initialized
INFO - 2021-07-02 09:40:09 --> Model "Activity_model" initialized
INFO - 2021-07-02 09:40:09 --> Model "Templates_model" initialized
INFO - 2021-07-02 09:40:09 --> Database Driver Class Initialized
INFO - 2021-07-02 09:40:09 --> Model "Hesaplar_model" initialized
INFO - 2021-07-02 09:40:09 --> Controller Class Initialized
ERROR - 2021-07-02 12:40:09 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-02 12:40:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\crm\application\views\hesaplar\rapor_ayrinti.php 53
INFO - 2021-07-02 12:40:09 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-02 12:40:09 --> Final output sent to browser
DEBUG - 2021-07-02 12:40:09 --> Total execution time: 0.1218
INFO - 2021-07-02 09:40:32 --> Config Class Initialized
INFO - 2021-07-02 09:40:32 --> Hooks Class Initialized
DEBUG - 2021-07-02 09:40:32 --> UTF-8 Support Enabled
INFO - 2021-07-02 09:40:32 --> Utf8 Class Initialized
INFO - 2021-07-02 09:40:32 --> URI Class Initialized
INFO - 2021-07-02 09:40:32 --> Router Class Initialized
INFO - 2021-07-02 09:40:32 --> Output Class Initialized
INFO - 2021-07-02 09:40:32 --> Security Class Initialized
DEBUG - 2021-07-02 09:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 09:40:32 --> Input Class Initialized
INFO - 2021-07-02 09:40:32 --> Language Class Initialized
INFO - 2021-07-02 09:40:32 --> Loader Class Initialized
INFO - 2021-07-02 09:40:32 --> Helper loaded: basic_helper
INFO - 2021-07-02 09:40:32 --> Helper loaded: url_helper
INFO - 2021-07-02 09:40:32 --> Helper loaded: file_helper
INFO - 2021-07-02 09:40:32 --> Helper loaded: form_helper
INFO - 2021-07-02 09:40:32 --> Helper loaded: cookie_helper
INFO - 2021-07-02 09:40:32 --> Helper loaded: security_helper
INFO - 2021-07-02 09:40:32 --> Helper loaded: directory_helper
INFO - 2021-07-02 09:40:32 --> Helper loaded: language_helper
INFO - 2021-07-02 09:40:32 --> Helper loaded: general_helper
INFO - 2021-07-02 09:40:32 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-02 09:40:32 --> Database Driver Class Initialized
DEBUG - 2021-07-02 09:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-02 09:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-02 09:40:32 --> Parser Class Initialized
INFO - 2021-07-02 09:40:32 --> Form Validation Class Initialized
INFO - 2021-07-02 09:40:32 --> Upload Class Initialized
INFO - 2021-07-02 09:40:32 --> Email Class Initialized
INFO - 2021-07-02 09:40:32 --> MY_Model class loaded
INFO - 2021-07-02 09:40:32 --> Model "Users_model" initialized
INFO - 2021-07-02 09:40:32 --> Model "Settings_model" initialized
INFO - 2021-07-02 09:40:32 --> Model "Role_permissions_model" initialized
INFO - 2021-07-02 09:40:32 --> Model "Permissions_model" initialized
INFO - 2021-07-02 09:40:32 --> Model "Roles_model" initialized
INFO - 2021-07-02 09:40:32 --> Model "Activity_model" initialized
INFO - 2021-07-02 09:40:32 --> Model "Templates_model" initialized
INFO - 2021-07-02 09:40:32 --> Database Driver Class Initialized
INFO - 2021-07-02 09:40:32 --> Model "Hesaplar_model" initialized
INFO - 2021-07-02 09:40:32 --> Controller Class Initialized
ERROR - 2021-07-02 12:40:32 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-02 12:40:32 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-02 12:40:32 --> Final output sent to browser
DEBUG - 2021-07-02 12:40:32 --> Total execution time: 0.1725
INFO - 2021-07-02 09:40:33 --> Config Class Initialized
INFO - 2021-07-02 09:40:33 --> Hooks Class Initialized
DEBUG - 2021-07-02 09:40:33 --> UTF-8 Support Enabled
INFO - 2021-07-02 09:40:33 --> Utf8 Class Initialized
INFO - 2021-07-02 09:40:33 --> URI Class Initialized
INFO - 2021-07-02 09:40:33 --> Router Class Initialized
INFO - 2021-07-02 09:40:33 --> Output Class Initialized
INFO - 2021-07-02 09:40:33 --> Security Class Initialized
DEBUG - 2021-07-02 09:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 09:40:33 --> Input Class Initialized
INFO - 2021-07-02 09:40:33 --> Language Class Initialized
INFO - 2021-07-02 09:40:33 --> Loader Class Initialized
INFO - 2021-07-02 09:40:33 --> Helper loaded: basic_helper
INFO - 2021-07-02 09:40:33 --> Helper loaded: url_helper
INFO - 2021-07-02 09:40:33 --> Helper loaded: file_helper
INFO - 2021-07-02 09:40:33 --> Helper loaded: form_helper
INFO - 2021-07-02 09:40:33 --> Helper loaded: cookie_helper
INFO - 2021-07-02 09:40:33 --> Helper loaded: security_helper
INFO - 2021-07-02 09:40:33 --> Helper loaded: directory_helper
INFO - 2021-07-02 09:40:33 --> Helper loaded: language_helper
INFO - 2021-07-02 09:40:33 --> Helper loaded: general_helper
INFO - 2021-07-02 09:40:33 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-02 09:40:33 --> Database Driver Class Initialized
DEBUG - 2021-07-02 09:40:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-02 09:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-02 09:40:33 --> Parser Class Initialized
INFO - 2021-07-02 09:40:33 --> Form Validation Class Initialized
INFO - 2021-07-02 09:40:33 --> Upload Class Initialized
INFO - 2021-07-02 09:40:33 --> Email Class Initialized
INFO - 2021-07-02 09:40:33 --> MY_Model class loaded
INFO - 2021-07-02 09:40:33 --> Model "Users_model" initialized
INFO - 2021-07-02 09:40:33 --> Model "Settings_model" initialized
INFO - 2021-07-02 09:40:33 --> Model "Role_permissions_model" initialized
INFO - 2021-07-02 09:40:33 --> Model "Permissions_model" initialized
INFO - 2021-07-02 09:40:33 --> Model "Roles_model" initialized
INFO - 2021-07-02 09:40:33 --> Model "Activity_model" initialized
INFO - 2021-07-02 09:40:33 --> Model "Templates_model" initialized
INFO - 2021-07-02 09:40:33 --> Database Driver Class Initialized
INFO - 2021-07-02 09:40:33 --> Model "Hesaplar_model" initialized
INFO - 2021-07-02 09:40:33 --> Controller Class Initialized
ERROR - 2021-07-02 12:40:33 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-02 12:40:33 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-02 12:40:33 --> Final output sent to browser
DEBUG - 2021-07-02 12:40:33 --> Total execution time: 0.0599
INFO - 2021-07-02 09:40:35 --> Config Class Initialized
INFO - 2021-07-02 09:40:35 --> Hooks Class Initialized
DEBUG - 2021-07-02 09:40:35 --> UTF-8 Support Enabled
INFO - 2021-07-02 09:40:35 --> Utf8 Class Initialized
INFO - 2021-07-02 09:40:35 --> URI Class Initialized
INFO - 2021-07-02 09:40:35 --> Router Class Initialized
INFO - 2021-07-02 09:40:35 --> Output Class Initialized
INFO - 2021-07-02 09:40:35 --> Security Class Initialized
DEBUG - 2021-07-02 09:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 09:40:35 --> Input Class Initialized
INFO - 2021-07-02 09:40:35 --> Language Class Initialized
INFO - 2021-07-02 09:40:35 --> Loader Class Initialized
INFO - 2021-07-02 09:40:35 --> Helper loaded: basic_helper
INFO - 2021-07-02 09:40:35 --> Helper loaded: url_helper
INFO - 2021-07-02 09:40:35 --> Helper loaded: file_helper
INFO - 2021-07-02 09:40:35 --> Helper loaded: form_helper
INFO - 2021-07-02 09:40:35 --> Helper loaded: cookie_helper
INFO - 2021-07-02 09:40:35 --> Helper loaded: security_helper
INFO - 2021-07-02 09:40:35 --> Helper loaded: directory_helper
INFO - 2021-07-02 09:40:35 --> Helper loaded: language_helper
INFO - 2021-07-02 09:40:35 --> Helper loaded: general_helper
INFO - 2021-07-02 09:40:35 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-02 09:40:35 --> Database Driver Class Initialized
DEBUG - 2021-07-02 09:40:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-02 09:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-02 09:40:35 --> Parser Class Initialized
INFO - 2021-07-02 09:40:35 --> Form Validation Class Initialized
INFO - 2021-07-02 09:40:35 --> Upload Class Initialized
INFO - 2021-07-02 09:40:35 --> Email Class Initialized
INFO - 2021-07-02 09:40:35 --> MY_Model class loaded
INFO - 2021-07-02 09:40:35 --> Model "Users_model" initialized
INFO - 2021-07-02 09:40:35 --> Model "Settings_model" initialized
INFO - 2021-07-02 09:40:35 --> Model "Role_permissions_model" initialized
INFO - 2021-07-02 09:40:35 --> Model "Permissions_model" initialized
INFO - 2021-07-02 09:40:35 --> Model "Roles_model" initialized
INFO - 2021-07-02 09:40:35 --> Model "Activity_model" initialized
INFO - 2021-07-02 09:40:35 --> Model "Templates_model" initialized
INFO - 2021-07-02 09:40:35 --> Database Driver Class Initialized
INFO - 2021-07-02 09:40:35 --> Model "Hesaplar_model" initialized
INFO - 2021-07-02 09:40:35 --> Controller Class Initialized
ERROR - 2021-07-02 12:40:35 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-02 12:40:35 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-02 12:40:35 --> Final output sent to browser
DEBUG - 2021-07-02 12:40:35 --> Total execution time: 0.0647
INFO - 2021-07-02 09:40:38 --> Config Class Initialized
INFO - 2021-07-02 09:40:38 --> Hooks Class Initialized
DEBUG - 2021-07-02 09:40:38 --> UTF-8 Support Enabled
INFO - 2021-07-02 09:40:38 --> Utf8 Class Initialized
INFO - 2021-07-02 09:40:38 --> URI Class Initialized
INFO - 2021-07-02 09:40:38 --> Router Class Initialized
INFO - 2021-07-02 09:40:38 --> Output Class Initialized
INFO - 2021-07-02 09:40:38 --> Security Class Initialized
DEBUG - 2021-07-02 09:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 09:40:38 --> Input Class Initialized
INFO - 2021-07-02 09:40:38 --> Language Class Initialized
INFO - 2021-07-02 09:40:38 --> Loader Class Initialized
INFO - 2021-07-02 09:40:38 --> Helper loaded: basic_helper
INFO - 2021-07-02 09:40:38 --> Helper loaded: url_helper
INFO - 2021-07-02 09:40:38 --> Helper loaded: file_helper
INFO - 2021-07-02 09:40:38 --> Helper loaded: form_helper
INFO - 2021-07-02 09:40:38 --> Helper loaded: cookie_helper
INFO - 2021-07-02 09:40:38 --> Helper loaded: security_helper
INFO - 2021-07-02 09:40:38 --> Helper loaded: directory_helper
INFO - 2021-07-02 09:40:38 --> Helper loaded: language_helper
INFO - 2021-07-02 09:40:38 --> Helper loaded: general_helper
INFO - 2021-07-02 09:40:38 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-02 09:40:38 --> Database Driver Class Initialized
DEBUG - 2021-07-02 09:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-02 09:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-02 09:40:38 --> Parser Class Initialized
INFO - 2021-07-02 09:40:38 --> Form Validation Class Initialized
INFO - 2021-07-02 09:40:38 --> Upload Class Initialized
INFO - 2021-07-02 09:40:38 --> Email Class Initialized
INFO - 2021-07-02 09:40:38 --> MY_Model class loaded
INFO - 2021-07-02 09:40:38 --> Model "Users_model" initialized
INFO - 2021-07-02 09:40:38 --> Model "Settings_model" initialized
INFO - 2021-07-02 09:40:38 --> Model "Role_permissions_model" initialized
INFO - 2021-07-02 09:40:38 --> Model "Permissions_model" initialized
INFO - 2021-07-02 09:40:38 --> Model "Roles_model" initialized
INFO - 2021-07-02 09:40:38 --> Model "Activity_model" initialized
INFO - 2021-07-02 09:40:38 --> Model "Templates_model" initialized
INFO - 2021-07-02 09:40:38 --> Database Driver Class Initialized
INFO - 2021-07-02 09:40:38 --> Model "Hesaplar_model" initialized
INFO - 2021-07-02 09:40:38 --> Controller Class Initialized
ERROR - 2021-07-02 12:40:38 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-02 12:40:38 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-02 12:40:38 --> Final output sent to browser
DEBUG - 2021-07-02 12:40:38 --> Total execution time: 0.1475
INFO - 2021-07-02 09:40:41 --> Config Class Initialized
INFO - 2021-07-02 09:40:41 --> Hooks Class Initialized
DEBUG - 2021-07-02 09:40:41 --> UTF-8 Support Enabled
INFO - 2021-07-02 09:40:41 --> Utf8 Class Initialized
INFO - 2021-07-02 09:40:41 --> URI Class Initialized
INFO - 2021-07-02 09:40:41 --> Router Class Initialized
INFO - 2021-07-02 09:40:41 --> Output Class Initialized
INFO - 2021-07-02 09:40:41 --> Security Class Initialized
DEBUG - 2021-07-02 09:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 09:40:41 --> Input Class Initialized
INFO - 2021-07-02 09:40:41 --> Language Class Initialized
INFO - 2021-07-02 09:40:41 --> Loader Class Initialized
INFO - 2021-07-02 09:40:41 --> Helper loaded: basic_helper
INFO - 2021-07-02 09:40:41 --> Helper loaded: url_helper
INFO - 2021-07-02 09:40:41 --> Helper loaded: file_helper
INFO - 2021-07-02 09:40:41 --> Helper loaded: form_helper
INFO - 2021-07-02 09:40:41 --> Helper loaded: cookie_helper
INFO - 2021-07-02 09:40:41 --> Helper loaded: security_helper
INFO - 2021-07-02 09:40:41 --> Helper loaded: directory_helper
INFO - 2021-07-02 09:40:41 --> Helper loaded: language_helper
INFO - 2021-07-02 09:40:41 --> Helper loaded: general_helper
INFO - 2021-07-02 09:40:41 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-02 09:40:41 --> Database Driver Class Initialized
DEBUG - 2021-07-02 09:40:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-02 09:40:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-02 09:40:41 --> Parser Class Initialized
INFO - 2021-07-02 09:40:41 --> Form Validation Class Initialized
INFO - 2021-07-02 09:40:41 --> Upload Class Initialized
INFO - 2021-07-02 09:40:41 --> Email Class Initialized
INFO - 2021-07-02 09:40:41 --> MY_Model class loaded
INFO - 2021-07-02 09:40:41 --> Model "Users_model" initialized
INFO - 2021-07-02 09:40:41 --> Model "Settings_model" initialized
INFO - 2021-07-02 09:40:41 --> Model "Role_permissions_model" initialized
INFO - 2021-07-02 09:40:41 --> Model "Permissions_model" initialized
INFO - 2021-07-02 09:40:41 --> Model "Roles_model" initialized
INFO - 2021-07-02 09:40:41 --> Model "Activity_model" initialized
INFO - 2021-07-02 09:40:41 --> Model "Templates_model" initialized
INFO - 2021-07-02 09:40:41 --> Database Driver Class Initialized
INFO - 2021-07-02 09:40:41 --> Model "Hesaplar_model" initialized
INFO - 2021-07-02 09:40:41 --> Controller Class Initialized
ERROR - 2021-07-02 12:40:41 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-02 12:40:41 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-02 12:40:41 --> Final output sent to browser
DEBUG - 2021-07-02 12:40:41 --> Total execution time: 0.1311
INFO - 2021-07-02 09:40:43 --> Config Class Initialized
INFO - 2021-07-02 09:40:43 --> Hooks Class Initialized
DEBUG - 2021-07-02 09:40:43 --> UTF-8 Support Enabled
INFO - 2021-07-02 09:40:43 --> Utf8 Class Initialized
INFO - 2021-07-02 09:40:43 --> URI Class Initialized
INFO - 2021-07-02 09:40:43 --> Router Class Initialized
INFO - 2021-07-02 09:40:43 --> Output Class Initialized
INFO - 2021-07-02 09:40:43 --> Security Class Initialized
DEBUG - 2021-07-02 09:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 09:40:43 --> Input Class Initialized
INFO - 2021-07-02 09:40:43 --> Language Class Initialized
INFO - 2021-07-02 09:40:43 --> Loader Class Initialized
INFO - 2021-07-02 09:40:43 --> Helper loaded: basic_helper
INFO - 2021-07-02 09:40:43 --> Helper loaded: url_helper
INFO - 2021-07-02 09:40:43 --> Helper loaded: file_helper
INFO - 2021-07-02 09:40:43 --> Helper loaded: form_helper
INFO - 2021-07-02 09:40:43 --> Helper loaded: cookie_helper
INFO - 2021-07-02 09:40:43 --> Helper loaded: security_helper
INFO - 2021-07-02 09:40:43 --> Helper loaded: directory_helper
INFO - 2021-07-02 09:40:43 --> Helper loaded: language_helper
INFO - 2021-07-02 09:40:43 --> Helper loaded: general_helper
INFO - 2021-07-02 09:40:43 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-02 09:40:43 --> Database Driver Class Initialized
DEBUG - 2021-07-02 09:40:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-02 09:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-02 09:40:43 --> Parser Class Initialized
INFO - 2021-07-02 09:40:43 --> Form Validation Class Initialized
INFO - 2021-07-02 09:40:43 --> Upload Class Initialized
INFO - 2021-07-02 09:40:43 --> Email Class Initialized
INFO - 2021-07-02 09:40:43 --> MY_Model class loaded
INFO - 2021-07-02 09:40:43 --> Model "Users_model" initialized
INFO - 2021-07-02 09:40:43 --> Model "Settings_model" initialized
INFO - 2021-07-02 09:40:43 --> Model "Role_permissions_model" initialized
INFO - 2021-07-02 09:40:43 --> Model "Permissions_model" initialized
INFO - 2021-07-02 09:40:43 --> Model "Roles_model" initialized
INFO - 2021-07-02 09:40:43 --> Model "Activity_model" initialized
INFO - 2021-07-02 09:40:43 --> Model "Templates_model" initialized
INFO - 2021-07-02 09:40:43 --> Database Driver Class Initialized
INFO - 2021-07-02 09:40:43 --> Model "Hesaplar_model" initialized
INFO - 2021-07-02 09:40:43 --> Controller Class Initialized
ERROR - 2021-07-02 12:40:43 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-02 12:40:43 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-02 12:40:43 --> Final output sent to browser
DEBUG - 2021-07-02 12:40:43 --> Total execution time: 0.2406
INFO - 2021-07-02 10:38:07 --> Config Class Initialized
INFO - 2021-07-02 10:38:07 --> Hooks Class Initialized
DEBUG - 2021-07-02 10:38:07 --> UTF-8 Support Enabled
INFO - 2021-07-02 10:38:07 --> Utf8 Class Initialized
INFO - 2021-07-02 10:38:07 --> URI Class Initialized
DEBUG - 2021-07-02 10:38:07 --> No URI present. Default controller set.
INFO - 2021-07-02 10:38:07 --> Router Class Initialized
INFO - 2021-07-02 10:38:07 --> Output Class Initialized
INFO - 2021-07-02 10:38:07 --> Security Class Initialized
DEBUG - 2021-07-02 10:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 10:38:07 --> Input Class Initialized
INFO - 2021-07-02 10:38:07 --> Language Class Initialized
INFO - 2021-07-02 10:38:07 --> Loader Class Initialized
INFO - 2021-07-02 10:38:07 --> Helper loaded: basic_helper
INFO - 2021-07-02 10:38:07 --> Helper loaded: url_helper
INFO - 2021-07-02 10:38:07 --> Helper loaded: file_helper
INFO - 2021-07-02 10:38:07 --> Helper loaded: form_helper
INFO - 2021-07-02 10:38:07 --> Helper loaded: cookie_helper
INFO - 2021-07-02 10:38:07 --> Helper loaded: security_helper
INFO - 2021-07-02 10:38:07 --> Helper loaded: directory_helper
INFO - 2021-07-02 10:38:07 --> Helper loaded: language_helper
INFO - 2021-07-02 10:38:07 --> Helper loaded: general_helper
INFO - 2021-07-02 10:38:07 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-02 10:38:07 --> Database Driver Class Initialized
DEBUG - 2021-07-02 10:38:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-02 10:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-02 10:38:07 --> Parser Class Initialized
INFO - 2021-07-02 10:38:07 --> Form Validation Class Initialized
INFO - 2021-07-02 10:38:07 --> Upload Class Initialized
INFO - 2021-07-02 10:38:07 --> Email Class Initialized
INFO - 2021-07-02 10:38:07 --> MY_Model class loaded
INFO - 2021-07-02 10:38:07 --> Model "Users_model" initialized
INFO - 2021-07-02 10:38:07 --> Model "Settings_model" initialized
INFO - 2021-07-02 10:38:07 --> Model "Role_permissions_model" initialized
INFO - 2021-07-02 10:38:07 --> Model "Permissions_model" initialized
INFO - 2021-07-02 10:38:07 --> Model "Roles_model" initialized
INFO - 2021-07-02 10:38:07 --> Model "Activity_model" initialized
INFO - 2021-07-02 10:38:07 --> Model "Templates_model" initialized
INFO - 2021-07-02 10:38:07 --> Database Driver Class Initialized
INFO - 2021-07-02 10:38:07 --> Model "Hesaplar_model" initialized
INFO - 2021-07-02 10:38:07 --> Controller Class Initialized
INFO - 2021-07-02 11:50:06 --> Config Class Initialized
INFO - 2021-07-02 11:50:06 --> Hooks Class Initialized
DEBUG - 2021-07-02 11:50:06 --> UTF-8 Support Enabled
INFO - 2021-07-02 11:50:06 --> Utf8 Class Initialized
INFO - 2021-07-02 11:50:06 --> URI Class Initialized
DEBUG - 2021-07-02 11:50:06 --> No URI present. Default controller set.
INFO - 2021-07-02 11:50:06 --> Router Class Initialized
INFO - 2021-07-02 11:50:06 --> Output Class Initialized
INFO - 2021-07-02 11:50:06 --> Security Class Initialized
DEBUG - 2021-07-02 11:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 11:50:06 --> Input Class Initialized
INFO - 2021-07-02 11:50:06 --> Language Class Initialized
INFO - 2021-07-02 11:50:06 --> Loader Class Initialized
INFO - 2021-07-02 11:50:06 --> Helper loaded: basic_helper
INFO - 2021-07-02 11:50:06 --> Helper loaded: url_helper
INFO - 2021-07-02 11:50:06 --> Helper loaded: file_helper
INFO - 2021-07-02 11:50:06 --> Helper loaded: form_helper
INFO - 2021-07-02 11:50:06 --> Helper loaded: cookie_helper
INFO - 2021-07-02 11:50:06 --> Helper loaded: security_helper
INFO - 2021-07-02 11:50:06 --> Helper loaded: directory_helper
INFO - 2021-07-02 11:50:06 --> Helper loaded: language_helper
INFO - 2021-07-02 11:50:06 --> Helper loaded: general_helper
INFO - 2021-07-02 11:50:06 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-02 11:50:06 --> Database Driver Class Initialized
DEBUG - 2021-07-02 11:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-02 11:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-02 11:50:06 --> Parser Class Initialized
INFO - 2021-07-02 11:50:06 --> Form Validation Class Initialized
INFO - 2021-07-02 11:50:06 --> Upload Class Initialized
INFO - 2021-07-02 11:50:06 --> Email Class Initialized
INFO - 2021-07-02 11:50:06 --> MY_Model class loaded
INFO - 2021-07-02 11:50:06 --> Model "Users_model" initialized
INFO - 2021-07-02 11:50:06 --> Model "Settings_model" initialized
INFO - 2021-07-02 11:50:06 --> Model "Role_permissions_model" initialized
INFO - 2021-07-02 11:50:06 --> Model "Permissions_model" initialized
INFO - 2021-07-02 11:50:06 --> Model "Roles_model" initialized
INFO - 2021-07-02 11:50:06 --> Model "Activity_model" initialized
INFO - 2021-07-02 11:50:06 --> Model "Templates_model" initialized
INFO - 2021-07-02 11:50:06 --> Database Driver Class Initialized
INFO - 2021-07-02 11:50:06 --> Model "Hesaplar_model" initialized
INFO - 2021-07-02 11:50:06 --> Controller Class Initialized
INFO - 2021-07-02 13:38:11 --> Config Class Initialized
INFO - 2021-07-02 13:38:11 --> Hooks Class Initialized
DEBUG - 2021-07-02 13:38:11 --> UTF-8 Support Enabled
INFO - 2021-07-02 13:38:11 --> Utf8 Class Initialized
INFO - 2021-07-02 13:38:11 --> URI Class Initialized
DEBUG - 2021-07-02 13:38:11 --> No URI present. Default controller set.
INFO - 2021-07-02 13:38:11 --> Router Class Initialized
INFO - 2021-07-02 13:38:11 --> Output Class Initialized
INFO - 2021-07-02 13:38:11 --> Security Class Initialized
DEBUG - 2021-07-02 13:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 13:38:11 --> Input Class Initialized
INFO - 2021-07-02 13:38:11 --> Language Class Initialized
INFO - 2021-07-02 13:38:11 --> Loader Class Initialized
INFO - 2021-07-02 13:38:11 --> Helper loaded: basic_helper
INFO - 2021-07-02 13:38:11 --> Helper loaded: url_helper
INFO - 2021-07-02 13:38:11 --> Helper loaded: file_helper
INFO - 2021-07-02 13:38:11 --> Helper loaded: form_helper
INFO - 2021-07-02 13:38:11 --> Helper loaded: cookie_helper
INFO - 2021-07-02 13:38:11 --> Helper loaded: security_helper
INFO - 2021-07-02 13:38:11 --> Helper loaded: directory_helper
INFO - 2021-07-02 13:38:11 --> Helper loaded: language_helper
INFO - 2021-07-02 13:38:11 --> Helper loaded: general_helper
INFO - 2021-07-02 13:38:11 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-02 13:38:11 --> Database Driver Class Initialized
DEBUG - 2021-07-02 13:38:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-02 13:38:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-02 13:38:11 --> Parser Class Initialized
INFO - 2021-07-02 13:38:11 --> Form Validation Class Initialized
INFO - 2021-07-02 13:38:11 --> Upload Class Initialized
INFO - 2021-07-02 13:38:11 --> Email Class Initialized
INFO - 2021-07-02 13:38:11 --> MY_Model class loaded
INFO - 2021-07-02 13:38:11 --> Model "Users_model" initialized
INFO - 2021-07-02 13:38:11 --> Model "Settings_model" initialized
INFO - 2021-07-02 13:38:11 --> Model "Role_permissions_model" initialized
INFO - 2021-07-02 13:38:11 --> Model "Permissions_model" initialized
INFO - 2021-07-02 13:38:11 --> Model "Roles_model" initialized
INFO - 2021-07-02 13:38:11 --> Model "Activity_model" initialized
INFO - 2021-07-02 13:38:11 --> Model "Templates_model" initialized
INFO - 2021-07-02 13:38:11 --> Database Driver Class Initialized
INFO - 2021-07-02 13:38:11 --> Model "Hesaplar_model" initialized
INFO - 2021-07-02 13:38:11 --> Controller Class Initialized
INFO - 2021-07-02 14:35:19 --> Config Class Initialized
INFO - 2021-07-02 14:35:19 --> Hooks Class Initialized
DEBUG - 2021-07-02 14:35:19 --> UTF-8 Support Enabled
INFO - 2021-07-02 14:35:19 --> Utf8 Class Initialized
INFO - 2021-07-02 14:35:19 --> URI Class Initialized
INFO - 2021-07-02 14:35:19 --> Router Class Initialized
INFO - 2021-07-02 14:35:19 --> Output Class Initialized
INFO - 2021-07-02 14:35:19 --> Security Class Initialized
DEBUG - 2021-07-02 14:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 14:35:19 --> Input Class Initialized
INFO - 2021-07-02 14:35:19 --> Language Class Initialized
INFO - 2021-07-02 14:35:19 --> Loader Class Initialized
INFO - 2021-07-02 14:35:19 --> Helper loaded: basic_helper
INFO - 2021-07-02 14:35:19 --> Helper loaded: url_helper
INFO - 2021-07-02 14:35:19 --> Helper loaded: file_helper
INFO - 2021-07-02 14:35:19 --> Helper loaded: form_helper
INFO - 2021-07-02 14:35:19 --> Helper loaded: cookie_helper
INFO - 2021-07-02 14:35:19 --> Helper loaded: security_helper
INFO - 2021-07-02 14:35:19 --> Helper loaded: directory_helper
INFO - 2021-07-02 14:35:19 --> Helper loaded: language_helper
INFO - 2021-07-02 14:35:19 --> Helper loaded: general_helper
INFO - 2021-07-02 14:35:19 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-02 14:35:19 --> Database Driver Class Initialized
DEBUG - 2021-07-02 14:35:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-02 14:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-02 14:35:19 --> Parser Class Initialized
INFO - 2021-07-02 14:35:19 --> Form Validation Class Initialized
INFO - 2021-07-02 14:35:19 --> Upload Class Initialized
INFO - 2021-07-02 14:35:19 --> Email Class Initialized
INFO - 2021-07-02 14:35:19 --> MY_Model class loaded
INFO - 2021-07-02 14:35:19 --> Model "Users_model" initialized
INFO - 2021-07-02 14:35:19 --> Model "Settings_model" initialized
INFO - 2021-07-02 14:35:19 --> Model "Role_permissions_model" initialized
INFO - 2021-07-02 14:35:19 --> Model "Permissions_model" initialized
INFO - 2021-07-02 14:35:19 --> Model "Roles_model" initialized
INFO - 2021-07-02 14:35:19 --> Model "Activity_model" initialized
INFO - 2021-07-02 14:35:19 --> Model "Templates_model" initialized
INFO - 2021-07-02 14:35:19 --> Database Driver Class Initialized
INFO - 2021-07-02 14:35:19 --> Model "Hesaplar_model" initialized
INFO - 2021-07-02 14:35:19 --> Controller Class Initialized
INFO - 2021-07-02 14:35:19 --> Config Class Initialized
INFO - 2021-07-02 14:35:19 --> Hooks Class Initialized
DEBUG - 2021-07-02 14:35:19 --> UTF-8 Support Enabled
INFO - 2021-07-02 14:35:19 --> Utf8 Class Initialized
INFO - 2021-07-02 14:35:19 --> URI Class Initialized
INFO - 2021-07-02 14:35:19 --> Router Class Initialized
INFO - 2021-07-02 14:35:19 --> Output Class Initialized
INFO - 2021-07-02 14:35:19 --> Security Class Initialized
DEBUG - 2021-07-02 14:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 14:35:19 --> Input Class Initialized
INFO - 2021-07-02 14:35:19 --> Language Class Initialized
INFO - 2021-07-02 14:35:19 --> Loader Class Initialized
INFO - 2021-07-02 14:35:19 --> Helper loaded: basic_helper
INFO - 2021-07-02 14:35:19 --> Helper loaded: url_helper
INFO - 2021-07-02 14:35:19 --> Helper loaded: file_helper
INFO - 2021-07-02 14:35:19 --> Helper loaded: form_helper
INFO - 2021-07-02 14:35:19 --> Helper loaded: cookie_helper
INFO - 2021-07-02 14:35:19 --> Helper loaded: security_helper
INFO - 2021-07-02 14:35:19 --> Helper loaded: directory_helper
INFO - 2021-07-02 14:35:19 --> Helper loaded: language_helper
INFO - 2021-07-02 14:35:19 --> Helper loaded: general_helper
INFO - 2021-07-02 14:35:19 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-02 14:35:19 --> Database Driver Class Initialized
DEBUG - 2021-07-02 14:35:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-02 14:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-02 14:35:19 --> Parser Class Initialized
INFO - 2021-07-02 14:35:19 --> Form Validation Class Initialized
INFO - 2021-07-02 14:35:19 --> Upload Class Initialized
INFO - 2021-07-02 14:35:19 --> Email Class Initialized
INFO - 2021-07-02 14:35:19 --> MY_Model class loaded
INFO - 2021-07-02 14:35:19 --> Model "Users_model" initialized
INFO - 2021-07-02 14:35:19 --> Model "Settings_model" initialized
INFO - 2021-07-02 14:35:19 --> Model "Role_permissions_model" initialized
INFO - 2021-07-02 14:35:19 --> Model "Permissions_model" initialized
INFO - 2021-07-02 14:35:19 --> Model "Roles_model" initialized
INFO - 2021-07-02 14:35:19 --> Model "Activity_model" initialized
INFO - 2021-07-02 14:35:19 --> Model "Templates_model" initialized
INFO - 2021-07-02 14:35:19 --> Database Driver Class Initialized
INFO - 2021-07-02 14:35:19 --> Model "Hesaplar_model" initialized
INFO - 2021-07-02 14:35:19 --> Controller Class Initialized
INFO - 2021-07-02 17:35:19 --> File loaded: C:\wamp64\www\crm\application\views\account/login.php
INFO - 2021-07-02 17:35:19 --> Final output sent to browser
DEBUG - 2021-07-02 17:35:19 --> Total execution time: 0.0728
INFO - 2021-07-02 14:35:19 --> Config Class Initialized
INFO - 2021-07-02 14:35:19 --> Hooks Class Initialized
DEBUG - 2021-07-02 14:35:19 --> UTF-8 Support Enabled
INFO - 2021-07-02 14:35:19 --> Utf8 Class Initialized
INFO - 2021-07-02 14:35:19 --> URI Class Initialized
INFO - 2021-07-02 14:35:19 --> Router Class Initialized
INFO - 2021-07-02 14:35:19 --> Output Class Initialized
INFO - 2021-07-02 14:35:19 --> Security Class Initialized
DEBUG - 2021-07-02 14:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 14:35:19 --> Config Class Initialized
INFO - 2021-07-02 14:35:19 --> Input Class Initialized
INFO - 2021-07-02 14:35:19 --> Hooks Class Initialized
INFO - 2021-07-02 14:35:19 --> Language Class Initialized
DEBUG - 2021-07-02 14:35:19 --> UTF-8 Support Enabled
INFO - 2021-07-02 14:35:19 --> Utf8 Class Initialized
ERROR - 2021-07-02 14:35:19 --> 404 Page Not Found: Assets/jquery
INFO - 2021-07-02 14:35:19 --> URI Class Initialized
INFO - 2021-07-02 14:35:19 --> Router Class Initialized
INFO - 2021-07-02 14:35:19 --> Output Class Initialized
INFO - 2021-07-02 14:35:19 --> Security Class Initialized
DEBUG - 2021-07-02 14:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 14:35:19 --> Input Class Initialized
INFO - 2021-07-02 14:35:19 --> Language Class Initialized
ERROR - 2021-07-02 14:35:19 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-02 14:35:19 --> Config Class Initialized
INFO - 2021-07-02 14:35:19 --> Hooks Class Initialized
DEBUG - 2021-07-02 14:35:19 --> UTF-8 Support Enabled
INFO - 2021-07-02 14:35:19 --> Utf8 Class Initialized
INFO - 2021-07-02 14:35:19 --> URI Class Initialized
INFO - 2021-07-02 14:35:19 --> Router Class Initialized
INFO - 2021-07-02 14:35:19 --> Output Class Initialized
INFO - 2021-07-02 14:35:19 --> Security Class Initialized
DEBUG - 2021-07-02 14:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 14:35:19 --> Input Class Initialized
INFO - 2021-07-02 14:35:19 --> Language Class Initialized
ERROR - 2021-07-02 14:35:19 --> 404 Page Not Found: Assets/jquery
INFO - 2021-07-02 14:35:19 --> Config Class Initialized
INFO - 2021-07-02 14:35:19 --> Hooks Class Initialized
DEBUG - 2021-07-02 14:35:19 --> UTF-8 Support Enabled
INFO - 2021-07-02 14:35:19 --> Utf8 Class Initialized
INFO - 2021-07-02 14:35:19 --> URI Class Initialized
INFO - 2021-07-02 14:35:19 --> Router Class Initialized
INFO - 2021-07-02 14:35:19 --> Output Class Initialized
INFO - 2021-07-02 14:35:19 --> Security Class Initialized
DEBUG - 2021-07-02 14:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 14:35:19 --> Input Class Initialized
INFO - 2021-07-02 14:35:19 --> Language Class Initialized
ERROR - 2021-07-02 14:35:19 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-02 14:35:24 --> Config Class Initialized
INFO - 2021-07-02 14:35:24 --> Hooks Class Initialized
DEBUG - 2021-07-02 14:35:24 --> UTF-8 Support Enabled
INFO - 2021-07-02 14:35:24 --> Utf8 Class Initialized
INFO - 2021-07-02 14:35:24 --> URI Class Initialized
INFO - 2021-07-02 14:35:24 --> Router Class Initialized
INFO - 2021-07-02 14:35:24 --> Output Class Initialized
INFO - 2021-07-02 14:35:24 --> Security Class Initialized
DEBUG - 2021-07-02 14:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 14:35:24 --> Input Class Initialized
INFO - 2021-07-02 14:35:24 --> Language Class Initialized
INFO - 2021-07-02 14:35:24 --> Loader Class Initialized
INFO - 2021-07-02 14:35:24 --> Helper loaded: basic_helper
INFO - 2021-07-02 14:35:24 --> Helper loaded: url_helper
INFO - 2021-07-02 14:35:24 --> Helper loaded: file_helper
INFO - 2021-07-02 14:35:24 --> Helper loaded: form_helper
INFO - 2021-07-02 14:35:24 --> Helper loaded: cookie_helper
INFO - 2021-07-02 14:35:24 --> Helper loaded: security_helper
INFO - 2021-07-02 14:35:24 --> Helper loaded: directory_helper
INFO - 2021-07-02 14:35:24 --> Helper loaded: language_helper
INFO - 2021-07-02 14:35:24 --> Helper loaded: general_helper
INFO - 2021-07-02 14:35:24 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-02 14:35:24 --> Database Driver Class Initialized
DEBUG - 2021-07-02 14:35:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-02 14:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-02 14:35:24 --> Parser Class Initialized
INFO - 2021-07-02 14:35:24 --> Form Validation Class Initialized
INFO - 2021-07-02 14:35:24 --> Upload Class Initialized
INFO - 2021-07-02 14:35:24 --> Email Class Initialized
INFO - 2021-07-02 14:35:24 --> MY_Model class loaded
INFO - 2021-07-02 14:35:24 --> Model "Users_model" initialized
INFO - 2021-07-02 14:35:24 --> Model "Settings_model" initialized
INFO - 2021-07-02 14:35:24 --> Model "Role_permissions_model" initialized
INFO - 2021-07-02 14:35:24 --> Model "Permissions_model" initialized
INFO - 2021-07-02 14:35:24 --> Model "Roles_model" initialized
INFO - 2021-07-02 14:35:24 --> Model "Activity_model" initialized
INFO - 2021-07-02 14:35:24 --> Model "Templates_model" initialized
INFO - 2021-07-02 14:35:24 --> Database Driver Class Initialized
INFO - 2021-07-02 14:35:24 --> Model "Hesaplar_model" initialized
INFO - 2021-07-02 14:35:24 --> Controller Class Initialized
DEBUG - 2021-07-02 17:35:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-02 17:35:24 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2021-07-02 14:35:24 --> Config Class Initialized
INFO - 2021-07-02 14:35:24 --> Hooks Class Initialized
DEBUG - 2021-07-02 14:35:24 --> UTF-8 Support Enabled
INFO - 2021-07-02 14:35:24 --> Utf8 Class Initialized
INFO - 2021-07-02 14:35:24 --> URI Class Initialized
DEBUG - 2021-07-02 14:35:24 --> No URI present. Default controller set.
INFO - 2021-07-02 14:35:24 --> Router Class Initialized
INFO - 2021-07-02 14:35:24 --> Output Class Initialized
INFO - 2021-07-02 14:35:24 --> Security Class Initialized
DEBUG - 2021-07-02 14:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 14:35:24 --> Input Class Initialized
INFO - 2021-07-02 14:35:24 --> Language Class Initialized
INFO - 2021-07-02 14:35:24 --> Loader Class Initialized
INFO - 2021-07-02 14:35:24 --> Helper loaded: basic_helper
INFO - 2021-07-02 14:35:24 --> Helper loaded: url_helper
INFO - 2021-07-02 14:35:24 --> Helper loaded: file_helper
INFO - 2021-07-02 14:35:24 --> Helper loaded: form_helper
INFO - 2021-07-02 14:35:24 --> Helper loaded: cookie_helper
INFO - 2021-07-02 14:35:24 --> Helper loaded: security_helper
INFO - 2021-07-02 14:35:24 --> Helper loaded: directory_helper
INFO - 2021-07-02 14:35:24 --> Helper loaded: language_helper
INFO - 2021-07-02 14:35:24 --> Helper loaded: general_helper
INFO - 2021-07-02 14:35:24 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-02 14:35:24 --> Database Driver Class Initialized
DEBUG - 2021-07-02 14:35:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-02 14:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-02 14:35:24 --> Parser Class Initialized
INFO - 2021-07-02 14:35:24 --> Form Validation Class Initialized
INFO - 2021-07-02 14:35:24 --> Upload Class Initialized
INFO - 2021-07-02 14:35:24 --> Email Class Initialized
INFO - 2021-07-02 14:35:24 --> MY_Model class loaded
INFO - 2021-07-02 14:35:24 --> Model "Users_model" initialized
INFO - 2021-07-02 14:35:24 --> Model "Settings_model" initialized
INFO - 2021-07-02 14:35:24 --> Model "Role_permissions_model" initialized
INFO - 2021-07-02 14:35:24 --> Model "Permissions_model" initialized
INFO - 2021-07-02 14:35:24 --> Model "Roles_model" initialized
INFO - 2021-07-02 14:35:24 --> Model "Activity_model" initialized
INFO - 2021-07-02 14:35:24 --> Model "Templates_model" initialized
INFO - 2021-07-02 14:35:24 --> Database Driver Class Initialized
INFO - 2021-07-02 14:35:24 --> Model "Hesaplar_model" initialized
INFO - 2021-07-02 14:35:24 --> Controller Class Initialized
ERROR - 2021-07-02 17:35:24 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-02 17:35:24 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-02 17:35:24 --> Final output sent to browser
DEBUG - 2021-07-02 17:35:24 --> Total execution time: 0.0598
INFO - 2021-07-02 14:35:26 --> Config Class Initialized
INFO - 2021-07-02 14:35:26 --> Hooks Class Initialized
DEBUG - 2021-07-02 14:35:26 --> UTF-8 Support Enabled
INFO - 2021-07-02 14:35:26 --> Utf8 Class Initialized
INFO - 2021-07-02 14:35:26 --> URI Class Initialized
INFO - 2021-07-02 14:35:26 --> Router Class Initialized
INFO - 2021-07-02 14:35:26 --> Output Class Initialized
INFO - 2021-07-02 14:35:26 --> Security Class Initialized
DEBUG - 2021-07-02 14:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 14:35:26 --> Input Class Initialized
INFO - 2021-07-02 14:35:26 --> Language Class Initialized
INFO - 2021-07-02 14:35:26 --> Loader Class Initialized
INFO - 2021-07-02 14:35:26 --> Helper loaded: basic_helper
INFO - 2021-07-02 14:35:26 --> Helper loaded: url_helper
INFO - 2021-07-02 14:35:26 --> Helper loaded: file_helper
INFO - 2021-07-02 14:35:26 --> Helper loaded: form_helper
INFO - 2021-07-02 14:35:26 --> Helper loaded: cookie_helper
INFO - 2021-07-02 14:35:26 --> Helper loaded: security_helper
INFO - 2021-07-02 14:35:26 --> Helper loaded: directory_helper
INFO - 2021-07-02 14:35:26 --> Helper loaded: language_helper
INFO - 2021-07-02 14:35:26 --> Helper loaded: general_helper
INFO - 2021-07-02 14:35:26 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-02 14:35:26 --> Database Driver Class Initialized
DEBUG - 2021-07-02 14:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-02 14:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-02 14:35:26 --> Parser Class Initialized
INFO - 2021-07-02 14:35:26 --> Form Validation Class Initialized
INFO - 2021-07-02 14:35:26 --> Upload Class Initialized
INFO - 2021-07-02 14:35:26 --> Email Class Initialized
INFO - 2021-07-02 14:35:26 --> MY_Model class loaded
INFO - 2021-07-02 14:35:26 --> Model "Users_model" initialized
INFO - 2021-07-02 14:35:26 --> Model "Settings_model" initialized
INFO - 2021-07-02 14:35:26 --> Model "Role_permissions_model" initialized
INFO - 2021-07-02 14:35:26 --> Model "Permissions_model" initialized
INFO - 2021-07-02 14:35:26 --> Model "Roles_model" initialized
INFO - 2021-07-02 14:35:26 --> Model "Activity_model" initialized
INFO - 2021-07-02 14:35:26 --> Model "Templates_model" initialized
INFO - 2021-07-02 14:35:26 --> Database Driver Class Initialized
INFO - 2021-07-02 14:35:26 --> Model "Hesaplar_model" initialized
INFO - 2021-07-02 14:35:26 --> Controller Class Initialized
ERROR - 2021-07-02 17:35:26 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-02 17:35:26 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-02 17:35:26 --> Final output sent to browser
DEBUG - 2021-07-02 17:35:26 --> Total execution time: 0.2629
INFO - 2021-07-02 14:35:28 --> Config Class Initialized
INFO - 2021-07-02 14:35:28 --> Hooks Class Initialized
DEBUG - 2021-07-02 14:35:28 --> UTF-8 Support Enabled
INFO - 2021-07-02 14:35:28 --> Utf8 Class Initialized
INFO - 2021-07-02 14:35:28 --> URI Class Initialized
INFO - 2021-07-02 14:35:28 --> Router Class Initialized
INFO - 2021-07-02 14:35:28 --> Output Class Initialized
INFO - 2021-07-02 14:35:28 --> Security Class Initialized
DEBUG - 2021-07-02 14:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 14:35:28 --> Input Class Initialized
INFO - 2021-07-02 14:35:28 --> Language Class Initialized
INFO - 2021-07-02 14:35:28 --> Loader Class Initialized
INFO - 2021-07-02 14:35:28 --> Helper loaded: basic_helper
INFO - 2021-07-02 14:35:28 --> Helper loaded: url_helper
INFO - 2021-07-02 14:35:28 --> Helper loaded: file_helper
INFO - 2021-07-02 14:35:28 --> Helper loaded: form_helper
INFO - 2021-07-02 14:35:28 --> Helper loaded: cookie_helper
INFO - 2021-07-02 14:35:28 --> Helper loaded: security_helper
INFO - 2021-07-02 14:35:28 --> Helper loaded: directory_helper
INFO - 2021-07-02 14:35:28 --> Helper loaded: language_helper
INFO - 2021-07-02 14:35:28 --> Helper loaded: general_helper
INFO - 2021-07-02 14:35:28 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-02 14:35:28 --> Database Driver Class Initialized
DEBUG - 2021-07-02 14:35:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-02 14:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-02 14:35:28 --> Parser Class Initialized
INFO - 2021-07-02 14:35:28 --> Form Validation Class Initialized
INFO - 2021-07-02 14:35:28 --> Upload Class Initialized
INFO - 2021-07-02 14:35:28 --> Email Class Initialized
INFO - 2021-07-02 14:35:28 --> MY_Model class loaded
INFO - 2021-07-02 14:35:28 --> Model "Users_model" initialized
INFO - 2021-07-02 14:35:28 --> Model "Settings_model" initialized
INFO - 2021-07-02 14:35:28 --> Model "Role_permissions_model" initialized
INFO - 2021-07-02 14:35:28 --> Model "Permissions_model" initialized
INFO - 2021-07-02 14:35:28 --> Model "Roles_model" initialized
INFO - 2021-07-02 14:35:28 --> Model "Activity_model" initialized
INFO - 2021-07-02 14:35:28 --> Model "Templates_model" initialized
INFO - 2021-07-02 14:35:28 --> Database Driver Class Initialized
INFO - 2021-07-02 14:35:28 --> Model "Hesaplar_model" initialized
INFO - 2021-07-02 14:35:28 --> Controller Class Initialized
ERROR - 2021-07-02 17:35:28 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-02 17:35:28 --> Invalid query: 
INFO - 2021-07-02 17:35:28 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-02 17:35:28 --> Final output sent to browser
DEBUG - 2021-07-02 17:35:28 --> Total execution time: 0.0806
INFO - 2021-07-02 14:36:56 --> Config Class Initialized
INFO - 2021-07-02 14:36:56 --> Hooks Class Initialized
DEBUG - 2021-07-02 14:36:56 --> UTF-8 Support Enabled
INFO - 2021-07-02 14:36:56 --> Utf8 Class Initialized
INFO - 2021-07-02 14:36:56 --> URI Class Initialized
DEBUG - 2021-07-02 14:36:56 --> No URI present. Default controller set.
INFO - 2021-07-02 14:36:56 --> Router Class Initialized
INFO - 2021-07-02 14:36:56 --> Output Class Initialized
INFO - 2021-07-02 14:36:56 --> Security Class Initialized
DEBUG - 2021-07-02 14:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 14:36:56 --> Input Class Initialized
INFO - 2021-07-02 14:36:56 --> Language Class Initialized
INFO - 2021-07-02 14:36:56 --> Loader Class Initialized
INFO - 2021-07-02 14:36:56 --> Helper loaded: basic_helper
INFO - 2021-07-02 14:36:56 --> Helper loaded: url_helper
INFO - 2021-07-02 14:36:56 --> Helper loaded: file_helper
INFO - 2021-07-02 14:36:56 --> Helper loaded: form_helper
INFO - 2021-07-02 14:36:56 --> Helper loaded: cookie_helper
INFO - 2021-07-02 14:36:56 --> Helper loaded: security_helper
INFO - 2021-07-02 14:36:56 --> Helper loaded: directory_helper
INFO - 2021-07-02 14:36:56 --> Helper loaded: language_helper
INFO - 2021-07-02 14:36:56 --> Helper loaded: general_helper
INFO - 2021-07-02 14:36:56 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-02 14:36:56 --> Database Driver Class Initialized
DEBUG - 2021-07-02 14:36:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-02 14:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-02 14:36:56 --> Parser Class Initialized
INFO - 2021-07-02 14:36:56 --> Form Validation Class Initialized
INFO - 2021-07-02 14:36:56 --> Upload Class Initialized
INFO - 2021-07-02 14:36:56 --> Email Class Initialized
INFO - 2021-07-02 14:36:56 --> MY_Model class loaded
INFO - 2021-07-02 14:36:56 --> Model "Users_model" initialized
INFO - 2021-07-02 14:36:56 --> Model "Settings_model" initialized
INFO - 2021-07-02 14:36:56 --> Model "Role_permissions_model" initialized
INFO - 2021-07-02 14:36:56 --> Model "Permissions_model" initialized
INFO - 2021-07-02 14:36:56 --> Model "Roles_model" initialized
INFO - 2021-07-02 14:36:56 --> Model "Activity_model" initialized
INFO - 2021-07-02 14:36:56 --> Model "Templates_model" initialized
INFO - 2021-07-02 14:36:56 --> Database Driver Class Initialized
INFO - 2021-07-02 14:36:56 --> Model "Hesaplar_model" initialized
INFO - 2021-07-02 14:36:56 --> Controller Class Initialized
INFO - 2021-07-02 14:40:55 --> Config Class Initialized
INFO - 2021-07-02 14:40:55 --> Hooks Class Initialized
DEBUG - 2021-07-02 14:40:55 --> UTF-8 Support Enabled
INFO - 2021-07-02 14:40:55 --> Utf8 Class Initialized
INFO - 2021-07-02 14:40:55 --> URI Class Initialized
INFO - 2021-07-02 14:40:55 --> Router Class Initialized
INFO - 2021-07-02 14:40:55 --> Output Class Initialized
INFO - 2021-07-02 14:40:55 --> Security Class Initialized
DEBUG - 2021-07-02 14:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 14:40:55 --> Input Class Initialized
INFO - 2021-07-02 14:40:55 --> Language Class Initialized
INFO - 2021-07-02 14:40:55 --> Loader Class Initialized
INFO - 2021-07-02 14:40:55 --> Helper loaded: basic_helper
INFO - 2021-07-02 14:40:55 --> Helper loaded: url_helper
INFO - 2021-07-02 14:40:55 --> Helper loaded: file_helper
INFO - 2021-07-02 14:40:55 --> Helper loaded: form_helper
INFO - 2021-07-02 14:40:55 --> Helper loaded: cookie_helper
INFO - 2021-07-02 14:40:55 --> Helper loaded: security_helper
INFO - 2021-07-02 14:40:55 --> Helper loaded: directory_helper
INFO - 2021-07-02 14:40:55 --> Helper loaded: language_helper
INFO - 2021-07-02 14:40:55 --> Helper loaded: general_helper
INFO - 2021-07-02 14:40:55 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-02 14:40:55 --> Database Driver Class Initialized
DEBUG - 2021-07-02 14:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-02 14:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-02 14:40:55 --> Parser Class Initialized
INFO - 2021-07-02 14:40:55 --> Form Validation Class Initialized
INFO - 2021-07-02 14:40:55 --> Upload Class Initialized
INFO - 2021-07-02 14:40:55 --> Email Class Initialized
INFO - 2021-07-02 14:40:55 --> MY_Model class loaded
INFO - 2021-07-02 14:40:55 --> Model "Users_model" initialized
INFO - 2021-07-02 14:40:55 --> Model "Settings_model" initialized
INFO - 2021-07-02 14:40:55 --> Model "Role_permissions_model" initialized
INFO - 2021-07-02 14:40:55 --> Model "Permissions_model" initialized
INFO - 2021-07-02 14:40:55 --> Model "Roles_model" initialized
INFO - 2021-07-02 14:40:55 --> Model "Activity_model" initialized
INFO - 2021-07-02 14:40:55 --> Model "Templates_model" initialized
INFO - 2021-07-02 14:40:55 --> Database Driver Class Initialized
INFO - 2021-07-02 14:40:55 --> Model "Hesaplar_model" initialized
INFO - 2021-07-02 14:40:55 --> Controller Class Initialized
ERROR - 2021-07-02 17:40:55 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-02 17:40:55 --> File loaded: C:\wamp64\www\crm\application\views\blank_page.php
INFO - 2021-07-02 17:40:55 --> Final output sent to browser
DEBUG - 2021-07-02 17:40:55 --> Total execution time: 0.1247
INFO - 2021-07-02 14:40:56 --> Config Class Initialized
INFO - 2021-07-02 14:40:56 --> Hooks Class Initialized
DEBUG - 2021-07-02 14:40:56 --> UTF-8 Support Enabled
INFO - 2021-07-02 14:40:56 --> Utf8 Class Initialized
INFO - 2021-07-02 14:40:56 --> URI Class Initialized
INFO - 2021-07-02 14:40:56 --> Router Class Initialized
INFO - 2021-07-02 14:40:56 --> Output Class Initialized
INFO - 2021-07-02 14:40:56 --> Security Class Initialized
DEBUG - 2021-07-02 14:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 14:40:56 --> Input Class Initialized
INFO - 2021-07-02 14:40:56 --> Language Class Initialized
INFO - 2021-07-02 14:40:56 --> Loader Class Initialized
INFO - 2021-07-02 14:40:56 --> Helper loaded: basic_helper
INFO - 2021-07-02 14:40:56 --> Helper loaded: url_helper
INFO - 2021-07-02 14:40:56 --> Helper loaded: file_helper
INFO - 2021-07-02 14:40:56 --> Helper loaded: form_helper
INFO - 2021-07-02 14:40:56 --> Helper loaded: cookie_helper
INFO - 2021-07-02 14:40:56 --> Helper loaded: security_helper
INFO - 2021-07-02 14:40:56 --> Helper loaded: directory_helper
INFO - 2021-07-02 14:40:56 --> Helper loaded: language_helper
INFO - 2021-07-02 14:40:56 --> Helper loaded: general_helper
INFO - 2021-07-02 14:40:56 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-02 14:40:56 --> Database Driver Class Initialized
DEBUG - 2021-07-02 14:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-02 14:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-02 14:40:56 --> Parser Class Initialized
INFO - 2021-07-02 14:40:56 --> Form Validation Class Initialized
INFO - 2021-07-02 14:40:56 --> Upload Class Initialized
INFO - 2021-07-02 14:40:56 --> Email Class Initialized
INFO - 2021-07-02 14:40:56 --> MY_Model class loaded
INFO - 2021-07-02 14:40:56 --> Model "Users_model" initialized
INFO - 2021-07-02 14:40:56 --> Model "Settings_model" initialized
INFO - 2021-07-02 14:40:56 --> Model "Role_permissions_model" initialized
INFO - 2021-07-02 14:40:56 --> Model "Permissions_model" initialized
INFO - 2021-07-02 14:40:56 --> Model "Roles_model" initialized
INFO - 2021-07-02 14:40:56 --> Model "Activity_model" initialized
INFO - 2021-07-02 14:40:56 --> Model "Templates_model" initialized
INFO - 2021-07-02 14:40:56 --> Database Driver Class Initialized
INFO - 2021-07-02 14:40:56 --> Model "Hesaplar_model" initialized
INFO - 2021-07-02 14:40:56 --> Controller Class Initialized
ERROR - 2021-07-02 17:40:56 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-02 17:40:57 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-02 17:40:57 --> Final output sent to browser
DEBUG - 2021-07-02 17:40:57 --> Total execution time: 0.1788
INFO - 2021-07-02 14:40:59 --> Config Class Initialized
INFO - 2021-07-02 14:40:59 --> Hooks Class Initialized
DEBUG - 2021-07-02 14:40:59 --> UTF-8 Support Enabled
INFO - 2021-07-02 14:40:59 --> Utf8 Class Initialized
INFO - 2021-07-02 14:40:59 --> URI Class Initialized
INFO - 2021-07-02 14:40:59 --> Router Class Initialized
INFO - 2021-07-02 14:40:59 --> Output Class Initialized
INFO - 2021-07-02 14:40:59 --> Security Class Initialized
DEBUG - 2021-07-02 14:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 14:40:59 --> Input Class Initialized
INFO - 2021-07-02 14:40:59 --> Language Class Initialized
INFO - 2021-07-02 14:40:59 --> Loader Class Initialized
INFO - 2021-07-02 14:40:59 --> Helper loaded: basic_helper
INFO - 2021-07-02 14:40:59 --> Helper loaded: url_helper
INFO - 2021-07-02 14:40:59 --> Helper loaded: file_helper
INFO - 2021-07-02 14:40:59 --> Helper loaded: form_helper
INFO - 2021-07-02 14:40:59 --> Helper loaded: cookie_helper
INFO - 2021-07-02 14:40:59 --> Helper loaded: security_helper
INFO - 2021-07-02 14:40:59 --> Helper loaded: directory_helper
INFO - 2021-07-02 14:40:59 --> Helper loaded: language_helper
INFO - 2021-07-02 14:40:59 --> Helper loaded: general_helper
INFO - 2021-07-02 14:40:59 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-02 14:40:59 --> Database Driver Class Initialized
DEBUG - 2021-07-02 14:40:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-02 14:40:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-02 14:40:59 --> Parser Class Initialized
INFO - 2021-07-02 14:40:59 --> Form Validation Class Initialized
INFO - 2021-07-02 14:40:59 --> Upload Class Initialized
INFO - 2021-07-02 14:40:59 --> Email Class Initialized
INFO - 2021-07-02 14:40:59 --> MY_Model class loaded
INFO - 2021-07-02 14:40:59 --> Model "Users_model" initialized
INFO - 2021-07-02 14:40:59 --> Model "Settings_model" initialized
INFO - 2021-07-02 14:40:59 --> Model "Role_permissions_model" initialized
INFO - 2021-07-02 14:40:59 --> Model "Permissions_model" initialized
INFO - 2021-07-02 14:40:59 --> Model "Roles_model" initialized
INFO - 2021-07-02 14:40:59 --> Model "Activity_model" initialized
INFO - 2021-07-02 14:40:59 --> Model "Templates_model" initialized
INFO - 2021-07-02 14:40:59 --> Database Driver Class Initialized
INFO - 2021-07-02 14:41:00 --> Model "Hesaplar_model" initialized
INFO - 2021-07-02 14:41:00 --> Controller Class Initialized
ERROR - 2021-07-02 17:41:00 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-02 17:41:00 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-02 17:41:00 --> Final output sent to browser
DEBUG - 2021-07-02 17:41:00 --> Total execution time: 0.0736
INFO - 2021-07-02 14:41:04 --> Config Class Initialized
INFO - 2021-07-02 14:41:04 --> Hooks Class Initialized
DEBUG - 2021-07-02 14:41:04 --> UTF-8 Support Enabled
INFO - 2021-07-02 14:41:04 --> Utf8 Class Initialized
INFO - 2021-07-02 14:41:04 --> URI Class Initialized
INFO - 2021-07-02 14:41:04 --> Router Class Initialized
INFO - 2021-07-02 14:41:04 --> Output Class Initialized
INFO - 2021-07-02 14:41:04 --> Security Class Initialized
DEBUG - 2021-07-02 14:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 14:41:04 --> Input Class Initialized
INFO - 2021-07-02 14:41:04 --> Language Class Initialized
INFO - 2021-07-02 14:41:04 --> Loader Class Initialized
INFO - 2021-07-02 14:41:04 --> Helper loaded: basic_helper
INFO - 2021-07-02 14:41:04 --> Helper loaded: url_helper
INFO - 2021-07-02 14:41:04 --> Helper loaded: file_helper
INFO - 2021-07-02 14:41:04 --> Helper loaded: form_helper
INFO - 2021-07-02 14:41:04 --> Helper loaded: cookie_helper
INFO - 2021-07-02 14:41:04 --> Helper loaded: security_helper
INFO - 2021-07-02 14:41:04 --> Helper loaded: directory_helper
INFO - 2021-07-02 14:41:04 --> Helper loaded: language_helper
INFO - 2021-07-02 14:41:04 --> Helper loaded: general_helper
INFO - 2021-07-02 14:41:04 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-02 14:41:04 --> Database Driver Class Initialized
DEBUG - 2021-07-02 14:41:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-02 14:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-02 14:41:04 --> Parser Class Initialized
INFO - 2021-07-02 14:41:04 --> Form Validation Class Initialized
INFO - 2021-07-02 14:41:04 --> Upload Class Initialized
INFO - 2021-07-02 14:41:04 --> Email Class Initialized
INFO - 2021-07-02 14:41:04 --> MY_Model class loaded
INFO - 2021-07-02 14:41:04 --> Model "Users_model" initialized
INFO - 2021-07-02 14:41:04 --> Model "Settings_model" initialized
INFO - 2021-07-02 14:41:04 --> Model "Role_permissions_model" initialized
INFO - 2021-07-02 14:41:04 --> Model "Permissions_model" initialized
INFO - 2021-07-02 14:41:04 --> Model "Roles_model" initialized
INFO - 2021-07-02 14:41:04 --> Model "Activity_model" initialized
INFO - 2021-07-02 14:41:04 --> Model "Templates_model" initialized
INFO - 2021-07-02 14:41:04 --> Database Driver Class Initialized
INFO - 2021-07-02 14:41:04 --> Model "Hesaplar_model" initialized
INFO - 2021-07-02 14:41:04 --> Controller Class Initialized
ERROR - 2021-07-02 17:41:04 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-02 17:41:04 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-02 17:41:04 --> Final output sent to browser
DEBUG - 2021-07-02 17:41:04 --> Total execution time: 0.1338
INFO - 2021-07-02 14:41:07 --> Config Class Initialized
INFO - 2021-07-02 14:41:07 --> Hooks Class Initialized
DEBUG - 2021-07-02 14:41:07 --> UTF-8 Support Enabled
INFO - 2021-07-02 14:41:07 --> Utf8 Class Initialized
INFO - 2021-07-02 14:41:07 --> URI Class Initialized
INFO - 2021-07-02 14:41:07 --> Router Class Initialized
INFO - 2021-07-02 14:41:07 --> Output Class Initialized
INFO - 2021-07-02 14:41:07 --> Security Class Initialized
DEBUG - 2021-07-02 14:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 14:41:07 --> Input Class Initialized
INFO - 2021-07-02 14:41:07 --> Language Class Initialized
INFO - 2021-07-02 14:41:07 --> Loader Class Initialized
INFO - 2021-07-02 14:41:07 --> Helper loaded: basic_helper
INFO - 2021-07-02 14:41:07 --> Helper loaded: url_helper
INFO - 2021-07-02 14:41:07 --> Helper loaded: file_helper
INFO - 2021-07-02 14:41:07 --> Helper loaded: form_helper
INFO - 2021-07-02 14:41:07 --> Helper loaded: cookie_helper
INFO - 2021-07-02 14:41:07 --> Helper loaded: security_helper
INFO - 2021-07-02 14:41:07 --> Helper loaded: directory_helper
INFO - 2021-07-02 14:41:07 --> Helper loaded: language_helper
INFO - 2021-07-02 14:41:07 --> Helper loaded: general_helper
INFO - 2021-07-02 14:41:07 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-02 14:41:07 --> Database Driver Class Initialized
DEBUG - 2021-07-02 14:41:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-02 14:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-02 14:41:07 --> Parser Class Initialized
INFO - 2021-07-02 14:41:07 --> Form Validation Class Initialized
INFO - 2021-07-02 14:41:07 --> Upload Class Initialized
INFO - 2021-07-02 14:41:07 --> Email Class Initialized
INFO - 2021-07-02 14:41:07 --> MY_Model class loaded
INFO - 2021-07-02 14:41:07 --> Model "Users_model" initialized
INFO - 2021-07-02 14:41:07 --> Model "Settings_model" initialized
INFO - 2021-07-02 14:41:07 --> Model "Role_permissions_model" initialized
INFO - 2021-07-02 14:41:07 --> Model "Permissions_model" initialized
INFO - 2021-07-02 14:41:07 --> Model "Roles_model" initialized
INFO - 2021-07-02 14:41:07 --> Model "Activity_model" initialized
INFO - 2021-07-02 14:41:07 --> Model "Templates_model" initialized
INFO - 2021-07-02 14:41:07 --> Database Driver Class Initialized
INFO - 2021-07-02 14:41:07 --> Model "Hesaplar_model" initialized
INFO - 2021-07-02 14:41:07 --> Controller Class Initialized
ERROR - 2021-07-02 17:41:07 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-02 17:41:07 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-02 17:41:07 --> Final output sent to browser
DEBUG - 2021-07-02 17:41:07 --> Total execution time: 0.0820
INFO - 2021-07-02 14:41:08 --> Config Class Initialized
INFO - 2021-07-02 14:41:08 --> Hooks Class Initialized
DEBUG - 2021-07-02 14:41:08 --> UTF-8 Support Enabled
INFO - 2021-07-02 14:41:08 --> Utf8 Class Initialized
INFO - 2021-07-02 14:41:08 --> URI Class Initialized
INFO - 2021-07-02 14:41:08 --> Router Class Initialized
INFO - 2021-07-02 14:41:08 --> Output Class Initialized
INFO - 2021-07-02 14:41:08 --> Security Class Initialized
DEBUG - 2021-07-02 14:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 14:41:08 --> Input Class Initialized
INFO - 2021-07-02 14:41:08 --> Language Class Initialized
INFO - 2021-07-02 14:41:08 --> Loader Class Initialized
INFO - 2021-07-02 14:41:08 --> Helper loaded: basic_helper
INFO - 2021-07-02 14:41:08 --> Helper loaded: url_helper
INFO - 2021-07-02 14:41:08 --> Helper loaded: file_helper
INFO - 2021-07-02 14:41:08 --> Helper loaded: form_helper
INFO - 2021-07-02 14:41:08 --> Helper loaded: cookie_helper
INFO - 2021-07-02 14:41:08 --> Helper loaded: security_helper
INFO - 2021-07-02 14:41:08 --> Helper loaded: directory_helper
INFO - 2021-07-02 14:41:08 --> Helper loaded: language_helper
INFO - 2021-07-02 14:41:08 --> Helper loaded: general_helper
INFO - 2021-07-02 14:41:08 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-02 14:41:08 --> Database Driver Class Initialized
DEBUG - 2021-07-02 14:41:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-02 14:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-02 14:41:08 --> Parser Class Initialized
INFO - 2021-07-02 14:41:08 --> Form Validation Class Initialized
INFO - 2021-07-02 14:41:08 --> Upload Class Initialized
INFO - 2021-07-02 14:41:08 --> Email Class Initialized
INFO - 2021-07-02 14:41:08 --> MY_Model class loaded
INFO - 2021-07-02 14:41:08 --> Model "Users_model" initialized
INFO - 2021-07-02 14:41:08 --> Model "Settings_model" initialized
INFO - 2021-07-02 14:41:08 --> Model "Role_permissions_model" initialized
INFO - 2021-07-02 14:41:08 --> Model "Permissions_model" initialized
INFO - 2021-07-02 14:41:08 --> Model "Roles_model" initialized
INFO - 2021-07-02 14:41:08 --> Model "Activity_model" initialized
INFO - 2021-07-02 14:41:08 --> Model "Templates_model" initialized
INFO - 2021-07-02 14:41:08 --> Database Driver Class Initialized
INFO - 2021-07-02 14:41:08 --> Model "Hesaplar_model" initialized
INFO - 2021-07-02 14:41:08 --> Controller Class Initialized
ERROR - 2021-07-02 17:41:08 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-02 17:41:08 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-02 17:41:08 --> Final output sent to browser
DEBUG - 2021-07-02 17:41:08 --> Total execution time: 0.2155
INFO - 2021-07-02 14:41:10 --> Config Class Initialized
INFO - 2021-07-02 14:41:10 --> Hooks Class Initialized
DEBUG - 2021-07-02 14:41:10 --> UTF-8 Support Enabled
INFO - 2021-07-02 14:41:10 --> Utf8 Class Initialized
INFO - 2021-07-02 14:41:10 --> URI Class Initialized
INFO - 2021-07-02 14:41:10 --> Router Class Initialized
INFO - 2021-07-02 14:41:10 --> Output Class Initialized
INFO - 2021-07-02 14:41:10 --> Security Class Initialized
DEBUG - 2021-07-02 14:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 14:41:10 --> Input Class Initialized
INFO - 2021-07-02 14:41:10 --> Language Class Initialized
INFO - 2021-07-02 14:41:10 --> Loader Class Initialized
INFO - 2021-07-02 14:41:10 --> Helper loaded: basic_helper
INFO - 2021-07-02 14:41:10 --> Helper loaded: url_helper
INFO - 2021-07-02 14:41:10 --> Helper loaded: file_helper
INFO - 2021-07-02 14:41:10 --> Helper loaded: form_helper
INFO - 2021-07-02 14:41:10 --> Helper loaded: cookie_helper
INFO - 2021-07-02 14:41:10 --> Helper loaded: security_helper
INFO - 2021-07-02 14:41:10 --> Helper loaded: directory_helper
INFO - 2021-07-02 14:41:10 --> Helper loaded: language_helper
INFO - 2021-07-02 14:41:10 --> Helper loaded: general_helper
INFO - 2021-07-02 14:41:10 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-02 14:41:10 --> Database Driver Class Initialized
DEBUG - 2021-07-02 14:41:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-02 14:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-02 14:41:10 --> Parser Class Initialized
INFO - 2021-07-02 14:41:10 --> Form Validation Class Initialized
INFO - 2021-07-02 14:41:10 --> Upload Class Initialized
INFO - 2021-07-02 14:41:10 --> Email Class Initialized
INFO - 2021-07-02 14:41:10 --> MY_Model class loaded
INFO - 2021-07-02 14:41:10 --> Model "Users_model" initialized
INFO - 2021-07-02 14:41:10 --> Model "Settings_model" initialized
INFO - 2021-07-02 14:41:10 --> Model "Role_permissions_model" initialized
INFO - 2021-07-02 14:41:10 --> Model "Permissions_model" initialized
INFO - 2021-07-02 14:41:10 --> Model "Roles_model" initialized
INFO - 2021-07-02 14:41:10 --> Model "Activity_model" initialized
INFO - 2021-07-02 14:41:10 --> Model "Templates_model" initialized
INFO - 2021-07-02 14:41:10 --> Database Driver Class Initialized
INFO - 2021-07-02 14:41:10 --> Model "Hesaplar_model" initialized
INFO - 2021-07-02 14:41:10 --> Controller Class Initialized
ERROR - 2021-07-02 17:41:10 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-02 17:41:10 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-02 17:41:10 --> Final output sent to browser
DEBUG - 2021-07-02 17:41:10 --> Total execution time: 0.1382
INFO - 2021-07-02 14:41:13 --> Config Class Initialized
INFO - 2021-07-02 14:41:13 --> Hooks Class Initialized
DEBUG - 2021-07-02 14:41:13 --> UTF-8 Support Enabled
INFO - 2021-07-02 14:41:13 --> Utf8 Class Initialized
INFO - 2021-07-02 14:41:13 --> URI Class Initialized
INFO - 2021-07-02 14:41:13 --> Router Class Initialized
INFO - 2021-07-02 14:41:13 --> Output Class Initialized
INFO - 2021-07-02 14:41:13 --> Security Class Initialized
DEBUG - 2021-07-02 14:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 14:41:13 --> Input Class Initialized
INFO - 2021-07-02 14:41:13 --> Language Class Initialized
INFO - 2021-07-02 14:41:13 --> Loader Class Initialized
INFO - 2021-07-02 14:41:13 --> Helper loaded: basic_helper
INFO - 2021-07-02 14:41:13 --> Helper loaded: url_helper
INFO - 2021-07-02 14:41:13 --> Helper loaded: file_helper
INFO - 2021-07-02 14:41:13 --> Helper loaded: form_helper
INFO - 2021-07-02 14:41:13 --> Helper loaded: cookie_helper
INFO - 2021-07-02 14:41:13 --> Helper loaded: security_helper
INFO - 2021-07-02 14:41:13 --> Helper loaded: directory_helper
INFO - 2021-07-02 14:41:13 --> Helper loaded: language_helper
INFO - 2021-07-02 14:41:13 --> Helper loaded: general_helper
INFO - 2021-07-02 14:41:13 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-02 14:41:13 --> Database Driver Class Initialized
DEBUG - 2021-07-02 14:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-02 14:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-02 14:41:13 --> Parser Class Initialized
INFO - 2021-07-02 14:41:13 --> Form Validation Class Initialized
INFO - 2021-07-02 14:41:13 --> Upload Class Initialized
INFO - 2021-07-02 14:41:13 --> Email Class Initialized
INFO - 2021-07-02 14:41:13 --> MY_Model class loaded
INFO - 2021-07-02 14:41:13 --> Model "Users_model" initialized
INFO - 2021-07-02 14:41:13 --> Model "Settings_model" initialized
INFO - 2021-07-02 14:41:13 --> Model "Role_permissions_model" initialized
INFO - 2021-07-02 14:41:13 --> Model "Permissions_model" initialized
INFO - 2021-07-02 14:41:13 --> Model "Roles_model" initialized
INFO - 2021-07-02 14:41:13 --> Model "Activity_model" initialized
INFO - 2021-07-02 14:41:13 --> Model "Templates_model" initialized
INFO - 2021-07-02 14:41:13 --> Database Driver Class Initialized
INFO - 2021-07-02 14:41:13 --> Model "Hesaplar_model" initialized
INFO - 2021-07-02 14:41:13 --> Controller Class Initialized
ERROR - 2021-07-02 17:41:13 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-02 17:41:13 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-02 17:41:13 --> Final output sent to browser
DEBUG - 2021-07-02 17:41:13 --> Total execution time: 0.0708
INFO - 2021-07-02 14:41:15 --> Config Class Initialized
INFO - 2021-07-02 14:41:15 --> Hooks Class Initialized
DEBUG - 2021-07-02 14:41:15 --> UTF-8 Support Enabled
INFO - 2021-07-02 14:41:15 --> Utf8 Class Initialized
INFO - 2021-07-02 14:41:15 --> URI Class Initialized
INFO - 2021-07-02 14:41:15 --> Router Class Initialized
INFO - 2021-07-02 14:41:15 --> Output Class Initialized
INFO - 2021-07-02 14:41:15 --> Security Class Initialized
DEBUG - 2021-07-02 14:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 14:41:15 --> Input Class Initialized
INFO - 2021-07-02 14:41:15 --> Language Class Initialized
INFO - 2021-07-02 14:41:15 --> Loader Class Initialized
INFO - 2021-07-02 14:41:15 --> Helper loaded: basic_helper
INFO - 2021-07-02 14:41:15 --> Helper loaded: url_helper
INFO - 2021-07-02 14:41:15 --> Helper loaded: file_helper
INFO - 2021-07-02 14:41:15 --> Helper loaded: form_helper
INFO - 2021-07-02 14:41:15 --> Helper loaded: cookie_helper
INFO - 2021-07-02 14:41:15 --> Helper loaded: security_helper
INFO - 2021-07-02 14:41:15 --> Helper loaded: directory_helper
INFO - 2021-07-02 14:41:15 --> Helper loaded: language_helper
INFO - 2021-07-02 14:41:15 --> Helper loaded: general_helper
INFO - 2021-07-02 14:41:15 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-02 14:41:15 --> Database Driver Class Initialized
DEBUG - 2021-07-02 14:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-02 14:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-02 14:41:15 --> Parser Class Initialized
INFO - 2021-07-02 14:41:15 --> Form Validation Class Initialized
INFO - 2021-07-02 14:41:15 --> Upload Class Initialized
INFO - 2021-07-02 14:41:15 --> Email Class Initialized
INFO - 2021-07-02 14:41:15 --> MY_Model class loaded
INFO - 2021-07-02 14:41:15 --> Model "Users_model" initialized
INFO - 2021-07-02 14:41:15 --> Model "Settings_model" initialized
INFO - 2021-07-02 14:41:15 --> Model "Role_permissions_model" initialized
INFO - 2021-07-02 14:41:15 --> Model "Permissions_model" initialized
INFO - 2021-07-02 14:41:15 --> Model "Roles_model" initialized
INFO - 2021-07-02 14:41:15 --> Model "Activity_model" initialized
INFO - 2021-07-02 14:41:15 --> Model "Templates_model" initialized
INFO - 2021-07-02 14:41:15 --> Database Driver Class Initialized
INFO - 2021-07-02 14:41:15 --> Model "Hesaplar_model" initialized
INFO - 2021-07-02 14:41:15 --> Controller Class Initialized
ERROR - 2021-07-02 17:41:15 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-02 17:41:16 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-02 17:41:16 --> Final output sent to browser
DEBUG - 2021-07-02 17:41:16 --> Total execution time: 0.9342
INFO - 2021-07-02 14:41:33 --> Config Class Initialized
INFO - 2021-07-02 14:41:33 --> Hooks Class Initialized
DEBUG - 2021-07-02 14:41:33 --> UTF-8 Support Enabled
INFO - 2021-07-02 14:41:33 --> Utf8 Class Initialized
INFO - 2021-07-02 14:41:33 --> URI Class Initialized
INFO - 2021-07-02 14:41:33 --> Router Class Initialized
INFO - 2021-07-02 14:41:33 --> Output Class Initialized
INFO - 2021-07-02 14:41:33 --> Security Class Initialized
DEBUG - 2021-07-02 14:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 14:41:33 --> Input Class Initialized
INFO - 2021-07-02 14:41:33 --> Language Class Initialized
INFO - 2021-07-02 14:41:33 --> Loader Class Initialized
INFO - 2021-07-02 14:41:33 --> Helper loaded: basic_helper
INFO - 2021-07-02 14:41:33 --> Helper loaded: url_helper
INFO - 2021-07-02 14:41:33 --> Helper loaded: file_helper
INFO - 2021-07-02 14:41:33 --> Helper loaded: form_helper
INFO - 2021-07-02 14:41:33 --> Helper loaded: cookie_helper
INFO - 2021-07-02 14:41:33 --> Helper loaded: security_helper
INFO - 2021-07-02 14:41:33 --> Helper loaded: directory_helper
INFO - 2021-07-02 14:41:33 --> Helper loaded: language_helper
INFO - 2021-07-02 14:41:33 --> Helper loaded: general_helper
INFO - 2021-07-02 14:41:33 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-02 14:41:33 --> Database Driver Class Initialized
DEBUG - 2021-07-02 14:41:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-02 14:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-02 14:41:33 --> Parser Class Initialized
INFO - 2021-07-02 14:41:33 --> Form Validation Class Initialized
INFO - 2021-07-02 14:41:33 --> Upload Class Initialized
INFO - 2021-07-02 14:41:33 --> Email Class Initialized
INFO - 2021-07-02 14:41:33 --> MY_Model class loaded
INFO - 2021-07-02 14:41:33 --> Model "Users_model" initialized
INFO - 2021-07-02 14:41:33 --> Model "Settings_model" initialized
INFO - 2021-07-02 14:41:33 --> Model "Role_permissions_model" initialized
INFO - 2021-07-02 14:41:33 --> Model "Permissions_model" initialized
INFO - 2021-07-02 14:41:33 --> Model "Roles_model" initialized
INFO - 2021-07-02 14:41:33 --> Model "Activity_model" initialized
INFO - 2021-07-02 14:41:33 --> Model "Templates_model" initialized
INFO - 2021-07-02 14:41:33 --> Database Driver Class Initialized
INFO - 2021-07-02 14:41:33 --> Model "Hesaplar_model" initialized
INFO - 2021-07-02 14:41:33 --> Controller Class Initialized
ERROR - 2021-07-02 17:41:33 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-02 17:41:33 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-02 17:41:33 --> Final output sent to browser
DEBUG - 2021-07-02 17:41:33 --> Total execution time: 0.1228
INFO - 2021-07-02 15:36:32 --> Config Class Initialized
INFO - 2021-07-02 15:36:32 --> Hooks Class Initialized
DEBUG - 2021-07-02 15:36:32 --> UTF-8 Support Enabled
INFO - 2021-07-02 15:36:32 --> Utf8 Class Initialized
INFO - 2021-07-02 15:36:32 --> URI Class Initialized
INFO - 2021-07-02 15:36:32 --> Router Class Initialized
INFO - 2021-07-02 15:36:32 --> Output Class Initialized
INFO - 2021-07-02 15:36:32 --> Security Class Initialized
DEBUG - 2021-07-02 15:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 15:36:32 --> Input Class Initialized
INFO - 2021-07-02 15:36:32 --> Language Class Initialized
INFO - 2021-07-02 15:36:32 --> Loader Class Initialized
INFO - 2021-07-02 15:36:32 --> Helper loaded: basic_helper
INFO - 2021-07-02 15:36:32 --> Helper loaded: url_helper
INFO - 2021-07-02 15:36:32 --> Helper loaded: file_helper
INFO - 2021-07-02 15:36:32 --> Helper loaded: form_helper
INFO - 2021-07-02 15:36:32 --> Helper loaded: cookie_helper
INFO - 2021-07-02 15:36:32 --> Helper loaded: security_helper
INFO - 2021-07-02 15:36:32 --> Helper loaded: directory_helper
INFO - 2021-07-02 15:36:32 --> Helper loaded: language_helper
INFO - 2021-07-02 15:36:32 --> Helper loaded: general_helper
INFO - 2021-07-02 15:36:32 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-02 15:36:32 --> Database Driver Class Initialized
DEBUG - 2021-07-02 15:36:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-02 15:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-02 15:36:32 --> Parser Class Initialized
INFO - 2021-07-02 15:36:32 --> Form Validation Class Initialized
INFO - 2021-07-02 15:36:32 --> Upload Class Initialized
INFO - 2021-07-02 15:36:32 --> Email Class Initialized
INFO - 2021-07-02 15:36:32 --> MY_Model class loaded
INFO - 2021-07-02 15:36:32 --> Model "Users_model" initialized
INFO - 2021-07-02 15:36:32 --> Model "Settings_model" initialized
INFO - 2021-07-02 15:36:32 --> Model "Role_permissions_model" initialized
INFO - 2021-07-02 15:36:32 --> Model "Permissions_model" initialized
INFO - 2021-07-02 15:36:32 --> Model "Roles_model" initialized
INFO - 2021-07-02 15:36:32 --> Model "Activity_model" initialized
INFO - 2021-07-02 15:36:32 --> Model "Templates_model" initialized
INFO - 2021-07-02 15:36:32 --> Database Driver Class Initialized
INFO - 2021-07-02 15:36:32 --> Model "Hesaplar_model" initialized
INFO - 2021-07-02 15:36:32 --> Controller Class Initialized
ERROR - 2021-07-02 18:36:32 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-02 18:36:32 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-02 18:36:32 --> Final output sent to browser
DEBUG - 2021-07-02 18:36:32 --> Total execution time: 0.1673
INFO - 2021-07-02 15:41:46 --> Config Class Initialized
INFO - 2021-07-02 15:41:46 --> Hooks Class Initialized
DEBUG - 2021-07-02 15:41:46 --> UTF-8 Support Enabled
INFO - 2021-07-02 15:41:46 --> Utf8 Class Initialized
INFO - 2021-07-02 15:41:46 --> URI Class Initialized
INFO - 2021-07-02 15:41:46 --> Router Class Initialized
INFO - 2021-07-02 15:41:46 --> Output Class Initialized
INFO - 2021-07-02 15:41:46 --> Security Class Initialized
DEBUG - 2021-07-02 15:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-02 15:41:46 --> Input Class Initialized
INFO - 2021-07-02 15:41:46 --> Language Class Initialized
INFO - 2021-07-02 15:41:46 --> Loader Class Initialized
INFO - 2021-07-02 15:41:46 --> Helper loaded: basic_helper
INFO - 2021-07-02 15:41:46 --> Helper loaded: url_helper
INFO - 2021-07-02 15:41:46 --> Helper loaded: file_helper
INFO - 2021-07-02 15:41:46 --> Helper loaded: form_helper
INFO - 2021-07-02 15:41:46 --> Helper loaded: cookie_helper
INFO - 2021-07-02 15:41:46 --> Helper loaded: security_helper
INFO - 2021-07-02 15:41:46 --> Helper loaded: directory_helper
INFO - 2021-07-02 15:41:46 --> Helper loaded: language_helper
INFO - 2021-07-02 15:41:46 --> Helper loaded: general_helper
INFO - 2021-07-02 15:41:46 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-02 15:41:46 --> Database Driver Class Initialized
DEBUG - 2021-07-02 15:41:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-02 15:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-02 15:41:46 --> Parser Class Initialized
INFO - 2021-07-02 15:41:46 --> Form Validation Class Initialized
INFO - 2021-07-02 15:41:46 --> Upload Class Initialized
INFO - 2021-07-02 15:41:46 --> Email Class Initialized
INFO - 2021-07-02 15:41:46 --> MY_Model class loaded
INFO - 2021-07-02 15:41:46 --> Model "Users_model" initialized
INFO - 2021-07-02 15:41:46 --> Model "Settings_model" initialized
INFO - 2021-07-02 15:41:46 --> Model "Role_permissions_model" initialized
INFO - 2021-07-02 15:41:46 --> Model "Permissions_model" initialized
INFO - 2021-07-02 15:41:46 --> Model "Roles_model" initialized
INFO - 2021-07-02 15:41:46 --> Model "Activity_model" initialized
INFO - 2021-07-02 15:41:46 --> Model "Templates_model" initialized
INFO - 2021-07-02 15:41:46 --> Database Driver Class Initialized
INFO - 2021-07-02 15:41:47 --> Model "Hesaplar_model" initialized
INFO - 2021-07-02 15:41:47 --> Controller Class Initialized
ERROR - 2021-07-02 18:41:47 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-02 18:41:47 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/rapor_ayrinti.php
INFO - 2021-07-02 18:41:47 --> Final output sent to browser
DEBUG - 2021-07-02 18:41:47 --> Total execution time: 0.1202
