<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-07-14 00:04:03 --> Config Class Initialized
INFO - 2021-07-14 00:04:03 --> Hooks Class Initialized
DEBUG - 2021-07-14 00:04:03 --> UTF-8 Support Enabled
INFO - 2021-07-14 00:04:03 --> Utf8 Class Initialized
INFO - 2021-07-14 00:04:03 --> URI Class Initialized
INFO - 2021-07-14 00:04:03 --> Router Class Initialized
INFO - 2021-07-14 00:04:03 --> Output Class Initialized
INFO - 2021-07-14 00:04:03 --> Security Class Initialized
DEBUG - 2021-07-14 00:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 00:04:03 --> Input Class Initialized
INFO - 2021-07-14 00:04:03 --> Language Class Initialized
INFO - 2021-07-14 00:04:03 --> Loader Class Initialized
INFO - 2021-07-14 00:04:03 --> Helper loaded: basic_helper
INFO - 2021-07-14 00:04:03 --> Helper loaded: url_helper
INFO - 2021-07-14 00:04:03 --> Helper loaded: file_helper
INFO - 2021-07-14 00:04:03 --> Helper loaded: form_helper
INFO - 2021-07-14 00:04:03 --> Helper loaded: cookie_helper
INFO - 2021-07-14 00:04:03 --> Helper loaded: security_helper
INFO - 2021-07-14 00:04:03 --> Helper loaded: directory_helper
INFO - 2021-07-14 00:04:03 --> Helper loaded: language_helper
INFO - 2021-07-14 00:04:03 --> Helper loaded: general_helper
INFO - 2021-07-14 00:04:03 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 00:04:03 --> Database Driver Class Initialized
DEBUG - 2021-07-14 00:04:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 00:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 00:04:03 --> Parser Class Initialized
INFO - 2021-07-14 00:04:03 --> Form Validation Class Initialized
INFO - 2021-07-14 00:04:03 --> Upload Class Initialized
INFO - 2021-07-14 00:04:03 --> Email Class Initialized
INFO - 2021-07-14 00:04:03 --> MY_Model class loaded
INFO - 2021-07-14 00:04:03 --> Model "Users_model" initialized
INFO - 2021-07-14 00:04:03 --> Model "Settings_model" initialized
INFO - 2021-07-14 00:04:03 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 00:04:03 --> Model "Permissions_model" initialized
INFO - 2021-07-14 00:04:03 --> Model "Roles_model" initialized
INFO - 2021-07-14 00:04:03 --> Model "Activity_model" initialized
INFO - 2021-07-14 00:04:03 --> Model "Templates_model" initialized
INFO - 2021-07-14 00:04:03 --> Database Driver Class Initialized
INFO - 2021-07-14 00:04:03 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 00:04:03 --> Controller Class Initialized
ERROR - 2021-07-14 00:04:03 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 00:04:03 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-14 00:04:03 --> Final output sent to browser
DEBUG - 2021-07-14 00:04:03 --> Total execution time: 0.5495
INFO - 2021-07-14 00:04:04 --> Config Class Initialized
INFO - 2021-07-14 00:04:04 --> Hooks Class Initialized
DEBUG - 2021-07-14 00:04:04 --> UTF-8 Support Enabled
INFO - 2021-07-14 00:04:04 --> Utf8 Class Initialized
INFO - 2021-07-14 00:04:04 --> URI Class Initialized
INFO - 2021-07-14 00:04:04 --> Router Class Initialized
INFO - 2021-07-14 00:04:04 --> Output Class Initialized
INFO - 2021-07-14 00:04:04 --> Security Class Initialized
DEBUG - 2021-07-14 00:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 00:04:04 --> Input Class Initialized
INFO - 2021-07-14 00:04:04 --> Language Class Initialized
INFO - 2021-07-14 00:04:04 --> Loader Class Initialized
INFO - 2021-07-14 00:04:04 --> Helper loaded: basic_helper
INFO - 2021-07-14 00:04:04 --> Helper loaded: url_helper
INFO - 2021-07-14 00:04:04 --> Helper loaded: file_helper
INFO - 2021-07-14 00:04:04 --> Helper loaded: form_helper
INFO - 2021-07-14 00:04:04 --> Helper loaded: cookie_helper
INFO - 2021-07-14 00:04:04 --> Helper loaded: security_helper
INFO - 2021-07-14 00:04:04 --> Helper loaded: directory_helper
INFO - 2021-07-14 00:04:04 --> Helper loaded: language_helper
INFO - 2021-07-14 00:04:04 --> Helper loaded: general_helper
INFO - 2021-07-14 00:04:04 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 00:04:04 --> Database Driver Class Initialized
DEBUG - 2021-07-14 00:04:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 00:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 00:04:04 --> Parser Class Initialized
INFO - 2021-07-14 00:04:04 --> Form Validation Class Initialized
INFO - 2021-07-14 00:04:04 --> Upload Class Initialized
INFO - 2021-07-14 00:04:04 --> Email Class Initialized
INFO - 2021-07-14 00:04:04 --> MY_Model class loaded
INFO - 2021-07-14 00:04:04 --> Model "Users_model" initialized
INFO - 2021-07-14 00:04:04 --> Model "Settings_model" initialized
INFO - 2021-07-14 00:04:04 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 00:04:04 --> Model "Permissions_model" initialized
INFO - 2021-07-14 00:04:04 --> Model "Roles_model" initialized
INFO - 2021-07-14 00:04:04 --> Model "Activity_model" initialized
INFO - 2021-07-14 00:04:04 --> Model "Templates_model" initialized
INFO - 2021-07-14 00:04:04 --> Database Driver Class Initialized
INFO - 2021-07-14 00:04:04 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 00:04:04 --> Controller Class Initialized
ERROR - 2021-07-14 00:04:04 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 00:04:04 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-14 00:04:04 --> Final output sent to browser
DEBUG - 2021-07-14 00:04:04 --> Total execution time: 0.0595
INFO - 2021-07-14 00:04:50 --> Config Class Initialized
INFO - 2021-07-14 00:04:50 --> Hooks Class Initialized
DEBUG - 2021-07-14 00:04:50 --> UTF-8 Support Enabled
INFO - 2021-07-14 00:04:50 --> Utf8 Class Initialized
INFO - 2021-07-14 00:04:50 --> URI Class Initialized
INFO - 2021-07-14 00:04:50 --> Router Class Initialized
INFO - 2021-07-14 00:04:50 --> Output Class Initialized
INFO - 2021-07-14 00:04:50 --> Security Class Initialized
DEBUG - 2021-07-14 00:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 00:04:50 --> Input Class Initialized
INFO - 2021-07-14 00:04:50 --> Language Class Initialized
INFO - 2021-07-14 00:04:50 --> Loader Class Initialized
INFO - 2021-07-14 00:04:50 --> Helper loaded: basic_helper
INFO - 2021-07-14 00:04:50 --> Helper loaded: url_helper
INFO - 2021-07-14 00:04:50 --> Helper loaded: file_helper
INFO - 2021-07-14 00:04:50 --> Helper loaded: form_helper
INFO - 2021-07-14 00:04:50 --> Helper loaded: cookie_helper
INFO - 2021-07-14 00:04:50 --> Helper loaded: security_helper
INFO - 2021-07-14 00:04:50 --> Helper loaded: directory_helper
INFO - 2021-07-14 00:04:50 --> Helper loaded: language_helper
INFO - 2021-07-14 00:04:50 --> Helper loaded: general_helper
INFO - 2021-07-14 00:04:50 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 00:04:50 --> Database Driver Class Initialized
DEBUG - 2021-07-14 00:04:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 00:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 00:04:50 --> Parser Class Initialized
INFO - 2021-07-14 00:04:50 --> Form Validation Class Initialized
INFO - 2021-07-14 00:04:50 --> Upload Class Initialized
INFO - 2021-07-14 00:04:50 --> Email Class Initialized
INFO - 2021-07-14 00:04:50 --> MY_Model class loaded
INFO - 2021-07-14 00:04:50 --> Model "Users_model" initialized
INFO - 2021-07-14 00:04:50 --> Model "Settings_model" initialized
INFO - 2021-07-14 00:04:50 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 00:04:50 --> Model "Permissions_model" initialized
INFO - 2021-07-14 00:04:50 --> Model "Roles_model" initialized
INFO - 2021-07-14 00:04:50 --> Model "Activity_model" initialized
INFO - 2021-07-14 00:04:50 --> Model "Templates_model" initialized
INFO - 2021-07-14 00:04:50 --> Database Driver Class Initialized
INFO - 2021-07-14 00:04:50 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 00:04:50 --> Controller Class Initialized
ERROR - 2021-07-14 00:04:50 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 00:04:50 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-14 00:04:50 --> Final output sent to browser
DEBUG - 2021-07-14 00:04:50 --> Total execution time: 0.1372
INFO - 2021-07-14 00:06:52 --> Config Class Initialized
INFO - 2021-07-14 00:06:52 --> Hooks Class Initialized
DEBUG - 2021-07-14 00:06:52 --> UTF-8 Support Enabled
INFO - 2021-07-14 00:06:52 --> Utf8 Class Initialized
INFO - 2021-07-14 00:06:52 --> URI Class Initialized
INFO - 2021-07-14 00:06:52 --> Router Class Initialized
INFO - 2021-07-14 00:06:52 --> Output Class Initialized
INFO - 2021-07-14 00:06:52 --> Security Class Initialized
DEBUG - 2021-07-14 00:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 00:06:52 --> Input Class Initialized
INFO - 2021-07-14 00:06:52 --> Language Class Initialized
INFO - 2021-07-14 00:06:52 --> Loader Class Initialized
INFO - 2021-07-14 00:06:52 --> Helper loaded: basic_helper
INFO - 2021-07-14 00:06:52 --> Helper loaded: url_helper
INFO - 2021-07-14 00:06:52 --> Helper loaded: file_helper
INFO - 2021-07-14 00:06:52 --> Helper loaded: form_helper
INFO - 2021-07-14 00:06:52 --> Helper loaded: cookie_helper
INFO - 2021-07-14 00:06:52 --> Helper loaded: security_helper
INFO - 2021-07-14 00:06:52 --> Helper loaded: directory_helper
INFO - 2021-07-14 00:06:52 --> Helper loaded: language_helper
INFO - 2021-07-14 00:06:52 --> Helper loaded: general_helper
INFO - 2021-07-14 00:06:52 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 00:06:52 --> Database Driver Class Initialized
DEBUG - 2021-07-14 00:06:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 00:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 00:06:52 --> Parser Class Initialized
INFO - 2021-07-14 00:06:52 --> Form Validation Class Initialized
INFO - 2021-07-14 00:06:52 --> Upload Class Initialized
INFO - 2021-07-14 00:06:52 --> Email Class Initialized
INFO - 2021-07-14 00:06:52 --> MY_Model class loaded
INFO - 2021-07-14 00:06:52 --> Model "Users_model" initialized
INFO - 2021-07-14 00:06:52 --> Model "Settings_model" initialized
INFO - 2021-07-14 00:06:52 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 00:06:52 --> Model "Permissions_model" initialized
INFO - 2021-07-14 00:06:52 --> Model "Roles_model" initialized
INFO - 2021-07-14 00:06:52 --> Model "Activity_model" initialized
INFO - 2021-07-14 00:06:52 --> Model "Templates_model" initialized
INFO - 2021-07-14 00:06:52 --> Database Driver Class Initialized
INFO - 2021-07-14 00:06:53 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 00:06:53 --> Controller Class Initialized
ERROR - 2021-07-14 00:06:53 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 00:06:53 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-14 00:06:53 --> Final output sent to browser
DEBUG - 2021-07-14 00:06:53 --> Total execution time: 0.1314
INFO - 2021-07-14 00:11:07 --> Config Class Initialized
INFO - 2021-07-14 00:11:07 --> Hooks Class Initialized
DEBUG - 2021-07-14 00:11:07 --> UTF-8 Support Enabled
INFO - 2021-07-14 00:11:07 --> Utf8 Class Initialized
INFO - 2021-07-14 00:11:07 --> URI Class Initialized
INFO - 2021-07-14 00:11:07 --> Router Class Initialized
INFO - 2021-07-14 00:11:07 --> Output Class Initialized
INFO - 2021-07-14 00:11:07 --> Security Class Initialized
DEBUG - 2021-07-14 00:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 00:11:07 --> Input Class Initialized
INFO - 2021-07-14 00:11:07 --> Language Class Initialized
INFO - 2021-07-14 00:11:07 --> Loader Class Initialized
INFO - 2021-07-14 00:11:07 --> Helper loaded: basic_helper
INFO - 2021-07-14 00:11:07 --> Helper loaded: url_helper
INFO - 2021-07-14 00:11:07 --> Helper loaded: file_helper
INFO - 2021-07-14 00:11:07 --> Helper loaded: form_helper
INFO - 2021-07-14 00:11:07 --> Helper loaded: cookie_helper
INFO - 2021-07-14 00:11:07 --> Helper loaded: security_helper
INFO - 2021-07-14 00:11:07 --> Helper loaded: directory_helper
INFO - 2021-07-14 00:11:07 --> Helper loaded: language_helper
INFO - 2021-07-14 00:11:07 --> Helper loaded: general_helper
INFO - 2021-07-14 00:11:07 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 00:11:07 --> Database Driver Class Initialized
DEBUG - 2021-07-14 00:11:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 00:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 00:11:07 --> Parser Class Initialized
INFO - 2021-07-14 00:11:07 --> Form Validation Class Initialized
INFO - 2021-07-14 00:11:07 --> Upload Class Initialized
INFO - 2021-07-14 00:11:07 --> Email Class Initialized
INFO - 2021-07-14 00:11:07 --> MY_Model class loaded
INFO - 2021-07-14 00:11:07 --> Model "Users_model" initialized
INFO - 2021-07-14 00:11:07 --> Model "Settings_model" initialized
INFO - 2021-07-14 00:11:07 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 00:11:07 --> Model "Permissions_model" initialized
INFO - 2021-07-14 00:11:07 --> Model "Roles_model" initialized
INFO - 2021-07-14 00:11:07 --> Model "Activity_model" initialized
INFO - 2021-07-14 00:11:07 --> Model "Templates_model" initialized
INFO - 2021-07-14 00:11:07 --> Database Driver Class Initialized
INFO - 2021-07-14 00:11:08 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 00:11:08 --> Controller Class Initialized
ERROR - 2021-07-14 00:11:08 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 00:11:08 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-14 00:11:08 --> Final output sent to browser
DEBUG - 2021-07-14 00:11:08 --> Total execution time: 0.5495
INFO - 2021-07-14 00:12:24 --> Config Class Initialized
INFO - 2021-07-14 00:12:24 --> Hooks Class Initialized
DEBUG - 2021-07-14 00:12:24 --> UTF-8 Support Enabled
INFO - 2021-07-14 00:12:24 --> Utf8 Class Initialized
INFO - 2021-07-14 00:12:24 --> URI Class Initialized
INFO - 2021-07-14 00:12:24 --> Router Class Initialized
INFO - 2021-07-14 00:12:24 --> Output Class Initialized
INFO - 2021-07-14 00:12:24 --> Security Class Initialized
DEBUG - 2021-07-14 00:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 00:12:24 --> Input Class Initialized
INFO - 2021-07-14 00:12:24 --> Language Class Initialized
INFO - 2021-07-14 00:12:24 --> Loader Class Initialized
INFO - 2021-07-14 00:12:24 --> Helper loaded: basic_helper
INFO - 2021-07-14 00:12:24 --> Helper loaded: url_helper
INFO - 2021-07-14 00:12:24 --> Helper loaded: file_helper
INFO - 2021-07-14 00:12:24 --> Helper loaded: form_helper
INFO - 2021-07-14 00:12:24 --> Helper loaded: cookie_helper
INFO - 2021-07-14 00:12:24 --> Helper loaded: security_helper
INFO - 2021-07-14 00:12:24 --> Helper loaded: directory_helper
INFO - 2021-07-14 00:12:24 --> Helper loaded: language_helper
INFO - 2021-07-14 00:12:24 --> Helper loaded: general_helper
INFO - 2021-07-14 00:12:24 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 00:12:24 --> Database Driver Class Initialized
DEBUG - 2021-07-14 00:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 00:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 00:12:24 --> Parser Class Initialized
INFO - 2021-07-14 00:12:24 --> Form Validation Class Initialized
INFO - 2021-07-14 00:12:24 --> Upload Class Initialized
INFO - 2021-07-14 00:12:24 --> Email Class Initialized
INFO - 2021-07-14 00:12:24 --> MY_Model class loaded
INFO - 2021-07-14 00:12:24 --> Model "Users_model" initialized
INFO - 2021-07-14 00:12:24 --> Model "Settings_model" initialized
INFO - 2021-07-14 00:12:24 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 00:12:24 --> Model "Permissions_model" initialized
INFO - 2021-07-14 00:12:24 --> Model "Roles_model" initialized
INFO - 2021-07-14 00:12:24 --> Model "Activity_model" initialized
INFO - 2021-07-14 00:12:24 --> Model "Templates_model" initialized
INFO - 2021-07-14 00:12:24 --> Database Driver Class Initialized
INFO - 2021-07-14 00:12:24 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 00:12:24 --> Controller Class Initialized
ERROR - 2021-07-14 00:12:24 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 00:12:24 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-14 00:12:24 --> Final output sent to browser
DEBUG - 2021-07-14 00:12:24 --> Total execution time: 0.6001
INFO - 2021-07-14 00:12:25 --> Config Class Initialized
INFO - 2021-07-14 00:12:25 --> Hooks Class Initialized
DEBUG - 2021-07-14 00:12:25 --> UTF-8 Support Enabled
INFO - 2021-07-14 00:12:25 --> Utf8 Class Initialized
INFO - 2021-07-14 00:12:25 --> URI Class Initialized
INFO - 2021-07-14 00:12:25 --> Router Class Initialized
INFO - 2021-07-14 00:12:25 --> Output Class Initialized
INFO - 2021-07-14 00:12:25 --> Security Class Initialized
DEBUG - 2021-07-14 00:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 00:12:25 --> Input Class Initialized
INFO - 2021-07-14 00:12:25 --> Language Class Initialized
INFO - 2021-07-14 00:12:25 --> Loader Class Initialized
INFO - 2021-07-14 00:12:25 --> Helper loaded: basic_helper
INFO - 2021-07-14 00:12:25 --> Helper loaded: url_helper
INFO - 2021-07-14 00:12:25 --> Helper loaded: file_helper
INFO - 2021-07-14 00:12:25 --> Helper loaded: form_helper
INFO - 2021-07-14 00:12:25 --> Helper loaded: cookie_helper
INFO - 2021-07-14 00:12:25 --> Helper loaded: security_helper
INFO - 2021-07-14 00:12:25 --> Helper loaded: directory_helper
INFO - 2021-07-14 00:12:25 --> Helper loaded: language_helper
INFO - 2021-07-14 00:12:25 --> Helper loaded: general_helper
INFO - 2021-07-14 00:12:25 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 00:12:25 --> Database Driver Class Initialized
DEBUG - 2021-07-14 00:12:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 00:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 00:12:25 --> Parser Class Initialized
INFO - 2021-07-14 00:12:25 --> Form Validation Class Initialized
INFO - 2021-07-14 00:12:25 --> Upload Class Initialized
INFO - 2021-07-14 00:12:25 --> Email Class Initialized
INFO - 2021-07-14 00:12:25 --> MY_Model class loaded
INFO - 2021-07-14 00:12:25 --> Model "Users_model" initialized
INFO - 2021-07-14 00:12:25 --> Model "Settings_model" initialized
INFO - 2021-07-14 00:12:25 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 00:12:25 --> Model "Permissions_model" initialized
INFO - 2021-07-14 00:12:25 --> Model "Roles_model" initialized
INFO - 2021-07-14 00:12:25 --> Model "Activity_model" initialized
INFO - 2021-07-14 00:12:25 --> Model "Templates_model" initialized
INFO - 2021-07-14 00:12:25 --> Database Driver Class Initialized
INFO - 2021-07-14 00:12:25 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 00:12:25 --> Controller Class Initialized
ERROR - 2021-07-14 00:12:25 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 00:12:25 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-14 00:12:25 --> Final output sent to browser
DEBUG - 2021-07-14 00:12:25 --> Total execution time: 0.0742
INFO - 2021-07-14 00:12:25 --> Config Class Initialized
INFO - 2021-07-14 00:12:25 --> Hooks Class Initialized
DEBUG - 2021-07-14 00:12:25 --> UTF-8 Support Enabled
INFO - 2021-07-14 00:12:25 --> Utf8 Class Initialized
INFO - 2021-07-14 00:12:25 --> URI Class Initialized
INFO - 2021-07-14 00:12:25 --> Router Class Initialized
INFO - 2021-07-14 00:12:25 --> Output Class Initialized
INFO - 2021-07-14 00:12:25 --> Security Class Initialized
DEBUG - 2021-07-14 00:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 00:12:25 --> Input Class Initialized
INFO - 2021-07-14 00:12:25 --> Language Class Initialized
INFO - 2021-07-14 00:12:25 --> Loader Class Initialized
INFO - 2021-07-14 00:12:25 --> Helper loaded: basic_helper
INFO - 2021-07-14 00:12:25 --> Helper loaded: url_helper
INFO - 2021-07-14 00:12:25 --> Helper loaded: file_helper
INFO - 2021-07-14 00:12:25 --> Helper loaded: form_helper
INFO - 2021-07-14 00:12:25 --> Helper loaded: cookie_helper
INFO - 2021-07-14 00:12:25 --> Helper loaded: security_helper
INFO - 2021-07-14 00:12:25 --> Helper loaded: directory_helper
INFO - 2021-07-14 00:12:25 --> Helper loaded: language_helper
INFO - 2021-07-14 00:12:25 --> Helper loaded: general_helper
INFO - 2021-07-14 00:12:25 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 00:12:25 --> Database Driver Class Initialized
DEBUG - 2021-07-14 00:12:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 00:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 00:12:25 --> Parser Class Initialized
INFO - 2021-07-14 00:12:25 --> Form Validation Class Initialized
INFO - 2021-07-14 00:12:25 --> Upload Class Initialized
INFO - 2021-07-14 00:12:25 --> Email Class Initialized
INFO - 2021-07-14 00:12:25 --> MY_Model class loaded
INFO - 2021-07-14 00:12:25 --> Model "Users_model" initialized
INFO - 2021-07-14 00:12:25 --> Model "Settings_model" initialized
INFO - 2021-07-14 00:12:25 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 00:12:25 --> Model "Permissions_model" initialized
INFO - 2021-07-14 00:12:25 --> Model "Roles_model" initialized
INFO - 2021-07-14 00:12:25 --> Model "Activity_model" initialized
INFO - 2021-07-14 00:12:25 --> Model "Templates_model" initialized
INFO - 2021-07-14 00:12:25 --> Database Driver Class Initialized
INFO - 2021-07-14 00:12:25 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 00:12:25 --> Controller Class Initialized
ERROR - 2021-07-14 00:12:25 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 00:12:25 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-14 00:12:25 --> Final output sent to browser
DEBUG - 2021-07-14 00:12:25 --> Total execution time: 0.0824
INFO - 2021-07-14 00:12:50 --> Config Class Initialized
INFO - 2021-07-14 00:12:50 --> Hooks Class Initialized
DEBUG - 2021-07-14 00:12:50 --> UTF-8 Support Enabled
INFO - 2021-07-14 00:12:50 --> Utf8 Class Initialized
INFO - 2021-07-14 00:12:50 --> URI Class Initialized
INFO - 2021-07-14 00:12:50 --> Router Class Initialized
INFO - 2021-07-14 00:12:50 --> Output Class Initialized
INFO - 2021-07-14 00:12:50 --> Security Class Initialized
DEBUG - 2021-07-14 00:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 00:12:50 --> Input Class Initialized
INFO - 2021-07-14 00:12:50 --> Language Class Initialized
INFO - 2021-07-14 00:12:50 --> Loader Class Initialized
INFO - 2021-07-14 00:12:50 --> Helper loaded: basic_helper
INFO - 2021-07-14 00:12:50 --> Helper loaded: url_helper
INFO - 2021-07-14 00:12:50 --> Helper loaded: file_helper
INFO - 2021-07-14 00:12:50 --> Helper loaded: form_helper
INFO - 2021-07-14 00:12:50 --> Helper loaded: cookie_helper
INFO - 2021-07-14 00:12:50 --> Helper loaded: security_helper
INFO - 2021-07-14 00:12:50 --> Helper loaded: directory_helper
INFO - 2021-07-14 00:12:50 --> Helper loaded: language_helper
INFO - 2021-07-14 00:12:50 --> Helper loaded: general_helper
INFO - 2021-07-14 00:12:50 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 00:12:50 --> Database Driver Class Initialized
DEBUG - 2021-07-14 00:12:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 00:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 00:12:50 --> Parser Class Initialized
INFO - 2021-07-14 00:12:50 --> Form Validation Class Initialized
INFO - 2021-07-14 00:12:50 --> Upload Class Initialized
INFO - 2021-07-14 00:12:50 --> Email Class Initialized
INFO - 2021-07-14 00:12:50 --> MY_Model class loaded
INFO - 2021-07-14 00:12:50 --> Model "Users_model" initialized
INFO - 2021-07-14 00:12:50 --> Model "Settings_model" initialized
INFO - 2021-07-14 00:12:50 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 00:12:50 --> Model "Permissions_model" initialized
INFO - 2021-07-14 00:12:50 --> Model "Roles_model" initialized
INFO - 2021-07-14 00:12:50 --> Model "Activity_model" initialized
INFO - 2021-07-14 00:12:50 --> Model "Templates_model" initialized
INFO - 2021-07-14 00:12:50 --> Database Driver Class Initialized
INFO - 2021-07-14 00:12:50 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 00:12:50 --> Controller Class Initialized
ERROR - 2021-07-14 00:12:50 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 00:12:50 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-14 00:12:50 --> Final output sent to browser
DEBUG - 2021-07-14 00:12:50 --> Total execution time: 0.1244
INFO - 2021-07-14 00:13:00 --> Config Class Initialized
INFO - 2021-07-14 00:13:00 --> Hooks Class Initialized
DEBUG - 2021-07-14 00:13:00 --> UTF-8 Support Enabled
INFO - 2021-07-14 00:13:00 --> Utf8 Class Initialized
INFO - 2021-07-14 00:13:00 --> URI Class Initialized
INFO - 2021-07-14 00:13:00 --> Router Class Initialized
INFO - 2021-07-14 00:13:00 --> Output Class Initialized
INFO - 2021-07-14 00:13:00 --> Security Class Initialized
DEBUG - 2021-07-14 00:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 00:13:00 --> Input Class Initialized
INFO - 2021-07-14 00:13:00 --> Language Class Initialized
INFO - 2021-07-14 00:13:00 --> Loader Class Initialized
INFO - 2021-07-14 00:13:00 --> Helper loaded: basic_helper
INFO - 2021-07-14 00:13:00 --> Helper loaded: url_helper
INFO - 2021-07-14 00:13:00 --> Helper loaded: file_helper
INFO - 2021-07-14 00:13:00 --> Helper loaded: form_helper
INFO - 2021-07-14 00:13:00 --> Helper loaded: cookie_helper
INFO - 2021-07-14 00:13:00 --> Helper loaded: security_helper
INFO - 2021-07-14 00:13:00 --> Helper loaded: directory_helper
INFO - 2021-07-14 00:13:00 --> Helper loaded: language_helper
INFO - 2021-07-14 00:13:00 --> Helper loaded: general_helper
INFO - 2021-07-14 00:13:00 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 00:13:00 --> Database Driver Class Initialized
DEBUG - 2021-07-14 00:13:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 00:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 00:13:00 --> Parser Class Initialized
INFO - 2021-07-14 00:13:00 --> Form Validation Class Initialized
INFO - 2021-07-14 00:13:00 --> Upload Class Initialized
INFO - 2021-07-14 00:13:00 --> Email Class Initialized
INFO - 2021-07-14 00:13:00 --> MY_Model class loaded
INFO - 2021-07-14 00:13:00 --> Model "Users_model" initialized
INFO - 2021-07-14 00:13:00 --> Model "Settings_model" initialized
INFO - 2021-07-14 00:13:00 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 00:13:00 --> Model "Permissions_model" initialized
INFO - 2021-07-14 00:13:00 --> Model "Roles_model" initialized
INFO - 2021-07-14 00:13:00 --> Model "Activity_model" initialized
INFO - 2021-07-14 00:13:00 --> Model "Templates_model" initialized
INFO - 2021-07-14 00:13:00 --> Database Driver Class Initialized
INFO - 2021-07-14 00:13:00 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 00:13:00 --> Controller Class Initialized
ERROR - 2021-07-14 00:13:00 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 00:13:00 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-14 00:13:00 --> Final output sent to browser
DEBUG - 2021-07-14 00:13:00 --> Total execution time: 0.1408
INFO - 2021-07-14 00:13:29 --> Config Class Initialized
INFO - 2021-07-14 00:13:29 --> Hooks Class Initialized
DEBUG - 2021-07-14 00:13:29 --> UTF-8 Support Enabled
INFO - 2021-07-14 00:13:29 --> Utf8 Class Initialized
INFO - 2021-07-14 00:13:29 --> URI Class Initialized
INFO - 2021-07-14 00:13:29 --> Router Class Initialized
INFO - 2021-07-14 00:13:29 --> Output Class Initialized
INFO - 2021-07-14 00:13:29 --> Security Class Initialized
DEBUG - 2021-07-14 00:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 00:13:29 --> Input Class Initialized
INFO - 2021-07-14 00:13:29 --> Language Class Initialized
INFO - 2021-07-14 00:13:29 --> Loader Class Initialized
INFO - 2021-07-14 00:13:29 --> Helper loaded: basic_helper
INFO - 2021-07-14 00:13:29 --> Helper loaded: url_helper
INFO - 2021-07-14 00:13:29 --> Helper loaded: file_helper
INFO - 2021-07-14 00:13:29 --> Helper loaded: form_helper
INFO - 2021-07-14 00:13:29 --> Helper loaded: cookie_helper
INFO - 2021-07-14 00:13:29 --> Helper loaded: security_helper
INFO - 2021-07-14 00:13:29 --> Helper loaded: directory_helper
INFO - 2021-07-14 00:13:29 --> Helper loaded: language_helper
INFO - 2021-07-14 00:13:29 --> Helper loaded: general_helper
INFO - 2021-07-14 00:13:29 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 00:13:29 --> Database Driver Class Initialized
DEBUG - 2021-07-14 00:13:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 00:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 00:13:29 --> Parser Class Initialized
INFO - 2021-07-14 00:13:29 --> Form Validation Class Initialized
INFO - 2021-07-14 00:13:29 --> Upload Class Initialized
INFO - 2021-07-14 00:13:29 --> Email Class Initialized
INFO - 2021-07-14 00:13:29 --> MY_Model class loaded
INFO - 2021-07-14 00:13:29 --> Model "Users_model" initialized
INFO - 2021-07-14 00:13:29 --> Model "Settings_model" initialized
INFO - 2021-07-14 00:13:29 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 00:13:29 --> Model "Permissions_model" initialized
INFO - 2021-07-14 00:13:29 --> Model "Roles_model" initialized
INFO - 2021-07-14 00:13:29 --> Model "Activity_model" initialized
INFO - 2021-07-14 00:13:29 --> Model "Templates_model" initialized
INFO - 2021-07-14 00:13:29 --> Database Driver Class Initialized
INFO - 2021-07-14 00:13:29 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 00:13:29 --> Controller Class Initialized
ERROR - 2021-07-14 00:13:29 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 00:13:29 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-14 00:13:29 --> Final output sent to browser
DEBUG - 2021-07-14 00:13:29 --> Total execution time: 0.1319
INFO - 2021-07-14 00:13:38 --> Config Class Initialized
INFO - 2021-07-14 00:13:38 --> Hooks Class Initialized
DEBUG - 2021-07-14 00:13:38 --> UTF-8 Support Enabled
INFO - 2021-07-14 00:13:38 --> Utf8 Class Initialized
INFO - 2021-07-14 00:13:38 --> URI Class Initialized
INFO - 2021-07-14 00:13:38 --> Router Class Initialized
INFO - 2021-07-14 00:13:38 --> Output Class Initialized
INFO - 2021-07-14 00:13:38 --> Security Class Initialized
DEBUG - 2021-07-14 00:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 00:13:38 --> Input Class Initialized
INFO - 2021-07-14 00:13:38 --> Language Class Initialized
INFO - 2021-07-14 00:13:38 --> Loader Class Initialized
INFO - 2021-07-14 00:13:38 --> Helper loaded: basic_helper
INFO - 2021-07-14 00:13:38 --> Helper loaded: url_helper
INFO - 2021-07-14 00:13:38 --> Helper loaded: file_helper
INFO - 2021-07-14 00:13:38 --> Helper loaded: form_helper
INFO - 2021-07-14 00:13:38 --> Helper loaded: cookie_helper
INFO - 2021-07-14 00:13:38 --> Helper loaded: security_helper
INFO - 2021-07-14 00:13:38 --> Helper loaded: directory_helper
INFO - 2021-07-14 00:13:38 --> Helper loaded: language_helper
INFO - 2021-07-14 00:13:38 --> Helper loaded: general_helper
INFO - 2021-07-14 00:13:38 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 00:13:38 --> Database Driver Class Initialized
DEBUG - 2021-07-14 00:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 00:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 00:13:38 --> Parser Class Initialized
INFO - 2021-07-14 00:13:38 --> Form Validation Class Initialized
INFO - 2021-07-14 00:13:38 --> Upload Class Initialized
INFO - 2021-07-14 00:13:38 --> Email Class Initialized
INFO - 2021-07-14 00:13:38 --> MY_Model class loaded
INFO - 2021-07-14 00:13:38 --> Model "Users_model" initialized
INFO - 2021-07-14 00:13:38 --> Model "Settings_model" initialized
INFO - 2021-07-14 00:13:38 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 00:13:38 --> Model "Permissions_model" initialized
INFO - 2021-07-14 00:13:38 --> Model "Roles_model" initialized
INFO - 2021-07-14 00:13:38 --> Model "Activity_model" initialized
INFO - 2021-07-14 00:13:38 --> Model "Templates_model" initialized
INFO - 2021-07-14 00:13:38 --> Database Driver Class Initialized
INFO - 2021-07-14 00:13:38 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 00:13:38 --> Controller Class Initialized
ERROR - 2021-07-14 00:13:38 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 00:13:38 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-14 00:13:38 --> Final output sent to browser
DEBUG - 2021-07-14 00:13:38 --> Total execution time: 0.1265
INFO - 2021-07-14 00:13:46 --> Config Class Initialized
INFO - 2021-07-14 00:13:46 --> Hooks Class Initialized
DEBUG - 2021-07-14 00:13:46 --> UTF-8 Support Enabled
INFO - 2021-07-14 00:13:46 --> Utf8 Class Initialized
INFO - 2021-07-14 00:13:46 --> URI Class Initialized
INFO - 2021-07-14 00:13:46 --> Router Class Initialized
INFO - 2021-07-14 00:13:46 --> Output Class Initialized
INFO - 2021-07-14 00:13:46 --> Security Class Initialized
DEBUG - 2021-07-14 00:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 00:13:46 --> Input Class Initialized
INFO - 2021-07-14 00:13:46 --> Language Class Initialized
INFO - 2021-07-14 00:13:46 --> Loader Class Initialized
INFO - 2021-07-14 00:13:46 --> Helper loaded: basic_helper
INFO - 2021-07-14 00:13:46 --> Helper loaded: url_helper
INFO - 2021-07-14 00:13:46 --> Helper loaded: file_helper
INFO - 2021-07-14 00:13:46 --> Helper loaded: form_helper
INFO - 2021-07-14 00:13:46 --> Helper loaded: cookie_helper
INFO - 2021-07-14 00:13:46 --> Helper loaded: security_helper
INFO - 2021-07-14 00:13:46 --> Helper loaded: directory_helper
INFO - 2021-07-14 00:13:46 --> Helper loaded: language_helper
INFO - 2021-07-14 00:13:46 --> Helper loaded: general_helper
INFO - 2021-07-14 00:13:46 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 00:13:46 --> Database Driver Class Initialized
DEBUG - 2021-07-14 00:13:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 00:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 00:13:46 --> Parser Class Initialized
INFO - 2021-07-14 00:13:46 --> Form Validation Class Initialized
INFO - 2021-07-14 00:13:46 --> Upload Class Initialized
INFO - 2021-07-14 00:13:46 --> Email Class Initialized
INFO - 2021-07-14 00:13:46 --> MY_Model class loaded
INFO - 2021-07-14 00:13:46 --> Model "Users_model" initialized
INFO - 2021-07-14 00:13:46 --> Model "Settings_model" initialized
INFO - 2021-07-14 00:13:46 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 00:13:46 --> Model "Permissions_model" initialized
INFO - 2021-07-14 00:13:46 --> Model "Roles_model" initialized
INFO - 2021-07-14 00:13:46 --> Model "Activity_model" initialized
INFO - 2021-07-14 00:13:46 --> Model "Templates_model" initialized
INFO - 2021-07-14 00:13:46 --> Database Driver Class Initialized
INFO - 2021-07-14 00:13:46 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 00:13:46 --> Controller Class Initialized
ERROR - 2021-07-14 00:13:46 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 00:13:46 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-14 00:13:46 --> Final output sent to browser
DEBUG - 2021-07-14 00:13:46 --> Total execution time: 0.1245
INFO - 2021-07-14 00:14:02 --> Config Class Initialized
INFO - 2021-07-14 00:14:02 --> Hooks Class Initialized
DEBUG - 2021-07-14 00:14:02 --> UTF-8 Support Enabled
INFO - 2021-07-14 00:14:02 --> Utf8 Class Initialized
INFO - 2021-07-14 00:14:02 --> URI Class Initialized
INFO - 2021-07-14 00:14:02 --> Router Class Initialized
INFO - 2021-07-14 00:14:02 --> Output Class Initialized
INFO - 2021-07-14 00:14:02 --> Security Class Initialized
DEBUG - 2021-07-14 00:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 00:14:02 --> Input Class Initialized
INFO - 2021-07-14 00:14:02 --> Language Class Initialized
INFO - 2021-07-14 00:14:02 --> Loader Class Initialized
INFO - 2021-07-14 00:14:02 --> Helper loaded: basic_helper
INFO - 2021-07-14 00:14:02 --> Helper loaded: url_helper
INFO - 2021-07-14 00:14:02 --> Helper loaded: file_helper
INFO - 2021-07-14 00:14:02 --> Helper loaded: form_helper
INFO - 2021-07-14 00:14:02 --> Helper loaded: cookie_helper
INFO - 2021-07-14 00:14:02 --> Helper loaded: security_helper
INFO - 2021-07-14 00:14:02 --> Helper loaded: directory_helper
INFO - 2021-07-14 00:14:02 --> Helper loaded: language_helper
INFO - 2021-07-14 00:14:02 --> Helper loaded: general_helper
INFO - 2021-07-14 00:14:02 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 00:14:02 --> Database Driver Class Initialized
DEBUG - 2021-07-14 00:14:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 00:14:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 00:14:02 --> Parser Class Initialized
INFO - 2021-07-14 00:14:02 --> Form Validation Class Initialized
INFO - 2021-07-14 00:14:02 --> Upload Class Initialized
INFO - 2021-07-14 00:14:02 --> Email Class Initialized
INFO - 2021-07-14 00:14:02 --> MY_Model class loaded
INFO - 2021-07-14 00:14:02 --> Model "Users_model" initialized
INFO - 2021-07-14 00:14:02 --> Model "Settings_model" initialized
INFO - 2021-07-14 00:14:02 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 00:14:02 --> Model "Permissions_model" initialized
INFO - 2021-07-14 00:14:02 --> Model "Roles_model" initialized
INFO - 2021-07-14 00:14:02 --> Model "Activity_model" initialized
INFO - 2021-07-14 00:14:02 --> Model "Templates_model" initialized
INFO - 2021-07-14 00:14:02 --> Database Driver Class Initialized
INFO - 2021-07-14 00:14:02 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 00:14:02 --> Controller Class Initialized
ERROR - 2021-07-14 00:14:02 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 00:14:02 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-14 00:14:02 --> Final output sent to browser
DEBUG - 2021-07-14 00:14:02 --> Total execution time: 0.1231
INFO - 2021-07-14 00:15:11 --> Config Class Initialized
INFO - 2021-07-14 00:15:11 --> Hooks Class Initialized
DEBUG - 2021-07-14 00:15:11 --> UTF-8 Support Enabled
INFO - 2021-07-14 00:15:11 --> Utf8 Class Initialized
INFO - 2021-07-14 00:15:11 --> URI Class Initialized
INFO - 2021-07-14 00:15:11 --> Router Class Initialized
INFO - 2021-07-14 00:15:11 --> Output Class Initialized
INFO - 2021-07-14 00:15:11 --> Security Class Initialized
DEBUG - 2021-07-14 00:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 00:15:11 --> Input Class Initialized
INFO - 2021-07-14 00:15:11 --> Language Class Initialized
INFO - 2021-07-14 00:15:11 --> Loader Class Initialized
INFO - 2021-07-14 00:15:11 --> Helper loaded: basic_helper
INFO - 2021-07-14 00:15:11 --> Helper loaded: url_helper
INFO - 2021-07-14 00:15:11 --> Helper loaded: file_helper
INFO - 2021-07-14 00:15:11 --> Helper loaded: form_helper
INFO - 2021-07-14 00:15:11 --> Helper loaded: cookie_helper
INFO - 2021-07-14 00:15:11 --> Helper loaded: security_helper
INFO - 2021-07-14 00:15:11 --> Helper loaded: directory_helper
INFO - 2021-07-14 00:15:11 --> Helper loaded: language_helper
INFO - 2021-07-14 00:15:11 --> Helper loaded: general_helper
INFO - 2021-07-14 00:15:11 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 00:15:11 --> Database Driver Class Initialized
DEBUG - 2021-07-14 00:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 00:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 00:15:11 --> Parser Class Initialized
INFO - 2021-07-14 00:15:11 --> Form Validation Class Initialized
INFO - 2021-07-14 00:15:11 --> Upload Class Initialized
INFO - 2021-07-14 00:15:11 --> Email Class Initialized
INFO - 2021-07-14 00:15:11 --> MY_Model class loaded
INFO - 2021-07-14 00:15:11 --> Model "Users_model" initialized
INFO - 2021-07-14 00:15:11 --> Model "Settings_model" initialized
INFO - 2021-07-14 00:15:11 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 00:15:11 --> Model "Permissions_model" initialized
INFO - 2021-07-14 00:15:11 --> Model "Roles_model" initialized
INFO - 2021-07-14 00:15:11 --> Model "Activity_model" initialized
INFO - 2021-07-14 00:15:11 --> Model "Templates_model" initialized
INFO - 2021-07-14 00:15:11 --> Database Driver Class Initialized
INFO - 2021-07-14 00:15:11 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 00:15:11 --> Controller Class Initialized
ERROR - 2021-07-14 00:15:11 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 00:15:11 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-14 00:15:11 --> Final output sent to browser
DEBUG - 2021-07-14 00:15:11 --> Total execution time: 0.1437
INFO - 2021-07-14 00:17:10 --> Config Class Initialized
INFO - 2021-07-14 00:17:10 --> Hooks Class Initialized
DEBUG - 2021-07-14 00:17:10 --> UTF-8 Support Enabled
INFO - 2021-07-14 00:17:10 --> Utf8 Class Initialized
INFO - 2021-07-14 00:17:10 --> URI Class Initialized
INFO - 2021-07-14 00:17:10 --> Router Class Initialized
INFO - 2021-07-14 00:17:10 --> Output Class Initialized
INFO - 2021-07-14 00:17:10 --> Security Class Initialized
DEBUG - 2021-07-14 00:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 00:17:10 --> Input Class Initialized
INFO - 2021-07-14 00:17:10 --> Language Class Initialized
INFO - 2021-07-14 00:17:10 --> Loader Class Initialized
INFO - 2021-07-14 00:17:10 --> Helper loaded: basic_helper
INFO - 2021-07-14 00:17:10 --> Helper loaded: url_helper
INFO - 2021-07-14 00:17:10 --> Helper loaded: file_helper
INFO - 2021-07-14 00:17:10 --> Helper loaded: form_helper
INFO - 2021-07-14 00:17:10 --> Helper loaded: cookie_helper
INFO - 2021-07-14 00:17:10 --> Helper loaded: security_helper
INFO - 2021-07-14 00:17:10 --> Helper loaded: directory_helper
INFO - 2021-07-14 00:17:10 --> Helper loaded: language_helper
INFO - 2021-07-14 00:17:10 --> Helper loaded: general_helper
INFO - 2021-07-14 00:17:10 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 00:17:10 --> Database Driver Class Initialized
DEBUG - 2021-07-14 00:17:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 00:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 00:17:10 --> Parser Class Initialized
INFO - 2021-07-14 00:17:10 --> Form Validation Class Initialized
INFO - 2021-07-14 00:17:10 --> Upload Class Initialized
INFO - 2021-07-14 00:17:10 --> Email Class Initialized
INFO - 2021-07-14 00:17:10 --> MY_Model class loaded
INFO - 2021-07-14 00:17:10 --> Model "Users_model" initialized
INFO - 2021-07-14 00:17:10 --> Model "Settings_model" initialized
INFO - 2021-07-14 00:17:10 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 00:17:10 --> Model "Permissions_model" initialized
INFO - 2021-07-14 00:17:10 --> Model "Roles_model" initialized
INFO - 2021-07-14 00:17:10 --> Model "Activity_model" initialized
INFO - 2021-07-14 00:17:10 --> Model "Templates_model" initialized
INFO - 2021-07-14 00:17:10 --> Database Driver Class Initialized
INFO - 2021-07-14 00:17:10 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 00:17:10 --> Controller Class Initialized
ERROR - 2021-07-14 00:17:10 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-14 00:17:10 --> Severity: error --> Exception: Call to undefined function datetime() C:\wamp64\www\crm\application\views\car\car_list.php 77
INFO - 2021-07-14 00:18:39 --> Config Class Initialized
INFO - 2021-07-14 00:18:39 --> Hooks Class Initialized
DEBUG - 2021-07-14 00:18:39 --> UTF-8 Support Enabled
INFO - 2021-07-14 00:18:39 --> Utf8 Class Initialized
INFO - 2021-07-14 00:18:39 --> URI Class Initialized
INFO - 2021-07-14 00:18:39 --> Router Class Initialized
INFO - 2021-07-14 00:18:39 --> Output Class Initialized
INFO - 2021-07-14 00:18:39 --> Security Class Initialized
DEBUG - 2021-07-14 00:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 00:18:39 --> Input Class Initialized
INFO - 2021-07-14 00:18:39 --> Language Class Initialized
INFO - 2021-07-14 00:18:39 --> Loader Class Initialized
INFO - 2021-07-14 00:18:39 --> Helper loaded: basic_helper
INFO - 2021-07-14 00:18:39 --> Helper loaded: url_helper
INFO - 2021-07-14 00:18:39 --> Helper loaded: file_helper
INFO - 2021-07-14 00:18:39 --> Helper loaded: form_helper
INFO - 2021-07-14 00:18:39 --> Helper loaded: cookie_helper
INFO - 2021-07-14 00:18:39 --> Helper loaded: security_helper
INFO - 2021-07-14 00:18:39 --> Helper loaded: directory_helper
INFO - 2021-07-14 00:18:39 --> Helper loaded: language_helper
INFO - 2021-07-14 00:18:39 --> Helper loaded: general_helper
INFO - 2021-07-14 00:18:39 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 00:18:39 --> Database Driver Class Initialized
DEBUG - 2021-07-14 00:18:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 00:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 00:18:39 --> Parser Class Initialized
INFO - 2021-07-14 00:18:39 --> Form Validation Class Initialized
INFO - 2021-07-14 00:18:39 --> Upload Class Initialized
INFO - 2021-07-14 00:18:39 --> Email Class Initialized
INFO - 2021-07-14 00:18:39 --> MY_Model class loaded
INFO - 2021-07-14 00:18:39 --> Model "Users_model" initialized
INFO - 2021-07-14 00:18:39 --> Model "Settings_model" initialized
INFO - 2021-07-14 00:18:39 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 00:18:39 --> Model "Permissions_model" initialized
INFO - 2021-07-14 00:18:39 --> Model "Roles_model" initialized
INFO - 2021-07-14 00:18:39 --> Model "Activity_model" initialized
INFO - 2021-07-14 00:18:39 --> Model "Templates_model" initialized
INFO - 2021-07-14 00:18:39 --> Database Driver Class Initialized
INFO - 2021-07-14 00:18:39 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 00:18:39 --> Controller Class Initialized
ERROR - 2021-07-14 00:18:39 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 00:18:39 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-14 00:18:39 --> Final output sent to browser
DEBUG - 2021-07-14 00:18:39 --> Total execution time: 0.5337
INFO - 2021-07-14 00:19:17 --> Config Class Initialized
INFO - 2021-07-14 00:19:17 --> Hooks Class Initialized
DEBUG - 2021-07-14 00:19:17 --> UTF-8 Support Enabled
INFO - 2021-07-14 00:19:17 --> Utf8 Class Initialized
INFO - 2021-07-14 00:19:17 --> URI Class Initialized
INFO - 2021-07-14 00:19:17 --> Router Class Initialized
INFO - 2021-07-14 00:19:17 --> Output Class Initialized
INFO - 2021-07-14 00:19:17 --> Security Class Initialized
DEBUG - 2021-07-14 00:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 00:19:17 --> Input Class Initialized
INFO - 2021-07-14 00:19:17 --> Language Class Initialized
INFO - 2021-07-14 00:19:17 --> Loader Class Initialized
INFO - 2021-07-14 00:19:17 --> Helper loaded: basic_helper
INFO - 2021-07-14 00:19:17 --> Helper loaded: url_helper
INFO - 2021-07-14 00:19:17 --> Helper loaded: file_helper
INFO - 2021-07-14 00:19:17 --> Helper loaded: form_helper
INFO - 2021-07-14 00:19:17 --> Helper loaded: cookie_helper
INFO - 2021-07-14 00:19:17 --> Helper loaded: security_helper
INFO - 2021-07-14 00:19:17 --> Helper loaded: directory_helper
INFO - 2021-07-14 00:19:17 --> Helper loaded: language_helper
INFO - 2021-07-14 00:19:17 --> Helper loaded: general_helper
INFO - 2021-07-14 00:19:17 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 00:19:17 --> Database Driver Class Initialized
DEBUG - 2021-07-14 00:19:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 00:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 00:19:17 --> Parser Class Initialized
INFO - 2021-07-14 00:19:17 --> Form Validation Class Initialized
INFO - 2021-07-14 00:19:17 --> Upload Class Initialized
INFO - 2021-07-14 00:19:17 --> Email Class Initialized
INFO - 2021-07-14 00:19:17 --> MY_Model class loaded
INFO - 2021-07-14 00:19:17 --> Model "Users_model" initialized
INFO - 2021-07-14 00:19:17 --> Model "Settings_model" initialized
INFO - 2021-07-14 00:19:17 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 00:19:17 --> Model "Permissions_model" initialized
INFO - 2021-07-14 00:19:17 --> Model "Roles_model" initialized
INFO - 2021-07-14 00:19:17 --> Model "Activity_model" initialized
INFO - 2021-07-14 00:19:17 --> Model "Templates_model" initialized
INFO - 2021-07-14 00:19:17 --> Database Driver Class Initialized
INFO - 2021-07-14 00:19:17 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 00:19:17 --> Controller Class Initialized
ERROR - 2021-07-14 00:19:17 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 00:19:17 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-14 00:19:17 --> Final output sent to browser
DEBUG - 2021-07-14 00:19:17 --> Total execution time: 0.1246
INFO - 2021-07-14 00:20:03 --> Config Class Initialized
INFO - 2021-07-14 00:20:03 --> Hooks Class Initialized
DEBUG - 2021-07-14 00:20:03 --> UTF-8 Support Enabled
INFO - 2021-07-14 00:20:03 --> Utf8 Class Initialized
INFO - 2021-07-14 00:20:03 --> URI Class Initialized
INFO - 2021-07-14 00:20:03 --> Router Class Initialized
INFO - 2021-07-14 00:20:03 --> Output Class Initialized
INFO - 2021-07-14 00:20:03 --> Security Class Initialized
DEBUG - 2021-07-14 00:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 00:20:03 --> Input Class Initialized
INFO - 2021-07-14 00:20:03 --> Language Class Initialized
INFO - 2021-07-14 00:20:03 --> Loader Class Initialized
INFO - 2021-07-14 00:20:03 --> Helper loaded: basic_helper
INFO - 2021-07-14 00:20:03 --> Helper loaded: url_helper
INFO - 2021-07-14 00:20:03 --> Helper loaded: file_helper
INFO - 2021-07-14 00:20:03 --> Helper loaded: form_helper
INFO - 2021-07-14 00:20:03 --> Helper loaded: cookie_helper
INFO - 2021-07-14 00:20:03 --> Helper loaded: security_helper
INFO - 2021-07-14 00:20:03 --> Helper loaded: directory_helper
INFO - 2021-07-14 00:20:03 --> Helper loaded: language_helper
INFO - 2021-07-14 00:20:03 --> Helper loaded: general_helper
INFO - 2021-07-14 00:20:03 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 00:20:03 --> Database Driver Class Initialized
DEBUG - 2021-07-14 00:20:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 00:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 00:20:03 --> Parser Class Initialized
INFO - 2021-07-14 00:20:03 --> Form Validation Class Initialized
INFO - 2021-07-14 00:20:03 --> Upload Class Initialized
INFO - 2021-07-14 00:20:03 --> Email Class Initialized
INFO - 2021-07-14 00:20:03 --> MY_Model class loaded
INFO - 2021-07-14 00:20:03 --> Model "Users_model" initialized
INFO - 2021-07-14 00:20:03 --> Model "Settings_model" initialized
INFO - 2021-07-14 00:20:03 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 00:20:03 --> Model "Permissions_model" initialized
INFO - 2021-07-14 00:20:03 --> Model "Roles_model" initialized
INFO - 2021-07-14 00:20:03 --> Model "Activity_model" initialized
INFO - 2021-07-14 00:20:03 --> Model "Templates_model" initialized
INFO - 2021-07-14 00:20:03 --> Database Driver Class Initialized
INFO - 2021-07-14 00:20:03 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 00:20:03 --> Controller Class Initialized
ERROR - 2021-07-14 00:20:03 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 00:20:03 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-14 00:20:03 --> Final output sent to browser
DEBUG - 2021-07-14 00:20:03 --> Total execution time: 0.1225
INFO - 2021-07-14 00:22:11 --> Config Class Initialized
INFO - 2021-07-14 00:22:11 --> Hooks Class Initialized
DEBUG - 2021-07-14 00:22:11 --> UTF-8 Support Enabled
INFO - 2021-07-14 00:22:11 --> Utf8 Class Initialized
INFO - 2021-07-14 00:22:11 --> URI Class Initialized
INFO - 2021-07-14 00:22:11 --> Router Class Initialized
INFO - 2021-07-14 00:22:11 --> Output Class Initialized
INFO - 2021-07-14 00:22:11 --> Security Class Initialized
DEBUG - 2021-07-14 00:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 00:22:11 --> Input Class Initialized
INFO - 2021-07-14 00:22:11 --> Language Class Initialized
INFO - 2021-07-14 00:22:11 --> Loader Class Initialized
INFO - 2021-07-14 00:22:11 --> Helper loaded: basic_helper
INFO - 2021-07-14 00:22:11 --> Helper loaded: url_helper
INFO - 2021-07-14 00:22:11 --> Helper loaded: file_helper
INFO - 2021-07-14 00:22:11 --> Helper loaded: form_helper
INFO - 2021-07-14 00:22:11 --> Helper loaded: cookie_helper
INFO - 2021-07-14 00:22:11 --> Helper loaded: security_helper
INFO - 2021-07-14 00:22:11 --> Helper loaded: directory_helper
INFO - 2021-07-14 00:22:11 --> Helper loaded: language_helper
INFO - 2021-07-14 00:22:11 --> Helper loaded: general_helper
INFO - 2021-07-14 00:22:11 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 00:22:11 --> Database Driver Class Initialized
DEBUG - 2021-07-14 00:22:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 00:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 00:22:11 --> Parser Class Initialized
INFO - 2021-07-14 00:22:11 --> Form Validation Class Initialized
INFO - 2021-07-14 00:22:11 --> Upload Class Initialized
INFO - 2021-07-14 00:22:11 --> Email Class Initialized
INFO - 2021-07-14 00:22:11 --> MY_Model class loaded
INFO - 2021-07-14 00:22:11 --> Model "Users_model" initialized
INFO - 2021-07-14 00:22:11 --> Model "Settings_model" initialized
INFO - 2021-07-14 00:22:11 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 00:22:11 --> Model "Permissions_model" initialized
INFO - 2021-07-14 00:22:11 --> Model "Roles_model" initialized
INFO - 2021-07-14 00:22:11 --> Model "Activity_model" initialized
INFO - 2021-07-14 00:22:11 --> Model "Templates_model" initialized
INFO - 2021-07-14 00:22:11 --> Database Driver Class Initialized
INFO - 2021-07-14 00:22:12 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 00:22:12 --> Controller Class Initialized
ERROR - 2021-07-14 00:22:12 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 00:22:12 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-14 00:22:12 --> Final output sent to browser
DEBUG - 2021-07-14 00:22:12 --> Total execution time: 0.6462
INFO - 2021-07-14 00:22:15 --> Config Class Initialized
INFO - 2021-07-14 00:22:15 --> Hooks Class Initialized
DEBUG - 2021-07-14 00:22:15 --> UTF-8 Support Enabled
INFO - 2021-07-14 00:22:15 --> Utf8 Class Initialized
INFO - 2021-07-14 00:22:15 --> URI Class Initialized
INFO - 2021-07-14 00:22:15 --> Router Class Initialized
INFO - 2021-07-14 00:22:15 --> Output Class Initialized
INFO - 2021-07-14 00:22:15 --> Security Class Initialized
DEBUG - 2021-07-14 00:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 00:22:15 --> Input Class Initialized
INFO - 2021-07-14 00:22:15 --> Language Class Initialized
INFO - 2021-07-14 00:22:15 --> Loader Class Initialized
INFO - 2021-07-14 00:22:15 --> Helper loaded: basic_helper
INFO - 2021-07-14 00:22:15 --> Helper loaded: url_helper
INFO - 2021-07-14 00:22:15 --> Helper loaded: file_helper
INFO - 2021-07-14 00:22:15 --> Helper loaded: form_helper
INFO - 2021-07-14 00:22:15 --> Helper loaded: cookie_helper
INFO - 2021-07-14 00:22:15 --> Helper loaded: security_helper
INFO - 2021-07-14 00:22:15 --> Helper loaded: directory_helper
INFO - 2021-07-14 00:22:15 --> Helper loaded: language_helper
INFO - 2021-07-14 00:22:15 --> Helper loaded: general_helper
INFO - 2021-07-14 00:22:15 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 00:22:15 --> Database Driver Class Initialized
DEBUG - 2021-07-14 00:22:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 00:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 00:22:15 --> Parser Class Initialized
INFO - 2021-07-14 00:22:15 --> Form Validation Class Initialized
INFO - 2021-07-14 00:22:15 --> Upload Class Initialized
INFO - 2021-07-14 00:22:15 --> Email Class Initialized
INFO - 2021-07-14 00:22:15 --> MY_Model class loaded
INFO - 2021-07-14 00:22:15 --> Model "Users_model" initialized
INFO - 2021-07-14 00:22:15 --> Model "Settings_model" initialized
INFO - 2021-07-14 00:22:15 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 00:22:15 --> Model "Permissions_model" initialized
INFO - 2021-07-14 00:22:15 --> Model "Roles_model" initialized
INFO - 2021-07-14 00:22:15 --> Model "Activity_model" initialized
INFO - 2021-07-14 00:22:15 --> Model "Templates_model" initialized
INFO - 2021-07-14 00:22:15 --> Database Driver Class Initialized
INFO - 2021-07-14 00:22:15 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 00:22:15 --> Controller Class Initialized
ERROR - 2021-07-14 00:22:15 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 00:22:15 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-14 00:22:15 --> Final output sent to browser
DEBUG - 2021-07-14 00:22:15 --> Total execution time: 0.0848
INFO - 2021-07-14 00:22:46 --> Config Class Initialized
INFO - 2021-07-14 00:22:46 --> Hooks Class Initialized
DEBUG - 2021-07-14 00:22:46 --> UTF-8 Support Enabled
INFO - 2021-07-14 00:22:46 --> Utf8 Class Initialized
INFO - 2021-07-14 00:22:46 --> URI Class Initialized
INFO - 2021-07-14 00:22:46 --> Router Class Initialized
INFO - 2021-07-14 00:22:46 --> Output Class Initialized
INFO - 2021-07-14 00:22:46 --> Security Class Initialized
DEBUG - 2021-07-14 00:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 00:22:46 --> Input Class Initialized
INFO - 2021-07-14 00:22:46 --> Language Class Initialized
INFO - 2021-07-14 00:22:46 --> Loader Class Initialized
INFO - 2021-07-14 00:22:46 --> Helper loaded: basic_helper
INFO - 2021-07-14 00:22:46 --> Helper loaded: url_helper
INFO - 2021-07-14 00:22:46 --> Helper loaded: file_helper
INFO - 2021-07-14 00:22:46 --> Helper loaded: form_helper
INFO - 2021-07-14 00:22:46 --> Helper loaded: cookie_helper
INFO - 2021-07-14 00:22:46 --> Helper loaded: security_helper
INFO - 2021-07-14 00:22:46 --> Helper loaded: directory_helper
INFO - 2021-07-14 00:22:46 --> Helper loaded: language_helper
INFO - 2021-07-14 00:22:46 --> Helper loaded: general_helper
INFO - 2021-07-14 00:22:46 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 00:22:46 --> Database Driver Class Initialized
DEBUG - 2021-07-14 00:22:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 00:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 00:22:46 --> Parser Class Initialized
INFO - 2021-07-14 00:22:46 --> Form Validation Class Initialized
INFO - 2021-07-14 00:22:46 --> Upload Class Initialized
INFO - 2021-07-14 00:22:46 --> Email Class Initialized
INFO - 2021-07-14 00:22:46 --> MY_Model class loaded
INFO - 2021-07-14 00:22:46 --> Model "Users_model" initialized
INFO - 2021-07-14 00:22:46 --> Model "Settings_model" initialized
INFO - 2021-07-14 00:22:46 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 00:22:46 --> Model "Permissions_model" initialized
INFO - 2021-07-14 00:22:46 --> Model "Roles_model" initialized
INFO - 2021-07-14 00:22:46 --> Model "Activity_model" initialized
INFO - 2021-07-14 00:22:46 --> Model "Templates_model" initialized
INFO - 2021-07-14 00:22:46 --> Database Driver Class Initialized
INFO - 2021-07-14 00:22:46 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 00:22:46 --> Controller Class Initialized
ERROR - 2021-07-14 00:22:46 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 00:22:46 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-14 00:22:46 --> Final output sent to browser
DEBUG - 2021-07-14 00:22:46 --> Total execution time: 0.1225
INFO - 2021-07-14 00:23:13 --> Config Class Initialized
INFO - 2021-07-14 00:23:13 --> Hooks Class Initialized
DEBUG - 2021-07-14 00:23:13 --> UTF-8 Support Enabled
INFO - 2021-07-14 00:23:13 --> Utf8 Class Initialized
INFO - 2021-07-14 00:23:13 --> URI Class Initialized
INFO - 2021-07-14 00:23:13 --> Router Class Initialized
INFO - 2021-07-14 00:23:13 --> Output Class Initialized
INFO - 2021-07-14 00:23:13 --> Security Class Initialized
DEBUG - 2021-07-14 00:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 00:23:13 --> Input Class Initialized
INFO - 2021-07-14 00:23:13 --> Language Class Initialized
INFO - 2021-07-14 00:23:13 --> Loader Class Initialized
INFO - 2021-07-14 00:23:13 --> Helper loaded: basic_helper
INFO - 2021-07-14 00:23:13 --> Helper loaded: url_helper
INFO - 2021-07-14 00:23:13 --> Helper loaded: file_helper
INFO - 2021-07-14 00:23:13 --> Helper loaded: form_helper
INFO - 2021-07-14 00:23:13 --> Helper loaded: cookie_helper
INFO - 2021-07-14 00:23:13 --> Helper loaded: security_helper
INFO - 2021-07-14 00:23:13 --> Helper loaded: directory_helper
INFO - 2021-07-14 00:23:13 --> Helper loaded: language_helper
INFO - 2021-07-14 00:23:13 --> Helper loaded: general_helper
INFO - 2021-07-14 00:23:13 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 00:23:13 --> Database Driver Class Initialized
DEBUG - 2021-07-14 00:23:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 00:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 00:23:13 --> Parser Class Initialized
INFO - 2021-07-14 00:23:13 --> Form Validation Class Initialized
INFO - 2021-07-14 00:23:13 --> Upload Class Initialized
INFO - 2021-07-14 00:23:13 --> Email Class Initialized
INFO - 2021-07-14 00:23:13 --> MY_Model class loaded
INFO - 2021-07-14 00:23:13 --> Model "Users_model" initialized
INFO - 2021-07-14 00:23:13 --> Model "Settings_model" initialized
INFO - 2021-07-14 00:23:13 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 00:23:13 --> Model "Permissions_model" initialized
INFO - 2021-07-14 00:23:13 --> Model "Roles_model" initialized
INFO - 2021-07-14 00:23:13 --> Model "Activity_model" initialized
INFO - 2021-07-14 00:23:13 --> Model "Templates_model" initialized
INFO - 2021-07-14 00:23:13 --> Database Driver Class Initialized
INFO - 2021-07-14 00:23:13 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 00:23:13 --> Controller Class Initialized
ERROR - 2021-07-14 00:23:13 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 00:23:13 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-14 00:23:13 --> Final output sent to browser
DEBUG - 2021-07-14 00:23:13 --> Total execution time: 0.1364
INFO - 2021-07-14 00:24:45 --> Config Class Initialized
INFO - 2021-07-14 00:24:45 --> Hooks Class Initialized
DEBUG - 2021-07-14 00:24:45 --> UTF-8 Support Enabled
INFO - 2021-07-14 00:24:45 --> Utf8 Class Initialized
INFO - 2021-07-14 00:24:45 --> URI Class Initialized
INFO - 2021-07-14 00:24:45 --> Router Class Initialized
INFO - 2021-07-14 00:24:45 --> Output Class Initialized
INFO - 2021-07-14 00:24:45 --> Security Class Initialized
DEBUG - 2021-07-14 00:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 00:24:45 --> Input Class Initialized
INFO - 2021-07-14 00:24:45 --> Language Class Initialized
INFO - 2021-07-14 00:24:45 --> Loader Class Initialized
INFO - 2021-07-14 00:24:45 --> Helper loaded: basic_helper
INFO - 2021-07-14 00:24:45 --> Helper loaded: url_helper
INFO - 2021-07-14 00:24:45 --> Helper loaded: file_helper
INFO - 2021-07-14 00:24:45 --> Helper loaded: form_helper
INFO - 2021-07-14 00:24:45 --> Helper loaded: cookie_helper
INFO - 2021-07-14 00:24:45 --> Helper loaded: security_helper
INFO - 2021-07-14 00:24:45 --> Helper loaded: directory_helper
INFO - 2021-07-14 00:24:45 --> Helper loaded: language_helper
INFO - 2021-07-14 00:24:45 --> Helper loaded: general_helper
INFO - 2021-07-14 00:24:45 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 00:24:45 --> Database Driver Class Initialized
DEBUG - 2021-07-14 00:24:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 00:24:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 00:24:45 --> Parser Class Initialized
INFO - 2021-07-14 00:24:45 --> Form Validation Class Initialized
INFO - 2021-07-14 00:24:45 --> Upload Class Initialized
INFO - 2021-07-14 00:24:45 --> Email Class Initialized
INFO - 2021-07-14 00:24:45 --> MY_Model class loaded
INFO - 2021-07-14 00:24:45 --> Model "Users_model" initialized
INFO - 2021-07-14 00:24:45 --> Model "Settings_model" initialized
INFO - 2021-07-14 00:24:45 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 00:24:45 --> Model "Permissions_model" initialized
INFO - 2021-07-14 00:24:45 --> Model "Roles_model" initialized
INFO - 2021-07-14 00:24:45 --> Model "Activity_model" initialized
INFO - 2021-07-14 00:24:45 --> Model "Templates_model" initialized
INFO - 2021-07-14 00:24:45 --> Database Driver Class Initialized
INFO - 2021-07-14 00:24:45 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 00:24:45 --> Controller Class Initialized
ERROR - 2021-07-14 00:24:45 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 00:24:45 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-14 00:24:45 --> Final output sent to browser
DEBUG - 2021-07-14 00:24:45 --> Total execution time: 0.5385
INFO - 2021-07-14 00:29:40 --> Config Class Initialized
INFO - 2021-07-14 00:29:40 --> Hooks Class Initialized
DEBUG - 2021-07-14 00:29:40 --> UTF-8 Support Enabled
INFO - 2021-07-14 00:29:40 --> Utf8 Class Initialized
INFO - 2021-07-14 00:29:40 --> URI Class Initialized
INFO - 2021-07-14 00:29:40 --> Router Class Initialized
INFO - 2021-07-14 00:29:40 --> Output Class Initialized
INFO - 2021-07-14 00:29:40 --> Security Class Initialized
DEBUG - 2021-07-14 00:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 00:29:40 --> Input Class Initialized
INFO - 2021-07-14 00:29:40 --> Language Class Initialized
INFO - 2021-07-14 00:29:40 --> Loader Class Initialized
INFO - 2021-07-14 00:29:40 --> Helper loaded: basic_helper
INFO - 2021-07-14 00:29:40 --> Helper loaded: url_helper
INFO - 2021-07-14 00:29:40 --> Helper loaded: file_helper
INFO - 2021-07-14 00:29:40 --> Helper loaded: form_helper
INFO - 2021-07-14 00:29:40 --> Helper loaded: cookie_helper
INFO - 2021-07-14 00:29:40 --> Helper loaded: security_helper
INFO - 2021-07-14 00:29:40 --> Helper loaded: directory_helper
INFO - 2021-07-14 00:29:40 --> Helper loaded: language_helper
INFO - 2021-07-14 00:29:40 --> Helper loaded: general_helper
INFO - 2021-07-14 00:29:40 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 00:29:40 --> Database Driver Class Initialized
DEBUG - 2021-07-14 00:29:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 00:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 00:29:41 --> Parser Class Initialized
INFO - 2021-07-14 00:29:41 --> Form Validation Class Initialized
INFO - 2021-07-14 00:29:41 --> Upload Class Initialized
INFO - 2021-07-14 00:29:41 --> Email Class Initialized
INFO - 2021-07-14 00:29:41 --> MY_Model class loaded
INFO - 2021-07-14 00:29:41 --> Model "Users_model" initialized
INFO - 2021-07-14 00:29:41 --> Model "Settings_model" initialized
INFO - 2021-07-14 00:29:41 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 00:29:41 --> Model "Permissions_model" initialized
INFO - 2021-07-14 00:29:41 --> Model "Roles_model" initialized
INFO - 2021-07-14 00:29:41 --> Model "Activity_model" initialized
INFO - 2021-07-14 00:29:41 --> Model "Templates_model" initialized
INFO - 2021-07-14 00:29:41 --> Database Driver Class Initialized
INFO - 2021-07-14 00:29:41 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 00:29:41 --> Controller Class Initialized
ERROR - 2021-07-14 00:29:41 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 00:29:41 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-14 00:29:41 --> Final output sent to browser
DEBUG - 2021-07-14 00:29:41 --> Total execution time: 0.2136
INFO - 2021-07-14 00:29:41 --> Config Class Initialized
INFO - 2021-07-14 00:29:41 --> Hooks Class Initialized
DEBUG - 2021-07-14 00:29:41 --> UTF-8 Support Enabled
INFO - 2021-07-14 00:29:41 --> Utf8 Class Initialized
INFO - 2021-07-14 00:29:41 --> URI Class Initialized
INFO - 2021-07-14 00:29:41 --> Router Class Initialized
INFO - 2021-07-14 00:29:41 --> Output Class Initialized
INFO - 2021-07-14 00:29:41 --> Security Class Initialized
DEBUG - 2021-07-14 00:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 00:29:41 --> Input Class Initialized
INFO - 2021-07-14 00:29:41 --> Language Class Initialized
ERROR - 2021-07-14 00:29:41 --> 404 Page Not Found: Faviconico/index
INFO - 2021-07-14 00:30:09 --> Config Class Initialized
INFO - 2021-07-14 00:30:09 --> Hooks Class Initialized
DEBUG - 2021-07-14 00:30:09 --> UTF-8 Support Enabled
INFO - 2021-07-14 00:30:09 --> Utf8 Class Initialized
INFO - 2021-07-14 00:30:09 --> URI Class Initialized
INFO - 2021-07-14 00:30:09 --> Router Class Initialized
INFO - 2021-07-14 00:30:09 --> Output Class Initialized
INFO - 2021-07-14 00:30:09 --> Security Class Initialized
DEBUG - 2021-07-14 00:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 00:30:09 --> Input Class Initialized
INFO - 2021-07-14 00:30:09 --> Language Class Initialized
INFO - 2021-07-14 00:30:09 --> Loader Class Initialized
INFO - 2021-07-14 00:30:09 --> Helper loaded: basic_helper
INFO - 2021-07-14 00:30:09 --> Helper loaded: url_helper
INFO - 2021-07-14 00:30:09 --> Helper loaded: file_helper
INFO - 2021-07-14 00:30:09 --> Helper loaded: form_helper
INFO - 2021-07-14 00:30:09 --> Helper loaded: cookie_helper
INFO - 2021-07-14 00:30:09 --> Helper loaded: security_helper
INFO - 2021-07-14 00:30:09 --> Helper loaded: directory_helper
INFO - 2021-07-14 00:30:09 --> Helper loaded: language_helper
INFO - 2021-07-14 00:30:09 --> Helper loaded: general_helper
INFO - 2021-07-14 00:30:09 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 00:30:09 --> Database Driver Class Initialized
DEBUG - 2021-07-14 00:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 00:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 00:30:09 --> Parser Class Initialized
INFO - 2021-07-14 00:30:09 --> Form Validation Class Initialized
INFO - 2021-07-14 00:30:09 --> Upload Class Initialized
INFO - 2021-07-14 00:30:09 --> Email Class Initialized
INFO - 2021-07-14 00:30:09 --> MY_Model class loaded
INFO - 2021-07-14 00:30:09 --> Model "Users_model" initialized
INFO - 2021-07-14 00:30:09 --> Model "Settings_model" initialized
INFO - 2021-07-14 00:30:09 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 00:30:09 --> Model "Permissions_model" initialized
INFO - 2021-07-14 00:30:09 --> Model "Roles_model" initialized
INFO - 2021-07-14 00:30:09 --> Model "Activity_model" initialized
INFO - 2021-07-14 00:30:09 --> Model "Templates_model" initialized
INFO - 2021-07-14 00:30:09 --> Database Driver Class Initialized
INFO - 2021-07-14 00:30:10 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 00:30:10 --> Controller Class Initialized
ERROR - 2021-07-14 00:30:10 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 00:30:10 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-14 00:30:10 --> Final output sent to browser
DEBUG - 2021-07-14 00:30:10 --> Total execution time: 0.1265
INFO - 2021-07-14 00:30:10 --> Config Class Initialized
INFO - 2021-07-14 00:30:10 --> Hooks Class Initialized
DEBUG - 2021-07-14 00:30:10 --> UTF-8 Support Enabled
INFO - 2021-07-14 00:30:10 --> Utf8 Class Initialized
INFO - 2021-07-14 00:30:10 --> URI Class Initialized
INFO - 2021-07-14 00:30:10 --> Router Class Initialized
INFO - 2021-07-14 00:30:10 --> Output Class Initialized
INFO - 2021-07-14 00:30:10 --> Security Class Initialized
DEBUG - 2021-07-14 00:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 00:30:10 --> Input Class Initialized
INFO - 2021-07-14 00:30:10 --> Language Class Initialized
ERROR - 2021-07-14 00:30:10 --> 404 Page Not Found: Faviconico/index
INFO - 2021-07-14 00:30:29 --> Config Class Initialized
INFO - 2021-07-14 00:30:29 --> Hooks Class Initialized
DEBUG - 2021-07-14 00:30:29 --> UTF-8 Support Enabled
INFO - 2021-07-14 00:30:29 --> Utf8 Class Initialized
INFO - 2021-07-14 00:30:29 --> URI Class Initialized
INFO - 2021-07-14 00:30:29 --> Router Class Initialized
INFO - 2021-07-14 00:30:29 --> Output Class Initialized
INFO - 2021-07-14 00:30:29 --> Security Class Initialized
DEBUG - 2021-07-14 00:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 00:30:29 --> Input Class Initialized
INFO - 2021-07-14 00:30:29 --> Language Class Initialized
INFO - 2021-07-14 00:30:29 --> Loader Class Initialized
INFO - 2021-07-14 00:30:29 --> Helper loaded: basic_helper
INFO - 2021-07-14 00:30:29 --> Helper loaded: url_helper
INFO - 2021-07-14 00:30:29 --> Helper loaded: file_helper
INFO - 2021-07-14 00:30:29 --> Helper loaded: form_helper
INFO - 2021-07-14 00:30:29 --> Helper loaded: cookie_helper
INFO - 2021-07-14 00:30:29 --> Helper loaded: security_helper
INFO - 2021-07-14 00:30:29 --> Helper loaded: directory_helper
INFO - 2021-07-14 00:30:29 --> Helper loaded: language_helper
INFO - 2021-07-14 00:30:29 --> Helper loaded: general_helper
INFO - 2021-07-14 00:30:29 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 00:30:29 --> Database Driver Class Initialized
DEBUG - 2021-07-14 00:30:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 00:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 00:30:29 --> Parser Class Initialized
INFO - 2021-07-14 00:30:29 --> Form Validation Class Initialized
INFO - 2021-07-14 00:30:29 --> Upload Class Initialized
INFO - 2021-07-14 00:30:29 --> Email Class Initialized
INFO - 2021-07-14 00:30:29 --> MY_Model class loaded
INFO - 2021-07-14 00:30:29 --> Model "Users_model" initialized
INFO - 2021-07-14 00:30:29 --> Model "Settings_model" initialized
INFO - 2021-07-14 00:30:29 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 00:30:29 --> Model "Permissions_model" initialized
INFO - 2021-07-14 00:30:29 --> Model "Roles_model" initialized
INFO - 2021-07-14 00:30:29 --> Model "Activity_model" initialized
INFO - 2021-07-14 00:30:29 --> Model "Templates_model" initialized
INFO - 2021-07-14 00:30:29 --> Database Driver Class Initialized
INFO - 2021-07-14 00:30:29 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 00:30:29 --> Controller Class Initialized
ERROR - 2021-07-14 00:30:29 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 00:30:29 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-14 00:30:29 --> Final output sent to browser
DEBUG - 2021-07-14 00:30:29 --> Total execution time: 0.1238
INFO - 2021-07-14 00:31:19 --> Config Class Initialized
INFO - 2021-07-14 00:31:19 --> Hooks Class Initialized
DEBUG - 2021-07-14 00:31:19 --> UTF-8 Support Enabled
INFO - 2021-07-14 00:31:19 --> Utf8 Class Initialized
INFO - 2021-07-14 00:31:19 --> URI Class Initialized
INFO - 2021-07-14 00:31:19 --> Router Class Initialized
INFO - 2021-07-14 00:31:19 --> Output Class Initialized
INFO - 2021-07-14 00:31:19 --> Security Class Initialized
DEBUG - 2021-07-14 00:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 00:31:19 --> Input Class Initialized
INFO - 2021-07-14 00:31:19 --> Language Class Initialized
INFO - 2021-07-14 00:31:19 --> Loader Class Initialized
INFO - 2021-07-14 00:31:19 --> Helper loaded: basic_helper
INFO - 2021-07-14 00:31:19 --> Helper loaded: url_helper
INFO - 2021-07-14 00:31:19 --> Helper loaded: file_helper
INFO - 2021-07-14 00:31:19 --> Helper loaded: form_helper
INFO - 2021-07-14 00:31:19 --> Helper loaded: cookie_helper
INFO - 2021-07-14 00:31:19 --> Helper loaded: security_helper
INFO - 2021-07-14 00:31:19 --> Helper loaded: directory_helper
INFO - 2021-07-14 00:31:19 --> Helper loaded: language_helper
INFO - 2021-07-14 00:31:19 --> Helper loaded: general_helper
INFO - 2021-07-14 00:31:19 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 00:31:19 --> Database Driver Class Initialized
DEBUG - 2021-07-14 00:31:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 00:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 00:31:19 --> Parser Class Initialized
INFO - 2021-07-14 00:31:19 --> Form Validation Class Initialized
INFO - 2021-07-14 00:31:19 --> Upload Class Initialized
INFO - 2021-07-14 00:31:19 --> Email Class Initialized
INFO - 2021-07-14 00:31:19 --> MY_Model class loaded
INFO - 2021-07-14 00:31:19 --> Model "Users_model" initialized
INFO - 2021-07-14 00:31:19 --> Model "Settings_model" initialized
INFO - 2021-07-14 00:31:19 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 00:31:19 --> Model "Permissions_model" initialized
INFO - 2021-07-14 00:31:19 --> Model "Roles_model" initialized
INFO - 2021-07-14 00:31:19 --> Model "Activity_model" initialized
INFO - 2021-07-14 00:31:19 --> Model "Templates_model" initialized
INFO - 2021-07-14 00:31:19 --> Database Driver Class Initialized
INFO - 2021-07-14 00:31:19 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 00:31:19 --> Controller Class Initialized
ERROR - 2021-07-14 00:31:19 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 00:31:19 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-14 00:31:19 --> Final output sent to browser
DEBUG - 2021-07-14 00:31:19 --> Total execution time: 0.3029
INFO - 2021-07-14 00:32:31 --> Config Class Initialized
INFO - 2021-07-14 00:32:31 --> Hooks Class Initialized
DEBUG - 2021-07-14 00:32:31 --> UTF-8 Support Enabled
INFO - 2021-07-14 00:32:31 --> Utf8 Class Initialized
INFO - 2021-07-14 00:32:31 --> URI Class Initialized
INFO - 2021-07-14 00:32:31 --> Router Class Initialized
INFO - 2021-07-14 00:32:31 --> Output Class Initialized
INFO - 2021-07-14 00:32:31 --> Security Class Initialized
DEBUG - 2021-07-14 00:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 00:32:31 --> Input Class Initialized
INFO - 2021-07-14 00:32:31 --> Language Class Initialized
INFO - 2021-07-14 00:32:31 --> Loader Class Initialized
INFO - 2021-07-14 00:32:31 --> Helper loaded: basic_helper
INFO - 2021-07-14 00:32:31 --> Helper loaded: url_helper
INFO - 2021-07-14 00:32:31 --> Helper loaded: file_helper
INFO - 2021-07-14 00:32:31 --> Helper loaded: form_helper
INFO - 2021-07-14 00:32:31 --> Helper loaded: cookie_helper
INFO - 2021-07-14 00:32:31 --> Helper loaded: security_helper
INFO - 2021-07-14 00:32:31 --> Helper loaded: directory_helper
INFO - 2021-07-14 00:32:31 --> Helper loaded: language_helper
INFO - 2021-07-14 00:32:31 --> Helper loaded: general_helper
INFO - 2021-07-14 00:32:31 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 00:32:31 --> Database Driver Class Initialized
DEBUG - 2021-07-14 00:32:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 00:32:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 00:32:31 --> Parser Class Initialized
INFO - 2021-07-14 00:32:31 --> Form Validation Class Initialized
INFO - 2021-07-14 00:32:31 --> Upload Class Initialized
INFO - 2021-07-14 00:32:31 --> Email Class Initialized
INFO - 2021-07-14 00:32:31 --> MY_Model class loaded
INFO - 2021-07-14 00:32:31 --> Model "Users_model" initialized
INFO - 2021-07-14 00:32:31 --> Model "Settings_model" initialized
INFO - 2021-07-14 00:32:31 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 00:32:31 --> Model "Permissions_model" initialized
INFO - 2021-07-14 00:32:31 --> Model "Roles_model" initialized
INFO - 2021-07-14 00:32:31 --> Model "Activity_model" initialized
INFO - 2021-07-14 00:32:31 --> Model "Templates_model" initialized
INFO - 2021-07-14 00:32:31 --> Database Driver Class Initialized
INFO - 2021-07-14 00:32:31 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 00:32:31 --> Controller Class Initialized
ERROR - 2021-07-14 00:32:31 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 00:32:31 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-14 00:32:31 --> Final output sent to browser
DEBUG - 2021-07-14 00:32:31 --> Total execution time: 0.1277
INFO - 2021-07-14 02:39:04 --> Config Class Initialized
INFO - 2021-07-14 02:39:04 --> Hooks Class Initialized
DEBUG - 2021-07-14 02:39:04 --> UTF-8 Support Enabled
INFO - 2021-07-14 02:39:04 --> Utf8 Class Initialized
INFO - 2021-07-14 02:39:04 --> URI Class Initialized
INFO - 2021-07-14 02:39:04 --> Router Class Initialized
INFO - 2021-07-14 02:39:04 --> Output Class Initialized
INFO - 2021-07-14 02:39:04 --> Security Class Initialized
DEBUG - 2021-07-14 02:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 02:39:04 --> Input Class Initialized
INFO - 2021-07-14 02:39:04 --> Language Class Initialized
INFO - 2021-07-14 02:39:04 --> Loader Class Initialized
INFO - 2021-07-14 02:39:04 --> Helper loaded: basic_helper
INFO - 2021-07-14 02:39:04 --> Helper loaded: url_helper
INFO - 2021-07-14 02:39:04 --> Helper loaded: file_helper
INFO - 2021-07-14 02:39:04 --> Helper loaded: form_helper
INFO - 2021-07-14 02:39:04 --> Helper loaded: cookie_helper
INFO - 2021-07-14 02:39:04 --> Helper loaded: security_helper
INFO - 2021-07-14 02:39:04 --> Helper loaded: directory_helper
INFO - 2021-07-14 02:39:04 --> Helper loaded: language_helper
INFO - 2021-07-14 02:39:04 --> Helper loaded: general_helper
INFO - 2021-07-14 02:39:04 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 02:39:04 --> Database Driver Class Initialized
DEBUG - 2021-07-14 02:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 02:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 02:39:04 --> Parser Class Initialized
INFO - 2021-07-14 02:39:04 --> Form Validation Class Initialized
INFO - 2021-07-14 02:39:04 --> Upload Class Initialized
INFO - 2021-07-14 02:39:04 --> Email Class Initialized
INFO - 2021-07-14 02:39:04 --> MY_Model class loaded
INFO - 2021-07-14 02:39:04 --> Model "Users_model" initialized
INFO - 2021-07-14 02:39:04 --> Model "Settings_model" initialized
INFO - 2021-07-14 02:39:04 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 02:39:04 --> Model "Permissions_model" initialized
INFO - 2021-07-14 02:39:04 --> Model "Roles_model" initialized
INFO - 2021-07-14 02:39:04 --> Model "Activity_model" initialized
INFO - 2021-07-14 02:39:04 --> Model "Templates_model" initialized
INFO - 2021-07-14 02:39:04 --> Database Driver Class Initialized
INFO - 2021-07-14 02:39:04 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 02:39:04 --> Controller Class Initialized
INFO - 2021-07-14 02:39:04 --> Config Class Initialized
INFO - 2021-07-14 02:39:04 --> Hooks Class Initialized
DEBUG - 2021-07-14 02:39:04 --> UTF-8 Support Enabled
INFO - 2021-07-14 02:39:04 --> Utf8 Class Initialized
INFO - 2021-07-14 02:39:04 --> URI Class Initialized
INFO - 2021-07-14 02:39:04 --> Router Class Initialized
INFO - 2021-07-14 02:39:04 --> Output Class Initialized
INFO - 2021-07-14 02:39:04 --> Security Class Initialized
DEBUG - 2021-07-14 02:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 02:39:04 --> Input Class Initialized
INFO - 2021-07-14 02:39:04 --> Language Class Initialized
INFO - 2021-07-14 02:39:04 --> Loader Class Initialized
INFO - 2021-07-14 02:39:04 --> Helper loaded: basic_helper
INFO - 2021-07-14 02:39:04 --> Helper loaded: url_helper
INFO - 2021-07-14 02:39:04 --> Helper loaded: file_helper
INFO - 2021-07-14 02:39:04 --> Helper loaded: form_helper
INFO - 2021-07-14 02:39:04 --> Helper loaded: cookie_helper
INFO - 2021-07-14 02:39:04 --> Helper loaded: security_helper
INFO - 2021-07-14 02:39:04 --> Helper loaded: directory_helper
INFO - 2021-07-14 02:39:04 --> Helper loaded: language_helper
INFO - 2021-07-14 02:39:04 --> Helper loaded: general_helper
INFO - 2021-07-14 02:39:04 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 02:39:04 --> Database Driver Class Initialized
DEBUG - 2021-07-14 02:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 02:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 02:39:04 --> Parser Class Initialized
INFO - 2021-07-14 02:39:04 --> Form Validation Class Initialized
INFO - 2021-07-14 02:39:04 --> Upload Class Initialized
INFO - 2021-07-14 02:39:04 --> Email Class Initialized
INFO - 2021-07-14 02:39:04 --> MY_Model class loaded
INFO - 2021-07-14 02:39:04 --> Model "Users_model" initialized
INFO - 2021-07-14 02:39:04 --> Model "Settings_model" initialized
INFO - 2021-07-14 02:39:04 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 02:39:04 --> Model "Permissions_model" initialized
INFO - 2021-07-14 02:39:04 --> Model "Roles_model" initialized
INFO - 2021-07-14 02:39:04 --> Model "Activity_model" initialized
INFO - 2021-07-14 02:39:04 --> Model "Templates_model" initialized
INFO - 2021-07-14 02:39:04 --> Database Driver Class Initialized
INFO - 2021-07-14 02:39:04 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 02:39:04 --> Controller Class Initialized
INFO - 2021-07-14 02:39:04 --> File loaded: C:\wamp64\www\crm\application\views\account/login.php
INFO - 2021-07-14 02:39:04 --> Final output sent to browser
DEBUG - 2021-07-14 02:39:04 --> Total execution time: 0.0491
INFO - 2021-07-14 02:39:04 --> Config Class Initialized
INFO - 2021-07-14 02:39:04 --> Hooks Class Initialized
DEBUG - 2021-07-14 02:39:04 --> UTF-8 Support Enabled
INFO - 2021-07-14 02:39:04 --> Utf8 Class Initialized
INFO - 2021-07-14 02:39:04 --> URI Class Initialized
INFO - 2021-07-14 02:39:04 --> Router Class Initialized
INFO - 2021-07-14 02:39:04 --> Output Class Initialized
INFO - 2021-07-14 02:39:04 --> Security Class Initialized
DEBUG - 2021-07-14 02:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 02:39:04 --> Input Class Initialized
INFO - 2021-07-14 02:39:04 --> Language Class Initialized
ERROR - 2021-07-14 02:39:04 --> 404 Page Not Found: Assets/jquery
INFO - 2021-07-14 02:39:04 --> Config Class Initialized
INFO - 2021-07-14 02:39:04 --> Hooks Class Initialized
DEBUG - 2021-07-14 02:39:04 --> UTF-8 Support Enabled
INFO - 2021-07-14 02:39:04 --> Utf8 Class Initialized
INFO - 2021-07-14 02:39:04 --> URI Class Initialized
INFO - 2021-07-14 02:39:04 --> Router Class Initialized
INFO - 2021-07-14 02:39:04 --> Output Class Initialized
INFO - 2021-07-14 02:39:04 --> Security Class Initialized
DEBUG - 2021-07-14 02:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 02:39:04 --> Input Class Initialized
INFO - 2021-07-14 02:39:04 --> Language Class Initialized
ERROR - 2021-07-14 02:39:04 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-14 02:39:06 --> Config Class Initialized
INFO - 2021-07-14 02:39:06 --> Hooks Class Initialized
DEBUG - 2021-07-14 02:39:06 --> UTF-8 Support Enabled
INFO - 2021-07-14 02:39:06 --> Utf8 Class Initialized
INFO - 2021-07-14 02:39:06 --> URI Class Initialized
INFO - 2021-07-14 02:39:06 --> Router Class Initialized
INFO - 2021-07-14 02:39:06 --> Output Class Initialized
INFO - 2021-07-14 02:39:06 --> Security Class Initialized
DEBUG - 2021-07-14 02:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 02:39:06 --> Input Class Initialized
INFO - 2021-07-14 02:39:06 --> Language Class Initialized
INFO - 2021-07-14 02:39:06 --> Loader Class Initialized
INFO - 2021-07-14 02:39:06 --> Helper loaded: basic_helper
INFO - 2021-07-14 02:39:06 --> Helper loaded: url_helper
INFO - 2021-07-14 02:39:06 --> Helper loaded: file_helper
INFO - 2021-07-14 02:39:06 --> Helper loaded: form_helper
INFO - 2021-07-14 02:39:06 --> Helper loaded: cookie_helper
INFO - 2021-07-14 02:39:06 --> Helper loaded: security_helper
INFO - 2021-07-14 02:39:06 --> Helper loaded: directory_helper
INFO - 2021-07-14 02:39:06 --> Helper loaded: language_helper
INFO - 2021-07-14 02:39:06 --> Helper loaded: general_helper
INFO - 2021-07-14 02:39:06 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 02:39:06 --> Database Driver Class Initialized
DEBUG - 2021-07-14 02:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 02:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 02:39:06 --> Parser Class Initialized
INFO - 2021-07-14 02:39:06 --> Form Validation Class Initialized
INFO - 2021-07-14 02:39:06 --> Upload Class Initialized
INFO - 2021-07-14 02:39:06 --> Email Class Initialized
INFO - 2021-07-14 02:39:06 --> MY_Model class loaded
INFO - 2021-07-14 02:39:06 --> Model "Users_model" initialized
INFO - 2021-07-14 02:39:06 --> Model "Settings_model" initialized
INFO - 2021-07-14 02:39:06 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 02:39:06 --> Model "Permissions_model" initialized
INFO - 2021-07-14 02:39:06 --> Model "Roles_model" initialized
INFO - 2021-07-14 02:39:06 --> Model "Activity_model" initialized
INFO - 2021-07-14 02:39:06 --> Model "Templates_model" initialized
INFO - 2021-07-14 02:39:06 --> Database Driver Class Initialized
INFO - 2021-07-14 02:39:06 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 02:39:06 --> Controller Class Initialized
DEBUG - 2021-07-14 02:39:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-14 02:39:06 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2021-07-14 02:39:06 --> Config Class Initialized
INFO - 2021-07-14 02:39:06 --> Hooks Class Initialized
DEBUG - 2021-07-14 02:39:06 --> UTF-8 Support Enabled
INFO - 2021-07-14 02:39:06 --> Utf8 Class Initialized
INFO - 2021-07-14 02:39:06 --> URI Class Initialized
DEBUG - 2021-07-14 02:39:06 --> No URI present. Default controller set.
INFO - 2021-07-14 02:39:06 --> Router Class Initialized
INFO - 2021-07-14 02:39:06 --> Output Class Initialized
INFO - 2021-07-14 02:39:06 --> Security Class Initialized
DEBUG - 2021-07-14 02:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 02:39:06 --> Input Class Initialized
INFO - 2021-07-14 02:39:06 --> Language Class Initialized
INFO - 2021-07-14 02:39:06 --> Loader Class Initialized
INFO - 2021-07-14 02:39:06 --> Helper loaded: basic_helper
INFO - 2021-07-14 02:39:06 --> Helper loaded: url_helper
INFO - 2021-07-14 02:39:06 --> Helper loaded: file_helper
INFO - 2021-07-14 02:39:06 --> Helper loaded: form_helper
INFO - 2021-07-14 02:39:06 --> Helper loaded: cookie_helper
INFO - 2021-07-14 02:39:06 --> Helper loaded: security_helper
INFO - 2021-07-14 02:39:06 --> Helper loaded: directory_helper
INFO - 2021-07-14 02:39:06 --> Helper loaded: language_helper
INFO - 2021-07-14 02:39:06 --> Helper loaded: general_helper
INFO - 2021-07-14 02:39:06 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 02:39:06 --> Database Driver Class Initialized
DEBUG - 2021-07-14 02:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 02:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 02:39:06 --> Parser Class Initialized
INFO - 2021-07-14 02:39:06 --> Form Validation Class Initialized
INFO - 2021-07-14 02:39:06 --> Upload Class Initialized
INFO - 2021-07-14 02:39:06 --> Email Class Initialized
INFO - 2021-07-14 02:39:06 --> MY_Model class loaded
INFO - 2021-07-14 02:39:06 --> Model "Users_model" initialized
INFO - 2021-07-14 02:39:06 --> Model "Settings_model" initialized
INFO - 2021-07-14 02:39:06 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 02:39:06 --> Model "Permissions_model" initialized
INFO - 2021-07-14 02:39:06 --> Model "Roles_model" initialized
INFO - 2021-07-14 02:39:06 --> Model "Activity_model" initialized
INFO - 2021-07-14 02:39:06 --> Model "Templates_model" initialized
INFO - 2021-07-14 02:39:06 --> Database Driver Class Initialized
INFO - 2021-07-14 02:39:06 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 02:39:06 --> Controller Class Initialized
ERROR - 2021-07-14 02:39:06 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 02:39:06 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-14 02:39:06 --> Final output sent to browser
DEBUG - 2021-07-14 02:39:06 --> Total execution time: 0.0632
INFO - 2021-07-14 02:39:08 --> Config Class Initialized
INFO - 2021-07-14 02:39:08 --> Hooks Class Initialized
DEBUG - 2021-07-14 02:39:08 --> UTF-8 Support Enabled
INFO - 2021-07-14 02:39:08 --> Utf8 Class Initialized
INFO - 2021-07-14 02:39:08 --> URI Class Initialized
INFO - 2021-07-14 02:39:08 --> Router Class Initialized
INFO - 2021-07-14 02:39:08 --> Output Class Initialized
INFO - 2021-07-14 02:39:08 --> Security Class Initialized
DEBUG - 2021-07-14 02:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 02:39:08 --> Input Class Initialized
INFO - 2021-07-14 02:39:08 --> Language Class Initialized
INFO - 2021-07-14 02:39:08 --> Loader Class Initialized
INFO - 2021-07-14 02:39:08 --> Helper loaded: basic_helper
INFO - 2021-07-14 02:39:08 --> Helper loaded: url_helper
INFO - 2021-07-14 02:39:08 --> Helper loaded: file_helper
INFO - 2021-07-14 02:39:08 --> Helper loaded: form_helper
INFO - 2021-07-14 02:39:08 --> Helper loaded: cookie_helper
INFO - 2021-07-14 02:39:08 --> Helper loaded: security_helper
INFO - 2021-07-14 02:39:08 --> Helper loaded: directory_helper
INFO - 2021-07-14 02:39:08 --> Helper loaded: language_helper
INFO - 2021-07-14 02:39:08 --> Helper loaded: general_helper
INFO - 2021-07-14 02:39:08 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 02:39:08 --> Database Driver Class Initialized
DEBUG - 2021-07-14 02:39:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 02:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 02:39:08 --> Parser Class Initialized
INFO - 2021-07-14 02:39:08 --> Form Validation Class Initialized
INFO - 2021-07-14 02:39:09 --> Upload Class Initialized
INFO - 2021-07-14 02:39:09 --> Email Class Initialized
INFO - 2021-07-14 02:39:09 --> MY_Model class loaded
INFO - 2021-07-14 02:39:09 --> Model "Users_model" initialized
INFO - 2021-07-14 02:39:09 --> Model "Settings_model" initialized
INFO - 2021-07-14 02:39:09 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 02:39:09 --> Model "Permissions_model" initialized
INFO - 2021-07-14 02:39:09 --> Model "Roles_model" initialized
INFO - 2021-07-14 02:39:09 --> Model "Activity_model" initialized
INFO - 2021-07-14 02:39:09 --> Model "Templates_model" initialized
INFO - 2021-07-14 02:39:09 --> Database Driver Class Initialized
INFO - 2021-07-14 02:39:09 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 02:39:09 --> Controller Class Initialized
ERROR - 2021-07-14 02:39:09 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 02:39:09 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-14 02:39:09 --> Final output sent to browser
DEBUG - 2021-07-14 02:39:09 --> Total execution time: 0.0617
INFO - 2021-07-14 09:10:19 --> Config Class Initialized
INFO - 2021-07-14 09:10:19 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:10:19 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:10:19 --> Utf8 Class Initialized
INFO - 2021-07-14 09:10:19 --> URI Class Initialized
DEBUG - 2021-07-14 09:10:19 --> No URI present. Default controller set.
INFO - 2021-07-14 09:10:19 --> Router Class Initialized
INFO - 2021-07-14 09:10:19 --> Output Class Initialized
INFO - 2021-07-14 09:10:19 --> Security Class Initialized
DEBUG - 2021-07-14 09:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:10:19 --> Input Class Initialized
INFO - 2021-07-14 09:10:19 --> Language Class Initialized
INFO - 2021-07-14 09:10:19 --> Loader Class Initialized
INFO - 2021-07-14 09:10:19 --> Helper loaded: basic_helper
INFO - 2021-07-14 09:10:19 --> Helper loaded: url_helper
INFO - 2021-07-14 09:10:19 --> Helper loaded: file_helper
INFO - 2021-07-14 09:10:19 --> Helper loaded: form_helper
INFO - 2021-07-14 09:10:19 --> Helper loaded: cookie_helper
INFO - 2021-07-14 09:10:19 --> Helper loaded: security_helper
INFO - 2021-07-14 09:10:19 --> Helper loaded: directory_helper
INFO - 2021-07-14 09:10:19 --> Helper loaded: language_helper
INFO - 2021-07-14 09:10:19 --> Helper loaded: general_helper
INFO - 2021-07-14 09:10:19 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 09:10:19 --> Database Driver Class Initialized
DEBUG - 2021-07-14 09:10:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 09:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:10:19 --> Parser Class Initialized
INFO - 2021-07-14 09:10:19 --> Form Validation Class Initialized
INFO - 2021-07-14 09:10:19 --> Upload Class Initialized
INFO - 2021-07-14 09:10:19 --> Email Class Initialized
INFO - 2021-07-14 09:10:19 --> MY_Model class loaded
INFO - 2021-07-14 09:10:19 --> Model "Users_model" initialized
INFO - 2021-07-14 09:10:19 --> Model "Settings_model" initialized
INFO - 2021-07-14 09:10:19 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 09:10:19 --> Model "Permissions_model" initialized
INFO - 2021-07-14 09:10:19 --> Model "Roles_model" initialized
INFO - 2021-07-14 09:10:19 --> Model "Activity_model" initialized
INFO - 2021-07-14 09:10:19 --> Model "Templates_model" initialized
INFO - 2021-07-14 09:10:19 --> Database Driver Class Initialized
INFO - 2021-07-14 09:10:19 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 09:10:19 --> Controller Class Initialized
ERROR - 2021-07-14 09:10:19 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 09:10:19 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-14 09:10:19 --> Final output sent to browser
DEBUG - 2021-07-14 09:10:19 --> Total execution time: 0.1371
INFO - 2021-07-14 09:10:25 --> Config Class Initialized
INFO - 2021-07-14 09:10:25 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:10:25 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:10:25 --> Utf8 Class Initialized
INFO - 2021-07-14 09:10:25 --> URI Class Initialized
INFO - 2021-07-14 09:10:25 --> Router Class Initialized
INFO - 2021-07-14 09:10:25 --> Output Class Initialized
INFO - 2021-07-14 09:10:25 --> Security Class Initialized
DEBUG - 2021-07-14 09:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:10:25 --> Input Class Initialized
INFO - 2021-07-14 09:10:25 --> Language Class Initialized
ERROR - 2021-07-14 09:10:25 --> 404 Page Not Found: Faviconico/index
INFO - 2021-07-14 09:10:29 --> Config Class Initialized
INFO - 2021-07-14 09:10:29 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:10:29 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:10:29 --> Utf8 Class Initialized
INFO - 2021-07-14 09:10:29 --> URI Class Initialized
INFO - 2021-07-14 09:10:29 --> Router Class Initialized
INFO - 2021-07-14 09:10:29 --> Output Class Initialized
INFO - 2021-07-14 09:10:29 --> Security Class Initialized
DEBUG - 2021-07-14 09:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:10:29 --> Input Class Initialized
INFO - 2021-07-14 09:10:29 --> Language Class Initialized
INFO - 2021-07-14 09:10:29 --> Loader Class Initialized
INFO - 2021-07-14 09:10:29 --> Helper loaded: basic_helper
INFO - 2021-07-14 09:10:29 --> Helper loaded: url_helper
INFO - 2021-07-14 09:10:29 --> Helper loaded: file_helper
INFO - 2021-07-14 09:10:29 --> Helper loaded: form_helper
INFO - 2021-07-14 09:10:29 --> Helper loaded: cookie_helper
INFO - 2021-07-14 09:10:29 --> Helper loaded: security_helper
INFO - 2021-07-14 09:10:29 --> Helper loaded: directory_helper
INFO - 2021-07-14 09:10:29 --> Helper loaded: language_helper
INFO - 2021-07-14 09:10:29 --> Helper loaded: general_helper
INFO - 2021-07-14 09:10:29 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 09:10:29 --> Database Driver Class Initialized
DEBUG - 2021-07-14 09:10:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 09:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:10:29 --> Parser Class Initialized
INFO - 2021-07-14 09:10:29 --> Form Validation Class Initialized
INFO - 2021-07-14 09:10:29 --> Upload Class Initialized
INFO - 2021-07-14 09:10:29 --> Email Class Initialized
INFO - 2021-07-14 09:10:29 --> MY_Model class loaded
INFO - 2021-07-14 09:10:29 --> Model "Users_model" initialized
INFO - 2021-07-14 09:10:29 --> Model "Settings_model" initialized
INFO - 2021-07-14 09:10:29 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 09:10:29 --> Model "Permissions_model" initialized
INFO - 2021-07-14 09:10:29 --> Model "Roles_model" initialized
INFO - 2021-07-14 09:10:29 --> Model "Activity_model" initialized
INFO - 2021-07-14 09:10:29 --> Model "Templates_model" initialized
INFO - 2021-07-14 09:10:29 --> Database Driver Class Initialized
INFO - 2021-07-14 09:10:30 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 09:10:30 --> Controller Class Initialized
ERROR - 2021-07-14 09:10:30 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 09:10:30 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-14 09:10:30 --> Final output sent to browser
DEBUG - 2021-07-14 09:10:30 --> Total execution time: 0.2715
INFO - 2021-07-14 09:10:45 --> Config Class Initialized
INFO - 2021-07-14 09:10:45 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:10:45 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:10:45 --> Utf8 Class Initialized
INFO - 2021-07-14 09:10:45 --> URI Class Initialized
INFO - 2021-07-14 09:10:45 --> Router Class Initialized
INFO - 2021-07-14 09:10:45 --> Output Class Initialized
INFO - 2021-07-14 09:10:45 --> Security Class Initialized
DEBUG - 2021-07-14 09:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:10:45 --> Input Class Initialized
INFO - 2021-07-14 09:10:45 --> Language Class Initialized
INFO - 2021-07-14 09:10:45 --> Loader Class Initialized
INFO - 2021-07-14 09:10:45 --> Helper loaded: basic_helper
INFO - 2021-07-14 09:10:45 --> Helper loaded: url_helper
INFO - 2021-07-14 09:10:45 --> Helper loaded: file_helper
INFO - 2021-07-14 09:10:45 --> Helper loaded: form_helper
INFO - 2021-07-14 09:10:45 --> Helper loaded: cookie_helper
INFO - 2021-07-14 09:10:45 --> Helper loaded: security_helper
INFO - 2021-07-14 09:10:45 --> Helper loaded: directory_helper
INFO - 2021-07-14 09:10:45 --> Helper loaded: language_helper
INFO - 2021-07-14 09:10:45 --> Helper loaded: general_helper
INFO - 2021-07-14 09:10:45 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 09:10:45 --> Database Driver Class Initialized
DEBUG - 2021-07-14 09:10:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 09:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:10:45 --> Parser Class Initialized
INFO - 2021-07-14 09:10:45 --> Form Validation Class Initialized
INFO - 2021-07-14 09:10:45 --> Upload Class Initialized
INFO - 2021-07-14 09:10:45 --> Email Class Initialized
INFO - 2021-07-14 09:10:45 --> MY_Model class loaded
INFO - 2021-07-14 09:10:45 --> Model "Users_model" initialized
INFO - 2021-07-14 09:10:45 --> Model "Settings_model" initialized
INFO - 2021-07-14 09:10:45 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 09:10:45 --> Model "Permissions_model" initialized
INFO - 2021-07-14 09:10:45 --> Model "Roles_model" initialized
INFO - 2021-07-14 09:10:45 --> Model "Activity_model" initialized
INFO - 2021-07-14 09:10:45 --> Model "Templates_model" initialized
INFO - 2021-07-14 09:10:45 --> Database Driver Class Initialized
INFO - 2021-07-14 09:10:45 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 09:10:45 --> Controller Class Initialized
ERROR - 2021-07-14 09:10:45 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 09:10:45 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-14 09:10:45 --> Final output sent to browser
DEBUG - 2021-07-14 09:10:45 --> Total execution time: 0.1348
INFO - 2021-07-14 09:11:45 --> Config Class Initialized
INFO - 2021-07-14 09:11:45 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:11:45 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:11:45 --> Utf8 Class Initialized
INFO - 2021-07-14 09:11:45 --> URI Class Initialized
INFO - 2021-07-14 09:11:45 --> Router Class Initialized
INFO - 2021-07-14 09:11:45 --> Output Class Initialized
INFO - 2021-07-14 09:11:45 --> Security Class Initialized
DEBUG - 2021-07-14 09:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:11:45 --> Input Class Initialized
INFO - 2021-07-14 09:11:45 --> Language Class Initialized
INFO - 2021-07-14 09:11:45 --> Loader Class Initialized
INFO - 2021-07-14 09:11:45 --> Helper loaded: basic_helper
INFO - 2021-07-14 09:11:45 --> Helper loaded: url_helper
INFO - 2021-07-14 09:11:45 --> Helper loaded: file_helper
INFO - 2021-07-14 09:11:45 --> Helper loaded: form_helper
INFO - 2021-07-14 09:11:45 --> Helper loaded: cookie_helper
INFO - 2021-07-14 09:11:45 --> Helper loaded: security_helper
INFO - 2021-07-14 09:11:45 --> Helper loaded: directory_helper
INFO - 2021-07-14 09:11:45 --> Helper loaded: language_helper
INFO - 2021-07-14 09:11:45 --> Helper loaded: general_helper
INFO - 2021-07-14 09:11:45 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 09:11:45 --> Database Driver Class Initialized
DEBUG - 2021-07-14 09:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 09:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:11:45 --> Parser Class Initialized
INFO - 2021-07-14 09:11:45 --> Form Validation Class Initialized
INFO - 2021-07-14 09:11:45 --> Upload Class Initialized
INFO - 2021-07-14 09:11:45 --> Email Class Initialized
INFO - 2021-07-14 09:11:45 --> MY_Model class loaded
INFO - 2021-07-14 09:11:45 --> Model "Users_model" initialized
INFO - 2021-07-14 09:11:45 --> Model "Settings_model" initialized
INFO - 2021-07-14 09:11:45 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 09:11:45 --> Model "Permissions_model" initialized
INFO - 2021-07-14 09:11:45 --> Model "Roles_model" initialized
INFO - 2021-07-14 09:11:45 --> Model "Activity_model" initialized
INFO - 2021-07-14 09:11:45 --> Model "Templates_model" initialized
INFO - 2021-07-14 09:11:45 --> Database Driver Class Initialized
INFO - 2021-07-14 09:11:45 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 09:11:45 --> Controller Class Initialized
ERROR - 2021-07-14 09:11:45 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 09:11:45 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-14 09:11:45 --> Final output sent to browser
DEBUG - 2021-07-14 09:11:45 --> Total execution time: 0.1946
INFO - 2021-07-14 09:11:54 --> Config Class Initialized
INFO - 2021-07-14 09:11:54 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:11:54 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:11:54 --> Utf8 Class Initialized
INFO - 2021-07-14 09:11:54 --> URI Class Initialized
INFO - 2021-07-14 09:11:54 --> Router Class Initialized
INFO - 2021-07-14 09:11:54 --> Output Class Initialized
INFO - 2021-07-14 09:11:54 --> Security Class Initialized
DEBUG - 2021-07-14 09:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:11:54 --> Input Class Initialized
INFO - 2021-07-14 09:11:54 --> Language Class Initialized
INFO - 2021-07-14 09:11:54 --> Loader Class Initialized
INFO - 2021-07-14 09:11:54 --> Helper loaded: basic_helper
INFO - 2021-07-14 09:11:54 --> Helper loaded: url_helper
INFO - 2021-07-14 09:11:54 --> Helper loaded: file_helper
INFO - 2021-07-14 09:11:54 --> Helper loaded: form_helper
INFO - 2021-07-14 09:11:54 --> Helper loaded: cookie_helper
INFO - 2021-07-14 09:11:54 --> Helper loaded: security_helper
INFO - 2021-07-14 09:11:54 --> Helper loaded: directory_helper
INFO - 2021-07-14 09:11:54 --> Helper loaded: language_helper
INFO - 2021-07-14 09:11:54 --> Helper loaded: general_helper
INFO - 2021-07-14 09:11:54 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 09:11:54 --> Database Driver Class Initialized
DEBUG - 2021-07-14 09:11:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 09:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:11:54 --> Parser Class Initialized
INFO - 2021-07-14 09:11:54 --> Form Validation Class Initialized
INFO - 2021-07-14 09:11:54 --> Upload Class Initialized
INFO - 2021-07-14 09:11:54 --> Email Class Initialized
INFO - 2021-07-14 09:11:54 --> MY_Model class loaded
INFO - 2021-07-14 09:11:54 --> Model "Users_model" initialized
INFO - 2021-07-14 09:11:54 --> Model "Settings_model" initialized
INFO - 2021-07-14 09:11:54 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 09:11:54 --> Model "Permissions_model" initialized
INFO - 2021-07-14 09:11:54 --> Model "Roles_model" initialized
INFO - 2021-07-14 09:11:54 --> Model "Activity_model" initialized
INFO - 2021-07-14 09:11:54 --> Model "Templates_model" initialized
INFO - 2021-07-14 09:11:54 --> Database Driver Class Initialized
INFO - 2021-07-14 09:11:54 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 09:11:54 --> Controller Class Initialized
ERROR - 2021-07-14 09:11:54 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 09:11:54 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-14 09:11:54 --> Final output sent to browser
DEBUG - 2021-07-14 09:11:54 --> Total execution time: 0.1367
INFO - 2021-07-14 09:14:39 --> Config Class Initialized
INFO - 2021-07-14 09:14:39 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:14:39 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:14:39 --> Utf8 Class Initialized
INFO - 2021-07-14 09:14:39 --> URI Class Initialized
DEBUG - 2021-07-14 09:14:39 --> No URI present. Default controller set.
INFO - 2021-07-14 09:14:39 --> Router Class Initialized
INFO - 2021-07-14 09:14:39 --> Output Class Initialized
INFO - 2021-07-14 09:14:39 --> Security Class Initialized
DEBUG - 2021-07-14 09:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:14:39 --> Input Class Initialized
INFO - 2021-07-14 09:14:39 --> Language Class Initialized
INFO - 2021-07-14 09:14:39 --> Loader Class Initialized
INFO - 2021-07-14 09:14:39 --> Helper loaded: basic_helper
INFO - 2021-07-14 09:14:39 --> Helper loaded: url_helper
INFO - 2021-07-14 09:14:39 --> Helper loaded: file_helper
INFO - 2021-07-14 09:14:39 --> Helper loaded: form_helper
INFO - 2021-07-14 09:14:39 --> Helper loaded: cookie_helper
INFO - 2021-07-14 09:14:39 --> Helper loaded: security_helper
INFO - 2021-07-14 09:14:39 --> Helper loaded: directory_helper
INFO - 2021-07-14 09:14:39 --> Helper loaded: language_helper
INFO - 2021-07-14 09:14:39 --> Helper loaded: general_helper
INFO - 2021-07-14 09:14:39 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 09:14:39 --> Database Driver Class Initialized
DEBUG - 2021-07-14 09:14:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 09:14:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:14:39 --> Parser Class Initialized
INFO - 2021-07-14 09:14:39 --> Form Validation Class Initialized
INFO - 2021-07-14 09:14:39 --> Upload Class Initialized
INFO - 2021-07-14 09:14:39 --> Email Class Initialized
INFO - 2021-07-14 09:14:39 --> MY_Model class loaded
INFO - 2021-07-14 09:14:39 --> Model "Users_model" initialized
INFO - 2021-07-14 09:14:39 --> Model "Settings_model" initialized
INFO - 2021-07-14 09:14:39 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 09:14:39 --> Model "Permissions_model" initialized
INFO - 2021-07-14 09:14:39 --> Model "Roles_model" initialized
INFO - 2021-07-14 09:14:39 --> Model "Activity_model" initialized
INFO - 2021-07-14 09:14:39 --> Model "Templates_model" initialized
INFO - 2021-07-14 09:14:39 --> Database Driver Class Initialized
INFO - 2021-07-14 09:14:40 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 09:14:40 --> Controller Class Initialized
ERROR - 2021-07-14 09:14:40 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 09:14:40 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-14 09:14:40 --> Final output sent to browser
DEBUG - 2021-07-14 09:14:40 --> Total execution time: 0.5331
INFO - 2021-07-14 09:14:42 --> Config Class Initialized
INFO - 2021-07-14 09:14:42 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:14:42 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:14:42 --> Utf8 Class Initialized
INFO - 2021-07-14 09:14:42 --> URI Class Initialized
INFO - 2021-07-14 09:14:42 --> Router Class Initialized
INFO - 2021-07-14 09:14:42 --> Output Class Initialized
INFO - 2021-07-14 09:14:42 --> Security Class Initialized
DEBUG - 2021-07-14 09:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:14:42 --> Input Class Initialized
INFO - 2021-07-14 09:14:42 --> Language Class Initialized
INFO - 2021-07-14 09:14:42 --> Loader Class Initialized
INFO - 2021-07-14 09:14:42 --> Helper loaded: basic_helper
INFO - 2021-07-14 09:14:42 --> Helper loaded: url_helper
INFO - 2021-07-14 09:14:42 --> Helper loaded: file_helper
INFO - 2021-07-14 09:14:42 --> Helper loaded: form_helper
INFO - 2021-07-14 09:14:42 --> Helper loaded: cookie_helper
INFO - 2021-07-14 09:14:42 --> Helper loaded: security_helper
INFO - 2021-07-14 09:14:42 --> Helper loaded: directory_helper
INFO - 2021-07-14 09:14:42 --> Helper loaded: language_helper
INFO - 2021-07-14 09:14:42 --> Helper loaded: general_helper
INFO - 2021-07-14 09:14:42 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 09:14:42 --> Database Driver Class Initialized
DEBUG - 2021-07-14 09:14:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 09:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:14:42 --> Parser Class Initialized
INFO - 2021-07-14 09:14:42 --> Form Validation Class Initialized
INFO - 2021-07-14 09:14:42 --> Upload Class Initialized
INFO - 2021-07-14 09:14:42 --> Email Class Initialized
INFO - 2021-07-14 09:14:42 --> MY_Model class loaded
INFO - 2021-07-14 09:14:42 --> Model "Users_model" initialized
INFO - 2021-07-14 09:14:42 --> Model "Settings_model" initialized
INFO - 2021-07-14 09:14:42 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 09:14:42 --> Model "Permissions_model" initialized
INFO - 2021-07-14 09:14:42 --> Model "Roles_model" initialized
INFO - 2021-07-14 09:14:42 --> Model "Activity_model" initialized
INFO - 2021-07-14 09:14:42 --> Model "Templates_model" initialized
INFO - 2021-07-14 09:14:42 --> Database Driver Class Initialized
INFO - 2021-07-14 09:14:42 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 09:14:42 --> Controller Class Initialized
ERROR - 2021-07-14 09:14:42 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 09:14:42 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-14 09:14:42 --> Final output sent to browser
DEBUG - 2021-07-14 09:14:42 --> Total execution time: 0.1323
INFO - 2021-07-14 09:14:58 --> Config Class Initialized
INFO - 2021-07-14 09:14:58 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:14:58 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:14:58 --> Utf8 Class Initialized
INFO - 2021-07-14 09:14:58 --> URI Class Initialized
INFO - 2021-07-14 09:14:58 --> Router Class Initialized
INFO - 2021-07-14 09:14:58 --> Output Class Initialized
INFO - 2021-07-14 09:14:58 --> Security Class Initialized
DEBUG - 2021-07-14 09:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:14:58 --> Input Class Initialized
INFO - 2021-07-14 09:14:58 --> Language Class Initialized
INFO - 2021-07-14 09:14:58 --> Loader Class Initialized
INFO - 2021-07-14 09:14:58 --> Helper loaded: basic_helper
INFO - 2021-07-14 09:14:58 --> Helper loaded: url_helper
INFO - 2021-07-14 09:14:58 --> Helper loaded: file_helper
INFO - 2021-07-14 09:14:58 --> Helper loaded: form_helper
INFO - 2021-07-14 09:14:58 --> Helper loaded: cookie_helper
INFO - 2021-07-14 09:14:58 --> Helper loaded: security_helper
INFO - 2021-07-14 09:14:58 --> Helper loaded: directory_helper
INFO - 2021-07-14 09:14:58 --> Helper loaded: language_helper
INFO - 2021-07-14 09:14:58 --> Helper loaded: general_helper
INFO - 2021-07-14 09:14:58 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 09:14:58 --> Database Driver Class Initialized
DEBUG - 2021-07-14 09:14:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 09:14:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:14:58 --> Parser Class Initialized
INFO - 2021-07-14 09:14:58 --> Form Validation Class Initialized
INFO - 2021-07-14 09:14:58 --> Upload Class Initialized
INFO - 2021-07-14 09:14:58 --> Email Class Initialized
INFO - 2021-07-14 09:14:58 --> MY_Model class loaded
INFO - 2021-07-14 09:14:58 --> Model "Users_model" initialized
INFO - 2021-07-14 09:14:58 --> Model "Settings_model" initialized
INFO - 2021-07-14 09:14:58 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 09:14:58 --> Model "Permissions_model" initialized
INFO - 2021-07-14 09:14:58 --> Model "Roles_model" initialized
INFO - 2021-07-14 09:14:58 --> Model "Activity_model" initialized
INFO - 2021-07-14 09:14:58 --> Model "Templates_model" initialized
INFO - 2021-07-14 09:14:58 --> Database Driver Class Initialized
INFO - 2021-07-14 09:14:58 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 09:14:58 --> Controller Class Initialized
ERROR - 2021-07-14 09:14:58 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 09:14:58 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-14 09:14:58 --> Final output sent to browser
DEBUG - 2021-07-14 09:14:58 --> Total execution time: 0.1680
INFO - 2021-07-14 09:22:07 --> Config Class Initialized
INFO - 2021-07-14 09:22:07 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:22:07 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:22:07 --> Utf8 Class Initialized
INFO - 2021-07-14 09:22:07 --> URI Class Initialized
DEBUG - 2021-07-14 09:22:07 --> No URI present. Default controller set.
INFO - 2021-07-14 09:22:07 --> Router Class Initialized
INFO - 2021-07-14 09:22:07 --> Output Class Initialized
INFO - 2021-07-14 09:22:07 --> Security Class Initialized
DEBUG - 2021-07-14 09:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:22:07 --> Input Class Initialized
INFO - 2021-07-14 09:22:07 --> Language Class Initialized
INFO - 2021-07-14 09:22:07 --> Loader Class Initialized
INFO - 2021-07-14 09:22:07 --> Helper loaded: basic_helper
INFO - 2021-07-14 09:22:07 --> Helper loaded: url_helper
INFO - 2021-07-14 09:22:07 --> Helper loaded: file_helper
INFO - 2021-07-14 09:22:07 --> Helper loaded: form_helper
INFO - 2021-07-14 09:22:07 --> Helper loaded: cookie_helper
INFO - 2021-07-14 09:22:07 --> Helper loaded: security_helper
INFO - 2021-07-14 09:22:07 --> Helper loaded: directory_helper
INFO - 2021-07-14 09:22:07 --> Helper loaded: language_helper
INFO - 2021-07-14 09:22:07 --> Helper loaded: general_helper
INFO - 2021-07-14 09:22:07 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 09:22:07 --> Database Driver Class Initialized
DEBUG - 2021-07-14 09:22:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 09:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:22:07 --> Parser Class Initialized
INFO - 2021-07-14 09:22:07 --> Form Validation Class Initialized
INFO - 2021-07-14 09:22:07 --> Upload Class Initialized
INFO - 2021-07-14 09:22:07 --> Email Class Initialized
INFO - 2021-07-14 09:22:07 --> MY_Model class loaded
INFO - 2021-07-14 09:22:07 --> Model "Users_model" initialized
INFO - 2021-07-14 09:22:07 --> Model "Settings_model" initialized
INFO - 2021-07-14 09:22:07 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 09:22:07 --> Model "Permissions_model" initialized
INFO - 2021-07-14 09:22:07 --> Model "Roles_model" initialized
INFO - 2021-07-14 09:22:07 --> Model "Activity_model" initialized
INFO - 2021-07-14 09:22:07 --> Model "Templates_model" initialized
INFO - 2021-07-14 09:22:07 --> Database Driver Class Initialized
INFO - 2021-07-14 09:22:07 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 09:22:07 --> Controller Class Initialized
ERROR - 2021-07-14 09:22:07 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 09:22:07 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-14 09:22:07 --> Final output sent to browser
DEBUG - 2021-07-14 09:22:07 --> Total execution time: 0.1342
INFO - 2021-07-14 09:22:09 --> Config Class Initialized
INFO - 2021-07-14 09:22:09 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:22:09 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:22:09 --> Utf8 Class Initialized
INFO - 2021-07-14 09:22:09 --> URI Class Initialized
INFO - 2021-07-14 09:22:09 --> Router Class Initialized
INFO - 2021-07-14 09:22:09 --> Output Class Initialized
INFO - 2021-07-14 09:22:09 --> Security Class Initialized
DEBUG - 2021-07-14 09:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:22:09 --> Input Class Initialized
INFO - 2021-07-14 09:22:09 --> Language Class Initialized
INFO - 2021-07-14 09:22:09 --> Loader Class Initialized
INFO - 2021-07-14 09:22:09 --> Helper loaded: basic_helper
INFO - 2021-07-14 09:22:09 --> Helper loaded: url_helper
INFO - 2021-07-14 09:22:09 --> Helper loaded: file_helper
INFO - 2021-07-14 09:22:09 --> Helper loaded: form_helper
INFO - 2021-07-14 09:22:09 --> Helper loaded: cookie_helper
INFO - 2021-07-14 09:22:09 --> Helper loaded: security_helper
INFO - 2021-07-14 09:22:09 --> Helper loaded: directory_helper
INFO - 2021-07-14 09:22:09 --> Helper loaded: language_helper
INFO - 2021-07-14 09:22:09 --> Helper loaded: general_helper
INFO - 2021-07-14 09:22:09 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 09:22:09 --> Database Driver Class Initialized
DEBUG - 2021-07-14 09:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 09:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:22:09 --> Parser Class Initialized
INFO - 2021-07-14 09:22:09 --> Form Validation Class Initialized
INFO - 2021-07-14 09:22:09 --> Upload Class Initialized
INFO - 2021-07-14 09:22:09 --> Email Class Initialized
INFO - 2021-07-14 09:22:09 --> MY_Model class loaded
INFO - 2021-07-14 09:22:09 --> Model "Users_model" initialized
INFO - 2021-07-14 09:22:09 --> Model "Settings_model" initialized
INFO - 2021-07-14 09:22:09 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 09:22:09 --> Model "Permissions_model" initialized
INFO - 2021-07-14 09:22:09 --> Model "Roles_model" initialized
INFO - 2021-07-14 09:22:09 --> Model "Activity_model" initialized
INFO - 2021-07-14 09:22:09 --> Model "Templates_model" initialized
INFO - 2021-07-14 09:22:09 --> Database Driver Class Initialized
INFO - 2021-07-14 09:22:09 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 09:22:09 --> Controller Class Initialized
ERROR - 2021-07-14 09:22:09 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 09:22:09 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-14 09:22:09 --> Final output sent to browser
DEBUG - 2021-07-14 09:22:09 --> Total execution time: 0.1317
INFO - 2021-07-14 09:22:17 --> Config Class Initialized
INFO - 2021-07-14 09:22:17 --> Hooks Class Initialized
DEBUG - 2021-07-14 09:22:17 --> UTF-8 Support Enabled
INFO - 2021-07-14 09:22:17 --> Utf8 Class Initialized
INFO - 2021-07-14 09:22:17 --> URI Class Initialized
INFO - 2021-07-14 09:22:17 --> Router Class Initialized
INFO - 2021-07-14 09:22:17 --> Output Class Initialized
INFO - 2021-07-14 09:22:17 --> Security Class Initialized
DEBUG - 2021-07-14 09:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 09:22:17 --> Input Class Initialized
INFO - 2021-07-14 09:22:17 --> Language Class Initialized
INFO - 2021-07-14 09:22:17 --> Loader Class Initialized
INFO - 2021-07-14 09:22:17 --> Helper loaded: basic_helper
INFO - 2021-07-14 09:22:17 --> Helper loaded: url_helper
INFO - 2021-07-14 09:22:17 --> Helper loaded: file_helper
INFO - 2021-07-14 09:22:17 --> Helper loaded: form_helper
INFO - 2021-07-14 09:22:17 --> Helper loaded: cookie_helper
INFO - 2021-07-14 09:22:17 --> Helper loaded: security_helper
INFO - 2021-07-14 09:22:17 --> Helper loaded: directory_helper
INFO - 2021-07-14 09:22:17 --> Helper loaded: language_helper
INFO - 2021-07-14 09:22:17 --> Helper loaded: general_helper
INFO - 2021-07-14 09:22:17 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 09:22:17 --> Database Driver Class Initialized
DEBUG - 2021-07-14 09:22:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 09:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 09:22:17 --> Parser Class Initialized
INFO - 2021-07-14 09:22:17 --> Form Validation Class Initialized
INFO - 2021-07-14 09:22:17 --> Upload Class Initialized
INFO - 2021-07-14 09:22:17 --> Email Class Initialized
INFO - 2021-07-14 09:22:17 --> MY_Model class loaded
INFO - 2021-07-14 09:22:17 --> Model "Users_model" initialized
INFO - 2021-07-14 09:22:17 --> Model "Settings_model" initialized
INFO - 2021-07-14 09:22:17 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 09:22:17 --> Model "Permissions_model" initialized
INFO - 2021-07-14 09:22:17 --> Model "Roles_model" initialized
INFO - 2021-07-14 09:22:17 --> Model "Activity_model" initialized
INFO - 2021-07-14 09:22:17 --> Model "Templates_model" initialized
INFO - 2021-07-14 09:22:17 --> Database Driver Class Initialized
INFO - 2021-07-14 09:22:18 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 09:22:18 --> Controller Class Initialized
ERROR - 2021-07-14 09:22:18 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 09:22:18 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-14 09:22:18 --> Final output sent to browser
DEBUG - 2021-07-14 09:22:18 --> Total execution time: 0.1314
INFO - 2021-07-14 10:10:11 --> Config Class Initialized
INFO - 2021-07-14 10:10:11 --> Hooks Class Initialized
DEBUG - 2021-07-14 10:10:11 --> UTF-8 Support Enabled
INFO - 2021-07-14 10:10:11 --> Utf8 Class Initialized
INFO - 2021-07-14 10:10:11 --> URI Class Initialized
INFO - 2021-07-14 10:10:11 --> Router Class Initialized
INFO - 2021-07-14 10:10:11 --> Output Class Initialized
INFO - 2021-07-14 10:10:11 --> Security Class Initialized
DEBUG - 2021-07-14 10:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 10:10:11 --> Input Class Initialized
INFO - 2021-07-14 10:10:11 --> Language Class Initialized
INFO - 2021-07-14 10:10:11 --> Loader Class Initialized
INFO - 2021-07-14 10:10:11 --> Helper loaded: basic_helper
INFO - 2021-07-14 10:10:11 --> Helper loaded: url_helper
INFO - 2021-07-14 10:10:11 --> Helper loaded: file_helper
INFO - 2021-07-14 10:10:11 --> Helper loaded: form_helper
INFO - 2021-07-14 10:10:11 --> Helper loaded: cookie_helper
INFO - 2021-07-14 10:10:11 --> Helper loaded: security_helper
INFO - 2021-07-14 10:10:11 --> Helper loaded: directory_helper
INFO - 2021-07-14 10:10:11 --> Helper loaded: language_helper
INFO - 2021-07-14 10:10:11 --> Helper loaded: general_helper
INFO - 2021-07-14 10:10:11 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 10:10:11 --> Database Driver Class Initialized
DEBUG - 2021-07-14 10:10:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 10:10:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 10:10:11 --> Parser Class Initialized
INFO - 2021-07-14 10:10:11 --> Form Validation Class Initialized
INFO - 2021-07-14 10:10:11 --> Upload Class Initialized
INFO - 2021-07-14 10:10:11 --> Email Class Initialized
INFO - 2021-07-14 10:10:11 --> MY_Model class loaded
INFO - 2021-07-14 10:10:11 --> Model "Users_model" initialized
INFO - 2021-07-14 10:10:11 --> Model "Settings_model" initialized
INFO - 2021-07-14 10:10:11 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 10:10:11 --> Model "Permissions_model" initialized
INFO - 2021-07-14 10:10:11 --> Model "Roles_model" initialized
INFO - 2021-07-14 10:10:11 --> Model "Activity_model" initialized
INFO - 2021-07-14 10:10:11 --> Model "Templates_model" initialized
INFO - 2021-07-14 10:10:11 --> Database Driver Class Initialized
INFO - 2021-07-14 10:10:11 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 10:10:11 --> Controller Class Initialized
ERROR - 2021-07-14 10:10:11 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 10:10:11 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-14 10:10:11 --> Final output sent to browser
DEBUG - 2021-07-14 10:10:11 --> Total execution time: 0.3684
INFO - 2021-07-14 10:11:22 --> Config Class Initialized
INFO - 2021-07-14 10:11:22 --> Hooks Class Initialized
DEBUG - 2021-07-14 10:11:22 --> UTF-8 Support Enabled
INFO - 2021-07-14 10:11:22 --> Utf8 Class Initialized
INFO - 2021-07-14 10:11:22 --> URI Class Initialized
DEBUG - 2021-07-14 10:11:22 --> No URI present. Default controller set.
INFO - 2021-07-14 10:11:22 --> Router Class Initialized
INFO - 2021-07-14 10:11:22 --> Output Class Initialized
INFO - 2021-07-14 10:11:22 --> Security Class Initialized
DEBUG - 2021-07-14 10:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 10:11:22 --> Input Class Initialized
INFO - 2021-07-14 10:11:22 --> Language Class Initialized
INFO - 2021-07-14 10:11:22 --> Loader Class Initialized
INFO - 2021-07-14 10:11:22 --> Helper loaded: basic_helper
INFO - 2021-07-14 10:11:22 --> Helper loaded: url_helper
INFO - 2021-07-14 10:11:22 --> Helper loaded: file_helper
INFO - 2021-07-14 10:11:22 --> Helper loaded: form_helper
INFO - 2021-07-14 10:11:22 --> Helper loaded: cookie_helper
INFO - 2021-07-14 10:11:22 --> Helper loaded: security_helper
INFO - 2021-07-14 10:11:22 --> Helper loaded: directory_helper
INFO - 2021-07-14 10:11:22 --> Helper loaded: language_helper
INFO - 2021-07-14 10:11:22 --> Helper loaded: general_helper
INFO - 2021-07-14 10:11:22 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 10:11:22 --> Database Driver Class Initialized
DEBUG - 2021-07-14 10:11:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 10:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 10:11:22 --> Parser Class Initialized
INFO - 2021-07-14 10:11:22 --> Form Validation Class Initialized
INFO - 2021-07-14 10:11:22 --> Upload Class Initialized
INFO - 2021-07-14 10:11:22 --> Email Class Initialized
INFO - 2021-07-14 10:11:22 --> MY_Model class loaded
INFO - 2021-07-14 10:11:22 --> Model "Users_model" initialized
INFO - 2021-07-14 10:11:22 --> Model "Settings_model" initialized
INFO - 2021-07-14 10:11:22 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 10:11:22 --> Model "Permissions_model" initialized
INFO - 2021-07-14 10:11:22 --> Model "Roles_model" initialized
INFO - 2021-07-14 10:11:22 --> Model "Activity_model" initialized
INFO - 2021-07-14 10:11:22 --> Model "Templates_model" initialized
INFO - 2021-07-14 10:11:22 --> Database Driver Class Initialized
INFO - 2021-07-14 10:11:22 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 10:11:22 --> Controller Class Initialized
ERROR - 2021-07-14 10:11:22 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 10:11:22 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-14 10:11:22 --> Final output sent to browser
DEBUG - 2021-07-14 10:11:22 --> Total execution time: 0.5437
INFO - 2021-07-14 10:11:43 --> Config Class Initialized
INFO - 2021-07-14 10:11:43 --> Hooks Class Initialized
DEBUG - 2021-07-14 10:11:43 --> UTF-8 Support Enabled
INFO - 2021-07-14 10:11:43 --> Utf8 Class Initialized
INFO - 2021-07-14 10:11:43 --> URI Class Initialized
INFO - 2021-07-14 10:11:43 --> Router Class Initialized
INFO - 2021-07-14 10:11:43 --> Output Class Initialized
INFO - 2021-07-14 10:11:43 --> Security Class Initialized
DEBUG - 2021-07-14 10:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 10:11:43 --> Input Class Initialized
INFO - 2021-07-14 10:11:43 --> Language Class Initialized
INFO - 2021-07-14 10:11:43 --> Loader Class Initialized
INFO - 2021-07-14 10:11:43 --> Helper loaded: basic_helper
INFO - 2021-07-14 10:11:43 --> Helper loaded: url_helper
INFO - 2021-07-14 10:11:43 --> Helper loaded: file_helper
INFO - 2021-07-14 10:11:43 --> Helper loaded: form_helper
INFO - 2021-07-14 10:11:43 --> Helper loaded: cookie_helper
INFO - 2021-07-14 10:11:43 --> Helper loaded: security_helper
INFO - 2021-07-14 10:11:43 --> Helper loaded: directory_helper
INFO - 2021-07-14 10:11:43 --> Helper loaded: language_helper
INFO - 2021-07-14 10:11:43 --> Helper loaded: general_helper
INFO - 2021-07-14 10:11:43 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 10:11:43 --> Database Driver Class Initialized
DEBUG - 2021-07-14 10:11:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 10:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 10:11:43 --> Parser Class Initialized
INFO - 2021-07-14 10:11:43 --> Form Validation Class Initialized
INFO - 2021-07-14 10:11:43 --> Upload Class Initialized
INFO - 2021-07-14 10:11:43 --> Email Class Initialized
INFO - 2021-07-14 10:11:43 --> MY_Model class loaded
INFO - 2021-07-14 10:11:43 --> Model "Users_model" initialized
INFO - 2021-07-14 10:11:43 --> Model "Settings_model" initialized
INFO - 2021-07-14 10:11:43 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 10:11:43 --> Model "Permissions_model" initialized
INFO - 2021-07-14 10:11:43 --> Model "Roles_model" initialized
INFO - 2021-07-14 10:11:43 --> Model "Activity_model" initialized
INFO - 2021-07-14 10:11:43 --> Model "Templates_model" initialized
INFO - 2021-07-14 10:11:43 --> Database Driver Class Initialized
INFO - 2021-07-14 10:11:43 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 10:11:43 --> Controller Class Initialized
ERROR - 2021-07-14 10:11:43 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 10:11:44 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-14 10:11:44 --> Final output sent to browser
DEBUG - 2021-07-14 10:11:44 --> Total execution time: 0.2805
INFO - 2021-07-14 10:11:52 --> Config Class Initialized
INFO - 2021-07-14 10:11:52 --> Hooks Class Initialized
DEBUG - 2021-07-14 10:11:52 --> UTF-8 Support Enabled
INFO - 2021-07-14 10:11:52 --> Utf8 Class Initialized
INFO - 2021-07-14 10:11:52 --> URI Class Initialized
INFO - 2021-07-14 10:11:52 --> Router Class Initialized
INFO - 2021-07-14 10:11:52 --> Output Class Initialized
INFO - 2021-07-14 10:11:52 --> Security Class Initialized
DEBUG - 2021-07-14 10:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 10:11:52 --> Input Class Initialized
INFO - 2021-07-14 10:11:52 --> Language Class Initialized
INFO - 2021-07-14 10:11:52 --> Loader Class Initialized
INFO - 2021-07-14 10:11:52 --> Helper loaded: basic_helper
INFO - 2021-07-14 10:11:52 --> Helper loaded: url_helper
INFO - 2021-07-14 10:11:52 --> Helper loaded: file_helper
INFO - 2021-07-14 10:11:52 --> Helper loaded: form_helper
INFO - 2021-07-14 10:11:52 --> Helper loaded: cookie_helper
INFO - 2021-07-14 10:11:52 --> Helper loaded: security_helper
INFO - 2021-07-14 10:11:52 --> Helper loaded: directory_helper
INFO - 2021-07-14 10:11:52 --> Helper loaded: language_helper
INFO - 2021-07-14 10:11:52 --> Helper loaded: general_helper
INFO - 2021-07-14 10:11:52 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 10:11:52 --> Database Driver Class Initialized
DEBUG - 2021-07-14 10:11:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 10:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 10:11:52 --> Parser Class Initialized
INFO - 2021-07-14 10:11:52 --> Form Validation Class Initialized
INFO - 2021-07-14 10:11:52 --> Upload Class Initialized
INFO - 2021-07-14 10:11:52 --> Email Class Initialized
INFO - 2021-07-14 10:11:52 --> MY_Model class loaded
INFO - 2021-07-14 10:11:52 --> Model "Users_model" initialized
INFO - 2021-07-14 10:11:52 --> Model "Settings_model" initialized
INFO - 2021-07-14 10:11:52 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 10:11:52 --> Model "Permissions_model" initialized
INFO - 2021-07-14 10:11:52 --> Model "Roles_model" initialized
INFO - 2021-07-14 10:11:52 --> Model "Activity_model" initialized
INFO - 2021-07-14 10:11:52 --> Model "Templates_model" initialized
INFO - 2021-07-14 10:11:52 --> Database Driver Class Initialized
INFO - 2021-07-14 10:11:52 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 10:11:52 --> Controller Class Initialized
ERROR - 2021-07-14 10:11:52 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 10:11:52 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-14 10:11:52 --> Final output sent to browser
DEBUG - 2021-07-14 10:11:52 --> Total execution time: 0.1560
INFO - 2021-07-14 10:26:48 --> Config Class Initialized
INFO - 2021-07-14 10:26:48 --> Hooks Class Initialized
DEBUG - 2021-07-14 10:26:48 --> UTF-8 Support Enabled
INFO - 2021-07-14 10:26:48 --> Utf8 Class Initialized
INFO - 2021-07-14 10:26:48 --> URI Class Initialized
INFO - 2021-07-14 10:26:48 --> Router Class Initialized
INFO - 2021-07-14 10:26:48 --> Output Class Initialized
INFO - 2021-07-14 10:26:48 --> Security Class Initialized
DEBUG - 2021-07-14 10:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 10:26:48 --> Input Class Initialized
INFO - 2021-07-14 10:26:48 --> Language Class Initialized
INFO - 2021-07-14 10:26:48 --> Loader Class Initialized
INFO - 2021-07-14 10:26:48 --> Helper loaded: basic_helper
INFO - 2021-07-14 10:26:48 --> Helper loaded: url_helper
INFO - 2021-07-14 10:26:48 --> Helper loaded: file_helper
INFO - 2021-07-14 10:26:48 --> Helper loaded: form_helper
INFO - 2021-07-14 10:26:48 --> Helper loaded: cookie_helper
INFO - 2021-07-14 10:26:48 --> Helper loaded: security_helper
INFO - 2021-07-14 10:26:48 --> Helper loaded: directory_helper
INFO - 2021-07-14 10:26:48 --> Helper loaded: language_helper
INFO - 2021-07-14 10:26:48 --> Helper loaded: general_helper
INFO - 2021-07-14 10:26:48 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 10:26:48 --> Database Driver Class Initialized
DEBUG - 2021-07-14 10:26:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 10:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 10:26:48 --> Parser Class Initialized
INFO - 2021-07-14 10:26:48 --> Form Validation Class Initialized
INFO - 2021-07-14 10:26:48 --> Upload Class Initialized
INFO - 2021-07-14 10:26:48 --> Email Class Initialized
INFO - 2021-07-14 10:26:48 --> MY_Model class loaded
INFO - 2021-07-14 10:26:48 --> Model "Users_model" initialized
INFO - 2021-07-14 10:26:48 --> Model "Settings_model" initialized
INFO - 2021-07-14 10:26:48 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 10:26:48 --> Model "Permissions_model" initialized
INFO - 2021-07-14 10:26:48 --> Model "Roles_model" initialized
INFO - 2021-07-14 10:26:48 --> Model "Activity_model" initialized
INFO - 2021-07-14 10:26:48 --> Model "Templates_model" initialized
INFO - 2021-07-14 10:26:48 --> Database Driver Class Initialized
INFO - 2021-07-14 10:26:48 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 10:26:48 --> Controller Class Initialized
INFO - 2021-07-14 10:26:48 --> File loaded: C:\wamp64\www\crm\application\views\account/login.php
INFO - 2021-07-14 10:26:48 --> Final output sent to browser
DEBUG - 2021-07-14 10:26:48 --> Total execution time: 0.1360
INFO - 2021-07-14 10:26:51 --> Config Class Initialized
INFO - 2021-07-14 10:26:51 --> Config Class Initialized
INFO - 2021-07-14 10:26:51 --> Hooks Class Initialized
INFO - 2021-07-14 10:26:51 --> Hooks Class Initialized
DEBUG - 2021-07-14 10:26:51 --> UTF-8 Support Enabled
DEBUG - 2021-07-14 10:26:51 --> UTF-8 Support Enabled
INFO - 2021-07-14 10:26:51 --> Utf8 Class Initialized
INFO - 2021-07-14 10:26:51 --> Utf8 Class Initialized
INFO - 2021-07-14 10:26:51 --> URI Class Initialized
INFO - 2021-07-14 10:26:51 --> URI Class Initialized
INFO - 2021-07-14 10:26:51 --> Router Class Initialized
INFO - 2021-07-14 10:26:51 --> Router Class Initialized
INFO - 2021-07-14 10:26:51 --> Output Class Initialized
INFO - 2021-07-14 10:26:51 --> Output Class Initialized
INFO - 2021-07-14 10:26:51 --> Security Class Initialized
INFO - 2021-07-14 10:26:51 --> Security Class Initialized
DEBUG - 2021-07-14 10:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 10:26:51 --> Input Class Initialized
DEBUG - 2021-07-14 10:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 10:26:51 --> Input Class Initialized
INFO - 2021-07-14 10:26:51 --> Language Class Initialized
INFO - 2021-07-14 10:26:51 --> Language Class Initialized
ERROR - 2021-07-14 10:26:51 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-07-14 10:26:51 --> 404 Page Not Found: Assets/jquery
INFO - 2021-07-14 10:26:51 --> Config Class Initialized
INFO - 2021-07-14 10:26:51 --> Hooks Class Initialized
DEBUG - 2021-07-14 10:26:51 --> UTF-8 Support Enabled
INFO - 2021-07-14 10:26:51 --> Utf8 Class Initialized
INFO - 2021-07-14 10:26:51 --> URI Class Initialized
INFO - 2021-07-14 10:26:51 --> Router Class Initialized
INFO - 2021-07-14 10:26:51 --> Output Class Initialized
INFO - 2021-07-14 10:26:51 --> Security Class Initialized
DEBUG - 2021-07-14 10:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 10:26:51 --> Input Class Initialized
INFO - 2021-07-14 10:26:51 --> Language Class Initialized
ERROR - 2021-07-14 10:26:51 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-14 10:26:51 --> Config Class Initialized
INFO - 2021-07-14 10:26:51 --> Hooks Class Initialized
DEBUG - 2021-07-14 10:26:51 --> UTF-8 Support Enabled
INFO - 2021-07-14 10:26:51 --> Utf8 Class Initialized
INFO - 2021-07-14 10:26:51 --> URI Class Initialized
INFO - 2021-07-14 10:26:51 --> Router Class Initialized
INFO - 2021-07-14 10:26:51 --> Output Class Initialized
INFO - 2021-07-14 10:26:51 --> Security Class Initialized
DEBUG - 2021-07-14 10:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 10:26:51 --> Input Class Initialized
INFO - 2021-07-14 10:26:51 --> Language Class Initialized
ERROR - 2021-07-14 10:26:51 --> 404 Page Not Found: Faviconico/index
INFO - 2021-07-14 10:26:54 --> Config Class Initialized
INFO - 2021-07-14 10:26:54 --> Hooks Class Initialized
DEBUG - 2021-07-14 10:26:54 --> UTF-8 Support Enabled
INFO - 2021-07-14 10:26:54 --> Utf8 Class Initialized
INFO - 2021-07-14 10:26:54 --> URI Class Initialized
INFO - 2021-07-14 10:26:54 --> Router Class Initialized
INFO - 2021-07-14 10:26:54 --> Output Class Initialized
INFO - 2021-07-14 10:26:54 --> Security Class Initialized
DEBUG - 2021-07-14 10:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 10:26:54 --> Input Class Initialized
INFO - 2021-07-14 10:26:54 --> Language Class Initialized
INFO - 2021-07-14 10:26:54 --> Loader Class Initialized
INFO - 2021-07-14 10:26:54 --> Helper loaded: basic_helper
INFO - 2021-07-14 10:26:54 --> Helper loaded: url_helper
INFO - 2021-07-14 10:26:54 --> Helper loaded: file_helper
INFO - 2021-07-14 10:26:54 --> Helper loaded: form_helper
INFO - 2021-07-14 10:26:54 --> Helper loaded: cookie_helper
INFO - 2021-07-14 10:26:54 --> Helper loaded: security_helper
INFO - 2021-07-14 10:26:54 --> Helper loaded: directory_helper
INFO - 2021-07-14 10:26:54 --> Helper loaded: language_helper
INFO - 2021-07-14 10:26:54 --> Helper loaded: general_helper
INFO - 2021-07-14 10:26:54 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 10:26:54 --> Database Driver Class Initialized
DEBUG - 2021-07-14 10:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 10:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 10:26:54 --> Parser Class Initialized
INFO - 2021-07-14 10:26:54 --> Form Validation Class Initialized
INFO - 2021-07-14 10:26:54 --> Upload Class Initialized
INFO - 2021-07-14 10:26:54 --> Email Class Initialized
INFO - 2021-07-14 10:26:54 --> MY_Model class loaded
INFO - 2021-07-14 10:26:54 --> Model "Users_model" initialized
INFO - 2021-07-14 10:26:54 --> Model "Settings_model" initialized
INFO - 2021-07-14 10:26:54 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 10:26:54 --> Model "Permissions_model" initialized
INFO - 2021-07-14 10:26:54 --> Model "Roles_model" initialized
INFO - 2021-07-14 10:26:54 --> Model "Activity_model" initialized
INFO - 2021-07-14 10:26:54 --> Model "Templates_model" initialized
INFO - 2021-07-14 10:26:54 --> Database Driver Class Initialized
INFO - 2021-07-14 10:26:54 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 10:26:54 --> Controller Class Initialized
DEBUG - 2021-07-14 10:26:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-14 10:26:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2021-07-14 10:26:54 --> Config Class Initialized
INFO - 2021-07-14 10:26:54 --> Hooks Class Initialized
DEBUG - 2021-07-14 10:26:54 --> UTF-8 Support Enabled
INFO - 2021-07-14 10:26:54 --> Utf8 Class Initialized
INFO - 2021-07-14 10:26:54 --> URI Class Initialized
DEBUG - 2021-07-14 10:26:54 --> No URI present. Default controller set.
INFO - 2021-07-14 10:26:54 --> Router Class Initialized
INFO - 2021-07-14 10:26:54 --> Output Class Initialized
INFO - 2021-07-14 10:26:54 --> Security Class Initialized
DEBUG - 2021-07-14 10:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 10:26:54 --> Input Class Initialized
INFO - 2021-07-14 10:26:54 --> Language Class Initialized
INFO - 2021-07-14 10:26:54 --> Loader Class Initialized
INFO - 2021-07-14 10:26:54 --> Helper loaded: basic_helper
INFO - 2021-07-14 10:26:54 --> Helper loaded: url_helper
INFO - 2021-07-14 10:26:54 --> Helper loaded: file_helper
INFO - 2021-07-14 10:26:54 --> Helper loaded: form_helper
INFO - 2021-07-14 10:26:54 --> Helper loaded: cookie_helper
INFO - 2021-07-14 10:26:54 --> Helper loaded: security_helper
INFO - 2021-07-14 10:26:54 --> Helper loaded: directory_helper
INFO - 2021-07-14 10:26:54 --> Helper loaded: language_helper
INFO - 2021-07-14 10:26:54 --> Helper loaded: general_helper
INFO - 2021-07-14 10:26:54 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 10:26:54 --> Database Driver Class Initialized
DEBUG - 2021-07-14 10:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 10:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 10:26:54 --> Parser Class Initialized
INFO - 2021-07-14 10:26:54 --> Form Validation Class Initialized
INFO - 2021-07-14 10:26:54 --> Upload Class Initialized
INFO - 2021-07-14 10:26:54 --> Email Class Initialized
INFO - 2021-07-14 10:26:54 --> MY_Model class loaded
INFO - 2021-07-14 10:26:54 --> Model "Users_model" initialized
INFO - 2021-07-14 10:26:54 --> Model "Settings_model" initialized
INFO - 2021-07-14 10:26:54 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 10:26:54 --> Model "Permissions_model" initialized
INFO - 2021-07-14 10:26:54 --> Model "Roles_model" initialized
INFO - 2021-07-14 10:26:54 --> Model "Activity_model" initialized
INFO - 2021-07-14 10:26:54 --> Model "Templates_model" initialized
INFO - 2021-07-14 10:26:54 --> Database Driver Class Initialized
INFO - 2021-07-14 10:26:54 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 10:26:54 --> Controller Class Initialized
ERROR - 2021-07-14 10:26:54 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 10:26:54 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-14 10:26:54 --> Final output sent to browser
DEBUG - 2021-07-14 10:26:54 --> Total execution time: 0.0740
INFO - 2021-07-14 10:26:59 --> Config Class Initialized
INFO - 2021-07-14 10:26:59 --> Hooks Class Initialized
DEBUG - 2021-07-14 10:26:59 --> UTF-8 Support Enabled
INFO - 2021-07-14 10:26:59 --> Utf8 Class Initialized
INFO - 2021-07-14 10:26:59 --> URI Class Initialized
INFO - 2021-07-14 10:26:59 --> Router Class Initialized
INFO - 2021-07-14 10:26:59 --> Output Class Initialized
INFO - 2021-07-14 10:26:59 --> Security Class Initialized
DEBUG - 2021-07-14 10:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 10:26:59 --> Input Class Initialized
INFO - 2021-07-14 10:26:59 --> Language Class Initialized
INFO - 2021-07-14 10:26:59 --> Loader Class Initialized
INFO - 2021-07-14 10:26:59 --> Helper loaded: basic_helper
INFO - 2021-07-14 10:26:59 --> Helper loaded: url_helper
INFO - 2021-07-14 10:26:59 --> Helper loaded: file_helper
INFO - 2021-07-14 10:26:59 --> Helper loaded: form_helper
INFO - 2021-07-14 10:26:59 --> Helper loaded: cookie_helper
INFO - 2021-07-14 10:26:59 --> Helper loaded: security_helper
INFO - 2021-07-14 10:26:59 --> Helper loaded: directory_helper
INFO - 2021-07-14 10:26:59 --> Helper loaded: language_helper
INFO - 2021-07-14 10:26:59 --> Helper loaded: general_helper
INFO - 2021-07-14 10:26:59 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 10:26:59 --> Database Driver Class Initialized
DEBUG - 2021-07-14 10:26:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 10:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 10:26:59 --> Parser Class Initialized
INFO - 2021-07-14 10:26:59 --> Form Validation Class Initialized
INFO - 2021-07-14 10:26:59 --> Upload Class Initialized
INFO - 2021-07-14 10:26:59 --> Email Class Initialized
INFO - 2021-07-14 10:26:59 --> MY_Model class loaded
INFO - 2021-07-14 10:26:59 --> Model "Users_model" initialized
INFO - 2021-07-14 10:26:59 --> Model "Settings_model" initialized
INFO - 2021-07-14 10:26:59 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 10:26:59 --> Model "Permissions_model" initialized
INFO - 2021-07-14 10:26:59 --> Model "Roles_model" initialized
INFO - 2021-07-14 10:26:59 --> Model "Activity_model" initialized
INFO - 2021-07-14 10:26:59 --> Model "Templates_model" initialized
INFO - 2021-07-14 10:26:59 --> Database Driver Class Initialized
INFO - 2021-07-14 10:26:59 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 10:26:59 --> Controller Class Initialized
ERROR - 2021-07-14 10:26:59 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 10:26:59 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-14 10:26:59 --> Final output sent to browser
DEBUG - 2021-07-14 10:26:59 --> Total execution time: 0.1241
INFO - 2021-07-14 10:34:57 --> Config Class Initialized
INFO - 2021-07-14 10:34:57 --> Hooks Class Initialized
DEBUG - 2021-07-14 10:34:57 --> UTF-8 Support Enabled
INFO - 2021-07-14 10:34:57 --> Utf8 Class Initialized
INFO - 2021-07-14 10:34:57 --> URI Class Initialized
INFO - 2021-07-14 10:34:57 --> Router Class Initialized
INFO - 2021-07-14 10:34:57 --> Output Class Initialized
INFO - 2021-07-14 10:34:57 --> Security Class Initialized
DEBUG - 2021-07-14 10:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 10:34:57 --> Input Class Initialized
INFO - 2021-07-14 10:34:57 --> Language Class Initialized
INFO - 2021-07-14 10:34:57 --> Loader Class Initialized
INFO - 2021-07-14 10:34:57 --> Helper loaded: basic_helper
INFO - 2021-07-14 10:34:57 --> Helper loaded: url_helper
INFO - 2021-07-14 10:34:57 --> Helper loaded: file_helper
INFO - 2021-07-14 10:34:57 --> Helper loaded: form_helper
INFO - 2021-07-14 10:34:57 --> Helper loaded: cookie_helper
INFO - 2021-07-14 10:34:57 --> Helper loaded: security_helper
INFO - 2021-07-14 10:34:57 --> Helper loaded: directory_helper
INFO - 2021-07-14 10:34:57 --> Helper loaded: language_helper
INFO - 2021-07-14 10:34:57 --> Helper loaded: general_helper
INFO - 2021-07-14 10:34:57 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 10:34:57 --> Database Driver Class Initialized
DEBUG - 2021-07-14 10:34:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 10:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 10:34:57 --> Parser Class Initialized
INFO - 2021-07-14 10:34:57 --> Form Validation Class Initialized
INFO - 2021-07-14 10:34:57 --> Upload Class Initialized
INFO - 2021-07-14 10:34:57 --> Email Class Initialized
INFO - 2021-07-14 10:34:57 --> MY_Model class loaded
INFO - 2021-07-14 10:34:57 --> Model "Users_model" initialized
INFO - 2021-07-14 10:34:57 --> Model "Settings_model" initialized
INFO - 2021-07-14 10:34:57 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 10:34:57 --> Model "Permissions_model" initialized
INFO - 2021-07-14 10:34:57 --> Model "Roles_model" initialized
INFO - 2021-07-14 10:34:57 --> Model "Activity_model" initialized
INFO - 2021-07-14 10:34:57 --> Model "Templates_model" initialized
INFO - 2021-07-14 10:34:57 --> Database Driver Class Initialized
INFO - 2021-07-14 10:34:58 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 10:34:58 --> Controller Class Initialized
ERROR - 2021-07-14 10:34:58 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 10:34:58 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-14 10:34:58 --> Final output sent to browser
DEBUG - 2021-07-14 10:34:58 --> Total execution time: 0.8136
INFO - 2021-07-14 10:35:08 --> Config Class Initialized
INFO - 2021-07-14 10:35:08 --> Hooks Class Initialized
DEBUG - 2021-07-14 10:35:08 --> UTF-8 Support Enabled
INFO - 2021-07-14 10:35:08 --> Utf8 Class Initialized
INFO - 2021-07-14 10:35:08 --> URI Class Initialized
INFO - 2021-07-14 10:35:08 --> Router Class Initialized
INFO - 2021-07-14 10:35:08 --> Output Class Initialized
INFO - 2021-07-14 10:35:08 --> Security Class Initialized
DEBUG - 2021-07-14 10:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 10:35:08 --> Input Class Initialized
INFO - 2021-07-14 10:35:08 --> Language Class Initialized
INFO - 2021-07-14 10:35:08 --> Loader Class Initialized
INFO - 2021-07-14 10:35:08 --> Helper loaded: basic_helper
INFO - 2021-07-14 10:35:08 --> Helper loaded: url_helper
INFO - 2021-07-14 10:35:08 --> Helper loaded: file_helper
INFO - 2021-07-14 10:35:08 --> Helper loaded: form_helper
INFO - 2021-07-14 10:35:08 --> Helper loaded: cookie_helper
INFO - 2021-07-14 10:35:08 --> Helper loaded: security_helper
INFO - 2021-07-14 10:35:08 --> Helper loaded: directory_helper
INFO - 2021-07-14 10:35:08 --> Helper loaded: language_helper
INFO - 2021-07-14 10:35:08 --> Helper loaded: general_helper
INFO - 2021-07-14 10:35:08 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 10:35:08 --> Database Driver Class Initialized
DEBUG - 2021-07-14 10:35:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 10:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 10:35:08 --> Parser Class Initialized
INFO - 2021-07-14 10:35:08 --> Form Validation Class Initialized
INFO - 2021-07-14 10:35:08 --> Upload Class Initialized
INFO - 2021-07-14 10:35:08 --> Email Class Initialized
INFO - 2021-07-14 10:35:08 --> MY_Model class loaded
INFO - 2021-07-14 10:35:08 --> Model "Users_model" initialized
INFO - 2021-07-14 10:35:08 --> Model "Settings_model" initialized
INFO - 2021-07-14 10:35:08 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 10:35:08 --> Model "Permissions_model" initialized
INFO - 2021-07-14 10:35:08 --> Model "Roles_model" initialized
INFO - 2021-07-14 10:35:08 --> Model "Activity_model" initialized
INFO - 2021-07-14 10:35:08 --> Model "Templates_model" initialized
INFO - 2021-07-14 10:35:08 --> Database Driver Class Initialized
INFO - 2021-07-14 10:35:08 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 10:35:08 --> Controller Class Initialized
ERROR - 2021-07-14 10:35:08 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 10:35:08 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-14 10:35:08 --> Final output sent to browser
DEBUG - 2021-07-14 10:35:08 --> Total execution time: 0.1522
INFO - 2021-07-14 10:35:12 --> Config Class Initialized
INFO - 2021-07-14 10:35:12 --> Hooks Class Initialized
DEBUG - 2021-07-14 10:35:12 --> UTF-8 Support Enabled
INFO - 2021-07-14 10:35:12 --> Utf8 Class Initialized
INFO - 2021-07-14 10:35:12 --> URI Class Initialized
INFO - 2021-07-14 10:35:12 --> Router Class Initialized
INFO - 2021-07-14 10:35:12 --> Output Class Initialized
INFO - 2021-07-14 10:35:12 --> Security Class Initialized
DEBUG - 2021-07-14 10:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 10:35:12 --> Input Class Initialized
INFO - 2021-07-14 10:35:12 --> Language Class Initialized
INFO - 2021-07-14 10:35:12 --> Loader Class Initialized
INFO - 2021-07-14 10:35:12 --> Helper loaded: basic_helper
INFO - 2021-07-14 10:35:12 --> Helper loaded: url_helper
INFO - 2021-07-14 10:35:12 --> Helper loaded: file_helper
INFO - 2021-07-14 10:35:12 --> Helper loaded: form_helper
INFO - 2021-07-14 10:35:12 --> Helper loaded: cookie_helper
INFO - 2021-07-14 10:35:12 --> Helper loaded: security_helper
INFO - 2021-07-14 10:35:12 --> Helper loaded: directory_helper
INFO - 2021-07-14 10:35:12 --> Helper loaded: language_helper
INFO - 2021-07-14 10:35:12 --> Helper loaded: general_helper
INFO - 2021-07-14 10:35:12 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 10:35:12 --> Database Driver Class Initialized
DEBUG - 2021-07-14 10:35:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 10:35:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 10:35:12 --> Parser Class Initialized
INFO - 2021-07-14 10:35:12 --> Form Validation Class Initialized
INFO - 2021-07-14 10:35:12 --> Upload Class Initialized
INFO - 2021-07-14 10:35:12 --> Email Class Initialized
INFO - 2021-07-14 10:35:12 --> MY_Model class loaded
INFO - 2021-07-14 10:35:12 --> Model "Users_model" initialized
INFO - 2021-07-14 10:35:12 --> Model "Settings_model" initialized
INFO - 2021-07-14 10:35:12 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 10:35:12 --> Model "Permissions_model" initialized
INFO - 2021-07-14 10:35:12 --> Model "Roles_model" initialized
INFO - 2021-07-14 10:35:12 --> Model "Activity_model" initialized
INFO - 2021-07-14 10:35:12 --> Model "Templates_model" initialized
INFO - 2021-07-14 10:35:12 --> Database Driver Class Initialized
INFO - 2021-07-14 10:35:12 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 10:35:12 --> Controller Class Initialized
ERROR - 2021-07-14 10:35:12 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 10:35:12 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-14 10:35:12 --> Final output sent to browser
DEBUG - 2021-07-14 10:35:12 --> Total execution time: 0.0863
INFO - 2021-07-14 10:35:15 --> Config Class Initialized
INFO - 2021-07-14 10:35:15 --> Hooks Class Initialized
DEBUG - 2021-07-14 10:35:15 --> UTF-8 Support Enabled
INFO - 2021-07-14 10:35:15 --> Utf8 Class Initialized
INFO - 2021-07-14 10:35:15 --> URI Class Initialized
INFO - 2021-07-14 10:35:15 --> Router Class Initialized
INFO - 2021-07-14 10:35:15 --> Output Class Initialized
INFO - 2021-07-14 10:35:15 --> Security Class Initialized
DEBUG - 2021-07-14 10:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 10:35:15 --> Input Class Initialized
INFO - 2021-07-14 10:35:15 --> Language Class Initialized
INFO - 2021-07-14 10:35:15 --> Loader Class Initialized
INFO - 2021-07-14 10:35:15 --> Helper loaded: basic_helper
INFO - 2021-07-14 10:35:15 --> Helper loaded: url_helper
INFO - 2021-07-14 10:35:15 --> Helper loaded: file_helper
INFO - 2021-07-14 10:35:15 --> Helper loaded: form_helper
INFO - 2021-07-14 10:35:15 --> Helper loaded: cookie_helper
INFO - 2021-07-14 10:35:15 --> Helper loaded: security_helper
INFO - 2021-07-14 10:35:15 --> Helper loaded: directory_helper
INFO - 2021-07-14 10:35:15 --> Helper loaded: language_helper
INFO - 2021-07-14 10:35:15 --> Helper loaded: general_helper
INFO - 2021-07-14 10:35:15 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 10:35:15 --> Database Driver Class Initialized
DEBUG - 2021-07-14 10:35:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 10:35:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 10:35:15 --> Parser Class Initialized
INFO - 2021-07-14 10:35:15 --> Form Validation Class Initialized
INFO - 2021-07-14 10:35:15 --> Upload Class Initialized
INFO - 2021-07-14 10:35:15 --> Email Class Initialized
INFO - 2021-07-14 10:35:15 --> MY_Model class loaded
INFO - 2021-07-14 10:35:15 --> Model "Users_model" initialized
INFO - 2021-07-14 10:35:15 --> Model "Settings_model" initialized
INFO - 2021-07-14 10:35:15 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 10:35:15 --> Model "Permissions_model" initialized
INFO - 2021-07-14 10:35:15 --> Model "Roles_model" initialized
INFO - 2021-07-14 10:35:15 --> Model "Activity_model" initialized
INFO - 2021-07-14 10:35:15 --> Model "Templates_model" initialized
INFO - 2021-07-14 10:35:15 --> Database Driver Class Initialized
INFO - 2021-07-14 10:35:16 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 10:35:16 --> Controller Class Initialized
ERROR - 2021-07-14 10:35:16 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 10:35:16 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-14 10:35:16 --> Final output sent to browser
DEBUG - 2021-07-14 10:35:16 --> Total execution time: 0.1398
INFO - 2021-07-14 10:43:58 --> Config Class Initialized
INFO - 2021-07-14 10:43:58 --> Hooks Class Initialized
DEBUG - 2021-07-14 10:43:58 --> UTF-8 Support Enabled
INFO - 2021-07-14 10:43:58 --> Utf8 Class Initialized
INFO - 2021-07-14 10:43:58 --> URI Class Initialized
INFO - 2021-07-14 10:43:58 --> Router Class Initialized
INFO - 2021-07-14 10:43:58 --> Output Class Initialized
INFO - 2021-07-14 10:43:58 --> Security Class Initialized
DEBUG - 2021-07-14 10:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 10:43:58 --> Input Class Initialized
INFO - 2021-07-14 10:43:58 --> Language Class Initialized
INFO - 2021-07-14 10:43:58 --> Loader Class Initialized
INFO - 2021-07-14 10:43:58 --> Helper loaded: basic_helper
INFO - 2021-07-14 10:43:58 --> Helper loaded: url_helper
INFO - 2021-07-14 10:43:58 --> Helper loaded: file_helper
INFO - 2021-07-14 10:43:58 --> Helper loaded: form_helper
INFO - 2021-07-14 10:43:58 --> Helper loaded: cookie_helper
INFO - 2021-07-14 10:43:58 --> Helper loaded: security_helper
INFO - 2021-07-14 10:43:58 --> Helper loaded: directory_helper
INFO - 2021-07-14 10:43:58 --> Helper loaded: language_helper
INFO - 2021-07-14 10:43:58 --> Helper loaded: general_helper
INFO - 2021-07-14 10:43:58 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 10:43:58 --> Database Driver Class Initialized
DEBUG - 2021-07-14 10:43:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 10:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 10:43:58 --> Parser Class Initialized
INFO - 2021-07-14 10:43:58 --> Form Validation Class Initialized
INFO - 2021-07-14 10:43:58 --> Upload Class Initialized
INFO - 2021-07-14 10:43:58 --> Email Class Initialized
INFO - 2021-07-14 10:43:58 --> MY_Model class loaded
INFO - 2021-07-14 10:43:58 --> Model "Users_model" initialized
INFO - 2021-07-14 10:43:58 --> Model "Settings_model" initialized
INFO - 2021-07-14 10:43:58 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 10:43:58 --> Model "Permissions_model" initialized
INFO - 2021-07-14 10:43:58 --> Model "Roles_model" initialized
INFO - 2021-07-14 10:43:58 --> Model "Activity_model" initialized
INFO - 2021-07-14 10:43:58 --> Model "Templates_model" initialized
INFO - 2021-07-14 10:43:58 --> Database Driver Class Initialized
INFO - 2021-07-14 10:43:58 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 10:43:58 --> Controller Class Initialized
ERROR - 2021-07-14 10:43:58 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 10:43:58 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-14 10:43:58 --> Final output sent to browser
DEBUG - 2021-07-14 10:43:58 --> Total execution time: 0.1348
INFO - 2021-07-14 10:44:02 --> Config Class Initialized
INFO - 2021-07-14 10:44:02 --> Hooks Class Initialized
DEBUG - 2021-07-14 10:44:02 --> UTF-8 Support Enabled
INFO - 2021-07-14 10:44:02 --> Utf8 Class Initialized
INFO - 2021-07-14 10:44:02 --> URI Class Initialized
INFO - 2021-07-14 10:44:02 --> Router Class Initialized
INFO - 2021-07-14 10:44:02 --> Output Class Initialized
INFO - 2021-07-14 10:44:02 --> Security Class Initialized
DEBUG - 2021-07-14 10:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 10:44:02 --> Input Class Initialized
INFO - 2021-07-14 10:44:02 --> Language Class Initialized
INFO - 2021-07-14 10:44:02 --> Loader Class Initialized
INFO - 2021-07-14 10:44:02 --> Helper loaded: basic_helper
INFO - 2021-07-14 10:44:02 --> Helper loaded: url_helper
INFO - 2021-07-14 10:44:02 --> Helper loaded: file_helper
INFO - 2021-07-14 10:44:02 --> Helper loaded: form_helper
INFO - 2021-07-14 10:44:02 --> Helper loaded: cookie_helper
INFO - 2021-07-14 10:44:02 --> Helper loaded: security_helper
INFO - 2021-07-14 10:44:02 --> Helper loaded: directory_helper
INFO - 2021-07-14 10:44:02 --> Helper loaded: language_helper
INFO - 2021-07-14 10:44:02 --> Helper loaded: general_helper
INFO - 2021-07-14 10:44:02 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 10:44:02 --> Database Driver Class Initialized
DEBUG - 2021-07-14 10:44:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 10:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 10:44:02 --> Parser Class Initialized
INFO - 2021-07-14 10:44:02 --> Form Validation Class Initialized
INFO - 2021-07-14 10:44:02 --> Upload Class Initialized
INFO - 2021-07-14 10:44:02 --> Email Class Initialized
INFO - 2021-07-14 10:44:02 --> MY_Model class loaded
INFO - 2021-07-14 10:44:02 --> Model "Users_model" initialized
INFO - 2021-07-14 10:44:02 --> Model "Settings_model" initialized
INFO - 2021-07-14 10:44:02 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 10:44:02 --> Model "Permissions_model" initialized
INFO - 2021-07-14 10:44:02 --> Model "Roles_model" initialized
INFO - 2021-07-14 10:44:02 --> Model "Activity_model" initialized
INFO - 2021-07-14 10:44:02 --> Model "Templates_model" initialized
INFO - 2021-07-14 10:44:02 --> Database Driver Class Initialized
INFO - 2021-07-14 10:44:02 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 10:44:02 --> Controller Class Initialized
ERROR - 2021-07-14 10:44:02 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 10:44:02 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-14 10:44:02 --> Final output sent to browser
DEBUG - 2021-07-14 10:44:02 --> Total execution time: 0.2397
INFO - 2021-07-14 11:01:24 --> Config Class Initialized
INFO - 2021-07-14 11:01:24 --> Hooks Class Initialized
DEBUG - 2021-07-14 11:01:24 --> UTF-8 Support Enabled
INFO - 2021-07-14 11:01:24 --> Utf8 Class Initialized
INFO - 2021-07-14 11:01:24 --> URI Class Initialized
INFO - 2021-07-14 11:01:24 --> Router Class Initialized
INFO - 2021-07-14 11:01:24 --> Output Class Initialized
INFO - 2021-07-14 11:01:24 --> Security Class Initialized
DEBUG - 2021-07-14 11:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 11:01:24 --> Input Class Initialized
INFO - 2021-07-14 11:01:24 --> Language Class Initialized
INFO - 2021-07-14 11:01:24 --> Loader Class Initialized
INFO - 2021-07-14 11:01:24 --> Helper loaded: basic_helper
INFO - 2021-07-14 11:01:24 --> Helper loaded: url_helper
INFO - 2021-07-14 11:01:24 --> Helper loaded: file_helper
INFO - 2021-07-14 11:01:24 --> Helper loaded: form_helper
INFO - 2021-07-14 11:01:24 --> Helper loaded: cookie_helper
INFO - 2021-07-14 11:01:24 --> Helper loaded: security_helper
INFO - 2021-07-14 11:01:24 --> Helper loaded: directory_helper
INFO - 2021-07-14 11:01:24 --> Helper loaded: language_helper
INFO - 2021-07-14 11:01:24 --> Helper loaded: general_helper
INFO - 2021-07-14 11:01:24 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 11:01:24 --> Database Driver Class Initialized
DEBUG - 2021-07-14 11:01:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 11:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 11:01:24 --> Parser Class Initialized
INFO - 2021-07-14 11:01:24 --> Form Validation Class Initialized
INFO - 2021-07-14 11:01:24 --> Upload Class Initialized
INFO - 2021-07-14 11:01:24 --> Email Class Initialized
INFO - 2021-07-14 11:01:24 --> MY_Model class loaded
INFO - 2021-07-14 11:01:24 --> Model "Users_model" initialized
INFO - 2021-07-14 11:01:24 --> Model "Settings_model" initialized
INFO - 2021-07-14 11:01:24 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 11:01:24 --> Model "Permissions_model" initialized
INFO - 2021-07-14 11:01:24 --> Model "Roles_model" initialized
INFO - 2021-07-14 11:01:24 --> Model "Activity_model" initialized
INFO - 2021-07-14 11:01:24 --> Model "Templates_model" initialized
INFO - 2021-07-14 11:01:24 --> Database Driver Class Initialized
INFO - 2021-07-14 11:01:24 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 11:01:24 --> Controller Class Initialized
ERROR - 2021-07-14 11:01:24 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 11:01:24 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-14 11:01:24 --> Final output sent to browser
DEBUG - 2021-07-14 11:01:24 --> Total execution time: 0.2370
INFO - 2021-07-14 11:45:41 --> Config Class Initialized
INFO - 2021-07-14 11:45:41 --> Hooks Class Initialized
DEBUG - 2021-07-14 11:45:41 --> UTF-8 Support Enabled
INFO - 2021-07-14 11:45:41 --> Utf8 Class Initialized
INFO - 2021-07-14 11:45:41 --> URI Class Initialized
DEBUG - 2021-07-14 11:45:41 --> No URI present. Default controller set.
INFO - 2021-07-14 11:45:41 --> Router Class Initialized
INFO - 2021-07-14 11:45:41 --> Output Class Initialized
INFO - 2021-07-14 11:45:41 --> Security Class Initialized
DEBUG - 2021-07-14 11:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 11:45:41 --> Input Class Initialized
INFO - 2021-07-14 11:45:41 --> Language Class Initialized
INFO - 2021-07-14 11:45:41 --> Loader Class Initialized
INFO - 2021-07-14 11:45:41 --> Helper loaded: basic_helper
INFO - 2021-07-14 11:45:41 --> Helper loaded: url_helper
INFO - 2021-07-14 11:45:41 --> Helper loaded: file_helper
INFO - 2021-07-14 11:45:41 --> Helper loaded: form_helper
INFO - 2021-07-14 11:45:41 --> Helper loaded: cookie_helper
INFO - 2021-07-14 11:45:41 --> Helper loaded: security_helper
INFO - 2021-07-14 11:45:41 --> Helper loaded: directory_helper
INFO - 2021-07-14 11:45:41 --> Helper loaded: language_helper
INFO - 2021-07-14 11:45:41 --> Helper loaded: general_helper
INFO - 2021-07-14 11:45:41 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 11:45:41 --> Database Driver Class Initialized
DEBUG - 2021-07-14 11:45:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 11:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 11:45:41 --> Parser Class Initialized
INFO - 2021-07-14 11:45:41 --> Form Validation Class Initialized
INFO - 2021-07-14 11:45:41 --> Upload Class Initialized
INFO - 2021-07-14 11:45:41 --> Email Class Initialized
INFO - 2021-07-14 11:45:41 --> MY_Model class loaded
INFO - 2021-07-14 11:45:41 --> Model "Users_model" initialized
INFO - 2021-07-14 11:45:41 --> Model "Settings_model" initialized
INFO - 2021-07-14 11:45:41 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 11:45:41 --> Model "Permissions_model" initialized
INFO - 2021-07-14 11:45:41 --> Model "Roles_model" initialized
INFO - 2021-07-14 11:45:41 --> Model "Activity_model" initialized
INFO - 2021-07-14 11:45:41 --> Model "Templates_model" initialized
INFO - 2021-07-14 11:45:41 --> Database Driver Class Initialized
INFO - 2021-07-14 11:45:41 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 11:45:41 --> Controller Class Initialized
INFO - 2021-07-14 12:49:09 --> Config Class Initialized
INFO - 2021-07-14 12:49:09 --> Hooks Class Initialized
DEBUG - 2021-07-14 12:49:09 --> UTF-8 Support Enabled
INFO - 2021-07-14 12:49:09 --> Utf8 Class Initialized
INFO - 2021-07-14 12:49:09 --> URI Class Initialized
DEBUG - 2021-07-14 12:49:09 --> No URI present. Default controller set.
INFO - 2021-07-14 12:49:09 --> Router Class Initialized
INFO - 2021-07-14 12:49:09 --> Output Class Initialized
INFO - 2021-07-14 12:49:09 --> Security Class Initialized
DEBUG - 2021-07-14 12:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 12:49:09 --> Input Class Initialized
INFO - 2021-07-14 12:49:09 --> Language Class Initialized
INFO - 2021-07-14 12:49:09 --> Loader Class Initialized
INFO - 2021-07-14 12:49:09 --> Helper loaded: basic_helper
INFO - 2021-07-14 12:49:09 --> Helper loaded: url_helper
INFO - 2021-07-14 12:49:09 --> Helper loaded: file_helper
INFO - 2021-07-14 12:49:09 --> Helper loaded: form_helper
INFO - 2021-07-14 12:49:09 --> Helper loaded: cookie_helper
INFO - 2021-07-14 12:49:09 --> Helper loaded: security_helper
INFO - 2021-07-14 12:49:09 --> Helper loaded: directory_helper
INFO - 2021-07-14 12:49:09 --> Helper loaded: language_helper
INFO - 2021-07-14 12:49:09 --> Helper loaded: general_helper
INFO - 2021-07-14 12:49:09 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 12:49:09 --> Database Driver Class Initialized
DEBUG - 2021-07-14 12:49:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 12:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 12:49:09 --> Parser Class Initialized
INFO - 2021-07-14 12:49:09 --> Form Validation Class Initialized
INFO - 2021-07-14 12:49:09 --> Upload Class Initialized
INFO - 2021-07-14 12:49:09 --> Email Class Initialized
INFO - 2021-07-14 12:49:09 --> MY_Model class loaded
INFO - 2021-07-14 12:49:09 --> Model "Users_model" initialized
INFO - 2021-07-14 12:49:09 --> Model "Settings_model" initialized
INFO - 2021-07-14 12:49:09 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 12:49:09 --> Model "Permissions_model" initialized
INFO - 2021-07-14 12:49:09 --> Model "Roles_model" initialized
INFO - 2021-07-14 12:49:09 --> Model "Activity_model" initialized
INFO - 2021-07-14 12:49:09 --> Model "Templates_model" initialized
INFO - 2021-07-14 12:49:09 --> Database Driver Class Initialized
INFO - 2021-07-14 12:49:09 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 12:49:09 --> Controller Class Initialized
ERROR - 2021-07-14 12:49:09 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 12:49:09 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-14 12:49:09 --> Final output sent to browser
DEBUG - 2021-07-14 12:49:09 --> Total execution time: 0.1428
INFO - 2021-07-14 12:49:14 --> Config Class Initialized
INFO - 2021-07-14 12:49:14 --> Hooks Class Initialized
DEBUG - 2021-07-14 12:49:14 --> UTF-8 Support Enabled
INFO - 2021-07-14 12:49:14 --> Utf8 Class Initialized
INFO - 2021-07-14 12:49:14 --> URI Class Initialized
INFO - 2021-07-14 12:49:14 --> Router Class Initialized
INFO - 2021-07-14 12:49:14 --> Output Class Initialized
INFO - 2021-07-14 12:49:14 --> Security Class Initialized
DEBUG - 2021-07-14 12:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 12:49:14 --> Input Class Initialized
INFO - 2021-07-14 12:49:14 --> Language Class Initialized
INFO - 2021-07-14 12:49:14 --> Loader Class Initialized
INFO - 2021-07-14 12:49:14 --> Helper loaded: basic_helper
INFO - 2021-07-14 12:49:14 --> Helper loaded: url_helper
INFO - 2021-07-14 12:49:14 --> Helper loaded: file_helper
INFO - 2021-07-14 12:49:14 --> Helper loaded: form_helper
INFO - 2021-07-14 12:49:14 --> Helper loaded: cookie_helper
INFO - 2021-07-14 12:49:14 --> Helper loaded: security_helper
INFO - 2021-07-14 12:49:14 --> Helper loaded: directory_helper
INFO - 2021-07-14 12:49:14 --> Helper loaded: language_helper
INFO - 2021-07-14 12:49:14 --> Helper loaded: general_helper
INFO - 2021-07-14 12:49:14 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 12:49:14 --> Database Driver Class Initialized
DEBUG - 2021-07-14 12:49:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 12:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 12:49:14 --> Parser Class Initialized
INFO - 2021-07-14 12:49:14 --> Form Validation Class Initialized
INFO - 2021-07-14 12:49:14 --> Upload Class Initialized
INFO - 2021-07-14 12:49:14 --> Email Class Initialized
INFO - 2021-07-14 12:49:14 --> MY_Model class loaded
INFO - 2021-07-14 12:49:14 --> Model "Users_model" initialized
INFO - 2021-07-14 12:49:14 --> Model "Settings_model" initialized
INFO - 2021-07-14 12:49:14 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 12:49:14 --> Model "Permissions_model" initialized
INFO - 2021-07-14 12:49:14 --> Model "Roles_model" initialized
INFO - 2021-07-14 12:49:14 --> Model "Activity_model" initialized
INFO - 2021-07-14 12:49:14 --> Model "Templates_model" initialized
INFO - 2021-07-14 12:49:14 --> Database Driver Class Initialized
INFO - 2021-07-14 12:49:14 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 12:49:14 --> Controller Class Initialized
ERROR - 2021-07-14 12:49:14 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 12:49:14 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-14 12:49:14 --> Final output sent to browser
DEBUG - 2021-07-14 12:49:14 --> Total execution time: 0.2158
INFO - 2021-07-14 12:49:26 --> Config Class Initialized
INFO - 2021-07-14 12:49:26 --> Hooks Class Initialized
DEBUG - 2021-07-14 12:49:26 --> UTF-8 Support Enabled
INFO - 2021-07-14 12:49:26 --> Utf8 Class Initialized
INFO - 2021-07-14 12:49:26 --> URI Class Initialized
INFO - 2021-07-14 12:49:26 --> Router Class Initialized
INFO - 2021-07-14 12:49:26 --> Output Class Initialized
INFO - 2021-07-14 12:49:26 --> Security Class Initialized
DEBUG - 2021-07-14 12:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 12:49:26 --> Input Class Initialized
INFO - 2021-07-14 12:49:26 --> Language Class Initialized
INFO - 2021-07-14 12:49:26 --> Loader Class Initialized
INFO - 2021-07-14 12:49:26 --> Helper loaded: basic_helper
INFO - 2021-07-14 12:49:26 --> Helper loaded: url_helper
INFO - 2021-07-14 12:49:26 --> Helper loaded: file_helper
INFO - 2021-07-14 12:49:26 --> Helper loaded: form_helper
INFO - 2021-07-14 12:49:26 --> Helper loaded: cookie_helper
INFO - 2021-07-14 12:49:26 --> Helper loaded: security_helper
INFO - 2021-07-14 12:49:26 --> Helper loaded: directory_helper
INFO - 2021-07-14 12:49:26 --> Helper loaded: language_helper
INFO - 2021-07-14 12:49:26 --> Helper loaded: general_helper
INFO - 2021-07-14 12:49:26 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 12:49:26 --> Database Driver Class Initialized
DEBUG - 2021-07-14 12:49:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 12:49:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 12:49:26 --> Parser Class Initialized
INFO - 2021-07-14 12:49:26 --> Form Validation Class Initialized
INFO - 2021-07-14 12:49:26 --> Upload Class Initialized
INFO - 2021-07-14 12:49:26 --> Email Class Initialized
INFO - 2021-07-14 12:49:26 --> MY_Model class loaded
INFO - 2021-07-14 12:49:26 --> Model "Users_model" initialized
INFO - 2021-07-14 12:49:26 --> Model "Settings_model" initialized
INFO - 2021-07-14 12:49:26 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 12:49:26 --> Model "Permissions_model" initialized
INFO - 2021-07-14 12:49:26 --> Model "Roles_model" initialized
INFO - 2021-07-14 12:49:26 --> Model "Activity_model" initialized
INFO - 2021-07-14 12:49:26 --> Model "Templates_model" initialized
INFO - 2021-07-14 12:49:26 --> Database Driver Class Initialized
INFO - 2021-07-14 12:49:26 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 12:49:26 --> Controller Class Initialized
ERROR - 2021-07-14 12:49:26 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 12:49:26 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-14 12:49:26 --> Final output sent to browser
DEBUG - 2021-07-14 12:49:26 --> Total execution time: 0.1400
INFO - 2021-07-14 12:50:44 --> Config Class Initialized
INFO - 2021-07-14 12:50:44 --> Hooks Class Initialized
DEBUG - 2021-07-14 12:50:44 --> UTF-8 Support Enabled
INFO - 2021-07-14 12:50:44 --> Utf8 Class Initialized
INFO - 2021-07-14 12:50:44 --> URI Class Initialized
DEBUG - 2021-07-14 12:50:44 --> No URI present. Default controller set.
INFO - 2021-07-14 12:50:44 --> Router Class Initialized
INFO - 2021-07-14 12:50:44 --> Output Class Initialized
INFO - 2021-07-14 12:50:44 --> Security Class Initialized
DEBUG - 2021-07-14 12:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 12:50:44 --> Input Class Initialized
INFO - 2021-07-14 12:50:44 --> Language Class Initialized
INFO - 2021-07-14 12:50:44 --> Loader Class Initialized
INFO - 2021-07-14 12:50:44 --> Helper loaded: basic_helper
INFO - 2021-07-14 12:50:44 --> Helper loaded: url_helper
INFO - 2021-07-14 12:50:44 --> Helper loaded: file_helper
INFO - 2021-07-14 12:50:44 --> Helper loaded: form_helper
INFO - 2021-07-14 12:50:44 --> Helper loaded: cookie_helper
INFO - 2021-07-14 12:50:44 --> Helper loaded: security_helper
INFO - 2021-07-14 12:50:44 --> Helper loaded: directory_helper
INFO - 2021-07-14 12:50:44 --> Helper loaded: language_helper
INFO - 2021-07-14 12:50:44 --> Helper loaded: general_helper
INFO - 2021-07-14 12:50:44 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 12:50:44 --> Database Driver Class Initialized
DEBUG - 2021-07-14 12:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 12:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 12:50:44 --> Parser Class Initialized
INFO - 2021-07-14 12:50:44 --> Form Validation Class Initialized
INFO - 2021-07-14 12:50:44 --> Upload Class Initialized
INFO - 2021-07-14 12:50:44 --> Email Class Initialized
INFO - 2021-07-14 12:50:44 --> MY_Model class loaded
INFO - 2021-07-14 12:50:44 --> Model "Users_model" initialized
INFO - 2021-07-14 12:50:44 --> Model "Settings_model" initialized
INFO - 2021-07-14 12:50:44 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 12:50:44 --> Model "Permissions_model" initialized
INFO - 2021-07-14 12:50:44 --> Model "Roles_model" initialized
INFO - 2021-07-14 12:50:44 --> Model "Activity_model" initialized
INFO - 2021-07-14 12:50:44 --> Model "Templates_model" initialized
INFO - 2021-07-14 12:50:44 --> Database Driver Class Initialized
INFO - 2021-07-14 12:50:44 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 12:50:44 --> Controller Class Initialized
ERROR - 2021-07-14 12:50:44 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 12:50:44 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-14 12:50:44 --> Final output sent to browser
DEBUG - 2021-07-14 12:50:44 --> Total execution time: 0.1391
INFO - 2021-07-14 12:50:47 --> Config Class Initialized
INFO - 2021-07-14 12:50:47 --> Hooks Class Initialized
DEBUG - 2021-07-14 12:50:47 --> UTF-8 Support Enabled
INFO - 2021-07-14 12:50:47 --> Utf8 Class Initialized
INFO - 2021-07-14 12:50:47 --> URI Class Initialized
INFO - 2021-07-14 12:50:47 --> Router Class Initialized
INFO - 2021-07-14 12:50:47 --> Output Class Initialized
INFO - 2021-07-14 12:50:47 --> Security Class Initialized
DEBUG - 2021-07-14 12:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 12:50:47 --> Input Class Initialized
INFO - 2021-07-14 12:50:47 --> Language Class Initialized
INFO - 2021-07-14 12:50:47 --> Loader Class Initialized
INFO - 2021-07-14 12:50:47 --> Helper loaded: basic_helper
INFO - 2021-07-14 12:50:47 --> Helper loaded: url_helper
INFO - 2021-07-14 12:50:47 --> Helper loaded: file_helper
INFO - 2021-07-14 12:50:47 --> Helper loaded: form_helper
INFO - 2021-07-14 12:50:47 --> Helper loaded: cookie_helper
INFO - 2021-07-14 12:50:47 --> Helper loaded: security_helper
INFO - 2021-07-14 12:50:47 --> Helper loaded: directory_helper
INFO - 2021-07-14 12:50:47 --> Helper loaded: language_helper
INFO - 2021-07-14 12:50:47 --> Helper loaded: general_helper
INFO - 2021-07-14 12:50:47 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 12:50:47 --> Database Driver Class Initialized
DEBUG - 2021-07-14 12:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 12:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 12:50:47 --> Parser Class Initialized
INFO - 2021-07-14 12:50:47 --> Form Validation Class Initialized
INFO - 2021-07-14 12:50:47 --> Upload Class Initialized
INFO - 2021-07-14 12:50:47 --> Email Class Initialized
INFO - 2021-07-14 12:50:47 --> MY_Model class loaded
INFO - 2021-07-14 12:50:47 --> Model "Users_model" initialized
INFO - 2021-07-14 12:50:47 --> Model "Settings_model" initialized
INFO - 2021-07-14 12:50:47 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 12:50:47 --> Model "Permissions_model" initialized
INFO - 2021-07-14 12:50:47 --> Model "Roles_model" initialized
INFO - 2021-07-14 12:50:47 --> Model "Activity_model" initialized
INFO - 2021-07-14 12:50:47 --> Model "Templates_model" initialized
INFO - 2021-07-14 12:50:47 --> Database Driver Class Initialized
INFO - 2021-07-14 12:50:47 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 12:50:47 --> Controller Class Initialized
ERROR - 2021-07-14 12:50:47 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 12:50:47 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-14 12:50:47 --> Final output sent to browser
DEBUG - 2021-07-14 12:50:47 --> Total execution time: 0.1548
INFO - 2021-07-14 12:50:54 --> Config Class Initialized
INFO - 2021-07-14 12:50:54 --> Hooks Class Initialized
DEBUG - 2021-07-14 12:50:54 --> UTF-8 Support Enabled
INFO - 2021-07-14 12:50:54 --> Utf8 Class Initialized
INFO - 2021-07-14 12:50:54 --> URI Class Initialized
INFO - 2021-07-14 12:50:54 --> Router Class Initialized
INFO - 2021-07-14 12:50:54 --> Output Class Initialized
INFO - 2021-07-14 12:50:54 --> Security Class Initialized
DEBUG - 2021-07-14 12:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 12:50:54 --> Input Class Initialized
INFO - 2021-07-14 12:50:54 --> Language Class Initialized
INFO - 2021-07-14 12:50:54 --> Loader Class Initialized
INFO - 2021-07-14 12:50:54 --> Helper loaded: basic_helper
INFO - 2021-07-14 12:50:54 --> Helper loaded: url_helper
INFO - 2021-07-14 12:50:54 --> Helper loaded: file_helper
INFO - 2021-07-14 12:50:54 --> Helper loaded: form_helper
INFO - 2021-07-14 12:50:54 --> Helper loaded: cookie_helper
INFO - 2021-07-14 12:50:54 --> Helper loaded: security_helper
INFO - 2021-07-14 12:50:54 --> Helper loaded: directory_helper
INFO - 2021-07-14 12:50:54 --> Helper loaded: language_helper
INFO - 2021-07-14 12:50:54 --> Helper loaded: general_helper
INFO - 2021-07-14 12:50:54 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 12:50:54 --> Database Driver Class Initialized
DEBUG - 2021-07-14 12:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 12:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 12:50:54 --> Parser Class Initialized
INFO - 2021-07-14 12:50:54 --> Form Validation Class Initialized
INFO - 2021-07-14 12:50:54 --> Upload Class Initialized
INFO - 2021-07-14 12:50:54 --> Email Class Initialized
INFO - 2021-07-14 12:50:54 --> MY_Model class loaded
INFO - 2021-07-14 12:50:54 --> Model "Users_model" initialized
INFO - 2021-07-14 12:50:54 --> Model "Settings_model" initialized
INFO - 2021-07-14 12:50:54 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 12:50:54 --> Model "Permissions_model" initialized
INFO - 2021-07-14 12:50:54 --> Model "Roles_model" initialized
INFO - 2021-07-14 12:50:54 --> Model "Activity_model" initialized
INFO - 2021-07-14 12:50:54 --> Model "Templates_model" initialized
INFO - 2021-07-14 12:50:54 --> Database Driver Class Initialized
INFO - 2021-07-14 12:50:54 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 12:50:54 --> Controller Class Initialized
ERROR - 2021-07-14 12:50:54 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 12:50:54 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-14 12:50:54 --> Final output sent to browser
DEBUG - 2021-07-14 12:50:54 --> Total execution time: 0.1472
INFO - 2021-07-14 12:57:40 --> Config Class Initialized
INFO - 2021-07-14 12:57:40 --> Hooks Class Initialized
DEBUG - 2021-07-14 12:57:40 --> UTF-8 Support Enabled
INFO - 2021-07-14 12:57:40 --> Utf8 Class Initialized
INFO - 2021-07-14 12:57:40 --> URI Class Initialized
DEBUG - 2021-07-14 12:57:40 --> No URI present. Default controller set.
INFO - 2021-07-14 12:57:40 --> Router Class Initialized
INFO - 2021-07-14 12:57:40 --> Output Class Initialized
INFO - 2021-07-14 12:57:40 --> Security Class Initialized
DEBUG - 2021-07-14 12:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 12:57:40 --> Input Class Initialized
INFO - 2021-07-14 12:57:40 --> Language Class Initialized
INFO - 2021-07-14 12:57:40 --> Loader Class Initialized
INFO - 2021-07-14 12:57:40 --> Helper loaded: basic_helper
INFO - 2021-07-14 12:57:40 --> Helper loaded: url_helper
INFO - 2021-07-14 12:57:40 --> Helper loaded: file_helper
INFO - 2021-07-14 12:57:40 --> Helper loaded: form_helper
INFO - 2021-07-14 12:57:40 --> Helper loaded: cookie_helper
INFO - 2021-07-14 12:57:40 --> Helper loaded: security_helper
INFO - 2021-07-14 12:57:40 --> Helper loaded: directory_helper
INFO - 2021-07-14 12:57:40 --> Helper loaded: language_helper
INFO - 2021-07-14 12:57:40 --> Helper loaded: general_helper
INFO - 2021-07-14 12:57:40 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 12:57:40 --> Database Driver Class Initialized
DEBUG - 2021-07-14 12:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 12:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 12:57:40 --> Parser Class Initialized
INFO - 2021-07-14 12:57:40 --> Form Validation Class Initialized
INFO - 2021-07-14 12:57:40 --> Upload Class Initialized
INFO - 2021-07-14 12:57:40 --> Email Class Initialized
INFO - 2021-07-14 12:57:40 --> MY_Model class loaded
INFO - 2021-07-14 12:57:40 --> Model "Users_model" initialized
INFO - 2021-07-14 12:57:40 --> Model "Settings_model" initialized
INFO - 2021-07-14 12:57:40 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 12:57:40 --> Model "Permissions_model" initialized
INFO - 2021-07-14 12:57:40 --> Model "Roles_model" initialized
INFO - 2021-07-14 12:57:40 --> Model "Activity_model" initialized
INFO - 2021-07-14 12:57:40 --> Model "Templates_model" initialized
INFO - 2021-07-14 12:57:40 --> Database Driver Class Initialized
INFO - 2021-07-14 12:57:40 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 12:57:40 --> Controller Class Initialized
INFO - 2021-07-14 12:58:17 --> Config Class Initialized
INFO - 2021-07-14 12:58:17 --> Hooks Class Initialized
DEBUG - 2021-07-14 12:58:17 --> UTF-8 Support Enabled
INFO - 2021-07-14 12:58:17 --> Utf8 Class Initialized
INFO - 2021-07-14 12:58:17 --> URI Class Initialized
INFO - 2021-07-14 12:58:17 --> Router Class Initialized
INFO - 2021-07-14 12:58:17 --> Output Class Initialized
INFO - 2021-07-14 12:58:17 --> Security Class Initialized
DEBUG - 2021-07-14 12:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 12:58:17 --> Input Class Initialized
INFO - 2021-07-14 12:58:17 --> Language Class Initialized
INFO - 2021-07-14 12:58:17 --> Loader Class Initialized
INFO - 2021-07-14 12:58:17 --> Helper loaded: basic_helper
INFO - 2021-07-14 12:58:17 --> Helper loaded: url_helper
INFO - 2021-07-14 12:58:17 --> Helper loaded: file_helper
INFO - 2021-07-14 12:58:17 --> Helper loaded: form_helper
INFO - 2021-07-14 12:58:17 --> Helper loaded: cookie_helper
INFO - 2021-07-14 12:58:17 --> Helper loaded: security_helper
INFO - 2021-07-14 12:58:17 --> Helper loaded: directory_helper
INFO - 2021-07-14 12:58:17 --> Helper loaded: language_helper
INFO - 2021-07-14 12:58:17 --> Helper loaded: general_helper
INFO - 2021-07-14 12:58:17 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 12:58:17 --> Database Driver Class Initialized
DEBUG - 2021-07-14 12:58:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 12:58:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 12:58:17 --> Parser Class Initialized
INFO - 2021-07-14 12:58:17 --> Form Validation Class Initialized
INFO - 2021-07-14 12:58:17 --> Upload Class Initialized
INFO - 2021-07-14 12:58:17 --> Email Class Initialized
INFO - 2021-07-14 12:58:17 --> MY_Model class loaded
INFO - 2021-07-14 12:58:17 --> Model "Users_model" initialized
INFO - 2021-07-14 12:58:17 --> Model "Settings_model" initialized
INFO - 2021-07-14 12:58:17 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 12:58:17 --> Model "Permissions_model" initialized
INFO - 2021-07-14 12:58:17 --> Model "Roles_model" initialized
INFO - 2021-07-14 12:58:17 --> Model "Activity_model" initialized
INFO - 2021-07-14 12:58:17 --> Model "Templates_model" initialized
INFO - 2021-07-14 12:58:17 --> Database Driver Class Initialized
INFO - 2021-07-14 12:58:17 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 12:58:17 --> Controller Class Initialized
INFO - 2021-07-14 12:58:17 --> Config Class Initialized
INFO - 2021-07-14 12:58:17 --> Hooks Class Initialized
DEBUG - 2021-07-14 12:58:17 --> UTF-8 Support Enabled
INFO - 2021-07-14 12:58:17 --> Utf8 Class Initialized
INFO - 2021-07-14 12:58:17 --> URI Class Initialized
INFO - 2021-07-14 12:58:17 --> Router Class Initialized
INFO - 2021-07-14 12:58:17 --> Output Class Initialized
INFO - 2021-07-14 12:58:17 --> Security Class Initialized
DEBUG - 2021-07-14 12:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 12:58:17 --> Config Class Initialized
INFO - 2021-07-14 12:58:17 --> Input Class Initialized
INFO - 2021-07-14 12:58:17 --> Hooks Class Initialized
INFO - 2021-07-14 12:58:17 --> Language Class Initialized
DEBUG - 2021-07-14 12:58:17 --> UTF-8 Support Enabled
INFO - 2021-07-14 12:58:17 --> Utf8 Class Initialized
ERROR - 2021-07-14 12:58:17 --> 404 Page Not Found: Faviconico/index
INFO - 2021-07-14 12:58:17 --> URI Class Initialized
INFO - 2021-07-14 12:58:17 --> Router Class Initialized
INFO - 2021-07-14 12:58:17 --> Output Class Initialized
INFO - 2021-07-14 12:58:17 --> Security Class Initialized
DEBUG - 2021-07-14 12:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 12:58:17 --> Input Class Initialized
INFO - 2021-07-14 12:58:17 --> Language Class Initialized
INFO - 2021-07-14 12:58:17 --> Loader Class Initialized
INFO - 2021-07-14 12:58:17 --> Helper loaded: basic_helper
INFO - 2021-07-14 12:58:17 --> Helper loaded: url_helper
INFO - 2021-07-14 12:58:17 --> Helper loaded: file_helper
INFO - 2021-07-14 12:58:17 --> Helper loaded: form_helper
INFO - 2021-07-14 12:58:17 --> Helper loaded: cookie_helper
INFO - 2021-07-14 12:58:17 --> Helper loaded: security_helper
INFO - 2021-07-14 12:58:17 --> Helper loaded: directory_helper
INFO - 2021-07-14 12:58:17 --> Helper loaded: language_helper
INFO - 2021-07-14 12:58:17 --> Helper loaded: general_helper
INFO - 2021-07-14 12:58:17 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 12:58:17 --> Database Driver Class Initialized
DEBUG - 2021-07-14 12:58:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 12:58:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 12:58:17 --> Parser Class Initialized
INFO - 2021-07-14 12:58:17 --> Form Validation Class Initialized
INFO - 2021-07-14 12:58:17 --> Upload Class Initialized
INFO - 2021-07-14 12:58:17 --> Email Class Initialized
INFO - 2021-07-14 12:58:17 --> MY_Model class loaded
INFO - 2021-07-14 12:58:17 --> Model "Users_model" initialized
INFO - 2021-07-14 12:58:17 --> Model "Settings_model" initialized
INFO - 2021-07-14 12:58:17 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 12:58:17 --> Model "Permissions_model" initialized
INFO - 2021-07-14 12:58:17 --> Model "Roles_model" initialized
INFO - 2021-07-14 12:58:17 --> Model "Activity_model" initialized
INFO - 2021-07-14 12:58:17 --> Model "Templates_model" initialized
INFO - 2021-07-14 12:58:17 --> Database Driver Class Initialized
INFO - 2021-07-14 12:58:17 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 12:58:17 --> Controller Class Initialized
INFO - 2021-07-14 12:58:17 --> File loaded: C:\wamp64\www\crm\application\views\account/login.php
INFO - 2021-07-14 12:58:17 --> Final output sent to browser
DEBUG - 2021-07-14 12:58:17 --> Total execution time: 0.0550
INFO - 2021-07-14 12:58:17 --> Config Class Initialized
INFO - 2021-07-14 12:58:17 --> Hooks Class Initialized
DEBUG - 2021-07-14 12:58:17 --> UTF-8 Support Enabled
INFO - 2021-07-14 12:58:17 --> Utf8 Class Initialized
INFO - 2021-07-14 12:58:17 --> URI Class Initialized
INFO - 2021-07-14 12:58:17 --> Router Class Initialized
INFO - 2021-07-14 12:58:17 --> Output Class Initialized
INFO - 2021-07-14 12:58:17 --> Security Class Initialized
DEBUG - 2021-07-14 12:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 12:58:17 --> Input Class Initialized
INFO - 2021-07-14 12:58:17 --> Language Class Initialized
ERROR - 2021-07-14 12:58:17 --> 404 Page Not Found: Assets/jquery
INFO - 2021-07-14 12:58:17 --> Config Class Initialized
INFO - 2021-07-14 12:58:17 --> Hooks Class Initialized
DEBUG - 2021-07-14 12:58:17 --> UTF-8 Support Enabled
INFO - 2021-07-14 12:58:17 --> Utf8 Class Initialized
INFO - 2021-07-14 12:58:17 --> URI Class Initialized
INFO - 2021-07-14 12:58:17 --> Router Class Initialized
INFO - 2021-07-14 12:58:17 --> Output Class Initialized
INFO - 2021-07-14 12:58:17 --> Security Class Initialized
DEBUG - 2021-07-14 12:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 12:58:17 --> Input Class Initialized
INFO - 2021-07-14 12:58:17 --> Language Class Initialized
ERROR - 2021-07-14 12:58:17 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-14 12:58:18 --> Config Class Initialized
INFO - 2021-07-14 12:58:18 --> Hooks Class Initialized
DEBUG - 2021-07-14 12:58:18 --> UTF-8 Support Enabled
INFO - 2021-07-14 12:58:18 --> Utf8 Class Initialized
INFO - 2021-07-14 12:58:18 --> URI Class Initialized
INFO - 2021-07-14 12:58:18 --> Router Class Initialized
INFO - 2021-07-14 12:58:18 --> Output Class Initialized
INFO - 2021-07-14 12:58:18 --> Security Class Initialized
DEBUG - 2021-07-14 12:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 12:58:18 --> Input Class Initialized
INFO - 2021-07-14 12:58:18 --> Language Class Initialized
INFO - 2021-07-14 12:58:18 --> Loader Class Initialized
INFO - 2021-07-14 12:58:18 --> Helper loaded: basic_helper
INFO - 2021-07-14 12:58:18 --> Helper loaded: url_helper
INFO - 2021-07-14 12:58:18 --> Helper loaded: file_helper
INFO - 2021-07-14 12:58:18 --> Helper loaded: form_helper
INFO - 2021-07-14 12:58:18 --> Helper loaded: cookie_helper
INFO - 2021-07-14 12:58:18 --> Helper loaded: security_helper
INFO - 2021-07-14 12:58:18 --> Helper loaded: directory_helper
INFO - 2021-07-14 12:58:18 --> Helper loaded: language_helper
INFO - 2021-07-14 12:58:18 --> Helper loaded: general_helper
INFO - 2021-07-14 12:58:18 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 12:58:18 --> Database Driver Class Initialized
DEBUG - 2021-07-14 12:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 12:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 12:58:18 --> Parser Class Initialized
INFO - 2021-07-14 12:58:18 --> Form Validation Class Initialized
INFO - 2021-07-14 12:58:18 --> Upload Class Initialized
INFO - 2021-07-14 12:58:18 --> Email Class Initialized
INFO - 2021-07-14 12:58:18 --> MY_Model class loaded
INFO - 2021-07-14 12:58:18 --> Model "Users_model" initialized
INFO - 2021-07-14 12:58:18 --> Model "Settings_model" initialized
INFO - 2021-07-14 12:58:18 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 12:58:18 --> Model "Permissions_model" initialized
INFO - 2021-07-14 12:58:18 --> Model "Roles_model" initialized
INFO - 2021-07-14 12:58:18 --> Model "Activity_model" initialized
INFO - 2021-07-14 12:58:18 --> Model "Templates_model" initialized
INFO - 2021-07-14 12:58:18 --> Database Driver Class Initialized
INFO - 2021-07-14 12:58:18 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 12:58:18 --> Controller Class Initialized
DEBUG - 2021-07-14 12:58:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-14 12:58:18 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2021-07-14 12:58:18 --> Config Class Initialized
INFO - 2021-07-14 12:58:18 --> Hooks Class Initialized
DEBUG - 2021-07-14 12:58:18 --> UTF-8 Support Enabled
INFO - 2021-07-14 12:58:18 --> Utf8 Class Initialized
INFO - 2021-07-14 12:58:18 --> URI Class Initialized
DEBUG - 2021-07-14 12:58:18 --> No URI present. Default controller set.
INFO - 2021-07-14 12:58:18 --> Router Class Initialized
INFO - 2021-07-14 12:58:18 --> Output Class Initialized
INFO - 2021-07-14 12:58:18 --> Security Class Initialized
DEBUG - 2021-07-14 12:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 12:58:18 --> Input Class Initialized
INFO - 2021-07-14 12:58:18 --> Language Class Initialized
INFO - 2021-07-14 12:58:18 --> Loader Class Initialized
INFO - 2021-07-14 12:58:18 --> Helper loaded: basic_helper
INFO - 2021-07-14 12:58:18 --> Helper loaded: url_helper
INFO - 2021-07-14 12:58:18 --> Helper loaded: file_helper
INFO - 2021-07-14 12:58:18 --> Helper loaded: form_helper
INFO - 2021-07-14 12:58:18 --> Helper loaded: cookie_helper
INFO - 2021-07-14 12:58:18 --> Helper loaded: security_helper
INFO - 2021-07-14 12:58:18 --> Helper loaded: directory_helper
INFO - 2021-07-14 12:58:18 --> Helper loaded: language_helper
INFO - 2021-07-14 12:58:18 --> Helper loaded: general_helper
INFO - 2021-07-14 12:58:18 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 12:58:18 --> Database Driver Class Initialized
DEBUG - 2021-07-14 12:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 12:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 12:58:18 --> Parser Class Initialized
INFO - 2021-07-14 12:58:18 --> Form Validation Class Initialized
INFO - 2021-07-14 12:58:18 --> Upload Class Initialized
INFO - 2021-07-14 12:58:18 --> Email Class Initialized
INFO - 2021-07-14 12:58:18 --> MY_Model class loaded
INFO - 2021-07-14 12:58:18 --> Model "Users_model" initialized
INFO - 2021-07-14 12:58:18 --> Model "Settings_model" initialized
INFO - 2021-07-14 12:58:18 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 12:58:18 --> Model "Permissions_model" initialized
INFO - 2021-07-14 12:58:18 --> Model "Roles_model" initialized
INFO - 2021-07-14 12:58:18 --> Model "Activity_model" initialized
INFO - 2021-07-14 12:58:18 --> Model "Templates_model" initialized
INFO - 2021-07-14 12:58:18 --> Database Driver Class Initialized
INFO - 2021-07-14 12:58:18 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 12:58:18 --> Controller Class Initialized
ERROR - 2021-07-14 12:58:18 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 12:58:18 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-14 12:58:18 --> Final output sent to browser
DEBUG - 2021-07-14 12:58:18 --> Total execution time: 0.0604
INFO - 2021-07-14 12:58:21 --> Config Class Initialized
INFO - 2021-07-14 12:58:21 --> Hooks Class Initialized
DEBUG - 2021-07-14 12:58:21 --> UTF-8 Support Enabled
INFO - 2021-07-14 12:58:21 --> Utf8 Class Initialized
INFO - 2021-07-14 12:58:21 --> URI Class Initialized
INFO - 2021-07-14 12:58:21 --> Router Class Initialized
INFO - 2021-07-14 12:58:21 --> Output Class Initialized
INFO - 2021-07-14 12:58:21 --> Security Class Initialized
DEBUG - 2021-07-14 12:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 12:58:21 --> Input Class Initialized
INFO - 2021-07-14 12:58:21 --> Language Class Initialized
INFO - 2021-07-14 12:58:21 --> Loader Class Initialized
INFO - 2021-07-14 12:58:21 --> Helper loaded: basic_helper
INFO - 2021-07-14 12:58:21 --> Helper loaded: url_helper
INFO - 2021-07-14 12:58:21 --> Helper loaded: file_helper
INFO - 2021-07-14 12:58:21 --> Helper loaded: form_helper
INFO - 2021-07-14 12:58:21 --> Helper loaded: cookie_helper
INFO - 2021-07-14 12:58:21 --> Helper loaded: security_helper
INFO - 2021-07-14 12:58:21 --> Helper loaded: directory_helper
INFO - 2021-07-14 12:58:21 --> Helper loaded: language_helper
INFO - 2021-07-14 12:58:21 --> Helper loaded: general_helper
INFO - 2021-07-14 12:58:21 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 12:58:21 --> Database Driver Class Initialized
DEBUG - 2021-07-14 12:58:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 12:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 12:58:21 --> Parser Class Initialized
INFO - 2021-07-14 12:58:21 --> Form Validation Class Initialized
INFO - 2021-07-14 12:58:21 --> Upload Class Initialized
INFO - 2021-07-14 12:58:21 --> Email Class Initialized
INFO - 2021-07-14 12:58:21 --> MY_Model class loaded
INFO - 2021-07-14 12:58:21 --> Model "Users_model" initialized
INFO - 2021-07-14 12:58:21 --> Model "Settings_model" initialized
INFO - 2021-07-14 12:58:21 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 12:58:21 --> Model "Permissions_model" initialized
INFO - 2021-07-14 12:58:21 --> Model "Roles_model" initialized
INFO - 2021-07-14 12:58:21 --> Model "Activity_model" initialized
INFO - 2021-07-14 12:58:21 --> Model "Templates_model" initialized
INFO - 2021-07-14 12:58:21 --> Database Driver Class Initialized
INFO - 2021-07-14 12:58:21 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 12:58:21 --> Controller Class Initialized
ERROR - 2021-07-14 12:58:21 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 12:58:21 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-14 12:58:21 --> Final output sent to browser
DEBUG - 2021-07-14 12:58:21 --> Total execution time: 0.0725
INFO - 2021-07-14 12:58:38 --> Config Class Initialized
INFO - 2021-07-14 12:58:38 --> Hooks Class Initialized
DEBUG - 2021-07-14 12:58:38 --> UTF-8 Support Enabled
INFO - 2021-07-14 12:58:38 --> Utf8 Class Initialized
INFO - 2021-07-14 12:58:38 --> URI Class Initialized
INFO - 2021-07-14 12:58:38 --> Router Class Initialized
INFO - 2021-07-14 12:58:38 --> Output Class Initialized
INFO - 2021-07-14 12:58:38 --> Security Class Initialized
DEBUG - 2021-07-14 12:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 12:58:38 --> Input Class Initialized
INFO - 2021-07-14 12:58:38 --> Language Class Initialized
INFO - 2021-07-14 12:58:38 --> Loader Class Initialized
INFO - 2021-07-14 12:58:38 --> Helper loaded: basic_helper
INFO - 2021-07-14 12:58:38 --> Helper loaded: url_helper
INFO - 2021-07-14 12:58:38 --> Helper loaded: file_helper
INFO - 2021-07-14 12:58:38 --> Helper loaded: form_helper
INFO - 2021-07-14 12:58:38 --> Helper loaded: cookie_helper
INFO - 2021-07-14 12:58:38 --> Helper loaded: security_helper
INFO - 2021-07-14 12:58:38 --> Helper loaded: directory_helper
INFO - 2021-07-14 12:58:38 --> Helper loaded: language_helper
INFO - 2021-07-14 12:58:38 --> Helper loaded: general_helper
INFO - 2021-07-14 12:58:38 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 12:58:38 --> Database Driver Class Initialized
DEBUG - 2021-07-14 12:58:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 12:58:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 12:58:38 --> Parser Class Initialized
INFO - 2021-07-14 12:58:38 --> Form Validation Class Initialized
INFO - 2021-07-14 12:58:38 --> Upload Class Initialized
INFO - 2021-07-14 12:58:38 --> Email Class Initialized
INFO - 2021-07-14 12:58:38 --> MY_Model class loaded
INFO - 2021-07-14 12:58:38 --> Model "Users_model" initialized
INFO - 2021-07-14 12:58:38 --> Model "Settings_model" initialized
INFO - 2021-07-14 12:58:38 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 12:58:38 --> Model "Permissions_model" initialized
INFO - 2021-07-14 12:58:38 --> Model "Roles_model" initialized
INFO - 2021-07-14 12:58:38 --> Model "Activity_model" initialized
INFO - 2021-07-14 12:58:38 --> Model "Templates_model" initialized
INFO - 2021-07-14 12:58:38 --> Database Driver Class Initialized
INFO - 2021-07-14 12:58:38 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 12:58:38 --> Controller Class Initialized
ERROR - 2021-07-14 12:58:38 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 12:58:38 --> File loaded: C:\wamp64\www\crm\application\views\blank_page.php
INFO - 2021-07-14 12:58:38 --> Final output sent to browser
DEBUG - 2021-07-14 12:58:38 --> Total execution time: 0.1351
INFO - 2021-07-14 12:58:43 --> Config Class Initialized
INFO - 2021-07-14 12:58:43 --> Hooks Class Initialized
DEBUG - 2021-07-14 12:58:43 --> UTF-8 Support Enabled
INFO - 2021-07-14 12:58:43 --> Utf8 Class Initialized
INFO - 2021-07-14 12:58:43 --> URI Class Initialized
INFO - 2021-07-14 12:58:43 --> Router Class Initialized
INFO - 2021-07-14 12:58:43 --> Output Class Initialized
INFO - 2021-07-14 12:58:43 --> Security Class Initialized
DEBUG - 2021-07-14 12:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 12:58:43 --> Input Class Initialized
INFO - 2021-07-14 12:58:43 --> Language Class Initialized
INFO - 2021-07-14 12:58:43 --> Loader Class Initialized
INFO - 2021-07-14 12:58:43 --> Helper loaded: basic_helper
INFO - 2021-07-14 12:58:43 --> Helper loaded: url_helper
INFO - 2021-07-14 12:58:43 --> Helper loaded: file_helper
INFO - 2021-07-14 12:58:43 --> Helper loaded: form_helper
INFO - 2021-07-14 12:58:43 --> Helper loaded: cookie_helper
INFO - 2021-07-14 12:58:43 --> Helper loaded: security_helper
INFO - 2021-07-14 12:58:43 --> Helper loaded: directory_helper
INFO - 2021-07-14 12:58:43 --> Helper loaded: language_helper
INFO - 2021-07-14 12:58:43 --> Helper loaded: general_helper
INFO - 2021-07-14 12:58:43 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 12:58:43 --> Database Driver Class Initialized
DEBUG - 2021-07-14 12:58:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 12:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 12:58:43 --> Parser Class Initialized
INFO - 2021-07-14 12:58:43 --> Form Validation Class Initialized
INFO - 2021-07-14 12:58:43 --> Upload Class Initialized
INFO - 2021-07-14 12:58:43 --> Email Class Initialized
INFO - 2021-07-14 12:58:43 --> MY_Model class loaded
INFO - 2021-07-14 12:58:43 --> Model "Users_model" initialized
INFO - 2021-07-14 12:58:43 --> Model "Settings_model" initialized
INFO - 2021-07-14 12:58:43 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 12:58:43 --> Model "Permissions_model" initialized
INFO - 2021-07-14 12:58:43 --> Model "Roles_model" initialized
INFO - 2021-07-14 12:58:43 --> Model "Activity_model" initialized
INFO - 2021-07-14 12:58:43 --> Model "Templates_model" initialized
INFO - 2021-07-14 12:58:43 --> Database Driver Class Initialized
INFO - 2021-07-14 12:58:43 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 12:58:43 --> Controller Class Initialized
ERROR - 2021-07-14 12:58:43 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 12:58:43 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-14 12:58:43 --> Final output sent to browser
DEBUG - 2021-07-14 12:58:43 --> Total execution time: 0.1356
INFO - 2021-07-14 13:34:30 --> Config Class Initialized
INFO - 2021-07-14 13:34:30 --> Hooks Class Initialized
DEBUG - 2021-07-14 13:34:30 --> UTF-8 Support Enabled
INFO - 2021-07-14 13:34:30 --> Utf8 Class Initialized
INFO - 2021-07-14 13:34:30 --> URI Class Initialized
INFO - 2021-07-14 13:34:30 --> Router Class Initialized
INFO - 2021-07-14 13:34:30 --> Output Class Initialized
INFO - 2021-07-14 13:34:30 --> Security Class Initialized
DEBUG - 2021-07-14 13:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 13:34:30 --> Input Class Initialized
INFO - 2021-07-14 13:34:30 --> Language Class Initialized
INFO - 2021-07-14 13:34:30 --> Loader Class Initialized
INFO - 2021-07-14 13:34:30 --> Helper loaded: basic_helper
INFO - 2021-07-14 13:34:30 --> Helper loaded: url_helper
INFO - 2021-07-14 13:34:30 --> Helper loaded: file_helper
INFO - 2021-07-14 13:34:30 --> Helper loaded: form_helper
INFO - 2021-07-14 13:34:30 --> Helper loaded: cookie_helper
INFO - 2021-07-14 13:34:30 --> Helper loaded: security_helper
INFO - 2021-07-14 13:34:30 --> Helper loaded: directory_helper
INFO - 2021-07-14 13:34:30 --> Helper loaded: language_helper
INFO - 2021-07-14 13:34:30 --> Helper loaded: general_helper
INFO - 2021-07-14 13:34:30 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 13:34:30 --> Database Driver Class Initialized
DEBUG - 2021-07-14 13:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 13:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 13:34:30 --> Parser Class Initialized
INFO - 2021-07-14 13:34:30 --> Form Validation Class Initialized
INFO - 2021-07-14 13:34:30 --> Upload Class Initialized
INFO - 2021-07-14 13:34:30 --> Email Class Initialized
INFO - 2021-07-14 13:34:30 --> MY_Model class loaded
INFO - 2021-07-14 13:34:30 --> Model "Users_model" initialized
INFO - 2021-07-14 13:34:30 --> Model "Settings_model" initialized
INFO - 2021-07-14 13:34:30 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 13:34:30 --> Model "Permissions_model" initialized
INFO - 2021-07-14 13:34:30 --> Model "Roles_model" initialized
INFO - 2021-07-14 13:34:30 --> Model "Activity_model" initialized
INFO - 2021-07-14 13:34:30 --> Model "Templates_model" initialized
INFO - 2021-07-14 13:34:30 --> Database Driver Class Initialized
INFO - 2021-07-14 13:34:30 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 13:34:30 --> Controller Class Initialized
ERROR - 2021-07-14 13:34:30 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 13:34:30 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-14 13:34:30 --> Final output sent to browser
DEBUG - 2021-07-14 13:34:30 --> Total execution time: 0.1496
INFO - 2021-07-14 13:34:31 --> Config Class Initialized
INFO - 2021-07-14 13:34:31 --> Hooks Class Initialized
DEBUG - 2021-07-14 13:34:31 --> UTF-8 Support Enabled
INFO - 2021-07-14 13:34:31 --> Utf8 Class Initialized
INFO - 2021-07-14 13:34:31 --> URI Class Initialized
INFO - 2021-07-14 13:34:31 --> Router Class Initialized
INFO - 2021-07-14 13:34:31 --> Output Class Initialized
INFO - 2021-07-14 13:34:31 --> Security Class Initialized
DEBUG - 2021-07-14 13:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 13:34:31 --> Input Class Initialized
INFO - 2021-07-14 13:34:31 --> Language Class Initialized
ERROR - 2021-07-14 13:34:31 --> 404 Page Not Found: Faviconico/index
INFO - 2021-07-14 13:34:49 --> Config Class Initialized
INFO - 2021-07-14 13:34:49 --> Hooks Class Initialized
DEBUG - 2021-07-14 13:34:49 --> UTF-8 Support Enabled
INFO - 2021-07-14 13:34:49 --> Utf8 Class Initialized
INFO - 2021-07-14 13:34:49 --> URI Class Initialized
INFO - 2021-07-14 13:34:49 --> Router Class Initialized
INFO - 2021-07-14 13:34:49 --> Output Class Initialized
INFO - 2021-07-14 13:34:49 --> Security Class Initialized
DEBUG - 2021-07-14 13:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 13:34:49 --> Input Class Initialized
INFO - 2021-07-14 13:34:49 --> Language Class Initialized
INFO - 2021-07-14 13:34:49 --> Loader Class Initialized
INFO - 2021-07-14 13:34:49 --> Helper loaded: basic_helper
INFO - 2021-07-14 13:34:49 --> Helper loaded: url_helper
INFO - 2021-07-14 13:34:49 --> Helper loaded: file_helper
INFO - 2021-07-14 13:34:49 --> Helper loaded: form_helper
INFO - 2021-07-14 13:34:49 --> Helper loaded: cookie_helper
INFO - 2021-07-14 13:34:49 --> Helper loaded: security_helper
INFO - 2021-07-14 13:34:49 --> Helper loaded: directory_helper
INFO - 2021-07-14 13:34:49 --> Helper loaded: language_helper
INFO - 2021-07-14 13:34:49 --> Helper loaded: general_helper
INFO - 2021-07-14 13:34:49 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 13:34:49 --> Database Driver Class Initialized
DEBUG - 2021-07-14 13:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 13:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 13:34:49 --> Parser Class Initialized
INFO - 2021-07-14 13:34:49 --> Form Validation Class Initialized
INFO - 2021-07-14 13:34:49 --> Upload Class Initialized
INFO - 2021-07-14 13:34:49 --> Email Class Initialized
INFO - 2021-07-14 13:34:49 --> MY_Model class loaded
INFO - 2021-07-14 13:34:49 --> Model "Users_model" initialized
INFO - 2021-07-14 13:34:49 --> Model "Settings_model" initialized
INFO - 2021-07-14 13:34:49 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 13:34:49 --> Model "Permissions_model" initialized
INFO - 2021-07-14 13:34:49 --> Model "Roles_model" initialized
INFO - 2021-07-14 13:34:49 --> Model "Activity_model" initialized
INFO - 2021-07-14 13:34:49 --> Model "Templates_model" initialized
INFO - 2021-07-14 13:34:49 --> Database Driver Class Initialized
INFO - 2021-07-14 13:34:49 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 13:34:49 --> Controller Class Initialized
ERROR - 2021-07-14 13:34:49 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 13:34:49 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-14 13:34:49 --> Final output sent to browser
DEBUG - 2021-07-14 13:34:49 --> Total execution time: 0.1424
INFO - 2021-07-14 13:44:46 --> Config Class Initialized
INFO - 2021-07-14 13:44:46 --> Hooks Class Initialized
DEBUG - 2021-07-14 13:44:46 --> UTF-8 Support Enabled
INFO - 2021-07-14 13:44:46 --> Utf8 Class Initialized
INFO - 2021-07-14 13:44:46 --> URI Class Initialized
INFO - 2021-07-14 13:44:46 --> Router Class Initialized
INFO - 2021-07-14 13:44:46 --> Output Class Initialized
INFO - 2021-07-14 13:44:46 --> Security Class Initialized
DEBUG - 2021-07-14 13:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 13:44:46 --> Input Class Initialized
INFO - 2021-07-14 13:44:46 --> Language Class Initialized
INFO - 2021-07-14 13:44:46 --> Loader Class Initialized
INFO - 2021-07-14 13:44:46 --> Helper loaded: basic_helper
INFO - 2021-07-14 13:44:46 --> Helper loaded: url_helper
INFO - 2021-07-14 13:44:46 --> Helper loaded: file_helper
INFO - 2021-07-14 13:44:46 --> Helper loaded: form_helper
INFO - 2021-07-14 13:44:46 --> Helper loaded: cookie_helper
INFO - 2021-07-14 13:44:46 --> Helper loaded: security_helper
INFO - 2021-07-14 13:44:46 --> Helper loaded: directory_helper
INFO - 2021-07-14 13:44:46 --> Helper loaded: language_helper
INFO - 2021-07-14 13:44:46 --> Helper loaded: general_helper
INFO - 2021-07-14 13:44:46 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 13:44:46 --> Database Driver Class Initialized
DEBUG - 2021-07-14 13:44:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 13:44:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 13:44:47 --> Parser Class Initialized
INFO - 2021-07-14 13:44:47 --> Form Validation Class Initialized
INFO - 2021-07-14 13:44:47 --> Upload Class Initialized
INFO - 2021-07-14 13:44:47 --> Email Class Initialized
INFO - 2021-07-14 13:44:47 --> MY_Model class loaded
INFO - 2021-07-14 13:44:47 --> Model "Users_model" initialized
INFO - 2021-07-14 13:44:47 --> Model "Settings_model" initialized
INFO - 2021-07-14 13:44:47 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 13:44:47 --> Model "Permissions_model" initialized
INFO - 2021-07-14 13:44:47 --> Model "Roles_model" initialized
INFO - 2021-07-14 13:44:47 --> Model "Activity_model" initialized
INFO - 2021-07-14 13:44:47 --> Model "Templates_model" initialized
INFO - 2021-07-14 13:44:47 --> Database Driver Class Initialized
INFO - 2021-07-14 13:44:47 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 13:44:47 --> Controller Class Initialized
ERROR - 2021-07-14 13:44:47 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 13:44:47 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-14 13:44:47 --> Final output sent to browser
DEBUG - 2021-07-14 13:44:47 --> Total execution time: 0.1560
INFO - 2021-07-14 13:45:38 --> Config Class Initialized
INFO - 2021-07-14 13:45:38 --> Hooks Class Initialized
DEBUG - 2021-07-14 13:45:38 --> UTF-8 Support Enabled
INFO - 2021-07-14 13:45:38 --> Utf8 Class Initialized
INFO - 2021-07-14 13:45:38 --> URI Class Initialized
INFO - 2021-07-14 13:45:38 --> Router Class Initialized
INFO - 2021-07-14 13:45:38 --> Output Class Initialized
INFO - 2021-07-14 13:45:38 --> Security Class Initialized
DEBUG - 2021-07-14 13:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 13:45:38 --> Input Class Initialized
INFO - 2021-07-14 13:45:38 --> Language Class Initialized
INFO - 2021-07-14 13:45:38 --> Loader Class Initialized
INFO - 2021-07-14 13:45:38 --> Helper loaded: basic_helper
INFO - 2021-07-14 13:45:38 --> Helper loaded: url_helper
INFO - 2021-07-14 13:45:38 --> Helper loaded: file_helper
INFO - 2021-07-14 13:45:38 --> Helper loaded: form_helper
INFO - 2021-07-14 13:45:38 --> Helper loaded: cookie_helper
INFO - 2021-07-14 13:45:38 --> Helper loaded: security_helper
INFO - 2021-07-14 13:45:38 --> Helper loaded: directory_helper
INFO - 2021-07-14 13:45:38 --> Helper loaded: language_helper
INFO - 2021-07-14 13:45:38 --> Helper loaded: general_helper
INFO - 2021-07-14 13:45:38 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 13:45:38 --> Database Driver Class Initialized
DEBUG - 2021-07-14 13:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 13:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 13:45:38 --> Parser Class Initialized
INFO - 2021-07-14 13:45:38 --> Form Validation Class Initialized
INFO - 2021-07-14 13:45:38 --> Upload Class Initialized
INFO - 2021-07-14 13:45:38 --> Email Class Initialized
INFO - 2021-07-14 13:45:38 --> MY_Model class loaded
INFO - 2021-07-14 13:45:38 --> Model "Users_model" initialized
INFO - 2021-07-14 13:45:38 --> Model "Settings_model" initialized
INFO - 2021-07-14 13:45:38 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 13:45:38 --> Model "Permissions_model" initialized
INFO - 2021-07-14 13:45:38 --> Model "Roles_model" initialized
INFO - 2021-07-14 13:45:38 --> Model "Activity_model" initialized
INFO - 2021-07-14 13:45:38 --> Model "Templates_model" initialized
INFO - 2021-07-14 13:45:38 --> Database Driver Class Initialized
INFO - 2021-07-14 13:45:38 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 13:45:38 --> Controller Class Initialized
ERROR - 2021-07-14 13:45:38 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 13:45:38 --> File loaded: C:\wamp64\www\crm\application\views\blank_page.php
INFO - 2021-07-14 13:45:38 --> Final output sent to browser
DEBUG - 2021-07-14 13:45:38 --> Total execution time: 0.1458
INFO - 2021-07-14 13:45:41 --> Config Class Initialized
INFO - 2021-07-14 13:45:41 --> Hooks Class Initialized
DEBUG - 2021-07-14 13:45:41 --> UTF-8 Support Enabled
INFO - 2021-07-14 13:45:41 --> Utf8 Class Initialized
INFO - 2021-07-14 13:45:41 --> URI Class Initialized
INFO - 2021-07-14 13:45:41 --> Router Class Initialized
INFO - 2021-07-14 13:45:41 --> Output Class Initialized
INFO - 2021-07-14 13:45:41 --> Security Class Initialized
DEBUG - 2021-07-14 13:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 13:45:41 --> Input Class Initialized
INFO - 2021-07-14 13:45:41 --> Language Class Initialized
INFO - 2021-07-14 13:45:41 --> Loader Class Initialized
INFO - 2021-07-14 13:45:41 --> Helper loaded: basic_helper
INFO - 2021-07-14 13:45:41 --> Helper loaded: url_helper
INFO - 2021-07-14 13:45:41 --> Helper loaded: file_helper
INFO - 2021-07-14 13:45:41 --> Helper loaded: form_helper
INFO - 2021-07-14 13:45:41 --> Helper loaded: cookie_helper
INFO - 2021-07-14 13:45:41 --> Helper loaded: security_helper
INFO - 2021-07-14 13:45:41 --> Helper loaded: directory_helper
INFO - 2021-07-14 13:45:41 --> Helper loaded: language_helper
INFO - 2021-07-14 13:45:41 --> Helper loaded: general_helper
INFO - 2021-07-14 13:45:41 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 13:45:41 --> Database Driver Class Initialized
DEBUG - 2021-07-14 13:45:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 13:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 13:45:41 --> Parser Class Initialized
INFO - 2021-07-14 13:45:41 --> Form Validation Class Initialized
INFO - 2021-07-14 13:45:41 --> Upload Class Initialized
INFO - 2021-07-14 13:45:41 --> Email Class Initialized
INFO - 2021-07-14 13:45:41 --> MY_Model class loaded
INFO - 2021-07-14 13:45:41 --> Model "Users_model" initialized
INFO - 2021-07-14 13:45:41 --> Model "Settings_model" initialized
INFO - 2021-07-14 13:45:41 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 13:45:41 --> Model "Permissions_model" initialized
INFO - 2021-07-14 13:45:41 --> Model "Roles_model" initialized
INFO - 2021-07-14 13:45:41 --> Model "Activity_model" initialized
INFO - 2021-07-14 13:45:41 --> Model "Templates_model" initialized
INFO - 2021-07-14 13:45:41 --> Database Driver Class Initialized
INFO - 2021-07-14 13:45:41 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 13:45:41 --> Controller Class Initialized
ERROR - 2021-07-14 13:45:41 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 13:45:41 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-14 13:45:41 --> Final output sent to browser
DEBUG - 2021-07-14 13:45:41 --> Total execution time: 0.0667
INFO - 2021-07-14 13:46:26 --> Config Class Initialized
INFO - 2021-07-14 13:46:26 --> Hooks Class Initialized
DEBUG - 2021-07-14 13:46:26 --> UTF-8 Support Enabled
INFO - 2021-07-14 13:46:26 --> Utf8 Class Initialized
INFO - 2021-07-14 13:46:26 --> URI Class Initialized
INFO - 2021-07-14 13:46:26 --> Router Class Initialized
INFO - 2021-07-14 13:46:26 --> Output Class Initialized
INFO - 2021-07-14 13:46:26 --> Security Class Initialized
DEBUG - 2021-07-14 13:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 13:46:26 --> Input Class Initialized
INFO - 2021-07-14 13:46:26 --> Language Class Initialized
INFO - 2021-07-14 13:46:26 --> Loader Class Initialized
INFO - 2021-07-14 13:46:26 --> Helper loaded: basic_helper
INFO - 2021-07-14 13:46:26 --> Helper loaded: url_helper
INFO - 2021-07-14 13:46:26 --> Helper loaded: file_helper
INFO - 2021-07-14 13:46:26 --> Helper loaded: form_helper
INFO - 2021-07-14 13:46:26 --> Helper loaded: cookie_helper
INFO - 2021-07-14 13:46:26 --> Helper loaded: security_helper
INFO - 2021-07-14 13:46:26 --> Helper loaded: directory_helper
INFO - 2021-07-14 13:46:26 --> Helper loaded: language_helper
INFO - 2021-07-14 13:46:26 --> Helper loaded: general_helper
INFO - 2021-07-14 13:46:26 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 13:46:26 --> Database Driver Class Initialized
DEBUG - 2021-07-14 13:46:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 13:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 13:46:26 --> Parser Class Initialized
INFO - 2021-07-14 13:46:26 --> Form Validation Class Initialized
INFO - 2021-07-14 13:46:26 --> Upload Class Initialized
INFO - 2021-07-14 13:46:26 --> Email Class Initialized
INFO - 2021-07-14 13:46:26 --> MY_Model class loaded
INFO - 2021-07-14 13:46:26 --> Model "Users_model" initialized
INFO - 2021-07-14 13:46:26 --> Model "Settings_model" initialized
INFO - 2021-07-14 13:46:26 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 13:46:26 --> Model "Permissions_model" initialized
INFO - 2021-07-14 13:46:26 --> Model "Roles_model" initialized
INFO - 2021-07-14 13:46:26 --> Model "Activity_model" initialized
INFO - 2021-07-14 13:46:26 --> Model "Templates_model" initialized
INFO - 2021-07-14 13:46:26 --> Database Driver Class Initialized
INFO - 2021-07-14 13:46:26 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 13:46:26 --> Controller Class Initialized
ERROR - 2021-07-14 13:46:26 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 13:46:26 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-14 13:46:26 --> Final output sent to browser
DEBUG - 2021-07-14 13:46:26 --> Total execution time: 0.1457
INFO - 2021-07-14 13:46:30 --> Config Class Initialized
INFO - 2021-07-14 13:46:30 --> Hooks Class Initialized
DEBUG - 2021-07-14 13:46:30 --> UTF-8 Support Enabled
INFO - 2021-07-14 13:46:30 --> Utf8 Class Initialized
INFO - 2021-07-14 13:46:30 --> URI Class Initialized
INFO - 2021-07-14 13:46:30 --> Router Class Initialized
INFO - 2021-07-14 13:46:30 --> Output Class Initialized
INFO - 2021-07-14 13:46:30 --> Security Class Initialized
DEBUG - 2021-07-14 13:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 13:46:30 --> Input Class Initialized
INFO - 2021-07-14 13:46:30 --> Language Class Initialized
INFO - 2021-07-14 13:46:30 --> Loader Class Initialized
INFO - 2021-07-14 13:46:30 --> Helper loaded: basic_helper
INFO - 2021-07-14 13:46:30 --> Helper loaded: url_helper
INFO - 2021-07-14 13:46:30 --> Helper loaded: file_helper
INFO - 2021-07-14 13:46:30 --> Helper loaded: form_helper
INFO - 2021-07-14 13:46:30 --> Helper loaded: cookie_helper
INFO - 2021-07-14 13:46:30 --> Helper loaded: security_helper
INFO - 2021-07-14 13:46:30 --> Helper loaded: directory_helper
INFO - 2021-07-14 13:46:30 --> Helper loaded: language_helper
INFO - 2021-07-14 13:46:30 --> Helper loaded: general_helper
INFO - 2021-07-14 13:46:30 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 13:46:30 --> Database Driver Class Initialized
DEBUG - 2021-07-14 13:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 13:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 13:46:30 --> Parser Class Initialized
INFO - 2021-07-14 13:46:30 --> Form Validation Class Initialized
INFO - 2021-07-14 13:46:30 --> Upload Class Initialized
INFO - 2021-07-14 13:46:30 --> Email Class Initialized
INFO - 2021-07-14 13:46:30 --> MY_Model class loaded
INFO - 2021-07-14 13:46:30 --> Model "Users_model" initialized
INFO - 2021-07-14 13:46:30 --> Model "Settings_model" initialized
INFO - 2021-07-14 13:46:30 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 13:46:30 --> Model "Permissions_model" initialized
INFO - 2021-07-14 13:46:30 --> Model "Roles_model" initialized
INFO - 2021-07-14 13:46:30 --> Model "Activity_model" initialized
INFO - 2021-07-14 13:46:30 --> Model "Templates_model" initialized
INFO - 2021-07-14 13:46:30 --> Database Driver Class Initialized
INFO - 2021-07-14 13:46:30 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 13:46:30 --> Controller Class Initialized
ERROR - 2021-07-14 13:46:30 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 13:46:30 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-14 13:46:30 --> Final output sent to browser
DEBUG - 2021-07-14 13:46:30 --> Total execution time: 0.2131
INFO - 2021-07-14 13:46:37 --> Config Class Initialized
INFO - 2021-07-14 13:46:37 --> Hooks Class Initialized
DEBUG - 2021-07-14 13:46:37 --> UTF-8 Support Enabled
INFO - 2021-07-14 13:46:37 --> Utf8 Class Initialized
INFO - 2021-07-14 13:46:37 --> URI Class Initialized
INFO - 2021-07-14 13:46:37 --> Router Class Initialized
INFO - 2021-07-14 13:46:37 --> Output Class Initialized
INFO - 2021-07-14 13:46:37 --> Security Class Initialized
DEBUG - 2021-07-14 13:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 13:46:37 --> Input Class Initialized
INFO - 2021-07-14 13:46:37 --> Language Class Initialized
INFO - 2021-07-14 13:46:37 --> Loader Class Initialized
INFO - 2021-07-14 13:46:37 --> Helper loaded: basic_helper
INFO - 2021-07-14 13:46:37 --> Helper loaded: url_helper
INFO - 2021-07-14 13:46:37 --> Helper loaded: file_helper
INFO - 2021-07-14 13:46:37 --> Helper loaded: form_helper
INFO - 2021-07-14 13:46:37 --> Helper loaded: cookie_helper
INFO - 2021-07-14 13:46:37 --> Helper loaded: security_helper
INFO - 2021-07-14 13:46:37 --> Helper loaded: directory_helper
INFO - 2021-07-14 13:46:37 --> Helper loaded: language_helper
INFO - 2021-07-14 13:46:37 --> Helper loaded: general_helper
INFO - 2021-07-14 13:46:37 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 13:46:37 --> Database Driver Class Initialized
DEBUG - 2021-07-14 13:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 13:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 13:46:37 --> Parser Class Initialized
INFO - 2021-07-14 13:46:37 --> Form Validation Class Initialized
INFO - 2021-07-14 13:46:37 --> Upload Class Initialized
INFO - 2021-07-14 13:46:37 --> Email Class Initialized
INFO - 2021-07-14 13:46:37 --> MY_Model class loaded
INFO - 2021-07-14 13:46:37 --> Model "Users_model" initialized
INFO - 2021-07-14 13:46:37 --> Model "Settings_model" initialized
INFO - 2021-07-14 13:46:37 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 13:46:37 --> Model "Permissions_model" initialized
INFO - 2021-07-14 13:46:37 --> Model "Roles_model" initialized
INFO - 2021-07-14 13:46:37 --> Model "Activity_model" initialized
INFO - 2021-07-14 13:46:37 --> Model "Templates_model" initialized
INFO - 2021-07-14 13:46:37 --> Database Driver Class Initialized
INFO - 2021-07-14 13:46:37 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 13:46:37 --> Controller Class Initialized
ERROR - 2021-07-14 13:46:37 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 13:46:37 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-14 13:46:37 --> Final output sent to browser
DEBUG - 2021-07-14 13:46:37 --> Total execution time: 0.1340
INFO - 2021-07-14 13:46:39 --> Config Class Initialized
INFO - 2021-07-14 13:46:39 --> Hooks Class Initialized
DEBUG - 2021-07-14 13:46:39 --> UTF-8 Support Enabled
INFO - 2021-07-14 13:46:39 --> Utf8 Class Initialized
INFO - 2021-07-14 13:46:39 --> URI Class Initialized
INFO - 2021-07-14 13:46:39 --> Router Class Initialized
INFO - 2021-07-14 13:46:39 --> Output Class Initialized
INFO - 2021-07-14 13:46:39 --> Security Class Initialized
DEBUG - 2021-07-14 13:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 13:46:39 --> Input Class Initialized
INFO - 2021-07-14 13:46:39 --> Language Class Initialized
INFO - 2021-07-14 13:46:39 --> Loader Class Initialized
INFO - 2021-07-14 13:46:39 --> Helper loaded: basic_helper
INFO - 2021-07-14 13:46:39 --> Helper loaded: url_helper
INFO - 2021-07-14 13:46:39 --> Helper loaded: file_helper
INFO - 2021-07-14 13:46:39 --> Helper loaded: form_helper
INFO - 2021-07-14 13:46:39 --> Helper loaded: cookie_helper
INFO - 2021-07-14 13:46:39 --> Helper loaded: security_helper
INFO - 2021-07-14 13:46:39 --> Helper loaded: directory_helper
INFO - 2021-07-14 13:46:39 --> Helper loaded: language_helper
INFO - 2021-07-14 13:46:39 --> Helper loaded: general_helper
INFO - 2021-07-14 13:46:39 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 13:46:39 --> Database Driver Class Initialized
DEBUG - 2021-07-14 13:46:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 13:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 13:46:39 --> Parser Class Initialized
INFO - 2021-07-14 13:46:39 --> Form Validation Class Initialized
INFO - 2021-07-14 13:46:39 --> Upload Class Initialized
INFO - 2021-07-14 13:46:39 --> Email Class Initialized
INFO - 2021-07-14 13:46:39 --> MY_Model class loaded
INFO - 2021-07-14 13:46:39 --> Model "Users_model" initialized
INFO - 2021-07-14 13:46:39 --> Model "Settings_model" initialized
INFO - 2021-07-14 13:46:39 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 13:46:39 --> Model "Permissions_model" initialized
INFO - 2021-07-14 13:46:39 --> Model "Roles_model" initialized
INFO - 2021-07-14 13:46:39 --> Model "Activity_model" initialized
INFO - 2021-07-14 13:46:39 --> Model "Templates_model" initialized
INFO - 2021-07-14 13:46:39 --> Database Driver Class Initialized
INFO - 2021-07-14 13:46:39 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 13:46:39 --> Controller Class Initialized
ERROR - 2021-07-14 13:46:39 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 13:46:39 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/musteri_bilgi_guncelleme.php
INFO - 2021-07-14 13:46:39 --> Final output sent to browser
DEBUG - 2021-07-14 13:46:39 --> Total execution time: 0.0652
INFO - 2021-07-14 13:46:42 --> Config Class Initialized
INFO - 2021-07-14 13:46:42 --> Hooks Class Initialized
DEBUG - 2021-07-14 13:46:42 --> UTF-8 Support Enabled
INFO - 2021-07-14 13:46:42 --> Utf8 Class Initialized
INFO - 2021-07-14 13:46:42 --> URI Class Initialized
INFO - 2021-07-14 13:46:42 --> Router Class Initialized
INFO - 2021-07-14 13:46:42 --> Output Class Initialized
INFO - 2021-07-14 13:46:42 --> Security Class Initialized
DEBUG - 2021-07-14 13:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 13:46:42 --> Input Class Initialized
INFO - 2021-07-14 13:46:42 --> Language Class Initialized
INFO - 2021-07-14 13:46:42 --> Loader Class Initialized
INFO - 2021-07-14 13:46:42 --> Helper loaded: basic_helper
INFO - 2021-07-14 13:46:42 --> Helper loaded: url_helper
INFO - 2021-07-14 13:46:42 --> Helper loaded: file_helper
INFO - 2021-07-14 13:46:42 --> Helper loaded: form_helper
INFO - 2021-07-14 13:46:42 --> Helper loaded: cookie_helper
INFO - 2021-07-14 13:46:42 --> Helper loaded: security_helper
INFO - 2021-07-14 13:46:42 --> Helper loaded: directory_helper
INFO - 2021-07-14 13:46:42 --> Helper loaded: language_helper
INFO - 2021-07-14 13:46:42 --> Helper loaded: general_helper
INFO - 2021-07-14 13:46:42 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 13:46:42 --> Database Driver Class Initialized
DEBUG - 2021-07-14 13:46:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 13:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 13:46:42 --> Parser Class Initialized
INFO - 2021-07-14 13:46:42 --> Form Validation Class Initialized
INFO - 2021-07-14 13:46:42 --> Upload Class Initialized
INFO - 2021-07-14 13:46:42 --> Email Class Initialized
INFO - 2021-07-14 13:46:42 --> MY_Model class loaded
INFO - 2021-07-14 13:46:42 --> Model "Users_model" initialized
INFO - 2021-07-14 13:46:42 --> Model "Settings_model" initialized
INFO - 2021-07-14 13:46:42 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 13:46:42 --> Model "Permissions_model" initialized
INFO - 2021-07-14 13:46:42 --> Model "Roles_model" initialized
INFO - 2021-07-14 13:46:42 --> Model "Activity_model" initialized
INFO - 2021-07-14 13:46:42 --> Model "Templates_model" initialized
INFO - 2021-07-14 13:46:42 --> Database Driver Class Initialized
INFO - 2021-07-14 13:46:43 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 13:46:43 --> Controller Class Initialized
ERROR - 2021-07-14 13:46:43 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 13:46:43 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-14 13:46:43 --> Final output sent to browser
DEBUG - 2021-07-14 13:46:43 --> Total execution time: 0.1341
INFO - 2021-07-14 14:09:42 --> Config Class Initialized
INFO - 2021-07-14 14:09:42 --> Hooks Class Initialized
DEBUG - 2021-07-14 14:09:42 --> UTF-8 Support Enabled
INFO - 2021-07-14 14:09:42 --> Utf8 Class Initialized
INFO - 2021-07-14 14:09:42 --> URI Class Initialized
DEBUG - 2021-07-14 14:09:42 --> No URI present. Default controller set.
INFO - 2021-07-14 14:09:42 --> Router Class Initialized
INFO - 2021-07-14 14:09:42 --> Output Class Initialized
INFO - 2021-07-14 14:09:42 --> Security Class Initialized
DEBUG - 2021-07-14 14:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 14:09:42 --> Input Class Initialized
INFO - 2021-07-14 14:09:42 --> Language Class Initialized
INFO - 2021-07-14 14:09:42 --> Loader Class Initialized
INFO - 2021-07-14 14:09:42 --> Helper loaded: basic_helper
INFO - 2021-07-14 14:09:42 --> Helper loaded: url_helper
INFO - 2021-07-14 14:09:42 --> Helper loaded: file_helper
INFO - 2021-07-14 14:09:42 --> Helper loaded: form_helper
INFO - 2021-07-14 14:09:42 --> Helper loaded: cookie_helper
INFO - 2021-07-14 14:09:42 --> Helper loaded: security_helper
INFO - 2021-07-14 14:09:42 --> Helper loaded: directory_helper
INFO - 2021-07-14 14:09:42 --> Helper loaded: language_helper
INFO - 2021-07-14 14:09:42 --> Helper loaded: general_helper
INFO - 2021-07-14 14:09:42 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 14:09:42 --> Database Driver Class Initialized
DEBUG - 2021-07-14 14:09:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 14:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 14:09:42 --> Parser Class Initialized
INFO - 2021-07-14 14:09:42 --> Form Validation Class Initialized
INFO - 2021-07-14 14:09:42 --> Upload Class Initialized
INFO - 2021-07-14 14:09:42 --> Email Class Initialized
INFO - 2021-07-14 14:09:42 --> MY_Model class loaded
INFO - 2021-07-14 14:09:42 --> Model "Users_model" initialized
INFO - 2021-07-14 14:09:42 --> Model "Settings_model" initialized
INFO - 2021-07-14 14:09:42 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 14:09:42 --> Model "Permissions_model" initialized
INFO - 2021-07-14 14:09:42 --> Model "Roles_model" initialized
INFO - 2021-07-14 14:09:42 --> Model "Activity_model" initialized
INFO - 2021-07-14 14:09:42 --> Model "Templates_model" initialized
INFO - 2021-07-14 14:09:42 --> Database Driver Class Initialized
INFO - 2021-07-14 14:09:42 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 14:09:42 --> Controller Class Initialized
INFO - 2021-07-14 15:00:48 --> Config Class Initialized
INFO - 2021-07-14 15:00:48 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:00:48 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:00:48 --> Utf8 Class Initialized
INFO - 2021-07-14 15:00:48 --> URI Class Initialized
INFO - 2021-07-14 15:00:48 --> Router Class Initialized
INFO - 2021-07-14 15:00:48 --> Output Class Initialized
INFO - 2021-07-14 15:00:48 --> Security Class Initialized
DEBUG - 2021-07-14 15:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:00:48 --> Input Class Initialized
INFO - 2021-07-14 15:00:48 --> Language Class Initialized
INFO - 2021-07-14 15:00:48 --> Loader Class Initialized
INFO - 2021-07-14 15:00:48 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:00:48 --> Helper loaded: url_helper
INFO - 2021-07-14 15:00:48 --> Helper loaded: file_helper
INFO - 2021-07-14 15:00:48 --> Helper loaded: form_helper
INFO - 2021-07-14 15:00:48 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:00:48 --> Helper loaded: security_helper
INFO - 2021-07-14 15:00:48 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:00:48 --> Helper loaded: language_helper
INFO - 2021-07-14 15:00:48 --> Helper loaded: general_helper
INFO - 2021-07-14 15:00:48 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:00:48 --> Database Driver Class Initialized
DEBUG - 2021-07-14 15:00:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:00:48 --> Parser Class Initialized
INFO - 2021-07-14 15:00:48 --> Form Validation Class Initialized
INFO - 2021-07-14 15:00:48 --> Upload Class Initialized
INFO - 2021-07-14 15:00:48 --> Email Class Initialized
INFO - 2021-07-14 15:00:48 --> MY_Model class loaded
INFO - 2021-07-14 15:00:48 --> Model "Users_model" initialized
INFO - 2021-07-14 15:00:48 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:00:48 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:00:48 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:00:48 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:00:48 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:00:48 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:00:48 --> Database Driver Class Initialized
INFO - 2021-07-14 15:00:48 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:00:48 --> Controller Class Initialized
INFO - 2021-07-14 15:00:48 --> File loaded: C:\wamp64\www\crm\application\views\account/login.php
INFO - 2021-07-14 15:00:48 --> Final output sent to browser
DEBUG - 2021-07-14 15:00:48 --> Total execution time: 0.1197
INFO - 2021-07-14 15:00:48 --> Config Class Initialized
INFO - 2021-07-14 15:00:48 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:00:48 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:00:48 --> Utf8 Class Initialized
INFO - 2021-07-14 15:00:48 --> URI Class Initialized
INFO - 2021-07-14 15:00:48 --> Router Class Initialized
INFO - 2021-07-14 15:00:48 --> Output Class Initialized
INFO - 2021-07-14 15:00:48 --> Security Class Initialized
INFO - 2021-07-14 15:00:48 --> Config Class Initialized
DEBUG - 2021-07-14 15:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:00:48 --> Hooks Class Initialized
INFO - 2021-07-14 15:00:48 --> Input Class Initialized
DEBUG - 2021-07-14 15:00:48 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:00:48 --> Language Class Initialized
INFO - 2021-07-14 15:00:48 --> Utf8 Class Initialized
ERROR - 2021-07-14 15:00:48 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-14 15:00:48 --> URI Class Initialized
INFO - 2021-07-14 15:00:48 --> Router Class Initialized
INFO - 2021-07-14 15:00:48 --> Output Class Initialized
INFO - 2021-07-14 15:00:48 --> Security Class Initialized
DEBUG - 2021-07-14 15:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:00:48 --> Input Class Initialized
INFO - 2021-07-14 15:00:48 --> Language Class Initialized
ERROR - 2021-07-14 15:00:48 --> 404 Page Not Found: Assets/jquery
INFO - 2021-07-14 15:00:49 --> Config Class Initialized
INFO - 2021-07-14 15:00:49 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:00:49 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:00:49 --> Utf8 Class Initialized
INFO - 2021-07-14 15:00:49 --> URI Class Initialized
INFO - 2021-07-14 15:00:49 --> Router Class Initialized
INFO - 2021-07-14 15:00:49 --> Output Class Initialized
INFO - 2021-07-14 15:00:49 --> Security Class Initialized
DEBUG - 2021-07-14 15:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:00:49 --> Input Class Initialized
INFO - 2021-07-14 15:00:49 --> Language Class Initialized
ERROR - 2021-07-14 15:00:49 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-14 15:00:49 --> Config Class Initialized
INFO - 2021-07-14 15:00:49 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:00:49 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:00:49 --> Utf8 Class Initialized
INFO - 2021-07-14 15:00:49 --> URI Class Initialized
INFO - 2021-07-14 15:00:49 --> Router Class Initialized
INFO - 2021-07-14 15:00:49 --> Output Class Initialized
INFO - 2021-07-14 15:00:49 --> Security Class Initialized
DEBUG - 2021-07-14 15:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:00:49 --> Input Class Initialized
INFO - 2021-07-14 15:00:49 --> Language Class Initialized
ERROR - 2021-07-14 15:00:49 --> 404 Page Not Found: Faviconico/index
INFO - 2021-07-14 15:00:52 --> Config Class Initialized
INFO - 2021-07-14 15:00:52 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:00:52 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:00:52 --> Utf8 Class Initialized
INFO - 2021-07-14 15:00:52 --> URI Class Initialized
INFO - 2021-07-14 15:00:52 --> Router Class Initialized
INFO - 2021-07-14 15:00:52 --> Output Class Initialized
INFO - 2021-07-14 15:00:52 --> Security Class Initialized
DEBUG - 2021-07-14 15:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:00:52 --> Input Class Initialized
INFO - 2021-07-14 15:00:52 --> Language Class Initialized
INFO - 2021-07-14 15:00:52 --> Loader Class Initialized
INFO - 2021-07-14 15:00:52 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:00:52 --> Helper loaded: url_helper
INFO - 2021-07-14 15:00:52 --> Helper loaded: file_helper
INFO - 2021-07-14 15:00:52 --> Helper loaded: form_helper
INFO - 2021-07-14 15:00:52 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:00:52 --> Helper loaded: security_helper
INFO - 2021-07-14 15:00:52 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:00:52 --> Helper loaded: language_helper
INFO - 2021-07-14 15:00:52 --> Helper loaded: general_helper
INFO - 2021-07-14 15:00:52 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:00:52 --> Database Driver Class Initialized
DEBUG - 2021-07-14 15:00:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:00:52 --> Parser Class Initialized
INFO - 2021-07-14 15:00:52 --> Form Validation Class Initialized
INFO - 2021-07-14 15:00:52 --> Upload Class Initialized
INFO - 2021-07-14 15:00:52 --> Email Class Initialized
INFO - 2021-07-14 15:00:52 --> MY_Model class loaded
INFO - 2021-07-14 15:00:52 --> Model "Users_model" initialized
INFO - 2021-07-14 15:00:52 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:00:52 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:00:52 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:00:52 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:00:52 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:00:52 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:00:52 --> Database Driver Class Initialized
INFO - 2021-07-14 15:00:52 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:00:52 --> Controller Class Initialized
DEBUG - 2021-07-14 15:00:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-14 15:00:52 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2021-07-14 15:00:52 --> Config Class Initialized
INFO - 2021-07-14 15:00:52 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:00:52 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:00:52 --> Utf8 Class Initialized
INFO - 2021-07-14 15:00:52 --> URI Class Initialized
DEBUG - 2021-07-14 15:00:52 --> No URI present. Default controller set.
INFO - 2021-07-14 15:00:52 --> Router Class Initialized
INFO - 2021-07-14 15:00:52 --> Output Class Initialized
INFO - 2021-07-14 15:00:52 --> Security Class Initialized
DEBUG - 2021-07-14 15:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:00:52 --> Input Class Initialized
INFO - 2021-07-14 15:00:52 --> Language Class Initialized
INFO - 2021-07-14 15:00:52 --> Loader Class Initialized
INFO - 2021-07-14 15:00:52 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:00:52 --> Helper loaded: url_helper
INFO - 2021-07-14 15:00:52 --> Helper loaded: file_helper
INFO - 2021-07-14 15:00:52 --> Helper loaded: form_helper
INFO - 2021-07-14 15:00:52 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:00:52 --> Helper loaded: security_helper
INFO - 2021-07-14 15:00:52 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:00:52 --> Helper loaded: language_helper
INFO - 2021-07-14 15:00:52 --> Helper loaded: general_helper
INFO - 2021-07-14 15:00:52 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:00:52 --> Database Driver Class Initialized
DEBUG - 2021-07-14 15:00:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:00:52 --> Parser Class Initialized
INFO - 2021-07-14 15:00:52 --> Form Validation Class Initialized
INFO - 2021-07-14 15:00:52 --> Upload Class Initialized
INFO - 2021-07-14 15:00:52 --> Email Class Initialized
INFO - 2021-07-14 15:00:52 --> MY_Model class loaded
INFO - 2021-07-14 15:00:52 --> Model "Users_model" initialized
INFO - 2021-07-14 15:00:52 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:00:52 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:00:52 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:00:52 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:00:52 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:00:52 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:00:52 --> Database Driver Class Initialized
INFO - 2021-07-14 15:00:52 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:00:52 --> Controller Class Initialized
ERROR - 2021-07-14 15:00:52 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 15:00:52 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-14 15:00:52 --> Final output sent to browser
DEBUG - 2021-07-14 15:00:52 --> Total execution time: 0.0664
INFO - 2021-07-14 15:00:55 --> Config Class Initialized
INFO - 2021-07-14 15:00:55 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:00:55 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:00:55 --> Utf8 Class Initialized
INFO - 2021-07-14 15:00:55 --> URI Class Initialized
DEBUG - 2021-07-14 15:00:55 --> No URI present. Default controller set.
INFO - 2021-07-14 15:00:55 --> Router Class Initialized
INFO - 2021-07-14 15:00:55 --> Output Class Initialized
INFO - 2021-07-14 15:00:55 --> Security Class Initialized
DEBUG - 2021-07-14 15:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:00:55 --> Input Class Initialized
INFO - 2021-07-14 15:00:55 --> Language Class Initialized
INFO - 2021-07-14 15:00:55 --> Loader Class Initialized
INFO - 2021-07-14 15:00:55 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:00:55 --> Helper loaded: url_helper
INFO - 2021-07-14 15:00:55 --> Helper loaded: file_helper
INFO - 2021-07-14 15:00:55 --> Helper loaded: form_helper
INFO - 2021-07-14 15:00:55 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:00:55 --> Helper loaded: security_helper
INFO - 2021-07-14 15:00:55 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:00:55 --> Helper loaded: language_helper
INFO - 2021-07-14 15:00:55 --> Helper loaded: general_helper
INFO - 2021-07-14 15:00:55 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:00:55 --> Database Driver Class Initialized
DEBUG - 2021-07-14 15:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:00:55 --> Parser Class Initialized
INFO - 2021-07-14 15:00:55 --> Form Validation Class Initialized
INFO - 2021-07-14 15:00:55 --> Upload Class Initialized
INFO - 2021-07-14 15:00:55 --> Email Class Initialized
INFO - 2021-07-14 15:00:55 --> MY_Model class loaded
INFO - 2021-07-14 15:00:55 --> Model "Users_model" initialized
INFO - 2021-07-14 15:00:55 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:00:55 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:00:55 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:00:55 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:00:55 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:00:55 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:00:55 --> Database Driver Class Initialized
INFO - 2021-07-14 15:00:55 --> Config Class Initialized
INFO - 2021-07-14 15:00:55 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:00:55 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:00:55 --> Utf8 Class Initialized
INFO - 2021-07-14 15:00:55 --> URI Class Initialized
INFO - 2021-07-14 15:00:55 --> Router Class Initialized
INFO - 2021-07-14 15:00:55 --> Output Class Initialized
INFO - 2021-07-14 15:00:55 --> Security Class Initialized
DEBUG - 2021-07-14 15:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:00:55 --> Input Class Initialized
INFO - 2021-07-14 15:00:55 --> Language Class Initialized
INFO - 2021-07-14 15:00:55 --> Loader Class Initialized
INFO - 2021-07-14 15:00:55 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:00:55 --> Helper loaded: url_helper
INFO - 2021-07-14 15:00:55 --> Helper loaded: file_helper
INFO - 2021-07-14 15:00:55 --> Helper loaded: form_helper
INFO - 2021-07-14 15:00:55 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:00:55 --> Helper loaded: security_helper
INFO - 2021-07-14 15:00:55 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:00:55 --> Helper loaded: language_helper
INFO - 2021-07-14 15:00:55 --> Helper loaded: general_helper
INFO - 2021-07-14 15:00:55 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:00:55 --> Database Driver Class Initialized
DEBUG - 2021-07-14 15:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:00:55 --> Parser Class Initialized
INFO - 2021-07-14 15:00:55 --> Form Validation Class Initialized
INFO - 2021-07-14 15:00:55 --> Upload Class Initialized
INFO - 2021-07-14 15:00:55 --> Email Class Initialized
INFO - 2021-07-14 15:00:55 --> MY_Model class loaded
INFO - 2021-07-14 15:00:55 --> Model "Users_model" initialized
INFO - 2021-07-14 15:00:55 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:00:55 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:00:55 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:00:55 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:00:55 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:00:55 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:00:55 --> Database Driver Class Initialized
INFO - 2021-07-14 15:00:55 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:00:55 --> Controller Class Initialized
INFO - 2021-07-14 15:00:55 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:00:55 --> Controller Class Initialized
ERROR - 2021-07-14 15:00:55 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-14 15:00:55 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 15:00:55 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-14 15:00:55 --> Final output sent to browser
DEBUG - 2021-07-14 15:00:55 --> Total execution time: 0.1425
INFO - 2021-07-14 15:00:55 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-14 15:00:55 --> Final output sent to browser
DEBUG - 2021-07-14 15:00:55 --> Total execution time: 0.1431
INFO - 2021-07-14 15:00:56 --> Config Class Initialized
INFO - 2021-07-14 15:00:56 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:00:56 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:00:56 --> Utf8 Class Initialized
INFO - 2021-07-14 15:00:56 --> URI Class Initialized
INFO - 2021-07-14 15:00:56 --> Router Class Initialized
INFO - 2021-07-14 15:00:56 --> Output Class Initialized
INFO - 2021-07-14 15:00:56 --> Security Class Initialized
DEBUG - 2021-07-14 15:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:00:56 --> Input Class Initialized
INFO - 2021-07-14 15:00:56 --> Language Class Initialized
ERROR - 2021-07-14 15:00:56 --> 404 Page Not Found: Faviconico/index
INFO - 2021-07-14 15:00:58 --> Config Class Initialized
INFO - 2021-07-14 15:00:58 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:00:58 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:00:58 --> Utf8 Class Initialized
INFO - 2021-07-14 15:00:58 --> URI Class Initialized
INFO - 2021-07-14 15:00:58 --> Router Class Initialized
INFO - 2021-07-14 15:00:58 --> Output Class Initialized
INFO - 2021-07-14 15:00:58 --> Security Class Initialized
DEBUG - 2021-07-14 15:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:00:58 --> Input Class Initialized
INFO - 2021-07-14 15:00:58 --> Language Class Initialized
INFO - 2021-07-14 15:00:58 --> Loader Class Initialized
INFO - 2021-07-14 15:00:58 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:00:58 --> Helper loaded: url_helper
INFO - 2021-07-14 15:00:58 --> Helper loaded: file_helper
INFO - 2021-07-14 15:00:58 --> Helper loaded: form_helper
INFO - 2021-07-14 15:00:58 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:00:58 --> Helper loaded: security_helper
INFO - 2021-07-14 15:00:58 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:00:58 --> Helper loaded: language_helper
INFO - 2021-07-14 15:00:58 --> Helper loaded: general_helper
INFO - 2021-07-14 15:00:58 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:00:58 --> Database Driver Class Initialized
DEBUG - 2021-07-14 15:00:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:00:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:00:58 --> Parser Class Initialized
INFO - 2021-07-14 15:00:58 --> Form Validation Class Initialized
INFO - 2021-07-14 15:00:58 --> Upload Class Initialized
INFO - 2021-07-14 15:00:58 --> Email Class Initialized
INFO - 2021-07-14 15:00:58 --> MY_Model class loaded
INFO - 2021-07-14 15:00:58 --> Model "Users_model" initialized
INFO - 2021-07-14 15:00:58 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:00:58 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:00:58 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:00:58 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:00:58 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:00:58 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:00:58 --> Database Driver Class Initialized
INFO - 2021-07-14 15:00:58 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:00:58 --> Controller Class Initialized
ERROR - 2021-07-14 15:00:58 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 15:00:59 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-14 15:00:59 --> Final output sent to browser
DEBUG - 2021-07-14 15:00:59 --> Total execution time: 0.1143
INFO - 2021-07-14 15:01:06 --> Config Class Initialized
INFO - 2021-07-14 15:01:06 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:01:06 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:01:06 --> Utf8 Class Initialized
INFO - 2021-07-14 15:01:06 --> URI Class Initialized
INFO - 2021-07-14 15:01:06 --> Router Class Initialized
INFO - 2021-07-14 15:01:06 --> Output Class Initialized
INFO - 2021-07-14 15:01:06 --> Security Class Initialized
DEBUG - 2021-07-14 15:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:01:06 --> Input Class Initialized
INFO - 2021-07-14 15:01:06 --> Language Class Initialized
INFO - 2021-07-14 15:01:06 --> Loader Class Initialized
INFO - 2021-07-14 15:01:06 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:01:06 --> Helper loaded: url_helper
INFO - 2021-07-14 15:01:06 --> Helper loaded: file_helper
INFO - 2021-07-14 15:01:06 --> Helper loaded: form_helper
INFO - 2021-07-14 15:01:06 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:01:06 --> Helper loaded: security_helper
INFO - 2021-07-14 15:01:06 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:01:06 --> Helper loaded: language_helper
INFO - 2021-07-14 15:01:06 --> Helper loaded: general_helper
INFO - 2021-07-14 15:01:06 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:01:06 --> Database Driver Class Initialized
DEBUG - 2021-07-14 15:01:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:01:06 --> Parser Class Initialized
INFO - 2021-07-14 15:01:06 --> Form Validation Class Initialized
INFO - 2021-07-14 15:01:06 --> Upload Class Initialized
INFO - 2021-07-14 15:01:06 --> Email Class Initialized
INFO - 2021-07-14 15:01:06 --> MY_Model class loaded
INFO - 2021-07-14 15:01:06 --> Model "Users_model" initialized
INFO - 2021-07-14 15:01:06 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:01:06 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:01:06 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:01:06 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:01:06 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:01:06 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:01:06 --> Database Driver Class Initialized
INFO - 2021-07-14 15:01:06 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:01:06 --> Controller Class Initialized
ERROR - 2021-07-14 15:01:06 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 15:01:06 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-14 15:01:06 --> Final output sent to browser
DEBUG - 2021-07-14 15:01:06 --> Total execution time: 0.1472
INFO - 2021-07-14 15:01:11 --> Config Class Initialized
INFO - 2021-07-14 15:01:11 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:01:11 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:01:11 --> Utf8 Class Initialized
INFO - 2021-07-14 15:01:11 --> URI Class Initialized
INFO - 2021-07-14 15:01:11 --> Router Class Initialized
INFO - 2021-07-14 15:01:11 --> Output Class Initialized
INFO - 2021-07-14 15:01:11 --> Security Class Initialized
DEBUG - 2021-07-14 15:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:01:11 --> Input Class Initialized
INFO - 2021-07-14 15:01:11 --> Language Class Initialized
INFO - 2021-07-14 15:01:11 --> Loader Class Initialized
INFO - 2021-07-14 15:01:11 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:01:11 --> Helper loaded: url_helper
INFO - 2021-07-14 15:01:11 --> Helper loaded: file_helper
INFO - 2021-07-14 15:01:11 --> Helper loaded: form_helper
INFO - 2021-07-14 15:01:11 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:01:11 --> Helper loaded: security_helper
INFO - 2021-07-14 15:01:11 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:01:11 --> Helper loaded: language_helper
INFO - 2021-07-14 15:01:11 --> Helper loaded: general_helper
INFO - 2021-07-14 15:01:11 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:01:11 --> Database Driver Class Initialized
DEBUG - 2021-07-14 15:01:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:01:11 --> Parser Class Initialized
INFO - 2021-07-14 15:01:11 --> Form Validation Class Initialized
INFO - 2021-07-14 15:01:11 --> Upload Class Initialized
INFO - 2021-07-14 15:01:11 --> Email Class Initialized
INFO - 2021-07-14 15:01:11 --> MY_Model class loaded
INFO - 2021-07-14 15:01:11 --> Model "Users_model" initialized
INFO - 2021-07-14 15:01:11 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:01:11 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:01:11 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:01:11 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:01:11 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:01:11 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:01:11 --> Database Driver Class Initialized
INFO - 2021-07-14 15:01:11 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:01:11 --> Controller Class Initialized
ERROR - 2021-07-14 15:01:11 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 15:01:11 --> File loaded: C:\wamp64\www\crm\application\views\users/list.php
INFO - 2021-07-14 15:01:11 --> Final output sent to browser
DEBUG - 2021-07-14 15:01:11 --> Total execution time: 0.1223
INFO - 2021-07-14 15:01:11 --> Config Class Initialized
INFO - 2021-07-14 15:01:11 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:01:11 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:01:11 --> Utf8 Class Initialized
INFO - 2021-07-14 15:01:11 --> URI Class Initialized
INFO - 2021-07-14 15:01:11 --> Router Class Initialized
INFO - 2021-07-14 15:01:11 --> Output Class Initialized
INFO - 2021-07-14 15:01:11 --> Security Class Initialized
DEBUG - 2021-07-14 15:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:01:11 --> Input Class Initialized
INFO - 2021-07-14 15:01:11 --> Language Class Initialized
INFO - 2021-07-14 15:01:11 --> Loader Class Initialized
INFO - 2021-07-14 15:01:11 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:01:11 --> Helper loaded: url_helper
INFO - 2021-07-14 15:01:11 --> Helper loaded: file_helper
INFO - 2021-07-14 15:01:11 --> Helper loaded: form_helper
INFO - 2021-07-14 15:01:11 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:01:11 --> Helper loaded: security_helper
INFO - 2021-07-14 15:01:11 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:01:11 --> Helper loaded: language_helper
INFO - 2021-07-14 15:01:11 --> Helper loaded: general_helper
INFO - 2021-07-14 15:01:11 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:01:11 --> Database Driver Class Initialized
DEBUG - 2021-07-14 15:01:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:01:11 --> Parser Class Initialized
INFO - 2021-07-14 15:01:11 --> Form Validation Class Initialized
INFO - 2021-07-14 15:01:11 --> Upload Class Initialized
INFO - 2021-07-14 15:01:11 --> Email Class Initialized
INFO - 2021-07-14 15:01:11 --> MY_Model class loaded
INFO - 2021-07-14 15:01:11 --> Model "Users_model" initialized
INFO - 2021-07-14 15:01:11 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:01:11 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:01:11 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:01:11 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:01:11 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:01:11 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:01:11 --> Database Driver Class Initialized
INFO - 2021-07-14 15:01:11 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:01:11 --> Controller Class Initialized
ERROR - 2021-07-14 15:01:11 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 15:01:11 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-14 15:01:11 --> Final output sent to browser
DEBUG - 2021-07-14 15:01:11 --> Total execution time: 0.1490
INFO - 2021-07-14 15:01:11 --> Config Class Initialized
INFO - 2021-07-14 15:01:11 --> Hooks Class Initialized
INFO - 2021-07-14 15:01:11 --> Config Class Initialized
INFO - 2021-07-14 15:01:11 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:01:11 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:01:11 --> Utf8 Class Initialized
DEBUG - 2021-07-14 15:01:11 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:01:11 --> URI Class Initialized
INFO - 2021-07-14 15:01:11 --> Utf8 Class Initialized
INFO - 2021-07-14 15:01:11 --> URI Class Initialized
INFO - 2021-07-14 15:01:11 --> Router Class Initialized
INFO - 2021-07-14 15:01:11 --> Output Class Initialized
INFO - 2021-07-14 15:01:11 --> Router Class Initialized
INFO - 2021-07-14 15:01:11 --> Security Class Initialized
INFO - 2021-07-14 15:01:11 --> Output Class Initialized
DEBUG - 2021-07-14 15:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:01:11 --> Config Class Initialized
INFO - 2021-07-14 15:01:11 --> Security Class Initialized
INFO - 2021-07-14 15:01:11 --> Input Class Initialized
INFO - 2021-07-14 15:01:11 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:01:11 --> Language Class Initialized
INFO - 2021-07-14 15:01:11 --> Input Class Initialized
DEBUG - 2021-07-14 15:01:11 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:01:11 --> Utf8 Class Initialized
INFO - 2021-07-14 15:01:11 --> Language Class Initialized
INFO - 2021-07-14 15:01:11 --> Loader Class Initialized
INFO - 2021-07-14 15:01:11 --> URI Class Initialized
INFO - 2021-07-14 15:01:11 --> Loader Class Initialized
INFO - 2021-07-14 15:01:11 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:01:11 --> Router Class Initialized
INFO - 2021-07-14 15:01:11 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:01:11 --> Helper loaded: url_helper
INFO - 2021-07-14 15:01:11 --> Helper loaded: url_helper
INFO - 2021-07-14 15:01:11 --> Output Class Initialized
INFO - 2021-07-14 15:01:11 --> Helper loaded: file_helper
INFO - 2021-07-14 15:01:11 --> Helper loaded: file_helper
INFO - 2021-07-14 15:01:11 --> Security Class Initialized
INFO - 2021-07-14 15:01:11 --> Helper loaded: form_helper
INFO - 2021-07-14 15:01:11 --> Helper loaded: form_helper
DEBUG - 2021-07-14 15:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:01:11 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:01:11 --> Input Class Initialized
INFO - 2021-07-14 15:01:11 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:01:11 --> Config Class Initialized
INFO - 2021-07-14 15:01:11 --> Helper loaded: security_helper
INFO - 2021-07-14 15:01:11 --> Language Class Initialized
INFO - 2021-07-14 15:01:11 --> Hooks Class Initialized
INFO - 2021-07-14 15:01:11 --> Helper loaded: security_helper
INFO - 2021-07-14 15:01:11 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:01:11 --> Loader Class Initialized
INFO - 2021-07-14 15:01:11 --> Helper loaded: directory_helper
DEBUG - 2021-07-14 15:01:11 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:01:11 --> Helper loaded: language_helper
INFO - 2021-07-14 15:01:11 --> Utf8 Class Initialized
INFO - 2021-07-14 15:01:11 --> Helper loaded: language_helper
INFO - 2021-07-14 15:01:11 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:01:11 --> Helper loaded: general_helper
INFO - 2021-07-14 15:01:11 --> URI Class Initialized
INFO - 2021-07-14 15:01:11 --> Helper loaded: general_helper
INFO - 2021-07-14 15:01:11 --> Helper loaded: url_helper
INFO - 2021-07-14 15:01:11 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:01:12 --> Helper loaded: file_helper
INFO - 2021-07-14 15:01:12 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:01:12 --> Router Class Initialized
INFO - 2021-07-14 15:01:12 --> Helper loaded: form_helper
INFO - 2021-07-14 15:01:12 --> Database Driver Class Initialized
INFO - 2021-07-14 15:01:12 --> Output Class Initialized
INFO - 2021-07-14 15:01:12 --> Database Driver Class Initialized
INFO - 2021-07-14 15:01:12 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:01:12 --> Security Class Initialized
INFO - 2021-07-14 15:01:12 --> Helper loaded: security_helper
DEBUG - 2021-07-14 15:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:01:12 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:01:12 --> Input Class Initialized
INFO - 2021-07-14 15:01:12 --> Config Class Initialized
INFO - 2021-07-14 15:01:12 --> Helper loaded: language_helper
INFO - 2021-07-14 15:01:12 --> Language Class Initialized
DEBUG - 2021-07-14 15:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-07-14 15:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:01:12 --> Hooks Class Initialized
INFO - 2021-07-14 15:01:12 --> Helper loaded: general_helper
INFO - 2021-07-14 15:01:12 --> Config Class Initialized
INFO - 2021-07-14 15:01:12 --> Loader Class Initialized
INFO - 2021-07-14 15:01:12 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:01:12 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:01:12 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:01:12 --> Utf8 Class Initialized
INFO - 2021-07-14 15:01:12 --> Helper loaded: basic_helper
DEBUG - 2021-07-14 15:01:12 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:01:12 --> Parser Class Initialized
INFO - 2021-07-14 15:01:12 --> URI Class Initialized
INFO - 2021-07-14 15:01:12 --> Helper loaded: url_helper
INFO - 2021-07-14 15:01:12 --> Database Driver Class Initialized
INFO - 2021-07-14 15:01:12 --> Utf8 Class Initialized
INFO - 2021-07-14 15:01:12 --> Form Validation Class Initialized
INFO - 2021-07-14 15:01:12 --> Helper loaded: file_helper
INFO - 2021-07-14 15:01:12 --> Router Class Initialized
INFO - 2021-07-14 15:01:12 --> URI Class Initialized
INFO - 2021-07-14 15:01:12 --> Helper loaded: form_helper
INFO - 2021-07-14 15:01:12 --> Upload Class Initialized
INFO - 2021-07-14 15:01:12 --> Output Class Initialized
INFO - 2021-07-14 15:01:12 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:01:12 --> Router Class Initialized
INFO - 2021-07-14 15:01:12 --> Security Class Initialized
INFO - 2021-07-14 15:01:12 --> Email Class Initialized
INFO - 2021-07-14 15:01:12 --> Helper loaded: security_helper
INFO - 2021-07-14 15:01:12 --> Output Class Initialized
INFO - 2021-07-14 15:01:12 --> MY_Model class loaded
DEBUG - 2021-07-14 15:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:01:12 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:01:12 --> Security Class Initialized
INFO - 2021-07-14 15:01:12 --> Input Class Initialized
INFO - 2021-07-14 15:01:12 --> Model "Users_model" initialized
INFO - 2021-07-14 15:01:12 --> Helper loaded: language_helper
INFO - 2021-07-14 15:01:12 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:01:12 --> Language Class Initialized
DEBUG - 2021-07-14 15:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:01:12 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:01:12 --> Input Class Initialized
INFO - 2021-07-14 15:01:12 --> Helper loaded: general_helper
INFO - 2021-07-14 15:01:12 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:01:12 --> Loader Class Initialized
INFO - 2021-07-14 15:01:12 --> Language Class Initialized
INFO - 2021-07-14 15:01:12 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:01:12 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:01:12 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:01:12 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:01:12 --> Loader Class Initialized
INFO - 2021-07-14 15:01:12 --> Database Driver Class Initialized
INFO - 2021-07-14 15:01:12 --> Helper loaded: url_helper
INFO - 2021-07-14 15:01:12 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:01:12 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:01:12 --> Helper loaded: file_helper
DEBUG - 2021-07-14 15:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:01:12 --> Database Driver Class Initialized
INFO - 2021-07-14 15:01:12 --> Helper loaded: url_helper
INFO - 2021-07-14 15:01:12 --> Helper loaded: form_helper
INFO - 2021-07-14 15:01:12 --> Helper loaded: file_helper
INFO - 2021-07-14 15:01:12 --> Helper loaded: cookie_helper
DEBUG - 2021-07-14 15:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:01:12 --> Helper loaded: form_helper
INFO - 2021-07-14 15:01:12 --> Helper loaded: security_helper
INFO - 2021-07-14 15:01:12 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:01:12 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:01:12 --> Helper loaded: security_helper
INFO - 2021-07-14 15:01:12 --> Helper loaded: language_helper
INFO - 2021-07-14 15:01:12 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:01:12 --> Helper loaded: general_helper
INFO - 2021-07-14 15:01:12 --> Helper loaded: language_helper
INFO - 2021-07-14 15:01:12 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:01:12 --> Helper loaded: general_helper
INFO - 2021-07-14 15:01:12 --> Database Driver Class Initialized
INFO - 2021-07-14 15:01:12 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:01:12 --> Database Driver Class Initialized
DEBUG - 2021-07-14 15:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-07-14 15:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:01:12 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:01:12 --> Controller Class Initialized
INFO - 2021-07-14 15:01:12 --> Final output sent to browser
DEBUG - 2021-07-14 15:01:12 --> Total execution time: 0.0620
INFO - 2021-07-14 15:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:01:12 --> Parser Class Initialized
INFO - 2021-07-14 15:01:12 --> Form Validation Class Initialized
INFO - 2021-07-14 15:01:12 --> Upload Class Initialized
INFO - 2021-07-14 15:01:12 --> Email Class Initialized
INFO - 2021-07-14 15:01:12 --> MY_Model class loaded
INFO - 2021-07-14 15:01:12 --> Model "Users_model" initialized
INFO - 2021-07-14 15:01:12 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:01:12 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:01:12 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:01:12 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:01:12 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:01:12 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:01:12 --> Database Driver Class Initialized
INFO - 2021-07-14 15:01:12 --> Config Class Initialized
INFO - 2021-07-14 15:01:12 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:01:12 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:01:12 --> Utf8 Class Initialized
INFO - 2021-07-14 15:01:12 --> URI Class Initialized
INFO - 2021-07-14 15:01:12 --> Router Class Initialized
INFO - 2021-07-14 15:01:12 --> Output Class Initialized
INFO - 2021-07-14 15:01:12 --> Security Class Initialized
DEBUG - 2021-07-14 15:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:01:12 --> Input Class Initialized
INFO - 2021-07-14 15:01:12 --> Language Class Initialized
INFO - 2021-07-14 15:01:12 --> Loader Class Initialized
INFO - 2021-07-14 15:01:12 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:01:12 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:01:12 --> Helper loaded: url_helper
INFO - 2021-07-14 15:01:12 --> Controller Class Initialized
INFO - 2021-07-14 15:01:12 --> Helper loaded: file_helper
INFO - 2021-07-14 15:01:12 --> Helper loaded: form_helper
INFO - 2021-07-14 15:01:12 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:01:12 --> Final output sent to browser
INFO - 2021-07-14 15:01:12 --> Helper loaded: security_helper
DEBUG - 2021-07-14 15:01:12 --> Total execution time: 0.0906
INFO - 2021-07-14 15:01:12 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:01:12 --> Helper loaded: language_helper
INFO - 2021-07-14 15:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:01:12 --> Helper loaded: general_helper
INFO - 2021-07-14 15:01:12 --> Parser Class Initialized
INFO - 2021-07-14 15:01:12 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:01:12 --> Form Validation Class Initialized
INFO - 2021-07-14 15:01:12 --> Database Driver Class Initialized
INFO - 2021-07-14 15:01:12 --> Upload Class Initialized
INFO - 2021-07-14 15:01:12 --> Email Class Initialized
INFO - 2021-07-14 15:01:12 --> MY_Model class loaded
DEBUG - 2021-07-14 15:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:01:12 --> Model "Users_model" initialized
INFO - 2021-07-14 15:01:12 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:01:12 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:01:12 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:01:12 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:01:12 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:01:12 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:01:12 --> Database Driver Class Initialized
INFO - 2021-07-14 15:01:12 --> Config Class Initialized
INFO - 2021-07-14 15:01:12 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:01:12 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:01:12 --> Utf8 Class Initialized
INFO - 2021-07-14 15:01:12 --> URI Class Initialized
INFO - 2021-07-14 15:01:12 --> Router Class Initialized
INFO - 2021-07-14 15:01:12 --> Output Class Initialized
INFO - 2021-07-14 15:01:12 --> Security Class Initialized
DEBUG - 2021-07-14 15:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:01:12 --> Input Class Initialized
INFO - 2021-07-14 15:01:12 --> Language Class Initialized
INFO - 2021-07-14 15:01:12 --> Loader Class Initialized
INFO - 2021-07-14 15:01:12 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:01:12 --> Helper loaded: url_helper
INFO - 2021-07-14 15:01:12 --> Helper loaded: file_helper
INFO - 2021-07-14 15:01:12 --> Helper loaded: form_helper
INFO - 2021-07-14 15:01:12 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:01:12 --> Helper loaded: security_helper
INFO - 2021-07-14 15:01:12 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:01:12 --> Helper loaded: language_helper
INFO - 2021-07-14 15:01:12 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:01:12 --> Helper loaded: general_helper
INFO - 2021-07-14 15:01:12 --> Controller Class Initialized
INFO - 2021-07-14 15:01:12 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:01:12 --> Database Driver Class Initialized
INFO - 2021-07-14 15:01:12 --> Final output sent to browser
DEBUG - 2021-07-14 15:01:12 --> Total execution time: 0.1145
INFO - 2021-07-14 15:01:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2021-07-14 15:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:01:12 --> Parser Class Initialized
INFO - 2021-07-14 15:01:12 --> Form Validation Class Initialized
INFO - 2021-07-14 15:01:12 --> Upload Class Initialized
INFO - 2021-07-14 15:01:12 --> Email Class Initialized
INFO - 2021-07-14 15:01:12 --> MY_Model class loaded
INFO - 2021-07-14 15:01:12 --> Model "Users_model" initialized
INFO - 2021-07-14 15:01:12 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:01:12 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:01:12 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:01:12 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:01:12 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:01:12 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:01:12 --> Database Driver Class Initialized
INFO - 2021-07-14 15:01:12 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:01:12 --> Controller Class Initialized
INFO - 2021-07-14 15:01:12 --> Final output sent to browser
DEBUG - 2021-07-14 15:01:12 --> Total execution time: 0.1383
INFO - 2021-07-14 15:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:01:12 --> Parser Class Initialized
INFO - 2021-07-14 15:01:12 --> Form Validation Class Initialized
INFO - 2021-07-14 15:01:12 --> Upload Class Initialized
INFO - 2021-07-14 15:01:12 --> Email Class Initialized
INFO - 2021-07-14 15:01:12 --> Config Class Initialized
INFO - 2021-07-14 15:01:12 --> MY_Model class loaded
INFO - 2021-07-14 15:01:12 --> Hooks Class Initialized
INFO - 2021-07-14 15:01:12 --> Model "Users_model" initialized
INFO - 2021-07-14 15:01:12 --> Model "Settings_model" initialized
DEBUG - 2021-07-14 15:01:12 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:01:12 --> Utf8 Class Initialized
INFO - 2021-07-14 15:01:12 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:01:12 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:01:12 --> URI Class Initialized
INFO - 2021-07-14 15:01:12 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:01:12 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:01:12 --> Router Class Initialized
INFO - 2021-07-14 15:01:12 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:01:12 --> Output Class Initialized
INFO - 2021-07-14 15:01:12 --> Database Driver Class Initialized
INFO - 2021-07-14 15:01:12 --> Security Class Initialized
DEBUG - 2021-07-14 15:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:01:12 --> Input Class Initialized
INFO - 2021-07-14 15:01:12 --> Language Class Initialized
INFO - 2021-07-14 15:01:12 --> Loader Class Initialized
INFO - 2021-07-14 15:01:12 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:01:12 --> Helper loaded: url_helper
INFO - 2021-07-14 15:01:12 --> Helper loaded: file_helper
INFO - 2021-07-14 15:01:12 --> Helper loaded: form_helper
INFO - 2021-07-14 15:01:12 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:01:12 --> Helper loaded: security_helper
INFO - 2021-07-14 15:01:12 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:01:12 --> Helper loaded: language_helper
INFO - 2021-07-14 15:01:12 --> Helper loaded: general_helper
INFO - 2021-07-14 15:01:12 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:01:12 --> Database Driver Class Initialized
DEBUG - 2021-07-14 15:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:01:12 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:01:12 --> Controller Class Initialized
INFO - 2021-07-14 15:01:12 --> Final output sent to browser
DEBUG - 2021-07-14 15:01:12 --> Total execution time: 0.1557
INFO - 2021-07-14 15:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:01:12 --> Parser Class Initialized
INFO - 2021-07-14 15:01:12 --> Form Validation Class Initialized
INFO - 2021-07-14 15:01:12 --> Upload Class Initialized
INFO - 2021-07-14 15:01:12 --> Email Class Initialized
INFO - 2021-07-14 15:01:12 --> MY_Model class loaded
INFO - 2021-07-14 15:01:12 --> Model "Users_model" initialized
INFO - 2021-07-14 15:01:12 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:01:12 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:01:12 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:01:12 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:01:12 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:01:12 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:01:12 --> Database Driver Class Initialized
INFO - 2021-07-14 15:01:12 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:01:12 --> Controller Class Initialized
INFO - 2021-07-14 15:01:12 --> Final output sent to browser
DEBUG - 2021-07-14 15:01:12 --> Total execution time: 0.1879
INFO - 2021-07-14 15:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:01:12 --> Parser Class Initialized
INFO - 2021-07-14 15:01:12 --> Form Validation Class Initialized
INFO - 2021-07-14 15:01:12 --> Upload Class Initialized
INFO - 2021-07-14 15:01:12 --> Email Class Initialized
INFO - 2021-07-14 15:01:12 --> MY_Model class loaded
INFO - 2021-07-14 15:01:12 --> Model "Users_model" initialized
INFO - 2021-07-14 15:01:12 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:01:12 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:01:12 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:01:12 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:01:12 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:01:12 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:01:12 --> Database Driver Class Initialized
INFO - 2021-07-14 15:01:12 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:01:12 --> Controller Class Initialized
INFO - 2021-07-14 15:01:12 --> Final output sent to browser
DEBUG - 2021-07-14 15:01:12 --> Total execution time: 0.1672
INFO - 2021-07-14 15:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:01:12 --> Parser Class Initialized
INFO - 2021-07-14 15:01:12 --> Form Validation Class Initialized
INFO - 2021-07-14 15:01:12 --> Upload Class Initialized
INFO - 2021-07-14 15:01:12 --> Email Class Initialized
INFO - 2021-07-14 15:01:12 --> MY_Model class loaded
INFO - 2021-07-14 15:01:12 --> Model "Users_model" initialized
INFO - 2021-07-14 15:01:12 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:01:12 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:01:12 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:01:12 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:01:12 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:01:12 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:01:12 --> Database Driver Class Initialized
INFO - 2021-07-14 15:01:12 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:01:12 --> Controller Class Initialized
INFO - 2021-07-14 15:01:12 --> Final output sent to browser
DEBUG - 2021-07-14 15:01:12 --> Total execution time: 0.1717
INFO - 2021-07-14 15:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:01:12 --> Parser Class Initialized
INFO - 2021-07-14 15:01:12 --> Form Validation Class Initialized
INFO - 2021-07-14 15:01:12 --> Upload Class Initialized
INFO - 2021-07-14 15:01:12 --> Email Class Initialized
INFO - 2021-07-14 15:01:12 --> MY_Model class loaded
INFO - 2021-07-14 15:01:12 --> Model "Users_model" initialized
INFO - 2021-07-14 15:01:12 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:01:12 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:01:12 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:01:12 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:01:12 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:01:12 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:01:12 --> Database Driver Class Initialized
INFO - 2021-07-14 15:01:12 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:01:12 --> Controller Class Initialized
INFO - 2021-07-14 15:01:12 --> Final output sent to browser
DEBUG - 2021-07-14 15:01:12 --> Total execution time: 0.1520
INFO - 2021-07-14 15:01:13 --> Config Class Initialized
INFO - 2021-07-14 15:01:13 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:01:13 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:01:13 --> Utf8 Class Initialized
INFO - 2021-07-14 15:01:13 --> URI Class Initialized
INFO - 2021-07-14 15:01:13 --> Router Class Initialized
INFO - 2021-07-14 15:01:13 --> Output Class Initialized
INFO - 2021-07-14 15:01:13 --> Security Class Initialized
DEBUG - 2021-07-14 15:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:01:13 --> Input Class Initialized
INFO - 2021-07-14 15:01:13 --> Language Class Initialized
INFO - 2021-07-14 15:01:13 --> Loader Class Initialized
INFO - 2021-07-14 15:01:13 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:01:13 --> Helper loaded: url_helper
INFO - 2021-07-14 15:01:13 --> Helper loaded: file_helper
INFO - 2021-07-14 15:01:13 --> Helper loaded: form_helper
INFO - 2021-07-14 15:01:13 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:01:13 --> Helper loaded: security_helper
INFO - 2021-07-14 15:01:13 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:01:13 --> Helper loaded: language_helper
INFO - 2021-07-14 15:01:13 --> Helper loaded: general_helper
INFO - 2021-07-14 15:01:13 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:01:13 --> Database Driver Class Initialized
DEBUG - 2021-07-14 15:01:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:01:13 --> Parser Class Initialized
INFO - 2021-07-14 15:01:13 --> Form Validation Class Initialized
INFO - 2021-07-14 15:01:13 --> Upload Class Initialized
INFO - 2021-07-14 15:01:13 --> Email Class Initialized
INFO - 2021-07-14 15:01:13 --> MY_Model class loaded
INFO - 2021-07-14 15:01:13 --> Model "Users_model" initialized
INFO - 2021-07-14 15:01:13 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:01:13 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:01:13 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:01:13 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:01:13 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:01:13 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:01:13 --> Database Driver Class Initialized
INFO - 2021-07-14 15:01:13 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:01:13 --> Controller Class Initialized
ERROR - 2021-07-14 15:01:13 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 15:01:13 --> File loaded: C:\wamp64\www\crm\application\views\users/add.php
INFO - 2021-07-14 15:01:13 --> Final output sent to browser
DEBUG - 2021-07-14 15:01:13 --> Total execution time: 0.0665
INFO - 2021-07-14 15:01:48 --> Config Class Initialized
INFO - 2021-07-14 15:01:48 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:01:48 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:01:48 --> Utf8 Class Initialized
INFO - 2021-07-14 15:01:48 --> URI Class Initialized
INFO - 2021-07-14 15:01:48 --> Router Class Initialized
INFO - 2021-07-14 15:01:48 --> Output Class Initialized
INFO - 2021-07-14 15:01:48 --> Security Class Initialized
DEBUG - 2021-07-14 15:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:01:48 --> Input Class Initialized
INFO - 2021-07-14 15:01:48 --> Language Class Initialized
INFO - 2021-07-14 15:01:48 --> Loader Class Initialized
INFO - 2021-07-14 15:01:48 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:01:48 --> Helper loaded: url_helper
INFO - 2021-07-14 15:01:48 --> Helper loaded: file_helper
INFO - 2021-07-14 15:01:48 --> Helper loaded: form_helper
INFO - 2021-07-14 15:01:48 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:01:48 --> Helper loaded: security_helper
INFO - 2021-07-14 15:01:48 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:01:48 --> Helper loaded: language_helper
INFO - 2021-07-14 15:01:48 --> Helper loaded: general_helper
INFO - 2021-07-14 15:01:48 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:01:48 --> Database Driver Class Initialized
DEBUG - 2021-07-14 15:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:01:48 --> Parser Class Initialized
INFO - 2021-07-14 15:01:48 --> Form Validation Class Initialized
INFO - 2021-07-14 15:01:48 --> Upload Class Initialized
INFO - 2021-07-14 15:01:48 --> Email Class Initialized
INFO - 2021-07-14 15:01:48 --> MY_Model class loaded
INFO - 2021-07-14 15:01:48 --> Model "Users_model" initialized
INFO - 2021-07-14 15:01:48 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:01:48 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:01:48 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:01:48 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:01:48 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:01:48 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:01:48 --> Database Driver Class Initialized
INFO - 2021-07-14 15:01:48 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:01:48 --> Controller Class Initialized
INFO - 2021-07-14 15:01:48 --> Final output sent to browser
DEBUG - 2021-07-14 15:01:48 --> Total execution time: 0.1250
INFO - 2021-07-14 15:02:06 --> Config Class Initialized
INFO - 2021-07-14 15:02:06 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:02:06 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:02:06 --> Utf8 Class Initialized
INFO - 2021-07-14 15:02:06 --> URI Class Initialized
INFO - 2021-07-14 15:02:06 --> Router Class Initialized
INFO - 2021-07-14 15:02:06 --> Output Class Initialized
INFO - 2021-07-14 15:02:06 --> Security Class Initialized
DEBUG - 2021-07-14 15:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:02:06 --> Input Class Initialized
INFO - 2021-07-14 15:02:06 --> Language Class Initialized
INFO - 2021-07-14 15:02:06 --> Loader Class Initialized
INFO - 2021-07-14 15:02:06 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:02:06 --> Helper loaded: url_helper
INFO - 2021-07-14 15:02:06 --> Helper loaded: file_helper
INFO - 2021-07-14 15:02:06 --> Helper loaded: form_helper
INFO - 2021-07-14 15:02:06 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:02:06 --> Helper loaded: security_helper
INFO - 2021-07-14 15:02:06 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:02:06 --> Helper loaded: language_helper
INFO - 2021-07-14 15:02:06 --> Helper loaded: general_helper
INFO - 2021-07-14 15:02:06 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:02:06 --> Database Driver Class Initialized
DEBUG - 2021-07-14 15:02:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:02:06 --> Parser Class Initialized
INFO - 2021-07-14 15:02:06 --> Form Validation Class Initialized
INFO - 2021-07-14 15:02:06 --> Upload Class Initialized
INFO - 2021-07-14 15:02:06 --> Email Class Initialized
INFO - 2021-07-14 15:02:06 --> MY_Model class loaded
INFO - 2021-07-14 15:02:06 --> Model "Users_model" initialized
INFO - 2021-07-14 15:02:06 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:02:06 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:02:06 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:02:06 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:02:06 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:02:06 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:02:06 --> Database Driver Class Initialized
INFO - 2021-07-14 15:02:06 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:02:06 --> Controller Class Initialized
ERROR - 2021-07-14 15:02:06 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 15:02:07 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-14 15:02:07 --> Final output sent to browser
DEBUG - 2021-07-14 15:02:07 --> Total execution time: 0.1342
INFO - 2021-07-14 15:02:09 --> Config Class Initialized
INFO - 2021-07-14 15:02:09 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:02:09 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:02:09 --> Utf8 Class Initialized
INFO - 2021-07-14 15:02:09 --> URI Class Initialized
INFO - 2021-07-14 15:02:09 --> Router Class Initialized
INFO - 2021-07-14 15:02:09 --> Output Class Initialized
INFO - 2021-07-14 15:02:09 --> Security Class Initialized
DEBUG - 2021-07-14 15:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:02:09 --> Input Class Initialized
INFO - 2021-07-14 15:02:09 --> Language Class Initialized
INFO - 2021-07-14 15:02:09 --> Loader Class Initialized
INFO - 2021-07-14 15:02:09 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:02:09 --> Helper loaded: url_helper
INFO - 2021-07-14 15:02:09 --> Helper loaded: file_helper
INFO - 2021-07-14 15:02:09 --> Helper loaded: form_helper
INFO - 2021-07-14 15:02:09 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:02:09 --> Helper loaded: security_helper
INFO - 2021-07-14 15:02:09 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:02:09 --> Helper loaded: language_helper
INFO - 2021-07-14 15:02:09 --> Helper loaded: general_helper
INFO - 2021-07-14 15:02:09 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:02:09 --> Database Driver Class Initialized
DEBUG - 2021-07-14 15:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:02:09 --> Parser Class Initialized
INFO - 2021-07-14 15:02:09 --> Form Validation Class Initialized
INFO - 2021-07-14 15:02:09 --> Upload Class Initialized
INFO - 2021-07-14 15:02:09 --> Email Class Initialized
INFO - 2021-07-14 15:02:09 --> MY_Model class loaded
INFO - 2021-07-14 15:02:09 --> Model "Users_model" initialized
INFO - 2021-07-14 15:02:09 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:02:09 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:02:09 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:02:09 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:02:09 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:02:09 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:02:09 --> Database Driver Class Initialized
INFO - 2021-07-14 15:02:09 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:02:09 --> Controller Class Initialized
ERROR - 2021-07-14 15:02:09 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 15:02:09 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-14 15:02:09 --> Final output sent to browser
DEBUG - 2021-07-14 15:02:09 --> Total execution time: 0.1163
INFO - 2021-07-14 15:02:15 --> Config Class Initialized
INFO - 2021-07-14 15:02:15 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:02:15 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:02:15 --> Utf8 Class Initialized
INFO - 2021-07-14 15:02:15 --> URI Class Initialized
INFO - 2021-07-14 15:02:15 --> Router Class Initialized
INFO - 2021-07-14 15:02:15 --> Output Class Initialized
INFO - 2021-07-14 15:02:15 --> Security Class Initialized
DEBUG - 2021-07-14 15:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:02:15 --> Input Class Initialized
INFO - 2021-07-14 15:02:15 --> Language Class Initialized
INFO - 2021-07-14 15:02:15 --> Loader Class Initialized
INFO - 2021-07-14 15:02:15 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:02:15 --> Helper loaded: url_helper
INFO - 2021-07-14 15:02:15 --> Helper loaded: file_helper
INFO - 2021-07-14 15:02:15 --> Helper loaded: form_helper
INFO - 2021-07-14 15:02:15 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:02:15 --> Helper loaded: security_helper
INFO - 2021-07-14 15:02:15 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:02:15 --> Helper loaded: language_helper
INFO - 2021-07-14 15:02:15 --> Helper loaded: general_helper
INFO - 2021-07-14 15:02:15 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:02:15 --> Database Driver Class Initialized
DEBUG - 2021-07-14 15:02:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:02:15 --> Parser Class Initialized
INFO - 2021-07-14 15:02:15 --> Form Validation Class Initialized
INFO - 2021-07-14 15:02:15 --> Upload Class Initialized
INFO - 2021-07-14 15:02:15 --> Email Class Initialized
INFO - 2021-07-14 15:02:15 --> MY_Model class loaded
INFO - 2021-07-14 15:02:15 --> Model "Users_model" initialized
INFO - 2021-07-14 15:02:15 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:02:15 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:02:15 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:02:15 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:02:15 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:02:15 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:02:15 --> Database Driver Class Initialized
INFO - 2021-07-14 15:02:15 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:02:15 --> Controller Class Initialized
ERROR - 2021-07-14 15:02:15 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 15:02:15 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-14 15:02:15 --> Final output sent to browser
DEBUG - 2021-07-14 15:02:15 --> Total execution time: 0.1764
INFO - 2021-07-14 15:02:22 --> Config Class Initialized
INFO - 2021-07-14 15:02:22 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:02:22 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:02:22 --> Utf8 Class Initialized
INFO - 2021-07-14 15:02:22 --> URI Class Initialized
INFO - 2021-07-14 15:02:22 --> Router Class Initialized
INFO - 2021-07-14 15:02:22 --> Output Class Initialized
INFO - 2021-07-14 15:02:22 --> Security Class Initialized
DEBUG - 2021-07-14 15:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:02:22 --> Input Class Initialized
INFO - 2021-07-14 15:02:22 --> Language Class Initialized
INFO - 2021-07-14 15:02:22 --> Loader Class Initialized
INFO - 2021-07-14 15:02:22 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:02:22 --> Helper loaded: url_helper
INFO - 2021-07-14 15:02:22 --> Helper loaded: file_helper
INFO - 2021-07-14 15:02:22 --> Helper loaded: form_helper
INFO - 2021-07-14 15:02:22 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:02:22 --> Helper loaded: security_helper
INFO - 2021-07-14 15:02:22 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:02:22 --> Helper loaded: language_helper
INFO - 2021-07-14 15:02:22 --> Helper loaded: general_helper
INFO - 2021-07-14 15:02:22 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:02:22 --> Database Driver Class Initialized
DEBUG - 2021-07-14 15:02:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:02:22 --> Parser Class Initialized
INFO - 2021-07-14 15:02:22 --> Form Validation Class Initialized
INFO - 2021-07-14 15:02:22 --> Upload Class Initialized
INFO - 2021-07-14 15:02:22 --> Email Class Initialized
INFO - 2021-07-14 15:02:22 --> MY_Model class loaded
INFO - 2021-07-14 15:02:22 --> Model "Users_model" initialized
INFO - 2021-07-14 15:02:22 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:02:22 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:02:22 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:02:22 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:02:22 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:02:22 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:02:22 --> Database Driver Class Initialized
INFO - 2021-07-14 15:02:22 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:02:22 --> Controller Class Initialized
ERROR - 2021-07-14 15:02:22 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 15:02:22 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-14 15:02:22 --> Final output sent to browser
DEBUG - 2021-07-14 15:02:22 --> Total execution time: 0.1472
INFO - 2021-07-14 15:03:19 --> Config Class Initialized
INFO - 2021-07-14 15:03:19 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:03:19 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:03:19 --> Utf8 Class Initialized
INFO - 2021-07-14 15:03:19 --> URI Class Initialized
INFO - 2021-07-14 15:03:19 --> Router Class Initialized
INFO - 2021-07-14 15:03:19 --> Output Class Initialized
INFO - 2021-07-14 15:03:19 --> Security Class Initialized
DEBUG - 2021-07-14 15:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:03:19 --> Input Class Initialized
INFO - 2021-07-14 15:03:19 --> Language Class Initialized
INFO - 2021-07-14 15:03:19 --> Loader Class Initialized
INFO - 2021-07-14 15:03:19 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:03:19 --> Helper loaded: url_helper
INFO - 2021-07-14 15:03:19 --> Helper loaded: file_helper
INFO - 2021-07-14 15:03:19 --> Helper loaded: form_helper
INFO - 2021-07-14 15:03:19 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:03:19 --> Helper loaded: security_helper
INFO - 2021-07-14 15:03:19 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:03:19 --> Helper loaded: language_helper
INFO - 2021-07-14 15:03:19 --> Helper loaded: general_helper
INFO - 2021-07-14 15:03:19 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:03:19 --> Database Driver Class Initialized
DEBUG - 2021-07-14 15:03:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:03:19 --> Parser Class Initialized
INFO - 2021-07-14 15:03:19 --> Form Validation Class Initialized
INFO - 2021-07-14 15:03:19 --> Upload Class Initialized
INFO - 2021-07-14 15:03:19 --> Email Class Initialized
INFO - 2021-07-14 15:03:19 --> MY_Model class loaded
INFO - 2021-07-14 15:03:19 --> Model "Users_model" initialized
INFO - 2021-07-14 15:03:19 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:03:19 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:03:19 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:03:19 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:03:19 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:03:19 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:03:19 --> Database Driver Class Initialized
INFO - 2021-07-14 15:03:19 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:03:19 --> Controller Class Initialized
INFO - 2021-07-14 15:03:19 --> Final output sent to browser
DEBUG - 2021-07-14 15:03:19 --> Total execution time: 0.1135
INFO - 2021-07-14 15:04:37 --> Config Class Initialized
INFO - 2021-07-14 15:04:37 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:04:37 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:04:37 --> Utf8 Class Initialized
INFO - 2021-07-14 15:04:37 --> URI Class Initialized
INFO - 2021-07-14 15:04:37 --> Router Class Initialized
INFO - 2021-07-14 15:04:37 --> Output Class Initialized
INFO - 2021-07-14 15:04:37 --> Security Class Initialized
DEBUG - 2021-07-14 15:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:04:37 --> Input Class Initialized
INFO - 2021-07-14 15:04:37 --> Language Class Initialized
INFO - 2021-07-14 15:04:37 --> Loader Class Initialized
INFO - 2021-07-14 15:04:37 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:04:37 --> Helper loaded: url_helper
INFO - 2021-07-14 15:04:37 --> Helper loaded: file_helper
INFO - 2021-07-14 15:04:37 --> Helper loaded: form_helper
INFO - 2021-07-14 15:04:37 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:04:37 --> Helper loaded: security_helper
INFO - 2021-07-14 15:04:37 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:04:37 --> Helper loaded: language_helper
INFO - 2021-07-14 15:04:37 --> Helper loaded: general_helper
INFO - 2021-07-14 15:04:37 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:04:37 --> Database Driver Class Initialized
DEBUG - 2021-07-14 15:04:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:04:37 --> Parser Class Initialized
INFO - 2021-07-14 15:04:37 --> Form Validation Class Initialized
INFO - 2021-07-14 15:04:37 --> Upload Class Initialized
INFO - 2021-07-14 15:04:37 --> Email Class Initialized
INFO - 2021-07-14 15:04:37 --> MY_Model class loaded
INFO - 2021-07-14 15:04:37 --> Model "Users_model" initialized
INFO - 2021-07-14 15:04:37 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:04:37 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:04:37 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:04:37 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:04:37 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:04:37 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:04:37 --> Database Driver Class Initialized
INFO - 2021-07-14 15:04:38 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:04:38 --> Controller Class Initialized
INFO - 2021-07-14 15:04:38 --> Config Class Initialized
INFO - 2021-07-14 15:04:38 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:04:38 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:04:38 --> Utf8 Class Initialized
INFO - 2021-07-14 15:04:38 --> URI Class Initialized
INFO - 2021-07-14 15:04:38 --> Router Class Initialized
INFO - 2021-07-14 15:04:38 --> Output Class Initialized
INFO - 2021-07-14 15:04:38 --> Security Class Initialized
DEBUG - 2021-07-14 15:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:04:38 --> Input Class Initialized
INFO - 2021-07-14 15:04:38 --> Language Class Initialized
INFO - 2021-07-14 15:04:38 --> Loader Class Initialized
INFO - 2021-07-14 15:04:38 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:04:38 --> Helper loaded: url_helper
INFO - 2021-07-14 15:04:38 --> Helper loaded: file_helper
INFO - 2021-07-14 15:04:38 --> Helper loaded: form_helper
INFO - 2021-07-14 15:04:38 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:04:38 --> Helper loaded: security_helper
INFO - 2021-07-14 15:04:38 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:04:38 --> Helper loaded: language_helper
INFO - 2021-07-14 15:04:38 --> Helper loaded: general_helper
INFO - 2021-07-14 15:04:38 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:04:38 --> Database Driver Class Initialized
DEBUG - 2021-07-14 15:04:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:04:38 --> Parser Class Initialized
INFO - 2021-07-14 15:04:38 --> Form Validation Class Initialized
INFO - 2021-07-14 15:04:38 --> Upload Class Initialized
INFO - 2021-07-14 15:04:38 --> Email Class Initialized
INFO - 2021-07-14 15:04:38 --> MY_Model class loaded
INFO - 2021-07-14 15:04:38 --> Model "Users_model" initialized
INFO - 2021-07-14 15:04:38 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:04:38 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:04:38 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:04:38 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:04:38 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:04:38 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:04:38 --> Database Driver Class Initialized
INFO - 2021-07-14 15:04:38 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:04:38 --> Controller Class Initialized
ERROR - 2021-07-14 15:04:38 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 15:04:38 --> File loaded: C:\wamp64\www\crm\application\views\users/list.php
INFO - 2021-07-14 15:04:38 --> Final output sent to browser
DEBUG - 2021-07-14 15:04:38 --> Total execution time: 0.1204
INFO - 2021-07-14 15:04:38 --> Config Class Initialized
INFO - 2021-07-14 15:04:38 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:04:38 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:04:38 --> Utf8 Class Initialized
INFO - 2021-07-14 15:04:38 --> URI Class Initialized
INFO - 2021-07-14 15:04:38 --> Router Class Initialized
INFO - 2021-07-14 15:04:38 --> Output Class Initialized
INFO - 2021-07-14 15:04:38 --> Security Class Initialized
DEBUG - 2021-07-14 15:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:04:38 --> Input Class Initialized
INFO - 2021-07-14 15:04:38 --> Language Class Initialized
INFO - 2021-07-14 15:04:38 --> Loader Class Initialized
INFO - 2021-07-14 15:04:38 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:04:38 --> Helper loaded: url_helper
INFO - 2021-07-14 15:04:38 --> Helper loaded: file_helper
INFO - 2021-07-14 15:04:38 --> Helper loaded: form_helper
INFO - 2021-07-14 15:04:38 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:04:38 --> Helper loaded: security_helper
INFO - 2021-07-14 15:04:38 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:04:38 --> Helper loaded: language_helper
INFO - 2021-07-14 15:04:38 --> Config Class Initialized
INFO - 2021-07-14 15:04:38 --> Helper loaded: general_helper
INFO - 2021-07-14 15:04:38 --> Hooks Class Initialized
INFO - 2021-07-14 15:04:38 --> Language file loaded: language/en/basic_lang.php
DEBUG - 2021-07-14 15:04:38 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:04:38 --> Utf8 Class Initialized
INFO - 2021-07-14 15:04:38 --> Database Driver Class Initialized
INFO - 2021-07-14 15:04:38 --> URI Class Initialized
INFO - 2021-07-14 15:04:38 --> Router Class Initialized
INFO - 2021-07-14 15:04:38 --> Output Class Initialized
DEBUG - 2021-07-14 15:04:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:04:38 --> Security Class Initialized
INFO - 2021-07-14 15:04:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2021-07-14 15:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:04:38 --> Config Class Initialized
INFO - 2021-07-14 15:04:38 --> Input Class Initialized
INFO - 2021-07-14 15:04:38 --> Hooks Class Initialized
INFO - 2021-07-14 15:04:38 --> Parser Class Initialized
INFO - 2021-07-14 15:04:38 --> Language Class Initialized
DEBUG - 2021-07-14 15:04:38 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:04:38 --> Form Validation Class Initialized
INFO - 2021-07-14 15:04:38 --> Utf8 Class Initialized
INFO - 2021-07-14 15:04:38 --> Loader Class Initialized
INFO - 2021-07-14 15:04:38 --> URI Class Initialized
INFO - 2021-07-14 15:04:38 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:04:38 --> Upload Class Initialized
INFO - 2021-07-14 15:04:38 --> Helper loaded: url_helper
INFO - 2021-07-14 15:04:38 --> Router Class Initialized
INFO - 2021-07-14 15:04:38 --> Email Class Initialized
INFO - 2021-07-14 15:04:38 --> Helper loaded: file_helper
INFO - 2021-07-14 15:04:38 --> Output Class Initialized
INFO - 2021-07-14 15:04:38 --> MY_Model class loaded
INFO - 2021-07-14 15:04:38 --> Helper loaded: form_helper
INFO - 2021-07-14 15:04:38 --> Security Class Initialized
INFO - 2021-07-14 15:04:38 --> Model "Users_model" initialized
INFO - 2021-07-14 15:04:38 --> Config Class Initialized
INFO - 2021-07-14 15:04:38 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:04:38 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:04:38 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:04:38 --> Helper loaded: security_helper
INFO - 2021-07-14 15:04:38 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:04:38 --> Input Class Initialized
DEBUG - 2021-07-14 15:04:38 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:04:38 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:04:38 --> Utf8 Class Initialized
INFO - 2021-07-14 15:04:38 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:04:38 --> Language Class Initialized
INFO - 2021-07-14 15:04:38 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:04:38 --> URI Class Initialized
INFO - 2021-07-14 15:04:38 --> Helper loaded: language_helper
INFO - 2021-07-14 15:04:38 --> Loader Class Initialized
INFO - 2021-07-14 15:04:38 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:04:38 --> Helper loaded: general_helper
INFO - 2021-07-14 15:04:38 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:04:38 --> Router Class Initialized
INFO - 2021-07-14 15:04:38 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:04:38 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:04:38 --> Database Driver Class Initialized
INFO - 2021-07-14 15:04:38 --> Output Class Initialized
INFO - 2021-07-14 15:04:38 --> Helper loaded: url_helper
INFO - 2021-07-14 15:04:38 --> Database Driver Class Initialized
INFO - 2021-07-14 15:04:38 --> Security Class Initialized
INFO - 2021-07-14 15:04:38 --> Helper loaded: file_helper
INFO - 2021-07-14 15:04:38 --> Config Class Initialized
INFO - 2021-07-14 15:04:38 --> Helper loaded: form_helper
DEBUG - 2021-07-14 15:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:04:38 --> Hooks Class Initialized
INFO - 2021-07-14 15:04:38 --> Input Class Initialized
INFO - 2021-07-14 15:04:38 --> Helper loaded: cookie_helper
DEBUG - 2021-07-14 15:04:38 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:04:38 --> Language Class Initialized
INFO - 2021-07-14 15:04:38 --> Helper loaded: security_helper
DEBUG - 2021-07-14 15:04:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:04:38 --> Utf8 Class Initialized
INFO - 2021-07-14 15:04:38 --> Loader Class Initialized
INFO - 2021-07-14 15:04:38 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:04:38 --> URI Class Initialized
INFO - 2021-07-14 15:04:38 --> Helper loaded: language_helper
INFO - 2021-07-14 15:04:38 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:04:38 --> Router Class Initialized
INFO - 2021-07-14 15:04:38 --> Helper loaded: general_helper
INFO - 2021-07-14 15:04:38 --> Helper loaded: url_helper
INFO - 2021-07-14 15:04:38 --> Config Class Initialized
INFO - 2021-07-14 15:04:38 --> Output Class Initialized
INFO - 2021-07-14 15:04:38 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:04:38 --> Hooks Class Initialized
INFO - 2021-07-14 15:04:38 --> Helper loaded: file_helper
INFO - 2021-07-14 15:04:38 --> Security Class Initialized
DEBUG - 2021-07-14 15:04:38 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:04:38 --> Helper loaded: form_helper
INFO - 2021-07-14 15:04:38 --> Database Driver Class Initialized
INFO - 2021-07-14 15:04:38 --> Utf8 Class Initialized
DEBUG - 2021-07-14 15:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:04:38 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:04:38 --> Input Class Initialized
INFO - 2021-07-14 15:04:38 --> URI Class Initialized
INFO - 2021-07-14 15:04:38 --> Helper loaded: security_helper
INFO - 2021-07-14 15:04:38 --> Language Class Initialized
INFO - 2021-07-14 15:04:38 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:04:38 --> Router Class Initialized
INFO - 2021-07-14 15:04:38 --> Loader Class Initialized
INFO - 2021-07-14 15:04:38 --> Helper loaded: language_helper
INFO - 2021-07-14 15:04:38 --> Output Class Initialized
INFO - 2021-07-14 15:04:38 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:04:38 --> Helper loaded: general_helper
INFO - 2021-07-14 15:04:38 --> Security Class Initialized
INFO - 2021-07-14 15:04:38 --> Helper loaded: url_helper
INFO - 2021-07-14 15:04:38 --> Language file loaded: language/en/basic_lang.php
DEBUG - 2021-07-14 15:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:04:38 --> Helper loaded: file_helper
INFO - 2021-07-14 15:04:38 --> Input Class Initialized
INFO - 2021-07-14 15:04:38 --> Database Driver Class Initialized
INFO - 2021-07-14 15:04:38 --> Language Class Initialized
INFO - 2021-07-14 15:04:38 --> Helper loaded: form_helper
INFO - 2021-07-14 15:04:38 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:04:38 --> Loader Class Initialized
INFO - 2021-07-14 15:04:38 --> Helper loaded: security_helper
INFO - 2021-07-14 15:04:38 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:04:38 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:04:38 --> Helper loaded: directory_helper
DEBUG - 2021-07-14 15:04:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:04:38 --> Controller Class Initialized
INFO - 2021-07-14 15:04:38 --> Helper loaded: url_helper
INFO - 2021-07-14 15:04:38 --> Helper loaded: language_helper
INFO - 2021-07-14 15:04:38 --> Helper loaded: file_helper
INFO - 2021-07-14 15:04:38 --> Helper loaded: general_helper
INFO - 2021-07-14 15:04:38 --> Helper loaded: form_helper
INFO - 2021-07-14 15:04:38 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:04:38 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:04:38 --> Final output sent to browser
INFO - 2021-07-14 15:04:38 --> Database Driver Class Initialized
INFO - 2021-07-14 15:04:38 --> Helper loaded: security_helper
DEBUG - 2021-07-14 15:04:38 --> Total execution time: 0.0502
INFO - 2021-07-14 15:04:38 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:04:38 --> Helper loaded: language_helper
INFO - 2021-07-14 15:04:38 --> Parser Class Initialized
INFO - 2021-07-14 15:04:38 --> Helper loaded: general_helper
DEBUG - 2021-07-14 15:04:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:04:38 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:04:38 --> Form Validation Class Initialized
INFO - 2021-07-14 15:04:38 --> Database Driver Class Initialized
INFO - 2021-07-14 15:04:38 --> Upload Class Initialized
INFO - 2021-07-14 15:04:38 --> Email Class Initialized
INFO - 2021-07-14 15:04:38 --> MY_Model class loaded
INFO - 2021-07-14 15:04:38 --> Model "Users_model" initialized
DEBUG - 2021-07-14 15:04:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:04:38 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:04:38 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:04:38 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:04:38 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:04:38 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:04:38 --> Model "Templates_model" initialized
DEBUG - 2021-07-14 15:04:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:04:38 --> Database Driver Class Initialized
INFO - 2021-07-14 15:04:38 --> Config Class Initialized
INFO - 2021-07-14 15:04:38 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:04:38 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:04:38 --> Utf8 Class Initialized
INFO - 2021-07-14 15:04:38 --> URI Class Initialized
INFO - 2021-07-14 15:04:38 --> Router Class Initialized
INFO - 2021-07-14 15:04:38 --> Output Class Initialized
INFO - 2021-07-14 15:04:38 --> Security Class Initialized
DEBUG - 2021-07-14 15:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:04:38 --> Input Class Initialized
INFO - 2021-07-14 15:04:38 --> Language Class Initialized
INFO - 2021-07-14 15:04:38 --> Loader Class Initialized
INFO - 2021-07-14 15:04:38 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:04:38 --> Helper loaded: url_helper
INFO - 2021-07-14 15:04:38 --> Helper loaded: file_helper
INFO - 2021-07-14 15:04:38 --> Helper loaded: form_helper
INFO - 2021-07-14 15:04:38 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:04:38 --> Helper loaded: security_helper
INFO - 2021-07-14 15:04:38 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:04:38 --> Helper loaded: language_helper
INFO - 2021-07-14 15:04:38 --> Helper loaded: general_helper
INFO - 2021-07-14 15:04:38 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:04:38 --> Database Driver Class Initialized
DEBUG - 2021-07-14 15:04:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:04:38 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:04:38 --> Controller Class Initialized
INFO - 2021-07-14 15:04:38 --> Final output sent to browser
DEBUG - 2021-07-14 15:04:38 --> Total execution time: 0.0691
INFO - 2021-07-14 15:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:04:38 --> Parser Class Initialized
INFO - 2021-07-14 15:04:38 --> Form Validation Class Initialized
INFO - 2021-07-14 15:04:38 --> Upload Class Initialized
INFO - 2021-07-14 15:04:38 --> Email Class Initialized
INFO - 2021-07-14 15:04:38 --> MY_Model class loaded
INFO - 2021-07-14 15:04:38 --> Model "Users_model" initialized
INFO - 2021-07-14 15:04:38 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:04:38 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:04:38 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:04:38 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:04:38 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:04:38 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:04:38 --> Database Driver Class Initialized
INFO - 2021-07-14 15:04:38 --> Config Class Initialized
INFO - 2021-07-14 15:04:38 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:04:38 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:04:38 --> Utf8 Class Initialized
INFO - 2021-07-14 15:04:38 --> URI Class Initialized
INFO - 2021-07-14 15:04:38 --> Router Class Initialized
INFO - 2021-07-14 15:04:38 --> Output Class Initialized
INFO - 2021-07-14 15:04:38 --> Security Class Initialized
DEBUG - 2021-07-14 15:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:04:38 --> Input Class Initialized
INFO - 2021-07-14 15:04:38 --> Language Class Initialized
INFO - 2021-07-14 15:04:38 --> Loader Class Initialized
INFO - 2021-07-14 15:04:38 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:04:38 --> Helper loaded: url_helper
INFO - 2021-07-14 15:04:38 --> Helper loaded: file_helper
INFO - 2021-07-14 15:04:38 --> Helper loaded: form_helper
INFO - 2021-07-14 15:04:38 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:04:38 --> Helper loaded: security_helper
INFO - 2021-07-14 15:04:38 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:04:38 --> Helper loaded: language_helper
INFO - 2021-07-14 15:04:38 --> Helper loaded: general_helper
INFO - 2021-07-14 15:04:38 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:04:38 --> Database Driver Class Initialized
INFO - 2021-07-14 15:04:38 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:04:38 --> Controller Class Initialized
DEBUG - 2021-07-14 15:04:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:04:38 --> Final output sent to browser
DEBUG - 2021-07-14 15:04:38 --> Total execution time: 0.0856
INFO - 2021-07-14 15:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:04:38 --> Parser Class Initialized
INFO - 2021-07-14 15:04:38 --> Form Validation Class Initialized
INFO - 2021-07-14 15:04:38 --> Upload Class Initialized
INFO - 2021-07-14 15:04:38 --> Email Class Initialized
INFO - 2021-07-14 15:04:38 --> MY_Model class loaded
INFO - 2021-07-14 15:04:38 --> Model "Users_model" initialized
INFO - 2021-07-14 15:04:38 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:04:38 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:04:38 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:04:38 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:04:38 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:04:38 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:04:38 --> Database Driver Class Initialized
INFO - 2021-07-14 15:04:38 --> Config Class Initialized
INFO - 2021-07-14 15:04:38 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:04:38 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:04:38 --> Utf8 Class Initialized
INFO - 2021-07-14 15:04:38 --> URI Class Initialized
INFO - 2021-07-14 15:04:38 --> Router Class Initialized
INFO - 2021-07-14 15:04:38 --> Output Class Initialized
INFO - 2021-07-14 15:04:38 --> Security Class Initialized
DEBUG - 2021-07-14 15:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:04:38 --> Input Class Initialized
INFO - 2021-07-14 15:04:38 --> Language Class Initialized
INFO - 2021-07-14 15:04:38 --> Loader Class Initialized
INFO - 2021-07-14 15:04:38 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:04:38 --> Helper loaded: url_helper
INFO - 2021-07-14 15:04:38 --> Helper loaded: file_helper
INFO - 2021-07-14 15:04:38 --> Helper loaded: form_helper
INFO - 2021-07-14 15:04:38 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:04:38 --> Helper loaded: security_helper
INFO - 2021-07-14 15:04:38 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:04:38 --> Helper loaded: language_helper
INFO - 2021-07-14 15:04:38 --> Helper loaded: general_helper
INFO - 2021-07-14 15:04:38 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:04:38 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:04:38 --> Controller Class Initialized
INFO - 2021-07-14 15:04:38 --> Database Driver Class Initialized
INFO - 2021-07-14 15:04:38 --> Final output sent to browser
DEBUG - 2021-07-14 15:04:38 --> Total execution time: 0.1064
DEBUG - 2021-07-14 15:04:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:04:38 --> Parser Class Initialized
INFO - 2021-07-14 15:04:38 --> Form Validation Class Initialized
INFO - 2021-07-14 15:04:38 --> Upload Class Initialized
INFO - 2021-07-14 15:04:38 --> Email Class Initialized
INFO - 2021-07-14 15:04:38 --> MY_Model class loaded
INFO - 2021-07-14 15:04:38 --> Model "Users_model" initialized
INFO - 2021-07-14 15:04:38 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:04:38 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:04:38 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:04:38 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:04:38 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:04:38 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:04:38 --> Database Driver Class Initialized
INFO - 2021-07-14 15:04:39 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:04:39 --> Controller Class Initialized
INFO - 2021-07-14 15:04:39 --> Final output sent to browser
DEBUG - 2021-07-14 15:04:39 --> Total execution time: 0.1277
INFO - 2021-07-14 15:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:04:39 --> Parser Class Initialized
INFO - 2021-07-14 15:04:39 --> Form Validation Class Initialized
INFO - 2021-07-14 15:04:39 --> Upload Class Initialized
INFO - 2021-07-14 15:04:39 --> Email Class Initialized
INFO - 2021-07-14 15:04:39 --> MY_Model class loaded
INFO - 2021-07-14 15:04:39 --> Model "Users_model" initialized
INFO - 2021-07-14 15:04:39 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:04:39 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:04:39 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:04:39 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:04:39 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:04:39 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:04:39 --> Database Driver Class Initialized
INFO - 2021-07-14 15:04:39 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:04:39 --> Controller Class Initialized
INFO - 2021-07-14 15:04:39 --> Final output sent to browser
DEBUG - 2021-07-14 15:04:39 --> Total execution time: 0.1732
INFO - 2021-07-14 15:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:04:39 --> Parser Class Initialized
INFO - 2021-07-14 15:04:39 --> Form Validation Class Initialized
INFO - 2021-07-14 15:04:39 --> Upload Class Initialized
INFO - 2021-07-14 15:04:39 --> Email Class Initialized
INFO - 2021-07-14 15:04:39 --> MY_Model class loaded
INFO - 2021-07-14 15:04:39 --> Model "Users_model" initialized
INFO - 2021-07-14 15:04:39 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:04:39 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:04:39 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:04:39 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:04:39 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:04:39 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:04:39 --> Database Driver Class Initialized
INFO - 2021-07-14 15:04:39 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:04:39 --> Controller Class Initialized
INFO - 2021-07-14 15:04:39 --> Final output sent to browser
DEBUG - 2021-07-14 15:04:39 --> Total execution time: 0.1606
INFO - 2021-07-14 15:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:04:39 --> Parser Class Initialized
INFO - 2021-07-14 15:04:39 --> Form Validation Class Initialized
INFO - 2021-07-14 15:04:39 --> Upload Class Initialized
INFO - 2021-07-14 15:04:39 --> Email Class Initialized
INFO - 2021-07-14 15:04:39 --> MY_Model class loaded
INFO - 2021-07-14 15:04:39 --> Model "Users_model" initialized
INFO - 2021-07-14 15:04:39 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:04:39 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:04:39 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:04:39 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:04:39 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:04:39 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:04:39 --> Database Driver Class Initialized
INFO - 2021-07-14 15:04:39 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:04:39 --> Controller Class Initialized
INFO - 2021-07-14 15:04:39 --> Final output sent to browser
DEBUG - 2021-07-14 15:04:39 --> Total execution time: 0.1590
INFO - 2021-07-14 15:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:04:39 --> Parser Class Initialized
INFO - 2021-07-14 15:04:39 --> Form Validation Class Initialized
INFO - 2021-07-14 15:04:39 --> Upload Class Initialized
INFO - 2021-07-14 15:04:39 --> Email Class Initialized
INFO - 2021-07-14 15:04:39 --> MY_Model class loaded
INFO - 2021-07-14 15:04:39 --> Model "Users_model" initialized
INFO - 2021-07-14 15:04:39 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:04:39 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:04:39 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:04:39 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:04:39 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:04:39 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:04:39 --> Database Driver Class Initialized
INFO - 2021-07-14 15:04:39 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:04:39 --> Controller Class Initialized
INFO - 2021-07-14 15:04:39 --> Final output sent to browser
DEBUG - 2021-07-14 15:04:39 --> Total execution time: 0.1573
INFO - 2021-07-14 15:04:59 --> Config Class Initialized
INFO - 2021-07-14 15:04:59 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:04:59 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:04:59 --> Utf8 Class Initialized
INFO - 2021-07-14 15:04:59 --> URI Class Initialized
INFO - 2021-07-14 15:04:59 --> Router Class Initialized
INFO - 2021-07-14 15:04:59 --> Output Class Initialized
INFO - 2021-07-14 15:04:59 --> Security Class Initialized
DEBUG - 2021-07-14 15:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:04:59 --> Input Class Initialized
INFO - 2021-07-14 15:04:59 --> Language Class Initialized
INFO - 2021-07-14 15:04:59 --> Loader Class Initialized
INFO - 2021-07-14 15:04:59 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:04:59 --> Helper loaded: url_helper
INFO - 2021-07-14 15:04:59 --> Helper loaded: file_helper
INFO - 2021-07-14 15:04:59 --> Helper loaded: form_helper
INFO - 2021-07-14 15:04:59 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:04:59 --> Helper loaded: security_helper
INFO - 2021-07-14 15:04:59 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:04:59 --> Helper loaded: language_helper
INFO - 2021-07-14 15:04:59 --> Helper loaded: general_helper
INFO - 2021-07-14 15:04:59 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:04:59 --> Database Driver Class Initialized
DEBUG - 2021-07-14 15:04:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:04:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:04:59 --> Parser Class Initialized
INFO - 2021-07-14 15:04:59 --> Form Validation Class Initialized
INFO - 2021-07-14 15:04:59 --> Upload Class Initialized
INFO - 2021-07-14 15:04:59 --> Email Class Initialized
INFO - 2021-07-14 15:04:59 --> MY_Model class loaded
INFO - 2021-07-14 15:04:59 --> Model "Users_model" initialized
INFO - 2021-07-14 15:04:59 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:04:59 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:04:59 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:04:59 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:04:59 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:04:59 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:04:59 --> Database Driver Class Initialized
INFO - 2021-07-14 15:04:59 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:04:59 --> Controller Class Initialized
ERROR - 2021-07-14 15:04:59 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 15:04:59 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-14 15:04:59 --> Final output sent to browser
DEBUG - 2021-07-14 15:04:59 --> Total execution time: 0.2283
INFO - 2021-07-14 15:05:40 --> Config Class Initialized
INFO - 2021-07-14 15:05:40 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:05:40 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:05:40 --> Utf8 Class Initialized
INFO - 2021-07-14 15:05:40 --> URI Class Initialized
INFO - 2021-07-14 15:05:40 --> Router Class Initialized
INFO - 2021-07-14 15:05:40 --> Output Class Initialized
INFO - 2021-07-14 15:05:40 --> Security Class Initialized
DEBUG - 2021-07-14 15:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:05:40 --> Input Class Initialized
INFO - 2021-07-14 15:05:40 --> Language Class Initialized
INFO - 2021-07-14 15:05:40 --> Loader Class Initialized
INFO - 2021-07-14 15:05:40 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:05:40 --> Helper loaded: url_helper
INFO - 2021-07-14 15:05:40 --> Helper loaded: file_helper
INFO - 2021-07-14 15:05:40 --> Helper loaded: form_helper
INFO - 2021-07-14 15:05:40 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:05:40 --> Helper loaded: security_helper
INFO - 2021-07-14 15:05:40 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:05:40 --> Helper loaded: language_helper
INFO - 2021-07-14 15:05:40 --> Helper loaded: general_helper
INFO - 2021-07-14 15:05:40 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:05:40 --> Database Driver Class Initialized
DEBUG - 2021-07-14 15:05:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:05:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:05:40 --> Parser Class Initialized
INFO - 2021-07-14 15:05:40 --> Form Validation Class Initialized
INFO - 2021-07-14 15:05:40 --> Upload Class Initialized
INFO - 2021-07-14 15:05:40 --> Email Class Initialized
INFO - 2021-07-14 15:05:40 --> MY_Model class loaded
INFO - 2021-07-14 15:05:40 --> Model "Users_model" initialized
INFO - 2021-07-14 15:05:40 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:05:40 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:05:40 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:05:40 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:05:40 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:05:40 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:05:40 --> Database Driver Class Initialized
INFO - 2021-07-14 15:05:41 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:05:41 --> Controller Class Initialized
ERROR - 2021-07-14 15:05:41 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 15:05:41 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-14 15:05:41 --> Final output sent to browser
DEBUG - 2021-07-14 15:05:41 --> Total execution time: 0.1674
INFO - 2021-07-14 15:05:43 --> Config Class Initialized
INFO - 2021-07-14 15:05:43 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:05:43 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:05:43 --> Utf8 Class Initialized
INFO - 2021-07-14 15:05:43 --> URI Class Initialized
INFO - 2021-07-14 15:05:43 --> Router Class Initialized
INFO - 2021-07-14 15:05:43 --> Output Class Initialized
INFO - 2021-07-14 15:05:43 --> Security Class Initialized
DEBUG - 2021-07-14 15:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:05:43 --> Input Class Initialized
INFO - 2021-07-14 15:05:43 --> Language Class Initialized
INFO - 2021-07-14 15:05:43 --> Loader Class Initialized
INFO - 2021-07-14 15:05:43 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:05:43 --> Helper loaded: url_helper
INFO - 2021-07-14 15:05:43 --> Helper loaded: file_helper
INFO - 2021-07-14 15:05:43 --> Helper loaded: form_helper
INFO - 2021-07-14 15:05:43 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:05:43 --> Helper loaded: security_helper
INFO - 2021-07-14 15:05:43 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:05:43 --> Helper loaded: language_helper
INFO - 2021-07-14 15:05:43 --> Helper loaded: general_helper
INFO - 2021-07-14 15:05:43 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:05:43 --> Database Driver Class Initialized
DEBUG - 2021-07-14 15:05:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:05:43 --> Parser Class Initialized
INFO - 2021-07-14 15:05:43 --> Form Validation Class Initialized
INFO - 2021-07-14 15:05:43 --> Upload Class Initialized
INFO - 2021-07-14 15:05:43 --> Email Class Initialized
INFO - 2021-07-14 15:05:43 --> MY_Model class loaded
INFO - 2021-07-14 15:05:43 --> Model "Users_model" initialized
INFO - 2021-07-14 15:05:43 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:05:43 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:05:43 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:05:43 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:05:43 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:05:43 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:05:43 --> Database Driver Class Initialized
INFO - 2021-07-14 15:05:43 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:05:43 --> Controller Class Initialized
ERROR - 2021-07-14 15:05:43 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 15:05:43 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-14 15:05:43 --> Final output sent to browser
DEBUG - 2021-07-14 15:05:43 --> Total execution time: 0.0735
INFO - 2021-07-14 15:07:41 --> Config Class Initialized
INFO - 2021-07-14 15:07:41 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:07:41 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:07:41 --> Utf8 Class Initialized
INFO - 2021-07-14 15:07:41 --> URI Class Initialized
INFO - 2021-07-14 15:07:41 --> Router Class Initialized
INFO - 2021-07-14 15:07:41 --> Output Class Initialized
INFO - 2021-07-14 15:07:41 --> Security Class Initialized
DEBUG - 2021-07-14 15:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:07:41 --> Input Class Initialized
INFO - 2021-07-14 15:07:41 --> Language Class Initialized
INFO - 2021-07-14 15:07:41 --> Loader Class Initialized
INFO - 2021-07-14 15:07:41 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:07:41 --> Helper loaded: url_helper
INFO - 2021-07-14 15:07:41 --> Helper loaded: file_helper
INFO - 2021-07-14 15:07:41 --> Helper loaded: form_helper
INFO - 2021-07-14 15:07:41 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:07:41 --> Helper loaded: security_helper
INFO - 2021-07-14 15:07:41 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:07:41 --> Helper loaded: language_helper
INFO - 2021-07-14 15:07:41 --> Helper loaded: general_helper
INFO - 2021-07-14 15:07:41 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:07:41 --> Database Driver Class Initialized
DEBUG - 2021-07-14 15:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:07:41 --> Parser Class Initialized
INFO - 2021-07-14 15:07:41 --> Form Validation Class Initialized
INFO - 2021-07-14 15:07:41 --> Upload Class Initialized
INFO - 2021-07-14 15:07:41 --> Email Class Initialized
INFO - 2021-07-14 15:07:41 --> MY_Model class loaded
INFO - 2021-07-14 15:07:41 --> Model "Users_model" initialized
INFO - 2021-07-14 15:07:41 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:07:41 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:07:41 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:07:41 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:07:41 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:07:41 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:07:41 --> Database Driver Class Initialized
INFO - 2021-07-14 15:07:41 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:07:41 --> Controller Class Initialized
ERROR - 2021-07-14 15:07:41 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 15:07:41 --> File loaded: C:\wamp64\www\crm\application\views\users/list.php
INFO - 2021-07-14 15:07:41 --> Final output sent to browser
DEBUG - 2021-07-14 15:07:41 --> Total execution time: 0.1959
INFO - 2021-07-14 15:07:41 --> Config Class Initialized
INFO - 2021-07-14 15:07:41 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:07:41 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:07:41 --> Utf8 Class Initialized
INFO - 2021-07-14 15:07:41 --> URI Class Initialized
INFO - 2021-07-14 15:07:41 --> Router Class Initialized
INFO - 2021-07-14 15:07:41 --> Output Class Initialized
INFO - 2021-07-14 15:07:41 --> Security Class Initialized
DEBUG - 2021-07-14 15:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:07:41 --> Input Class Initialized
INFO - 2021-07-14 15:07:41 --> Language Class Initialized
INFO - 2021-07-14 15:07:41 --> Loader Class Initialized
INFO - 2021-07-14 15:07:41 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:07:41 --> Helper loaded: url_helper
INFO - 2021-07-14 15:07:41 --> Helper loaded: file_helper
INFO - 2021-07-14 15:07:41 --> Helper loaded: form_helper
INFO - 2021-07-14 15:07:41 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:07:41 --> Helper loaded: security_helper
INFO - 2021-07-14 15:07:41 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:07:41 --> Helper loaded: language_helper
INFO - 2021-07-14 15:07:41 --> Config Class Initialized
INFO - 2021-07-14 15:07:41 --> Hooks Class Initialized
INFO - 2021-07-14 15:07:41 --> Helper loaded: general_helper
DEBUG - 2021-07-14 15:07:41 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:07:41 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:07:41 --> Utf8 Class Initialized
INFO - 2021-07-14 15:07:41 --> Database Driver Class Initialized
INFO - 2021-07-14 15:07:41 --> URI Class Initialized
INFO - 2021-07-14 15:07:41 --> Router Class Initialized
INFO - 2021-07-14 15:07:41 --> Output Class Initialized
INFO - 2021-07-14 15:07:41 --> Security Class Initialized
DEBUG - 2021-07-14 15:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-07-14 15:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:07:41 --> Input Class Initialized
INFO - 2021-07-14 15:07:41 --> Config Class Initialized
INFO - 2021-07-14 15:07:41 --> Hooks Class Initialized
INFO - 2021-07-14 15:07:41 --> Language Class Initialized
INFO - 2021-07-14 15:07:41 --> Parser Class Initialized
DEBUG - 2021-07-14 15:07:41 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:07:41 --> Loader Class Initialized
INFO - 2021-07-14 15:07:41 --> Utf8 Class Initialized
INFO - 2021-07-14 15:07:41 --> Form Validation Class Initialized
INFO - 2021-07-14 15:07:41 --> URI Class Initialized
INFO - 2021-07-14 15:07:41 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:07:41 --> Upload Class Initialized
INFO - 2021-07-14 15:07:41 --> Helper loaded: url_helper
INFO - 2021-07-14 15:07:41 --> Router Class Initialized
INFO - 2021-07-14 15:07:41 --> Email Class Initialized
INFO - 2021-07-14 15:07:41 --> Helper loaded: file_helper
INFO - 2021-07-14 15:07:41 --> Output Class Initialized
INFO - 2021-07-14 15:07:41 --> MY_Model class loaded
INFO - 2021-07-14 15:07:41 --> Helper loaded: form_helper
INFO - 2021-07-14 15:07:41 --> Model "Users_model" initialized
INFO - 2021-07-14 15:07:41 --> Security Class Initialized
INFO - 2021-07-14 15:07:41 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:07:41 --> Config Class Initialized
INFO - 2021-07-14 15:07:41 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:07:41 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:07:41 --> Helper loaded: security_helper
INFO - 2021-07-14 15:07:41 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:07:41 --> Input Class Initialized
INFO - 2021-07-14 15:07:41 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:07:41 --> Model "Permissions_model" initialized
DEBUG - 2021-07-14 15:07:41 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:07:41 --> Language Class Initialized
INFO - 2021-07-14 15:07:41 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:07:41 --> Utf8 Class Initialized
INFO - 2021-07-14 15:07:41 --> Helper loaded: language_helper
INFO - 2021-07-14 15:07:41 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:07:41 --> URI Class Initialized
INFO - 2021-07-14 15:07:41 --> Loader Class Initialized
INFO - 2021-07-14 15:07:41 --> Helper loaded: general_helper
INFO - 2021-07-14 15:07:41 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:07:41 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:07:41 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:07:41 --> Router Class Initialized
INFO - 2021-07-14 15:07:41 --> Database Driver Class Initialized
INFO - 2021-07-14 15:07:41 --> Database Driver Class Initialized
INFO - 2021-07-14 15:07:41 --> Helper loaded: url_helper
INFO - 2021-07-14 15:07:41 --> Output Class Initialized
INFO - 2021-07-14 15:07:41 --> Helper loaded: file_helper
INFO - 2021-07-14 15:07:41 --> Security Class Initialized
INFO - 2021-07-14 15:07:41 --> Helper loaded: form_helper
DEBUG - 2021-07-14 15:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:07:41 --> Config Class Initialized
INFO - 2021-07-14 15:07:41 --> Input Class Initialized
INFO - 2021-07-14 15:07:41 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:07:41 --> Hooks Class Initialized
INFO - 2021-07-14 15:07:41 --> Language Class Initialized
DEBUG - 2021-07-14 15:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:07:41 --> Helper loaded: security_helper
DEBUG - 2021-07-14 15:07:41 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:07:41 --> Loader Class Initialized
INFO - 2021-07-14 15:07:41 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:07:41 --> Utf8 Class Initialized
INFO - 2021-07-14 15:07:41 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:07:41 --> Helper loaded: language_helper
INFO - 2021-07-14 15:07:41 --> URI Class Initialized
INFO - 2021-07-14 15:07:41 --> Helper loaded: general_helper
INFO - 2021-07-14 15:07:41 --> Helper loaded: url_helper
INFO - 2021-07-14 15:07:41 --> Router Class Initialized
INFO - 2021-07-14 15:07:41 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:07:41 --> Helper loaded: file_helper
INFO - 2021-07-14 15:07:41 --> Output Class Initialized
INFO - 2021-07-14 15:07:41 --> Database Driver Class Initialized
INFO - 2021-07-14 15:07:41 --> Helper loaded: form_helper
INFO - 2021-07-14 15:07:41 --> Security Class Initialized
INFO - 2021-07-14 15:07:41 --> Config Class Initialized
INFO - 2021-07-14 15:07:41 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:07:41 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:07:41 --> Helper loaded: security_helper
INFO - 2021-07-14 15:07:41 --> Input Class Initialized
DEBUG - 2021-07-14 15:07:41 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:07:41 --> Helper loaded: directory_helper
DEBUG - 2021-07-14 15:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:07:41 --> Language Class Initialized
INFO - 2021-07-14 15:07:41 --> Utf8 Class Initialized
INFO - 2021-07-14 15:07:41 --> Helper loaded: language_helper
INFO - 2021-07-14 15:07:41 --> URI Class Initialized
INFO - 2021-07-14 15:07:41 --> Loader Class Initialized
INFO - 2021-07-14 15:07:41 --> Helper loaded: general_helper
INFO - 2021-07-14 15:07:41 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:07:41 --> Router Class Initialized
INFO - 2021-07-14 15:07:41 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:07:41 --> Database Driver Class Initialized
INFO - 2021-07-14 15:07:41 --> Output Class Initialized
INFO - 2021-07-14 15:07:41 --> Helper loaded: url_helper
INFO - 2021-07-14 15:07:41 --> Security Class Initialized
INFO - 2021-07-14 15:07:41 --> Helper loaded: file_helper
DEBUG - 2021-07-14 15:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:07:41 --> Helper loaded: form_helper
INFO - 2021-07-14 15:07:41 --> Input Class Initialized
INFO - 2021-07-14 15:07:41 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:07:41 --> Language Class Initialized
DEBUG - 2021-07-14 15:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:07:41 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:07:41 --> Helper loaded: security_helper
INFO - 2021-07-14 15:07:41 --> Controller Class Initialized
INFO - 2021-07-14 15:07:41 --> Loader Class Initialized
INFO - 2021-07-14 15:07:41 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:07:41 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:07:41 --> Helper loaded: language_helper
INFO - 2021-07-14 15:07:41 --> Helper loaded: general_helper
INFO - 2021-07-14 15:07:41 --> Helper loaded: url_helper
INFO - 2021-07-14 15:07:41 --> Final output sent to browser
INFO - 2021-07-14 15:07:41 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:07:41 --> Helper loaded: file_helper
DEBUG - 2021-07-14 15:07:41 --> Total execution time: 0.0498
INFO - 2021-07-14 15:07:41 --> Helper loaded: form_helper
INFO - 2021-07-14 15:07:41 --> Database Driver Class Initialized
INFO - 2021-07-14 15:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:07:41 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:07:41 --> Parser Class Initialized
INFO - 2021-07-14 15:07:41 --> Helper loaded: security_helper
INFO - 2021-07-14 15:07:41 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:07:41 --> Form Validation Class Initialized
INFO - 2021-07-14 15:07:41 --> Helper loaded: language_helper
DEBUG - 2021-07-14 15:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:07:41 --> Helper loaded: general_helper
INFO - 2021-07-14 15:07:41 --> Upload Class Initialized
INFO - 2021-07-14 15:07:41 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:07:41 --> Email Class Initialized
INFO - 2021-07-14 15:07:41 --> Database Driver Class Initialized
INFO - 2021-07-14 15:07:41 --> MY_Model class loaded
INFO - 2021-07-14 15:07:41 --> Model "Users_model" initialized
INFO - 2021-07-14 15:07:41 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:07:41 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:07:41 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:07:41 --> Model "Roles_model" initialized
DEBUG - 2021-07-14 15:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:07:41 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:07:41 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:07:41 --> Database Driver Class Initialized
INFO - 2021-07-14 15:07:41 --> Config Class Initialized
INFO - 2021-07-14 15:07:41 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:07:41 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:07:41 --> Utf8 Class Initialized
INFO - 2021-07-14 15:07:41 --> URI Class Initialized
INFO - 2021-07-14 15:07:41 --> Router Class Initialized
INFO - 2021-07-14 15:07:41 --> Output Class Initialized
INFO - 2021-07-14 15:07:41 --> Security Class Initialized
DEBUG - 2021-07-14 15:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:07:41 --> Input Class Initialized
INFO - 2021-07-14 15:07:41 --> Language Class Initialized
INFO - 2021-07-14 15:07:41 --> Loader Class Initialized
INFO - 2021-07-14 15:07:41 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:07:41 --> Helper loaded: url_helper
INFO - 2021-07-14 15:07:41 --> Helper loaded: file_helper
INFO - 2021-07-14 15:07:41 --> Helper loaded: form_helper
INFO - 2021-07-14 15:07:41 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:07:41 --> Helper loaded: security_helper
INFO - 2021-07-14 15:07:41 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:07:41 --> Helper loaded: language_helper
INFO - 2021-07-14 15:07:41 --> Helper loaded: general_helper
INFO - 2021-07-14 15:07:41 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:07:41 --> Database Driver Class Initialized
INFO - 2021-07-14 15:07:41 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:07:41 --> Controller Class Initialized
DEBUG - 2021-07-14 15:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:07:41 --> Final output sent to browser
DEBUG - 2021-07-14 15:07:41 --> Total execution time: 0.0669
INFO - 2021-07-14 15:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:07:41 --> Parser Class Initialized
INFO - 2021-07-14 15:07:41 --> Form Validation Class Initialized
INFO - 2021-07-14 15:07:41 --> Upload Class Initialized
INFO - 2021-07-14 15:07:41 --> Email Class Initialized
INFO - 2021-07-14 15:07:41 --> MY_Model class loaded
INFO - 2021-07-14 15:07:41 --> Model "Users_model" initialized
INFO - 2021-07-14 15:07:41 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:07:41 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:07:41 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:07:41 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:07:41 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:07:41 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:07:41 --> Database Driver Class Initialized
INFO - 2021-07-14 15:07:41 --> Config Class Initialized
INFO - 2021-07-14 15:07:41 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:07:41 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:07:41 --> Utf8 Class Initialized
INFO - 2021-07-14 15:07:41 --> URI Class Initialized
INFO - 2021-07-14 15:07:41 --> Router Class Initialized
INFO - 2021-07-14 15:07:41 --> Output Class Initialized
INFO - 2021-07-14 15:07:41 --> Security Class Initialized
DEBUG - 2021-07-14 15:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:07:41 --> Input Class Initialized
INFO - 2021-07-14 15:07:41 --> Language Class Initialized
INFO - 2021-07-14 15:07:41 --> Loader Class Initialized
INFO - 2021-07-14 15:07:41 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:07:41 --> Helper loaded: url_helper
INFO - 2021-07-14 15:07:41 --> Helper loaded: file_helper
INFO - 2021-07-14 15:07:41 --> Helper loaded: form_helper
INFO - 2021-07-14 15:07:41 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:07:41 --> Helper loaded: security_helper
INFO - 2021-07-14 15:07:41 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:07:41 --> Helper loaded: language_helper
INFO - 2021-07-14 15:07:41 --> Helper loaded: general_helper
INFO - 2021-07-14 15:07:41 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:07:41 --> Database Driver Class Initialized
INFO - 2021-07-14 15:07:41 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:07:41 --> Controller Class Initialized
DEBUG - 2021-07-14 15:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:07:41 --> Final output sent to browser
DEBUG - 2021-07-14 15:07:41 --> Total execution time: 0.0899
INFO - 2021-07-14 15:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:07:41 --> Parser Class Initialized
INFO - 2021-07-14 15:07:41 --> Form Validation Class Initialized
INFO - 2021-07-14 15:07:41 --> Upload Class Initialized
INFO - 2021-07-14 15:07:41 --> Email Class Initialized
INFO - 2021-07-14 15:07:41 --> MY_Model class loaded
INFO - 2021-07-14 15:07:41 --> Model "Users_model" initialized
INFO - 2021-07-14 15:07:41 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:07:41 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:07:41 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:07:41 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:07:41 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:07:41 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:07:41 --> Database Driver Class Initialized
INFO - 2021-07-14 15:07:41 --> Config Class Initialized
INFO - 2021-07-14 15:07:41 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:07:41 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:07:41 --> Utf8 Class Initialized
INFO - 2021-07-14 15:07:41 --> URI Class Initialized
INFO - 2021-07-14 15:07:41 --> Router Class Initialized
INFO - 2021-07-14 15:07:41 --> Output Class Initialized
INFO - 2021-07-14 15:07:41 --> Security Class Initialized
DEBUG - 2021-07-14 15:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:07:41 --> Input Class Initialized
INFO - 2021-07-14 15:07:41 --> Language Class Initialized
INFO - 2021-07-14 15:07:41 --> Loader Class Initialized
INFO - 2021-07-14 15:07:41 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:07:41 --> Helper loaded: url_helper
INFO - 2021-07-14 15:07:41 --> Helper loaded: file_helper
INFO - 2021-07-14 15:07:41 --> Helper loaded: form_helper
INFO - 2021-07-14 15:07:41 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:07:41 --> Helper loaded: security_helper
INFO - 2021-07-14 15:07:41 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:07:41 --> Helper loaded: language_helper
INFO - 2021-07-14 15:07:41 --> Helper loaded: general_helper
INFO - 2021-07-14 15:07:41 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:07:41 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:07:41 --> Controller Class Initialized
INFO - 2021-07-14 15:07:41 --> Database Driver Class Initialized
INFO - 2021-07-14 15:07:41 --> Final output sent to browser
DEBUG - 2021-07-14 15:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-07-14 15:07:41 --> Total execution time: 0.1112
INFO - 2021-07-14 15:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:07:41 --> Parser Class Initialized
INFO - 2021-07-14 15:07:41 --> Form Validation Class Initialized
INFO - 2021-07-14 15:07:41 --> Upload Class Initialized
INFO - 2021-07-14 15:07:41 --> Email Class Initialized
INFO - 2021-07-14 15:07:41 --> MY_Model class loaded
INFO - 2021-07-14 15:07:41 --> Model "Users_model" initialized
INFO - 2021-07-14 15:07:41 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:07:41 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:07:41 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:07:41 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:07:41 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:07:41 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:07:41 --> Database Driver Class Initialized
INFO - 2021-07-14 15:07:41 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:07:41 --> Controller Class Initialized
INFO - 2021-07-14 15:07:41 --> Final output sent to browser
DEBUG - 2021-07-14 15:07:41 --> Total execution time: 0.1329
INFO - 2021-07-14 15:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:07:41 --> Parser Class Initialized
INFO - 2021-07-14 15:07:41 --> Form Validation Class Initialized
INFO - 2021-07-14 15:07:41 --> Upload Class Initialized
INFO - 2021-07-14 15:07:41 --> Email Class Initialized
INFO - 2021-07-14 15:07:41 --> MY_Model class loaded
INFO - 2021-07-14 15:07:41 --> Model "Users_model" initialized
INFO - 2021-07-14 15:07:41 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:07:41 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:07:41 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:07:41 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:07:41 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:07:41 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:07:41 --> Database Driver Class Initialized
INFO - 2021-07-14 15:07:41 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:07:41 --> Controller Class Initialized
INFO - 2021-07-14 15:07:41 --> Final output sent to browser
DEBUG - 2021-07-14 15:07:41 --> Total execution time: 0.1538
INFO - 2021-07-14 15:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:07:41 --> Parser Class Initialized
INFO - 2021-07-14 15:07:41 --> Form Validation Class Initialized
INFO - 2021-07-14 15:07:41 --> Upload Class Initialized
INFO - 2021-07-14 15:07:41 --> Email Class Initialized
INFO - 2021-07-14 15:07:41 --> MY_Model class loaded
INFO - 2021-07-14 15:07:41 --> Model "Users_model" initialized
INFO - 2021-07-14 15:07:41 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:07:41 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:07:41 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:07:41 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:07:41 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:07:41 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:07:41 --> Database Driver Class Initialized
INFO - 2021-07-14 15:07:41 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:07:41 --> Controller Class Initialized
INFO - 2021-07-14 15:07:41 --> Final output sent to browser
DEBUG - 2021-07-14 15:07:41 --> Total execution time: 0.1590
INFO - 2021-07-14 15:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:07:41 --> Parser Class Initialized
INFO - 2021-07-14 15:07:41 --> Form Validation Class Initialized
INFO - 2021-07-14 15:07:41 --> Upload Class Initialized
INFO - 2021-07-14 15:07:41 --> Email Class Initialized
INFO - 2021-07-14 15:07:41 --> MY_Model class loaded
INFO - 2021-07-14 15:07:41 --> Model "Users_model" initialized
INFO - 2021-07-14 15:07:41 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:07:41 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:07:41 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:07:41 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:07:41 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:07:41 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:07:41 --> Database Driver Class Initialized
INFO - 2021-07-14 15:07:42 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:07:42 --> Controller Class Initialized
INFO - 2021-07-14 15:07:42 --> Final output sent to browser
DEBUG - 2021-07-14 15:07:42 --> Total execution time: 0.1570
INFO - 2021-07-14 15:07:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:07:42 --> Parser Class Initialized
INFO - 2021-07-14 15:07:42 --> Form Validation Class Initialized
INFO - 2021-07-14 15:07:42 --> Upload Class Initialized
INFO - 2021-07-14 15:07:42 --> Email Class Initialized
INFO - 2021-07-14 15:07:42 --> MY_Model class loaded
INFO - 2021-07-14 15:07:42 --> Model "Users_model" initialized
INFO - 2021-07-14 15:07:42 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:07:42 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:07:42 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:07:42 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:07:42 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:07:42 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:07:42 --> Database Driver Class Initialized
INFO - 2021-07-14 15:07:42 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:07:42 --> Controller Class Initialized
INFO - 2021-07-14 15:07:42 --> Final output sent to browser
DEBUG - 2021-07-14 15:07:42 --> Total execution time: 0.1560
INFO - 2021-07-14 15:07:49 --> Config Class Initialized
INFO - 2021-07-14 15:07:49 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:07:49 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:07:49 --> Utf8 Class Initialized
INFO - 2021-07-14 15:07:49 --> URI Class Initialized
INFO - 2021-07-14 15:07:49 --> Router Class Initialized
INFO - 2021-07-14 15:07:49 --> Output Class Initialized
INFO - 2021-07-14 15:07:49 --> Security Class Initialized
DEBUG - 2021-07-14 15:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:07:49 --> Input Class Initialized
INFO - 2021-07-14 15:07:49 --> Language Class Initialized
INFO - 2021-07-14 15:07:49 --> Loader Class Initialized
INFO - 2021-07-14 15:07:49 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:07:49 --> Helper loaded: url_helper
INFO - 2021-07-14 15:07:49 --> Helper loaded: file_helper
INFO - 2021-07-14 15:07:49 --> Helper loaded: form_helper
INFO - 2021-07-14 15:07:49 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:07:49 --> Helper loaded: security_helper
INFO - 2021-07-14 15:07:49 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:07:49 --> Helper loaded: language_helper
INFO - 2021-07-14 15:07:49 --> Helper loaded: general_helper
INFO - 2021-07-14 15:07:49 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:07:49 --> Database Driver Class Initialized
DEBUG - 2021-07-14 15:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:07:49 --> Parser Class Initialized
INFO - 2021-07-14 15:07:49 --> Form Validation Class Initialized
INFO - 2021-07-14 15:07:49 --> Upload Class Initialized
INFO - 2021-07-14 15:07:49 --> Email Class Initialized
INFO - 2021-07-14 15:07:49 --> MY_Model class loaded
INFO - 2021-07-14 15:07:49 --> Model "Users_model" initialized
INFO - 2021-07-14 15:07:49 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:07:49 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:07:49 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:07:49 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:07:49 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:07:49 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:07:49 --> Database Driver Class Initialized
INFO - 2021-07-14 15:07:50 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:07:50 --> Controller Class Initialized
INFO - 2021-07-14 15:07:50 --> Final output sent to browser
DEBUG - 2021-07-14 15:07:50 --> Total execution time: 0.1202
INFO - 2021-07-14 15:07:50 --> Config Class Initialized
INFO - 2021-07-14 15:07:50 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:07:50 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:07:50 --> Utf8 Class Initialized
INFO - 2021-07-14 15:07:50 --> URI Class Initialized
INFO - 2021-07-14 15:07:50 --> Router Class Initialized
INFO - 2021-07-14 15:07:50 --> Output Class Initialized
INFO - 2021-07-14 15:07:50 --> Security Class Initialized
DEBUG - 2021-07-14 15:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:07:50 --> Input Class Initialized
INFO - 2021-07-14 15:07:50 --> Language Class Initialized
INFO - 2021-07-14 15:07:50 --> Loader Class Initialized
INFO - 2021-07-14 15:07:50 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:07:50 --> Helper loaded: url_helper
INFO - 2021-07-14 15:07:50 --> Helper loaded: file_helper
INFO - 2021-07-14 15:07:50 --> Helper loaded: form_helper
INFO - 2021-07-14 15:07:50 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:07:50 --> Helper loaded: security_helper
INFO - 2021-07-14 15:07:50 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:07:50 --> Helper loaded: language_helper
INFO - 2021-07-14 15:07:50 --> Helper loaded: general_helper
INFO - 2021-07-14 15:07:50 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:07:50 --> Database Driver Class Initialized
DEBUG - 2021-07-14 15:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:07:50 --> Parser Class Initialized
INFO - 2021-07-14 15:07:50 --> Form Validation Class Initialized
INFO - 2021-07-14 15:07:50 --> Upload Class Initialized
INFO - 2021-07-14 15:07:50 --> Email Class Initialized
INFO - 2021-07-14 15:07:50 --> MY_Model class loaded
INFO - 2021-07-14 15:07:50 --> Model "Users_model" initialized
INFO - 2021-07-14 15:07:50 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:07:50 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:07:50 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:07:50 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:07:50 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:07:50 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:07:50 --> Database Driver Class Initialized
INFO - 2021-07-14 15:07:50 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:07:50 --> Controller Class Initialized
INFO - 2021-07-14 15:07:50 --> Final output sent to browser
DEBUG - 2021-07-14 15:07:50 --> Total execution time: 0.0454
INFO - 2021-07-14 15:08:51 --> Config Class Initialized
INFO - 2021-07-14 15:08:51 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:08:51 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:08:51 --> Utf8 Class Initialized
INFO - 2021-07-14 15:08:51 --> URI Class Initialized
INFO - 2021-07-14 15:08:51 --> Router Class Initialized
INFO - 2021-07-14 15:08:51 --> Output Class Initialized
INFO - 2021-07-14 15:08:51 --> Security Class Initialized
DEBUG - 2021-07-14 15:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:08:51 --> Input Class Initialized
INFO - 2021-07-14 15:08:51 --> Language Class Initialized
INFO - 2021-07-14 15:08:51 --> Loader Class Initialized
INFO - 2021-07-14 15:08:51 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:08:51 --> Helper loaded: url_helper
INFO - 2021-07-14 15:08:51 --> Helper loaded: file_helper
INFO - 2021-07-14 15:08:51 --> Helper loaded: form_helper
INFO - 2021-07-14 15:08:51 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:08:51 --> Helper loaded: security_helper
INFO - 2021-07-14 15:08:51 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:08:51 --> Helper loaded: language_helper
INFO - 2021-07-14 15:08:51 --> Helper loaded: general_helper
INFO - 2021-07-14 15:08:51 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:08:51 --> Database Driver Class Initialized
DEBUG - 2021-07-14 15:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:08:51 --> Parser Class Initialized
INFO - 2021-07-14 15:08:51 --> Form Validation Class Initialized
INFO - 2021-07-14 15:08:51 --> Upload Class Initialized
INFO - 2021-07-14 15:08:51 --> Email Class Initialized
INFO - 2021-07-14 15:08:51 --> MY_Model class loaded
INFO - 2021-07-14 15:08:51 --> Model "Users_model" initialized
INFO - 2021-07-14 15:08:51 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:08:51 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:08:51 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:08:51 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:08:51 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:08:51 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:08:51 --> Database Driver Class Initialized
INFO - 2021-07-14 15:08:52 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:08:52 --> Controller Class Initialized
ERROR - 2021-07-14 15:08:52 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 15:08:52 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-14 15:08:52 --> Final output sent to browser
DEBUG - 2021-07-14 15:08:52 --> Total execution time: 0.8097
INFO - 2021-07-14 15:08:55 --> Config Class Initialized
INFO - 2021-07-14 15:08:55 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:08:55 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:08:55 --> Utf8 Class Initialized
INFO - 2021-07-14 15:08:55 --> URI Class Initialized
INFO - 2021-07-14 15:08:55 --> Router Class Initialized
INFO - 2021-07-14 15:08:55 --> Output Class Initialized
INFO - 2021-07-14 15:08:55 --> Security Class Initialized
DEBUG - 2021-07-14 15:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:08:55 --> Input Class Initialized
INFO - 2021-07-14 15:08:55 --> Language Class Initialized
INFO - 2021-07-14 15:08:55 --> Loader Class Initialized
INFO - 2021-07-14 15:08:55 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:08:55 --> Helper loaded: url_helper
INFO - 2021-07-14 15:08:55 --> Helper loaded: file_helper
INFO - 2021-07-14 15:08:55 --> Helper loaded: form_helper
INFO - 2021-07-14 15:08:55 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:08:55 --> Helper loaded: security_helper
INFO - 2021-07-14 15:08:55 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:08:55 --> Helper loaded: language_helper
INFO - 2021-07-14 15:08:55 --> Helper loaded: general_helper
INFO - 2021-07-14 15:08:55 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:08:55 --> Database Driver Class Initialized
DEBUG - 2021-07-14 15:08:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:08:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:08:55 --> Parser Class Initialized
INFO - 2021-07-14 15:08:55 --> Form Validation Class Initialized
INFO - 2021-07-14 15:08:55 --> Upload Class Initialized
INFO - 2021-07-14 15:08:55 --> Email Class Initialized
INFO - 2021-07-14 15:08:55 --> MY_Model class loaded
INFO - 2021-07-14 15:08:55 --> Model "Users_model" initialized
INFO - 2021-07-14 15:08:55 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:08:55 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:08:55 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:08:55 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:08:55 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:08:55 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:08:55 --> Database Driver Class Initialized
INFO - 2021-07-14 15:08:55 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:08:55 --> Controller Class Initialized
ERROR - 2021-07-14 15:08:55 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 15:08:56 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-14 15:08:56 --> Final output sent to browser
DEBUG - 2021-07-14 15:08:56 --> Total execution time: 0.2722
INFO - 2021-07-14 15:09:17 --> Config Class Initialized
INFO - 2021-07-14 15:09:17 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:09:17 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:09:17 --> Utf8 Class Initialized
INFO - 2021-07-14 15:09:17 --> URI Class Initialized
INFO - 2021-07-14 15:09:17 --> Router Class Initialized
INFO - 2021-07-14 15:09:17 --> Output Class Initialized
INFO - 2021-07-14 15:09:17 --> Security Class Initialized
DEBUG - 2021-07-14 15:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:09:17 --> Input Class Initialized
INFO - 2021-07-14 15:09:17 --> Language Class Initialized
INFO - 2021-07-14 15:09:17 --> Loader Class Initialized
INFO - 2021-07-14 15:09:17 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:09:17 --> Helper loaded: url_helper
INFO - 2021-07-14 15:09:17 --> Helper loaded: file_helper
INFO - 2021-07-14 15:09:17 --> Helper loaded: form_helper
INFO - 2021-07-14 15:09:17 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:09:17 --> Helper loaded: security_helper
INFO - 2021-07-14 15:09:17 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:09:17 --> Helper loaded: language_helper
INFO - 2021-07-14 15:09:17 --> Helper loaded: general_helper
INFO - 2021-07-14 15:09:17 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:09:17 --> Database Driver Class Initialized
DEBUG - 2021-07-14 15:09:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:09:17 --> Parser Class Initialized
INFO - 2021-07-14 15:09:17 --> Form Validation Class Initialized
INFO - 2021-07-14 15:09:17 --> Upload Class Initialized
INFO - 2021-07-14 15:09:17 --> Email Class Initialized
INFO - 2021-07-14 15:09:17 --> MY_Model class loaded
INFO - 2021-07-14 15:09:17 --> Model "Users_model" initialized
INFO - 2021-07-14 15:09:17 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:09:17 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:09:17 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:09:17 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:09:17 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:09:17 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:09:17 --> Database Driver Class Initialized
INFO - 2021-07-14 15:09:18 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:09:18 --> Controller Class Initialized
ERROR - 2021-07-14 15:09:18 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 15:09:18 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-14 15:09:18 --> Final output sent to browser
DEBUG - 2021-07-14 15:09:18 --> Total execution time: 0.1493
INFO - 2021-07-14 15:09:23 --> Config Class Initialized
INFO - 2021-07-14 15:09:23 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:09:23 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:09:23 --> Utf8 Class Initialized
INFO - 2021-07-14 15:09:23 --> URI Class Initialized
INFO - 2021-07-14 15:09:23 --> Router Class Initialized
INFO - 2021-07-14 15:09:23 --> Output Class Initialized
INFO - 2021-07-14 15:09:23 --> Security Class Initialized
DEBUG - 2021-07-14 15:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:09:23 --> Input Class Initialized
INFO - 2021-07-14 15:09:23 --> Language Class Initialized
INFO - 2021-07-14 15:09:23 --> Loader Class Initialized
INFO - 2021-07-14 15:09:23 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:09:23 --> Helper loaded: url_helper
INFO - 2021-07-14 15:09:23 --> Helper loaded: file_helper
INFO - 2021-07-14 15:09:23 --> Helper loaded: form_helper
INFO - 2021-07-14 15:09:23 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:09:23 --> Helper loaded: security_helper
INFO - 2021-07-14 15:09:23 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:09:23 --> Helper loaded: language_helper
INFO - 2021-07-14 15:09:23 --> Helper loaded: general_helper
INFO - 2021-07-14 15:09:23 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:09:23 --> Database Driver Class Initialized
DEBUG - 2021-07-14 15:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:09:23 --> Parser Class Initialized
INFO - 2021-07-14 15:09:23 --> Form Validation Class Initialized
INFO - 2021-07-14 15:09:23 --> Upload Class Initialized
INFO - 2021-07-14 15:09:23 --> Email Class Initialized
INFO - 2021-07-14 15:09:23 --> MY_Model class loaded
INFO - 2021-07-14 15:09:23 --> Model "Users_model" initialized
INFO - 2021-07-14 15:09:23 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:09:23 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:09:23 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:09:23 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:09:23 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:09:23 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:09:23 --> Database Driver Class Initialized
INFO - 2021-07-14 15:09:24 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:09:24 --> Controller Class Initialized
ERROR - 2021-07-14 15:09:24 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 15:09:24 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-14 15:09:24 --> Final output sent to browser
DEBUG - 2021-07-14 15:09:24 --> Total execution time: 0.3047
INFO - 2021-07-14 15:09:29 --> Config Class Initialized
INFO - 2021-07-14 15:09:29 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:09:29 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:09:29 --> Utf8 Class Initialized
INFO - 2021-07-14 15:09:29 --> URI Class Initialized
INFO - 2021-07-14 15:09:29 --> Router Class Initialized
INFO - 2021-07-14 15:09:29 --> Output Class Initialized
INFO - 2021-07-14 15:09:29 --> Security Class Initialized
DEBUG - 2021-07-14 15:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:09:29 --> Input Class Initialized
INFO - 2021-07-14 15:09:29 --> Language Class Initialized
INFO - 2021-07-14 15:09:29 --> Loader Class Initialized
INFO - 2021-07-14 15:09:29 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:09:29 --> Helper loaded: url_helper
INFO - 2021-07-14 15:09:29 --> Helper loaded: file_helper
INFO - 2021-07-14 15:09:29 --> Helper loaded: form_helper
INFO - 2021-07-14 15:09:29 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:09:29 --> Helper loaded: security_helper
INFO - 2021-07-14 15:09:29 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:09:29 --> Helper loaded: language_helper
INFO - 2021-07-14 15:09:29 --> Helper loaded: general_helper
INFO - 2021-07-14 15:09:29 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:09:29 --> Database Driver Class Initialized
DEBUG - 2021-07-14 15:09:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:09:29 --> Parser Class Initialized
INFO - 2021-07-14 15:09:29 --> Form Validation Class Initialized
INFO - 2021-07-14 15:09:29 --> Upload Class Initialized
INFO - 2021-07-14 15:09:29 --> Email Class Initialized
INFO - 2021-07-14 15:09:29 --> MY_Model class loaded
INFO - 2021-07-14 15:09:29 --> Model "Users_model" initialized
INFO - 2021-07-14 15:09:29 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:09:29 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:09:29 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:09:29 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:09:29 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:09:29 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:09:29 --> Database Driver Class Initialized
INFO - 2021-07-14 15:09:30 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:09:30 --> Controller Class Initialized
ERROR - 2021-07-14 15:09:30 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 15:09:30 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-14 15:09:30 --> Final output sent to browser
DEBUG - 2021-07-14 15:09:30 --> Total execution time: 0.1450
INFO - 2021-07-14 15:09:42 --> Config Class Initialized
INFO - 2021-07-14 15:09:42 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:09:42 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:09:42 --> Utf8 Class Initialized
INFO - 2021-07-14 15:09:42 --> URI Class Initialized
INFO - 2021-07-14 15:09:42 --> Router Class Initialized
INFO - 2021-07-14 15:09:42 --> Output Class Initialized
INFO - 2021-07-14 15:09:42 --> Security Class Initialized
DEBUG - 2021-07-14 15:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:09:42 --> Input Class Initialized
INFO - 2021-07-14 15:09:42 --> Language Class Initialized
INFO - 2021-07-14 15:09:42 --> Loader Class Initialized
INFO - 2021-07-14 15:09:42 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:09:42 --> Helper loaded: url_helper
INFO - 2021-07-14 15:09:42 --> Helper loaded: file_helper
INFO - 2021-07-14 15:09:42 --> Helper loaded: form_helper
INFO - 2021-07-14 15:09:42 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:09:42 --> Helper loaded: security_helper
INFO - 2021-07-14 15:09:42 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:09:42 --> Helper loaded: language_helper
INFO - 2021-07-14 15:09:42 --> Helper loaded: general_helper
INFO - 2021-07-14 15:09:42 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:09:42 --> Database Driver Class Initialized
DEBUG - 2021-07-14 15:09:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:09:42 --> Parser Class Initialized
INFO - 2021-07-14 15:09:42 --> Form Validation Class Initialized
INFO - 2021-07-14 15:09:42 --> Upload Class Initialized
INFO - 2021-07-14 15:09:42 --> Email Class Initialized
INFO - 2021-07-14 15:09:42 --> MY_Model class loaded
INFO - 2021-07-14 15:09:42 --> Model "Users_model" initialized
INFO - 2021-07-14 15:09:42 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:09:42 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:09:42 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:09:42 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:09:42 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:09:42 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:09:42 --> Database Driver Class Initialized
INFO - 2021-07-14 15:09:43 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:09:43 --> Controller Class Initialized
ERROR - 2021-07-14 15:09:43 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 15:09:43 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-14 15:09:43 --> Final output sent to browser
DEBUG - 2021-07-14 15:09:43 --> Total execution time: 0.3076
INFO - 2021-07-14 15:09:54 --> Config Class Initialized
INFO - 2021-07-14 15:09:54 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:09:54 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:09:54 --> Utf8 Class Initialized
INFO - 2021-07-14 15:09:54 --> URI Class Initialized
INFO - 2021-07-14 15:09:54 --> Router Class Initialized
INFO - 2021-07-14 15:09:54 --> Output Class Initialized
INFO - 2021-07-14 15:09:54 --> Security Class Initialized
DEBUG - 2021-07-14 15:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:09:54 --> Input Class Initialized
INFO - 2021-07-14 15:09:54 --> Language Class Initialized
INFO - 2021-07-14 15:09:54 --> Loader Class Initialized
INFO - 2021-07-14 15:09:54 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:09:54 --> Helper loaded: url_helper
INFO - 2021-07-14 15:09:54 --> Helper loaded: file_helper
INFO - 2021-07-14 15:09:54 --> Helper loaded: form_helper
INFO - 2021-07-14 15:09:54 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:09:54 --> Helper loaded: security_helper
INFO - 2021-07-14 15:09:54 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:09:54 --> Helper loaded: language_helper
INFO - 2021-07-14 15:09:54 --> Helper loaded: general_helper
INFO - 2021-07-14 15:09:54 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:09:54 --> Database Driver Class Initialized
DEBUG - 2021-07-14 15:09:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:09:54 --> Parser Class Initialized
INFO - 2021-07-14 15:09:54 --> Form Validation Class Initialized
INFO - 2021-07-14 15:09:54 --> Upload Class Initialized
INFO - 2021-07-14 15:09:54 --> Email Class Initialized
INFO - 2021-07-14 15:09:54 --> MY_Model class loaded
INFO - 2021-07-14 15:09:54 --> Model "Users_model" initialized
INFO - 2021-07-14 15:09:54 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:09:54 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:09:54 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:09:54 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:09:54 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:09:54 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:09:54 --> Database Driver Class Initialized
INFO - 2021-07-14 15:09:54 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:09:54 --> Controller Class Initialized
ERROR - 2021-07-14 15:09:54 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 15:09:54 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-14 15:09:54 --> Final output sent to browser
DEBUG - 2021-07-14 15:09:54 --> Total execution time: 0.1429
INFO - 2021-07-14 15:10:03 --> Config Class Initialized
INFO - 2021-07-14 15:10:03 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:10:03 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:10:03 --> Utf8 Class Initialized
INFO - 2021-07-14 15:10:03 --> URI Class Initialized
INFO - 2021-07-14 15:10:03 --> Router Class Initialized
INFO - 2021-07-14 15:10:03 --> Output Class Initialized
INFO - 2021-07-14 15:10:03 --> Security Class Initialized
DEBUG - 2021-07-14 15:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:10:03 --> Input Class Initialized
INFO - 2021-07-14 15:10:03 --> Language Class Initialized
INFO - 2021-07-14 15:10:03 --> Loader Class Initialized
INFO - 2021-07-14 15:10:03 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:10:03 --> Helper loaded: url_helper
INFO - 2021-07-14 15:10:03 --> Helper loaded: file_helper
INFO - 2021-07-14 15:10:03 --> Helper loaded: form_helper
INFO - 2021-07-14 15:10:03 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:10:03 --> Helper loaded: security_helper
INFO - 2021-07-14 15:10:03 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:10:03 --> Helper loaded: language_helper
INFO - 2021-07-14 15:10:03 --> Helper loaded: general_helper
INFO - 2021-07-14 15:10:03 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:10:03 --> Database Driver Class Initialized
DEBUG - 2021-07-14 15:10:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:10:03 --> Parser Class Initialized
INFO - 2021-07-14 15:10:03 --> Form Validation Class Initialized
INFO - 2021-07-14 15:10:03 --> Upload Class Initialized
INFO - 2021-07-14 15:10:03 --> Email Class Initialized
INFO - 2021-07-14 15:10:03 --> MY_Model class loaded
INFO - 2021-07-14 15:10:03 --> Model "Users_model" initialized
INFO - 2021-07-14 15:10:03 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:10:03 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:10:03 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:10:03 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:10:03 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:10:03 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:10:03 --> Database Driver Class Initialized
INFO - 2021-07-14 15:10:04 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:10:04 --> Controller Class Initialized
ERROR - 2021-07-14 15:10:04 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 15:10:04 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-14 15:10:04 --> Final output sent to browser
DEBUG - 2021-07-14 15:10:04 --> Total execution time: 0.2959
INFO - 2021-07-14 15:10:14 --> Config Class Initialized
INFO - 2021-07-14 15:10:14 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:10:14 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:10:14 --> Utf8 Class Initialized
INFO - 2021-07-14 15:10:14 --> URI Class Initialized
INFO - 2021-07-14 15:10:14 --> Router Class Initialized
INFO - 2021-07-14 15:10:14 --> Output Class Initialized
INFO - 2021-07-14 15:10:14 --> Security Class Initialized
DEBUG - 2021-07-14 15:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:10:14 --> Input Class Initialized
INFO - 2021-07-14 15:10:14 --> Language Class Initialized
INFO - 2021-07-14 15:10:14 --> Loader Class Initialized
INFO - 2021-07-14 15:10:14 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:10:14 --> Helper loaded: url_helper
INFO - 2021-07-14 15:10:14 --> Helper loaded: file_helper
INFO - 2021-07-14 15:10:14 --> Helper loaded: form_helper
INFO - 2021-07-14 15:10:14 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:10:14 --> Helper loaded: security_helper
INFO - 2021-07-14 15:10:14 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:10:14 --> Helper loaded: language_helper
INFO - 2021-07-14 15:10:14 --> Helper loaded: general_helper
INFO - 2021-07-14 15:10:14 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:10:14 --> Database Driver Class Initialized
DEBUG - 2021-07-14 15:10:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:10:14 --> Parser Class Initialized
INFO - 2021-07-14 15:10:14 --> Form Validation Class Initialized
INFO - 2021-07-14 15:10:14 --> Upload Class Initialized
INFO - 2021-07-14 15:10:14 --> Email Class Initialized
INFO - 2021-07-14 15:10:14 --> MY_Model class loaded
INFO - 2021-07-14 15:10:14 --> Model "Users_model" initialized
INFO - 2021-07-14 15:10:14 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:10:14 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:10:14 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:10:14 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:10:14 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:10:14 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:10:14 --> Database Driver Class Initialized
INFO - 2021-07-14 15:10:14 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:10:14 --> Controller Class Initialized
ERROR - 2021-07-14 15:10:14 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 15:10:14 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-14 15:10:14 --> Final output sent to browser
DEBUG - 2021-07-14 15:10:14 --> Total execution time: 0.1321
INFO - 2021-07-14 15:10:18 --> Config Class Initialized
INFO - 2021-07-14 15:10:18 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:10:18 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:10:18 --> Utf8 Class Initialized
INFO - 2021-07-14 15:10:18 --> URI Class Initialized
INFO - 2021-07-14 15:10:18 --> Router Class Initialized
INFO - 2021-07-14 15:10:18 --> Output Class Initialized
INFO - 2021-07-14 15:10:18 --> Security Class Initialized
DEBUG - 2021-07-14 15:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:10:18 --> Input Class Initialized
INFO - 2021-07-14 15:10:18 --> Language Class Initialized
INFO - 2021-07-14 15:10:18 --> Loader Class Initialized
INFO - 2021-07-14 15:10:18 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:10:18 --> Helper loaded: url_helper
INFO - 2021-07-14 15:10:18 --> Helper loaded: file_helper
INFO - 2021-07-14 15:10:18 --> Helper loaded: form_helper
INFO - 2021-07-14 15:10:18 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:10:18 --> Helper loaded: security_helper
INFO - 2021-07-14 15:10:18 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:10:18 --> Helper loaded: language_helper
INFO - 2021-07-14 15:10:18 --> Helper loaded: general_helper
INFO - 2021-07-14 15:10:18 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:10:18 --> Database Driver Class Initialized
DEBUG - 2021-07-14 15:10:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:10:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:10:18 --> Parser Class Initialized
INFO - 2021-07-14 15:10:18 --> Form Validation Class Initialized
INFO - 2021-07-14 15:10:18 --> Upload Class Initialized
INFO - 2021-07-14 15:10:18 --> Email Class Initialized
INFO - 2021-07-14 15:10:18 --> MY_Model class loaded
INFO - 2021-07-14 15:10:18 --> Model "Users_model" initialized
INFO - 2021-07-14 15:10:18 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:10:18 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:10:18 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:10:18 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:10:18 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:10:18 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:10:18 --> Database Driver Class Initialized
INFO - 2021-07-14 15:10:18 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:10:18 --> Controller Class Initialized
ERROR - 2021-07-14 15:10:18 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 15:10:18 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-14 15:10:18 --> Final output sent to browser
DEBUG - 2021-07-14 15:10:18 --> Total execution time: 0.2077
INFO - 2021-07-14 15:10:29 --> Config Class Initialized
INFO - 2021-07-14 15:10:29 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:10:29 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:10:29 --> Utf8 Class Initialized
INFO - 2021-07-14 15:10:29 --> URI Class Initialized
INFO - 2021-07-14 15:10:29 --> Router Class Initialized
INFO - 2021-07-14 15:10:29 --> Output Class Initialized
INFO - 2021-07-14 15:10:29 --> Security Class Initialized
DEBUG - 2021-07-14 15:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:10:29 --> Input Class Initialized
INFO - 2021-07-14 15:10:29 --> Language Class Initialized
INFO - 2021-07-14 15:10:29 --> Loader Class Initialized
INFO - 2021-07-14 15:10:29 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:10:29 --> Helper loaded: url_helper
INFO - 2021-07-14 15:10:29 --> Helper loaded: file_helper
INFO - 2021-07-14 15:10:29 --> Helper loaded: form_helper
INFO - 2021-07-14 15:10:29 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:10:29 --> Helper loaded: security_helper
INFO - 2021-07-14 15:10:29 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:10:29 --> Helper loaded: language_helper
INFO - 2021-07-14 15:10:29 --> Helper loaded: general_helper
INFO - 2021-07-14 15:10:29 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:10:29 --> Database Driver Class Initialized
DEBUG - 2021-07-14 15:10:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:10:29 --> Parser Class Initialized
INFO - 2021-07-14 15:10:29 --> Form Validation Class Initialized
INFO - 2021-07-14 15:10:29 --> Upload Class Initialized
INFO - 2021-07-14 15:10:29 --> Email Class Initialized
INFO - 2021-07-14 15:10:29 --> MY_Model class loaded
INFO - 2021-07-14 15:10:29 --> Model "Users_model" initialized
INFO - 2021-07-14 15:10:29 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:10:29 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:10:29 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:10:29 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:10:29 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:10:29 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:10:29 --> Database Driver Class Initialized
INFO - 2021-07-14 15:10:29 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:10:29 --> Controller Class Initialized
ERROR - 2021-07-14 15:10:29 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 15:10:29 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-14 15:10:29 --> Final output sent to browser
DEBUG - 2021-07-14 15:10:29 --> Total execution time: 0.1526
INFO - 2021-07-14 15:11:13 --> Config Class Initialized
INFO - 2021-07-14 15:11:13 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:11:13 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:11:13 --> Utf8 Class Initialized
INFO - 2021-07-14 15:11:13 --> URI Class Initialized
INFO - 2021-07-14 15:11:13 --> Router Class Initialized
INFO - 2021-07-14 15:11:13 --> Output Class Initialized
INFO - 2021-07-14 15:11:13 --> Security Class Initialized
DEBUG - 2021-07-14 15:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:11:13 --> Input Class Initialized
INFO - 2021-07-14 15:11:13 --> Language Class Initialized
INFO - 2021-07-14 15:11:13 --> Loader Class Initialized
INFO - 2021-07-14 15:11:13 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:11:13 --> Helper loaded: url_helper
INFO - 2021-07-14 15:11:13 --> Helper loaded: file_helper
INFO - 2021-07-14 15:11:13 --> Helper loaded: form_helper
INFO - 2021-07-14 15:11:13 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:11:13 --> Helper loaded: security_helper
INFO - 2021-07-14 15:11:13 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:11:13 --> Helper loaded: language_helper
INFO - 2021-07-14 15:11:13 --> Helper loaded: general_helper
INFO - 2021-07-14 15:11:13 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:11:13 --> Database Driver Class Initialized
DEBUG - 2021-07-14 15:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:11:13 --> Parser Class Initialized
INFO - 2021-07-14 15:11:13 --> Form Validation Class Initialized
INFO - 2021-07-14 15:11:13 --> Upload Class Initialized
INFO - 2021-07-14 15:11:13 --> Email Class Initialized
INFO - 2021-07-14 15:11:13 --> MY_Model class loaded
INFO - 2021-07-14 15:11:13 --> Model "Users_model" initialized
INFO - 2021-07-14 15:11:13 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:11:13 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:11:13 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:11:13 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:11:13 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:11:13 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:11:13 --> Database Driver Class Initialized
INFO - 2021-07-14 15:11:13 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:11:13 --> Controller Class Initialized
ERROR - 2021-07-14 15:11:13 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 15:11:13 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-14 15:11:13 --> Final output sent to browser
DEBUG - 2021-07-14 15:11:13 --> Total execution time: 0.2970
INFO - 2021-07-14 15:11:16 --> Config Class Initialized
INFO - 2021-07-14 15:11:16 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:11:16 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:11:16 --> Utf8 Class Initialized
INFO - 2021-07-14 15:11:16 --> URI Class Initialized
INFO - 2021-07-14 15:11:16 --> Router Class Initialized
INFO - 2021-07-14 15:11:16 --> Output Class Initialized
INFO - 2021-07-14 15:11:16 --> Security Class Initialized
DEBUG - 2021-07-14 15:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:11:16 --> Input Class Initialized
INFO - 2021-07-14 15:11:16 --> Language Class Initialized
INFO - 2021-07-14 15:11:16 --> Loader Class Initialized
INFO - 2021-07-14 15:11:16 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:11:16 --> Helper loaded: url_helper
INFO - 2021-07-14 15:11:16 --> Helper loaded: file_helper
INFO - 2021-07-14 15:11:16 --> Helper loaded: form_helper
INFO - 2021-07-14 15:11:16 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:11:16 --> Helper loaded: security_helper
INFO - 2021-07-14 15:11:16 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:11:16 --> Helper loaded: language_helper
INFO - 2021-07-14 15:11:16 --> Helper loaded: general_helper
INFO - 2021-07-14 15:11:16 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:11:16 --> Database Driver Class Initialized
DEBUG - 2021-07-14 15:11:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:11:16 --> Parser Class Initialized
INFO - 2021-07-14 15:11:16 --> Form Validation Class Initialized
INFO - 2021-07-14 15:11:16 --> Upload Class Initialized
INFO - 2021-07-14 15:11:16 --> Email Class Initialized
INFO - 2021-07-14 15:11:16 --> MY_Model class loaded
INFO - 2021-07-14 15:11:16 --> Model "Users_model" initialized
INFO - 2021-07-14 15:11:16 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:11:16 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:11:16 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:11:16 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:11:16 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:11:16 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:11:16 --> Database Driver Class Initialized
INFO - 2021-07-14 15:11:16 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:11:16 --> Controller Class Initialized
ERROR - 2021-07-14 15:11:16 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 15:11:16 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-14 15:11:16 --> Final output sent to browser
DEBUG - 2021-07-14 15:11:16 --> Total execution time: 0.0673
INFO - 2021-07-14 15:15:17 --> Config Class Initialized
INFO - 2021-07-14 15:15:17 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:15:17 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:15:17 --> Utf8 Class Initialized
INFO - 2021-07-14 15:15:17 --> URI Class Initialized
INFO - 2021-07-14 15:15:17 --> Router Class Initialized
INFO - 2021-07-14 15:15:17 --> Output Class Initialized
INFO - 2021-07-14 15:15:17 --> Security Class Initialized
DEBUG - 2021-07-14 15:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:15:17 --> Input Class Initialized
INFO - 2021-07-14 15:15:17 --> Language Class Initialized
INFO - 2021-07-14 15:15:17 --> Loader Class Initialized
INFO - 2021-07-14 15:15:17 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:15:17 --> Helper loaded: url_helper
INFO - 2021-07-14 15:15:17 --> Helper loaded: file_helper
INFO - 2021-07-14 15:15:17 --> Helper loaded: form_helper
INFO - 2021-07-14 15:15:17 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:15:17 --> Helper loaded: security_helper
INFO - 2021-07-14 15:15:17 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:15:17 --> Helper loaded: language_helper
INFO - 2021-07-14 15:15:17 --> Helper loaded: general_helper
INFO - 2021-07-14 15:15:17 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:15:17 --> Database Driver Class Initialized
DEBUG - 2021-07-14 15:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:15:17 --> Parser Class Initialized
INFO - 2021-07-14 15:15:17 --> Form Validation Class Initialized
INFO - 2021-07-14 15:15:17 --> Upload Class Initialized
INFO - 2021-07-14 15:15:17 --> Email Class Initialized
INFO - 2021-07-14 15:15:17 --> MY_Model class loaded
INFO - 2021-07-14 15:15:17 --> Model "Users_model" initialized
INFO - 2021-07-14 15:15:17 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:15:17 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:15:17 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:15:17 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:15:17 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:15:17 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:15:17 --> Database Driver Class Initialized
INFO - 2021-07-14 15:15:17 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:15:17 --> Controller Class Initialized
ERROR - 2021-07-14 15:15:17 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 15:15:17 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-14 15:15:17 --> Final output sent to browser
DEBUG - 2021-07-14 15:15:17 --> Total execution time: 0.3090
INFO - 2021-07-14 15:20:34 --> Config Class Initialized
INFO - 2021-07-14 15:20:34 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:20:34 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:20:34 --> Utf8 Class Initialized
INFO - 2021-07-14 15:20:34 --> URI Class Initialized
INFO - 2021-07-14 15:20:34 --> Router Class Initialized
INFO - 2021-07-14 15:20:34 --> Output Class Initialized
INFO - 2021-07-14 15:20:34 --> Security Class Initialized
DEBUG - 2021-07-14 15:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:20:34 --> Input Class Initialized
INFO - 2021-07-14 15:20:34 --> Language Class Initialized
ERROR - 2021-07-14 15:20:34 --> 404 Page Not Found: DevMgmt/DiscoveryTree.xml
INFO - 2021-07-14 15:21:39 --> Config Class Initialized
INFO - 2021-07-14 15:21:39 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:21:39 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:21:39 --> Utf8 Class Initialized
INFO - 2021-07-14 15:21:39 --> URI Class Initialized
DEBUG - 2021-07-14 15:21:39 --> No URI present. Default controller set.
INFO - 2021-07-14 15:21:39 --> Router Class Initialized
INFO - 2021-07-14 15:21:39 --> Output Class Initialized
INFO - 2021-07-14 15:21:39 --> Security Class Initialized
DEBUG - 2021-07-14 15:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:21:39 --> Input Class Initialized
INFO - 2021-07-14 15:21:39 --> Language Class Initialized
INFO - 2021-07-14 15:21:39 --> Loader Class Initialized
INFO - 2021-07-14 15:21:39 --> Helper loaded: basic_helper
INFO - 2021-07-14 15:21:39 --> Helper loaded: url_helper
INFO - 2021-07-14 15:21:39 --> Helper loaded: file_helper
INFO - 2021-07-14 15:21:39 --> Helper loaded: form_helper
INFO - 2021-07-14 15:21:39 --> Helper loaded: cookie_helper
INFO - 2021-07-14 15:21:39 --> Helper loaded: security_helper
INFO - 2021-07-14 15:21:39 --> Helper loaded: directory_helper
INFO - 2021-07-14 15:21:39 --> Helper loaded: language_helper
INFO - 2021-07-14 15:21:39 --> Helper loaded: general_helper
INFO - 2021-07-14 15:21:39 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 15:21:39 --> Database Driver Class Initialized
DEBUG - 2021-07-14 15:21:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 15:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 15:21:39 --> Parser Class Initialized
INFO - 2021-07-14 15:21:39 --> Form Validation Class Initialized
INFO - 2021-07-14 15:21:39 --> Upload Class Initialized
INFO - 2021-07-14 15:21:39 --> Email Class Initialized
INFO - 2021-07-14 15:21:39 --> MY_Model class loaded
INFO - 2021-07-14 15:21:39 --> Model "Users_model" initialized
INFO - 2021-07-14 15:21:39 --> Model "Settings_model" initialized
INFO - 2021-07-14 15:21:39 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 15:21:39 --> Model "Permissions_model" initialized
INFO - 2021-07-14 15:21:39 --> Model "Roles_model" initialized
INFO - 2021-07-14 15:21:39 --> Model "Activity_model" initialized
INFO - 2021-07-14 15:21:39 --> Model "Templates_model" initialized
INFO - 2021-07-14 15:21:39 --> Database Driver Class Initialized
INFO - 2021-07-14 15:21:39 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 15:21:39 --> Controller Class Initialized
INFO - 2021-07-14 15:22:43 --> Config Class Initialized
INFO - 2021-07-14 15:22:43 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:22:43 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:22:43 --> Utf8 Class Initialized
INFO - 2021-07-14 15:22:43 --> URI Class Initialized
INFO - 2021-07-14 15:22:43 --> Router Class Initialized
INFO - 2021-07-14 15:22:43 --> Output Class Initialized
INFO - 2021-07-14 15:22:43 --> Security Class Initialized
DEBUG - 2021-07-14 15:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:22:43 --> Input Class Initialized
INFO - 2021-07-14 15:22:43 --> Language Class Initialized
ERROR - 2021-07-14 15:22:43 --> 404 Page Not Found: DevMgmt/DiscoveryTree.xml
INFO - 2021-07-14 15:35:59 --> Config Class Initialized
INFO - 2021-07-14 15:35:59 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:35:59 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:35:59 --> Utf8 Class Initialized
INFO - 2021-07-14 15:35:59 --> URI Class Initialized
INFO - 2021-07-14 15:35:59 --> Router Class Initialized
INFO - 2021-07-14 15:35:59 --> Output Class Initialized
INFO - 2021-07-14 15:35:59 --> Security Class Initialized
DEBUG - 2021-07-14 15:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:35:59 --> Input Class Initialized
INFO - 2021-07-14 15:35:59 --> Language Class Initialized
ERROR - 2021-07-14 15:35:59 --> 404 Page Not Found: DevMgmt/DiscoveryTree.xml
INFO - 2021-07-14 15:37:18 --> Config Class Initialized
INFO - 2021-07-14 15:37:18 --> Hooks Class Initialized
DEBUG - 2021-07-14 15:37:18 --> UTF-8 Support Enabled
INFO - 2021-07-14 15:37:18 --> Utf8 Class Initialized
INFO - 2021-07-14 15:37:18 --> URI Class Initialized
INFO - 2021-07-14 15:37:18 --> Router Class Initialized
INFO - 2021-07-14 15:37:18 --> Output Class Initialized
INFO - 2021-07-14 15:37:18 --> Security Class Initialized
DEBUG - 2021-07-14 15:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 15:37:18 --> Input Class Initialized
INFO - 2021-07-14 15:37:18 --> Language Class Initialized
ERROR - 2021-07-14 15:37:18 --> 404 Page Not Found: DevMgmt/DiscoveryTree.xml
INFO - 2021-07-14 16:46:48 --> Config Class Initialized
INFO - 2021-07-14 16:46:48 --> Hooks Class Initialized
DEBUG - 2021-07-14 16:46:48 --> UTF-8 Support Enabled
INFO - 2021-07-14 16:46:48 --> Utf8 Class Initialized
INFO - 2021-07-14 16:46:48 --> URI Class Initialized
DEBUG - 2021-07-14 16:46:48 --> No URI present. Default controller set.
INFO - 2021-07-14 16:46:48 --> Router Class Initialized
INFO - 2021-07-14 16:46:48 --> Output Class Initialized
INFO - 2021-07-14 16:46:48 --> Security Class Initialized
DEBUG - 2021-07-14 16:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 16:46:48 --> Input Class Initialized
INFO - 2021-07-14 16:46:48 --> Language Class Initialized
INFO - 2021-07-14 16:46:48 --> Loader Class Initialized
INFO - 2021-07-14 16:46:48 --> Helper loaded: basic_helper
INFO - 2021-07-14 16:46:48 --> Helper loaded: url_helper
INFO - 2021-07-14 16:46:48 --> Helper loaded: file_helper
INFO - 2021-07-14 16:46:48 --> Helper loaded: form_helper
INFO - 2021-07-14 16:46:48 --> Helper loaded: cookie_helper
INFO - 2021-07-14 16:46:48 --> Helper loaded: security_helper
INFO - 2021-07-14 16:46:48 --> Helper loaded: directory_helper
INFO - 2021-07-14 16:46:48 --> Helper loaded: language_helper
INFO - 2021-07-14 16:46:48 --> Helper loaded: general_helper
INFO - 2021-07-14 16:46:48 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 16:46:48 --> Database Driver Class Initialized
DEBUG - 2021-07-14 16:46:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 16:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 16:46:48 --> Parser Class Initialized
INFO - 2021-07-14 16:46:48 --> Form Validation Class Initialized
INFO - 2021-07-14 16:46:48 --> Upload Class Initialized
INFO - 2021-07-14 16:46:48 --> Email Class Initialized
INFO - 2021-07-14 16:46:48 --> MY_Model class loaded
INFO - 2021-07-14 16:46:48 --> Model "Users_model" initialized
INFO - 2021-07-14 16:46:48 --> Model "Settings_model" initialized
INFO - 2021-07-14 16:46:48 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 16:46:48 --> Model "Permissions_model" initialized
INFO - 2021-07-14 16:46:48 --> Model "Roles_model" initialized
INFO - 2021-07-14 16:46:48 --> Model "Activity_model" initialized
INFO - 2021-07-14 16:46:48 --> Model "Templates_model" initialized
INFO - 2021-07-14 16:46:48 --> Database Driver Class Initialized
INFO - 2021-07-14 16:46:48 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 16:46:48 --> Controller Class Initialized
INFO - 2021-07-14 16:47:08 --> Config Class Initialized
INFO - 2021-07-14 16:47:08 --> Hooks Class Initialized
DEBUG - 2021-07-14 16:47:08 --> UTF-8 Support Enabled
INFO - 2021-07-14 16:47:08 --> Utf8 Class Initialized
INFO - 2021-07-14 16:47:08 --> URI Class Initialized
INFO - 2021-07-14 16:47:08 --> Router Class Initialized
INFO - 2021-07-14 16:47:08 --> Output Class Initialized
INFO - 2021-07-14 16:47:08 --> Security Class Initialized
DEBUG - 2021-07-14 16:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 16:47:08 --> Input Class Initialized
INFO - 2021-07-14 16:47:08 --> Language Class Initialized
ERROR - 2021-07-14 16:47:08 --> 404 Page Not Found: DevMgmt/DiscoveryTree.xml
INFO - 2021-07-14 16:48:37 --> Config Class Initialized
INFO - 2021-07-14 16:48:37 --> Hooks Class Initialized
DEBUG - 2021-07-14 16:48:37 --> UTF-8 Support Enabled
INFO - 2021-07-14 16:48:37 --> Utf8 Class Initialized
INFO - 2021-07-14 16:48:37 --> URI Class Initialized
INFO - 2021-07-14 16:48:37 --> Router Class Initialized
INFO - 2021-07-14 16:48:37 --> Output Class Initialized
INFO - 2021-07-14 16:48:37 --> Security Class Initialized
DEBUG - 2021-07-14 16:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 16:48:37 --> Input Class Initialized
INFO - 2021-07-14 16:48:37 --> Language Class Initialized
INFO - 2021-07-14 16:48:37 --> Loader Class Initialized
INFO - 2021-07-14 16:48:37 --> Helper loaded: basic_helper
INFO - 2021-07-14 16:48:37 --> Helper loaded: url_helper
INFO - 2021-07-14 16:48:37 --> Helper loaded: file_helper
INFO - 2021-07-14 16:48:37 --> Helper loaded: form_helper
INFO - 2021-07-14 16:48:37 --> Helper loaded: cookie_helper
INFO - 2021-07-14 16:48:37 --> Helper loaded: security_helper
INFO - 2021-07-14 16:48:37 --> Helper loaded: directory_helper
INFO - 2021-07-14 16:48:37 --> Helper loaded: language_helper
INFO - 2021-07-14 16:48:37 --> Helper loaded: general_helper
INFO - 2021-07-14 16:48:37 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 16:48:37 --> Database Driver Class Initialized
DEBUG - 2021-07-14 16:48:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 16:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 16:48:37 --> Parser Class Initialized
INFO - 2021-07-14 16:48:37 --> Form Validation Class Initialized
INFO - 2021-07-14 16:48:37 --> Upload Class Initialized
INFO - 2021-07-14 16:48:37 --> Email Class Initialized
INFO - 2021-07-14 16:48:37 --> MY_Model class loaded
INFO - 2021-07-14 16:48:37 --> Model "Users_model" initialized
INFO - 2021-07-14 16:48:37 --> Model "Settings_model" initialized
INFO - 2021-07-14 16:48:37 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 16:48:37 --> Model "Permissions_model" initialized
INFO - 2021-07-14 16:48:37 --> Model "Roles_model" initialized
INFO - 2021-07-14 16:48:37 --> Model "Activity_model" initialized
INFO - 2021-07-14 16:48:37 --> Model "Templates_model" initialized
INFO - 2021-07-14 16:48:37 --> Database Driver Class Initialized
INFO - 2021-07-14 16:48:37 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 16:48:37 --> Controller Class Initialized
INFO - 2021-07-14 16:48:37 --> Config Class Initialized
INFO - 2021-07-14 16:48:37 --> Hooks Class Initialized
DEBUG - 2021-07-14 16:48:37 --> UTF-8 Support Enabled
INFO - 2021-07-14 16:48:37 --> Utf8 Class Initialized
INFO - 2021-07-14 16:48:37 --> URI Class Initialized
INFO - 2021-07-14 16:48:37 --> Router Class Initialized
INFO - 2021-07-14 16:48:37 --> Output Class Initialized
INFO - 2021-07-14 16:48:37 --> Security Class Initialized
DEBUG - 2021-07-14 16:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 16:48:37 --> Input Class Initialized
INFO - 2021-07-14 16:48:37 --> Language Class Initialized
INFO - 2021-07-14 16:48:37 --> Loader Class Initialized
INFO - 2021-07-14 16:48:37 --> Helper loaded: basic_helper
INFO - 2021-07-14 16:48:37 --> Helper loaded: url_helper
INFO - 2021-07-14 16:48:37 --> Helper loaded: file_helper
INFO - 2021-07-14 16:48:37 --> Helper loaded: form_helper
INFO - 2021-07-14 16:48:37 --> Helper loaded: cookie_helper
INFO - 2021-07-14 16:48:37 --> Helper loaded: security_helper
INFO - 2021-07-14 16:48:37 --> Helper loaded: directory_helper
INFO - 2021-07-14 16:48:37 --> Helper loaded: language_helper
INFO - 2021-07-14 16:48:37 --> Helper loaded: general_helper
INFO - 2021-07-14 16:48:37 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 16:48:37 --> Database Driver Class Initialized
INFO - 2021-07-14 16:48:37 --> Config Class Initialized
INFO - 2021-07-14 16:48:37 --> Hooks Class Initialized
DEBUG - 2021-07-14 16:48:37 --> UTF-8 Support Enabled
INFO - 2021-07-14 16:48:37 --> Utf8 Class Initialized
DEBUG - 2021-07-14 16:48:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 16:48:37 --> URI Class Initialized
INFO - 2021-07-14 16:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 16:48:37 --> Router Class Initialized
INFO - 2021-07-14 16:48:37 --> Parser Class Initialized
INFO - 2021-07-14 16:48:37 --> Output Class Initialized
INFO - 2021-07-14 16:48:37 --> Security Class Initialized
INFO - 2021-07-14 16:48:37 --> Form Validation Class Initialized
DEBUG - 2021-07-14 16:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 16:48:37 --> Input Class Initialized
INFO - 2021-07-14 16:48:37 --> Upload Class Initialized
INFO - 2021-07-14 16:48:37 --> Language Class Initialized
INFO - 2021-07-14 16:48:37 --> Email Class Initialized
ERROR - 2021-07-14 16:48:37 --> 404 Page Not Found: Faviconico/index
INFO - 2021-07-14 16:48:37 --> MY_Model class loaded
INFO - 2021-07-14 16:48:37 --> Model "Users_model" initialized
INFO - 2021-07-14 16:48:37 --> Model "Settings_model" initialized
INFO - 2021-07-14 16:48:37 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 16:48:37 --> Model "Permissions_model" initialized
INFO - 2021-07-14 16:48:37 --> Model "Roles_model" initialized
INFO - 2021-07-14 16:48:37 --> Model "Activity_model" initialized
INFO - 2021-07-14 16:48:37 --> Model "Templates_model" initialized
INFO - 2021-07-14 16:48:37 --> Database Driver Class Initialized
INFO - 2021-07-14 16:48:37 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 16:48:37 --> Controller Class Initialized
ERROR - 2021-07-14 16:48:37 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 16:48:37 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-14 16:48:37 --> Final output sent to browser
DEBUG - 2021-07-14 16:48:37 --> Total execution time: 0.0617
INFO - 2021-07-14 16:48:40 --> Config Class Initialized
INFO - 2021-07-14 16:48:40 --> Hooks Class Initialized
DEBUG - 2021-07-14 16:48:40 --> UTF-8 Support Enabled
INFO - 2021-07-14 16:48:40 --> Utf8 Class Initialized
INFO - 2021-07-14 16:48:40 --> URI Class Initialized
INFO - 2021-07-14 16:48:40 --> Router Class Initialized
INFO - 2021-07-14 16:48:40 --> Output Class Initialized
INFO - 2021-07-14 16:48:40 --> Security Class Initialized
DEBUG - 2021-07-14 16:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 16:48:40 --> Input Class Initialized
INFO - 2021-07-14 16:48:40 --> Language Class Initialized
INFO - 2021-07-14 16:48:40 --> Loader Class Initialized
INFO - 2021-07-14 16:48:40 --> Helper loaded: basic_helper
INFO - 2021-07-14 16:48:40 --> Helper loaded: url_helper
INFO - 2021-07-14 16:48:40 --> Helper loaded: file_helper
INFO - 2021-07-14 16:48:40 --> Helper loaded: form_helper
INFO - 2021-07-14 16:48:40 --> Helper loaded: cookie_helper
INFO - 2021-07-14 16:48:40 --> Helper loaded: security_helper
INFO - 2021-07-14 16:48:40 --> Helper loaded: directory_helper
INFO - 2021-07-14 16:48:40 --> Helper loaded: language_helper
INFO - 2021-07-14 16:48:40 --> Helper loaded: general_helper
INFO - 2021-07-14 16:48:40 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 16:48:40 --> Database Driver Class Initialized
DEBUG - 2021-07-14 16:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 16:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 16:48:40 --> Parser Class Initialized
INFO - 2021-07-14 16:48:40 --> Form Validation Class Initialized
INFO - 2021-07-14 16:48:40 --> Upload Class Initialized
INFO - 2021-07-14 16:48:40 --> Email Class Initialized
INFO - 2021-07-14 16:48:40 --> MY_Model class loaded
INFO - 2021-07-14 16:48:40 --> Model "Users_model" initialized
INFO - 2021-07-14 16:48:40 --> Model "Settings_model" initialized
INFO - 2021-07-14 16:48:40 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 16:48:40 --> Model "Permissions_model" initialized
INFO - 2021-07-14 16:48:40 --> Model "Roles_model" initialized
INFO - 2021-07-14 16:48:40 --> Model "Activity_model" initialized
INFO - 2021-07-14 16:48:40 --> Model "Templates_model" initialized
INFO - 2021-07-14 16:48:40 --> Database Driver Class Initialized
INFO - 2021-07-14 16:48:40 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 16:48:40 --> Controller Class Initialized
ERROR - 2021-07-14 16:48:40 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 16:48:40 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-14 16:48:40 --> Final output sent to browser
DEBUG - 2021-07-14 16:48:40 --> Total execution time: 0.0625
INFO - 2021-07-14 16:48:49 --> Config Class Initialized
INFO - 2021-07-14 16:48:49 --> Hooks Class Initialized
DEBUG - 2021-07-14 16:48:49 --> UTF-8 Support Enabled
INFO - 2021-07-14 16:48:49 --> Utf8 Class Initialized
INFO - 2021-07-14 16:48:49 --> URI Class Initialized
INFO - 2021-07-14 16:48:49 --> Router Class Initialized
INFO - 2021-07-14 16:48:49 --> Output Class Initialized
INFO - 2021-07-14 16:48:49 --> Security Class Initialized
DEBUG - 2021-07-14 16:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 16:48:49 --> Input Class Initialized
INFO - 2021-07-14 16:48:49 --> Language Class Initialized
INFO - 2021-07-14 16:48:49 --> Loader Class Initialized
INFO - 2021-07-14 16:48:49 --> Helper loaded: basic_helper
INFO - 2021-07-14 16:48:49 --> Helper loaded: url_helper
INFO - 2021-07-14 16:48:49 --> Helper loaded: file_helper
INFO - 2021-07-14 16:48:49 --> Helper loaded: form_helper
INFO - 2021-07-14 16:48:49 --> Helper loaded: cookie_helper
INFO - 2021-07-14 16:48:49 --> Helper loaded: security_helper
INFO - 2021-07-14 16:48:49 --> Helper loaded: directory_helper
INFO - 2021-07-14 16:48:49 --> Helper loaded: language_helper
INFO - 2021-07-14 16:48:49 --> Helper loaded: general_helper
INFO - 2021-07-14 16:48:49 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 16:48:49 --> Database Driver Class Initialized
DEBUG - 2021-07-14 16:48:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 16:48:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 16:48:49 --> Parser Class Initialized
INFO - 2021-07-14 16:48:49 --> Form Validation Class Initialized
INFO - 2021-07-14 16:48:49 --> Upload Class Initialized
INFO - 2021-07-14 16:48:49 --> Email Class Initialized
INFO - 2021-07-14 16:48:49 --> MY_Model class loaded
INFO - 2021-07-14 16:48:49 --> Model "Users_model" initialized
INFO - 2021-07-14 16:48:49 --> Model "Settings_model" initialized
INFO - 2021-07-14 16:48:49 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 16:48:49 --> Model "Permissions_model" initialized
INFO - 2021-07-14 16:48:49 --> Model "Roles_model" initialized
INFO - 2021-07-14 16:48:49 --> Model "Activity_model" initialized
INFO - 2021-07-14 16:48:49 --> Model "Templates_model" initialized
INFO - 2021-07-14 16:48:49 --> Database Driver Class Initialized
INFO - 2021-07-14 16:48:49 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 16:48:49 --> Controller Class Initialized
ERROR - 2021-07-14 16:48:49 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 16:48:49 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-14 16:48:49 --> Final output sent to browser
DEBUG - 2021-07-14 16:48:49 --> Total execution time: 0.1530
INFO - 2021-07-14 16:48:56 --> Config Class Initialized
INFO - 2021-07-14 16:48:56 --> Hooks Class Initialized
DEBUG - 2021-07-14 16:48:56 --> UTF-8 Support Enabled
INFO - 2021-07-14 16:48:56 --> Utf8 Class Initialized
INFO - 2021-07-14 16:48:56 --> URI Class Initialized
INFO - 2021-07-14 16:48:56 --> Router Class Initialized
INFO - 2021-07-14 16:48:56 --> Output Class Initialized
INFO - 2021-07-14 16:48:56 --> Security Class Initialized
DEBUG - 2021-07-14 16:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 16:48:56 --> Input Class Initialized
INFO - 2021-07-14 16:48:56 --> Language Class Initialized
INFO - 2021-07-14 16:48:56 --> Loader Class Initialized
INFO - 2021-07-14 16:48:56 --> Helper loaded: basic_helper
INFO - 2021-07-14 16:48:56 --> Helper loaded: url_helper
INFO - 2021-07-14 16:48:56 --> Helper loaded: file_helper
INFO - 2021-07-14 16:48:56 --> Helper loaded: form_helper
INFO - 2021-07-14 16:48:56 --> Helper loaded: cookie_helper
INFO - 2021-07-14 16:48:56 --> Helper loaded: security_helper
INFO - 2021-07-14 16:48:56 --> Helper loaded: directory_helper
INFO - 2021-07-14 16:48:56 --> Helper loaded: language_helper
INFO - 2021-07-14 16:48:56 --> Helper loaded: general_helper
INFO - 2021-07-14 16:48:56 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 16:48:56 --> Database Driver Class Initialized
DEBUG - 2021-07-14 16:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 16:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 16:48:56 --> Parser Class Initialized
INFO - 2021-07-14 16:48:56 --> Form Validation Class Initialized
INFO - 2021-07-14 16:48:56 --> Upload Class Initialized
INFO - 2021-07-14 16:48:56 --> Email Class Initialized
INFO - 2021-07-14 16:48:56 --> MY_Model class loaded
INFO - 2021-07-14 16:48:56 --> Model "Users_model" initialized
INFO - 2021-07-14 16:48:56 --> Model "Settings_model" initialized
INFO - 2021-07-14 16:48:56 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 16:48:56 --> Model "Permissions_model" initialized
INFO - 2021-07-14 16:48:56 --> Model "Roles_model" initialized
INFO - 2021-07-14 16:48:56 --> Model "Activity_model" initialized
INFO - 2021-07-14 16:48:56 --> Model "Templates_model" initialized
INFO - 2021-07-14 16:48:56 --> Database Driver Class Initialized
INFO - 2021-07-14 16:48:57 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 16:48:57 --> Controller Class Initialized
ERROR - 2021-07-14 16:48:57 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-14 16:48:57 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-14 16:48:57 --> Final output sent to browser
DEBUG - 2021-07-14 16:48:57 --> Total execution time: 0.2021
INFO - 2021-07-14 16:57:37 --> Config Class Initialized
INFO - 2021-07-14 16:57:37 --> Hooks Class Initialized
DEBUG - 2021-07-14 16:57:37 --> UTF-8 Support Enabled
INFO - 2021-07-14 16:57:37 --> Utf8 Class Initialized
INFO - 2021-07-14 16:57:37 --> URI Class Initialized
DEBUG - 2021-07-14 16:57:37 --> No URI present. Default controller set.
INFO - 2021-07-14 16:57:37 --> Router Class Initialized
INFO - 2021-07-14 16:57:37 --> Output Class Initialized
INFO - 2021-07-14 16:57:37 --> Security Class Initialized
DEBUG - 2021-07-14 16:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-14 16:57:37 --> Input Class Initialized
INFO - 2021-07-14 16:57:37 --> Language Class Initialized
INFO - 2021-07-14 16:57:37 --> Loader Class Initialized
INFO - 2021-07-14 16:57:37 --> Helper loaded: basic_helper
INFO - 2021-07-14 16:57:37 --> Helper loaded: url_helper
INFO - 2021-07-14 16:57:37 --> Helper loaded: file_helper
INFO - 2021-07-14 16:57:37 --> Helper loaded: form_helper
INFO - 2021-07-14 16:57:37 --> Helper loaded: cookie_helper
INFO - 2021-07-14 16:57:37 --> Helper loaded: security_helper
INFO - 2021-07-14 16:57:37 --> Helper loaded: directory_helper
INFO - 2021-07-14 16:57:37 --> Helper loaded: language_helper
INFO - 2021-07-14 16:57:37 --> Helper loaded: general_helper
INFO - 2021-07-14 16:57:37 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-14 16:57:37 --> Database Driver Class Initialized
DEBUG - 2021-07-14 16:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-14 16:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-14 16:57:37 --> Parser Class Initialized
INFO - 2021-07-14 16:57:37 --> Form Validation Class Initialized
INFO - 2021-07-14 16:57:37 --> Upload Class Initialized
INFO - 2021-07-14 16:57:37 --> Email Class Initialized
INFO - 2021-07-14 16:57:37 --> MY_Model class loaded
INFO - 2021-07-14 16:57:37 --> Model "Users_model" initialized
INFO - 2021-07-14 16:57:37 --> Model "Settings_model" initialized
INFO - 2021-07-14 16:57:37 --> Model "Role_permissions_model" initialized
INFO - 2021-07-14 16:57:37 --> Model "Permissions_model" initialized
INFO - 2021-07-14 16:57:37 --> Model "Roles_model" initialized
INFO - 2021-07-14 16:57:37 --> Model "Activity_model" initialized
INFO - 2021-07-14 16:57:37 --> Model "Templates_model" initialized
INFO - 2021-07-14 16:57:37 --> Database Driver Class Initialized
INFO - 2021-07-14 16:57:38 --> Model "Hesaplar_model" initialized
INFO - 2021-07-14 16:57:38 --> Controller Class Initialized
