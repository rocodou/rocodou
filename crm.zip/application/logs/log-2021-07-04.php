<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-07-04 07:50:52 --> Config Class Initialized
INFO - 2021-07-04 07:50:52 --> Hooks Class Initialized
DEBUG - 2021-07-04 07:50:52 --> UTF-8 Support Enabled
INFO - 2021-07-04 07:50:52 --> Utf8 Class Initialized
INFO - 2021-07-04 07:50:52 --> URI Class Initialized
INFO - 2021-07-04 07:50:52 --> Router Class Initialized
INFO - 2021-07-04 07:50:52 --> Output Class Initialized
INFO - 2021-07-04 07:50:52 --> Security Class Initialized
DEBUG - 2021-07-04 07:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-04 07:50:52 --> Input Class Initialized
INFO - 2021-07-04 07:50:52 --> Language Class Initialized
ERROR - 2021-07-04 07:50:52 --> 404 Page Not Found: DevMgmt/DiscoveryTree.xml
