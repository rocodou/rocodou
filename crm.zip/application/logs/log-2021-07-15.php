<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-07-15 15:03:00 --> Config Class Initialized
INFO - 2021-07-15 15:03:00 --> Hooks Class Initialized
DEBUG - 2021-07-15 15:03:00 --> UTF-8 Support Enabled
INFO - 2021-07-15 15:03:00 --> Utf8 Class Initialized
INFO - 2021-07-15 15:03:00 --> URI Class Initialized
INFO - 2021-07-15 15:03:00 --> Router Class Initialized
INFO - 2021-07-15 15:03:00 --> Output Class Initialized
INFO - 2021-07-15 15:03:00 --> Security Class Initialized
DEBUG - 2021-07-15 15:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 15:03:00 --> Input Class Initialized
INFO - 2021-07-15 15:03:00 --> Language Class Initialized
INFO - 2021-07-15 15:03:00 --> Loader Class Initialized
INFO - 2021-07-15 15:03:00 --> Helper loaded: basic_helper
INFO - 2021-07-15 15:03:00 --> Helper loaded: url_helper
INFO - 2021-07-15 15:03:00 --> Helper loaded: file_helper
INFO - 2021-07-15 15:03:00 --> Helper loaded: form_helper
INFO - 2021-07-15 15:03:00 --> Helper loaded: cookie_helper
INFO - 2021-07-15 15:03:00 --> Helper loaded: security_helper
INFO - 2021-07-15 15:03:00 --> Helper loaded: directory_helper
INFO - 2021-07-15 15:03:00 --> Helper loaded: language_helper
INFO - 2021-07-15 15:03:00 --> Helper loaded: general_helper
INFO - 2021-07-15 15:03:00 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 15:03:00 --> Database Driver Class Initialized
DEBUG - 2021-07-15 15:03:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 15:03:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 15:03:00 --> Parser Class Initialized
INFO - 2021-07-15 15:03:00 --> Form Validation Class Initialized
INFO - 2021-07-15 15:03:00 --> Upload Class Initialized
INFO - 2021-07-15 15:03:00 --> Email Class Initialized
INFO - 2021-07-15 15:03:00 --> MY_Model class loaded
INFO - 2021-07-15 15:03:00 --> Model "Users_model" initialized
INFO - 2021-07-15 15:03:00 --> Model "Settings_model" initialized
INFO - 2021-07-15 15:03:00 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 15:03:00 --> Model "Permissions_model" initialized
INFO - 2021-07-15 15:03:00 --> Model "Roles_model" initialized
INFO - 2021-07-15 15:03:00 --> Model "Activity_model" initialized
INFO - 2021-07-15 15:03:00 --> Model "Templates_model" initialized
INFO - 2021-07-15 15:03:00 --> Database Driver Class Initialized
INFO - 2021-07-15 15:03:01 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 15:03:01 --> Controller Class Initialized
ERROR - 2021-07-15 15:03:01 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 15:03:01 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-15 15:03:01 --> Final output sent to browser
DEBUG - 2021-07-15 15:03:01 --> Total execution time: 0.4245
INFO - 2021-07-15 15:03:02 --> Config Class Initialized
INFO - 2021-07-15 15:03:02 --> Hooks Class Initialized
DEBUG - 2021-07-15 15:03:02 --> UTF-8 Support Enabled
INFO - 2021-07-15 15:03:02 --> Utf8 Class Initialized
INFO - 2021-07-15 15:03:02 --> URI Class Initialized
INFO - 2021-07-15 15:03:02 --> Router Class Initialized
INFO - 2021-07-15 15:03:02 --> Output Class Initialized
INFO - 2021-07-15 15:03:02 --> Security Class Initialized
DEBUG - 2021-07-15 15:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 15:03:02 --> Input Class Initialized
INFO - 2021-07-15 15:03:02 --> Language Class Initialized
ERROR - 2021-07-15 15:03:02 --> 404 Page Not Found: Faviconico/index
INFO - 2021-07-15 15:17:58 --> Config Class Initialized
INFO - 2021-07-15 15:17:58 --> Hooks Class Initialized
DEBUG - 2021-07-15 15:17:58 --> UTF-8 Support Enabled
INFO - 2021-07-15 15:17:58 --> Utf8 Class Initialized
INFO - 2021-07-15 15:17:58 --> URI Class Initialized
DEBUG - 2021-07-15 15:17:58 --> No URI present. Default controller set.
INFO - 2021-07-15 15:17:58 --> Router Class Initialized
INFO - 2021-07-15 15:17:58 --> Output Class Initialized
INFO - 2021-07-15 15:17:58 --> Security Class Initialized
DEBUG - 2021-07-15 15:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 15:17:58 --> Input Class Initialized
INFO - 2021-07-15 15:17:58 --> Language Class Initialized
INFO - 2021-07-15 15:17:58 --> Loader Class Initialized
INFO - 2021-07-15 15:17:58 --> Helper loaded: basic_helper
INFO - 2021-07-15 15:17:58 --> Helper loaded: url_helper
INFO - 2021-07-15 15:17:58 --> Helper loaded: file_helper
INFO - 2021-07-15 15:17:58 --> Helper loaded: form_helper
INFO - 2021-07-15 15:17:58 --> Helper loaded: cookie_helper
INFO - 2021-07-15 15:17:58 --> Helper loaded: security_helper
INFO - 2021-07-15 15:17:58 --> Helper loaded: directory_helper
INFO - 2021-07-15 15:17:58 --> Helper loaded: language_helper
INFO - 2021-07-15 15:17:58 --> Helper loaded: general_helper
INFO - 2021-07-15 15:17:58 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 15:17:58 --> Database Driver Class Initialized
DEBUG - 2021-07-15 15:17:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 15:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 15:17:58 --> Parser Class Initialized
INFO - 2021-07-15 15:17:58 --> Form Validation Class Initialized
INFO - 2021-07-15 15:17:58 --> Upload Class Initialized
INFO - 2021-07-15 15:17:58 --> Email Class Initialized
INFO - 2021-07-15 15:17:58 --> MY_Model class loaded
INFO - 2021-07-15 15:17:58 --> Model "Users_model" initialized
INFO - 2021-07-15 15:17:58 --> Model "Settings_model" initialized
INFO - 2021-07-15 15:17:58 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 15:17:58 --> Model "Permissions_model" initialized
INFO - 2021-07-15 15:17:58 --> Model "Roles_model" initialized
INFO - 2021-07-15 15:17:58 --> Model "Activity_model" initialized
INFO - 2021-07-15 15:17:58 --> Model "Templates_model" initialized
INFO - 2021-07-15 15:17:58 --> Database Driver Class Initialized
INFO - 2021-07-15 15:17:58 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 15:17:58 --> Controller Class Initialized
INFO - 2021-07-15 15:22:56 --> Config Class Initialized
INFO - 2021-07-15 15:22:56 --> Hooks Class Initialized
DEBUG - 2021-07-15 15:22:56 --> UTF-8 Support Enabled
INFO - 2021-07-15 15:22:56 --> Utf8 Class Initialized
INFO - 2021-07-15 15:22:56 --> URI Class Initialized
INFO - 2021-07-15 15:22:56 --> Router Class Initialized
INFO - 2021-07-15 15:22:56 --> Output Class Initialized
INFO - 2021-07-15 15:22:56 --> Security Class Initialized
DEBUG - 2021-07-15 15:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 15:22:56 --> Input Class Initialized
INFO - 2021-07-15 15:22:56 --> Language Class Initialized
INFO - 2021-07-15 15:22:56 --> Loader Class Initialized
INFO - 2021-07-15 15:22:56 --> Helper loaded: basic_helper
INFO - 2021-07-15 15:22:56 --> Helper loaded: url_helper
INFO - 2021-07-15 15:22:56 --> Helper loaded: file_helper
INFO - 2021-07-15 15:22:56 --> Helper loaded: form_helper
INFO - 2021-07-15 15:22:56 --> Helper loaded: cookie_helper
INFO - 2021-07-15 15:22:56 --> Helper loaded: security_helper
INFO - 2021-07-15 15:22:56 --> Helper loaded: directory_helper
INFO - 2021-07-15 15:22:56 --> Helper loaded: language_helper
INFO - 2021-07-15 15:22:56 --> Helper loaded: general_helper
INFO - 2021-07-15 15:22:56 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 15:22:56 --> Database Driver Class Initialized
DEBUG - 2021-07-15 15:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 15:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 15:22:56 --> Parser Class Initialized
INFO - 2021-07-15 15:22:56 --> Form Validation Class Initialized
INFO - 2021-07-15 15:22:56 --> Upload Class Initialized
INFO - 2021-07-15 15:22:56 --> Email Class Initialized
INFO - 2021-07-15 15:22:56 --> MY_Model class loaded
INFO - 2021-07-15 15:22:56 --> Model "Users_model" initialized
INFO - 2021-07-15 15:22:56 --> Model "Settings_model" initialized
INFO - 2021-07-15 15:22:56 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 15:22:56 --> Model "Permissions_model" initialized
INFO - 2021-07-15 15:22:56 --> Model "Roles_model" initialized
INFO - 2021-07-15 15:22:56 --> Model "Activity_model" initialized
INFO - 2021-07-15 15:22:56 --> Model "Templates_model" initialized
INFO - 2021-07-15 15:22:56 --> Database Driver Class Initialized
INFO - 2021-07-15 15:22:56 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 15:22:56 --> Controller Class Initialized
ERROR - 2021-07-15 15:22:56 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 15:22:56 --> File loaded: C:\wamp64\www\crm\application\views\activity_logs/list.php
INFO - 2021-07-15 15:22:56 --> Final output sent to browser
DEBUG - 2021-07-15 15:22:56 --> Total execution time: 0.2716
INFO - 2021-07-15 15:24:01 --> Config Class Initialized
INFO - 2021-07-15 15:24:01 --> Hooks Class Initialized
DEBUG - 2021-07-15 15:24:01 --> UTF-8 Support Enabled
INFO - 2021-07-15 15:24:01 --> Utf8 Class Initialized
INFO - 2021-07-15 15:24:01 --> URI Class Initialized
INFO - 2021-07-15 15:24:01 --> Router Class Initialized
INFO - 2021-07-15 15:24:01 --> Output Class Initialized
INFO - 2021-07-15 15:24:01 --> Security Class Initialized
DEBUG - 2021-07-15 15:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 15:24:01 --> Input Class Initialized
INFO - 2021-07-15 15:24:01 --> Language Class Initialized
INFO - 2021-07-15 15:24:01 --> Loader Class Initialized
INFO - 2021-07-15 15:24:01 --> Helper loaded: basic_helper
INFO - 2021-07-15 15:24:01 --> Helper loaded: url_helper
INFO - 2021-07-15 15:24:01 --> Helper loaded: file_helper
INFO - 2021-07-15 15:24:01 --> Helper loaded: form_helper
INFO - 2021-07-15 15:24:01 --> Helper loaded: cookie_helper
INFO - 2021-07-15 15:24:01 --> Helper loaded: security_helper
INFO - 2021-07-15 15:24:01 --> Helper loaded: directory_helper
INFO - 2021-07-15 15:24:01 --> Helper loaded: language_helper
INFO - 2021-07-15 15:24:01 --> Helper loaded: general_helper
INFO - 2021-07-15 15:24:01 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 15:24:01 --> Database Driver Class Initialized
DEBUG - 2021-07-15 15:24:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 15:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 15:24:01 --> Parser Class Initialized
INFO - 2021-07-15 15:24:01 --> Form Validation Class Initialized
INFO - 2021-07-15 15:24:01 --> Upload Class Initialized
INFO - 2021-07-15 15:24:01 --> Email Class Initialized
INFO - 2021-07-15 15:24:01 --> MY_Model class loaded
INFO - 2021-07-15 15:24:01 --> Model "Users_model" initialized
INFO - 2021-07-15 15:24:01 --> Model "Settings_model" initialized
INFO - 2021-07-15 15:24:01 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 15:24:01 --> Model "Permissions_model" initialized
INFO - 2021-07-15 15:24:01 --> Model "Roles_model" initialized
INFO - 2021-07-15 15:24:01 --> Model "Activity_model" initialized
INFO - 2021-07-15 15:24:01 --> Model "Templates_model" initialized
INFO - 2021-07-15 15:24:01 --> Database Driver Class Initialized
INFO - 2021-07-15 15:24:01 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 15:24:01 --> Controller Class Initialized
INFO - 2021-07-15 15:24:01 --> Config Class Initialized
INFO - 2021-07-15 15:24:01 --> Hooks Class Initialized
DEBUG - 2021-07-15 15:24:01 --> UTF-8 Support Enabled
INFO - 2021-07-15 15:24:01 --> Utf8 Class Initialized
INFO - 2021-07-15 15:24:01 --> URI Class Initialized
INFO - 2021-07-15 15:24:01 --> Router Class Initialized
INFO - 2021-07-15 15:24:01 --> Output Class Initialized
INFO - 2021-07-15 15:24:01 --> Security Class Initialized
DEBUG - 2021-07-15 15:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 15:24:01 --> Input Class Initialized
INFO - 2021-07-15 15:24:01 --> Language Class Initialized
INFO - 2021-07-15 15:24:01 --> Loader Class Initialized
INFO - 2021-07-15 15:24:01 --> Helper loaded: basic_helper
INFO - 2021-07-15 15:24:01 --> Helper loaded: url_helper
INFO - 2021-07-15 15:24:01 --> Helper loaded: file_helper
INFO - 2021-07-15 15:24:01 --> Helper loaded: form_helper
INFO - 2021-07-15 15:24:01 --> Helper loaded: cookie_helper
INFO - 2021-07-15 15:24:01 --> Helper loaded: security_helper
INFO - 2021-07-15 15:24:01 --> Helper loaded: directory_helper
INFO - 2021-07-15 15:24:01 --> Helper loaded: language_helper
INFO - 2021-07-15 15:24:01 --> Helper loaded: general_helper
INFO - 2021-07-15 15:24:02 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 15:24:02 --> Database Driver Class Initialized
DEBUG - 2021-07-15 15:24:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 15:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 15:24:02 --> Parser Class Initialized
INFO - 2021-07-15 15:24:02 --> Form Validation Class Initialized
INFO - 2021-07-15 15:24:02 --> Upload Class Initialized
INFO - 2021-07-15 15:24:02 --> Email Class Initialized
INFO - 2021-07-15 15:24:02 --> MY_Model class loaded
INFO - 2021-07-15 15:24:02 --> Model "Users_model" initialized
INFO - 2021-07-15 15:24:02 --> Model "Settings_model" initialized
INFO - 2021-07-15 15:24:02 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 15:24:02 --> Model "Permissions_model" initialized
INFO - 2021-07-15 15:24:02 --> Model "Roles_model" initialized
INFO - 2021-07-15 15:24:02 --> Model "Activity_model" initialized
INFO - 2021-07-15 15:24:02 --> Model "Templates_model" initialized
INFO - 2021-07-15 15:24:02 --> Database Driver Class Initialized
INFO - 2021-07-15 15:24:02 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 15:24:02 --> Controller Class Initialized
INFO - 2021-07-15 15:24:02 --> File loaded: C:\wamp64\www\crm\application\views\account/login.php
INFO - 2021-07-15 15:24:02 --> Final output sent to browser
DEBUG - 2021-07-15 15:24:02 --> Total execution time: 0.0616
INFO - 2021-07-15 15:24:02 --> Config Class Initialized
INFO - 2021-07-15 15:24:02 --> Config Class Initialized
INFO - 2021-07-15 15:24:02 --> Hooks Class Initialized
INFO - 2021-07-15 15:24:02 --> Hooks Class Initialized
DEBUG - 2021-07-15 15:24:02 --> UTF-8 Support Enabled
DEBUG - 2021-07-15 15:24:02 --> UTF-8 Support Enabled
INFO - 2021-07-15 15:24:02 --> Utf8 Class Initialized
INFO - 2021-07-15 15:24:02 --> Utf8 Class Initialized
INFO - 2021-07-15 15:24:02 --> URI Class Initialized
INFO - 2021-07-15 15:24:02 --> URI Class Initialized
INFO - 2021-07-15 15:24:02 --> Router Class Initialized
INFO - 2021-07-15 15:24:02 --> Router Class Initialized
INFO - 2021-07-15 15:24:02 --> Output Class Initialized
INFO - 2021-07-15 15:24:02 --> Output Class Initialized
INFO - 2021-07-15 15:24:02 --> Security Class Initialized
INFO - 2021-07-15 15:24:02 --> Security Class Initialized
DEBUG - 2021-07-15 15:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-15 15:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 15:24:02 --> Input Class Initialized
INFO - 2021-07-15 15:24:02 --> Input Class Initialized
INFO - 2021-07-15 15:24:02 --> Language Class Initialized
INFO - 2021-07-15 15:24:02 --> Language Class Initialized
ERROR - 2021-07-15 15:24:02 --> 404 Page Not Found: Assets/jquery
ERROR - 2021-07-15 15:24:02 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-15 15:24:02 --> Config Class Initialized
INFO - 2021-07-15 15:24:02 --> Hooks Class Initialized
DEBUG - 2021-07-15 15:24:02 --> UTF-8 Support Enabled
INFO - 2021-07-15 15:24:02 --> Utf8 Class Initialized
INFO - 2021-07-15 15:24:02 --> URI Class Initialized
INFO - 2021-07-15 15:24:02 --> Router Class Initialized
INFO - 2021-07-15 15:24:02 --> Output Class Initialized
INFO - 2021-07-15 15:24:02 --> Security Class Initialized
DEBUG - 2021-07-15 15:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 15:24:02 --> Input Class Initialized
INFO - 2021-07-15 15:24:02 --> Language Class Initialized
ERROR - 2021-07-15 15:24:02 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-15 15:24:03 --> Config Class Initialized
INFO - 2021-07-15 15:24:03 --> Hooks Class Initialized
DEBUG - 2021-07-15 15:24:03 --> UTF-8 Support Enabled
INFO - 2021-07-15 15:24:03 --> Utf8 Class Initialized
INFO - 2021-07-15 15:24:03 --> URI Class Initialized
INFO - 2021-07-15 15:24:03 --> Router Class Initialized
INFO - 2021-07-15 15:24:03 --> Output Class Initialized
INFO - 2021-07-15 15:24:03 --> Security Class Initialized
DEBUG - 2021-07-15 15:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 15:24:03 --> Input Class Initialized
INFO - 2021-07-15 15:24:03 --> Language Class Initialized
INFO - 2021-07-15 15:24:03 --> Loader Class Initialized
INFO - 2021-07-15 15:24:03 --> Helper loaded: basic_helper
INFO - 2021-07-15 15:24:03 --> Helper loaded: url_helper
INFO - 2021-07-15 15:24:03 --> Helper loaded: file_helper
INFO - 2021-07-15 15:24:03 --> Helper loaded: form_helper
INFO - 2021-07-15 15:24:03 --> Helper loaded: cookie_helper
INFO - 2021-07-15 15:24:03 --> Helper loaded: security_helper
INFO - 2021-07-15 15:24:03 --> Helper loaded: directory_helper
INFO - 2021-07-15 15:24:03 --> Helper loaded: language_helper
INFO - 2021-07-15 15:24:03 --> Helper loaded: general_helper
INFO - 2021-07-15 15:24:03 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 15:24:03 --> Database Driver Class Initialized
DEBUG - 2021-07-15 15:24:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 15:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 15:24:03 --> Parser Class Initialized
INFO - 2021-07-15 15:24:03 --> Form Validation Class Initialized
INFO - 2021-07-15 15:24:03 --> Upload Class Initialized
INFO - 2021-07-15 15:24:03 --> Email Class Initialized
INFO - 2021-07-15 15:24:03 --> MY_Model class loaded
INFO - 2021-07-15 15:24:03 --> Model "Users_model" initialized
INFO - 2021-07-15 15:24:03 --> Model "Settings_model" initialized
INFO - 2021-07-15 15:24:03 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 15:24:03 --> Model "Permissions_model" initialized
INFO - 2021-07-15 15:24:03 --> Model "Roles_model" initialized
INFO - 2021-07-15 15:24:03 --> Model "Activity_model" initialized
INFO - 2021-07-15 15:24:03 --> Model "Templates_model" initialized
INFO - 2021-07-15 15:24:03 --> Database Driver Class Initialized
INFO - 2021-07-15 15:24:03 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 15:24:03 --> Controller Class Initialized
DEBUG - 2021-07-15 15:24:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-15 15:24:03 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2021-07-15 15:24:03 --> Config Class Initialized
INFO - 2021-07-15 15:24:03 --> Hooks Class Initialized
DEBUG - 2021-07-15 15:24:03 --> UTF-8 Support Enabled
INFO - 2021-07-15 15:24:03 --> Utf8 Class Initialized
INFO - 2021-07-15 15:24:03 --> URI Class Initialized
DEBUG - 2021-07-15 15:24:03 --> No URI present. Default controller set.
INFO - 2021-07-15 15:24:03 --> Router Class Initialized
INFO - 2021-07-15 15:24:03 --> Output Class Initialized
INFO - 2021-07-15 15:24:03 --> Security Class Initialized
DEBUG - 2021-07-15 15:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 15:24:03 --> Input Class Initialized
INFO - 2021-07-15 15:24:03 --> Language Class Initialized
INFO - 2021-07-15 15:24:03 --> Loader Class Initialized
INFO - 2021-07-15 15:24:03 --> Helper loaded: basic_helper
INFO - 2021-07-15 15:24:03 --> Helper loaded: url_helper
INFO - 2021-07-15 15:24:03 --> Helper loaded: file_helper
INFO - 2021-07-15 15:24:03 --> Helper loaded: form_helper
INFO - 2021-07-15 15:24:03 --> Helper loaded: cookie_helper
INFO - 2021-07-15 15:24:03 --> Helper loaded: security_helper
INFO - 2021-07-15 15:24:03 --> Helper loaded: directory_helper
INFO - 2021-07-15 15:24:03 --> Helper loaded: language_helper
INFO - 2021-07-15 15:24:03 --> Helper loaded: general_helper
INFO - 2021-07-15 15:24:03 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 15:24:03 --> Database Driver Class Initialized
DEBUG - 2021-07-15 15:24:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 15:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 15:24:03 --> Parser Class Initialized
INFO - 2021-07-15 15:24:03 --> Form Validation Class Initialized
INFO - 2021-07-15 15:24:03 --> Upload Class Initialized
INFO - 2021-07-15 15:24:03 --> Email Class Initialized
INFO - 2021-07-15 15:24:03 --> MY_Model class loaded
INFO - 2021-07-15 15:24:03 --> Model "Users_model" initialized
INFO - 2021-07-15 15:24:03 --> Model "Settings_model" initialized
INFO - 2021-07-15 15:24:03 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 15:24:03 --> Model "Permissions_model" initialized
INFO - 2021-07-15 15:24:03 --> Model "Roles_model" initialized
INFO - 2021-07-15 15:24:03 --> Model "Activity_model" initialized
INFO - 2021-07-15 15:24:03 --> Model "Templates_model" initialized
INFO - 2021-07-15 15:24:03 --> Database Driver Class Initialized
INFO - 2021-07-15 15:24:03 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 15:24:03 --> Controller Class Initialized
ERROR - 2021-07-15 15:24:03 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 15:24:03 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-15 15:24:03 --> Final output sent to browser
DEBUG - 2021-07-15 15:24:03 --> Total execution time: 0.0642
INFO - 2021-07-15 15:24:06 --> Config Class Initialized
INFO - 2021-07-15 15:24:06 --> Hooks Class Initialized
DEBUG - 2021-07-15 15:24:06 --> UTF-8 Support Enabled
INFO - 2021-07-15 15:24:06 --> Utf8 Class Initialized
INFO - 2021-07-15 15:24:06 --> URI Class Initialized
INFO - 2021-07-15 15:24:06 --> Router Class Initialized
INFO - 2021-07-15 15:24:06 --> Output Class Initialized
INFO - 2021-07-15 15:24:06 --> Security Class Initialized
DEBUG - 2021-07-15 15:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 15:24:06 --> Input Class Initialized
INFO - 2021-07-15 15:24:06 --> Language Class Initialized
INFO - 2021-07-15 15:24:06 --> Loader Class Initialized
INFO - 2021-07-15 15:24:06 --> Helper loaded: basic_helper
INFO - 2021-07-15 15:24:06 --> Helper loaded: url_helper
INFO - 2021-07-15 15:24:06 --> Helper loaded: file_helper
INFO - 2021-07-15 15:24:06 --> Helper loaded: form_helper
INFO - 2021-07-15 15:24:06 --> Helper loaded: cookie_helper
INFO - 2021-07-15 15:24:06 --> Helper loaded: security_helper
INFO - 2021-07-15 15:24:06 --> Helper loaded: directory_helper
INFO - 2021-07-15 15:24:06 --> Helper loaded: language_helper
INFO - 2021-07-15 15:24:06 --> Helper loaded: general_helper
INFO - 2021-07-15 15:24:06 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 15:24:06 --> Database Driver Class Initialized
DEBUG - 2021-07-15 15:24:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 15:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 15:24:06 --> Parser Class Initialized
INFO - 2021-07-15 15:24:06 --> Form Validation Class Initialized
INFO - 2021-07-15 15:24:06 --> Upload Class Initialized
INFO - 2021-07-15 15:24:06 --> Email Class Initialized
INFO - 2021-07-15 15:24:06 --> MY_Model class loaded
INFO - 2021-07-15 15:24:06 --> Model "Users_model" initialized
INFO - 2021-07-15 15:24:06 --> Model "Settings_model" initialized
INFO - 2021-07-15 15:24:06 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 15:24:06 --> Model "Permissions_model" initialized
INFO - 2021-07-15 15:24:06 --> Model "Roles_model" initialized
INFO - 2021-07-15 15:24:06 --> Model "Activity_model" initialized
INFO - 2021-07-15 15:24:06 --> Model "Templates_model" initialized
INFO - 2021-07-15 15:24:06 --> Database Driver Class Initialized
INFO - 2021-07-15 15:24:06 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 15:24:06 --> Controller Class Initialized
ERROR - 2021-07-15 15:24:06 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 15:24:06 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 15:24:06 --> Final output sent to browser
DEBUG - 2021-07-15 15:24:06 --> Total execution time: 0.0632
INFO - 2021-07-15 15:28:05 --> Config Class Initialized
INFO - 2021-07-15 15:28:05 --> Hooks Class Initialized
DEBUG - 2021-07-15 15:28:05 --> UTF-8 Support Enabled
INFO - 2021-07-15 15:28:05 --> Utf8 Class Initialized
INFO - 2021-07-15 15:28:05 --> URI Class Initialized
INFO - 2021-07-15 15:28:05 --> Router Class Initialized
INFO - 2021-07-15 15:28:05 --> Output Class Initialized
INFO - 2021-07-15 15:28:05 --> Security Class Initialized
DEBUG - 2021-07-15 15:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 15:28:05 --> Input Class Initialized
INFO - 2021-07-15 15:28:05 --> Language Class Initialized
INFO - 2021-07-15 15:28:05 --> Loader Class Initialized
INFO - 2021-07-15 15:28:05 --> Helper loaded: basic_helper
INFO - 2021-07-15 15:28:05 --> Helper loaded: url_helper
INFO - 2021-07-15 15:28:05 --> Helper loaded: file_helper
INFO - 2021-07-15 15:28:05 --> Helper loaded: form_helper
INFO - 2021-07-15 15:28:05 --> Helper loaded: cookie_helper
INFO - 2021-07-15 15:28:05 --> Helper loaded: security_helper
INFO - 2021-07-15 15:28:05 --> Helper loaded: directory_helper
INFO - 2021-07-15 15:28:05 --> Helper loaded: language_helper
INFO - 2021-07-15 15:28:05 --> Helper loaded: general_helper
INFO - 2021-07-15 15:28:05 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 15:28:05 --> Database Driver Class Initialized
DEBUG - 2021-07-15 15:28:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 15:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 15:28:05 --> Parser Class Initialized
INFO - 2021-07-15 15:28:05 --> Form Validation Class Initialized
INFO - 2021-07-15 15:28:05 --> Upload Class Initialized
INFO - 2021-07-15 15:28:05 --> Email Class Initialized
INFO - 2021-07-15 15:28:05 --> MY_Model class loaded
INFO - 2021-07-15 15:28:05 --> Model "Users_model" initialized
INFO - 2021-07-15 15:28:05 --> Model "Settings_model" initialized
INFO - 2021-07-15 15:28:05 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 15:28:05 --> Model "Permissions_model" initialized
INFO - 2021-07-15 15:28:05 --> Model "Roles_model" initialized
INFO - 2021-07-15 15:28:05 --> Model "Activity_model" initialized
INFO - 2021-07-15 15:28:05 --> Model "Templates_model" initialized
INFO - 2021-07-15 15:28:05 --> Database Driver Class Initialized
INFO - 2021-07-15 15:28:05 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 15:28:05 --> Controller Class Initialized
ERROR - 2021-07-15 15:28:05 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 15:28:05 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-15 15:28:05 --> Final output sent to browser
DEBUG - 2021-07-15 15:28:05 --> Total execution time: 0.3394
INFO - 2021-07-15 15:28:08 --> Config Class Initialized
INFO - 2021-07-15 15:28:08 --> Hooks Class Initialized
DEBUG - 2021-07-15 15:28:08 --> UTF-8 Support Enabled
INFO - 2021-07-15 15:28:08 --> Utf8 Class Initialized
INFO - 2021-07-15 15:28:08 --> URI Class Initialized
INFO - 2021-07-15 15:28:08 --> Router Class Initialized
INFO - 2021-07-15 15:28:08 --> Output Class Initialized
INFO - 2021-07-15 15:28:08 --> Security Class Initialized
DEBUG - 2021-07-15 15:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 15:28:08 --> Input Class Initialized
INFO - 2021-07-15 15:28:08 --> Language Class Initialized
INFO - 2021-07-15 15:28:08 --> Loader Class Initialized
INFO - 2021-07-15 15:28:08 --> Helper loaded: basic_helper
INFO - 2021-07-15 15:28:08 --> Helper loaded: url_helper
INFO - 2021-07-15 15:28:08 --> Helper loaded: file_helper
INFO - 2021-07-15 15:28:08 --> Helper loaded: form_helper
INFO - 2021-07-15 15:28:08 --> Helper loaded: cookie_helper
INFO - 2021-07-15 15:28:08 --> Helper loaded: security_helper
INFO - 2021-07-15 15:28:08 --> Helper loaded: directory_helper
INFO - 2021-07-15 15:28:08 --> Helper loaded: language_helper
INFO - 2021-07-15 15:28:08 --> Helper loaded: general_helper
INFO - 2021-07-15 15:28:08 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 15:28:08 --> Database Driver Class Initialized
DEBUG - 2021-07-15 15:28:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 15:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 15:28:08 --> Parser Class Initialized
INFO - 2021-07-15 15:28:08 --> Form Validation Class Initialized
INFO - 2021-07-15 15:28:08 --> Upload Class Initialized
INFO - 2021-07-15 15:28:08 --> Email Class Initialized
INFO - 2021-07-15 15:28:08 --> MY_Model class loaded
INFO - 2021-07-15 15:28:08 --> Model "Users_model" initialized
INFO - 2021-07-15 15:28:08 --> Model "Settings_model" initialized
INFO - 2021-07-15 15:28:08 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 15:28:08 --> Model "Permissions_model" initialized
INFO - 2021-07-15 15:28:08 --> Model "Roles_model" initialized
INFO - 2021-07-15 15:28:08 --> Model "Activity_model" initialized
INFO - 2021-07-15 15:28:08 --> Model "Templates_model" initialized
INFO - 2021-07-15 15:28:08 --> Database Driver Class Initialized
INFO - 2021-07-15 15:28:08 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 15:28:08 --> Controller Class Initialized
ERROR - 2021-07-15 15:28:08 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-15 15:28:08 --> Severity: error --> Exception: Call to a member function list() on null C:\wamp64\www\crm\application\views\car\car_list.php 40
INFO - 2021-07-15 15:30:57 --> Config Class Initialized
INFO - 2021-07-15 15:30:57 --> Hooks Class Initialized
DEBUG - 2021-07-15 15:30:57 --> UTF-8 Support Enabled
INFO - 2021-07-15 15:30:57 --> Utf8 Class Initialized
INFO - 2021-07-15 15:30:57 --> URI Class Initialized
INFO - 2021-07-15 15:30:57 --> Router Class Initialized
INFO - 2021-07-15 15:30:57 --> Output Class Initialized
INFO - 2021-07-15 15:30:57 --> Security Class Initialized
DEBUG - 2021-07-15 15:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 15:30:57 --> Input Class Initialized
INFO - 2021-07-15 15:30:57 --> Language Class Initialized
INFO - 2021-07-15 15:30:57 --> Loader Class Initialized
INFO - 2021-07-15 15:30:57 --> Helper loaded: basic_helper
INFO - 2021-07-15 15:30:57 --> Helper loaded: url_helper
INFO - 2021-07-15 15:30:57 --> Helper loaded: file_helper
INFO - 2021-07-15 15:30:57 --> Helper loaded: form_helper
INFO - 2021-07-15 15:30:57 --> Helper loaded: cookie_helper
INFO - 2021-07-15 15:30:57 --> Helper loaded: security_helper
INFO - 2021-07-15 15:30:57 --> Helper loaded: directory_helper
INFO - 2021-07-15 15:30:57 --> Helper loaded: language_helper
INFO - 2021-07-15 15:30:57 --> Helper loaded: general_helper
INFO - 2021-07-15 15:30:57 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 15:30:57 --> Database Driver Class Initialized
DEBUG - 2021-07-15 15:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 15:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 15:30:57 --> Parser Class Initialized
INFO - 2021-07-15 15:30:57 --> Form Validation Class Initialized
INFO - 2021-07-15 15:30:57 --> Upload Class Initialized
INFO - 2021-07-15 15:30:57 --> Email Class Initialized
INFO - 2021-07-15 15:30:57 --> MY_Model class loaded
INFO - 2021-07-15 15:30:57 --> Model "Users_model" initialized
INFO - 2021-07-15 15:30:57 --> Model "Settings_model" initialized
INFO - 2021-07-15 15:30:57 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 15:30:57 --> Model "Permissions_model" initialized
INFO - 2021-07-15 15:30:57 --> Model "Roles_model" initialized
INFO - 2021-07-15 15:30:57 --> Model "Activity_model" initialized
INFO - 2021-07-15 15:30:57 --> Model "Templates_model" initialized
INFO - 2021-07-15 15:30:57 --> Database Driver Class Initialized
INFO - 2021-07-15 15:30:57 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 15:30:57 --> Controller Class Initialized
ERROR - 2021-07-15 15:30:57 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-15 15:30:57 --> Severity: error --> Exception: Call to a member function list() on null C:\wamp64\www\crm\application\views\car\car_list.php 40
INFO - 2021-07-15 15:34:37 --> Config Class Initialized
INFO - 2021-07-15 15:34:37 --> Hooks Class Initialized
DEBUG - 2021-07-15 15:34:37 --> UTF-8 Support Enabled
INFO - 2021-07-15 15:34:37 --> Utf8 Class Initialized
INFO - 2021-07-15 15:34:37 --> URI Class Initialized
INFO - 2021-07-15 15:34:37 --> Router Class Initialized
INFO - 2021-07-15 15:34:37 --> Output Class Initialized
INFO - 2021-07-15 15:34:37 --> Security Class Initialized
DEBUG - 2021-07-15 15:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 15:34:37 --> Input Class Initialized
INFO - 2021-07-15 15:34:37 --> Language Class Initialized
INFO - 2021-07-15 15:34:37 --> Loader Class Initialized
INFO - 2021-07-15 15:34:37 --> Helper loaded: basic_helper
INFO - 2021-07-15 15:34:37 --> Helper loaded: url_helper
INFO - 2021-07-15 15:34:37 --> Helper loaded: file_helper
INFO - 2021-07-15 15:34:37 --> Helper loaded: form_helper
INFO - 2021-07-15 15:34:37 --> Helper loaded: cookie_helper
INFO - 2021-07-15 15:34:37 --> Helper loaded: security_helper
INFO - 2021-07-15 15:34:37 --> Helper loaded: directory_helper
INFO - 2021-07-15 15:34:37 --> Helper loaded: language_helper
INFO - 2021-07-15 15:34:37 --> Helper loaded: general_helper
INFO - 2021-07-15 15:34:37 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 15:34:37 --> Database Driver Class Initialized
DEBUG - 2021-07-15 15:34:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 15:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 15:34:37 --> Parser Class Initialized
INFO - 2021-07-15 15:34:37 --> Form Validation Class Initialized
INFO - 2021-07-15 15:34:37 --> Upload Class Initialized
INFO - 2021-07-15 15:34:37 --> Email Class Initialized
INFO - 2021-07-15 15:34:37 --> MY_Model class loaded
INFO - 2021-07-15 15:34:37 --> Model "Users_model" initialized
INFO - 2021-07-15 15:34:37 --> Model "Settings_model" initialized
INFO - 2021-07-15 15:34:37 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 15:34:37 --> Model "Permissions_model" initialized
INFO - 2021-07-15 15:34:37 --> Model "Roles_model" initialized
INFO - 2021-07-15 15:34:37 --> Model "Activity_model" initialized
INFO - 2021-07-15 15:34:37 --> Model "Templates_model" initialized
INFO - 2021-07-15 15:34:37 --> Database Driver Class Initialized
INFO - 2021-07-15 15:34:37 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 15:34:37 --> Controller Class Initialized
ERROR - 2021-07-15 15:34:37 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-15 15:34:37 --> Severity: error --> Exception: Call to a member function list() on null C:\wamp64\www\crm\application\views\car\car_list.php 40
INFO - 2021-07-15 15:35:01 --> Config Class Initialized
INFO - 2021-07-15 15:35:01 --> Hooks Class Initialized
DEBUG - 2021-07-15 15:35:01 --> UTF-8 Support Enabled
INFO - 2021-07-15 15:35:01 --> Utf8 Class Initialized
INFO - 2021-07-15 15:35:01 --> URI Class Initialized
INFO - 2021-07-15 15:35:01 --> Router Class Initialized
INFO - 2021-07-15 15:35:01 --> Output Class Initialized
INFO - 2021-07-15 15:35:01 --> Security Class Initialized
DEBUG - 2021-07-15 15:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 15:35:01 --> Input Class Initialized
INFO - 2021-07-15 15:35:01 --> Language Class Initialized
INFO - 2021-07-15 15:35:01 --> Loader Class Initialized
INFO - 2021-07-15 15:35:01 --> Helper loaded: basic_helper
INFO - 2021-07-15 15:35:01 --> Helper loaded: url_helper
INFO - 2021-07-15 15:35:01 --> Helper loaded: file_helper
INFO - 2021-07-15 15:35:01 --> Helper loaded: form_helper
INFO - 2021-07-15 15:35:01 --> Helper loaded: cookie_helper
INFO - 2021-07-15 15:35:01 --> Helper loaded: security_helper
INFO - 2021-07-15 15:35:01 --> Helper loaded: directory_helper
INFO - 2021-07-15 15:35:01 --> Helper loaded: language_helper
INFO - 2021-07-15 15:35:01 --> Helper loaded: general_helper
INFO - 2021-07-15 15:35:01 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 15:35:01 --> Database Driver Class Initialized
DEBUG - 2021-07-15 15:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 15:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 15:35:01 --> Parser Class Initialized
INFO - 2021-07-15 15:35:01 --> Form Validation Class Initialized
INFO - 2021-07-15 15:35:01 --> Upload Class Initialized
INFO - 2021-07-15 15:35:01 --> Email Class Initialized
INFO - 2021-07-15 15:35:01 --> MY_Model class loaded
INFO - 2021-07-15 15:35:01 --> Model "Users_model" initialized
INFO - 2021-07-15 15:35:01 --> Model "Settings_model" initialized
INFO - 2021-07-15 15:35:01 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 15:35:01 --> Model "Permissions_model" initialized
INFO - 2021-07-15 15:35:01 --> Model "Roles_model" initialized
INFO - 2021-07-15 15:35:01 --> Model "Activity_model" initialized
INFO - 2021-07-15 15:35:01 --> Model "Templates_model" initialized
INFO - 2021-07-15 15:35:01 --> Database Driver Class Initialized
INFO - 2021-07-15 15:35:01 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 15:35:01 --> Controller Class Initialized
ERROR - 2021-07-15 15:35:01 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-15 15:35:01 --> Severity: error --> Exception: Call to a member function list() on null C:\wamp64\www\crm\application\views\car\car_list.php 40
INFO - 2021-07-15 15:35:03 --> Config Class Initialized
INFO - 2021-07-15 15:35:03 --> Hooks Class Initialized
DEBUG - 2021-07-15 15:35:03 --> UTF-8 Support Enabled
INFO - 2021-07-15 15:35:03 --> Utf8 Class Initialized
INFO - 2021-07-15 15:35:03 --> URI Class Initialized
INFO - 2021-07-15 15:35:03 --> Router Class Initialized
INFO - 2021-07-15 15:35:03 --> Output Class Initialized
INFO - 2021-07-15 15:35:03 --> Security Class Initialized
DEBUG - 2021-07-15 15:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 15:35:03 --> Input Class Initialized
INFO - 2021-07-15 15:35:03 --> Language Class Initialized
INFO - 2021-07-15 15:35:03 --> Loader Class Initialized
INFO - 2021-07-15 15:35:03 --> Helper loaded: basic_helper
INFO - 2021-07-15 15:35:03 --> Helper loaded: url_helper
INFO - 2021-07-15 15:35:03 --> Helper loaded: file_helper
INFO - 2021-07-15 15:35:03 --> Helper loaded: form_helper
INFO - 2021-07-15 15:35:03 --> Helper loaded: cookie_helper
INFO - 2021-07-15 15:35:03 --> Helper loaded: security_helper
INFO - 2021-07-15 15:35:03 --> Helper loaded: directory_helper
INFO - 2021-07-15 15:35:03 --> Helper loaded: language_helper
INFO - 2021-07-15 15:35:03 --> Helper loaded: general_helper
INFO - 2021-07-15 15:35:03 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 15:35:03 --> Database Driver Class Initialized
DEBUG - 2021-07-15 15:35:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 15:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 15:35:03 --> Parser Class Initialized
INFO - 2021-07-15 15:35:03 --> Form Validation Class Initialized
INFO - 2021-07-15 15:35:03 --> Upload Class Initialized
INFO - 2021-07-15 15:35:03 --> Email Class Initialized
INFO - 2021-07-15 15:35:03 --> MY_Model class loaded
INFO - 2021-07-15 15:35:03 --> Model "Users_model" initialized
INFO - 2021-07-15 15:35:03 --> Model "Settings_model" initialized
INFO - 2021-07-15 15:35:03 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 15:35:03 --> Model "Permissions_model" initialized
INFO - 2021-07-15 15:35:03 --> Model "Roles_model" initialized
INFO - 2021-07-15 15:35:03 --> Model "Activity_model" initialized
INFO - 2021-07-15 15:35:03 --> Model "Templates_model" initialized
INFO - 2021-07-15 15:35:03 --> Database Driver Class Initialized
INFO - 2021-07-15 15:35:03 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 15:35:03 --> Controller Class Initialized
ERROR - 2021-07-15 15:35:03 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-15 15:35:03 --> Severity: error --> Exception: Call to a member function list() on null C:\wamp64\www\crm\application\views\car\car_list.php 40
INFO - 2021-07-15 15:35:09 --> Config Class Initialized
INFO - 2021-07-15 15:35:09 --> Hooks Class Initialized
DEBUG - 2021-07-15 15:35:09 --> UTF-8 Support Enabled
INFO - 2021-07-15 15:35:09 --> Utf8 Class Initialized
INFO - 2021-07-15 15:35:09 --> URI Class Initialized
INFO - 2021-07-15 15:35:09 --> Router Class Initialized
INFO - 2021-07-15 15:35:09 --> Output Class Initialized
INFO - 2021-07-15 15:35:09 --> Security Class Initialized
DEBUG - 2021-07-15 15:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 15:35:09 --> Input Class Initialized
INFO - 2021-07-15 15:35:09 --> Language Class Initialized
INFO - 2021-07-15 15:35:09 --> Loader Class Initialized
INFO - 2021-07-15 15:35:09 --> Helper loaded: basic_helper
INFO - 2021-07-15 15:35:09 --> Helper loaded: url_helper
INFO - 2021-07-15 15:35:09 --> Helper loaded: file_helper
INFO - 2021-07-15 15:35:09 --> Helper loaded: form_helper
INFO - 2021-07-15 15:35:09 --> Helper loaded: cookie_helper
INFO - 2021-07-15 15:35:09 --> Helper loaded: security_helper
INFO - 2021-07-15 15:35:09 --> Helper loaded: directory_helper
INFO - 2021-07-15 15:35:09 --> Helper loaded: language_helper
INFO - 2021-07-15 15:35:09 --> Helper loaded: general_helper
INFO - 2021-07-15 15:35:09 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 15:35:09 --> Database Driver Class Initialized
DEBUG - 2021-07-15 15:35:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 15:35:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 15:35:09 --> Parser Class Initialized
INFO - 2021-07-15 15:35:09 --> Form Validation Class Initialized
INFO - 2021-07-15 15:35:09 --> Upload Class Initialized
INFO - 2021-07-15 15:35:09 --> Email Class Initialized
INFO - 2021-07-15 15:35:09 --> MY_Model class loaded
INFO - 2021-07-15 15:35:09 --> Model "Users_model" initialized
INFO - 2021-07-15 15:35:09 --> Model "Settings_model" initialized
INFO - 2021-07-15 15:35:09 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 15:35:09 --> Model "Permissions_model" initialized
INFO - 2021-07-15 15:35:09 --> Model "Roles_model" initialized
INFO - 2021-07-15 15:35:09 --> Model "Activity_model" initialized
INFO - 2021-07-15 15:35:09 --> Model "Templates_model" initialized
INFO - 2021-07-15 15:35:09 --> Database Driver Class Initialized
INFO - 2021-07-15 15:35:09 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 15:35:09 --> Controller Class Initialized
ERROR - 2021-07-15 15:35:09 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-15 15:35:09 --> Severity: error --> Exception: Call to a member function list() on null C:\wamp64\www\crm\application\views\car\car_list.php 40
INFO - 2021-07-15 15:35:27 --> Config Class Initialized
INFO - 2021-07-15 15:35:27 --> Hooks Class Initialized
DEBUG - 2021-07-15 15:35:27 --> UTF-8 Support Enabled
INFO - 2021-07-15 15:35:27 --> Utf8 Class Initialized
INFO - 2021-07-15 15:35:27 --> URI Class Initialized
INFO - 2021-07-15 15:35:27 --> Router Class Initialized
INFO - 2021-07-15 15:35:27 --> Output Class Initialized
INFO - 2021-07-15 15:35:27 --> Security Class Initialized
DEBUG - 2021-07-15 15:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 15:35:27 --> Input Class Initialized
INFO - 2021-07-15 15:35:27 --> Language Class Initialized
INFO - 2021-07-15 15:35:27 --> Loader Class Initialized
INFO - 2021-07-15 15:35:27 --> Helper loaded: basic_helper
INFO - 2021-07-15 15:35:27 --> Helper loaded: url_helper
INFO - 2021-07-15 15:35:27 --> Helper loaded: file_helper
INFO - 2021-07-15 15:35:27 --> Helper loaded: form_helper
INFO - 2021-07-15 15:35:27 --> Helper loaded: cookie_helper
INFO - 2021-07-15 15:35:27 --> Helper loaded: security_helper
INFO - 2021-07-15 15:35:27 --> Helper loaded: directory_helper
INFO - 2021-07-15 15:35:27 --> Helper loaded: language_helper
INFO - 2021-07-15 15:35:27 --> Helper loaded: general_helper
INFO - 2021-07-15 15:35:27 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 15:35:27 --> Database Driver Class Initialized
DEBUG - 2021-07-15 15:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 15:35:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 15:35:27 --> Parser Class Initialized
INFO - 2021-07-15 15:35:27 --> Form Validation Class Initialized
INFO - 2021-07-15 15:35:27 --> Upload Class Initialized
INFO - 2021-07-15 15:35:27 --> Email Class Initialized
INFO - 2021-07-15 15:35:27 --> MY_Model class loaded
INFO - 2021-07-15 15:35:27 --> Model "Users_model" initialized
INFO - 2021-07-15 15:35:27 --> Model "Settings_model" initialized
INFO - 2021-07-15 15:35:27 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 15:35:27 --> Model "Permissions_model" initialized
INFO - 2021-07-15 15:35:27 --> Model "Roles_model" initialized
INFO - 2021-07-15 15:35:27 --> Model "Activity_model" initialized
INFO - 2021-07-15 15:35:27 --> Model "Templates_model" initialized
INFO - 2021-07-15 15:35:27 --> Database Driver Class Initialized
INFO - 2021-07-15 15:35:27 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 15:35:27 --> Controller Class Initialized
ERROR - 2021-07-15 15:35:27 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-15 15:35:27 --> Severity: error --> Exception: Call to a member function list() on null C:\wamp64\www\crm\application\views\car\car_list.php 40
INFO - 2021-07-15 15:35:34 --> Config Class Initialized
INFO - 2021-07-15 15:35:34 --> Hooks Class Initialized
DEBUG - 2021-07-15 15:35:34 --> UTF-8 Support Enabled
INFO - 2021-07-15 15:35:34 --> Utf8 Class Initialized
INFO - 2021-07-15 15:35:34 --> URI Class Initialized
INFO - 2021-07-15 15:35:34 --> Router Class Initialized
INFO - 2021-07-15 15:35:34 --> Output Class Initialized
INFO - 2021-07-15 15:35:34 --> Security Class Initialized
DEBUG - 2021-07-15 15:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 15:35:34 --> Input Class Initialized
INFO - 2021-07-15 15:35:34 --> Language Class Initialized
INFO - 2021-07-15 15:35:34 --> Loader Class Initialized
INFO - 2021-07-15 15:35:34 --> Helper loaded: basic_helper
INFO - 2021-07-15 15:35:34 --> Helper loaded: url_helper
INFO - 2021-07-15 15:35:34 --> Helper loaded: file_helper
INFO - 2021-07-15 15:35:34 --> Helper loaded: form_helper
INFO - 2021-07-15 15:35:34 --> Helper loaded: cookie_helper
INFO - 2021-07-15 15:35:34 --> Helper loaded: security_helper
INFO - 2021-07-15 15:35:34 --> Helper loaded: directory_helper
INFO - 2021-07-15 15:35:34 --> Helper loaded: language_helper
INFO - 2021-07-15 15:35:34 --> Helper loaded: general_helper
INFO - 2021-07-15 15:35:34 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 15:35:34 --> Database Driver Class Initialized
DEBUG - 2021-07-15 15:35:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 15:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 15:35:34 --> Parser Class Initialized
INFO - 2021-07-15 15:35:34 --> Form Validation Class Initialized
INFO - 2021-07-15 15:35:34 --> Upload Class Initialized
INFO - 2021-07-15 15:35:34 --> Email Class Initialized
INFO - 2021-07-15 15:35:34 --> MY_Model class loaded
INFO - 2021-07-15 15:35:34 --> Model "Users_model" initialized
INFO - 2021-07-15 15:35:34 --> Model "Settings_model" initialized
INFO - 2021-07-15 15:35:34 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 15:35:34 --> Model "Permissions_model" initialized
INFO - 2021-07-15 15:35:34 --> Model "Roles_model" initialized
INFO - 2021-07-15 15:35:34 --> Model "Activity_model" initialized
INFO - 2021-07-15 15:35:34 --> Model "Templates_model" initialized
INFO - 2021-07-15 15:35:34 --> Database Driver Class Initialized
INFO - 2021-07-15 15:35:34 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 15:35:34 --> Controller Class Initialized
ERROR - 2021-07-15 15:35:34 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-15 15:35:34 --> Severity: error --> Exception: Call to a member function list() on null C:\wamp64\www\crm\application\views\car\car_list.php 40
INFO - 2021-07-15 15:35:35 --> Config Class Initialized
INFO - 2021-07-15 15:35:35 --> Hooks Class Initialized
DEBUG - 2021-07-15 15:35:35 --> UTF-8 Support Enabled
INFO - 2021-07-15 15:35:35 --> Utf8 Class Initialized
INFO - 2021-07-15 15:35:35 --> URI Class Initialized
INFO - 2021-07-15 15:35:35 --> Router Class Initialized
INFO - 2021-07-15 15:35:35 --> Output Class Initialized
INFO - 2021-07-15 15:35:35 --> Security Class Initialized
DEBUG - 2021-07-15 15:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 15:35:35 --> Input Class Initialized
INFO - 2021-07-15 15:35:35 --> Language Class Initialized
INFO - 2021-07-15 15:35:35 --> Loader Class Initialized
INFO - 2021-07-15 15:35:35 --> Helper loaded: basic_helper
INFO - 2021-07-15 15:35:35 --> Helper loaded: url_helper
INFO - 2021-07-15 15:35:35 --> Helper loaded: file_helper
INFO - 2021-07-15 15:35:35 --> Helper loaded: form_helper
INFO - 2021-07-15 15:35:35 --> Helper loaded: cookie_helper
INFO - 2021-07-15 15:35:35 --> Helper loaded: security_helper
INFO - 2021-07-15 15:35:35 --> Helper loaded: directory_helper
INFO - 2021-07-15 15:35:35 --> Helper loaded: language_helper
INFO - 2021-07-15 15:35:35 --> Helper loaded: general_helper
INFO - 2021-07-15 15:35:35 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 15:35:35 --> Database Driver Class Initialized
DEBUG - 2021-07-15 15:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 15:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 15:35:35 --> Parser Class Initialized
INFO - 2021-07-15 15:35:35 --> Form Validation Class Initialized
INFO - 2021-07-15 15:35:35 --> Upload Class Initialized
INFO - 2021-07-15 15:35:35 --> Email Class Initialized
INFO - 2021-07-15 15:35:35 --> MY_Model class loaded
INFO - 2021-07-15 15:35:35 --> Model "Users_model" initialized
INFO - 2021-07-15 15:35:35 --> Model "Settings_model" initialized
INFO - 2021-07-15 15:35:35 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 15:35:35 --> Model "Permissions_model" initialized
INFO - 2021-07-15 15:35:35 --> Model "Roles_model" initialized
INFO - 2021-07-15 15:35:35 --> Model "Activity_model" initialized
INFO - 2021-07-15 15:35:35 --> Model "Templates_model" initialized
INFO - 2021-07-15 15:35:35 --> Database Driver Class Initialized
INFO - 2021-07-15 15:35:35 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 15:35:35 --> Controller Class Initialized
ERROR - 2021-07-15 15:35:35 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-15 15:35:35 --> Severity: error --> Exception: Call to a member function list() on null C:\wamp64\www\crm\application\views\car\car_list.php 40
INFO - 2021-07-15 15:36:40 --> Config Class Initialized
INFO - 2021-07-15 15:36:40 --> Hooks Class Initialized
DEBUG - 2021-07-15 15:36:40 --> UTF-8 Support Enabled
INFO - 2021-07-15 15:36:40 --> Utf8 Class Initialized
INFO - 2021-07-15 15:36:40 --> URI Class Initialized
INFO - 2021-07-15 15:36:40 --> Router Class Initialized
INFO - 2021-07-15 15:36:40 --> Output Class Initialized
INFO - 2021-07-15 15:36:40 --> Security Class Initialized
DEBUG - 2021-07-15 15:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 15:36:40 --> Input Class Initialized
INFO - 2021-07-15 15:36:40 --> Language Class Initialized
INFO - 2021-07-15 15:36:40 --> Loader Class Initialized
INFO - 2021-07-15 15:36:40 --> Helper loaded: basic_helper
INFO - 2021-07-15 15:36:40 --> Helper loaded: url_helper
INFO - 2021-07-15 15:36:40 --> Helper loaded: file_helper
INFO - 2021-07-15 15:36:40 --> Helper loaded: form_helper
INFO - 2021-07-15 15:36:40 --> Helper loaded: cookie_helper
INFO - 2021-07-15 15:36:40 --> Helper loaded: security_helper
INFO - 2021-07-15 15:36:40 --> Helper loaded: directory_helper
INFO - 2021-07-15 15:36:40 --> Helper loaded: language_helper
INFO - 2021-07-15 15:36:40 --> Helper loaded: general_helper
INFO - 2021-07-15 15:36:40 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 15:36:40 --> Database Driver Class Initialized
DEBUG - 2021-07-15 15:36:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 15:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 15:36:40 --> Parser Class Initialized
INFO - 2021-07-15 15:36:40 --> Form Validation Class Initialized
INFO - 2021-07-15 15:36:40 --> Upload Class Initialized
INFO - 2021-07-15 15:36:40 --> Email Class Initialized
INFO - 2021-07-15 15:36:40 --> MY_Model class loaded
INFO - 2021-07-15 15:36:40 --> Model "Users_model" initialized
INFO - 2021-07-15 15:36:40 --> Model "Settings_model" initialized
INFO - 2021-07-15 15:36:40 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 15:36:40 --> Model "Permissions_model" initialized
INFO - 2021-07-15 15:36:40 --> Model "Roles_model" initialized
INFO - 2021-07-15 15:36:40 --> Model "Activity_model" initialized
INFO - 2021-07-15 15:36:40 --> Model "Templates_model" initialized
INFO - 2021-07-15 15:36:40 --> Database Driver Class Initialized
INFO - 2021-07-15 15:36:40 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 15:36:40 --> Controller Class Initialized
ERROR - 2021-07-15 15:36:40 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-15 15:36:40 --> Severity: error --> Exception: Call to a member function list() on null C:\wamp64\www\crm\application\views\car\car_list.php 40
INFO - 2021-07-15 15:38:15 --> Config Class Initialized
INFO - 2021-07-15 15:38:15 --> Hooks Class Initialized
DEBUG - 2021-07-15 15:38:15 --> UTF-8 Support Enabled
INFO - 2021-07-15 15:38:15 --> Utf8 Class Initialized
INFO - 2021-07-15 15:38:15 --> URI Class Initialized
DEBUG - 2021-07-15 15:38:15 --> No URI present. Default controller set.
INFO - 2021-07-15 15:38:15 --> Router Class Initialized
INFO - 2021-07-15 15:38:15 --> Output Class Initialized
INFO - 2021-07-15 15:38:15 --> Security Class Initialized
DEBUG - 2021-07-15 15:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 15:38:15 --> Input Class Initialized
INFO - 2021-07-15 15:38:15 --> Language Class Initialized
INFO - 2021-07-15 15:38:15 --> Loader Class Initialized
INFO - 2021-07-15 15:38:15 --> Helper loaded: basic_helper
INFO - 2021-07-15 15:38:15 --> Helper loaded: url_helper
INFO - 2021-07-15 15:38:15 --> Helper loaded: file_helper
INFO - 2021-07-15 15:38:15 --> Helper loaded: form_helper
INFO - 2021-07-15 15:38:15 --> Helper loaded: cookie_helper
INFO - 2021-07-15 15:38:15 --> Helper loaded: security_helper
INFO - 2021-07-15 15:38:15 --> Helper loaded: directory_helper
INFO - 2021-07-15 15:38:15 --> Helper loaded: language_helper
INFO - 2021-07-15 15:38:15 --> Helper loaded: general_helper
INFO - 2021-07-15 15:38:15 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 15:38:15 --> Database Driver Class Initialized
DEBUG - 2021-07-15 15:38:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 15:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 15:38:15 --> Parser Class Initialized
INFO - 2021-07-15 15:38:15 --> Form Validation Class Initialized
INFO - 2021-07-15 15:38:15 --> Upload Class Initialized
INFO - 2021-07-15 15:38:15 --> Email Class Initialized
INFO - 2021-07-15 15:38:15 --> MY_Model class loaded
INFO - 2021-07-15 15:38:15 --> Model "Users_model" initialized
INFO - 2021-07-15 15:38:15 --> Model "Settings_model" initialized
INFO - 2021-07-15 15:38:15 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 15:38:15 --> Model "Permissions_model" initialized
INFO - 2021-07-15 15:38:15 --> Model "Roles_model" initialized
INFO - 2021-07-15 15:38:15 --> Model "Activity_model" initialized
INFO - 2021-07-15 15:38:15 --> Model "Templates_model" initialized
INFO - 2021-07-15 15:38:15 --> Database Driver Class Initialized
INFO - 2021-07-15 15:38:15 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 15:38:15 --> Controller Class Initialized
INFO - 2021-07-15 15:49:11 --> Config Class Initialized
INFO - 2021-07-15 15:49:11 --> Hooks Class Initialized
DEBUG - 2021-07-15 15:49:11 --> UTF-8 Support Enabled
INFO - 2021-07-15 15:49:11 --> Utf8 Class Initialized
INFO - 2021-07-15 15:49:11 --> URI Class Initialized
INFO - 2021-07-15 15:49:11 --> Router Class Initialized
INFO - 2021-07-15 15:49:11 --> Output Class Initialized
INFO - 2021-07-15 15:49:11 --> Security Class Initialized
DEBUG - 2021-07-15 15:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 15:49:11 --> Input Class Initialized
INFO - 2021-07-15 15:49:11 --> Language Class Initialized
INFO - 2021-07-15 15:49:11 --> Loader Class Initialized
INFO - 2021-07-15 15:49:11 --> Helper loaded: basic_helper
INFO - 2021-07-15 15:49:11 --> Helper loaded: url_helper
INFO - 2021-07-15 15:49:11 --> Helper loaded: file_helper
INFO - 2021-07-15 15:49:11 --> Helper loaded: form_helper
INFO - 2021-07-15 15:49:11 --> Helper loaded: cookie_helper
INFO - 2021-07-15 15:49:11 --> Helper loaded: security_helper
INFO - 2021-07-15 15:49:11 --> Helper loaded: directory_helper
INFO - 2021-07-15 15:49:11 --> Helper loaded: language_helper
INFO - 2021-07-15 15:49:11 --> Helper loaded: general_helper
INFO - 2021-07-15 15:49:11 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 15:49:11 --> Database Driver Class Initialized
DEBUG - 2021-07-15 15:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 15:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 15:49:11 --> Parser Class Initialized
INFO - 2021-07-15 15:49:11 --> Form Validation Class Initialized
INFO - 2021-07-15 15:49:11 --> Upload Class Initialized
INFO - 2021-07-15 15:49:11 --> Email Class Initialized
INFO - 2021-07-15 15:49:11 --> MY_Model class loaded
INFO - 2021-07-15 15:49:11 --> Model "Users_model" initialized
INFO - 2021-07-15 15:49:11 --> Model "Settings_model" initialized
INFO - 2021-07-15 15:49:11 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 15:49:11 --> Model "Permissions_model" initialized
INFO - 2021-07-15 15:49:11 --> Model "Roles_model" initialized
INFO - 2021-07-15 15:49:11 --> Model "Activity_model" initialized
INFO - 2021-07-15 15:49:11 --> Model "Templates_model" initialized
INFO - 2021-07-15 15:49:11 --> Database Driver Class Initialized
INFO - 2021-07-15 15:49:11 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 15:49:11 --> Controller Class Initialized
ERROR - 2021-07-15 15:49:11 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-15 15:49:11 --> Severity: error --> Exception: Call to a member function list() on null C:\wamp64\www\crm\application\views\car\car_list.php 40
INFO - 2021-07-15 15:49:57 --> Config Class Initialized
INFO - 2021-07-15 15:49:57 --> Hooks Class Initialized
DEBUG - 2021-07-15 15:49:57 --> UTF-8 Support Enabled
INFO - 2021-07-15 15:49:57 --> Utf8 Class Initialized
INFO - 2021-07-15 15:49:57 --> URI Class Initialized
INFO - 2021-07-15 15:49:57 --> Router Class Initialized
INFO - 2021-07-15 15:49:57 --> Output Class Initialized
INFO - 2021-07-15 15:49:57 --> Security Class Initialized
DEBUG - 2021-07-15 15:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 15:49:57 --> Input Class Initialized
INFO - 2021-07-15 15:49:57 --> Language Class Initialized
INFO - 2021-07-15 15:49:57 --> Loader Class Initialized
INFO - 2021-07-15 15:49:57 --> Helper loaded: basic_helper
INFO - 2021-07-15 15:49:57 --> Helper loaded: url_helper
INFO - 2021-07-15 15:49:57 --> Helper loaded: file_helper
INFO - 2021-07-15 15:49:57 --> Helper loaded: form_helper
INFO - 2021-07-15 15:49:57 --> Helper loaded: cookie_helper
INFO - 2021-07-15 15:49:57 --> Helper loaded: security_helper
INFO - 2021-07-15 15:49:57 --> Helper loaded: directory_helper
INFO - 2021-07-15 15:49:57 --> Helper loaded: language_helper
INFO - 2021-07-15 15:49:57 --> Helper loaded: general_helper
INFO - 2021-07-15 15:49:57 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 15:49:57 --> Database Driver Class Initialized
DEBUG - 2021-07-15 15:49:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 15:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 15:49:57 --> Parser Class Initialized
INFO - 2021-07-15 15:49:57 --> Form Validation Class Initialized
INFO - 2021-07-15 15:49:57 --> Upload Class Initialized
INFO - 2021-07-15 15:49:57 --> Email Class Initialized
INFO - 2021-07-15 15:49:57 --> MY_Model class loaded
INFO - 2021-07-15 15:49:57 --> Model "Users_model" initialized
INFO - 2021-07-15 15:49:57 --> Model "Settings_model" initialized
INFO - 2021-07-15 15:49:57 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 15:49:57 --> Model "Permissions_model" initialized
INFO - 2021-07-15 15:49:57 --> Model "Roles_model" initialized
INFO - 2021-07-15 15:49:57 --> Model "Activity_model" initialized
INFO - 2021-07-15 15:49:57 --> Model "Templates_model" initialized
INFO - 2021-07-15 15:49:57 --> Database Driver Class Initialized
INFO - 2021-07-15 15:49:57 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 15:49:57 --> Controller Class Initialized
ERROR - 2021-07-15 15:49:57 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-15 15:49:57 --> Severity: error --> Exception: Call to a member function list() on null C:\wamp64\www\crm\application\views\car\car_list.php 40
INFO - 2021-07-15 15:49:58 --> Config Class Initialized
INFO - 2021-07-15 15:49:58 --> Hooks Class Initialized
DEBUG - 2021-07-15 15:49:58 --> UTF-8 Support Enabled
INFO - 2021-07-15 15:49:58 --> Utf8 Class Initialized
INFO - 2021-07-15 15:49:58 --> URI Class Initialized
INFO - 2021-07-15 15:49:58 --> Router Class Initialized
INFO - 2021-07-15 15:49:58 --> Output Class Initialized
INFO - 2021-07-15 15:49:58 --> Security Class Initialized
DEBUG - 2021-07-15 15:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 15:49:58 --> Input Class Initialized
INFO - 2021-07-15 15:49:58 --> Language Class Initialized
INFO - 2021-07-15 15:49:58 --> Loader Class Initialized
INFO - 2021-07-15 15:49:58 --> Helper loaded: basic_helper
INFO - 2021-07-15 15:49:58 --> Helper loaded: url_helper
INFO - 2021-07-15 15:49:58 --> Helper loaded: file_helper
INFO - 2021-07-15 15:49:58 --> Helper loaded: form_helper
INFO - 2021-07-15 15:49:58 --> Helper loaded: cookie_helper
INFO - 2021-07-15 15:49:58 --> Helper loaded: security_helper
INFO - 2021-07-15 15:49:58 --> Helper loaded: directory_helper
INFO - 2021-07-15 15:49:58 --> Helper loaded: language_helper
INFO - 2021-07-15 15:49:58 --> Helper loaded: general_helper
INFO - 2021-07-15 15:49:58 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 15:49:58 --> Database Driver Class Initialized
DEBUG - 2021-07-15 15:49:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 15:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 15:49:58 --> Parser Class Initialized
INFO - 2021-07-15 15:49:58 --> Form Validation Class Initialized
INFO - 2021-07-15 15:49:58 --> Upload Class Initialized
INFO - 2021-07-15 15:49:58 --> Email Class Initialized
INFO - 2021-07-15 15:49:58 --> MY_Model class loaded
INFO - 2021-07-15 15:49:58 --> Model "Users_model" initialized
INFO - 2021-07-15 15:49:58 --> Model "Settings_model" initialized
INFO - 2021-07-15 15:49:58 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 15:49:58 --> Model "Permissions_model" initialized
INFO - 2021-07-15 15:49:58 --> Model "Roles_model" initialized
INFO - 2021-07-15 15:49:58 --> Model "Activity_model" initialized
INFO - 2021-07-15 15:49:58 --> Model "Templates_model" initialized
INFO - 2021-07-15 15:49:58 --> Database Driver Class Initialized
INFO - 2021-07-15 15:49:58 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 15:49:58 --> Controller Class Initialized
ERROR - 2021-07-15 15:49:58 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-15 15:49:58 --> Severity: error --> Exception: Call to a member function list() on null C:\wamp64\www\crm\application\views\car\car_list.php 40
INFO - 2021-07-15 15:50:01 --> Config Class Initialized
INFO - 2021-07-15 15:50:01 --> Hooks Class Initialized
DEBUG - 2021-07-15 15:50:01 --> UTF-8 Support Enabled
INFO - 2021-07-15 15:50:01 --> Utf8 Class Initialized
INFO - 2021-07-15 15:50:01 --> URI Class Initialized
INFO - 2021-07-15 15:50:01 --> Router Class Initialized
INFO - 2021-07-15 15:50:01 --> Output Class Initialized
INFO - 2021-07-15 15:50:01 --> Security Class Initialized
DEBUG - 2021-07-15 15:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 15:50:01 --> Input Class Initialized
INFO - 2021-07-15 15:50:01 --> Language Class Initialized
INFO - 2021-07-15 15:50:01 --> Loader Class Initialized
INFO - 2021-07-15 15:50:01 --> Helper loaded: basic_helper
INFO - 2021-07-15 15:50:01 --> Helper loaded: url_helper
INFO - 2021-07-15 15:50:01 --> Helper loaded: file_helper
INFO - 2021-07-15 15:50:01 --> Helper loaded: form_helper
INFO - 2021-07-15 15:50:01 --> Helper loaded: cookie_helper
INFO - 2021-07-15 15:50:01 --> Helper loaded: security_helper
INFO - 2021-07-15 15:50:01 --> Helper loaded: directory_helper
INFO - 2021-07-15 15:50:01 --> Helper loaded: language_helper
INFO - 2021-07-15 15:50:01 --> Helper loaded: general_helper
INFO - 2021-07-15 15:50:01 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 15:50:01 --> Database Driver Class Initialized
DEBUG - 2021-07-15 15:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 15:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 15:50:01 --> Parser Class Initialized
INFO - 2021-07-15 15:50:01 --> Form Validation Class Initialized
INFO - 2021-07-15 15:50:01 --> Upload Class Initialized
INFO - 2021-07-15 15:50:01 --> Email Class Initialized
INFO - 2021-07-15 15:50:01 --> MY_Model class loaded
INFO - 2021-07-15 15:50:01 --> Model "Users_model" initialized
INFO - 2021-07-15 15:50:01 --> Model "Settings_model" initialized
INFO - 2021-07-15 15:50:01 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 15:50:01 --> Model "Permissions_model" initialized
INFO - 2021-07-15 15:50:01 --> Model "Roles_model" initialized
INFO - 2021-07-15 15:50:01 --> Model "Activity_model" initialized
INFO - 2021-07-15 15:50:01 --> Model "Templates_model" initialized
INFO - 2021-07-15 15:50:01 --> Database Driver Class Initialized
INFO - 2021-07-15 15:50:01 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 15:50:01 --> Controller Class Initialized
ERROR - 2021-07-15 15:50:01 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-15 15:50:01 --> Severity: error --> Exception: Call to a member function list() on null C:\wamp64\www\crm\application\views\car\car_list.php 40
INFO - 2021-07-15 15:50:02 --> Config Class Initialized
INFO - 2021-07-15 15:50:02 --> Hooks Class Initialized
DEBUG - 2021-07-15 15:50:02 --> UTF-8 Support Enabled
INFO - 2021-07-15 15:50:02 --> Utf8 Class Initialized
INFO - 2021-07-15 15:50:02 --> URI Class Initialized
INFO - 2021-07-15 15:50:02 --> Router Class Initialized
INFO - 2021-07-15 15:50:02 --> Output Class Initialized
INFO - 2021-07-15 15:50:02 --> Security Class Initialized
DEBUG - 2021-07-15 15:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 15:50:02 --> Input Class Initialized
INFO - 2021-07-15 15:50:02 --> Language Class Initialized
INFO - 2021-07-15 15:50:02 --> Loader Class Initialized
INFO - 2021-07-15 15:50:02 --> Helper loaded: basic_helper
INFO - 2021-07-15 15:50:02 --> Helper loaded: url_helper
INFO - 2021-07-15 15:50:02 --> Helper loaded: file_helper
INFO - 2021-07-15 15:50:02 --> Helper loaded: form_helper
INFO - 2021-07-15 15:50:02 --> Helper loaded: cookie_helper
INFO - 2021-07-15 15:50:02 --> Helper loaded: security_helper
INFO - 2021-07-15 15:50:02 --> Helper loaded: directory_helper
INFO - 2021-07-15 15:50:02 --> Helper loaded: language_helper
INFO - 2021-07-15 15:50:02 --> Helper loaded: general_helper
INFO - 2021-07-15 15:50:02 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 15:50:02 --> Database Driver Class Initialized
DEBUG - 2021-07-15 15:50:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 15:50:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 15:50:02 --> Parser Class Initialized
INFO - 2021-07-15 15:50:02 --> Form Validation Class Initialized
INFO - 2021-07-15 15:50:02 --> Upload Class Initialized
INFO - 2021-07-15 15:50:02 --> Email Class Initialized
INFO - 2021-07-15 15:50:02 --> MY_Model class loaded
INFO - 2021-07-15 15:50:02 --> Model "Users_model" initialized
INFO - 2021-07-15 15:50:02 --> Model "Settings_model" initialized
INFO - 2021-07-15 15:50:02 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 15:50:02 --> Model "Permissions_model" initialized
INFO - 2021-07-15 15:50:02 --> Model "Roles_model" initialized
INFO - 2021-07-15 15:50:02 --> Model "Activity_model" initialized
INFO - 2021-07-15 15:50:02 --> Model "Templates_model" initialized
INFO - 2021-07-15 15:50:02 --> Database Driver Class Initialized
INFO - 2021-07-15 15:50:02 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 15:50:02 --> Controller Class Initialized
ERROR - 2021-07-15 15:50:02 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-15 15:50:02 --> Severity: error --> Exception: Call to a member function list() on null C:\wamp64\www\crm\application\views\car\car_list.php 40
INFO - 2021-07-15 15:51:56 --> Config Class Initialized
INFO - 2021-07-15 15:51:56 --> Hooks Class Initialized
DEBUG - 2021-07-15 15:51:56 --> UTF-8 Support Enabled
INFO - 2021-07-15 15:51:56 --> Utf8 Class Initialized
INFO - 2021-07-15 15:51:56 --> URI Class Initialized
INFO - 2021-07-15 15:51:56 --> Router Class Initialized
INFO - 2021-07-15 15:51:56 --> Output Class Initialized
INFO - 2021-07-15 15:51:56 --> Security Class Initialized
DEBUG - 2021-07-15 15:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 15:51:56 --> Input Class Initialized
INFO - 2021-07-15 15:51:56 --> Language Class Initialized
INFO - 2021-07-15 15:51:56 --> Loader Class Initialized
INFO - 2021-07-15 15:51:56 --> Helper loaded: basic_helper
INFO - 2021-07-15 15:51:56 --> Helper loaded: url_helper
INFO - 2021-07-15 15:51:56 --> Helper loaded: file_helper
INFO - 2021-07-15 15:51:56 --> Helper loaded: form_helper
INFO - 2021-07-15 15:51:56 --> Helper loaded: cookie_helper
INFO - 2021-07-15 15:51:56 --> Helper loaded: security_helper
INFO - 2021-07-15 15:51:56 --> Helper loaded: directory_helper
INFO - 2021-07-15 15:51:56 --> Helper loaded: language_helper
INFO - 2021-07-15 15:51:56 --> Helper loaded: general_helper
INFO - 2021-07-15 15:51:56 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 15:51:56 --> Database Driver Class Initialized
DEBUG - 2021-07-15 15:51:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 15:51:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 15:51:56 --> Parser Class Initialized
INFO - 2021-07-15 15:51:56 --> Form Validation Class Initialized
INFO - 2021-07-15 15:51:56 --> Upload Class Initialized
INFO - 2021-07-15 15:51:56 --> Email Class Initialized
INFO - 2021-07-15 15:51:56 --> MY_Model class loaded
INFO - 2021-07-15 15:51:56 --> Model "Users_model" initialized
INFO - 2021-07-15 15:51:56 --> Model "Settings_model" initialized
INFO - 2021-07-15 15:51:56 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 15:51:56 --> Model "Permissions_model" initialized
INFO - 2021-07-15 15:51:56 --> Model "Roles_model" initialized
INFO - 2021-07-15 15:51:56 --> Model "Activity_model" initialized
INFO - 2021-07-15 15:51:56 --> Model "Templates_model" initialized
INFO - 2021-07-15 15:51:56 --> Database Driver Class Initialized
INFO - 2021-07-15 15:51:56 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 15:51:56 --> Controller Class Initialized
ERROR - 2021-07-15 15:51:56 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-15 15:51:56 --> Severity: error --> Exception: Call to a member function list() on null C:\wamp64\www\crm\application\views\car\car_list.php 40
INFO - 2021-07-15 15:51:58 --> Config Class Initialized
INFO - 2021-07-15 15:51:58 --> Hooks Class Initialized
DEBUG - 2021-07-15 15:51:58 --> UTF-8 Support Enabled
INFO - 2021-07-15 15:51:58 --> Utf8 Class Initialized
INFO - 2021-07-15 15:51:58 --> URI Class Initialized
INFO - 2021-07-15 15:51:58 --> Router Class Initialized
INFO - 2021-07-15 15:51:58 --> Output Class Initialized
INFO - 2021-07-15 15:51:58 --> Security Class Initialized
DEBUG - 2021-07-15 15:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 15:51:58 --> Input Class Initialized
INFO - 2021-07-15 15:51:58 --> Language Class Initialized
INFO - 2021-07-15 15:51:58 --> Loader Class Initialized
INFO - 2021-07-15 15:51:58 --> Helper loaded: basic_helper
INFO - 2021-07-15 15:51:58 --> Helper loaded: url_helper
INFO - 2021-07-15 15:51:58 --> Helper loaded: file_helper
INFO - 2021-07-15 15:51:58 --> Helper loaded: form_helper
INFO - 2021-07-15 15:51:58 --> Helper loaded: cookie_helper
INFO - 2021-07-15 15:51:58 --> Helper loaded: security_helper
INFO - 2021-07-15 15:51:58 --> Helper loaded: directory_helper
INFO - 2021-07-15 15:51:58 --> Helper loaded: language_helper
INFO - 2021-07-15 15:51:58 --> Helper loaded: general_helper
INFO - 2021-07-15 15:51:58 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 15:51:58 --> Database Driver Class Initialized
DEBUG - 2021-07-15 15:51:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 15:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 15:51:58 --> Parser Class Initialized
INFO - 2021-07-15 15:51:58 --> Form Validation Class Initialized
INFO - 2021-07-15 15:51:58 --> Upload Class Initialized
INFO - 2021-07-15 15:51:58 --> Email Class Initialized
INFO - 2021-07-15 15:51:58 --> MY_Model class loaded
INFO - 2021-07-15 15:51:58 --> Model "Users_model" initialized
INFO - 2021-07-15 15:51:58 --> Model "Settings_model" initialized
INFO - 2021-07-15 15:51:58 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 15:51:58 --> Model "Permissions_model" initialized
INFO - 2021-07-15 15:51:58 --> Model "Roles_model" initialized
INFO - 2021-07-15 15:51:58 --> Model "Activity_model" initialized
INFO - 2021-07-15 15:51:58 --> Model "Templates_model" initialized
INFO - 2021-07-15 15:51:58 --> Database Driver Class Initialized
INFO - 2021-07-15 15:51:58 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 15:51:58 --> Controller Class Initialized
ERROR - 2021-07-15 15:51:58 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-15 15:51:58 --> Severity: error --> Exception: Call to a member function list() on null C:\wamp64\www\crm\application\views\car\car_list.php 40
INFO - 2021-07-15 15:52:04 --> Config Class Initialized
INFO - 2021-07-15 15:52:04 --> Hooks Class Initialized
DEBUG - 2021-07-15 15:52:04 --> UTF-8 Support Enabled
INFO - 2021-07-15 15:52:04 --> Utf8 Class Initialized
INFO - 2021-07-15 15:52:04 --> URI Class Initialized
INFO - 2021-07-15 15:52:04 --> Router Class Initialized
INFO - 2021-07-15 15:52:04 --> Output Class Initialized
INFO - 2021-07-15 15:52:04 --> Security Class Initialized
DEBUG - 2021-07-15 15:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 15:52:04 --> Input Class Initialized
INFO - 2021-07-15 15:52:04 --> Language Class Initialized
INFO - 2021-07-15 15:52:04 --> Loader Class Initialized
INFO - 2021-07-15 15:52:04 --> Helper loaded: basic_helper
INFO - 2021-07-15 15:52:04 --> Helper loaded: url_helper
INFO - 2021-07-15 15:52:04 --> Helper loaded: file_helper
INFO - 2021-07-15 15:52:04 --> Helper loaded: form_helper
INFO - 2021-07-15 15:52:04 --> Helper loaded: cookie_helper
INFO - 2021-07-15 15:52:04 --> Helper loaded: security_helper
INFO - 2021-07-15 15:52:04 --> Helper loaded: directory_helper
INFO - 2021-07-15 15:52:04 --> Helper loaded: language_helper
INFO - 2021-07-15 15:52:04 --> Helper loaded: general_helper
INFO - 2021-07-15 15:52:04 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 15:52:04 --> Database Driver Class Initialized
DEBUG - 2021-07-15 15:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 15:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 15:52:04 --> Parser Class Initialized
INFO - 2021-07-15 15:52:04 --> Form Validation Class Initialized
INFO - 2021-07-15 15:52:04 --> Upload Class Initialized
INFO - 2021-07-15 15:52:04 --> Email Class Initialized
INFO - 2021-07-15 15:52:04 --> MY_Model class loaded
INFO - 2021-07-15 15:52:04 --> Model "Users_model" initialized
INFO - 2021-07-15 15:52:04 --> Model "Settings_model" initialized
INFO - 2021-07-15 15:52:04 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 15:52:04 --> Model "Permissions_model" initialized
INFO - 2021-07-15 15:52:04 --> Model "Roles_model" initialized
INFO - 2021-07-15 15:52:04 --> Model "Activity_model" initialized
INFO - 2021-07-15 15:52:04 --> Model "Templates_model" initialized
INFO - 2021-07-15 15:52:04 --> Database Driver Class Initialized
INFO - 2021-07-15 15:52:05 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 15:52:05 --> Controller Class Initialized
ERROR - 2021-07-15 15:52:05 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-15 15:52:05 --> Severity: error --> Exception: Call to a member function list() on null C:\wamp64\www\crm\application\views\car\car_list.php 40
INFO - 2021-07-15 15:52:06 --> Config Class Initialized
INFO - 2021-07-15 15:52:06 --> Hooks Class Initialized
DEBUG - 2021-07-15 15:52:06 --> UTF-8 Support Enabled
INFO - 2021-07-15 15:52:06 --> Utf8 Class Initialized
INFO - 2021-07-15 15:52:06 --> URI Class Initialized
INFO - 2021-07-15 15:52:06 --> Router Class Initialized
INFO - 2021-07-15 15:52:06 --> Output Class Initialized
INFO - 2021-07-15 15:52:06 --> Security Class Initialized
DEBUG - 2021-07-15 15:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 15:52:06 --> Input Class Initialized
INFO - 2021-07-15 15:52:06 --> Language Class Initialized
INFO - 2021-07-15 15:52:06 --> Loader Class Initialized
INFO - 2021-07-15 15:52:06 --> Helper loaded: basic_helper
INFO - 2021-07-15 15:52:06 --> Helper loaded: url_helper
INFO - 2021-07-15 15:52:06 --> Helper loaded: file_helper
INFO - 2021-07-15 15:52:06 --> Helper loaded: form_helper
INFO - 2021-07-15 15:52:06 --> Helper loaded: cookie_helper
INFO - 2021-07-15 15:52:06 --> Helper loaded: security_helper
INFO - 2021-07-15 15:52:06 --> Helper loaded: directory_helper
INFO - 2021-07-15 15:52:06 --> Helper loaded: language_helper
INFO - 2021-07-15 15:52:06 --> Helper loaded: general_helper
INFO - 2021-07-15 15:52:06 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 15:52:06 --> Database Driver Class Initialized
DEBUG - 2021-07-15 15:52:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 15:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 15:52:06 --> Parser Class Initialized
INFO - 2021-07-15 15:52:06 --> Form Validation Class Initialized
INFO - 2021-07-15 15:52:06 --> Upload Class Initialized
INFO - 2021-07-15 15:52:06 --> Email Class Initialized
INFO - 2021-07-15 15:52:06 --> MY_Model class loaded
INFO - 2021-07-15 15:52:06 --> Model "Users_model" initialized
INFO - 2021-07-15 15:52:06 --> Model "Settings_model" initialized
INFO - 2021-07-15 15:52:06 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 15:52:06 --> Model "Permissions_model" initialized
INFO - 2021-07-15 15:52:06 --> Model "Roles_model" initialized
INFO - 2021-07-15 15:52:06 --> Model "Activity_model" initialized
INFO - 2021-07-15 15:52:06 --> Model "Templates_model" initialized
INFO - 2021-07-15 15:52:06 --> Database Driver Class Initialized
INFO - 2021-07-15 15:52:06 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 15:52:06 --> Controller Class Initialized
ERROR - 2021-07-15 15:52:06 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 15:52:06 --> File loaded: C:\wamp64\www\crm\application\views\blank_page.php
INFO - 2021-07-15 15:52:06 --> Final output sent to browser
DEBUG - 2021-07-15 15:52:06 --> Total execution time: 0.0594
INFO - 2021-07-15 15:52:08 --> Config Class Initialized
INFO - 2021-07-15 15:52:08 --> Hooks Class Initialized
DEBUG - 2021-07-15 15:52:08 --> UTF-8 Support Enabled
INFO - 2021-07-15 15:52:08 --> Utf8 Class Initialized
INFO - 2021-07-15 15:52:08 --> URI Class Initialized
INFO - 2021-07-15 15:52:08 --> Router Class Initialized
INFO - 2021-07-15 15:52:08 --> Output Class Initialized
INFO - 2021-07-15 15:52:08 --> Security Class Initialized
DEBUG - 2021-07-15 15:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 15:52:08 --> Input Class Initialized
INFO - 2021-07-15 15:52:08 --> Language Class Initialized
INFO - 2021-07-15 15:52:08 --> Loader Class Initialized
INFO - 2021-07-15 15:52:08 --> Helper loaded: basic_helper
INFO - 2021-07-15 15:52:08 --> Helper loaded: url_helper
INFO - 2021-07-15 15:52:08 --> Helper loaded: file_helper
INFO - 2021-07-15 15:52:08 --> Helper loaded: form_helper
INFO - 2021-07-15 15:52:08 --> Helper loaded: cookie_helper
INFO - 2021-07-15 15:52:08 --> Helper loaded: security_helper
INFO - 2021-07-15 15:52:08 --> Helper loaded: directory_helper
INFO - 2021-07-15 15:52:08 --> Helper loaded: language_helper
INFO - 2021-07-15 15:52:08 --> Helper loaded: general_helper
INFO - 2021-07-15 15:52:08 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 15:52:08 --> Database Driver Class Initialized
DEBUG - 2021-07-15 15:52:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 15:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 15:52:08 --> Parser Class Initialized
INFO - 2021-07-15 15:52:08 --> Form Validation Class Initialized
INFO - 2021-07-15 15:52:08 --> Upload Class Initialized
INFO - 2021-07-15 15:52:08 --> Email Class Initialized
INFO - 2021-07-15 15:52:08 --> MY_Model class loaded
INFO - 2021-07-15 15:52:08 --> Model "Users_model" initialized
INFO - 2021-07-15 15:52:08 --> Model "Settings_model" initialized
INFO - 2021-07-15 15:52:08 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 15:52:08 --> Model "Permissions_model" initialized
INFO - 2021-07-15 15:52:08 --> Model "Roles_model" initialized
INFO - 2021-07-15 15:52:08 --> Model "Activity_model" initialized
INFO - 2021-07-15 15:52:08 --> Model "Templates_model" initialized
INFO - 2021-07-15 15:52:08 --> Database Driver Class Initialized
INFO - 2021-07-15 15:52:08 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 15:52:08 --> Controller Class Initialized
ERROR - 2021-07-15 15:52:08 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-15 15:52:08 --> Severity: error --> Exception: Call to a member function list() on null C:\wamp64\www\crm\application\views\car\car_list.php 40
INFO - 2021-07-15 15:57:16 --> Config Class Initialized
INFO - 2021-07-15 15:57:16 --> Hooks Class Initialized
DEBUG - 2021-07-15 15:57:16 --> UTF-8 Support Enabled
INFO - 2021-07-15 15:57:16 --> Utf8 Class Initialized
INFO - 2021-07-15 15:57:16 --> URI Class Initialized
INFO - 2021-07-15 15:57:16 --> Router Class Initialized
INFO - 2021-07-15 15:57:16 --> Output Class Initialized
INFO - 2021-07-15 15:57:16 --> Security Class Initialized
DEBUG - 2021-07-15 15:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 15:57:16 --> Input Class Initialized
INFO - 2021-07-15 15:57:16 --> Language Class Initialized
INFO - 2021-07-15 15:57:16 --> Loader Class Initialized
INFO - 2021-07-15 15:57:16 --> Helper loaded: basic_helper
INFO - 2021-07-15 15:57:16 --> Helper loaded: url_helper
INFO - 2021-07-15 15:57:16 --> Helper loaded: file_helper
INFO - 2021-07-15 15:57:16 --> Helper loaded: form_helper
INFO - 2021-07-15 15:57:16 --> Helper loaded: cookie_helper
INFO - 2021-07-15 15:57:16 --> Helper loaded: security_helper
INFO - 2021-07-15 15:57:16 --> Helper loaded: directory_helper
INFO - 2021-07-15 15:57:16 --> Helper loaded: language_helper
INFO - 2021-07-15 15:57:16 --> Helper loaded: general_helper
INFO - 2021-07-15 15:57:16 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 15:57:16 --> Database Driver Class Initialized
DEBUG - 2021-07-15 15:57:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 15:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 15:57:16 --> Parser Class Initialized
INFO - 2021-07-15 15:57:16 --> Form Validation Class Initialized
INFO - 2021-07-15 15:57:16 --> Upload Class Initialized
INFO - 2021-07-15 15:57:16 --> Email Class Initialized
INFO - 2021-07-15 15:57:16 --> MY_Model class loaded
INFO - 2021-07-15 15:57:16 --> Model "Users_model" initialized
INFO - 2021-07-15 15:57:16 --> Model "Settings_model" initialized
INFO - 2021-07-15 15:57:16 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 15:57:16 --> Model "Permissions_model" initialized
INFO - 2021-07-15 15:57:16 --> Model "Roles_model" initialized
INFO - 2021-07-15 15:57:16 --> Model "Activity_model" initialized
INFO - 2021-07-15 15:57:16 --> Model "Templates_model" initialized
INFO - 2021-07-15 15:57:16 --> Database Driver Class Initialized
INFO - 2021-07-15 15:57:16 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 15:57:16 --> Controller Class Initialized
ERROR - 2021-07-15 15:57:16 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-15 15:57:16 --> Severity: error --> Exception: Call to a member function list() on null C:\wamp64\www\crm\application\views\car\car_list.php 40
INFO - 2021-07-15 15:57:17 --> Config Class Initialized
INFO - 2021-07-15 15:57:17 --> Hooks Class Initialized
DEBUG - 2021-07-15 15:57:17 --> UTF-8 Support Enabled
INFO - 2021-07-15 15:57:17 --> Utf8 Class Initialized
INFO - 2021-07-15 15:57:17 --> URI Class Initialized
INFO - 2021-07-15 15:57:17 --> Router Class Initialized
INFO - 2021-07-15 15:57:17 --> Output Class Initialized
INFO - 2021-07-15 15:57:17 --> Security Class Initialized
DEBUG - 2021-07-15 15:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 15:57:17 --> Input Class Initialized
INFO - 2021-07-15 15:57:17 --> Language Class Initialized
INFO - 2021-07-15 15:57:17 --> Loader Class Initialized
INFO - 2021-07-15 15:57:17 --> Helper loaded: basic_helper
INFO - 2021-07-15 15:57:17 --> Helper loaded: url_helper
INFO - 2021-07-15 15:57:17 --> Helper loaded: file_helper
INFO - 2021-07-15 15:57:17 --> Helper loaded: form_helper
INFO - 2021-07-15 15:57:17 --> Helper loaded: cookie_helper
INFO - 2021-07-15 15:57:17 --> Helper loaded: security_helper
INFO - 2021-07-15 15:57:17 --> Helper loaded: directory_helper
INFO - 2021-07-15 15:57:17 --> Helper loaded: language_helper
INFO - 2021-07-15 15:57:17 --> Helper loaded: general_helper
INFO - 2021-07-15 15:57:17 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 15:57:17 --> Database Driver Class Initialized
DEBUG - 2021-07-15 15:57:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 15:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 15:57:17 --> Parser Class Initialized
INFO - 2021-07-15 15:57:17 --> Form Validation Class Initialized
INFO - 2021-07-15 15:57:17 --> Upload Class Initialized
INFO - 2021-07-15 15:57:17 --> Email Class Initialized
INFO - 2021-07-15 15:57:17 --> MY_Model class loaded
INFO - 2021-07-15 15:57:17 --> Model "Users_model" initialized
INFO - 2021-07-15 15:57:17 --> Model "Settings_model" initialized
INFO - 2021-07-15 15:57:17 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 15:57:17 --> Model "Permissions_model" initialized
INFO - 2021-07-15 15:57:17 --> Model "Roles_model" initialized
INFO - 2021-07-15 15:57:17 --> Model "Activity_model" initialized
INFO - 2021-07-15 15:57:17 --> Model "Templates_model" initialized
INFO - 2021-07-15 15:57:17 --> Database Driver Class Initialized
INFO - 2021-07-15 15:57:17 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 15:57:17 --> Controller Class Initialized
ERROR - 2021-07-15 15:57:17 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-15 15:57:17 --> Severity: error --> Exception: Call to a member function list() on null C:\wamp64\www\crm\application\views\car\car_list.php 40
INFO - 2021-07-15 15:57:17 --> Config Class Initialized
INFO - 2021-07-15 15:57:17 --> Hooks Class Initialized
DEBUG - 2021-07-15 15:57:17 --> UTF-8 Support Enabled
INFO - 2021-07-15 15:57:17 --> Utf8 Class Initialized
INFO - 2021-07-15 15:57:17 --> URI Class Initialized
INFO - 2021-07-15 15:57:17 --> Router Class Initialized
INFO - 2021-07-15 15:57:17 --> Output Class Initialized
INFO - 2021-07-15 15:57:17 --> Security Class Initialized
DEBUG - 2021-07-15 15:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 15:57:17 --> Input Class Initialized
INFO - 2021-07-15 15:57:17 --> Language Class Initialized
INFO - 2021-07-15 15:57:17 --> Loader Class Initialized
INFO - 2021-07-15 15:57:17 --> Helper loaded: basic_helper
INFO - 2021-07-15 15:57:17 --> Helper loaded: url_helper
INFO - 2021-07-15 15:57:17 --> Helper loaded: file_helper
INFO - 2021-07-15 15:57:17 --> Helper loaded: form_helper
INFO - 2021-07-15 15:57:17 --> Helper loaded: cookie_helper
INFO - 2021-07-15 15:57:17 --> Helper loaded: security_helper
INFO - 2021-07-15 15:57:17 --> Helper loaded: directory_helper
INFO - 2021-07-15 15:57:17 --> Helper loaded: language_helper
INFO - 2021-07-15 15:57:17 --> Helper loaded: general_helper
INFO - 2021-07-15 15:57:17 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 15:57:17 --> Database Driver Class Initialized
DEBUG - 2021-07-15 15:57:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 15:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 15:57:17 --> Parser Class Initialized
INFO - 2021-07-15 15:57:17 --> Form Validation Class Initialized
INFO - 2021-07-15 15:57:17 --> Upload Class Initialized
INFO - 2021-07-15 15:57:17 --> Email Class Initialized
INFO - 2021-07-15 15:57:17 --> MY_Model class loaded
INFO - 2021-07-15 15:57:17 --> Model "Users_model" initialized
INFO - 2021-07-15 15:57:17 --> Model "Settings_model" initialized
INFO - 2021-07-15 15:57:17 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 15:57:17 --> Model "Permissions_model" initialized
INFO - 2021-07-15 15:57:17 --> Model "Roles_model" initialized
INFO - 2021-07-15 15:57:17 --> Model "Activity_model" initialized
INFO - 2021-07-15 15:57:17 --> Model "Templates_model" initialized
INFO - 2021-07-15 15:57:17 --> Database Driver Class Initialized
INFO - 2021-07-15 15:57:17 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 15:57:17 --> Controller Class Initialized
ERROR - 2021-07-15 15:57:17 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-15 15:57:17 --> Severity: error --> Exception: Call to a member function list() on null C:\wamp64\www\crm\application\views\car\car_list.php 40
INFO - 2021-07-15 15:57:17 --> Config Class Initialized
INFO - 2021-07-15 15:57:17 --> Hooks Class Initialized
DEBUG - 2021-07-15 15:57:17 --> UTF-8 Support Enabled
INFO - 2021-07-15 15:57:17 --> Utf8 Class Initialized
INFO - 2021-07-15 15:57:17 --> URI Class Initialized
INFO - 2021-07-15 15:57:17 --> Router Class Initialized
INFO - 2021-07-15 15:57:17 --> Output Class Initialized
INFO - 2021-07-15 15:57:17 --> Security Class Initialized
DEBUG - 2021-07-15 15:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 15:57:17 --> Input Class Initialized
INFO - 2021-07-15 15:57:17 --> Language Class Initialized
INFO - 2021-07-15 15:57:17 --> Loader Class Initialized
INFO - 2021-07-15 15:57:17 --> Helper loaded: basic_helper
INFO - 2021-07-15 15:57:17 --> Helper loaded: url_helper
INFO - 2021-07-15 15:57:17 --> Helper loaded: file_helper
INFO - 2021-07-15 15:57:17 --> Helper loaded: form_helper
INFO - 2021-07-15 15:57:17 --> Helper loaded: cookie_helper
INFO - 2021-07-15 15:57:17 --> Helper loaded: security_helper
INFO - 2021-07-15 15:57:17 --> Helper loaded: directory_helper
INFO - 2021-07-15 15:57:17 --> Helper loaded: language_helper
INFO - 2021-07-15 15:57:17 --> Helper loaded: general_helper
INFO - 2021-07-15 15:57:17 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 15:57:17 --> Database Driver Class Initialized
DEBUG - 2021-07-15 15:57:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 15:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 15:57:17 --> Parser Class Initialized
INFO - 2021-07-15 15:57:17 --> Form Validation Class Initialized
INFO - 2021-07-15 15:57:17 --> Upload Class Initialized
INFO - 2021-07-15 15:57:17 --> Email Class Initialized
INFO - 2021-07-15 15:57:17 --> MY_Model class loaded
INFO - 2021-07-15 15:57:17 --> Model "Users_model" initialized
INFO - 2021-07-15 15:57:17 --> Model "Settings_model" initialized
INFO - 2021-07-15 15:57:17 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 15:57:17 --> Model "Permissions_model" initialized
INFO - 2021-07-15 15:57:17 --> Model "Roles_model" initialized
INFO - 2021-07-15 15:57:17 --> Model "Activity_model" initialized
INFO - 2021-07-15 15:57:17 --> Model "Templates_model" initialized
INFO - 2021-07-15 15:57:17 --> Database Driver Class Initialized
INFO - 2021-07-15 15:57:17 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 15:57:17 --> Controller Class Initialized
ERROR - 2021-07-15 15:57:17 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-15 15:57:17 --> Severity: error --> Exception: Call to a member function list() on null C:\wamp64\www\crm\application\views\car\car_list.php 40
INFO - 2021-07-15 15:57:19 --> Config Class Initialized
INFO - 2021-07-15 15:57:19 --> Hooks Class Initialized
DEBUG - 2021-07-15 15:57:19 --> UTF-8 Support Enabled
INFO - 2021-07-15 15:57:19 --> Utf8 Class Initialized
INFO - 2021-07-15 15:57:19 --> URI Class Initialized
INFO - 2021-07-15 15:57:19 --> Router Class Initialized
INFO - 2021-07-15 15:57:19 --> Output Class Initialized
INFO - 2021-07-15 15:57:19 --> Security Class Initialized
DEBUG - 2021-07-15 15:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 15:57:19 --> Input Class Initialized
INFO - 2021-07-15 15:57:19 --> Language Class Initialized
INFO - 2021-07-15 15:57:19 --> Loader Class Initialized
INFO - 2021-07-15 15:57:19 --> Helper loaded: basic_helper
INFO - 2021-07-15 15:57:19 --> Helper loaded: url_helper
INFO - 2021-07-15 15:57:19 --> Helper loaded: file_helper
INFO - 2021-07-15 15:57:19 --> Helper loaded: form_helper
INFO - 2021-07-15 15:57:19 --> Helper loaded: cookie_helper
INFO - 2021-07-15 15:57:19 --> Helper loaded: security_helper
INFO - 2021-07-15 15:57:19 --> Helper loaded: directory_helper
INFO - 2021-07-15 15:57:19 --> Helper loaded: language_helper
INFO - 2021-07-15 15:57:19 --> Helper loaded: general_helper
INFO - 2021-07-15 15:57:19 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 15:57:19 --> Database Driver Class Initialized
DEBUG - 2021-07-15 15:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 15:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 15:57:19 --> Parser Class Initialized
INFO - 2021-07-15 15:57:19 --> Form Validation Class Initialized
INFO - 2021-07-15 15:57:19 --> Upload Class Initialized
INFO - 2021-07-15 15:57:19 --> Email Class Initialized
INFO - 2021-07-15 15:57:19 --> MY_Model class loaded
INFO - 2021-07-15 15:57:19 --> Model "Users_model" initialized
INFO - 2021-07-15 15:57:19 --> Model "Settings_model" initialized
INFO - 2021-07-15 15:57:19 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 15:57:19 --> Model "Permissions_model" initialized
INFO - 2021-07-15 15:57:19 --> Model "Roles_model" initialized
INFO - 2021-07-15 15:57:19 --> Model "Activity_model" initialized
INFO - 2021-07-15 15:57:19 --> Model "Templates_model" initialized
INFO - 2021-07-15 15:57:19 --> Database Driver Class Initialized
INFO - 2021-07-15 15:57:19 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 15:57:19 --> Controller Class Initialized
ERROR - 2021-07-15 15:57:19 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-15 15:57:19 --> Severity: error --> Exception: Call to a member function list() on null C:\wamp64\www\crm\application\views\car\car_list.php 40
INFO - 2021-07-15 15:57:19 --> Config Class Initialized
INFO - 2021-07-15 15:57:19 --> Hooks Class Initialized
DEBUG - 2021-07-15 15:57:19 --> UTF-8 Support Enabled
INFO - 2021-07-15 15:57:19 --> Utf8 Class Initialized
INFO - 2021-07-15 15:57:19 --> URI Class Initialized
INFO - 2021-07-15 15:57:19 --> Router Class Initialized
INFO - 2021-07-15 15:57:19 --> Output Class Initialized
INFO - 2021-07-15 15:57:19 --> Security Class Initialized
DEBUG - 2021-07-15 15:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 15:57:19 --> Input Class Initialized
INFO - 2021-07-15 15:57:19 --> Language Class Initialized
INFO - 2021-07-15 15:57:19 --> Loader Class Initialized
INFO - 2021-07-15 15:57:19 --> Helper loaded: basic_helper
INFO - 2021-07-15 15:57:19 --> Helper loaded: url_helper
INFO - 2021-07-15 15:57:19 --> Helper loaded: file_helper
INFO - 2021-07-15 15:57:19 --> Helper loaded: form_helper
INFO - 2021-07-15 15:57:19 --> Helper loaded: cookie_helper
INFO - 2021-07-15 15:57:19 --> Helper loaded: security_helper
INFO - 2021-07-15 15:57:19 --> Helper loaded: directory_helper
INFO - 2021-07-15 15:57:19 --> Helper loaded: language_helper
INFO - 2021-07-15 15:57:19 --> Helper loaded: general_helper
INFO - 2021-07-15 15:57:19 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 15:57:19 --> Database Driver Class Initialized
DEBUG - 2021-07-15 15:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 15:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 15:57:19 --> Parser Class Initialized
INFO - 2021-07-15 15:57:19 --> Form Validation Class Initialized
INFO - 2021-07-15 15:57:19 --> Upload Class Initialized
INFO - 2021-07-15 15:57:19 --> Email Class Initialized
INFO - 2021-07-15 15:57:19 --> MY_Model class loaded
INFO - 2021-07-15 15:57:19 --> Model "Users_model" initialized
INFO - 2021-07-15 15:57:19 --> Model "Settings_model" initialized
INFO - 2021-07-15 15:57:19 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 15:57:19 --> Model "Permissions_model" initialized
INFO - 2021-07-15 15:57:19 --> Model "Roles_model" initialized
INFO - 2021-07-15 15:57:19 --> Model "Activity_model" initialized
INFO - 2021-07-15 15:57:19 --> Model "Templates_model" initialized
INFO - 2021-07-15 15:57:19 --> Database Driver Class Initialized
INFO - 2021-07-15 15:57:19 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 15:57:19 --> Controller Class Initialized
ERROR - 2021-07-15 15:57:19 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-15 15:57:19 --> Severity: error --> Exception: Call to a member function list() on null C:\wamp64\www\crm\application\views\car\car_list.php 40
INFO - 2021-07-15 15:59:49 --> Config Class Initialized
INFO - 2021-07-15 15:59:49 --> Hooks Class Initialized
DEBUG - 2021-07-15 15:59:49 --> UTF-8 Support Enabled
INFO - 2021-07-15 15:59:49 --> Utf8 Class Initialized
INFO - 2021-07-15 15:59:49 --> URI Class Initialized
INFO - 2021-07-15 15:59:49 --> Router Class Initialized
INFO - 2021-07-15 15:59:49 --> Output Class Initialized
INFO - 2021-07-15 15:59:49 --> Security Class Initialized
DEBUG - 2021-07-15 15:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 15:59:49 --> Input Class Initialized
INFO - 2021-07-15 15:59:49 --> Language Class Initialized
INFO - 2021-07-15 15:59:49 --> Loader Class Initialized
INFO - 2021-07-15 15:59:49 --> Helper loaded: basic_helper
INFO - 2021-07-15 15:59:49 --> Helper loaded: url_helper
INFO - 2021-07-15 15:59:49 --> Helper loaded: file_helper
INFO - 2021-07-15 15:59:49 --> Helper loaded: form_helper
INFO - 2021-07-15 15:59:49 --> Helper loaded: cookie_helper
INFO - 2021-07-15 15:59:49 --> Helper loaded: security_helper
INFO - 2021-07-15 15:59:49 --> Helper loaded: directory_helper
INFO - 2021-07-15 15:59:49 --> Helper loaded: language_helper
INFO - 2021-07-15 15:59:49 --> Helper loaded: general_helper
INFO - 2021-07-15 15:59:49 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 15:59:49 --> Database Driver Class Initialized
DEBUG - 2021-07-15 15:59:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 15:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 15:59:49 --> Parser Class Initialized
INFO - 2021-07-15 15:59:49 --> Form Validation Class Initialized
INFO - 2021-07-15 15:59:49 --> Upload Class Initialized
INFO - 2021-07-15 15:59:49 --> Email Class Initialized
INFO - 2021-07-15 15:59:49 --> MY_Model class loaded
INFO - 2021-07-15 15:59:49 --> Model "Users_model" initialized
INFO - 2021-07-15 15:59:49 --> Model "Settings_model" initialized
INFO - 2021-07-15 15:59:49 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 15:59:49 --> Model "Permissions_model" initialized
INFO - 2021-07-15 15:59:49 --> Model "Roles_model" initialized
INFO - 2021-07-15 15:59:49 --> Model "Activity_model" initialized
INFO - 2021-07-15 15:59:49 --> Model "Templates_model" initialized
INFO - 2021-07-15 15:59:49 --> Database Driver Class Initialized
INFO - 2021-07-15 15:59:49 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 15:59:49 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 15:59:49 --> Controller Class Initialized
ERROR - 2021-07-15 15:59:49 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-15 15:59:49 --> Severity: error --> Exception: Call to a member function list() on null C:\wamp64\www\crm\application\views\car\car_list.php 40
INFO - 2021-07-15 15:59:53 --> Config Class Initialized
INFO - 2021-07-15 15:59:53 --> Hooks Class Initialized
DEBUG - 2021-07-15 15:59:53 --> UTF-8 Support Enabled
INFO - 2021-07-15 15:59:53 --> Utf8 Class Initialized
INFO - 2021-07-15 15:59:53 --> URI Class Initialized
INFO - 2021-07-15 15:59:53 --> Router Class Initialized
INFO - 2021-07-15 15:59:53 --> Output Class Initialized
INFO - 2021-07-15 15:59:53 --> Security Class Initialized
DEBUG - 2021-07-15 15:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 15:59:53 --> Input Class Initialized
INFO - 2021-07-15 15:59:53 --> Language Class Initialized
INFO - 2021-07-15 15:59:53 --> Loader Class Initialized
INFO - 2021-07-15 15:59:53 --> Helper loaded: basic_helper
INFO - 2021-07-15 15:59:53 --> Helper loaded: url_helper
INFO - 2021-07-15 15:59:53 --> Helper loaded: file_helper
INFO - 2021-07-15 15:59:53 --> Helper loaded: form_helper
INFO - 2021-07-15 15:59:53 --> Helper loaded: cookie_helper
INFO - 2021-07-15 15:59:53 --> Helper loaded: security_helper
INFO - 2021-07-15 15:59:53 --> Helper loaded: directory_helper
INFO - 2021-07-15 15:59:53 --> Helper loaded: language_helper
INFO - 2021-07-15 15:59:53 --> Helper loaded: general_helper
INFO - 2021-07-15 15:59:53 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 15:59:53 --> Database Driver Class Initialized
DEBUG - 2021-07-15 15:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 15:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 15:59:53 --> Parser Class Initialized
INFO - 2021-07-15 15:59:53 --> Form Validation Class Initialized
INFO - 2021-07-15 15:59:53 --> Upload Class Initialized
INFO - 2021-07-15 15:59:53 --> Email Class Initialized
INFO - 2021-07-15 15:59:53 --> MY_Model class loaded
INFO - 2021-07-15 15:59:53 --> Model "Users_model" initialized
INFO - 2021-07-15 15:59:53 --> Model "Settings_model" initialized
INFO - 2021-07-15 15:59:53 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 15:59:53 --> Model "Permissions_model" initialized
INFO - 2021-07-15 15:59:53 --> Model "Roles_model" initialized
INFO - 2021-07-15 15:59:53 --> Model "Activity_model" initialized
INFO - 2021-07-15 15:59:53 --> Model "Templates_model" initialized
INFO - 2021-07-15 15:59:53 --> Database Driver Class Initialized
INFO - 2021-07-15 15:59:53 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 15:59:53 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 15:59:53 --> Controller Class Initialized
ERROR - 2021-07-15 15:59:53 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-15 15:59:53 --> Severity: error --> Exception: Call to a member function list() on null C:\wamp64\www\crm\application\views\car\car_list.php 40
INFO - 2021-07-15 15:59:53 --> Config Class Initialized
INFO - 2021-07-15 15:59:53 --> Hooks Class Initialized
DEBUG - 2021-07-15 15:59:53 --> UTF-8 Support Enabled
INFO - 2021-07-15 15:59:53 --> Utf8 Class Initialized
INFO - 2021-07-15 15:59:53 --> URI Class Initialized
INFO - 2021-07-15 15:59:53 --> Router Class Initialized
INFO - 2021-07-15 15:59:53 --> Output Class Initialized
INFO - 2021-07-15 15:59:53 --> Security Class Initialized
DEBUG - 2021-07-15 15:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 15:59:53 --> Input Class Initialized
INFO - 2021-07-15 15:59:53 --> Language Class Initialized
INFO - 2021-07-15 15:59:53 --> Loader Class Initialized
INFO - 2021-07-15 15:59:53 --> Helper loaded: basic_helper
INFO - 2021-07-15 15:59:53 --> Helper loaded: url_helper
INFO - 2021-07-15 15:59:53 --> Helper loaded: file_helper
INFO - 2021-07-15 15:59:53 --> Helper loaded: form_helper
INFO - 2021-07-15 15:59:53 --> Helper loaded: cookie_helper
INFO - 2021-07-15 15:59:53 --> Helper loaded: security_helper
INFO - 2021-07-15 15:59:53 --> Helper loaded: directory_helper
INFO - 2021-07-15 15:59:53 --> Helper loaded: language_helper
INFO - 2021-07-15 15:59:53 --> Helper loaded: general_helper
INFO - 2021-07-15 15:59:53 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 15:59:53 --> Database Driver Class Initialized
DEBUG - 2021-07-15 15:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 15:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 15:59:53 --> Parser Class Initialized
INFO - 2021-07-15 15:59:53 --> Form Validation Class Initialized
INFO - 2021-07-15 15:59:53 --> Upload Class Initialized
INFO - 2021-07-15 15:59:53 --> Email Class Initialized
INFO - 2021-07-15 15:59:53 --> MY_Model class loaded
INFO - 2021-07-15 15:59:53 --> Model "Users_model" initialized
INFO - 2021-07-15 15:59:53 --> Model "Settings_model" initialized
INFO - 2021-07-15 15:59:53 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 15:59:53 --> Model "Permissions_model" initialized
INFO - 2021-07-15 15:59:53 --> Model "Roles_model" initialized
INFO - 2021-07-15 15:59:53 --> Model "Activity_model" initialized
INFO - 2021-07-15 15:59:53 --> Model "Templates_model" initialized
INFO - 2021-07-15 15:59:53 --> Database Driver Class Initialized
INFO - 2021-07-15 15:59:53 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 15:59:53 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 15:59:53 --> Controller Class Initialized
ERROR - 2021-07-15 15:59:53 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-15 15:59:53 --> Severity: error --> Exception: Call to a member function list() on null C:\wamp64\www\crm\application\views\car\car_list.php 40
INFO - 2021-07-15 15:59:54 --> Config Class Initialized
INFO - 2021-07-15 15:59:54 --> Hooks Class Initialized
DEBUG - 2021-07-15 15:59:54 --> UTF-8 Support Enabled
INFO - 2021-07-15 15:59:54 --> Utf8 Class Initialized
INFO - 2021-07-15 15:59:54 --> URI Class Initialized
INFO - 2021-07-15 15:59:54 --> Router Class Initialized
INFO - 2021-07-15 15:59:54 --> Output Class Initialized
INFO - 2021-07-15 15:59:54 --> Security Class Initialized
DEBUG - 2021-07-15 15:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 15:59:54 --> Input Class Initialized
INFO - 2021-07-15 15:59:54 --> Language Class Initialized
INFO - 2021-07-15 15:59:54 --> Loader Class Initialized
INFO - 2021-07-15 15:59:54 --> Helper loaded: basic_helper
INFO - 2021-07-15 15:59:54 --> Helper loaded: url_helper
INFO - 2021-07-15 15:59:54 --> Helper loaded: file_helper
INFO - 2021-07-15 15:59:54 --> Helper loaded: form_helper
INFO - 2021-07-15 15:59:54 --> Helper loaded: cookie_helper
INFO - 2021-07-15 15:59:54 --> Helper loaded: security_helper
INFO - 2021-07-15 15:59:54 --> Helper loaded: directory_helper
INFO - 2021-07-15 15:59:54 --> Helper loaded: language_helper
INFO - 2021-07-15 15:59:54 --> Helper loaded: general_helper
INFO - 2021-07-15 15:59:54 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 15:59:54 --> Database Driver Class Initialized
DEBUG - 2021-07-15 15:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 15:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 15:59:54 --> Parser Class Initialized
INFO - 2021-07-15 15:59:54 --> Form Validation Class Initialized
INFO - 2021-07-15 15:59:54 --> Upload Class Initialized
INFO - 2021-07-15 15:59:54 --> Email Class Initialized
INFO - 2021-07-15 15:59:54 --> MY_Model class loaded
INFO - 2021-07-15 15:59:54 --> Model "Users_model" initialized
INFO - 2021-07-15 15:59:54 --> Model "Settings_model" initialized
INFO - 2021-07-15 15:59:54 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 15:59:54 --> Model "Permissions_model" initialized
INFO - 2021-07-15 15:59:54 --> Model "Roles_model" initialized
INFO - 2021-07-15 15:59:54 --> Model "Activity_model" initialized
INFO - 2021-07-15 15:59:54 --> Model "Templates_model" initialized
INFO - 2021-07-15 15:59:54 --> Database Driver Class Initialized
INFO - 2021-07-15 15:59:54 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 15:59:54 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 15:59:54 --> Controller Class Initialized
ERROR - 2021-07-15 15:59:54 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-15 15:59:54 --> Severity: error --> Exception: Call to a member function list() on null C:\wamp64\www\crm\application\views\car\car_list.php 40
INFO - 2021-07-15 16:00:03 --> Config Class Initialized
INFO - 2021-07-15 16:00:03 --> Hooks Class Initialized
DEBUG - 2021-07-15 16:00:03 --> UTF-8 Support Enabled
INFO - 2021-07-15 16:00:03 --> Utf8 Class Initialized
INFO - 2021-07-15 16:00:03 --> URI Class Initialized
INFO - 2021-07-15 16:00:03 --> Router Class Initialized
INFO - 2021-07-15 16:00:03 --> Output Class Initialized
INFO - 2021-07-15 16:00:03 --> Security Class Initialized
DEBUG - 2021-07-15 16:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 16:00:03 --> Input Class Initialized
INFO - 2021-07-15 16:00:03 --> Language Class Initialized
INFO - 2021-07-15 16:00:03 --> Loader Class Initialized
INFO - 2021-07-15 16:00:03 --> Helper loaded: basic_helper
INFO - 2021-07-15 16:00:03 --> Helper loaded: url_helper
INFO - 2021-07-15 16:00:03 --> Helper loaded: file_helper
INFO - 2021-07-15 16:00:03 --> Helper loaded: form_helper
INFO - 2021-07-15 16:00:03 --> Helper loaded: cookie_helper
INFO - 2021-07-15 16:00:03 --> Helper loaded: security_helper
INFO - 2021-07-15 16:00:03 --> Helper loaded: directory_helper
INFO - 2021-07-15 16:00:03 --> Helper loaded: language_helper
INFO - 2021-07-15 16:00:03 --> Helper loaded: general_helper
INFO - 2021-07-15 16:00:03 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 16:00:03 --> Database Driver Class Initialized
DEBUG - 2021-07-15 16:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 16:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 16:00:03 --> Parser Class Initialized
INFO - 2021-07-15 16:00:03 --> Form Validation Class Initialized
INFO - 2021-07-15 16:00:03 --> Upload Class Initialized
INFO - 2021-07-15 16:00:03 --> Email Class Initialized
INFO - 2021-07-15 16:00:03 --> MY_Model class loaded
INFO - 2021-07-15 16:00:03 --> Model "Users_model" initialized
INFO - 2021-07-15 16:00:03 --> Model "Settings_model" initialized
INFO - 2021-07-15 16:00:03 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 16:00:03 --> Model "Permissions_model" initialized
INFO - 2021-07-15 16:00:03 --> Model "Roles_model" initialized
INFO - 2021-07-15 16:00:03 --> Model "Activity_model" initialized
INFO - 2021-07-15 16:00:03 --> Model "Templates_model" initialized
INFO - 2021-07-15 16:00:03 --> Database Driver Class Initialized
INFO - 2021-07-15 16:00:03 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 16:00:03 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 16:00:03 --> Controller Class Initialized
ERROR - 2021-07-15 16:00:03 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-15 16:00:03 --> Severity: error --> Exception: Call to a member function list() on null C:\wamp64\www\crm\application\views\car\car_list.php 40
INFO - 2021-07-15 16:00:03 --> Config Class Initialized
INFO - 2021-07-15 16:00:03 --> Hooks Class Initialized
DEBUG - 2021-07-15 16:00:03 --> UTF-8 Support Enabled
INFO - 2021-07-15 16:00:03 --> Utf8 Class Initialized
INFO - 2021-07-15 16:00:03 --> URI Class Initialized
INFO - 2021-07-15 16:00:03 --> Router Class Initialized
INFO - 2021-07-15 16:00:03 --> Output Class Initialized
INFO - 2021-07-15 16:00:03 --> Security Class Initialized
DEBUG - 2021-07-15 16:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 16:00:03 --> Input Class Initialized
INFO - 2021-07-15 16:00:03 --> Language Class Initialized
INFO - 2021-07-15 16:00:03 --> Loader Class Initialized
INFO - 2021-07-15 16:00:03 --> Helper loaded: basic_helper
INFO - 2021-07-15 16:00:03 --> Helper loaded: url_helper
INFO - 2021-07-15 16:00:03 --> Helper loaded: file_helper
INFO - 2021-07-15 16:00:03 --> Helper loaded: form_helper
INFO - 2021-07-15 16:00:03 --> Helper loaded: cookie_helper
INFO - 2021-07-15 16:00:03 --> Helper loaded: security_helper
INFO - 2021-07-15 16:00:03 --> Helper loaded: directory_helper
INFO - 2021-07-15 16:00:03 --> Helper loaded: language_helper
INFO - 2021-07-15 16:00:03 --> Helper loaded: general_helper
INFO - 2021-07-15 16:00:03 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 16:00:03 --> Database Driver Class Initialized
DEBUG - 2021-07-15 16:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 16:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 16:00:03 --> Parser Class Initialized
INFO - 2021-07-15 16:00:03 --> Form Validation Class Initialized
INFO - 2021-07-15 16:00:03 --> Upload Class Initialized
INFO - 2021-07-15 16:00:03 --> Email Class Initialized
INFO - 2021-07-15 16:00:03 --> MY_Model class loaded
INFO - 2021-07-15 16:00:03 --> Model "Users_model" initialized
INFO - 2021-07-15 16:00:03 --> Model "Settings_model" initialized
INFO - 2021-07-15 16:00:03 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 16:00:03 --> Model "Permissions_model" initialized
INFO - 2021-07-15 16:00:03 --> Model "Roles_model" initialized
INFO - 2021-07-15 16:00:03 --> Model "Activity_model" initialized
INFO - 2021-07-15 16:00:03 --> Model "Templates_model" initialized
INFO - 2021-07-15 16:00:03 --> Database Driver Class Initialized
INFO - 2021-07-15 16:00:03 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 16:00:03 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 16:00:03 --> Controller Class Initialized
ERROR - 2021-07-15 16:00:03 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-15 16:00:03 --> Severity: error --> Exception: Call to a member function list() on null C:\wamp64\www\crm\application\views\car\car_list.php 40
INFO - 2021-07-15 16:02:02 --> Config Class Initialized
INFO - 2021-07-15 16:02:02 --> Hooks Class Initialized
DEBUG - 2021-07-15 16:02:02 --> UTF-8 Support Enabled
INFO - 2021-07-15 16:02:02 --> Utf8 Class Initialized
INFO - 2021-07-15 16:02:02 --> URI Class Initialized
INFO - 2021-07-15 16:02:02 --> Router Class Initialized
INFO - 2021-07-15 16:02:02 --> Output Class Initialized
INFO - 2021-07-15 16:02:02 --> Security Class Initialized
DEBUG - 2021-07-15 16:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 16:02:02 --> Input Class Initialized
INFO - 2021-07-15 16:02:02 --> Language Class Initialized
INFO - 2021-07-15 16:02:02 --> Loader Class Initialized
INFO - 2021-07-15 16:02:02 --> Helper loaded: basic_helper
INFO - 2021-07-15 16:02:02 --> Helper loaded: url_helper
INFO - 2021-07-15 16:02:02 --> Helper loaded: file_helper
INFO - 2021-07-15 16:02:02 --> Helper loaded: form_helper
INFO - 2021-07-15 16:02:02 --> Helper loaded: cookie_helper
INFO - 2021-07-15 16:02:02 --> Helper loaded: security_helper
INFO - 2021-07-15 16:02:02 --> Helper loaded: directory_helper
INFO - 2021-07-15 16:02:02 --> Helper loaded: language_helper
INFO - 2021-07-15 16:02:02 --> Helper loaded: general_helper
INFO - 2021-07-15 16:02:02 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 16:02:02 --> Database Driver Class Initialized
DEBUG - 2021-07-15 16:02:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 16:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 16:02:02 --> Parser Class Initialized
INFO - 2021-07-15 16:02:02 --> Form Validation Class Initialized
INFO - 2021-07-15 16:02:02 --> Upload Class Initialized
INFO - 2021-07-15 16:02:02 --> Email Class Initialized
INFO - 2021-07-15 16:02:02 --> MY_Model class loaded
INFO - 2021-07-15 16:02:02 --> Model "Users_model" initialized
INFO - 2021-07-15 16:02:02 --> Model "Settings_model" initialized
INFO - 2021-07-15 16:02:02 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 16:02:02 --> Model "Permissions_model" initialized
INFO - 2021-07-15 16:02:02 --> Model "Roles_model" initialized
INFO - 2021-07-15 16:02:02 --> Model "Activity_model" initialized
INFO - 2021-07-15 16:02:02 --> Model "Templates_model" initialized
INFO - 2021-07-15 16:02:02 --> Database Driver Class Initialized
INFO - 2021-07-15 16:02:03 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 16:02:03 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 16:02:03 --> Controller Class Initialized
ERROR - 2021-07-15 16:02:03 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-15 16:02:03 --> Severity: error --> Exception: Call to a member function list() on null C:\wamp64\www\crm\application\views\car\car_list.php 40
INFO - 2021-07-15 16:02:03 --> Config Class Initialized
INFO - 2021-07-15 16:02:03 --> Hooks Class Initialized
DEBUG - 2021-07-15 16:02:03 --> UTF-8 Support Enabled
INFO - 2021-07-15 16:02:03 --> Utf8 Class Initialized
INFO - 2021-07-15 16:02:03 --> URI Class Initialized
INFO - 2021-07-15 16:02:03 --> Router Class Initialized
INFO - 2021-07-15 16:02:03 --> Output Class Initialized
INFO - 2021-07-15 16:02:03 --> Security Class Initialized
DEBUG - 2021-07-15 16:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 16:02:03 --> Input Class Initialized
INFO - 2021-07-15 16:02:03 --> Language Class Initialized
ERROR - 2021-07-15 16:02:03 --> 404 Page Not Found: Faviconico/index
INFO - 2021-07-15 16:02:10 --> Config Class Initialized
INFO - 2021-07-15 16:02:10 --> Hooks Class Initialized
DEBUG - 2021-07-15 16:02:10 --> UTF-8 Support Enabled
INFO - 2021-07-15 16:02:10 --> Utf8 Class Initialized
INFO - 2021-07-15 16:02:10 --> URI Class Initialized
INFO - 2021-07-15 16:02:10 --> Router Class Initialized
INFO - 2021-07-15 16:02:10 --> Output Class Initialized
INFO - 2021-07-15 16:02:10 --> Security Class Initialized
DEBUG - 2021-07-15 16:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 16:02:10 --> Input Class Initialized
INFO - 2021-07-15 16:02:10 --> Language Class Initialized
INFO - 2021-07-15 16:02:10 --> Loader Class Initialized
INFO - 2021-07-15 16:02:10 --> Helper loaded: basic_helper
INFO - 2021-07-15 16:02:10 --> Helper loaded: url_helper
INFO - 2021-07-15 16:02:10 --> Helper loaded: file_helper
INFO - 2021-07-15 16:02:10 --> Helper loaded: form_helper
INFO - 2021-07-15 16:02:10 --> Helper loaded: cookie_helper
INFO - 2021-07-15 16:02:10 --> Helper loaded: security_helper
INFO - 2021-07-15 16:02:10 --> Helper loaded: directory_helper
INFO - 2021-07-15 16:02:10 --> Helper loaded: language_helper
INFO - 2021-07-15 16:02:10 --> Helper loaded: general_helper
INFO - 2021-07-15 16:02:10 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 16:02:10 --> Database Driver Class Initialized
DEBUG - 2021-07-15 16:02:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 16:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 16:02:10 --> Parser Class Initialized
INFO - 2021-07-15 16:02:10 --> Form Validation Class Initialized
INFO - 2021-07-15 16:02:10 --> Upload Class Initialized
INFO - 2021-07-15 16:02:10 --> Email Class Initialized
INFO - 2021-07-15 16:02:10 --> MY_Model class loaded
INFO - 2021-07-15 16:02:10 --> Model "Users_model" initialized
INFO - 2021-07-15 16:02:10 --> Model "Settings_model" initialized
INFO - 2021-07-15 16:02:10 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 16:02:10 --> Model "Permissions_model" initialized
INFO - 2021-07-15 16:02:10 --> Model "Roles_model" initialized
INFO - 2021-07-15 16:02:10 --> Model "Activity_model" initialized
INFO - 2021-07-15 16:02:10 --> Model "Templates_model" initialized
INFO - 2021-07-15 16:02:10 --> Database Driver Class Initialized
INFO - 2021-07-15 16:02:11 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 16:02:11 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 16:02:11 --> Controller Class Initialized
ERROR - 2021-07-15 16:02:11 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-15 16:02:11 --> Severity: error --> Exception: Call to a member function list() on null C:\wamp64\www\crm\application\views\car\car_list.php 40
INFO - 2021-07-15 16:02:11 --> Config Class Initialized
INFO - 2021-07-15 16:02:11 --> Hooks Class Initialized
DEBUG - 2021-07-15 16:02:11 --> UTF-8 Support Enabled
INFO - 2021-07-15 16:02:11 --> Utf8 Class Initialized
INFO - 2021-07-15 16:02:11 --> URI Class Initialized
INFO - 2021-07-15 16:02:11 --> Router Class Initialized
INFO - 2021-07-15 16:02:11 --> Output Class Initialized
INFO - 2021-07-15 16:02:11 --> Security Class Initialized
DEBUG - 2021-07-15 16:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 16:02:11 --> Input Class Initialized
INFO - 2021-07-15 16:02:11 --> Language Class Initialized
ERROR - 2021-07-15 16:02:11 --> 404 Page Not Found: Faviconico/index
INFO - 2021-07-15 16:02:42 --> Config Class Initialized
INFO - 2021-07-15 16:02:42 --> Hooks Class Initialized
DEBUG - 2021-07-15 16:02:42 --> UTF-8 Support Enabled
INFO - 2021-07-15 16:02:42 --> Utf8 Class Initialized
INFO - 2021-07-15 16:02:42 --> URI Class Initialized
INFO - 2021-07-15 16:02:42 --> Router Class Initialized
INFO - 2021-07-15 16:02:42 --> Output Class Initialized
INFO - 2021-07-15 16:02:42 --> Security Class Initialized
DEBUG - 2021-07-15 16:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 16:02:42 --> Input Class Initialized
INFO - 2021-07-15 16:02:42 --> Language Class Initialized
INFO - 2021-07-15 16:02:42 --> Loader Class Initialized
INFO - 2021-07-15 16:02:42 --> Helper loaded: basic_helper
INFO - 2021-07-15 16:02:42 --> Helper loaded: url_helper
INFO - 2021-07-15 16:02:42 --> Helper loaded: file_helper
INFO - 2021-07-15 16:02:42 --> Helper loaded: form_helper
INFO - 2021-07-15 16:02:42 --> Helper loaded: cookie_helper
INFO - 2021-07-15 16:02:42 --> Helper loaded: security_helper
INFO - 2021-07-15 16:02:42 --> Helper loaded: directory_helper
INFO - 2021-07-15 16:02:42 --> Helper loaded: language_helper
INFO - 2021-07-15 16:02:42 --> Helper loaded: general_helper
INFO - 2021-07-15 16:02:42 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 16:02:42 --> Database Driver Class Initialized
DEBUG - 2021-07-15 16:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 16:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 16:02:42 --> Parser Class Initialized
INFO - 2021-07-15 16:02:42 --> Form Validation Class Initialized
INFO - 2021-07-15 16:02:42 --> Upload Class Initialized
INFO - 2021-07-15 16:02:42 --> Email Class Initialized
INFO - 2021-07-15 16:02:42 --> MY_Model class loaded
INFO - 2021-07-15 16:02:42 --> Model "Users_model" initialized
INFO - 2021-07-15 16:02:42 --> Model "Settings_model" initialized
INFO - 2021-07-15 16:02:42 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 16:02:42 --> Model "Permissions_model" initialized
INFO - 2021-07-15 16:02:42 --> Model "Roles_model" initialized
INFO - 2021-07-15 16:02:42 --> Model "Activity_model" initialized
INFO - 2021-07-15 16:02:42 --> Model "Templates_model" initialized
INFO - 2021-07-15 16:02:42 --> Database Driver Class Initialized
INFO - 2021-07-15 16:02:42 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 16:02:42 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 16:02:42 --> Controller Class Initialized
ERROR - 2021-07-15 16:02:42 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-15 16:02:42 --> Severity: error --> Exception: Call to a member function list() on null C:\wamp64\www\crm\application\views\car\car_list.php 41
INFO - 2021-07-15 16:03:43 --> Config Class Initialized
INFO - 2021-07-15 16:03:43 --> Hooks Class Initialized
DEBUG - 2021-07-15 16:03:43 --> UTF-8 Support Enabled
INFO - 2021-07-15 16:03:43 --> Utf8 Class Initialized
INFO - 2021-07-15 16:03:43 --> URI Class Initialized
INFO - 2021-07-15 16:03:43 --> Router Class Initialized
INFO - 2021-07-15 16:03:43 --> Output Class Initialized
INFO - 2021-07-15 16:03:43 --> Security Class Initialized
DEBUG - 2021-07-15 16:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 16:03:43 --> Input Class Initialized
INFO - 2021-07-15 16:03:43 --> Language Class Initialized
INFO - 2021-07-15 16:03:43 --> Loader Class Initialized
INFO - 2021-07-15 16:03:43 --> Helper loaded: basic_helper
INFO - 2021-07-15 16:03:43 --> Helper loaded: url_helper
INFO - 2021-07-15 16:03:43 --> Helper loaded: file_helper
INFO - 2021-07-15 16:03:43 --> Helper loaded: form_helper
INFO - 2021-07-15 16:03:43 --> Helper loaded: cookie_helper
INFO - 2021-07-15 16:03:43 --> Helper loaded: security_helper
INFO - 2021-07-15 16:03:43 --> Helper loaded: directory_helper
INFO - 2021-07-15 16:03:43 --> Helper loaded: language_helper
INFO - 2021-07-15 16:03:43 --> Helper loaded: general_helper
INFO - 2021-07-15 16:03:43 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 16:03:43 --> Database Driver Class Initialized
DEBUG - 2021-07-15 16:03:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 16:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 16:03:43 --> Parser Class Initialized
INFO - 2021-07-15 16:03:43 --> Form Validation Class Initialized
INFO - 2021-07-15 16:03:43 --> Upload Class Initialized
INFO - 2021-07-15 16:03:43 --> Email Class Initialized
INFO - 2021-07-15 16:03:43 --> MY_Model class loaded
INFO - 2021-07-15 16:03:43 --> Model "Users_model" initialized
INFO - 2021-07-15 16:03:43 --> Model "Settings_model" initialized
INFO - 2021-07-15 16:03:43 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 16:03:43 --> Model "Permissions_model" initialized
INFO - 2021-07-15 16:03:43 --> Model "Roles_model" initialized
INFO - 2021-07-15 16:03:43 --> Model "Activity_model" initialized
INFO - 2021-07-15 16:03:43 --> Model "Templates_model" initialized
INFO - 2021-07-15 16:03:43 --> Database Driver Class Initialized
INFO - 2021-07-15 16:03:44 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 16:03:44 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 16:03:44 --> Controller Class Initialized
ERROR - 2021-07-15 16:03:44 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 16:03:44 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 16:03:44 --> Final output sent to browser
DEBUG - 2021-07-15 16:03:44 --> Total execution time: 0.5401
INFO - 2021-07-15 16:04:02 --> Config Class Initialized
INFO - 2021-07-15 16:04:02 --> Hooks Class Initialized
DEBUG - 2021-07-15 16:04:02 --> UTF-8 Support Enabled
INFO - 2021-07-15 16:04:02 --> Utf8 Class Initialized
INFO - 2021-07-15 16:04:02 --> URI Class Initialized
INFO - 2021-07-15 16:04:02 --> Router Class Initialized
INFO - 2021-07-15 16:04:02 --> Output Class Initialized
INFO - 2021-07-15 16:04:02 --> Security Class Initialized
DEBUG - 2021-07-15 16:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 16:04:02 --> Input Class Initialized
INFO - 2021-07-15 16:04:02 --> Language Class Initialized
INFO - 2021-07-15 16:04:02 --> Loader Class Initialized
INFO - 2021-07-15 16:04:02 --> Helper loaded: basic_helper
INFO - 2021-07-15 16:04:02 --> Helper loaded: url_helper
INFO - 2021-07-15 16:04:02 --> Helper loaded: file_helper
INFO - 2021-07-15 16:04:02 --> Helper loaded: form_helper
INFO - 2021-07-15 16:04:02 --> Helper loaded: cookie_helper
INFO - 2021-07-15 16:04:02 --> Helper loaded: security_helper
INFO - 2021-07-15 16:04:02 --> Helper loaded: directory_helper
INFO - 2021-07-15 16:04:02 --> Helper loaded: language_helper
INFO - 2021-07-15 16:04:02 --> Helper loaded: general_helper
INFO - 2021-07-15 16:04:02 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 16:04:02 --> Database Driver Class Initialized
DEBUG - 2021-07-15 16:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 16:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 16:04:02 --> Parser Class Initialized
INFO - 2021-07-15 16:04:02 --> Form Validation Class Initialized
INFO - 2021-07-15 16:04:02 --> Upload Class Initialized
INFO - 2021-07-15 16:04:02 --> Email Class Initialized
INFO - 2021-07-15 16:04:02 --> MY_Model class loaded
INFO - 2021-07-15 16:04:02 --> Model "Users_model" initialized
INFO - 2021-07-15 16:04:02 --> Model "Settings_model" initialized
INFO - 2021-07-15 16:04:02 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 16:04:02 --> Model "Permissions_model" initialized
INFO - 2021-07-15 16:04:02 --> Model "Roles_model" initialized
INFO - 2021-07-15 16:04:02 --> Model "Activity_model" initialized
INFO - 2021-07-15 16:04:02 --> Model "Templates_model" initialized
INFO - 2021-07-15 16:04:02 --> Database Driver Class Initialized
INFO - 2021-07-15 16:04:02 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 16:04:02 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 16:04:02 --> Controller Class Initialized
ERROR - 2021-07-15 16:04:02 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 16:04:02 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 16:04:02 --> Final output sent to browser
DEBUG - 2021-07-15 16:04:02 --> Total execution time: 0.1287
INFO - 2021-07-15 16:05:29 --> Config Class Initialized
INFO - 2021-07-15 16:05:29 --> Hooks Class Initialized
DEBUG - 2021-07-15 16:05:29 --> UTF-8 Support Enabled
INFO - 2021-07-15 16:05:29 --> Utf8 Class Initialized
INFO - 2021-07-15 16:05:29 --> URI Class Initialized
INFO - 2021-07-15 16:05:29 --> Router Class Initialized
INFO - 2021-07-15 16:05:29 --> Output Class Initialized
INFO - 2021-07-15 16:05:29 --> Security Class Initialized
DEBUG - 2021-07-15 16:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 16:05:29 --> Input Class Initialized
INFO - 2021-07-15 16:05:29 --> Language Class Initialized
INFO - 2021-07-15 16:05:29 --> Loader Class Initialized
INFO - 2021-07-15 16:05:29 --> Helper loaded: basic_helper
INFO - 2021-07-15 16:05:29 --> Helper loaded: url_helper
INFO - 2021-07-15 16:05:29 --> Helper loaded: file_helper
INFO - 2021-07-15 16:05:29 --> Helper loaded: form_helper
INFO - 2021-07-15 16:05:29 --> Helper loaded: cookie_helper
INFO - 2021-07-15 16:05:29 --> Helper loaded: security_helper
INFO - 2021-07-15 16:05:29 --> Helper loaded: directory_helper
INFO - 2021-07-15 16:05:29 --> Helper loaded: language_helper
INFO - 2021-07-15 16:05:29 --> Helper loaded: general_helper
INFO - 2021-07-15 16:05:29 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 16:05:29 --> Database Driver Class Initialized
DEBUG - 2021-07-15 16:05:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 16:05:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 16:05:29 --> Parser Class Initialized
INFO - 2021-07-15 16:05:29 --> Form Validation Class Initialized
INFO - 2021-07-15 16:05:29 --> Upload Class Initialized
INFO - 2021-07-15 16:05:29 --> Email Class Initialized
INFO - 2021-07-15 16:05:29 --> MY_Model class loaded
INFO - 2021-07-15 16:05:29 --> Model "Users_model" initialized
INFO - 2021-07-15 16:05:29 --> Model "Settings_model" initialized
INFO - 2021-07-15 16:05:29 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 16:05:29 --> Model "Permissions_model" initialized
INFO - 2021-07-15 16:05:29 --> Model "Roles_model" initialized
INFO - 2021-07-15 16:05:29 --> Model "Activity_model" initialized
INFO - 2021-07-15 16:05:29 --> Model "Templates_model" initialized
INFO - 2021-07-15 16:05:29 --> Database Driver Class Initialized
INFO - 2021-07-15 16:05:29 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 16:05:29 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 16:05:29 --> Controller Class Initialized
ERROR - 2021-07-15 16:05:29 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 16:05:29 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 16:05:29 --> Final output sent to browser
DEBUG - 2021-07-15 16:05:29 --> Total execution time: 0.5444
INFO - 2021-07-15 16:05:38 --> Config Class Initialized
INFO - 2021-07-15 16:05:38 --> Hooks Class Initialized
DEBUG - 2021-07-15 16:05:38 --> UTF-8 Support Enabled
INFO - 2021-07-15 16:05:38 --> Utf8 Class Initialized
INFO - 2021-07-15 16:05:38 --> URI Class Initialized
INFO - 2021-07-15 16:05:38 --> Router Class Initialized
INFO - 2021-07-15 16:05:38 --> Output Class Initialized
INFO - 2021-07-15 16:05:38 --> Security Class Initialized
DEBUG - 2021-07-15 16:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 16:05:38 --> Input Class Initialized
INFO - 2021-07-15 16:05:38 --> Language Class Initialized
INFO - 2021-07-15 16:05:38 --> Loader Class Initialized
INFO - 2021-07-15 16:05:38 --> Helper loaded: basic_helper
INFO - 2021-07-15 16:05:38 --> Helper loaded: url_helper
INFO - 2021-07-15 16:05:38 --> Helper loaded: file_helper
INFO - 2021-07-15 16:05:38 --> Helper loaded: form_helper
INFO - 2021-07-15 16:05:38 --> Helper loaded: cookie_helper
INFO - 2021-07-15 16:05:38 --> Helper loaded: security_helper
INFO - 2021-07-15 16:05:38 --> Helper loaded: directory_helper
INFO - 2021-07-15 16:05:38 --> Helper loaded: language_helper
INFO - 2021-07-15 16:05:38 --> Helper loaded: general_helper
INFO - 2021-07-15 16:05:38 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 16:05:38 --> Database Driver Class Initialized
DEBUG - 2021-07-15 16:05:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 16:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 16:05:38 --> Parser Class Initialized
INFO - 2021-07-15 16:05:38 --> Form Validation Class Initialized
INFO - 2021-07-15 16:05:38 --> Upload Class Initialized
INFO - 2021-07-15 16:05:38 --> Email Class Initialized
INFO - 2021-07-15 16:05:38 --> MY_Model class loaded
INFO - 2021-07-15 16:05:38 --> Model "Users_model" initialized
INFO - 2021-07-15 16:05:38 --> Model "Settings_model" initialized
INFO - 2021-07-15 16:05:38 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 16:05:38 --> Model "Permissions_model" initialized
INFO - 2021-07-15 16:05:38 --> Model "Roles_model" initialized
INFO - 2021-07-15 16:05:38 --> Model "Activity_model" initialized
INFO - 2021-07-15 16:05:38 --> Model "Templates_model" initialized
INFO - 2021-07-15 16:05:38 --> Database Driver Class Initialized
INFO - 2021-07-15 16:05:38 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 16:05:38 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 16:05:38 --> Controller Class Initialized
ERROR - 2021-07-15 16:05:38 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 16:05:38 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 16:05:38 --> Final output sent to browser
DEBUG - 2021-07-15 16:05:38 --> Total execution time: 0.1249
INFO - 2021-07-15 16:05:55 --> Config Class Initialized
INFO - 2021-07-15 16:05:55 --> Hooks Class Initialized
DEBUG - 2021-07-15 16:05:55 --> UTF-8 Support Enabled
INFO - 2021-07-15 16:05:55 --> Utf8 Class Initialized
INFO - 2021-07-15 16:05:55 --> URI Class Initialized
INFO - 2021-07-15 16:05:55 --> Router Class Initialized
INFO - 2021-07-15 16:05:55 --> Output Class Initialized
INFO - 2021-07-15 16:05:55 --> Security Class Initialized
DEBUG - 2021-07-15 16:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 16:05:55 --> Input Class Initialized
INFO - 2021-07-15 16:05:55 --> Language Class Initialized
INFO - 2021-07-15 16:05:55 --> Loader Class Initialized
INFO - 2021-07-15 16:05:55 --> Helper loaded: basic_helper
INFO - 2021-07-15 16:05:55 --> Helper loaded: url_helper
INFO - 2021-07-15 16:05:55 --> Helper loaded: file_helper
INFO - 2021-07-15 16:05:55 --> Helper loaded: form_helper
INFO - 2021-07-15 16:05:55 --> Helper loaded: cookie_helper
INFO - 2021-07-15 16:05:55 --> Helper loaded: security_helper
INFO - 2021-07-15 16:05:55 --> Helper loaded: directory_helper
INFO - 2021-07-15 16:05:55 --> Helper loaded: language_helper
INFO - 2021-07-15 16:05:55 --> Helper loaded: general_helper
INFO - 2021-07-15 16:05:55 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 16:05:55 --> Database Driver Class Initialized
DEBUG - 2021-07-15 16:05:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 16:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 16:05:55 --> Parser Class Initialized
INFO - 2021-07-15 16:05:55 --> Form Validation Class Initialized
INFO - 2021-07-15 16:05:55 --> Upload Class Initialized
INFO - 2021-07-15 16:05:55 --> Email Class Initialized
INFO - 2021-07-15 16:05:55 --> MY_Model class loaded
INFO - 2021-07-15 16:05:55 --> Model "Users_model" initialized
INFO - 2021-07-15 16:05:55 --> Model "Settings_model" initialized
INFO - 2021-07-15 16:05:55 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 16:05:55 --> Model "Permissions_model" initialized
INFO - 2021-07-15 16:05:55 --> Model "Roles_model" initialized
INFO - 2021-07-15 16:05:55 --> Model "Activity_model" initialized
INFO - 2021-07-15 16:05:55 --> Model "Templates_model" initialized
INFO - 2021-07-15 16:05:55 --> Database Driver Class Initialized
INFO - 2021-07-15 16:05:55 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 16:05:55 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 16:05:55 --> Controller Class Initialized
ERROR - 2021-07-15 16:05:55 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 16:05:55 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 16:05:55 --> Final output sent to browser
DEBUG - 2021-07-15 16:05:55 --> Total execution time: 0.1290
INFO - 2021-07-15 16:07:47 --> Config Class Initialized
INFO - 2021-07-15 16:07:47 --> Hooks Class Initialized
DEBUG - 2021-07-15 16:07:47 --> UTF-8 Support Enabled
INFO - 2021-07-15 16:07:47 --> Utf8 Class Initialized
INFO - 2021-07-15 16:07:47 --> URI Class Initialized
INFO - 2021-07-15 16:07:47 --> Router Class Initialized
INFO - 2021-07-15 16:07:47 --> Output Class Initialized
INFO - 2021-07-15 16:07:47 --> Security Class Initialized
DEBUG - 2021-07-15 16:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 16:07:47 --> Input Class Initialized
INFO - 2021-07-15 16:07:47 --> Language Class Initialized
INFO - 2021-07-15 16:07:47 --> Loader Class Initialized
INFO - 2021-07-15 16:07:47 --> Helper loaded: basic_helper
INFO - 2021-07-15 16:07:47 --> Helper loaded: url_helper
INFO - 2021-07-15 16:07:47 --> Helper loaded: file_helper
INFO - 2021-07-15 16:07:47 --> Helper loaded: form_helper
INFO - 2021-07-15 16:07:47 --> Helper loaded: cookie_helper
INFO - 2021-07-15 16:07:47 --> Helper loaded: security_helper
INFO - 2021-07-15 16:07:47 --> Helper loaded: directory_helper
INFO - 2021-07-15 16:07:47 --> Helper loaded: language_helper
INFO - 2021-07-15 16:07:47 --> Helper loaded: general_helper
INFO - 2021-07-15 16:07:47 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 16:07:47 --> Database Driver Class Initialized
DEBUG - 2021-07-15 16:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 16:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 16:07:47 --> Parser Class Initialized
INFO - 2021-07-15 16:07:47 --> Form Validation Class Initialized
INFO - 2021-07-15 16:07:47 --> Upload Class Initialized
INFO - 2021-07-15 16:07:47 --> Email Class Initialized
INFO - 2021-07-15 16:07:47 --> MY_Model class loaded
INFO - 2021-07-15 16:07:47 --> Model "Users_model" initialized
INFO - 2021-07-15 16:07:47 --> Model "Settings_model" initialized
INFO - 2021-07-15 16:07:47 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 16:07:47 --> Model "Permissions_model" initialized
INFO - 2021-07-15 16:07:47 --> Model "Roles_model" initialized
INFO - 2021-07-15 16:07:47 --> Model "Activity_model" initialized
INFO - 2021-07-15 16:07:47 --> Model "Templates_model" initialized
INFO - 2021-07-15 16:07:47 --> Database Driver Class Initialized
INFO - 2021-07-15 16:07:48 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 16:07:48 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 16:07:48 --> Controller Class Initialized
ERROR - 2021-07-15 16:07:48 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 16:07:48 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 16:07:48 --> Final output sent to browser
DEBUG - 2021-07-15 16:07:48 --> Total execution time: 0.5366
INFO - 2021-07-15 16:10:30 --> Config Class Initialized
INFO - 2021-07-15 16:10:30 --> Hooks Class Initialized
DEBUG - 2021-07-15 16:10:30 --> UTF-8 Support Enabled
INFO - 2021-07-15 16:10:30 --> Utf8 Class Initialized
INFO - 2021-07-15 16:10:30 --> URI Class Initialized
INFO - 2021-07-15 16:10:30 --> Router Class Initialized
INFO - 2021-07-15 16:10:30 --> Output Class Initialized
INFO - 2021-07-15 16:10:30 --> Security Class Initialized
DEBUG - 2021-07-15 16:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 16:10:30 --> Input Class Initialized
INFO - 2021-07-15 16:10:30 --> Language Class Initialized
INFO - 2021-07-15 16:10:30 --> Loader Class Initialized
INFO - 2021-07-15 16:10:30 --> Helper loaded: basic_helper
INFO - 2021-07-15 16:10:30 --> Helper loaded: url_helper
INFO - 2021-07-15 16:10:30 --> Helper loaded: file_helper
INFO - 2021-07-15 16:10:30 --> Helper loaded: form_helper
INFO - 2021-07-15 16:10:30 --> Helper loaded: cookie_helper
INFO - 2021-07-15 16:10:30 --> Helper loaded: security_helper
INFO - 2021-07-15 16:10:30 --> Helper loaded: directory_helper
INFO - 2021-07-15 16:10:30 --> Helper loaded: language_helper
INFO - 2021-07-15 16:10:30 --> Helper loaded: general_helper
INFO - 2021-07-15 16:10:30 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 16:10:30 --> Database Driver Class Initialized
DEBUG - 2021-07-15 16:10:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 16:10:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 16:10:30 --> Parser Class Initialized
INFO - 2021-07-15 16:10:30 --> Form Validation Class Initialized
INFO - 2021-07-15 16:10:30 --> Upload Class Initialized
INFO - 2021-07-15 16:10:30 --> Email Class Initialized
INFO - 2021-07-15 16:10:30 --> MY_Model class loaded
INFO - 2021-07-15 16:10:30 --> Model "Users_model" initialized
INFO - 2021-07-15 16:10:30 --> Model "Settings_model" initialized
INFO - 2021-07-15 16:10:30 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 16:10:30 --> Model "Permissions_model" initialized
INFO - 2021-07-15 16:10:30 --> Model "Roles_model" initialized
INFO - 2021-07-15 16:10:30 --> Model "Activity_model" initialized
INFO - 2021-07-15 16:10:30 --> Model "Templates_model" initialized
INFO - 2021-07-15 16:10:30 --> Database Driver Class Initialized
INFO - 2021-07-15 16:10:30 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 16:10:30 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 16:10:30 --> Controller Class Initialized
ERROR - 2021-07-15 16:10:30 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 16:10:30 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 16:10:30 --> Final output sent to browser
DEBUG - 2021-07-15 16:10:30 --> Total execution time: 0.1590
INFO - 2021-07-15 16:10:41 --> Config Class Initialized
INFO - 2021-07-15 16:10:41 --> Hooks Class Initialized
DEBUG - 2021-07-15 16:10:41 --> UTF-8 Support Enabled
INFO - 2021-07-15 16:10:41 --> Utf8 Class Initialized
INFO - 2021-07-15 16:10:41 --> URI Class Initialized
INFO - 2021-07-15 16:10:41 --> Router Class Initialized
INFO - 2021-07-15 16:10:41 --> Output Class Initialized
INFO - 2021-07-15 16:10:41 --> Security Class Initialized
DEBUG - 2021-07-15 16:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 16:10:41 --> Input Class Initialized
INFO - 2021-07-15 16:10:41 --> Language Class Initialized
INFO - 2021-07-15 16:10:41 --> Loader Class Initialized
INFO - 2021-07-15 16:10:42 --> Helper loaded: basic_helper
INFO - 2021-07-15 16:10:42 --> Helper loaded: url_helper
INFO - 2021-07-15 16:10:42 --> Helper loaded: file_helper
INFO - 2021-07-15 16:10:42 --> Helper loaded: form_helper
INFO - 2021-07-15 16:10:42 --> Helper loaded: cookie_helper
INFO - 2021-07-15 16:10:42 --> Helper loaded: security_helper
INFO - 2021-07-15 16:10:42 --> Helper loaded: directory_helper
INFO - 2021-07-15 16:10:42 --> Helper loaded: language_helper
INFO - 2021-07-15 16:10:42 --> Helper loaded: general_helper
INFO - 2021-07-15 16:10:42 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 16:10:42 --> Database Driver Class Initialized
DEBUG - 2021-07-15 16:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 16:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 16:10:42 --> Parser Class Initialized
INFO - 2021-07-15 16:10:42 --> Form Validation Class Initialized
INFO - 2021-07-15 16:10:42 --> Upload Class Initialized
INFO - 2021-07-15 16:10:42 --> Email Class Initialized
INFO - 2021-07-15 16:10:42 --> MY_Model class loaded
INFO - 2021-07-15 16:10:42 --> Model "Users_model" initialized
INFO - 2021-07-15 16:10:42 --> Model "Settings_model" initialized
INFO - 2021-07-15 16:10:42 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 16:10:42 --> Model "Permissions_model" initialized
INFO - 2021-07-15 16:10:42 --> Model "Roles_model" initialized
INFO - 2021-07-15 16:10:42 --> Model "Activity_model" initialized
INFO - 2021-07-15 16:10:42 --> Model "Templates_model" initialized
INFO - 2021-07-15 16:10:42 --> Database Driver Class Initialized
INFO - 2021-07-15 16:10:42 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 16:10:42 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 16:10:42 --> Controller Class Initialized
ERROR - 2021-07-15 16:10:42 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 16:10:42 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 16:10:42 --> Final output sent to browser
DEBUG - 2021-07-15 16:10:42 --> Total execution time: 0.1311
INFO - 2021-07-15 16:10:50 --> Config Class Initialized
INFO - 2021-07-15 16:10:50 --> Hooks Class Initialized
DEBUG - 2021-07-15 16:10:50 --> UTF-8 Support Enabled
INFO - 2021-07-15 16:10:50 --> Utf8 Class Initialized
INFO - 2021-07-15 16:10:50 --> URI Class Initialized
INFO - 2021-07-15 16:10:50 --> Router Class Initialized
INFO - 2021-07-15 16:10:50 --> Output Class Initialized
INFO - 2021-07-15 16:10:50 --> Security Class Initialized
DEBUG - 2021-07-15 16:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 16:10:50 --> Input Class Initialized
INFO - 2021-07-15 16:10:50 --> Language Class Initialized
INFO - 2021-07-15 16:10:50 --> Loader Class Initialized
INFO - 2021-07-15 16:10:50 --> Helper loaded: basic_helper
INFO - 2021-07-15 16:10:50 --> Helper loaded: url_helper
INFO - 2021-07-15 16:10:50 --> Helper loaded: file_helper
INFO - 2021-07-15 16:10:50 --> Helper loaded: form_helper
INFO - 2021-07-15 16:10:50 --> Helper loaded: cookie_helper
INFO - 2021-07-15 16:10:50 --> Helper loaded: security_helper
INFO - 2021-07-15 16:10:50 --> Helper loaded: directory_helper
INFO - 2021-07-15 16:10:50 --> Helper loaded: language_helper
INFO - 2021-07-15 16:10:50 --> Helper loaded: general_helper
INFO - 2021-07-15 16:10:50 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 16:10:50 --> Database Driver Class Initialized
DEBUG - 2021-07-15 16:10:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 16:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 16:10:50 --> Parser Class Initialized
INFO - 2021-07-15 16:10:50 --> Form Validation Class Initialized
INFO - 2021-07-15 16:10:50 --> Upload Class Initialized
INFO - 2021-07-15 16:10:50 --> Email Class Initialized
INFO - 2021-07-15 16:10:50 --> MY_Model class loaded
INFO - 2021-07-15 16:10:50 --> Model "Users_model" initialized
INFO - 2021-07-15 16:10:50 --> Model "Settings_model" initialized
INFO - 2021-07-15 16:10:50 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 16:10:50 --> Model "Permissions_model" initialized
INFO - 2021-07-15 16:10:50 --> Model "Roles_model" initialized
INFO - 2021-07-15 16:10:50 --> Model "Activity_model" initialized
INFO - 2021-07-15 16:10:50 --> Model "Templates_model" initialized
INFO - 2021-07-15 16:10:50 --> Database Driver Class Initialized
INFO - 2021-07-15 16:10:50 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 16:10:50 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 16:10:50 --> Controller Class Initialized
ERROR - 2021-07-15 16:10:50 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 16:10:50 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 16:10:50 --> Final output sent to browser
DEBUG - 2021-07-15 16:10:50 --> Total execution time: 0.1435
INFO - 2021-07-15 16:24:03 --> Config Class Initialized
INFO - 2021-07-15 16:24:03 --> Hooks Class Initialized
DEBUG - 2021-07-15 16:24:03 --> UTF-8 Support Enabled
INFO - 2021-07-15 16:24:03 --> Utf8 Class Initialized
INFO - 2021-07-15 16:24:03 --> URI Class Initialized
INFO - 2021-07-15 16:24:03 --> Router Class Initialized
INFO - 2021-07-15 16:24:03 --> Output Class Initialized
INFO - 2021-07-15 16:24:03 --> Security Class Initialized
DEBUG - 2021-07-15 16:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 16:24:03 --> Input Class Initialized
INFO - 2021-07-15 16:24:03 --> Language Class Initialized
INFO - 2021-07-15 16:24:03 --> Loader Class Initialized
INFO - 2021-07-15 16:24:03 --> Helper loaded: basic_helper
INFO - 2021-07-15 16:24:03 --> Helper loaded: url_helper
INFO - 2021-07-15 16:24:03 --> Helper loaded: file_helper
INFO - 2021-07-15 16:24:03 --> Helper loaded: form_helper
INFO - 2021-07-15 16:24:03 --> Helper loaded: cookie_helper
INFO - 2021-07-15 16:24:03 --> Helper loaded: security_helper
INFO - 2021-07-15 16:24:03 --> Helper loaded: directory_helper
INFO - 2021-07-15 16:24:03 --> Helper loaded: language_helper
INFO - 2021-07-15 16:24:03 --> Helper loaded: general_helper
INFO - 2021-07-15 16:24:03 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 16:24:03 --> Database Driver Class Initialized
DEBUG - 2021-07-15 16:24:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 16:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 16:24:03 --> Parser Class Initialized
INFO - 2021-07-15 16:24:03 --> Form Validation Class Initialized
INFO - 2021-07-15 16:24:03 --> Upload Class Initialized
INFO - 2021-07-15 16:24:03 --> Email Class Initialized
INFO - 2021-07-15 16:24:03 --> MY_Model class loaded
INFO - 2021-07-15 16:24:03 --> Model "Users_model" initialized
INFO - 2021-07-15 16:24:03 --> Model "Settings_model" initialized
INFO - 2021-07-15 16:24:03 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 16:24:03 --> Model "Permissions_model" initialized
INFO - 2021-07-15 16:24:03 --> Model "Roles_model" initialized
INFO - 2021-07-15 16:24:03 --> Model "Activity_model" initialized
INFO - 2021-07-15 16:24:03 --> Model "Templates_model" initialized
INFO - 2021-07-15 16:24:03 --> Database Driver Class Initialized
INFO - 2021-07-15 16:24:03 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 16:24:03 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 16:24:03 --> Controller Class Initialized
ERROR - 2021-07-15 16:24:03 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 16:24:03 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 16:24:03 --> Final output sent to browser
DEBUG - 2021-07-15 16:24:03 --> Total execution time: 0.1294
INFO - 2021-07-15 16:24:03 --> Config Class Initialized
INFO - 2021-07-15 16:24:03 --> Hooks Class Initialized
DEBUG - 2021-07-15 16:24:03 --> UTF-8 Support Enabled
INFO - 2021-07-15 16:24:03 --> Utf8 Class Initialized
INFO - 2021-07-15 16:24:03 --> URI Class Initialized
INFO - 2021-07-15 16:24:03 --> Router Class Initialized
INFO - 2021-07-15 16:24:03 --> Output Class Initialized
INFO - 2021-07-15 16:24:03 --> Security Class Initialized
DEBUG - 2021-07-15 16:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 16:24:03 --> Input Class Initialized
INFO - 2021-07-15 16:24:03 --> Language Class Initialized
ERROR - 2021-07-15 16:24:03 --> 404 Page Not Found: Faviconico/index
INFO - 2021-07-15 16:25:19 --> Config Class Initialized
INFO - 2021-07-15 16:25:19 --> Hooks Class Initialized
DEBUG - 2021-07-15 16:25:19 --> UTF-8 Support Enabled
INFO - 2021-07-15 16:25:19 --> Utf8 Class Initialized
INFO - 2021-07-15 16:25:19 --> URI Class Initialized
INFO - 2021-07-15 16:25:19 --> Router Class Initialized
INFO - 2021-07-15 16:25:19 --> Output Class Initialized
INFO - 2021-07-15 16:25:19 --> Security Class Initialized
DEBUG - 2021-07-15 16:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 16:25:19 --> Input Class Initialized
INFO - 2021-07-15 16:25:19 --> Language Class Initialized
INFO - 2021-07-15 16:25:19 --> Loader Class Initialized
INFO - 2021-07-15 16:25:19 --> Helper loaded: basic_helper
INFO - 2021-07-15 16:25:19 --> Helper loaded: url_helper
INFO - 2021-07-15 16:25:19 --> Helper loaded: file_helper
INFO - 2021-07-15 16:25:19 --> Helper loaded: form_helper
INFO - 2021-07-15 16:25:19 --> Helper loaded: cookie_helper
INFO - 2021-07-15 16:25:19 --> Helper loaded: security_helper
INFO - 2021-07-15 16:25:19 --> Helper loaded: directory_helper
INFO - 2021-07-15 16:25:19 --> Helper loaded: language_helper
INFO - 2021-07-15 16:25:19 --> Helper loaded: general_helper
INFO - 2021-07-15 16:25:19 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 16:25:19 --> Database Driver Class Initialized
DEBUG - 2021-07-15 16:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 16:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 16:25:19 --> Parser Class Initialized
INFO - 2021-07-15 16:25:19 --> Form Validation Class Initialized
INFO - 2021-07-15 16:25:19 --> Upload Class Initialized
INFO - 2021-07-15 16:25:19 --> Email Class Initialized
INFO - 2021-07-15 16:25:19 --> MY_Model class loaded
INFO - 2021-07-15 16:25:19 --> Model "Users_model" initialized
INFO - 2021-07-15 16:25:19 --> Model "Settings_model" initialized
INFO - 2021-07-15 16:25:19 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 16:25:19 --> Model "Permissions_model" initialized
INFO - 2021-07-15 16:25:19 --> Model "Roles_model" initialized
INFO - 2021-07-15 16:25:19 --> Model "Activity_model" initialized
INFO - 2021-07-15 16:25:19 --> Model "Templates_model" initialized
INFO - 2021-07-15 16:25:19 --> Database Driver Class Initialized
INFO - 2021-07-15 16:25:20 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 16:25:20 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 16:25:20 --> Controller Class Initialized
ERROR - 2021-07-15 16:25:20 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 16:25:20 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 16:25:20 --> Final output sent to browser
DEBUG - 2021-07-15 16:25:20 --> Total execution time: 0.5329
INFO - 2021-07-15 16:26:26 --> Config Class Initialized
INFO - 2021-07-15 16:26:26 --> Hooks Class Initialized
DEBUG - 2021-07-15 16:26:26 --> UTF-8 Support Enabled
INFO - 2021-07-15 16:26:26 --> Utf8 Class Initialized
INFO - 2021-07-15 16:26:26 --> URI Class Initialized
INFO - 2021-07-15 16:26:26 --> Router Class Initialized
INFO - 2021-07-15 16:26:26 --> Output Class Initialized
INFO - 2021-07-15 16:26:26 --> Security Class Initialized
DEBUG - 2021-07-15 16:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 16:26:26 --> Input Class Initialized
INFO - 2021-07-15 16:26:26 --> Language Class Initialized
INFO - 2021-07-15 16:26:26 --> Loader Class Initialized
INFO - 2021-07-15 16:26:26 --> Helper loaded: basic_helper
INFO - 2021-07-15 16:26:26 --> Helper loaded: url_helper
INFO - 2021-07-15 16:26:26 --> Helper loaded: file_helper
INFO - 2021-07-15 16:26:26 --> Helper loaded: form_helper
INFO - 2021-07-15 16:26:26 --> Helper loaded: cookie_helper
INFO - 2021-07-15 16:26:26 --> Helper loaded: security_helper
INFO - 2021-07-15 16:26:26 --> Helper loaded: directory_helper
INFO - 2021-07-15 16:26:26 --> Helper loaded: language_helper
INFO - 2021-07-15 16:26:26 --> Helper loaded: general_helper
INFO - 2021-07-15 16:26:26 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 16:26:26 --> Database Driver Class Initialized
DEBUG - 2021-07-15 16:26:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 16:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 16:26:26 --> Parser Class Initialized
INFO - 2021-07-15 16:26:26 --> Form Validation Class Initialized
INFO - 2021-07-15 16:26:26 --> Upload Class Initialized
INFO - 2021-07-15 16:26:26 --> Email Class Initialized
INFO - 2021-07-15 16:26:26 --> MY_Model class loaded
INFO - 2021-07-15 16:26:26 --> Model "Users_model" initialized
INFO - 2021-07-15 16:26:26 --> Model "Settings_model" initialized
INFO - 2021-07-15 16:26:26 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 16:26:26 --> Model "Permissions_model" initialized
INFO - 2021-07-15 16:26:26 --> Model "Roles_model" initialized
INFO - 2021-07-15 16:26:26 --> Model "Activity_model" initialized
INFO - 2021-07-15 16:26:26 --> Model "Templates_model" initialized
INFO - 2021-07-15 16:26:26 --> Database Driver Class Initialized
INFO - 2021-07-15 16:26:27 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 16:26:27 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 16:26:27 --> Controller Class Initialized
ERROR - 2021-07-15 16:26:27 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 16:26:27 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-15 16:26:27 --> Final output sent to browser
DEBUG - 2021-07-15 16:26:27 --> Total execution time: 0.6338
INFO - 2021-07-15 17:19:35 --> Config Class Initialized
INFO - 2021-07-15 17:19:35 --> Hooks Class Initialized
DEBUG - 2021-07-15 17:19:35 --> UTF-8 Support Enabled
INFO - 2021-07-15 17:19:35 --> Utf8 Class Initialized
INFO - 2021-07-15 17:19:35 --> URI Class Initialized
INFO - 2021-07-15 17:19:35 --> Router Class Initialized
INFO - 2021-07-15 17:19:35 --> Output Class Initialized
INFO - 2021-07-15 17:19:35 --> Security Class Initialized
DEBUG - 2021-07-15 17:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 17:19:35 --> Input Class Initialized
INFO - 2021-07-15 17:19:35 --> Language Class Initialized
INFO - 2021-07-15 17:19:35 --> Loader Class Initialized
INFO - 2021-07-15 17:19:35 --> Helper loaded: basic_helper
INFO - 2021-07-15 17:19:35 --> Helper loaded: url_helper
INFO - 2021-07-15 17:19:35 --> Helper loaded: file_helper
INFO - 2021-07-15 17:19:35 --> Helper loaded: form_helper
INFO - 2021-07-15 17:19:35 --> Helper loaded: cookie_helper
INFO - 2021-07-15 17:19:35 --> Helper loaded: security_helper
INFO - 2021-07-15 17:19:35 --> Helper loaded: directory_helper
INFO - 2021-07-15 17:19:35 --> Helper loaded: language_helper
INFO - 2021-07-15 17:19:35 --> Helper loaded: general_helper
INFO - 2021-07-15 17:19:35 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 17:19:35 --> Database Driver Class Initialized
DEBUG - 2021-07-15 17:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 17:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 17:19:35 --> Parser Class Initialized
INFO - 2021-07-15 17:19:35 --> Form Validation Class Initialized
INFO - 2021-07-15 17:19:35 --> Upload Class Initialized
INFO - 2021-07-15 17:19:35 --> Email Class Initialized
INFO - 2021-07-15 17:19:35 --> MY_Model class loaded
INFO - 2021-07-15 17:19:35 --> Model "Users_model" initialized
INFO - 2021-07-15 17:19:35 --> Model "Settings_model" initialized
INFO - 2021-07-15 17:19:35 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 17:19:35 --> Model "Permissions_model" initialized
INFO - 2021-07-15 17:19:35 --> Model "Roles_model" initialized
INFO - 2021-07-15 17:19:35 --> Model "Activity_model" initialized
INFO - 2021-07-15 17:19:35 --> Model "Templates_model" initialized
INFO - 2021-07-15 17:19:35 --> Database Driver Class Initialized
INFO - 2021-07-15 17:19:35 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 17:19:35 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 17:19:35 --> Controller Class Initialized
ERROR - 2021-07-15 17:19:35 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 17:19:36 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 17:19:36 --> Final output sent to browser
DEBUG - 2021-07-15 17:19:36 --> Total execution time: 0.1563
INFO - 2021-07-15 17:19:37 --> Config Class Initialized
INFO - 2021-07-15 17:19:37 --> Hooks Class Initialized
DEBUG - 2021-07-15 17:19:37 --> UTF-8 Support Enabled
INFO - 2021-07-15 17:19:37 --> Utf8 Class Initialized
INFO - 2021-07-15 17:19:37 --> URI Class Initialized
INFO - 2021-07-15 17:19:37 --> Router Class Initialized
INFO - 2021-07-15 17:19:37 --> Output Class Initialized
INFO - 2021-07-15 17:19:37 --> Security Class Initialized
DEBUG - 2021-07-15 17:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 17:19:37 --> Input Class Initialized
INFO - 2021-07-15 17:19:37 --> Language Class Initialized
INFO - 2021-07-15 17:19:37 --> Loader Class Initialized
INFO - 2021-07-15 17:19:37 --> Helper loaded: basic_helper
INFO - 2021-07-15 17:19:37 --> Helper loaded: url_helper
INFO - 2021-07-15 17:19:37 --> Helper loaded: file_helper
INFO - 2021-07-15 17:19:37 --> Helper loaded: form_helper
INFO - 2021-07-15 17:19:37 --> Helper loaded: cookie_helper
INFO - 2021-07-15 17:19:37 --> Helper loaded: security_helper
INFO - 2021-07-15 17:19:37 --> Helper loaded: directory_helper
INFO - 2021-07-15 17:19:37 --> Helper loaded: language_helper
INFO - 2021-07-15 17:19:37 --> Helper loaded: general_helper
INFO - 2021-07-15 17:19:37 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 17:19:37 --> Database Driver Class Initialized
DEBUG - 2021-07-15 17:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 17:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 17:19:37 --> Parser Class Initialized
INFO - 2021-07-15 17:19:37 --> Form Validation Class Initialized
INFO - 2021-07-15 17:19:37 --> Upload Class Initialized
INFO - 2021-07-15 17:19:37 --> Email Class Initialized
INFO - 2021-07-15 17:19:37 --> MY_Model class loaded
INFO - 2021-07-15 17:19:37 --> Model "Users_model" initialized
INFO - 2021-07-15 17:19:37 --> Model "Settings_model" initialized
INFO - 2021-07-15 17:19:37 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 17:19:37 --> Model "Permissions_model" initialized
INFO - 2021-07-15 17:19:37 --> Model "Roles_model" initialized
INFO - 2021-07-15 17:19:37 --> Model "Activity_model" initialized
INFO - 2021-07-15 17:19:37 --> Model "Templates_model" initialized
INFO - 2021-07-15 17:19:37 --> Database Driver Class Initialized
INFO - 2021-07-15 17:19:37 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 17:19:37 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 17:19:37 --> Controller Class Initialized
ERROR - 2021-07-15 17:19:37 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 17:19:37 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 17:19:37 --> Final output sent to browser
DEBUG - 2021-07-15 17:19:37 --> Total execution time: 0.0624
INFO - 2021-07-15 17:23:14 --> Config Class Initialized
INFO - 2021-07-15 17:23:14 --> Hooks Class Initialized
DEBUG - 2021-07-15 17:23:14 --> UTF-8 Support Enabled
INFO - 2021-07-15 17:23:14 --> Utf8 Class Initialized
INFO - 2021-07-15 17:23:14 --> URI Class Initialized
INFO - 2021-07-15 17:23:14 --> Router Class Initialized
INFO - 2021-07-15 17:23:14 --> Output Class Initialized
INFO - 2021-07-15 17:23:14 --> Security Class Initialized
DEBUG - 2021-07-15 17:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 17:23:14 --> Input Class Initialized
INFO - 2021-07-15 17:23:14 --> Language Class Initialized
INFO - 2021-07-15 17:23:14 --> Loader Class Initialized
INFO - 2021-07-15 17:23:14 --> Helper loaded: basic_helper
INFO - 2021-07-15 17:23:14 --> Helper loaded: url_helper
INFO - 2021-07-15 17:23:14 --> Helper loaded: file_helper
INFO - 2021-07-15 17:23:14 --> Helper loaded: form_helper
INFO - 2021-07-15 17:23:14 --> Helper loaded: cookie_helper
INFO - 2021-07-15 17:23:14 --> Helper loaded: security_helper
INFO - 2021-07-15 17:23:14 --> Helper loaded: directory_helper
INFO - 2021-07-15 17:23:14 --> Helper loaded: language_helper
INFO - 2021-07-15 17:23:14 --> Helper loaded: general_helper
INFO - 2021-07-15 17:23:14 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 17:23:14 --> Database Driver Class Initialized
DEBUG - 2021-07-15 17:23:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 17:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 17:23:14 --> Parser Class Initialized
INFO - 2021-07-15 17:23:14 --> Form Validation Class Initialized
INFO - 2021-07-15 17:23:14 --> Upload Class Initialized
INFO - 2021-07-15 17:23:14 --> Email Class Initialized
INFO - 2021-07-15 17:23:14 --> MY_Model class loaded
INFO - 2021-07-15 17:23:14 --> Model "Users_model" initialized
INFO - 2021-07-15 17:23:14 --> Model "Settings_model" initialized
INFO - 2021-07-15 17:23:14 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 17:23:14 --> Model "Permissions_model" initialized
INFO - 2021-07-15 17:23:14 --> Model "Roles_model" initialized
INFO - 2021-07-15 17:23:14 --> Model "Activity_model" initialized
INFO - 2021-07-15 17:23:14 --> Model "Templates_model" initialized
INFO - 2021-07-15 17:23:14 --> Database Driver Class Initialized
INFO - 2021-07-15 17:23:14 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 17:23:14 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 17:23:14 --> Controller Class Initialized
ERROR - 2021-07-15 17:23:14 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 17:23:14 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 17:23:14 --> Final output sent to browser
DEBUG - 2021-07-15 17:23:14 --> Total execution time: 0.1485
INFO - 2021-07-15 17:43:46 --> Config Class Initialized
INFO - 2021-07-15 17:43:46 --> Hooks Class Initialized
DEBUG - 2021-07-15 17:43:46 --> UTF-8 Support Enabled
INFO - 2021-07-15 17:43:46 --> Utf8 Class Initialized
INFO - 2021-07-15 17:43:46 --> URI Class Initialized
INFO - 2021-07-15 17:43:46 --> Router Class Initialized
INFO - 2021-07-15 17:43:46 --> Output Class Initialized
INFO - 2021-07-15 17:43:46 --> Security Class Initialized
DEBUG - 2021-07-15 17:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 17:43:46 --> Input Class Initialized
INFO - 2021-07-15 17:43:46 --> Language Class Initialized
INFO - 2021-07-15 17:43:46 --> Loader Class Initialized
INFO - 2021-07-15 17:43:46 --> Helper loaded: basic_helper
INFO - 2021-07-15 17:43:46 --> Helper loaded: url_helper
INFO - 2021-07-15 17:43:46 --> Helper loaded: file_helper
INFO - 2021-07-15 17:43:46 --> Helper loaded: form_helper
INFO - 2021-07-15 17:43:46 --> Helper loaded: cookie_helper
INFO - 2021-07-15 17:43:46 --> Helper loaded: security_helper
INFO - 2021-07-15 17:43:46 --> Helper loaded: directory_helper
INFO - 2021-07-15 17:43:46 --> Helper loaded: language_helper
INFO - 2021-07-15 17:43:46 --> Helper loaded: general_helper
INFO - 2021-07-15 17:43:46 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 17:43:46 --> Database Driver Class Initialized
DEBUG - 2021-07-15 17:43:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 17:43:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 17:43:46 --> Parser Class Initialized
INFO - 2021-07-15 17:43:46 --> Form Validation Class Initialized
INFO - 2021-07-15 17:43:46 --> Upload Class Initialized
INFO - 2021-07-15 17:43:46 --> Email Class Initialized
INFO - 2021-07-15 17:43:46 --> MY_Model class loaded
INFO - 2021-07-15 17:43:46 --> Model "Users_model" initialized
INFO - 2021-07-15 17:43:46 --> Model "Settings_model" initialized
INFO - 2021-07-15 17:43:46 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 17:43:46 --> Model "Permissions_model" initialized
INFO - 2021-07-15 17:43:46 --> Model "Roles_model" initialized
INFO - 2021-07-15 17:43:46 --> Model "Activity_model" initialized
INFO - 2021-07-15 17:43:46 --> Model "Templates_model" initialized
INFO - 2021-07-15 17:43:46 --> Database Driver Class Initialized
INFO - 2021-07-15 17:43:46 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 17:43:46 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 17:43:46 --> Controller Class Initialized
ERROR - 2021-07-15 17:43:46 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 17:43:46 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 17:43:46 --> Final output sent to browser
DEBUG - 2021-07-15 17:43:46 --> Total execution time: 0.1650
INFO - 2021-07-15 17:43:46 --> Config Class Initialized
INFO - 2021-07-15 17:43:46 --> Hooks Class Initialized
DEBUG - 2021-07-15 17:43:46 --> UTF-8 Support Enabled
INFO - 2021-07-15 17:43:46 --> Utf8 Class Initialized
INFO - 2021-07-15 17:43:46 --> URI Class Initialized
INFO - 2021-07-15 17:43:46 --> Router Class Initialized
INFO - 2021-07-15 17:43:46 --> Output Class Initialized
INFO - 2021-07-15 17:43:46 --> Security Class Initialized
DEBUG - 2021-07-15 17:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 17:43:46 --> Input Class Initialized
INFO - 2021-07-15 17:43:46 --> Language Class Initialized
ERROR - 2021-07-15 17:43:46 --> 404 Page Not Found: Faviconico/index
INFO - 2021-07-15 17:45:41 --> Config Class Initialized
INFO - 2021-07-15 17:45:41 --> Hooks Class Initialized
DEBUG - 2021-07-15 17:45:41 --> UTF-8 Support Enabled
INFO - 2021-07-15 17:45:41 --> Utf8 Class Initialized
INFO - 2021-07-15 17:45:41 --> URI Class Initialized
INFO - 2021-07-15 17:45:41 --> Router Class Initialized
INFO - 2021-07-15 17:45:41 --> Output Class Initialized
INFO - 2021-07-15 17:45:41 --> Security Class Initialized
DEBUG - 2021-07-15 17:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 17:45:41 --> Input Class Initialized
INFO - 2021-07-15 17:45:41 --> Language Class Initialized
INFO - 2021-07-15 17:45:41 --> Loader Class Initialized
INFO - 2021-07-15 17:45:41 --> Helper loaded: basic_helper
INFO - 2021-07-15 17:45:41 --> Helper loaded: url_helper
INFO - 2021-07-15 17:45:41 --> Helper loaded: file_helper
INFO - 2021-07-15 17:45:41 --> Helper loaded: form_helper
INFO - 2021-07-15 17:45:41 --> Helper loaded: cookie_helper
INFO - 2021-07-15 17:45:41 --> Helper loaded: security_helper
INFO - 2021-07-15 17:45:41 --> Helper loaded: directory_helper
INFO - 2021-07-15 17:45:41 --> Helper loaded: language_helper
INFO - 2021-07-15 17:45:41 --> Helper loaded: general_helper
INFO - 2021-07-15 17:45:41 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 17:45:41 --> Database Driver Class Initialized
DEBUG - 2021-07-15 17:45:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 17:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 17:45:41 --> Parser Class Initialized
INFO - 2021-07-15 17:45:41 --> Form Validation Class Initialized
INFO - 2021-07-15 17:45:41 --> Upload Class Initialized
INFO - 2021-07-15 17:45:41 --> Email Class Initialized
INFO - 2021-07-15 17:45:41 --> MY_Model class loaded
INFO - 2021-07-15 17:45:41 --> Model "Users_model" initialized
INFO - 2021-07-15 17:45:41 --> Model "Settings_model" initialized
INFO - 2021-07-15 17:45:41 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 17:45:41 --> Model "Permissions_model" initialized
INFO - 2021-07-15 17:45:41 --> Model "Roles_model" initialized
INFO - 2021-07-15 17:45:41 --> Model "Activity_model" initialized
INFO - 2021-07-15 17:45:41 --> Model "Templates_model" initialized
INFO - 2021-07-15 17:45:41 --> Database Driver Class Initialized
INFO - 2021-07-15 17:45:41 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 17:45:41 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 17:45:41 --> Controller Class Initialized
ERROR - 2021-07-15 17:45:41 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 17:45:41 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 17:45:41 --> Final output sent to browser
DEBUG - 2021-07-15 17:45:41 --> Total execution time: 0.5739
INFO - 2021-07-15 17:46:12 --> Config Class Initialized
INFO - 2021-07-15 17:46:12 --> Hooks Class Initialized
DEBUG - 2021-07-15 17:46:12 --> UTF-8 Support Enabled
INFO - 2021-07-15 17:46:12 --> Utf8 Class Initialized
INFO - 2021-07-15 17:46:12 --> URI Class Initialized
INFO - 2021-07-15 17:46:12 --> Router Class Initialized
INFO - 2021-07-15 17:46:12 --> Output Class Initialized
INFO - 2021-07-15 17:46:12 --> Security Class Initialized
DEBUG - 2021-07-15 17:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 17:46:12 --> Input Class Initialized
INFO - 2021-07-15 17:46:12 --> Language Class Initialized
INFO - 2021-07-15 17:46:12 --> Loader Class Initialized
INFO - 2021-07-15 17:46:12 --> Helper loaded: basic_helper
INFO - 2021-07-15 17:46:12 --> Helper loaded: url_helper
INFO - 2021-07-15 17:46:12 --> Helper loaded: file_helper
INFO - 2021-07-15 17:46:12 --> Helper loaded: form_helper
INFO - 2021-07-15 17:46:12 --> Helper loaded: cookie_helper
INFO - 2021-07-15 17:46:12 --> Helper loaded: security_helper
INFO - 2021-07-15 17:46:12 --> Helper loaded: directory_helper
INFO - 2021-07-15 17:46:12 --> Helper loaded: language_helper
INFO - 2021-07-15 17:46:12 --> Helper loaded: general_helper
INFO - 2021-07-15 17:46:12 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 17:46:12 --> Database Driver Class Initialized
DEBUG - 2021-07-15 17:46:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 17:46:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 17:46:12 --> Parser Class Initialized
INFO - 2021-07-15 17:46:12 --> Form Validation Class Initialized
INFO - 2021-07-15 17:46:12 --> Upload Class Initialized
INFO - 2021-07-15 17:46:12 --> Email Class Initialized
INFO - 2021-07-15 17:46:12 --> MY_Model class loaded
INFO - 2021-07-15 17:46:12 --> Model "Users_model" initialized
INFO - 2021-07-15 17:46:12 --> Model "Settings_model" initialized
INFO - 2021-07-15 17:46:12 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 17:46:12 --> Model "Permissions_model" initialized
INFO - 2021-07-15 17:46:12 --> Model "Roles_model" initialized
INFO - 2021-07-15 17:46:12 --> Model "Activity_model" initialized
INFO - 2021-07-15 17:46:12 --> Model "Templates_model" initialized
INFO - 2021-07-15 17:46:12 --> Database Driver Class Initialized
INFO - 2021-07-15 17:46:12 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 17:46:12 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 17:46:12 --> Controller Class Initialized
ERROR - 2021-07-15 17:46:12 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 17:46:12 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 17:46:12 --> Final output sent to browser
DEBUG - 2021-07-15 17:46:12 --> Total execution time: 0.1471
INFO - 2021-07-15 17:46:39 --> Config Class Initialized
INFO - 2021-07-15 17:46:39 --> Hooks Class Initialized
DEBUG - 2021-07-15 17:46:39 --> UTF-8 Support Enabled
INFO - 2021-07-15 17:46:39 --> Utf8 Class Initialized
INFO - 2021-07-15 17:46:39 --> URI Class Initialized
INFO - 2021-07-15 17:46:39 --> Router Class Initialized
INFO - 2021-07-15 17:46:39 --> Output Class Initialized
INFO - 2021-07-15 17:46:39 --> Security Class Initialized
DEBUG - 2021-07-15 17:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 17:46:39 --> Input Class Initialized
INFO - 2021-07-15 17:46:39 --> Language Class Initialized
INFO - 2021-07-15 17:46:39 --> Loader Class Initialized
INFO - 2021-07-15 17:46:39 --> Helper loaded: basic_helper
INFO - 2021-07-15 17:46:39 --> Helper loaded: url_helper
INFO - 2021-07-15 17:46:39 --> Helper loaded: file_helper
INFO - 2021-07-15 17:46:39 --> Helper loaded: form_helper
INFO - 2021-07-15 17:46:39 --> Helper loaded: cookie_helper
INFO - 2021-07-15 17:46:39 --> Helper loaded: security_helper
INFO - 2021-07-15 17:46:39 --> Helper loaded: directory_helper
INFO - 2021-07-15 17:46:39 --> Helper loaded: language_helper
INFO - 2021-07-15 17:46:39 --> Helper loaded: general_helper
INFO - 2021-07-15 17:46:39 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 17:46:39 --> Database Driver Class Initialized
DEBUG - 2021-07-15 17:46:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 17:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 17:46:39 --> Parser Class Initialized
INFO - 2021-07-15 17:46:39 --> Form Validation Class Initialized
INFO - 2021-07-15 17:46:39 --> Upload Class Initialized
INFO - 2021-07-15 17:46:39 --> Email Class Initialized
INFO - 2021-07-15 17:46:39 --> MY_Model class loaded
INFO - 2021-07-15 17:46:39 --> Model "Users_model" initialized
INFO - 2021-07-15 17:46:39 --> Model "Settings_model" initialized
INFO - 2021-07-15 17:46:39 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 17:46:39 --> Model "Permissions_model" initialized
INFO - 2021-07-15 17:46:39 --> Model "Roles_model" initialized
INFO - 2021-07-15 17:46:39 --> Model "Activity_model" initialized
INFO - 2021-07-15 17:46:39 --> Model "Templates_model" initialized
INFO - 2021-07-15 17:46:39 --> Database Driver Class Initialized
INFO - 2021-07-15 17:46:39 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 17:46:39 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 17:46:39 --> Controller Class Initialized
ERROR - 2021-07-15 17:46:39 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 17:46:39 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 17:46:39 --> Final output sent to browser
DEBUG - 2021-07-15 17:46:39 --> Total execution time: 0.1401
INFO - 2021-07-15 17:46:39 --> Config Class Initialized
INFO - 2021-07-15 17:46:39 --> Hooks Class Initialized
DEBUG - 2021-07-15 17:46:39 --> UTF-8 Support Enabled
INFO - 2021-07-15 17:46:39 --> Utf8 Class Initialized
INFO - 2021-07-15 17:46:39 --> URI Class Initialized
INFO - 2021-07-15 17:46:39 --> Router Class Initialized
INFO - 2021-07-15 17:46:39 --> Output Class Initialized
INFO - 2021-07-15 17:46:39 --> Security Class Initialized
DEBUG - 2021-07-15 17:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 17:46:39 --> Input Class Initialized
INFO - 2021-07-15 17:46:39 --> Language Class Initialized
ERROR - 2021-07-15 17:46:39 --> 404 Page Not Found: Faviconico/index
INFO - 2021-07-15 17:48:20 --> Config Class Initialized
INFO - 2021-07-15 17:48:20 --> Hooks Class Initialized
DEBUG - 2021-07-15 17:48:20 --> UTF-8 Support Enabled
INFO - 2021-07-15 17:48:20 --> Utf8 Class Initialized
INFO - 2021-07-15 17:48:20 --> URI Class Initialized
INFO - 2021-07-15 17:48:20 --> Router Class Initialized
INFO - 2021-07-15 17:48:20 --> Output Class Initialized
INFO - 2021-07-15 17:48:20 --> Security Class Initialized
DEBUG - 2021-07-15 17:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 17:48:20 --> Input Class Initialized
INFO - 2021-07-15 17:48:20 --> Language Class Initialized
INFO - 2021-07-15 17:48:20 --> Loader Class Initialized
INFO - 2021-07-15 17:48:20 --> Helper loaded: basic_helper
INFO - 2021-07-15 17:48:20 --> Helper loaded: url_helper
INFO - 2021-07-15 17:48:20 --> Helper loaded: file_helper
INFO - 2021-07-15 17:48:20 --> Helper loaded: form_helper
INFO - 2021-07-15 17:48:20 --> Helper loaded: cookie_helper
INFO - 2021-07-15 17:48:20 --> Helper loaded: security_helper
INFO - 2021-07-15 17:48:20 --> Helper loaded: directory_helper
INFO - 2021-07-15 17:48:20 --> Helper loaded: language_helper
INFO - 2021-07-15 17:48:20 --> Helper loaded: general_helper
INFO - 2021-07-15 17:48:20 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 17:48:20 --> Database Driver Class Initialized
DEBUG - 2021-07-15 17:48:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 17:48:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 17:48:20 --> Parser Class Initialized
INFO - 2021-07-15 17:48:20 --> Form Validation Class Initialized
INFO - 2021-07-15 17:48:20 --> Upload Class Initialized
INFO - 2021-07-15 17:48:20 --> Email Class Initialized
INFO - 2021-07-15 17:48:20 --> MY_Model class loaded
INFO - 2021-07-15 17:48:20 --> Model "Users_model" initialized
INFO - 2021-07-15 17:48:20 --> Model "Settings_model" initialized
INFO - 2021-07-15 17:48:20 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 17:48:20 --> Model "Permissions_model" initialized
INFO - 2021-07-15 17:48:20 --> Model "Roles_model" initialized
INFO - 2021-07-15 17:48:20 --> Model "Activity_model" initialized
INFO - 2021-07-15 17:48:20 --> Model "Templates_model" initialized
INFO - 2021-07-15 17:48:20 --> Database Driver Class Initialized
INFO - 2021-07-15 17:48:20 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 17:48:20 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 17:48:20 --> Controller Class Initialized
ERROR - 2021-07-15 17:48:20 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 17:48:21 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 17:48:21 --> Final output sent to browser
DEBUG - 2021-07-15 17:48:21 --> Total execution time: 0.5557
INFO - 2021-07-15 17:48:21 --> Config Class Initialized
INFO - 2021-07-15 17:48:21 --> Hooks Class Initialized
DEBUG - 2021-07-15 17:48:21 --> UTF-8 Support Enabled
INFO - 2021-07-15 17:48:21 --> Utf8 Class Initialized
INFO - 2021-07-15 17:48:21 --> URI Class Initialized
INFO - 2021-07-15 17:48:21 --> Router Class Initialized
INFO - 2021-07-15 17:48:21 --> Output Class Initialized
INFO - 2021-07-15 17:48:21 --> Security Class Initialized
DEBUG - 2021-07-15 17:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 17:48:21 --> Input Class Initialized
INFO - 2021-07-15 17:48:21 --> Language Class Initialized
ERROR - 2021-07-15 17:48:21 --> 404 Page Not Found: Faviconico/index
INFO - 2021-07-15 17:48:39 --> Config Class Initialized
INFO - 2021-07-15 17:48:39 --> Hooks Class Initialized
DEBUG - 2021-07-15 17:48:39 --> UTF-8 Support Enabled
INFO - 2021-07-15 17:48:39 --> Utf8 Class Initialized
INFO - 2021-07-15 17:48:39 --> URI Class Initialized
INFO - 2021-07-15 17:48:39 --> Router Class Initialized
INFO - 2021-07-15 17:48:39 --> Output Class Initialized
INFO - 2021-07-15 17:48:39 --> Security Class Initialized
DEBUG - 2021-07-15 17:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 17:48:39 --> Input Class Initialized
INFO - 2021-07-15 17:48:39 --> Language Class Initialized
INFO - 2021-07-15 17:48:39 --> Loader Class Initialized
INFO - 2021-07-15 17:48:39 --> Helper loaded: basic_helper
INFO - 2021-07-15 17:48:39 --> Helper loaded: url_helper
INFO - 2021-07-15 17:48:39 --> Helper loaded: file_helper
INFO - 2021-07-15 17:48:39 --> Helper loaded: form_helper
INFO - 2021-07-15 17:48:39 --> Helper loaded: cookie_helper
INFO - 2021-07-15 17:48:39 --> Helper loaded: security_helper
INFO - 2021-07-15 17:48:39 --> Helper loaded: directory_helper
INFO - 2021-07-15 17:48:39 --> Helper loaded: language_helper
INFO - 2021-07-15 17:48:39 --> Helper loaded: general_helper
INFO - 2021-07-15 17:48:39 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 17:48:39 --> Database Driver Class Initialized
DEBUG - 2021-07-15 17:48:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 17:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 17:48:39 --> Parser Class Initialized
INFO - 2021-07-15 17:48:39 --> Form Validation Class Initialized
INFO - 2021-07-15 17:48:39 --> Upload Class Initialized
INFO - 2021-07-15 17:48:39 --> Email Class Initialized
INFO - 2021-07-15 17:48:39 --> MY_Model class loaded
INFO - 2021-07-15 17:48:39 --> Model "Users_model" initialized
INFO - 2021-07-15 17:48:39 --> Model "Settings_model" initialized
INFO - 2021-07-15 17:48:39 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 17:48:39 --> Model "Permissions_model" initialized
INFO - 2021-07-15 17:48:39 --> Model "Roles_model" initialized
INFO - 2021-07-15 17:48:39 --> Model "Activity_model" initialized
INFO - 2021-07-15 17:48:39 --> Model "Templates_model" initialized
INFO - 2021-07-15 17:48:39 --> Database Driver Class Initialized
INFO - 2021-07-15 17:48:39 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 17:48:39 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 17:48:39 --> Controller Class Initialized
ERROR - 2021-07-15 17:48:39 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 17:48:39 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 17:48:39 --> Final output sent to browser
DEBUG - 2021-07-15 17:48:39 --> Total execution time: 0.1432
INFO - 2021-07-15 17:48:39 --> Config Class Initialized
INFO - 2021-07-15 17:48:39 --> Hooks Class Initialized
DEBUG - 2021-07-15 17:48:39 --> UTF-8 Support Enabled
INFO - 2021-07-15 17:48:39 --> Utf8 Class Initialized
INFO - 2021-07-15 17:48:39 --> URI Class Initialized
INFO - 2021-07-15 17:48:39 --> Router Class Initialized
INFO - 2021-07-15 17:48:39 --> Output Class Initialized
INFO - 2021-07-15 17:48:39 --> Security Class Initialized
DEBUG - 2021-07-15 17:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 17:48:39 --> Input Class Initialized
INFO - 2021-07-15 17:48:39 --> Language Class Initialized
INFO - 2021-07-15 17:48:39 --> Loader Class Initialized
INFO - 2021-07-15 17:48:39 --> Helper loaded: basic_helper
INFO - 2021-07-15 17:48:39 --> Helper loaded: url_helper
INFO - 2021-07-15 17:48:39 --> Helper loaded: file_helper
INFO - 2021-07-15 17:48:39 --> Helper loaded: form_helper
INFO - 2021-07-15 17:48:39 --> Helper loaded: cookie_helper
INFO - 2021-07-15 17:48:39 --> Helper loaded: security_helper
INFO - 2021-07-15 17:48:39 --> Helper loaded: directory_helper
INFO - 2021-07-15 17:48:39 --> Helper loaded: language_helper
INFO - 2021-07-15 17:48:39 --> Helper loaded: general_helper
INFO - 2021-07-15 17:48:39 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 17:48:39 --> Database Driver Class Initialized
DEBUG - 2021-07-15 17:48:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 17:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 17:48:39 --> Parser Class Initialized
INFO - 2021-07-15 17:48:39 --> Form Validation Class Initialized
INFO - 2021-07-15 17:48:39 --> Upload Class Initialized
INFO - 2021-07-15 17:48:39 --> Email Class Initialized
INFO - 2021-07-15 17:48:39 --> MY_Model class loaded
INFO - 2021-07-15 17:48:39 --> Model "Users_model" initialized
INFO - 2021-07-15 17:48:39 --> Model "Settings_model" initialized
INFO - 2021-07-15 17:48:39 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 17:48:39 --> Model "Permissions_model" initialized
INFO - 2021-07-15 17:48:39 --> Model "Roles_model" initialized
INFO - 2021-07-15 17:48:39 --> Model "Activity_model" initialized
INFO - 2021-07-15 17:48:39 --> Model "Templates_model" initialized
INFO - 2021-07-15 17:48:39 --> Database Driver Class Initialized
INFO - 2021-07-15 17:48:39 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 17:48:39 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 17:48:39 --> Controller Class Initialized
ERROR - 2021-07-15 17:48:39 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 17:48:39 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 17:48:39 --> Final output sent to browser
DEBUG - 2021-07-15 17:48:39 --> Total execution time: 0.0646
INFO - 2021-07-15 17:48:39 --> Config Class Initialized
INFO - 2021-07-15 17:48:39 --> Hooks Class Initialized
DEBUG - 2021-07-15 17:48:39 --> UTF-8 Support Enabled
INFO - 2021-07-15 17:48:39 --> Utf8 Class Initialized
INFO - 2021-07-15 17:48:39 --> URI Class Initialized
INFO - 2021-07-15 17:48:39 --> Router Class Initialized
INFO - 2021-07-15 17:48:39 --> Output Class Initialized
INFO - 2021-07-15 17:48:39 --> Security Class Initialized
DEBUG - 2021-07-15 17:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 17:48:39 --> Input Class Initialized
INFO - 2021-07-15 17:48:39 --> Language Class Initialized
INFO - 2021-07-15 17:48:39 --> Loader Class Initialized
INFO - 2021-07-15 17:48:39 --> Helper loaded: basic_helper
INFO - 2021-07-15 17:48:39 --> Helper loaded: url_helper
INFO - 2021-07-15 17:48:39 --> Helper loaded: file_helper
INFO - 2021-07-15 17:48:39 --> Helper loaded: form_helper
INFO - 2021-07-15 17:48:39 --> Helper loaded: cookie_helper
INFO - 2021-07-15 17:48:39 --> Helper loaded: security_helper
INFO - 2021-07-15 17:48:39 --> Helper loaded: directory_helper
INFO - 2021-07-15 17:48:39 --> Helper loaded: language_helper
INFO - 2021-07-15 17:48:39 --> Helper loaded: general_helper
INFO - 2021-07-15 17:48:39 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 17:48:39 --> Database Driver Class Initialized
DEBUG - 2021-07-15 17:48:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 17:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 17:48:39 --> Parser Class Initialized
INFO - 2021-07-15 17:48:39 --> Form Validation Class Initialized
INFO - 2021-07-15 17:48:39 --> Upload Class Initialized
INFO - 2021-07-15 17:48:39 --> Email Class Initialized
INFO - 2021-07-15 17:48:39 --> MY_Model class loaded
INFO - 2021-07-15 17:48:39 --> Model "Users_model" initialized
INFO - 2021-07-15 17:48:39 --> Model "Settings_model" initialized
INFO - 2021-07-15 17:48:39 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 17:48:39 --> Model "Permissions_model" initialized
INFO - 2021-07-15 17:48:39 --> Model "Roles_model" initialized
INFO - 2021-07-15 17:48:39 --> Model "Activity_model" initialized
INFO - 2021-07-15 17:48:39 --> Model "Templates_model" initialized
INFO - 2021-07-15 17:48:39 --> Database Driver Class Initialized
INFO - 2021-07-15 17:48:39 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 17:48:39 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 17:48:39 --> Controller Class Initialized
ERROR - 2021-07-15 17:48:39 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 17:48:39 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 17:48:39 --> Final output sent to browser
DEBUG - 2021-07-15 17:48:39 --> Total execution time: 0.0604
INFO - 2021-07-15 17:48:39 --> Config Class Initialized
INFO - 2021-07-15 17:48:39 --> Hooks Class Initialized
DEBUG - 2021-07-15 17:48:39 --> UTF-8 Support Enabled
INFO - 2021-07-15 17:48:39 --> Utf8 Class Initialized
INFO - 2021-07-15 17:48:39 --> URI Class Initialized
INFO - 2021-07-15 17:48:39 --> Router Class Initialized
INFO - 2021-07-15 17:48:39 --> Output Class Initialized
INFO - 2021-07-15 17:48:39 --> Security Class Initialized
DEBUG - 2021-07-15 17:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 17:48:39 --> Input Class Initialized
INFO - 2021-07-15 17:48:39 --> Language Class Initialized
ERROR - 2021-07-15 17:48:39 --> 404 Page Not Found: Faviconico/index
INFO - 2021-07-15 17:48:40 --> Config Class Initialized
INFO - 2021-07-15 17:48:40 --> Hooks Class Initialized
DEBUG - 2021-07-15 17:48:40 --> UTF-8 Support Enabled
INFO - 2021-07-15 17:48:40 --> Utf8 Class Initialized
INFO - 2021-07-15 17:48:40 --> URI Class Initialized
INFO - 2021-07-15 17:48:40 --> Router Class Initialized
INFO - 2021-07-15 17:48:40 --> Output Class Initialized
INFO - 2021-07-15 17:48:40 --> Security Class Initialized
DEBUG - 2021-07-15 17:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 17:48:40 --> Input Class Initialized
INFO - 2021-07-15 17:48:40 --> Language Class Initialized
INFO - 2021-07-15 17:48:40 --> Loader Class Initialized
INFO - 2021-07-15 17:48:40 --> Helper loaded: basic_helper
INFO - 2021-07-15 17:48:40 --> Helper loaded: url_helper
INFO - 2021-07-15 17:48:40 --> Helper loaded: file_helper
INFO - 2021-07-15 17:48:40 --> Helper loaded: form_helper
INFO - 2021-07-15 17:48:40 --> Helper loaded: cookie_helper
INFO - 2021-07-15 17:48:40 --> Helper loaded: security_helper
INFO - 2021-07-15 17:48:40 --> Helper loaded: directory_helper
INFO - 2021-07-15 17:48:40 --> Helper loaded: language_helper
INFO - 2021-07-15 17:48:40 --> Helper loaded: general_helper
INFO - 2021-07-15 17:48:40 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 17:48:40 --> Database Driver Class Initialized
DEBUG - 2021-07-15 17:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 17:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 17:48:40 --> Parser Class Initialized
INFO - 2021-07-15 17:48:40 --> Form Validation Class Initialized
INFO - 2021-07-15 17:48:40 --> Upload Class Initialized
INFO - 2021-07-15 17:48:40 --> Email Class Initialized
INFO - 2021-07-15 17:48:40 --> MY_Model class loaded
INFO - 2021-07-15 17:48:40 --> Model "Users_model" initialized
INFO - 2021-07-15 17:48:40 --> Model "Settings_model" initialized
INFO - 2021-07-15 17:48:40 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 17:48:40 --> Model "Permissions_model" initialized
INFO - 2021-07-15 17:48:40 --> Model "Roles_model" initialized
INFO - 2021-07-15 17:48:40 --> Model "Activity_model" initialized
INFO - 2021-07-15 17:48:40 --> Model "Templates_model" initialized
INFO - 2021-07-15 17:48:40 --> Database Driver Class Initialized
INFO - 2021-07-15 17:48:40 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 17:48:40 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 17:48:40 --> Controller Class Initialized
ERROR - 2021-07-15 17:48:40 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 17:48:40 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 17:48:40 --> Final output sent to browser
DEBUG - 2021-07-15 17:48:40 --> Total execution time: 0.0597
INFO - 2021-07-15 17:48:41 --> Config Class Initialized
INFO - 2021-07-15 17:48:41 --> Hooks Class Initialized
DEBUG - 2021-07-15 17:48:41 --> UTF-8 Support Enabled
INFO - 2021-07-15 17:48:41 --> Utf8 Class Initialized
INFO - 2021-07-15 17:48:41 --> URI Class Initialized
INFO - 2021-07-15 17:48:41 --> Router Class Initialized
INFO - 2021-07-15 17:48:41 --> Output Class Initialized
INFO - 2021-07-15 17:48:41 --> Security Class Initialized
DEBUG - 2021-07-15 17:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 17:48:41 --> Input Class Initialized
INFO - 2021-07-15 17:48:41 --> Language Class Initialized
ERROR - 2021-07-15 17:48:41 --> 404 Page Not Found: Faviconico/index
INFO - 2021-07-15 17:48:41 --> Config Class Initialized
INFO - 2021-07-15 17:48:41 --> Hooks Class Initialized
DEBUG - 2021-07-15 17:48:41 --> UTF-8 Support Enabled
INFO - 2021-07-15 17:48:41 --> Utf8 Class Initialized
INFO - 2021-07-15 17:48:41 --> URI Class Initialized
INFO - 2021-07-15 17:48:41 --> Router Class Initialized
INFO - 2021-07-15 17:48:41 --> Output Class Initialized
INFO - 2021-07-15 17:48:41 --> Security Class Initialized
DEBUG - 2021-07-15 17:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 17:48:41 --> Input Class Initialized
INFO - 2021-07-15 17:48:41 --> Language Class Initialized
INFO - 2021-07-15 17:48:41 --> Loader Class Initialized
INFO - 2021-07-15 17:48:41 --> Helper loaded: basic_helper
INFO - 2021-07-15 17:48:41 --> Helper loaded: url_helper
INFO - 2021-07-15 17:48:41 --> Helper loaded: file_helper
INFO - 2021-07-15 17:48:41 --> Helper loaded: form_helper
INFO - 2021-07-15 17:48:41 --> Helper loaded: cookie_helper
INFO - 2021-07-15 17:48:41 --> Helper loaded: security_helper
INFO - 2021-07-15 17:48:41 --> Helper loaded: directory_helper
INFO - 2021-07-15 17:48:41 --> Helper loaded: language_helper
INFO - 2021-07-15 17:48:41 --> Helper loaded: general_helper
INFO - 2021-07-15 17:48:41 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 17:48:41 --> Database Driver Class Initialized
DEBUG - 2021-07-15 17:48:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 17:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 17:48:41 --> Parser Class Initialized
INFO - 2021-07-15 17:48:41 --> Form Validation Class Initialized
INFO - 2021-07-15 17:48:41 --> Upload Class Initialized
INFO - 2021-07-15 17:48:41 --> Email Class Initialized
INFO - 2021-07-15 17:48:41 --> MY_Model class loaded
INFO - 2021-07-15 17:48:41 --> Model "Users_model" initialized
INFO - 2021-07-15 17:48:41 --> Model "Settings_model" initialized
INFO - 2021-07-15 17:48:41 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 17:48:41 --> Model "Permissions_model" initialized
INFO - 2021-07-15 17:48:41 --> Model "Roles_model" initialized
INFO - 2021-07-15 17:48:41 --> Model "Activity_model" initialized
INFO - 2021-07-15 17:48:41 --> Model "Templates_model" initialized
INFO - 2021-07-15 17:48:41 --> Database Driver Class Initialized
INFO - 2021-07-15 17:48:41 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 17:48:41 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 17:48:41 --> Controller Class Initialized
ERROR - 2021-07-15 17:48:41 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 17:48:41 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 17:48:41 --> Final output sent to browser
DEBUG - 2021-07-15 17:48:41 --> Total execution time: 0.0620
INFO - 2021-07-15 17:48:42 --> Config Class Initialized
INFO - 2021-07-15 17:48:42 --> Hooks Class Initialized
DEBUG - 2021-07-15 17:48:42 --> UTF-8 Support Enabled
INFO - 2021-07-15 17:48:42 --> Utf8 Class Initialized
INFO - 2021-07-15 17:48:42 --> URI Class Initialized
INFO - 2021-07-15 17:48:42 --> Router Class Initialized
INFO - 2021-07-15 17:48:42 --> Output Class Initialized
INFO - 2021-07-15 17:48:42 --> Security Class Initialized
DEBUG - 2021-07-15 17:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 17:48:42 --> Input Class Initialized
INFO - 2021-07-15 17:48:42 --> Language Class Initialized
ERROR - 2021-07-15 17:48:42 --> 404 Page Not Found: Faviconico/index
INFO - 2021-07-15 17:49:27 --> Config Class Initialized
INFO - 2021-07-15 17:49:27 --> Hooks Class Initialized
DEBUG - 2021-07-15 17:49:27 --> UTF-8 Support Enabled
INFO - 2021-07-15 17:49:27 --> Utf8 Class Initialized
INFO - 2021-07-15 17:49:27 --> URI Class Initialized
INFO - 2021-07-15 17:49:27 --> Router Class Initialized
INFO - 2021-07-15 17:49:27 --> Output Class Initialized
INFO - 2021-07-15 17:49:27 --> Security Class Initialized
DEBUG - 2021-07-15 17:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 17:49:27 --> Input Class Initialized
INFO - 2021-07-15 17:49:27 --> Language Class Initialized
INFO - 2021-07-15 17:49:27 --> Loader Class Initialized
INFO - 2021-07-15 17:49:27 --> Helper loaded: basic_helper
INFO - 2021-07-15 17:49:27 --> Helper loaded: url_helper
INFO - 2021-07-15 17:49:27 --> Helper loaded: file_helper
INFO - 2021-07-15 17:49:27 --> Helper loaded: form_helper
INFO - 2021-07-15 17:49:27 --> Helper loaded: cookie_helper
INFO - 2021-07-15 17:49:27 --> Helper loaded: security_helper
INFO - 2021-07-15 17:49:27 --> Helper loaded: directory_helper
INFO - 2021-07-15 17:49:27 --> Helper loaded: language_helper
INFO - 2021-07-15 17:49:27 --> Helper loaded: general_helper
INFO - 2021-07-15 17:49:27 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 17:49:27 --> Database Driver Class Initialized
DEBUG - 2021-07-15 17:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 17:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 17:49:27 --> Parser Class Initialized
INFO - 2021-07-15 17:49:27 --> Form Validation Class Initialized
INFO - 2021-07-15 17:49:27 --> Upload Class Initialized
INFO - 2021-07-15 17:49:27 --> Email Class Initialized
INFO - 2021-07-15 17:49:27 --> MY_Model class loaded
INFO - 2021-07-15 17:49:27 --> Model "Users_model" initialized
INFO - 2021-07-15 17:49:27 --> Model "Settings_model" initialized
INFO - 2021-07-15 17:49:27 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 17:49:27 --> Model "Permissions_model" initialized
INFO - 2021-07-15 17:49:27 --> Model "Roles_model" initialized
INFO - 2021-07-15 17:49:27 --> Model "Activity_model" initialized
INFO - 2021-07-15 17:49:27 --> Model "Templates_model" initialized
INFO - 2021-07-15 17:49:27 --> Database Driver Class Initialized
INFO - 2021-07-15 17:49:28 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 17:49:28 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 17:49:28 --> Controller Class Initialized
ERROR - 2021-07-15 17:49:28 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 17:49:28 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 17:49:28 --> Final output sent to browser
DEBUG - 2021-07-15 17:49:28 --> Total execution time: 0.1437
INFO - 2021-07-15 17:49:44 --> Config Class Initialized
INFO - 2021-07-15 17:49:44 --> Hooks Class Initialized
DEBUG - 2021-07-15 17:49:44 --> UTF-8 Support Enabled
INFO - 2021-07-15 17:49:44 --> Utf8 Class Initialized
INFO - 2021-07-15 17:49:44 --> URI Class Initialized
INFO - 2021-07-15 17:49:44 --> Router Class Initialized
INFO - 2021-07-15 17:49:44 --> Output Class Initialized
INFO - 2021-07-15 17:49:44 --> Security Class Initialized
DEBUG - 2021-07-15 17:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 17:49:44 --> Input Class Initialized
INFO - 2021-07-15 17:49:44 --> Language Class Initialized
INFO - 2021-07-15 17:49:44 --> Loader Class Initialized
INFO - 2021-07-15 17:49:44 --> Helper loaded: basic_helper
INFO - 2021-07-15 17:49:44 --> Helper loaded: url_helper
INFO - 2021-07-15 17:49:44 --> Helper loaded: file_helper
INFO - 2021-07-15 17:49:44 --> Helper loaded: form_helper
INFO - 2021-07-15 17:49:44 --> Helper loaded: cookie_helper
INFO - 2021-07-15 17:49:44 --> Helper loaded: security_helper
INFO - 2021-07-15 17:49:44 --> Helper loaded: directory_helper
INFO - 2021-07-15 17:49:44 --> Helper loaded: language_helper
INFO - 2021-07-15 17:49:44 --> Helper loaded: general_helper
INFO - 2021-07-15 17:49:44 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 17:49:44 --> Database Driver Class Initialized
DEBUG - 2021-07-15 17:49:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 17:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 17:49:44 --> Parser Class Initialized
INFO - 2021-07-15 17:49:44 --> Form Validation Class Initialized
INFO - 2021-07-15 17:49:44 --> Upload Class Initialized
INFO - 2021-07-15 17:49:44 --> Email Class Initialized
INFO - 2021-07-15 17:49:44 --> MY_Model class loaded
INFO - 2021-07-15 17:49:44 --> Model "Users_model" initialized
INFO - 2021-07-15 17:49:44 --> Model "Settings_model" initialized
INFO - 2021-07-15 17:49:44 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 17:49:44 --> Model "Permissions_model" initialized
INFO - 2021-07-15 17:49:44 --> Model "Roles_model" initialized
INFO - 2021-07-15 17:49:44 --> Model "Activity_model" initialized
INFO - 2021-07-15 17:49:44 --> Model "Templates_model" initialized
INFO - 2021-07-15 17:49:44 --> Database Driver Class Initialized
INFO - 2021-07-15 17:49:44 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 17:49:44 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 17:49:44 --> Controller Class Initialized
ERROR - 2021-07-15 17:49:44 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-15 17:49:44 --> Severity: error --> Exception: Call to undefined method Car_activity_model::list() C:\wamp64\www\crm\application\views\car\car_list.php 42
INFO - 2021-07-15 17:49:50 --> Config Class Initialized
INFO - 2021-07-15 17:49:50 --> Hooks Class Initialized
DEBUG - 2021-07-15 17:49:50 --> UTF-8 Support Enabled
INFO - 2021-07-15 17:49:50 --> Utf8 Class Initialized
INFO - 2021-07-15 17:49:50 --> URI Class Initialized
INFO - 2021-07-15 17:49:50 --> Router Class Initialized
INFO - 2021-07-15 17:49:50 --> Output Class Initialized
INFO - 2021-07-15 17:49:50 --> Security Class Initialized
DEBUG - 2021-07-15 17:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 17:49:50 --> Input Class Initialized
INFO - 2021-07-15 17:49:50 --> Language Class Initialized
INFO - 2021-07-15 17:49:50 --> Loader Class Initialized
INFO - 2021-07-15 17:49:50 --> Helper loaded: basic_helper
INFO - 2021-07-15 17:49:50 --> Helper loaded: url_helper
INFO - 2021-07-15 17:49:50 --> Helper loaded: file_helper
INFO - 2021-07-15 17:49:50 --> Helper loaded: form_helper
INFO - 2021-07-15 17:49:50 --> Helper loaded: cookie_helper
INFO - 2021-07-15 17:49:50 --> Helper loaded: security_helper
INFO - 2021-07-15 17:49:50 --> Helper loaded: directory_helper
INFO - 2021-07-15 17:49:50 --> Helper loaded: language_helper
INFO - 2021-07-15 17:49:50 --> Helper loaded: general_helper
INFO - 2021-07-15 17:49:50 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 17:49:50 --> Database Driver Class Initialized
DEBUG - 2021-07-15 17:49:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 17:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 17:49:50 --> Parser Class Initialized
INFO - 2021-07-15 17:49:50 --> Form Validation Class Initialized
INFO - 2021-07-15 17:49:50 --> Upload Class Initialized
INFO - 2021-07-15 17:49:50 --> Email Class Initialized
INFO - 2021-07-15 17:49:50 --> MY_Model class loaded
INFO - 2021-07-15 17:49:50 --> Model "Users_model" initialized
INFO - 2021-07-15 17:49:50 --> Model "Settings_model" initialized
INFO - 2021-07-15 17:49:50 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 17:49:50 --> Model "Permissions_model" initialized
INFO - 2021-07-15 17:49:50 --> Model "Roles_model" initialized
INFO - 2021-07-15 17:49:50 --> Model "Activity_model" initialized
INFO - 2021-07-15 17:49:50 --> Model "Templates_model" initialized
INFO - 2021-07-15 17:49:50 --> Database Driver Class Initialized
INFO - 2021-07-15 17:49:50 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 17:49:50 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 17:49:50 --> Controller Class Initialized
ERROR - 2021-07-15 17:49:50 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-15 17:49:50 --> Severity: error --> Exception: Call to undefined method Car_activity_model::list() C:\wamp64\www\crm\application\views\car\car_list.php 42
INFO - 2021-07-15 17:49:50 --> Config Class Initialized
INFO - 2021-07-15 17:49:50 --> Hooks Class Initialized
DEBUG - 2021-07-15 17:49:50 --> UTF-8 Support Enabled
INFO - 2021-07-15 17:49:50 --> Utf8 Class Initialized
INFO - 2021-07-15 17:49:50 --> URI Class Initialized
INFO - 2021-07-15 17:49:50 --> Router Class Initialized
INFO - 2021-07-15 17:49:50 --> Output Class Initialized
INFO - 2021-07-15 17:49:50 --> Security Class Initialized
DEBUG - 2021-07-15 17:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 17:49:50 --> Input Class Initialized
INFO - 2021-07-15 17:49:50 --> Language Class Initialized
ERROR - 2021-07-15 17:49:50 --> 404 Page Not Found: Faviconico/index
INFO - 2021-07-15 17:49:54 --> Config Class Initialized
INFO - 2021-07-15 17:49:54 --> Hooks Class Initialized
DEBUG - 2021-07-15 17:49:54 --> UTF-8 Support Enabled
INFO - 2021-07-15 17:49:54 --> Utf8 Class Initialized
INFO - 2021-07-15 17:49:54 --> URI Class Initialized
INFO - 2021-07-15 17:49:54 --> Router Class Initialized
INFO - 2021-07-15 17:49:54 --> Output Class Initialized
INFO - 2021-07-15 17:49:54 --> Security Class Initialized
DEBUG - 2021-07-15 17:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 17:49:54 --> Input Class Initialized
INFO - 2021-07-15 17:49:54 --> Language Class Initialized
INFO - 2021-07-15 17:49:54 --> Loader Class Initialized
INFO - 2021-07-15 17:49:54 --> Helper loaded: basic_helper
INFO - 2021-07-15 17:49:54 --> Helper loaded: url_helper
INFO - 2021-07-15 17:49:54 --> Helper loaded: file_helper
INFO - 2021-07-15 17:49:54 --> Helper loaded: form_helper
INFO - 2021-07-15 17:49:54 --> Helper loaded: cookie_helper
INFO - 2021-07-15 17:49:54 --> Helper loaded: security_helper
INFO - 2021-07-15 17:49:54 --> Helper loaded: directory_helper
INFO - 2021-07-15 17:49:54 --> Helper loaded: language_helper
INFO - 2021-07-15 17:49:54 --> Helper loaded: general_helper
INFO - 2021-07-15 17:49:54 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 17:49:54 --> Database Driver Class Initialized
DEBUG - 2021-07-15 17:49:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 17:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 17:49:54 --> Parser Class Initialized
INFO - 2021-07-15 17:49:54 --> Form Validation Class Initialized
INFO - 2021-07-15 17:49:54 --> Upload Class Initialized
INFO - 2021-07-15 17:49:54 --> Email Class Initialized
INFO - 2021-07-15 17:49:54 --> MY_Model class loaded
INFO - 2021-07-15 17:49:54 --> Model "Users_model" initialized
INFO - 2021-07-15 17:49:54 --> Model "Settings_model" initialized
INFO - 2021-07-15 17:49:54 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 17:49:54 --> Model "Permissions_model" initialized
INFO - 2021-07-15 17:49:54 --> Model "Roles_model" initialized
INFO - 2021-07-15 17:49:54 --> Model "Activity_model" initialized
INFO - 2021-07-15 17:49:54 --> Model "Templates_model" initialized
INFO - 2021-07-15 17:49:54 --> Database Driver Class Initialized
INFO - 2021-07-15 17:49:54 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 17:49:54 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 17:49:54 --> Controller Class Initialized
ERROR - 2021-07-15 17:49:54 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 17:49:54 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 17:49:54 --> Final output sent to browser
DEBUG - 2021-07-15 17:49:54 --> Total execution time: 0.1398
INFO - 2021-07-15 17:50:02 --> Config Class Initialized
INFO - 2021-07-15 17:50:02 --> Hooks Class Initialized
DEBUG - 2021-07-15 17:50:02 --> UTF-8 Support Enabled
INFO - 2021-07-15 17:50:02 --> Utf8 Class Initialized
INFO - 2021-07-15 17:50:02 --> URI Class Initialized
INFO - 2021-07-15 17:50:02 --> Router Class Initialized
INFO - 2021-07-15 17:50:02 --> Output Class Initialized
INFO - 2021-07-15 17:50:02 --> Security Class Initialized
DEBUG - 2021-07-15 17:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 17:50:02 --> Input Class Initialized
INFO - 2021-07-15 17:50:02 --> Language Class Initialized
INFO - 2021-07-15 17:50:02 --> Loader Class Initialized
INFO - 2021-07-15 17:50:02 --> Helper loaded: basic_helper
INFO - 2021-07-15 17:50:02 --> Helper loaded: url_helper
INFO - 2021-07-15 17:50:02 --> Helper loaded: file_helper
INFO - 2021-07-15 17:50:02 --> Helper loaded: form_helper
INFO - 2021-07-15 17:50:02 --> Helper loaded: cookie_helper
INFO - 2021-07-15 17:50:02 --> Helper loaded: security_helper
INFO - 2021-07-15 17:50:02 --> Helper loaded: directory_helper
INFO - 2021-07-15 17:50:02 --> Helper loaded: language_helper
INFO - 2021-07-15 17:50:02 --> Helper loaded: general_helper
INFO - 2021-07-15 17:50:02 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 17:50:02 --> Database Driver Class Initialized
DEBUG - 2021-07-15 17:50:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 17:50:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 17:50:02 --> Parser Class Initialized
INFO - 2021-07-15 17:50:02 --> Form Validation Class Initialized
INFO - 2021-07-15 17:50:02 --> Upload Class Initialized
INFO - 2021-07-15 17:50:02 --> Email Class Initialized
INFO - 2021-07-15 17:50:02 --> MY_Model class loaded
INFO - 2021-07-15 17:50:02 --> Model "Users_model" initialized
INFO - 2021-07-15 17:50:02 --> Model "Settings_model" initialized
INFO - 2021-07-15 17:50:02 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 17:50:02 --> Model "Permissions_model" initialized
INFO - 2021-07-15 17:50:02 --> Model "Roles_model" initialized
INFO - 2021-07-15 17:50:02 --> Model "Activity_model" initialized
INFO - 2021-07-15 17:50:02 --> Model "Templates_model" initialized
INFO - 2021-07-15 17:50:02 --> Database Driver Class Initialized
INFO - 2021-07-15 17:50:02 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 17:50:02 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 17:50:02 --> Controller Class Initialized
ERROR - 2021-07-15 17:50:02 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 17:50:02 --> File loaded: C:\wamp64\www\crm\application\views\roles/list.php
INFO - 2021-07-15 17:50:02 --> Final output sent to browser
DEBUG - 2021-07-15 17:50:02 --> Total execution time: 0.1515
INFO - 2021-07-15 17:50:03 --> Config Class Initialized
INFO - 2021-07-15 17:50:03 --> Hooks Class Initialized
DEBUG - 2021-07-15 17:50:03 --> UTF-8 Support Enabled
INFO - 2021-07-15 17:50:03 --> Utf8 Class Initialized
INFO - 2021-07-15 17:50:03 --> URI Class Initialized
INFO - 2021-07-15 17:50:03 --> Router Class Initialized
INFO - 2021-07-15 17:50:03 --> Output Class Initialized
INFO - 2021-07-15 17:50:03 --> Security Class Initialized
DEBUG - 2021-07-15 17:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 17:50:03 --> Input Class Initialized
INFO - 2021-07-15 17:50:03 --> Language Class Initialized
INFO - 2021-07-15 17:50:03 --> Loader Class Initialized
INFO - 2021-07-15 17:50:03 --> Helper loaded: basic_helper
INFO - 2021-07-15 17:50:03 --> Helper loaded: url_helper
INFO - 2021-07-15 17:50:03 --> Helper loaded: file_helper
INFO - 2021-07-15 17:50:03 --> Helper loaded: form_helper
INFO - 2021-07-15 17:50:03 --> Helper loaded: cookie_helper
INFO - 2021-07-15 17:50:03 --> Helper loaded: security_helper
INFO - 2021-07-15 17:50:03 --> Helper loaded: directory_helper
INFO - 2021-07-15 17:50:03 --> Helper loaded: language_helper
INFO - 2021-07-15 17:50:03 --> Helper loaded: general_helper
INFO - 2021-07-15 17:50:03 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 17:50:03 --> Database Driver Class Initialized
DEBUG - 2021-07-15 17:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 17:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 17:50:03 --> Parser Class Initialized
INFO - 2021-07-15 17:50:03 --> Form Validation Class Initialized
INFO - 2021-07-15 17:50:03 --> Upload Class Initialized
INFO - 2021-07-15 17:50:03 --> Email Class Initialized
INFO - 2021-07-15 17:50:03 --> MY_Model class loaded
INFO - 2021-07-15 17:50:03 --> Model "Users_model" initialized
INFO - 2021-07-15 17:50:03 --> Model "Settings_model" initialized
INFO - 2021-07-15 17:50:03 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 17:50:03 --> Model "Permissions_model" initialized
INFO - 2021-07-15 17:50:03 --> Model "Roles_model" initialized
INFO - 2021-07-15 17:50:03 --> Model "Activity_model" initialized
INFO - 2021-07-15 17:50:03 --> Model "Templates_model" initialized
INFO - 2021-07-15 17:50:03 --> Database Driver Class Initialized
INFO - 2021-07-15 17:50:03 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 17:50:03 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 17:50:03 --> Controller Class Initialized
ERROR - 2021-07-15 17:50:03 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 17:50:03 --> File loaded: C:\wamp64\www\crm\application\views\roles/list.php
INFO - 2021-07-15 17:50:03 --> Final output sent to browser
DEBUG - 2021-07-15 17:50:03 --> Total execution time: 0.0700
INFO - 2021-07-15 17:50:03 --> Config Class Initialized
INFO - 2021-07-15 17:50:03 --> Hooks Class Initialized
DEBUG - 2021-07-15 17:50:03 --> UTF-8 Support Enabled
INFO - 2021-07-15 17:50:03 --> Utf8 Class Initialized
INFO - 2021-07-15 17:50:03 --> URI Class Initialized
INFO - 2021-07-15 17:50:03 --> Router Class Initialized
INFO - 2021-07-15 17:50:03 --> Output Class Initialized
INFO - 2021-07-15 17:50:03 --> Security Class Initialized
DEBUG - 2021-07-15 17:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 17:50:03 --> Input Class Initialized
INFO - 2021-07-15 17:50:03 --> Language Class Initialized
INFO - 2021-07-15 17:50:03 --> Loader Class Initialized
INFO - 2021-07-15 17:50:03 --> Helper loaded: basic_helper
INFO - 2021-07-15 17:50:03 --> Helper loaded: url_helper
INFO - 2021-07-15 17:50:03 --> Helper loaded: file_helper
INFO - 2021-07-15 17:50:03 --> Helper loaded: form_helper
INFO - 2021-07-15 17:50:03 --> Helper loaded: cookie_helper
INFO - 2021-07-15 17:50:03 --> Helper loaded: security_helper
INFO - 2021-07-15 17:50:03 --> Helper loaded: directory_helper
INFO - 2021-07-15 17:50:03 --> Helper loaded: language_helper
INFO - 2021-07-15 17:50:03 --> Helper loaded: general_helper
INFO - 2021-07-15 17:50:03 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 17:50:03 --> Database Driver Class Initialized
DEBUG - 2021-07-15 17:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 17:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 17:50:03 --> Parser Class Initialized
INFO - 2021-07-15 17:50:03 --> Form Validation Class Initialized
INFO - 2021-07-15 17:50:03 --> Upload Class Initialized
INFO - 2021-07-15 17:50:03 --> Email Class Initialized
INFO - 2021-07-15 17:50:03 --> MY_Model class loaded
INFO - 2021-07-15 17:50:03 --> Model "Users_model" initialized
INFO - 2021-07-15 17:50:03 --> Model "Settings_model" initialized
INFO - 2021-07-15 17:50:03 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 17:50:03 --> Model "Permissions_model" initialized
INFO - 2021-07-15 17:50:03 --> Model "Roles_model" initialized
INFO - 2021-07-15 17:50:03 --> Model "Activity_model" initialized
INFO - 2021-07-15 17:50:03 --> Model "Templates_model" initialized
INFO - 2021-07-15 17:50:03 --> Database Driver Class Initialized
INFO - 2021-07-15 17:50:03 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 17:50:03 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 17:50:03 --> Controller Class Initialized
ERROR - 2021-07-15 17:50:03 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 17:50:03 --> File loaded: C:\wamp64\www\crm\application\views\permissions/list.php
INFO - 2021-07-15 17:50:03 --> Final output sent to browser
DEBUG - 2021-07-15 17:50:03 --> Total execution time: 0.1319
INFO - 2021-07-15 17:50:07 --> Config Class Initialized
INFO - 2021-07-15 17:50:07 --> Hooks Class Initialized
DEBUG - 2021-07-15 17:50:07 --> UTF-8 Support Enabled
INFO - 2021-07-15 17:50:07 --> Utf8 Class Initialized
INFO - 2021-07-15 17:50:07 --> URI Class Initialized
INFO - 2021-07-15 17:50:07 --> Router Class Initialized
INFO - 2021-07-15 17:50:07 --> Output Class Initialized
INFO - 2021-07-15 17:50:07 --> Security Class Initialized
DEBUG - 2021-07-15 17:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 17:50:07 --> Input Class Initialized
INFO - 2021-07-15 17:50:07 --> Language Class Initialized
INFO - 2021-07-15 17:50:07 --> Loader Class Initialized
INFO - 2021-07-15 17:50:07 --> Helper loaded: basic_helper
INFO - 2021-07-15 17:50:07 --> Helper loaded: url_helper
INFO - 2021-07-15 17:50:07 --> Helper loaded: file_helper
INFO - 2021-07-15 17:50:07 --> Helper loaded: form_helper
INFO - 2021-07-15 17:50:07 --> Helper loaded: cookie_helper
INFO - 2021-07-15 17:50:07 --> Helper loaded: security_helper
INFO - 2021-07-15 17:50:07 --> Helper loaded: directory_helper
INFO - 2021-07-15 17:50:07 --> Helper loaded: language_helper
INFO - 2021-07-15 17:50:07 --> Helper loaded: general_helper
INFO - 2021-07-15 17:50:07 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 17:50:07 --> Database Driver Class Initialized
DEBUG - 2021-07-15 17:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 17:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 17:50:07 --> Parser Class Initialized
INFO - 2021-07-15 17:50:07 --> Form Validation Class Initialized
INFO - 2021-07-15 17:50:07 --> Upload Class Initialized
INFO - 2021-07-15 17:50:07 --> Email Class Initialized
INFO - 2021-07-15 17:50:07 --> MY_Model class loaded
INFO - 2021-07-15 17:50:07 --> Model "Users_model" initialized
INFO - 2021-07-15 17:50:07 --> Model "Settings_model" initialized
INFO - 2021-07-15 17:50:07 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 17:50:07 --> Model "Permissions_model" initialized
INFO - 2021-07-15 17:50:07 --> Model "Roles_model" initialized
INFO - 2021-07-15 17:50:07 --> Model "Activity_model" initialized
INFO - 2021-07-15 17:50:07 --> Model "Templates_model" initialized
INFO - 2021-07-15 17:50:07 --> Database Driver Class Initialized
INFO - 2021-07-15 17:50:07 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 17:50:07 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 17:50:07 --> Controller Class Initialized
ERROR - 2021-07-15 17:50:07 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 17:50:07 --> File loaded: C:\wamp64\www\crm\application\views\roles/list.php
INFO - 2021-07-15 17:50:07 --> Final output sent to browser
DEBUG - 2021-07-15 17:50:07 --> Total execution time: 0.1660
INFO - 2021-07-15 17:50:09 --> Config Class Initialized
INFO - 2021-07-15 17:50:09 --> Hooks Class Initialized
DEBUG - 2021-07-15 17:50:09 --> UTF-8 Support Enabled
INFO - 2021-07-15 17:50:09 --> Utf8 Class Initialized
INFO - 2021-07-15 17:50:09 --> URI Class Initialized
INFO - 2021-07-15 17:50:09 --> Router Class Initialized
INFO - 2021-07-15 17:50:09 --> Output Class Initialized
INFO - 2021-07-15 17:50:09 --> Security Class Initialized
DEBUG - 2021-07-15 17:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 17:50:09 --> Input Class Initialized
INFO - 2021-07-15 17:50:09 --> Language Class Initialized
INFO - 2021-07-15 17:50:09 --> Loader Class Initialized
INFO - 2021-07-15 17:50:09 --> Helper loaded: basic_helper
INFO - 2021-07-15 17:50:09 --> Helper loaded: url_helper
INFO - 2021-07-15 17:50:09 --> Helper loaded: file_helper
INFO - 2021-07-15 17:50:09 --> Helper loaded: form_helper
INFO - 2021-07-15 17:50:09 --> Helper loaded: cookie_helper
INFO - 2021-07-15 17:50:09 --> Helper loaded: security_helper
INFO - 2021-07-15 17:50:09 --> Helper loaded: directory_helper
INFO - 2021-07-15 17:50:09 --> Helper loaded: language_helper
INFO - 2021-07-15 17:50:09 --> Helper loaded: general_helper
INFO - 2021-07-15 17:50:09 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 17:50:09 --> Database Driver Class Initialized
DEBUG - 2021-07-15 17:50:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 17:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 17:50:09 --> Parser Class Initialized
INFO - 2021-07-15 17:50:09 --> Form Validation Class Initialized
INFO - 2021-07-15 17:50:09 --> Upload Class Initialized
INFO - 2021-07-15 17:50:09 --> Email Class Initialized
INFO - 2021-07-15 17:50:09 --> MY_Model class loaded
INFO - 2021-07-15 17:50:09 --> Model "Users_model" initialized
INFO - 2021-07-15 17:50:09 --> Model "Settings_model" initialized
INFO - 2021-07-15 17:50:09 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 17:50:09 --> Model "Permissions_model" initialized
INFO - 2021-07-15 17:50:09 --> Model "Roles_model" initialized
INFO - 2021-07-15 17:50:09 --> Model "Activity_model" initialized
INFO - 2021-07-15 17:50:09 --> Model "Templates_model" initialized
INFO - 2021-07-15 17:50:09 --> Database Driver Class Initialized
INFO - 2021-07-15 17:50:09 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 17:50:09 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 17:50:09 --> Controller Class Initialized
ERROR - 2021-07-15 17:50:09 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-15 17:50:09 --> Could not find the language line "edit_role"
ERROR - 2021-07-15 17:50:09 --> Could not find the language line "edit_role"
INFO - 2021-07-15 17:50:09 --> File loaded: C:\wamp64\www\crm\application\views\roles/edit.php
INFO - 2021-07-15 17:50:09 --> Final output sent to browser
DEBUG - 2021-07-15 17:50:09 --> Total execution time: 0.0670
INFO - 2021-07-15 17:50:17 --> Config Class Initialized
INFO - 2021-07-15 17:50:17 --> Hooks Class Initialized
DEBUG - 2021-07-15 17:50:17 --> UTF-8 Support Enabled
INFO - 2021-07-15 17:50:17 --> Utf8 Class Initialized
INFO - 2021-07-15 17:50:17 --> URI Class Initialized
INFO - 2021-07-15 17:50:17 --> Router Class Initialized
INFO - 2021-07-15 17:50:17 --> Output Class Initialized
INFO - 2021-07-15 17:50:17 --> Security Class Initialized
DEBUG - 2021-07-15 17:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 17:50:17 --> Input Class Initialized
INFO - 2021-07-15 17:50:17 --> Language Class Initialized
INFO - 2021-07-15 17:50:17 --> Loader Class Initialized
INFO - 2021-07-15 17:50:17 --> Helper loaded: basic_helper
INFO - 2021-07-15 17:50:17 --> Helper loaded: url_helper
INFO - 2021-07-15 17:50:17 --> Helper loaded: file_helper
INFO - 2021-07-15 17:50:17 --> Helper loaded: form_helper
INFO - 2021-07-15 17:50:17 --> Helper loaded: cookie_helper
INFO - 2021-07-15 17:50:17 --> Helper loaded: security_helper
INFO - 2021-07-15 17:50:17 --> Helper loaded: directory_helper
INFO - 2021-07-15 17:50:17 --> Helper loaded: language_helper
INFO - 2021-07-15 17:50:17 --> Helper loaded: general_helper
INFO - 2021-07-15 17:50:17 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 17:50:17 --> Database Driver Class Initialized
DEBUG - 2021-07-15 17:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 17:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 17:50:17 --> Parser Class Initialized
INFO - 2021-07-15 17:50:17 --> Form Validation Class Initialized
INFO - 2021-07-15 17:50:17 --> Upload Class Initialized
INFO - 2021-07-15 17:50:17 --> Email Class Initialized
INFO - 2021-07-15 17:50:17 --> MY_Model class loaded
INFO - 2021-07-15 17:50:17 --> Model "Users_model" initialized
INFO - 2021-07-15 17:50:17 --> Model "Settings_model" initialized
INFO - 2021-07-15 17:50:17 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 17:50:17 --> Model "Permissions_model" initialized
INFO - 2021-07-15 17:50:17 --> Model "Roles_model" initialized
INFO - 2021-07-15 17:50:17 --> Model "Activity_model" initialized
INFO - 2021-07-15 17:50:17 --> Model "Templates_model" initialized
INFO - 2021-07-15 17:50:17 --> Database Driver Class Initialized
INFO - 2021-07-15 17:50:17 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 17:50:17 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 17:50:17 --> Controller Class Initialized
INFO - 2021-07-15 17:50:17 --> Config Class Initialized
INFO - 2021-07-15 17:50:17 --> Hooks Class Initialized
DEBUG - 2021-07-15 17:50:17 --> UTF-8 Support Enabled
INFO - 2021-07-15 17:50:17 --> Utf8 Class Initialized
INFO - 2021-07-15 17:50:17 --> URI Class Initialized
INFO - 2021-07-15 17:50:17 --> Router Class Initialized
INFO - 2021-07-15 17:50:17 --> Output Class Initialized
INFO - 2021-07-15 17:50:17 --> Security Class Initialized
DEBUG - 2021-07-15 17:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 17:50:17 --> Input Class Initialized
INFO - 2021-07-15 17:50:17 --> Language Class Initialized
INFO - 2021-07-15 17:50:17 --> Loader Class Initialized
INFO - 2021-07-15 17:50:17 --> Helper loaded: basic_helper
INFO - 2021-07-15 17:50:17 --> Helper loaded: url_helper
INFO - 2021-07-15 17:50:17 --> Helper loaded: file_helper
INFO - 2021-07-15 17:50:17 --> Helper loaded: form_helper
INFO - 2021-07-15 17:50:17 --> Helper loaded: cookie_helper
INFO - 2021-07-15 17:50:17 --> Helper loaded: security_helper
INFO - 2021-07-15 17:50:17 --> Helper loaded: directory_helper
INFO - 2021-07-15 17:50:17 --> Helper loaded: language_helper
INFO - 2021-07-15 17:50:17 --> Helper loaded: general_helper
INFO - 2021-07-15 17:50:17 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 17:50:17 --> Database Driver Class Initialized
DEBUG - 2021-07-15 17:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 17:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 17:50:17 --> Parser Class Initialized
INFO - 2021-07-15 17:50:17 --> Form Validation Class Initialized
INFO - 2021-07-15 17:50:17 --> Upload Class Initialized
INFO - 2021-07-15 17:50:17 --> Email Class Initialized
INFO - 2021-07-15 17:50:17 --> MY_Model class loaded
INFO - 2021-07-15 17:50:17 --> Model "Users_model" initialized
INFO - 2021-07-15 17:50:17 --> Model "Settings_model" initialized
INFO - 2021-07-15 17:50:17 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 17:50:17 --> Model "Permissions_model" initialized
INFO - 2021-07-15 17:50:17 --> Model "Roles_model" initialized
INFO - 2021-07-15 17:50:17 --> Model "Activity_model" initialized
INFO - 2021-07-15 17:50:17 --> Model "Templates_model" initialized
INFO - 2021-07-15 17:50:17 --> Database Driver Class Initialized
INFO - 2021-07-15 17:50:17 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 17:50:17 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 17:50:17 --> Controller Class Initialized
ERROR - 2021-07-15 17:50:17 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 17:50:17 --> File loaded: C:\wamp64\www\crm\application\views\roles/list.php
INFO - 2021-07-15 17:50:17 --> Final output sent to browser
DEBUG - 2021-07-15 17:50:17 --> Total execution time: 0.0721
INFO - 2021-07-15 17:50:20 --> Config Class Initialized
INFO - 2021-07-15 17:50:20 --> Hooks Class Initialized
DEBUG - 2021-07-15 17:50:20 --> UTF-8 Support Enabled
INFO - 2021-07-15 17:50:20 --> Utf8 Class Initialized
INFO - 2021-07-15 17:50:20 --> URI Class Initialized
INFO - 2021-07-15 17:50:20 --> Router Class Initialized
INFO - 2021-07-15 17:50:20 --> Output Class Initialized
INFO - 2021-07-15 17:50:20 --> Security Class Initialized
DEBUG - 2021-07-15 17:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 17:50:20 --> Input Class Initialized
INFO - 2021-07-15 17:50:20 --> Language Class Initialized
INFO - 2021-07-15 17:50:20 --> Loader Class Initialized
INFO - 2021-07-15 17:50:20 --> Helper loaded: basic_helper
INFO - 2021-07-15 17:50:20 --> Helper loaded: url_helper
INFO - 2021-07-15 17:50:20 --> Helper loaded: file_helper
INFO - 2021-07-15 17:50:20 --> Helper loaded: form_helper
INFO - 2021-07-15 17:50:20 --> Helper loaded: cookie_helper
INFO - 2021-07-15 17:50:20 --> Helper loaded: security_helper
INFO - 2021-07-15 17:50:20 --> Helper loaded: directory_helper
INFO - 2021-07-15 17:50:20 --> Helper loaded: language_helper
INFO - 2021-07-15 17:50:21 --> Helper loaded: general_helper
INFO - 2021-07-15 17:50:21 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 17:50:21 --> Database Driver Class Initialized
DEBUG - 2021-07-15 17:50:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 17:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 17:50:21 --> Parser Class Initialized
INFO - 2021-07-15 17:50:21 --> Form Validation Class Initialized
INFO - 2021-07-15 17:50:21 --> Upload Class Initialized
INFO - 2021-07-15 17:50:21 --> Email Class Initialized
INFO - 2021-07-15 17:50:21 --> MY_Model class loaded
INFO - 2021-07-15 17:50:21 --> Model "Users_model" initialized
INFO - 2021-07-15 17:50:21 --> Model "Settings_model" initialized
INFO - 2021-07-15 17:50:21 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 17:50:21 --> Model "Permissions_model" initialized
INFO - 2021-07-15 17:50:21 --> Model "Roles_model" initialized
INFO - 2021-07-15 17:50:21 --> Model "Activity_model" initialized
INFO - 2021-07-15 17:50:21 --> Model "Templates_model" initialized
INFO - 2021-07-15 17:50:21 --> Database Driver Class Initialized
INFO - 2021-07-15 17:50:21 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 17:50:21 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 17:50:21 --> Controller Class Initialized
ERROR - 2021-07-15 17:50:21 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 17:50:21 --> File loaded: C:\wamp64\www\crm\application\views\roles/list.php
INFO - 2021-07-15 17:50:21 --> Final output sent to browser
DEBUG - 2021-07-15 17:50:21 --> Total execution time: 0.0723
INFO - 2021-07-15 17:50:24 --> Config Class Initialized
INFO - 2021-07-15 17:50:24 --> Hooks Class Initialized
DEBUG - 2021-07-15 17:50:24 --> UTF-8 Support Enabled
INFO - 2021-07-15 17:50:24 --> Utf8 Class Initialized
INFO - 2021-07-15 17:50:24 --> URI Class Initialized
INFO - 2021-07-15 17:50:24 --> Router Class Initialized
INFO - 2021-07-15 17:50:24 --> Output Class Initialized
INFO - 2021-07-15 17:50:24 --> Security Class Initialized
DEBUG - 2021-07-15 17:50:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 17:50:24 --> Input Class Initialized
INFO - 2021-07-15 17:50:24 --> Language Class Initialized
INFO - 2021-07-15 17:50:24 --> Loader Class Initialized
INFO - 2021-07-15 17:50:24 --> Helper loaded: basic_helper
INFO - 2021-07-15 17:50:24 --> Helper loaded: url_helper
INFO - 2021-07-15 17:50:24 --> Helper loaded: file_helper
INFO - 2021-07-15 17:50:24 --> Helper loaded: form_helper
INFO - 2021-07-15 17:50:24 --> Helper loaded: cookie_helper
INFO - 2021-07-15 17:50:24 --> Helper loaded: security_helper
INFO - 2021-07-15 17:50:24 --> Helper loaded: directory_helper
INFO - 2021-07-15 17:50:24 --> Helper loaded: language_helper
INFO - 2021-07-15 17:50:24 --> Helper loaded: general_helper
INFO - 2021-07-15 17:50:24 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 17:50:24 --> Database Driver Class Initialized
DEBUG - 2021-07-15 17:50:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 17:50:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 17:50:24 --> Parser Class Initialized
INFO - 2021-07-15 17:50:24 --> Form Validation Class Initialized
INFO - 2021-07-15 17:50:24 --> Upload Class Initialized
INFO - 2021-07-15 17:50:24 --> Email Class Initialized
INFO - 2021-07-15 17:50:24 --> MY_Model class loaded
INFO - 2021-07-15 17:50:24 --> Model "Users_model" initialized
INFO - 2021-07-15 17:50:24 --> Model "Settings_model" initialized
INFO - 2021-07-15 17:50:24 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 17:50:24 --> Model "Permissions_model" initialized
INFO - 2021-07-15 17:50:24 --> Model "Roles_model" initialized
INFO - 2021-07-15 17:50:24 --> Model "Activity_model" initialized
INFO - 2021-07-15 17:50:24 --> Model "Templates_model" initialized
INFO - 2021-07-15 17:50:24 --> Database Driver Class Initialized
INFO - 2021-07-15 17:50:24 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 17:50:24 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 17:50:24 --> Controller Class Initialized
ERROR - 2021-07-15 17:50:24 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 17:50:24 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 17:50:24 --> Final output sent to browser
DEBUG - 2021-07-15 17:50:24 --> Total execution time: 0.1459
INFO - 2021-07-15 17:50:27 --> Config Class Initialized
INFO - 2021-07-15 17:50:27 --> Hooks Class Initialized
DEBUG - 2021-07-15 17:50:27 --> UTF-8 Support Enabled
INFO - 2021-07-15 17:50:27 --> Utf8 Class Initialized
INFO - 2021-07-15 17:50:27 --> URI Class Initialized
INFO - 2021-07-15 17:50:27 --> Router Class Initialized
INFO - 2021-07-15 17:50:27 --> Output Class Initialized
INFO - 2021-07-15 17:50:27 --> Security Class Initialized
DEBUG - 2021-07-15 17:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 17:50:27 --> Input Class Initialized
INFO - 2021-07-15 17:50:27 --> Language Class Initialized
INFO - 2021-07-15 17:50:27 --> Loader Class Initialized
INFO - 2021-07-15 17:50:27 --> Helper loaded: basic_helper
INFO - 2021-07-15 17:50:27 --> Helper loaded: url_helper
INFO - 2021-07-15 17:50:27 --> Helper loaded: file_helper
INFO - 2021-07-15 17:50:27 --> Helper loaded: form_helper
INFO - 2021-07-15 17:50:27 --> Helper loaded: cookie_helper
INFO - 2021-07-15 17:50:27 --> Helper loaded: security_helper
INFO - 2021-07-15 17:50:27 --> Helper loaded: directory_helper
INFO - 2021-07-15 17:50:27 --> Helper loaded: language_helper
INFO - 2021-07-15 17:50:27 --> Helper loaded: general_helper
INFO - 2021-07-15 17:50:27 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 17:50:27 --> Database Driver Class Initialized
DEBUG - 2021-07-15 17:50:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 17:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 17:50:27 --> Parser Class Initialized
INFO - 2021-07-15 17:50:27 --> Form Validation Class Initialized
INFO - 2021-07-15 17:50:27 --> Upload Class Initialized
INFO - 2021-07-15 17:50:27 --> Email Class Initialized
INFO - 2021-07-15 17:50:27 --> MY_Model class loaded
INFO - 2021-07-15 17:50:27 --> Model "Users_model" initialized
INFO - 2021-07-15 17:50:27 --> Model "Settings_model" initialized
INFO - 2021-07-15 17:50:27 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 17:50:27 --> Model "Permissions_model" initialized
INFO - 2021-07-15 17:50:27 --> Model "Roles_model" initialized
INFO - 2021-07-15 17:50:27 --> Model "Activity_model" initialized
INFO - 2021-07-15 17:50:27 --> Model "Templates_model" initialized
INFO - 2021-07-15 17:50:27 --> Database Driver Class Initialized
INFO - 2021-07-15 17:50:27 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 17:50:27 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 17:50:27 --> Controller Class Initialized
ERROR - 2021-07-15 17:50:27 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 17:50:27 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 17:50:27 --> Final output sent to browser
DEBUG - 2021-07-15 17:50:27 --> Total execution time: 0.0904
INFO - 2021-07-15 17:50:53 --> Config Class Initialized
INFO - 2021-07-15 17:50:53 --> Hooks Class Initialized
DEBUG - 2021-07-15 17:50:53 --> UTF-8 Support Enabled
INFO - 2021-07-15 17:50:53 --> Utf8 Class Initialized
INFO - 2021-07-15 17:50:53 --> URI Class Initialized
INFO - 2021-07-15 17:50:53 --> Router Class Initialized
INFO - 2021-07-15 17:50:53 --> Output Class Initialized
INFO - 2021-07-15 17:50:53 --> Security Class Initialized
DEBUG - 2021-07-15 17:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 17:50:53 --> Input Class Initialized
INFO - 2021-07-15 17:50:53 --> Language Class Initialized
INFO - 2021-07-15 17:50:53 --> Loader Class Initialized
INFO - 2021-07-15 17:50:53 --> Helper loaded: basic_helper
INFO - 2021-07-15 17:50:53 --> Helper loaded: url_helper
INFO - 2021-07-15 17:50:53 --> Helper loaded: file_helper
INFO - 2021-07-15 17:50:53 --> Helper loaded: form_helper
INFO - 2021-07-15 17:50:53 --> Helper loaded: cookie_helper
INFO - 2021-07-15 17:50:53 --> Helper loaded: security_helper
INFO - 2021-07-15 17:50:53 --> Helper loaded: directory_helper
INFO - 2021-07-15 17:50:53 --> Helper loaded: language_helper
INFO - 2021-07-15 17:50:53 --> Helper loaded: general_helper
INFO - 2021-07-15 17:50:53 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 17:50:53 --> Database Driver Class Initialized
DEBUG - 2021-07-15 17:50:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 17:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 17:50:53 --> Parser Class Initialized
INFO - 2021-07-15 17:50:53 --> Form Validation Class Initialized
INFO - 2021-07-15 17:50:53 --> Upload Class Initialized
INFO - 2021-07-15 17:50:53 --> Email Class Initialized
INFO - 2021-07-15 17:50:53 --> MY_Model class loaded
INFO - 2021-07-15 17:50:53 --> Model "Users_model" initialized
INFO - 2021-07-15 17:50:53 --> Model "Settings_model" initialized
INFO - 2021-07-15 17:50:53 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 17:50:53 --> Model "Permissions_model" initialized
INFO - 2021-07-15 17:50:53 --> Model "Roles_model" initialized
INFO - 2021-07-15 17:50:53 --> Model "Activity_model" initialized
INFO - 2021-07-15 17:50:53 --> Model "Templates_model" initialized
INFO - 2021-07-15 17:50:53 --> Database Driver Class Initialized
INFO - 2021-07-15 17:50:53 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 17:50:53 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 17:50:53 --> Controller Class Initialized
ERROR - 2021-07-15 17:50:53 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 17:50:53 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 17:50:53 --> Final output sent to browser
DEBUG - 2021-07-15 17:50:53 --> Total execution time: 0.1622
INFO - 2021-07-15 17:50:58 --> Config Class Initialized
INFO - 2021-07-15 17:50:58 --> Hooks Class Initialized
DEBUG - 2021-07-15 17:50:58 --> UTF-8 Support Enabled
INFO - 2021-07-15 17:50:58 --> Utf8 Class Initialized
INFO - 2021-07-15 17:50:58 --> URI Class Initialized
INFO - 2021-07-15 17:50:58 --> Router Class Initialized
INFO - 2021-07-15 17:50:58 --> Output Class Initialized
INFO - 2021-07-15 17:50:58 --> Security Class Initialized
DEBUG - 2021-07-15 17:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 17:50:58 --> Input Class Initialized
INFO - 2021-07-15 17:50:58 --> Language Class Initialized
INFO - 2021-07-15 17:50:58 --> Loader Class Initialized
INFO - 2021-07-15 17:50:58 --> Helper loaded: basic_helper
INFO - 2021-07-15 17:50:58 --> Helper loaded: url_helper
INFO - 2021-07-15 17:50:58 --> Helper loaded: file_helper
INFO - 2021-07-15 17:50:58 --> Helper loaded: form_helper
INFO - 2021-07-15 17:50:58 --> Helper loaded: cookie_helper
INFO - 2021-07-15 17:50:58 --> Helper loaded: security_helper
INFO - 2021-07-15 17:50:58 --> Helper loaded: directory_helper
INFO - 2021-07-15 17:50:58 --> Helper loaded: language_helper
INFO - 2021-07-15 17:50:58 --> Helper loaded: general_helper
INFO - 2021-07-15 17:50:58 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 17:50:58 --> Database Driver Class Initialized
DEBUG - 2021-07-15 17:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 17:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 17:50:58 --> Parser Class Initialized
INFO - 2021-07-15 17:50:58 --> Form Validation Class Initialized
INFO - 2021-07-15 17:50:58 --> Upload Class Initialized
INFO - 2021-07-15 17:50:58 --> Email Class Initialized
INFO - 2021-07-15 17:50:59 --> MY_Model class loaded
INFO - 2021-07-15 17:50:59 --> Model "Users_model" initialized
INFO - 2021-07-15 17:50:59 --> Model "Settings_model" initialized
INFO - 2021-07-15 17:50:59 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 17:50:59 --> Model "Permissions_model" initialized
INFO - 2021-07-15 17:50:59 --> Model "Roles_model" initialized
INFO - 2021-07-15 17:50:59 --> Model "Activity_model" initialized
INFO - 2021-07-15 17:50:59 --> Model "Templates_model" initialized
INFO - 2021-07-15 17:50:59 --> Database Driver Class Initialized
INFO - 2021-07-15 17:50:59 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 17:50:59 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 17:50:59 --> Controller Class Initialized
ERROR - 2021-07-15 17:50:59 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 17:50:59 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 17:50:59 --> Final output sent to browser
DEBUG - 2021-07-15 17:50:59 --> Total execution time: 0.1391
INFO - 2021-07-15 17:58:36 --> Config Class Initialized
INFO - 2021-07-15 17:58:36 --> Hooks Class Initialized
DEBUG - 2021-07-15 17:58:36 --> UTF-8 Support Enabled
INFO - 2021-07-15 17:58:36 --> Utf8 Class Initialized
INFO - 2021-07-15 17:58:36 --> URI Class Initialized
INFO - 2021-07-15 17:58:36 --> Router Class Initialized
INFO - 2021-07-15 17:58:36 --> Output Class Initialized
INFO - 2021-07-15 17:58:36 --> Security Class Initialized
DEBUG - 2021-07-15 17:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 17:58:36 --> Input Class Initialized
INFO - 2021-07-15 17:58:36 --> Language Class Initialized
INFO - 2021-07-15 17:58:36 --> Loader Class Initialized
INFO - 2021-07-15 17:58:36 --> Helper loaded: basic_helper
INFO - 2021-07-15 17:58:36 --> Helper loaded: url_helper
INFO - 2021-07-15 17:58:36 --> Helper loaded: file_helper
INFO - 2021-07-15 17:58:36 --> Helper loaded: form_helper
INFO - 2021-07-15 17:58:36 --> Helper loaded: cookie_helper
INFO - 2021-07-15 17:58:36 --> Helper loaded: security_helper
INFO - 2021-07-15 17:58:36 --> Helper loaded: directory_helper
INFO - 2021-07-15 17:58:36 --> Helper loaded: language_helper
INFO - 2021-07-15 17:58:36 --> Helper loaded: general_helper
INFO - 2021-07-15 17:58:36 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 17:58:36 --> Database Driver Class Initialized
DEBUG - 2021-07-15 17:58:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 17:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 17:58:36 --> Parser Class Initialized
INFO - 2021-07-15 17:58:36 --> Form Validation Class Initialized
INFO - 2021-07-15 17:58:36 --> Upload Class Initialized
INFO - 2021-07-15 17:58:36 --> Email Class Initialized
INFO - 2021-07-15 17:58:36 --> MY_Model class loaded
INFO - 2021-07-15 17:58:36 --> Model "Users_model" initialized
INFO - 2021-07-15 17:58:36 --> Model "Settings_model" initialized
INFO - 2021-07-15 17:58:36 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 17:58:36 --> Model "Permissions_model" initialized
INFO - 2021-07-15 17:58:36 --> Model "Roles_model" initialized
INFO - 2021-07-15 17:58:36 --> Model "Activity_model" initialized
INFO - 2021-07-15 17:58:36 --> Model "Templates_model" initialized
INFO - 2021-07-15 17:58:36 --> Database Driver Class Initialized
INFO - 2021-07-15 17:58:36 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 17:58:36 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 17:58:36 --> Controller Class Initialized
ERROR - 2021-07-15 17:58:36 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 17:58:36 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 17:58:36 --> Final output sent to browser
DEBUG - 2021-07-15 17:58:36 --> Total execution time: 0.1867
INFO - 2021-07-15 17:58:46 --> Config Class Initialized
INFO - 2021-07-15 17:58:46 --> Hooks Class Initialized
DEBUG - 2021-07-15 17:58:46 --> UTF-8 Support Enabled
INFO - 2021-07-15 17:58:46 --> Utf8 Class Initialized
INFO - 2021-07-15 17:58:46 --> URI Class Initialized
INFO - 2021-07-15 17:58:46 --> Router Class Initialized
INFO - 2021-07-15 17:58:46 --> Output Class Initialized
INFO - 2021-07-15 17:58:46 --> Security Class Initialized
DEBUG - 2021-07-15 17:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 17:58:46 --> Input Class Initialized
INFO - 2021-07-15 17:58:46 --> Language Class Initialized
INFO - 2021-07-15 17:58:46 --> Loader Class Initialized
INFO - 2021-07-15 17:58:46 --> Helper loaded: basic_helper
INFO - 2021-07-15 17:58:46 --> Helper loaded: url_helper
INFO - 2021-07-15 17:58:46 --> Helper loaded: file_helper
INFO - 2021-07-15 17:58:46 --> Helper loaded: form_helper
INFO - 2021-07-15 17:58:46 --> Helper loaded: cookie_helper
INFO - 2021-07-15 17:58:46 --> Helper loaded: security_helper
INFO - 2021-07-15 17:58:46 --> Helper loaded: directory_helper
INFO - 2021-07-15 17:58:46 --> Helper loaded: language_helper
INFO - 2021-07-15 17:58:46 --> Helper loaded: general_helper
INFO - 2021-07-15 17:58:46 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 17:58:46 --> Database Driver Class Initialized
DEBUG - 2021-07-15 17:58:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 17:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 17:58:46 --> Parser Class Initialized
INFO - 2021-07-15 17:58:46 --> Form Validation Class Initialized
INFO - 2021-07-15 17:58:46 --> Upload Class Initialized
INFO - 2021-07-15 17:58:46 --> Email Class Initialized
INFO - 2021-07-15 17:58:46 --> MY_Model class loaded
INFO - 2021-07-15 17:58:46 --> Model "Users_model" initialized
INFO - 2021-07-15 17:58:46 --> Model "Settings_model" initialized
INFO - 2021-07-15 17:58:46 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 17:58:46 --> Model "Permissions_model" initialized
INFO - 2021-07-15 17:58:46 --> Model "Roles_model" initialized
INFO - 2021-07-15 17:58:46 --> Model "Activity_model" initialized
INFO - 2021-07-15 17:58:46 --> Model "Templates_model" initialized
INFO - 2021-07-15 17:58:46 --> Database Driver Class Initialized
INFO - 2021-07-15 17:58:46 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 17:58:46 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 17:58:46 --> Controller Class Initialized
ERROR - 2021-07-15 17:58:46 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 17:58:46 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 17:58:46 --> Final output sent to browser
DEBUG - 2021-07-15 17:58:46 --> Total execution time: 0.1503
INFO - 2021-07-15 17:59:44 --> Config Class Initialized
INFO - 2021-07-15 17:59:44 --> Hooks Class Initialized
DEBUG - 2021-07-15 17:59:44 --> UTF-8 Support Enabled
INFO - 2021-07-15 17:59:44 --> Utf8 Class Initialized
INFO - 2021-07-15 17:59:44 --> URI Class Initialized
INFO - 2021-07-15 17:59:44 --> Router Class Initialized
INFO - 2021-07-15 17:59:44 --> Output Class Initialized
INFO - 2021-07-15 17:59:44 --> Security Class Initialized
DEBUG - 2021-07-15 17:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 17:59:44 --> Input Class Initialized
INFO - 2021-07-15 17:59:44 --> Language Class Initialized
INFO - 2021-07-15 17:59:44 --> Loader Class Initialized
INFO - 2021-07-15 17:59:44 --> Helper loaded: basic_helper
INFO - 2021-07-15 17:59:44 --> Helper loaded: url_helper
INFO - 2021-07-15 17:59:44 --> Helper loaded: file_helper
INFO - 2021-07-15 17:59:44 --> Helper loaded: form_helper
INFO - 2021-07-15 17:59:44 --> Helper loaded: cookie_helper
INFO - 2021-07-15 17:59:44 --> Helper loaded: security_helper
INFO - 2021-07-15 17:59:44 --> Helper loaded: directory_helper
INFO - 2021-07-15 17:59:44 --> Helper loaded: language_helper
INFO - 2021-07-15 17:59:44 --> Helper loaded: general_helper
INFO - 2021-07-15 17:59:44 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 17:59:44 --> Database Driver Class Initialized
DEBUG - 2021-07-15 17:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 17:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 17:59:44 --> Parser Class Initialized
INFO - 2021-07-15 17:59:44 --> Form Validation Class Initialized
INFO - 2021-07-15 17:59:44 --> Upload Class Initialized
INFO - 2021-07-15 17:59:44 --> Email Class Initialized
INFO - 2021-07-15 17:59:44 --> MY_Model class loaded
INFO - 2021-07-15 17:59:44 --> Model "Users_model" initialized
INFO - 2021-07-15 17:59:44 --> Model "Settings_model" initialized
INFO - 2021-07-15 17:59:44 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 17:59:44 --> Model "Permissions_model" initialized
INFO - 2021-07-15 17:59:44 --> Model "Roles_model" initialized
INFO - 2021-07-15 17:59:44 --> Model "Activity_model" initialized
INFO - 2021-07-15 17:59:44 --> Model "Templates_model" initialized
INFO - 2021-07-15 17:59:44 --> Database Driver Class Initialized
INFO - 2021-07-15 17:59:44 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 17:59:44 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 17:59:44 --> Controller Class Initialized
ERROR - 2021-07-15 17:59:44 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 17:59:44 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 17:59:44 --> Final output sent to browser
DEBUG - 2021-07-15 17:59:44 --> Total execution time: 0.2306
INFO - 2021-07-15 17:59:46 --> Config Class Initialized
INFO - 2021-07-15 17:59:46 --> Hooks Class Initialized
DEBUG - 2021-07-15 17:59:46 --> UTF-8 Support Enabled
INFO - 2021-07-15 17:59:46 --> Utf8 Class Initialized
INFO - 2021-07-15 17:59:46 --> URI Class Initialized
INFO - 2021-07-15 17:59:46 --> Router Class Initialized
INFO - 2021-07-15 17:59:46 --> Output Class Initialized
INFO - 2021-07-15 17:59:46 --> Security Class Initialized
DEBUG - 2021-07-15 17:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 17:59:46 --> Input Class Initialized
INFO - 2021-07-15 17:59:46 --> Language Class Initialized
INFO - 2021-07-15 17:59:46 --> Loader Class Initialized
INFO - 2021-07-15 17:59:46 --> Helper loaded: basic_helper
INFO - 2021-07-15 17:59:46 --> Helper loaded: url_helper
INFO - 2021-07-15 17:59:46 --> Helper loaded: file_helper
INFO - 2021-07-15 17:59:46 --> Helper loaded: form_helper
INFO - 2021-07-15 17:59:46 --> Helper loaded: cookie_helper
INFO - 2021-07-15 17:59:46 --> Helper loaded: security_helper
INFO - 2021-07-15 17:59:46 --> Helper loaded: directory_helper
INFO - 2021-07-15 17:59:46 --> Helper loaded: language_helper
INFO - 2021-07-15 17:59:46 --> Helper loaded: general_helper
INFO - 2021-07-15 17:59:46 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 17:59:46 --> Database Driver Class Initialized
DEBUG - 2021-07-15 17:59:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 17:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 17:59:46 --> Parser Class Initialized
INFO - 2021-07-15 17:59:46 --> Form Validation Class Initialized
INFO - 2021-07-15 17:59:46 --> Upload Class Initialized
INFO - 2021-07-15 17:59:46 --> Email Class Initialized
INFO - 2021-07-15 17:59:46 --> MY_Model class loaded
INFO - 2021-07-15 17:59:46 --> Model "Users_model" initialized
INFO - 2021-07-15 17:59:46 --> Model "Settings_model" initialized
INFO - 2021-07-15 17:59:46 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 17:59:46 --> Model "Permissions_model" initialized
INFO - 2021-07-15 17:59:46 --> Model "Roles_model" initialized
INFO - 2021-07-15 17:59:46 --> Model "Activity_model" initialized
INFO - 2021-07-15 17:59:46 --> Model "Templates_model" initialized
INFO - 2021-07-15 17:59:46 --> Database Driver Class Initialized
INFO - 2021-07-15 17:59:46 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 17:59:46 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 17:59:46 --> Controller Class Initialized
ERROR - 2021-07-15 17:59:46 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 17:59:46 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 17:59:46 --> Final output sent to browser
DEBUG - 2021-07-15 17:59:46 --> Total execution time: 0.0628
INFO - 2021-07-15 17:59:46 --> Config Class Initialized
INFO - 2021-07-15 17:59:46 --> Hooks Class Initialized
DEBUG - 2021-07-15 17:59:46 --> UTF-8 Support Enabled
INFO - 2021-07-15 17:59:46 --> Utf8 Class Initialized
INFO - 2021-07-15 17:59:46 --> URI Class Initialized
INFO - 2021-07-15 17:59:46 --> Router Class Initialized
INFO - 2021-07-15 17:59:46 --> Output Class Initialized
INFO - 2021-07-15 17:59:46 --> Security Class Initialized
DEBUG - 2021-07-15 17:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 17:59:46 --> Input Class Initialized
INFO - 2021-07-15 17:59:46 --> Language Class Initialized
INFO - 2021-07-15 17:59:46 --> Loader Class Initialized
INFO - 2021-07-15 17:59:46 --> Helper loaded: basic_helper
INFO - 2021-07-15 17:59:46 --> Helper loaded: url_helper
INFO - 2021-07-15 17:59:46 --> Helper loaded: file_helper
INFO - 2021-07-15 17:59:46 --> Helper loaded: form_helper
INFO - 2021-07-15 17:59:46 --> Helper loaded: cookie_helper
INFO - 2021-07-15 17:59:46 --> Helper loaded: security_helper
INFO - 2021-07-15 17:59:46 --> Helper loaded: directory_helper
INFO - 2021-07-15 17:59:46 --> Helper loaded: language_helper
INFO - 2021-07-15 17:59:46 --> Helper loaded: general_helper
INFO - 2021-07-15 17:59:46 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 17:59:46 --> Database Driver Class Initialized
DEBUG - 2021-07-15 17:59:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 17:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 17:59:46 --> Parser Class Initialized
INFO - 2021-07-15 17:59:46 --> Form Validation Class Initialized
INFO - 2021-07-15 17:59:46 --> Upload Class Initialized
INFO - 2021-07-15 17:59:46 --> Email Class Initialized
INFO - 2021-07-15 17:59:46 --> MY_Model class loaded
INFO - 2021-07-15 17:59:46 --> Model "Users_model" initialized
INFO - 2021-07-15 17:59:46 --> Model "Settings_model" initialized
INFO - 2021-07-15 17:59:46 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 17:59:46 --> Model "Permissions_model" initialized
INFO - 2021-07-15 17:59:46 --> Model "Roles_model" initialized
INFO - 2021-07-15 17:59:46 --> Model "Activity_model" initialized
INFO - 2021-07-15 17:59:46 --> Model "Templates_model" initialized
INFO - 2021-07-15 17:59:46 --> Database Driver Class Initialized
INFO - 2021-07-15 17:59:46 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 17:59:46 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 17:59:46 --> Controller Class Initialized
ERROR - 2021-07-15 17:59:46 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 17:59:46 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 17:59:46 --> Final output sent to browser
DEBUG - 2021-07-15 17:59:46 --> Total execution time: 0.0650
INFO - 2021-07-15 17:59:47 --> Config Class Initialized
INFO - 2021-07-15 17:59:47 --> Hooks Class Initialized
DEBUG - 2021-07-15 17:59:47 --> UTF-8 Support Enabled
INFO - 2021-07-15 17:59:47 --> Utf8 Class Initialized
INFO - 2021-07-15 17:59:47 --> URI Class Initialized
INFO - 2021-07-15 17:59:47 --> Router Class Initialized
INFO - 2021-07-15 17:59:47 --> Output Class Initialized
INFO - 2021-07-15 17:59:47 --> Security Class Initialized
DEBUG - 2021-07-15 17:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 17:59:47 --> Input Class Initialized
INFO - 2021-07-15 17:59:47 --> Language Class Initialized
INFO - 2021-07-15 17:59:47 --> Loader Class Initialized
INFO - 2021-07-15 17:59:47 --> Helper loaded: basic_helper
INFO - 2021-07-15 17:59:47 --> Helper loaded: url_helper
INFO - 2021-07-15 17:59:47 --> Helper loaded: file_helper
INFO - 2021-07-15 17:59:47 --> Helper loaded: form_helper
INFO - 2021-07-15 17:59:47 --> Helper loaded: cookie_helper
INFO - 2021-07-15 17:59:47 --> Helper loaded: security_helper
INFO - 2021-07-15 17:59:47 --> Helper loaded: directory_helper
INFO - 2021-07-15 17:59:47 --> Helper loaded: language_helper
INFO - 2021-07-15 17:59:47 --> Helper loaded: general_helper
INFO - 2021-07-15 17:59:47 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 17:59:47 --> Database Driver Class Initialized
DEBUG - 2021-07-15 17:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 17:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 17:59:47 --> Parser Class Initialized
INFO - 2021-07-15 17:59:47 --> Form Validation Class Initialized
INFO - 2021-07-15 17:59:47 --> Upload Class Initialized
INFO - 2021-07-15 17:59:47 --> Email Class Initialized
INFO - 2021-07-15 17:59:47 --> MY_Model class loaded
INFO - 2021-07-15 17:59:47 --> Model "Users_model" initialized
INFO - 2021-07-15 17:59:47 --> Model "Settings_model" initialized
INFO - 2021-07-15 17:59:47 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 17:59:47 --> Model "Permissions_model" initialized
INFO - 2021-07-15 17:59:47 --> Model "Roles_model" initialized
INFO - 2021-07-15 17:59:47 --> Model "Activity_model" initialized
INFO - 2021-07-15 17:59:47 --> Model "Templates_model" initialized
INFO - 2021-07-15 17:59:47 --> Database Driver Class Initialized
INFO - 2021-07-15 17:59:47 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 17:59:47 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 17:59:47 --> Controller Class Initialized
ERROR - 2021-07-15 17:59:47 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 17:59:47 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 17:59:47 --> Final output sent to browser
DEBUG - 2021-07-15 17:59:47 --> Total execution time: 0.0838
INFO - 2021-07-15 17:59:47 --> Config Class Initialized
INFO - 2021-07-15 17:59:47 --> Hooks Class Initialized
DEBUG - 2021-07-15 17:59:47 --> UTF-8 Support Enabled
INFO - 2021-07-15 17:59:47 --> Utf8 Class Initialized
INFO - 2021-07-15 17:59:47 --> URI Class Initialized
INFO - 2021-07-15 17:59:47 --> Router Class Initialized
INFO - 2021-07-15 17:59:47 --> Output Class Initialized
INFO - 2021-07-15 17:59:47 --> Security Class Initialized
DEBUG - 2021-07-15 17:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 17:59:47 --> Input Class Initialized
INFO - 2021-07-15 17:59:47 --> Language Class Initialized
INFO - 2021-07-15 17:59:47 --> Loader Class Initialized
INFO - 2021-07-15 17:59:47 --> Helper loaded: basic_helper
INFO - 2021-07-15 17:59:47 --> Helper loaded: url_helper
INFO - 2021-07-15 17:59:47 --> Helper loaded: file_helper
INFO - 2021-07-15 17:59:47 --> Helper loaded: form_helper
INFO - 2021-07-15 17:59:47 --> Helper loaded: cookie_helper
INFO - 2021-07-15 17:59:47 --> Helper loaded: security_helper
INFO - 2021-07-15 17:59:47 --> Helper loaded: directory_helper
INFO - 2021-07-15 17:59:47 --> Helper loaded: language_helper
INFO - 2021-07-15 17:59:47 --> Helper loaded: general_helper
INFO - 2021-07-15 17:59:47 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 17:59:47 --> Database Driver Class Initialized
DEBUG - 2021-07-15 17:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 17:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 17:59:47 --> Parser Class Initialized
INFO - 2021-07-15 17:59:47 --> Form Validation Class Initialized
INFO - 2021-07-15 17:59:47 --> Upload Class Initialized
INFO - 2021-07-15 17:59:47 --> Email Class Initialized
INFO - 2021-07-15 17:59:47 --> MY_Model class loaded
INFO - 2021-07-15 17:59:47 --> Model "Users_model" initialized
INFO - 2021-07-15 17:59:47 --> Model "Settings_model" initialized
INFO - 2021-07-15 17:59:47 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 17:59:47 --> Model "Permissions_model" initialized
INFO - 2021-07-15 17:59:47 --> Model "Roles_model" initialized
INFO - 2021-07-15 17:59:47 --> Model "Activity_model" initialized
INFO - 2021-07-15 17:59:47 --> Model "Templates_model" initialized
INFO - 2021-07-15 17:59:47 --> Database Driver Class Initialized
INFO - 2021-07-15 17:59:47 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 17:59:47 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 17:59:47 --> Controller Class Initialized
ERROR - 2021-07-15 17:59:47 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 17:59:47 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 17:59:47 --> Final output sent to browser
DEBUG - 2021-07-15 17:59:47 --> Total execution time: 0.0777
INFO - 2021-07-15 20:55:49 --> Config Class Initialized
INFO - 2021-07-15 20:55:49 --> Hooks Class Initialized
DEBUG - 2021-07-15 20:55:49 --> UTF-8 Support Enabled
INFO - 2021-07-15 20:55:49 --> Utf8 Class Initialized
INFO - 2021-07-15 20:55:49 --> URI Class Initialized
INFO - 2021-07-15 20:55:49 --> Router Class Initialized
INFO - 2021-07-15 20:55:49 --> Output Class Initialized
INFO - 2021-07-15 20:55:49 --> Security Class Initialized
DEBUG - 2021-07-15 20:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 20:55:49 --> Input Class Initialized
INFO - 2021-07-15 20:55:49 --> Language Class Initialized
INFO - 2021-07-15 20:55:49 --> Loader Class Initialized
INFO - 2021-07-15 20:55:49 --> Helper loaded: basic_helper
INFO - 2021-07-15 20:55:49 --> Helper loaded: url_helper
INFO - 2021-07-15 20:55:49 --> Helper loaded: file_helper
INFO - 2021-07-15 20:55:49 --> Helper loaded: form_helper
INFO - 2021-07-15 20:55:49 --> Helper loaded: cookie_helper
INFO - 2021-07-15 20:55:49 --> Helper loaded: security_helper
INFO - 2021-07-15 20:55:49 --> Helper loaded: directory_helper
INFO - 2021-07-15 20:55:49 --> Helper loaded: language_helper
INFO - 2021-07-15 20:55:49 --> Helper loaded: general_helper
INFO - 2021-07-15 20:55:49 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 20:55:49 --> Database Driver Class Initialized
DEBUG - 2021-07-15 20:55:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 20:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 20:55:49 --> Parser Class Initialized
INFO - 2021-07-15 20:55:49 --> Form Validation Class Initialized
INFO - 2021-07-15 20:55:49 --> Upload Class Initialized
INFO - 2021-07-15 20:55:49 --> Email Class Initialized
INFO - 2021-07-15 20:55:49 --> MY_Model class loaded
INFO - 2021-07-15 20:55:49 --> Model "Users_model" initialized
INFO - 2021-07-15 20:55:49 --> Model "Settings_model" initialized
INFO - 2021-07-15 20:55:49 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 20:55:49 --> Model "Permissions_model" initialized
INFO - 2021-07-15 20:55:49 --> Model "Roles_model" initialized
INFO - 2021-07-15 20:55:49 --> Model "Activity_model" initialized
INFO - 2021-07-15 20:55:49 --> Model "Templates_model" initialized
INFO - 2021-07-15 20:55:49 --> Database Driver Class Initialized
INFO - 2021-07-15 20:55:49 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 20:55:49 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 20:55:49 --> Controller Class Initialized
ERROR - 2021-07-15 20:55:49 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 20:55:49 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 20:55:49 --> Final output sent to browser
DEBUG - 2021-07-15 20:55:49 --> Total execution time: 0.1443
INFO - 2021-07-15 21:01:51 --> Config Class Initialized
INFO - 2021-07-15 21:01:51 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:01:51 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:01:51 --> Utf8 Class Initialized
INFO - 2021-07-15 21:01:51 --> URI Class Initialized
INFO - 2021-07-15 21:01:51 --> Router Class Initialized
INFO - 2021-07-15 21:01:51 --> Output Class Initialized
INFO - 2021-07-15 21:01:51 --> Security Class Initialized
DEBUG - 2021-07-15 21:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:01:51 --> Input Class Initialized
INFO - 2021-07-15 21:01:51 --> Language Class Initialized
INFO - 2021-07-15 21:01:51 --> Loader Class Initialized
INFO - 2021-07-15 21:01:51 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:01:51 --> Helper loaded: url_helper
INFO - 2021-07-15 21:01:51 --> Helper loaded: file_helper
INFO - 2021-07-15 21:01:51 --> Helper loaded: form_helper
INFO - 2021-07-15 21:01:51 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:01:51 --> Helper loaded: security_helper
INFO - 2021-07-15 21:01:51 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:01:51 --> Helper loaded: language_helper
INFO - 2021-07-15 21:01:51 --> Helper loaded: general_helper
INFO - 2021-07-15 21:01:52 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:01:52 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:01:52 --> Parser Class Initialized
INFO - 2021-07-15 21:01:52 --> Form Validation Class Initialized
INFO - 2021-07-15 21:01:52 --> Upload Class Initialized
INFO - 2021-07-15 21:01:52 --> Email Class Initialized
INFO - 2021-07-15 21:01:52 --> MY_Model class loaded
INFO - 2021-07-15 21:01:52 --> Model "Users_model" initialized
INFO - 2021-07-15 21:01:52 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:01:52 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:01:52 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:01:52 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:01:52 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:01:52 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:01:52 --> Database Driver Class Initialized
INFO - 2021-07-15 21:01:52 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:01:52 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:01:52 --> Controller Class Initialized
ERROR - 2021-07-15 21:01:52 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 21:01:52 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 21:01:52 --> Final output sent to browser
DEBUG - 2021-07-15 21:01:52 --> Total execution time: 0.1862
INFO - 2021-07-15 21:08:14 --> Config Class Initialized
INFO - 2021-07-15 21:08:14 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:08:14 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:08:14 --> Utf8 Class Initialized
INFO - 2021-07-15 21:08:14 --> URI Class Initialized
INFO - 2021-07-15 21:08:14 --> Router Class Initialized
INFO - 2021-07-15 21:08:14 --> Output Class Initialized
INFO - 2021-07-15 21:08:14 --> Security Class Initialized
DEBUG - 2021-07-15 21:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:08:14 --> Input Class Initialized
INFO - 2021-07-15 21:08:14 --> Language Class Initialized
INFO - 2021-07-15 21:08:14 --> Loader Class Initialized
INFO - 2021-07-15 21:08:14 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:08:14 --> Helper loaded: url_helper
INFO - 2021-07-15 21:08:14 --> Helper loaded: file_helper
INFO - 2021-07-15 21:08:14 --> Helper loaded: form_helper
INFO - 2021-07-15 21:08:14 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:08:14 --> Helper loaded: security_helper
INFO - 2021-07-15 21:08:14 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:08:14 --> Helper loaded: language_helper
INFO - 2021-07-15 21:08:14 --> Helper loaded: general_helper
INFO - 2021-07-15 21:08:14 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:08:14 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:08:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:08:14 --> Parser Class Initialized
INFO - 2021-07-15 21:08:14 --> Form Validation Class Initialized
INFO - 2021-07-15 21:08:14 --> Upload Class Initialized
INFO - 2021-07-15 21:08:14 --> Email Class Initialized
INFO - 2021-07-15 21:08:14 --> MY_Model class loaded
INFO - 2021-07-15 21:08:14 --> Model "Users_model" initialized
INFO - 2021-07-15 21:08:14 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:08:14 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:08:14 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:08:14 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:08:14 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:08:14 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:08:14 --> Database Driver Class Initialized
INFO - 2021-07-15 21:08:14 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:08:14 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:08:14 --> Controller Class Initialized
ERROR - 2021-07-15 21:08:14 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 21:08:14 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 21:08:14 --> Final output sent to browser
DEBUG - 2021-07-15 21:08:14 --> Total execution time: 0.1260
INFO - 2021-07-15 21:08:15 --> Config Class Initialized
INFO - 2021-07-15 21:08:15 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:08:15 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:08:15 --> Utf8 Class Initialized
INFO - 2021-07-15 21:08:15 --> URI Class Initialized
INFO - 2021-07-15 21:08:15 --> Router Class Initialized
INFO - 2021-07-15 21:08:15 --> Output Class Initialized
INFO - 2021-07-15 21:08:15 --> Security Class Initialized
DEBUG - 2021-07-15 21:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:08:15 --> Input Class Initialized
INFO - 2021-07-15 21:08:15 --> Language Class Initialized
INFO - 2021-07-15 21:08:15 --> Loader Class Initialized
INFO - 2021-07-15 21:08:15 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:08:15 --> Helper loaded: url_helper
INFO - 2021-07-15 21:08:15 --> Helper loaded: file_helper
INFO - 2021-07-15 21:08:15 --> Helper loaded: form_helper
INFO - 2021-07-15 21:08:15 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:08:15 --> Helper loaded: security_helper
INFO - 2021-07-15 21:08:15 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:08:15 --> Helper loaded: language_helper
INFO - 2021-07-15 21:08:15 --> Helper loaded: general_helper
INFO - 2021-07-15 21:08:15 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:08:15 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:08:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:08:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:08:15 --> Parser Class Initialized
INFO - 2021-07-15 21:08:15 --> Form Validation Class Initialized
INFO - 2021-07-15 21:08:15 --> Upload Class Initialized
INFO - 2021-07-15 21:08:15 --> Email Class Initialized
INFO - 2021-07-15 21:08:15 --> MY_Model class loaded
INFO - 2021-07-15 21:08:15 --> Model "Users_model" initialized
INFO - 2021-07-15 21:08:15 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:08:15 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:08:15 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:08:15 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:08:15 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:08:15 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:08:15 --> Database Driver Class Initialized
INFO - 2021-07-15 21:08:15 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:08:15 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:08:15 --> Controller Class Initialized
ERROR - 2021-07-15 21:08:15 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 21:08:15 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 21:08:15 --> Final output sent to browser
DEBUG - 2021-07-15 21:08:15 --> Total execution time: 0.0635
INFO - 2021-07-15 21:09:47 --> Config Class Initialized
INFO - 2021-07-15 21:09:47 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:09:47 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:09:47 --> Utf8 Class Initialized
INFO - 2021-07-15 21:09:47 --> URI Class Initialized
INFO - 2021-07-15 21:09:47 --> Router Class Initialized
INFO - 2021-07-15 21:09:47 --> Output Class Initialized
INFO - 2021-07-15 21:09:47 --> Security Class Initialized
DEBUG - 2021-07-15 21:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:09:47 --> Input Class Initialized
INFO - 2021-07-15 21:09:47 --> Language Class Initialized
INFO - 2021-07-15 21:09:47 --> Loader Class Initialized
INFO - 2021-07-15 21:09:47 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:09:47 --> Helper loaded: url_helper
INFO - 2021-07-15 21:09:47 --> Helper loaded: file_helper
INFO - 2021-07-15 21:09:47 --> Helper loaded: form_helper
INFO - 2021-07-15 21:09:47 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:09:47 --> Helper loaded: security_helper
INFO - 2021-07-15 21:09:47 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:09:47 --> Helper loaded: language_helper
INFO - 2021-07-15 21:09:47 --> Helper loaded: general_helper
INFO - 2021-07-15 21:09:47 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:09:47 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:09:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:09:47 --> Parser Class Initialized
INFO - 2021-07-15 21:09:47 --> Form Validation Class Initialized
INFO - 2021-07-15 21:09:47 --> Upload Class Initialized
INFO - 2021-07-15 21:09:47 --> Email Class Initialized
INFO - 2021-07-15 21:09:47 --> MY_Model class loaded
INFO - 2021-07-15 21:09:47 --> Model "Users_model" initialized
INFO - 2021-07-15 21:09:47 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:09:47 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:09:47 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:09:47 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:09:47 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:09:47 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:09:47 --> Database Driver Class Initialized
INFO - 2021-07-15 21:09:48 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:09:48 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:09:48 --> Controller Class Initialized
ERROR - 2021-07-15 21:09:48 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 21:09:48 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 21:09:48 --> Final output sent to browser
DEBUG - 2021-07-15 21:09:48 --> Total execution time: 0.5495
INFO - 2021-07-15 21:09:49 --> Config Class Initialized
INFO - 2021-07-15 21:09:49 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:09:49 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:09:49 --> Utf8 Class Initialized
INFO - 2021-07-15 21:09:49 --> URI Class Initialized
INFO - 2021-07-15 21:09:49 --> Router Class Initialized
INFO - 2021-07-15 21:09:49 --> Output Class Initialized
INFO - 2021-07-15 21:09:49 --> Security Class Initialized
DEBUG - 2021-07-15 21:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:09:49 --> Input Class Initialized
INFO - 2021-07-15 21:09:49 --> Language Class Initialized
INFO - 2021-07-15 21:09:49 --> Loader Class Initialized
INFO - 2021-07-15 21:09:49 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:09:49 --> Helper loaded: url_helper
INFO - 2021-07-15 21:09:49 --> Helper loaded: file_helper
INFO - 2021-07-15 21:09:49 --> Helper loaded: form_helper
INFO - 2021-07-15 21:09:49 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:09:49 --> Helper loaded: security_helper
INFO - 2021-07-15 21:09:49 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:09:49 --> Helper loaded: language_helper
INFO - 2021-07-15 21:09:49 --> Helper loaded: general_helper
INFO - 2021-07-15 21:09:49 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:09:49 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:09:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:09:49 --> Parser Class Initialized
INFO - 2021-07-15 21:09:49 --> Form Validation Class Initialized
INFO - 2021-07-15 21:09:49 --> Upload Class Initialized
INFO - 2021-07-15 21:09:49 --> Email Class Initialized
INFO - 2021-07-15 21:09:49 --> MY_Model class loaded
INFO - 2021-07-15 21:09:49 --> Model "Users_model" initialized
INFO - 2021-07-15 21:09:49 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:09:49 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:09:49 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:09:49 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:09:49 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:09:49 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:09:49 --> Database Driver Class Initialized
INFO - 2021-07-15 21:09:49 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:09:49 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:09:49 --> Controller Class Initialized
ERROR - 2021-07-15 21:09:49 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 21:09:49 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 21:09:49 --> Final output sent to browser
DEBUG - 2021-07-15 21:09:49 --> Total execution time: 0.0637
INFO - 2021-07-15 21:13:49 --> Config Class Initialized
INFO - 2021-07-15 21:13:49 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:13:49 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:13:49 --> Utf8 Class Initialized
INFO - 2021-07-15 21:13:49 --> URI Class Initialized
INFO - 2021-07-15 21:13:49 --> Router Class Initialized
INFO - 2021-07-15 21:13:49 --> Output Class Initialized
INFO - 2021-07-15 21:13:49 --> Security Class Initialized
DEBUG - 2021-07-15 21:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:13:49 --> Input Class Initialized
INFO - 2021-07-15 21:13:49 --> Language Class Initialized
INFO - 2021-07-15 21:13:49 --> Loader Class Initialized
INFO - 2021-07-15 21:13:49 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:13:49 --> Helper loaded: url_helper
INFO - 2021-07-15 21:13:49 --> Helper loaded: file_helper
INFO - 2021-07-15 21:13:49 --> Helper loaded: form_helper
INFO - 2021-07-15 21:13:49 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:13:49 --> Helper loaded: security_helper
INFO - 2021-07-15 21:13:49 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:13:49 --> Helper loaded: language_helper
INFO - 2021-07-15 21:13:49 --> Helper loaded: general_helper
INFO - 2021-07-15 21:13:49 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:13:49 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:13:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:13:49 --> Parser Class Initialized
INFO - 2021-07-15 21:13:49 --> Form Validation Class Initialized
INFO - 2021-07-15 21:13:49 --> Upload Class Initialized
INFO - 2021-07-15 21:13:49 --> Email Class Initialized
INFO - 2021-07-15 21:13:49 --> MY_Model class loaded
INFO - 2021-07-15 21:13:49 --> Model "Users_model" initialized
INFO - 2021-07-15 21:13:49 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:13:49 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:13:49 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:13:49 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:13:49 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:13:49 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:13:49 --> Database Driver Class Initialized
INFO - 2021-07-15 21:13:50 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:13:50 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:13:50 --> Controller Class Initialized
ERROR - 2021-07-15 21:13:50 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 21:13:50 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 21:13:50 --> Final output sent to browser
DEBUG - 2021-07-15 21:13:50 --> Total execution time: 0.1459
INFO - 2021-07-15 21:14:34 --> Config Class Initialized
INFO - 2021-07-15 21:14:34 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:14:34 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:14:34 --> Utf8 Class Initialized
INFO - 2021-07-15 21:14:34 --> URI Class Initialized
INFO - 2021-07-15 21:14:34 --> Router Class Initialized
INFO - 2021-07-15 21:14:34 --> Output Class Initialized
INFO - 2021-07-15 21:14:34 --> Security Class Initialized
DEBUG - 2021-07-15 21:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:14:34 --> Input Class Initialized
INFO - 2021-07-15 21:14:34 --> Language Class Initialized
INFO - 2021-07-15 21:14:34 --> Loader Class Initialized
INFO - 2021-07-15 21:14:34 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:14:34 --> Helper loaded: url_helper
INFO - 2021-07-15 21:14:34 --> Helper loaded: file_helper
INFO - 2021-07-15 21:14:34 --> Helper loaded: form_helper
INFO - 2021-07-15 21:14:34 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:14:34 --> Helper loaded: security_helper
INFO - 2021-07-15 21:14:34 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:14:34 --> Helper loaded: language_helper
INFO - 2021-07-15 21:14:34 --> Helper loaded: general_helper
INFO - 2021-07-15 21:14:34 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:14:34 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:14:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:14:34 --> Parser Class Initialized
INFO - 2021-07-15 21:14:34 --> Form Validation Class Initialized
INFO - 2021-07-15 21:14:34 --> Upload Class Initialized
INFO - 2021-07-15 21:14:34 --> Email Class Initialized
INFO - 2021-07-15 21:14:34 --> MY_Model class loaded
INFO - 2021-07-15 21:14:34 --> Model "Users_model" initialized
INFO - 2021-07-15 21:14:34 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:14:34 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:14:34 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:14:34 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:14:34 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:14:34 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:14:34 --> Database Driver Class Initialized
INFO - 2021-07-15 21:14:35 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:14:35 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:14:35 --> Controller Class Initialized
ERROR - 2021-07-15 21:14:35 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 21:14:35 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 21:14:35 --> Final output sent to browser
DEBUG - 2021-07-15 21:14:35 --> Total execution time: 0.1256
INFO - 2021-07-15 21:15:28 --> Config Class Initialized
INFO - 2021-07-15 21:15:28 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:15:28 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:15:28 --> Utf8 Class Initialized
INFO - 2021-07-15 21:15:28 --> URI Class Initialized
INFO - 2021-07-15 21:15:28 --> Router Class Initialized
INFO - 2021-07-15 21:15:28 --> Output Class Initialized
INFO - 2021-07-15 21:15:28 --> Security Class Initialized
DEBUG - 2021-07-15 21:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:15:28 --> Input Class Initialized
INFO - 2021-07-15 21:15:28 --> Language Class Initialized
INFO - 2021-07-15 21:15:28 --> Loader Class Initialized
INFO - 2021-07-15 21:15:28 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:15:28 --> Helper loaded: url_helper
INFO - 2021-07-15 21:15:28 --> Helper loaded: file_helper
INFO - 2021-07-15 21:15:28 --> Helper loaded: form_helper
INFO - 2021-07-15 21:15:28 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:15:28 --> Helper loaded: security_helper
INFO - 2021-07-15 21:15:28 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:15:28 --> Helper loaded: language_helper
INFO - 2021-07-15 21:15:28 --> Helper loaded: general_helper
INFO - 2021-07-15 21:15:28 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:15:28 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:15:28 --> Parser Class Initialized
INFO - 2021-07-15 21:15:28 --> Form Validation Class Initialized
INFO - 2021-07-15 21:15:28 --> Upload Class Initialized
INFO - 2021-07-15 21:15:28 --> Email Class Initialized
INFO - 2021-07-15 21:15:28 --> MY_Model class loaded
INFO - 2021-07-15 21:15:28 --> Model "Users_model" initialized
INFO - 2021-07-15 21:15:28 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:15:28 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:15:28 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:15:28 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:15:28 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:15:28 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:15:28 --> Database Driver Class Initialized
INFO - 2021-07-15 21:15:28 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:15:28 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:15:28 --> Controller Class Initialized
ERROR - 2021-07-15 21:15:28 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 21:15:28 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 21:15:28 --> Final output sent to browser
DEBUG - 2021-07-15 21:15:28 --> Total execution time: 0.1368
INFO - 2021-07-15 21:16:02 --> Config Class Initialized
INFO - 2021-07-15 21:16:02 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:16:02 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:16:02 --> Utf8 Class Initialized
INFO - 2021-07-15 21:16:02 --> URI Class Initialized
INFO - 2021-07-15 21:16:02 --> Router Class Initialized
INFO - 2021-07-15 21:16:02 --> Output Class Initialized
INFO - 2021-07-15 21:16:02 --> Security Class Initialized
DEBUG - 2021-07-15 21:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:16:02 --> Input Class Initialized
INFO - 2021-07-15 21:16:02 --> Language Class Initialized
INFO - 2021-07-15 21:16:02 --> Loader Class Initialized
INFO - 2021-07-15 21:16:02 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:16:02 --> Helper loaded: url_helper
INFO - 2021-07-15 21:16:02 --> Helper loaded: file_helper
INFO - 2021-07-15 21:16:02 --> Helper loaded: form_helper
INFO - 2021-07-15 21:16:02 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:16:02 --> Helper loaded: security_helper
INFO - 2021-07-15 21:16:02 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:16:02 --> Helper loaded: language_helper
INFO - 2021-07-15 21:16:02 --> Helper loaded: general_helper
INFO - 2021-07-15 21:16:02 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:16:02 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:16:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:16:02 --> Parser Class Initialized
INFO - 2021-07-15 21:16:02 --> Form Validation Class Initialized
INFO - 2021-07-15 21:16:02 --> Upload Class Initialized
INFO - 2021-07-15 21:16:02 --> Email Class Initialized
INFO - 2021-07-15 21:16:02 --> MY_Model class loaded
INFO - 2021-07-15 21:16:02 --> Model "Users_model" initialized
INFO - 2021-07-15 21:16:02 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:16:02 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:16:02 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:16:02 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:16:02 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:16:02 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:16:02 --> Database Driver Class Initialized
INFO - 2021-07-15 21:16:02 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:16:02 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:16:02 --> Controller Class Initialized
ERROR - 2021-07-15 21:16:02 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 21:16:02 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 21:16:02 --> Final output sent to browser
DEBUG - 2021-07-15 21:16:02 --> Total execution time: 0.1320
INFO - 2021-07-15 21:21:15 --> Config Class Initialized
INFO - 2021-07-15 21:21:15 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:21:15 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:21:15 --> Utf8 Class Initialized
INFO - 2021-07-15 21:21:15 --> URI Class Initialized
INFO - 2021-07-15 21:21:15 --> Router Class Initialized
INFO - 2021-07-15 21:21:15 --> Output Class Initialized
INFO - 2021-07-15 21:21:15 --> Security Class Initialized
DEBUG - 2021-07-15 21:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:21:15 --> Input Class Initialized
INFO - 2021-07-15 21:21:15 --> Language Class Initialized
INFO - 2021-07-15 21:21:15 --> Loader Class Initialized
INFO - 2021-07-15 21:21:15 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:21:15 --> Helper loaded: url_helper
INFO - 2021-07-15 21:21:15 --> Helper loaded: file_helper
INFO - 2021-07-15 21:21:15 --> Helper loaded: form_helper
INFO - 2021-07-15 21:21:15 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:21:15 --> Helper loaded: security_helper
INFO - 2021-07-15 21:21:15 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:21:15 --> Helper loaded: language_helper
INFO - 2021-07-15 21:21:15 --> Helper loaded: general_helper
INFO - 2021-07-15 21:21:15 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:21:15 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:21:15 --> Parser Class Initialized
INFO - 2021-07-15 21:21:15 --> Form Validation Class Initialized
INFO - 2021-07-15 21:21:15 --> Upload Class Initialized
INFO - 2021-07-15 21:21:15 --> Email Class Initialized
INFO - 2021-07-15 21:21:15 --> MY_Model class loaded
INFO - 2021-07-15 21:21:15 --> Model "Users_model" initialized
INFO - 2021-07-15 21:21:15 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:21:15 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:21:15 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:21:15 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:21:15 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:21:15 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:21:15 --> Database Driver Class Initialized
INFO - 2021-07-15 21:21:15 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:21:15 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:21:15 --> Controller Class Initialized
INFO - 2021-07-15 21:21:15 --> Config Class Initialized
INFO - 2021-07-15 21:21:15 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:21:15 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:21:15 --> Utf8 Class Initialized
INFO - 2021-07-15 21:21:15 --> URI Class Initialized
INFO - 2021-07-15 21:21:15 --> Router Class Initialized
INFO - 2021-07-15 21:21:15 --> Output Class Initialized
INFO - 2021-07-15 21:21:15 --> Security Class Initialized
DEBUG - 2021-07-15 21:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:21:15 --> Input Class Initialized
INFO - 2021-07-15 21:21:15 --> Language Class Initialized
INFO - 2021-07-15 21:21:15 --> Loader Class Initialized
INFO - 2021-07-15 21:21:15 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:21:15 --> Helper loaded: url_helper
INFO - 2021-07-15 21:21:15 --> Helper loaded: file_helper
INFO - 2021-07-15 21:21:15 --> Helper loaded: form_helper
INFO - 2021-07-15 21:21:15 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:21:15 --> Helper loaded: security_helper
INFO - 2021-07-15 21:21:15 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:21:15 --> Helper loaded: language_helper
INFO - 2021-07-15 21:21:15 --> Helper loaded: general_helper
INFO - 2021-07-15 21:21:15 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:21:15 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:21:15 --> Parser Class Initialized
INFO - 2021-07-15 21:21:15 --> Form Validation Class Initialized
INFO - 2021-07-15 21:21:15 --> Upload Class Initialized
INFO - 2021-07-15 21:21:15 --> Email Class Initialized
INFO - 2021-07-15 21:21:15 --> MY_Model class loaded
INFO - 2021-07-15 21:21:15 --> Model "Users_model" initialized
INFO - 2021-07-15 21:21:15 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:21:15 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:21:15 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:21:15 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:21:15 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:21:15 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:21:15 --> Database Driver Class Initialized
INFO - 2021-07-15 21:21:15 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:21:15 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:21:15 --> Controller Class Initialized
INFO - 2021-07-15 21:21:15 --> File loaded: C:\wamp64\www\crm\application\views\account/login.php
INFO - 2021-07-15 21:21:15 --> Final output sent to browser
DEBUG - 2021-07-15 21:21:15 --> Total execution time: 0.0464
INFO - 2021-07-15 21:21:15 --> Config Class Initialized
INFO - 2021-07-15 21:21:15 --> Hooks Class Initialized
INFO - 2021-07-15 21:21:15 --> Config Class Initialized
INFO - 2021-07-15 21:21:15 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:21:15 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:21:15 --> Utf8 Class Initialized
DEBUG - 2021-07-15 21:21:15 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:21:15 --> Utf8 Class Initialized
INFO - 2021-07-15 21:21:15 --> URI Class Initialized
INFO - 2021-07-15 21:21:15 --> URI Class Initialized
INFO - 2021-07-15 21:21:15 --> Router Class Initialized
INFO - 2021-07-15 21:21:15 --> Router Class Initialized
INFO - 2021-07-15 21:21:15 --> Output Class Initialized
INFO - 2021-07-15 21:21:15 --> Output Class Initialized
INFO - 2021-07-15 21:21:15 --> Security Class Initialized
INFO - 2021-07-15 21:21:15 --> Security Class Initialized
DEBUG - 2021-07-15 21:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:21:15 --> Input Class Initialized
DEBUG - 2021-07-15 21:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:21:15 --> Input Class Initialized
INFO - 2021-07-15 21:21:15 --> Language Class Initialized
INFO - 2021-07-15 21:21:15 --> Language Class Initialized
ERROR - 2021-07-15 21:21:15 --> 404 Page Not Found: Assets/jquery
ERROR - 2021-07-15 21:21:15 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-15 21:21:15 --> Config Class Initialized
INFO - 2021-07-15 21:21:15 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:21:15 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:21:15 --> Utf8 Class Initialized
INFO - 2021-07-15 21:21:15 --> URI Class Initialized
INFO - 2021-07-15 21:21:15 --> Router Class Initialized
INFO - 2021-07-15 21:21:15 --> Output Class Initialized
INFO - 2021-07-15 21:21:15 --> Security Class Initialized
DEBUG - 2021-07-15 21:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:21:15 --> Input Class Initialized
INFO - 2021-07-15 21:21:15 --> Language Class Initialized
ERROR - 2021-07-15 21:21:15 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-15 21:21:17 --> Config Class Initialized
INFO - 2021-07-15 21:21:17 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:21:17 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:21:17 --> Utf8 Class Initialized
INFO - 2021-07-15 21:21:17 --> URI Class Initialized
INFO - 2021-07-15 21:21:17 --> Router Class Initialized
INFO - 2021-07-15 21:21:17 --> Output Class Initialized
INFO - 2021-07-15 21:21:17 --> Security Class Initialized
DEBUG - 2021-07-15 21:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:21:17 --> Input Class Initialized
INFO - 2021-07-15 21:21:17 --> Language Class Initialized
INFO - 2021-07-15 21:21:17 --> Loader Class Initialized
INFO - 2021-07-15 21:21:17 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:21:17 --> Helper loaded: url_helper
INFO - 2021-07-15 21:21:17 --> Helper loaded: file_helper
INFO - 2021-07-15 21:21:17 --> Helper loaded: form_helper
INFO - 2021-07-15 21:21:17 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:21:17 --> Helper loaded: security_helper
INFO - 2021-07-15 21:21:17 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:21:17 --> Helper loaded: language_helper
INFO - 2021-07-15 21:21:17 --> Helper loaded: general_helper
INFO - 2021-07-15 21:21:17 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:21:17 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:21:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:21:17 --> Parser Class Initialized
INFO - 2021-07-15 21:21:17 --> Form Validation Class Initialized
INFO - 2021-07-15 21:21:17 --> Upload Class Initialized
INFO - 2021-07-15 21:21:17 --> Email Class Initialized
INFO - 2021-07-15 21:21:17 --> MY_Model class loaded
INFO - 2021-07-15 21:21:17 --> Model "Users_model" initialized
INFO - 2021-07-15 21:21:17 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:21:17 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:21:17 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:21:17 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:21:17 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:21:17 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:21:17 --> Database Driver Class Initialized
INFO - 2021-07-15 21:21:17 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:21:17 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:21:17 --> Controller Class Initialized
DEBUG - 2021-07-15 21:21:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-15 21:21:17 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2021-07-15 21:21:17 --> Config Class Initialized
INFO - 2021-07-15 21:21:17 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:21:17 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:21:17 --> Utf8 Class Initialized
INFO - 2021-07-15 21:21:17 --> URI Class Initialized
DEBUG - 2021-07-15 21:21:17 --> No URI present. Default controller set.
INFO - 2021-07-15 21:21:17 --> Router Class Initialized
INFO - 2021-07-15 21:21:17 --> Output Class Initialized
INFO - 2021-07-15 21:21:17 --> Security Class Initialized
DEBUG - 2021-07-15 21:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:21:17 --> Input Class Initialized
INFO - 2021-07-15 21:21:17 --> Language Class Initialized
INFO - 2021-07-15 21:21:17 --> Loader Class Initialized
INFO - 2021-07-15 21:21:17 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:21:17 --> Helper loaded: url_helper
INFO - 2021-07-15 21:21:17 --> Helper loaded: file_helper
INFO - 2021-07-15 21:21:17 --> Helper loaded: form_helper
INFO - 2021-07-15 21:21:17 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:21:17 --> Helper loaded: security_helper
INFO - 2021-07-15 21:21:17 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:21:17 --> Helper loaded: language_helper
INFO - 2021-07-15 21:21:17 --> Helper loaded: general_helper
INFO - 2021-07-15 21:21:17 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:21:17 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:21:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:21:17 --> Parser Class Initialized
INFO - 2021-07-15 21:21:17 --> Form Validation Class Initialized
INFO - 2021-07-15 21:21:17 --> Upload Class Initialized
INFO - 2021-07-15 21:21:17 --> Email Class Initialized
INFO - 2021-07-15 21:21:17 --> MY_Model class loaded
INFO - 2021-07-15 21:21:17 --> Model "Users_model" initialized
INFO - 2021-07-15 21:21:17 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:21:17 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:21:17 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:21:17 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:21:17 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:21:17 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:21:17 --> Database Driver Class Initialized
INFO - 2021-07-15 21:21:17 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:21:17 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:21:17 --> Controller Class Initialized
ERROR - 2021-07-15 21:21:17 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 21:21:17 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-15 21:21:17 --> Final output sent to browser
DEBUG - 2021-07-15 21:21:17 --> Total execution time: 0.0592
INFO - 2021-07-15 21:21:19 --> Config Class Initialized
INFO - 2021-07-15 21:21:19 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:21:19 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:21:19 --> Utf8 Class Initialized
INFO - 2021-07-15 21:21:19 --> URI Class Initialized
INFO - 2021-07-15 21:21:19 --> Router Class Initialized
INFO - 2021-07-15 21:21:19 --> Output Class Initialized
INFO - 2021-07-15 21:21:19 --> Security Class Initialized
DEBUG - 2021-07-15 21:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:21:19 --> Input Class Initialized
INFO - 2021-07-15 21:21:19 --> Language Class Initialized
INFO - 2021-07-15 21:21:19 --> Loader Class Initialized
INFO - 2021-07-15 21:21:19 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:21:19 --> Helper loaded: url_helper
INFO - 2021-07-15 21:21:19 --> Helper loaded: file_helper
INFO - 2021-07-15 21:21:19 --> Helper loaded: form_helper
INFO - 2021-07-15 21:21:19 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:21:19 --> Helper loaded: security_helper
INFO - 2021-07-15 21:21:19 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:21:19 --> Helper loaded: language_helper
INFO - 2021-07-15 21:21:19 --> Helper loaded: general_helper
INFO - 2021-07-15 21:21:19 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:21:19 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:21:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:21:19 --> Parser Class Initialized
INFO - 2021-07-15 21:21:19 --> Form Validation Class Initialized
INFO - 2021-07-15 21:21:19 --> Upload Class Initialized
INFO - 2021-07-15 21:21:19 --> Email Class Initialized
INFO - 2021-07-15 21:21:19 --> MY_Model class loaded
INFO - 2021-07-15 21:21:19 --> Model "Users_model" initialized
INFO - 2021-07-15 21:21:19 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:21:19 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:21:19 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:21:19 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:21:19 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:21:19 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:21:19 --> Database Driver Class Initialized
INFO - 2021-07-15 21:21:19 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:21:19 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:21:19 --> Controller Class Initialized
ERROR - 2021-07-15 21:21:19 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 21:21:19 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 21:21:19 --> Final output sent to browser
DEBUG - 2021-07-15 21:21:19 --> Total execution time: 0.0822
INFO - 2021-07-15 21:22:05 --> Config Class Initialized
INFO - 2021-07-15 21:22:05 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:22:05 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:22:05 --> Utf8 Class Initialized
INFO - 2021-07-15 21:22:05 --> URI Class Initialized
INFO - 2021-07-15 21:22:05 --> Router Class Initialized
INFO - 2021-07-15 21:22:05 --> Output Class Initialized
INFO - 2021-07-15 21:22:05 --> Security Class Initialized
DEBUG - 2021-07-15 21:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:22:05 --> Input Class Initialized
INFO - 2021-07-15 21:22:05 --> Language Class Initialized
INFO - 2021-07-15 21:22:05 --> Loader Class Initialized
INFO - 2021-07-15 21:22:05 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:22:05 --> Helper loaded: url_helper
INFO - 2021-07-15 21:22:05 --> Helper loaded: file_helper
INFO - 2021-07-15 21:22:05 --> Helper loaded: form_helper
INFO - 2021-07-15 21:22:05 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:22:05 --> Helper loaded: security_helper
INFO - 2021-07-15 21:22:05 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:22:05 --> Helper loaded: language_helper
INFO - 2021-07-15 21:22:05 --> Helper loaded: general_helper
INFO - 2021-07-15 21:22:05 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:22:05 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:22:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:22:05 --> Parser Class Initialized
INFO - 2021-07-15 21:22:05 --> Form Validation Class Initialized
INFO - 2021-07-15 21:22:05 --> Upload Class Initialized
INFO - 2021-07-15 21:22:05 --> Email Class Initialized
INFO - 2021-07-15 21:22:05 --> MY_Model class loaded
INFO - 2021-07-15 21:22:05 --> Model "Users_model" initialized
INFO - 2021-07-15 21:22:05 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:22:05 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:22:05 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:22:05 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:22:05 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:22:05 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:22:05 --> Database Driver Class Initialized
INFO - 2021-07-15 21:22:05 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:22:05 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:22:05 --> Controller Class Initialized
ERROR - 2021-07-15 21:22:05 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 21:22:05 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 21:22:05 --> Final output sent to browser
DEBUG - 2021-07-15 21:22:05 --> Total execution time: 0.1274
INFO - 2021-07-15 21:22:10 --> Config Class Initialized
INFO - 2021-07-15 21:22:10 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:22:10 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:22:10 --> Utf8 Class Initialized
INFO - 2021-07-15 21:22:10 --> URI Class Initialized
INFO - 2021-07-15 21:22:10 --> Router Class Initialized
INFO - 2021-07-15 21:22:10 --> Output Class Initialized
INFO - 2021-07-15 21:22:10 --> Security Class Initialized
DEBUG - 2021-07-15 21:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:22:10 --> Input Class Initialized
INFO - 2021-07-15 21:22:10 --> Language Class Initialized
INFO - 2021-07-15 21:22:10 --> Loader Class Initialized
INFO - 2021-07-15 21:22:10 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:22:10 --> Helper loaded: url_helper
INFO - 2021-07-15 21:22:10 --> Helper loaded: file_helper
INFO - 2021-07-15 21:22:10 --> Helper loaded: form_helper
INFO - 2021-07-15 21:22:10 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:22:10 --> Helper loaded: security_helper
INFO - 2021-07-15 21:22:10 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:22:10 --> Helper loaded: language_helper
INFO - 2021-07-15 21:22:10 --> Helper loaded: general_helper
INFO - 2021-07-15 21:22:10 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:22:10 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:22:10 --> Parser Class Initialized
INFO - 2021-07-15 21:22:10 --> Form Validation Class Initialized
INFO - 2021-07-15 21:22:10 --> Upload Class Initialized
INFO - 2021-07-15 21:22:10 --> Email Class Initialized
INFO - 2021-07-15 21:22:10 --> MY_Model class loaded
INFO - 2021-07-15 21:22:10 --> Model "Users_model" initialized
INFO - 2021-07-15 21:22:10 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:22:10 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:22:10 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:22:10 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:22:10 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:22:10 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:22:10 --> Database Driver Class Initialized
INFO - 2021-07-15 21:22:10 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:22:10 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:22:10 --> Controller Class Initialized
ERROR - 2021-07-15 21:22:10 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 21:22:10 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 21:22:10 --> Final output sent to browser
DEBUG - 2021-07-15 21:22:10 --> Total execution time: 0.1221
INFO - 2021-07-15 21:26:05 --> Config Class Initialized
INFO - 2021-07-15 21:26:05 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:26:05 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:26:05 --> Utf8 Class Initialized
INFO - 2021-07-15 21:26:05 --> URI Class Initialized
INFO - 2021-07-15 21:26:05 --> Router Class Initialized
INFO - 2021-07-15 21:26:05 --> Output Class Initialized
INFO - 2021-07-15 21:26:05 --> Security Class Initialized
DEBUG - 2021-07-15 21:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:26:05 --> Input Class Initialized
INFO - 2021-07-15 21:26:05 --> Language Class Initialized
INFO - 2021-07-15 21:26:05 --> Loader Class Initialized
INFO - 2021-07-15 21:26:05 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:26:05 --> Helper loaded: url_helper
INFO - 2021-07-15 21:26:05 --> Helper loaded: file_helper
INFO - 2021-07-15 21:26:05 --> Helper loaded: form_helper
INFO - 2021-07-15 21:26:05 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:26:05 --> Helper loaded: security_helper
INFO - 2021-07-15 21:26:05 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:26:05 --> Helper loaded: language_helper
INFO - 2021-07-15 21:26:05 --> Helper loaded: general_helper
INFO - 2021-07-15 21:26:05 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:26:05 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:26:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:26:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:26:05 --> Parser Class Initialized
INFO - 2021-07-15 21:26:05 --> Form Validation Class Initialized
INFO - 2021-07-15 21:26:05 --> Upload Class Initialized
INFO - 2021-07-15 21:26:05 --> Email Class Initialized
INFO - 2021-07-15 21:26:05 --> MY_Model class loaded
INFO - 2021-07-15 21:26:05 --> Model "Users_model" initialized
INFO - 2021-07-15 21:26:05 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:26:05 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:26:05 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:26:05 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:26:05 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:26:05 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:26:05 --> Database Driver Class Initialized
INFO - 2021-07-15 21:26:05 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:26:05 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:26:05 --> Controller Class Initialized
ERROR - 2021-07-15 21:26:05 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 21:26:05 --> File loaded: C:\wamp64\www\crm\application\views\permissions/list.php
INFO - 2021-07-15 21:26:05 --> Final output sent to browser
DEBUG - 2021-07-15 21:26:05 --> Total execution time: 0.2025
INFO - 2021-07-15 21:26:25 --> Config Class Initialized
INFO - 2021-07-15 21:26:25 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:26:25 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:26:25 --> Utf8 Class Initialized
INFO - 2021-07-15 21:26:25 --> URI Class Initialized
INFO - 2021-07-15 21:26:25 --> Router Class Initialized
INFO - 2021-07-15 21:26:25 --> Output Class Initialized
INFO - 2021-07-15 21:26:25 --> Security Class Initialized
DEBUG - 2021-07-15 21:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:26:25 --> Input Class Initialized
INFO - 2021-07-15 21:26:25 --> Language Class Initialized
INFO - 2021-07-15 21:26:25 --> Loader Class Initialized
INFO - 2021-07-15 21:26:25 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:26:25 --> Helper loaded: url_helper
INFO - 2021-07-15 21:26:25 --> Helper loaded: file_helper
INFO - 2021-07-15 21:26:25 --> Helper loaded: form_helper
INFO - 2021-07-15 21:26:25 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:26:25 --> Helper loaded: security_helper
INFO - 2021-07-15 21:26:25 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:26:25 --> Helper loaded: language_helper
INFO - 2021-07-15 21:26:25 --> Helper loaded: general_helper
INFO - 2021-07-15 21:26:25 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:26:25 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:26:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:26:25 --> Parser Class Initialized
INFO - 2021-07-15 21:26:25 --> Form Validation Class Initialized
INFO - 2021-07-15 21:26:25 --> Upload Class Initialized
INFO - 2021-07-15 21:26:25 --> Email Class Initialized
INFO - 2021-07-15 21:26:25 --> MY_Model class loaded
INFO - 2021-07-15 21:26:25 --> Model "Users_model" initialized
INFO - 2021-07-15 21:26:25 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:26:25 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:26:25 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:26:25 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:26:25 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:26:25 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:26:25 --> Database Driver Class Initialized
INFO - 2021-07-15 21:26:25 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:26:25 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:26:25 --> Controller Class Initialized
ERROR - 2021-07-15 21:26:25 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 21:26:25 --> File loaded: C:\wamp64\www\crm\application\views\permissions/add.php
INFO - 2021-07-15 21:26:25 --> Final output sent to browser
DEBUG - 2021-07-15 21:26:25 --> Total execution time: 0.1255
INFO - 2021-07-15 21:27:04 --> Config Class Initialized
INFO - 2021-07-15 21:27:04 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:27:04 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:27:04 --> Utf8 Class Initialized
INFO - 2021-07-15 21:27:04 --> URI Class Initialized
INFO - 2021-07-15 21:27:04 --> Router Class Initialized
INFO - 2021-07-15 21:27:04 --> Output Class Initialized
INFO - 2021-07-15 21:27:04 --> Security Class Initialized
DEBUG - 2021-07-15 21:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:27:04 --> Input Class Initialized
INFO - 2021-07-15 21:27:04 --> Language Class Initialized
INFO - 2021-07-15 21:27:04 --> Loader Class Initialized
INFO - 2021-07-15 21:27:04 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:27:04 --> Helper loaded: url_helper
INFO - 2021-07-15 21:27:04 --> Helper loaded: file_helper
INFO - 2021-07-15 21:27:04 --> Helper loaded: form_helper
INFO - 2021-07-15 21:27:04 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:27:04 --> Helper loaded: security_helper
INFO - 2021-07-15 21:27:04 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:27:04 --> Helper loaded: language_helper
INFO - 2021-07-15 21:27:04 --> Helper loaded: general_helper
INFO - 2021-07-15 21:27:04 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:27:04 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:27:04 --> Parser Class Initialized
INFO - 2021-07-15 21:27:04 --> Form Validation Class Initialized
INFO - 2021-07-15 21:27:04 --> Upload Class Initialized
INFO - 2021-07-15 21:27:04 --> Email Class Initialized
INFO - 2021-07-15 21:27:04 --> MY_Model class loaded
INFO - 2021-07-15 21:27:04 --> Model "Users_model" initialized
INFO - 2021-07-15 21:27:04 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:27:04 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:27:04 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:27:04 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:27:04 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:27:04 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:27:04 --> Database Driver Class Initialized
INFO - 2021-07-15 21:27:05 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:27:05 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:27:05 --> Controller Class Initialized
INFO - 2021-07-15 21:28:01 --> Config Class Initialized
INFO - 2021-07-15 21:28:01 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:28:01 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:28:01 --> Utf8 Class Initialized
INFO - 2021-07-15 21:28:01 --> URI Class Initialized
INFO - 2021-07-15 21:28:01 --> Router Class Initialized
INFO - 2021-07-15 21:28:01 --> Output Class Initialized
INFO - 2021-07-15 21:28:01 --> Security Class Initialized
DEBUG - 2021-07-15 21:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:28:01 --> Input Class Initialized
INFO - 2021-07-15 21:28:01 --> Language Class Initialized
INFO - 2021-07-15 21:28:01 --> Loader Class Initialized
INFO - 2021-07-15 21:28:01 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:28:01 --> Helper loaded: url_helper
INFO - 2021-07-15 21:28:01 --> Helper loaded: file_helper
INFO - 2021-07-15 21:28:01 --> Helper loaded: form_helper
INFO - 2021-07-15 21:28:01 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:28:01 --> Helper loaded: security_helper
INFO - 2021-07-15 21:28:01 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:28:01 --> Helper loaded: language_helper
INFO - 2021-07-15 21:28:01 --> Helper loaded: general_helper
INFO - 2021-07-15 21:28:01 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:28:01 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:28:01 --> Parser Class Initialized
INFO - 2021-07-15 21:28:01 --> Form Validation Class Initialized
INFO - 2021-07-15 21:28:01 --> Upload Class Initialized
INFO - 2021-07-15 21:28:01 --> Email Class Initialized
INFO - 2021-07-15 21:28:01 --> MY_Model class loaded
INFO - 2021-07-15 21:28:01 --> Model "Users_model" initialized
INFO - 2021-07-15 21:28:01 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:28:01 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:28:01 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:28:01 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:28:01 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:28:01 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:28:01 --> Database Driver Class Initialized
INFO - 2021-07-15 21:28:01 --> Model "Hesaplar_model" initialized
ERROR - 2021-07-15 21:28:01 --> Severity: error --> Exception: syntax error, unexpected '}' C:\wamp64\www\crm\application\models\Car_activity_model.php 74
INFO - 2021-07-15 21:28:24 --> Config Class Initialized
INFO - 2021-07-15 21:28:24 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:28:24 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:28:24 --> Utf8 Class Initialized
INFO - 2021-07-15 21:28:24 --> URI Class Initialized
INFO - 2021-07-15 21:28:24 --> Router Class Initialized
INFO - 2021-07-15 21:28:24 --> Output Class Initialized
INFO - 2021-07-15 21:28:24 --> Security Class Initialized
DEBUG - 2021-07-15 21:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:28:24 --> Input Class Initialized
INFO - 2021-07-15 21:28:24 --> Language Class Initialized
INFO - 2021-07-15 21:28:24 --> Loader Class Initialized
INFO - 2021-07-15 21:28:24 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:28:24 --> Helper loaded: url_helper
INFO - 2021-07-15 21:28:24 --> Helper loaded: file_helper
INFO - 2021-07-15 21:28:24 --> Helper loaded: form_helper
INFO - 2021-07-15 21:28:24 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:28:24 --> Helper loaded: security_helper
INFO - 2021-07-15 21:28:24 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:28:24 --> Helper loaded: language_helper
INFO - 2021-07-15 21:28:24 --> Helper loaded: general_helper
INFO - 2021-07-15 21:28:24 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:28:24 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:28:24 --> Parser Class Initialized
INFO - 2021-07-15 21:28:24 --> Form Validation Class Initialized
INFO - 2021-07-15 21:28:24 --> Upload Class Initialized
INFO - 2021-07-15 21:28:24 --> Email Class Initialized
INFO - 2021-07-15 21:28:24 --> MY_Model class loaded
INFO - 2021-07-15 21:28:24 --> Model "Users_model" initialized
INFO - 2021-07-15 21:28:24 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:28:24 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:28:24 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:28:24 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:28:24 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:28:24 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:28:24 --> Database Driver Class Initialized
INFO - 2021-07-15 21:28:24 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:28:24 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:28:24 --> Controller Class Initialized
INFO - 2021-07-15 21:28:24 --> Config Class Initialized
INFO - 2021-07-15 21:28:24 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:28:24 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:28:24 --> Utf8 Class Initialized
INFO - 2021-07-15 21:28:24 --> URI Class Initialized
INFO - 2021-07-15 21:28:24 --> Router Class Initialized
INFO - 2021-07-15 21:28:24 --> Output Class Initialized
INFO - 2021-07-15 21:28:24 --> Security Class Initialized
DEBUG - 2021-07-15 21:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:28:24 --> Input Class Initialized
INFO - 2021-07-15 21:28:24 --> Language Class Initialized
INFO - 2021-07-15 21:28:24 --> Loader Class Initialized
INFO - 2021-07-15 21:28:24 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:28:24 --> Helper loaded: url_helper
INFO - 2021-07-15 21:28:24 --> Helper loaded: file_helper
INFO - 2021-07-15 21:28:24 --> Helper loaded: form_helper
INFO - 2021-07-15 21:28:24 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:28:24 --> Helper loaded: security_helper
INFO - 2021-07-15 21:28:24 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:28:24 --> Helper loaded: language_helper
INFO - 2021-07-15 21:28:24 --> Helper loaded: general_helper
INFO - 2021-07-15 21:28:24 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:28:24 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:28:24 --> Parser Class Initialized
INFO - 2021-07-15 21:28:24 --> Form Validation Class Initialized
INFO - 2021-07-15 21:28:24 --> Upload Class Initialized
INFO - 2021-07-15 21:28:24 --> Email Class Initialized
INFO - 2021-07-15 21:28:24 --> MY_Model class loaded
INFO - 2021-07-15 21:28:24 --> Model "Users_model" initialized
INFO - 2021-07-15 21:28:24 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:28:24 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:28:24 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:28:24 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:28:24 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:28:24 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:28:24 --> Database Driver Class Initialized
INFO - 2021-07-15 21:28:24 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:28:24 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:28:24 --> Controller Class Initialized
ERROR - 2021-07-15 21:28:24 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 21:28:25 --> File loaded: C:\wamp64\www\crm\application\views\permissions/list.php
INFO - 2021-07-15 21:28:25 --> Final output sent to browser
DEBUG - 2021-07-15 21:28:25 --> Total execution time: 0.1352
INFO - 2021-07-15 21:28:34 --> Config Class Initialized
INFO - 2021-07-15 21:28:34 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:28:34 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:28:34 --> Utf8 Class Initialized
INFO - 2021-07-15 21:28:34 --> URI Class Initialized
INFO - 2021-07-15 21:28:34 --> Router Class Initialized
INFO - 2021-07-15 21:28:34 --> Output Class Initialized
INFO - 2021-07-15 21:28:34 --> Security Class Initialized
DEBUG - 2021-07-15 21:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:28:34 --> Input Class Initialized
INFO - 2021-07-15 21:28:34 --> Language Class Initialized
INFO - 2021-07-15 21:28:34 --> Loader Class Initialized
INFO - 2021-07-15 21:28:34 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:28:34 --> Helper loaded: url_helper
INFO - 2021-07-15 21:28:34 --> Helper loaded: file_helper
INFO - 2021-07-15 21:28:34 --> Helper loaded: form_helper
INFO - 2021-07-15 21:28:34 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:28:34 --> Helper loaded: security_helper
INFO - 2021-07-15 21:28:34 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:28:34 --> Helper loaded: language_helper
INFO - 2021-07-15 21:28:34 --> Helper loaded: general_helper
INFO - 2021-07-15 21:28:34 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:28:34 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:28:34 --> Parser Class Initialized
INFO - 2021-07-15 21:28:34 --> Form Validation Class Initialized
INFO - 2021-07-15 21:28:34 --> Upload Class Initialized
INFO - 2021-07-15 21:28:34 --> Email Class Initialized
INFO - 2021-07-15 21:28:34 --> MY_Model class loaded
INFO - 2021-07-15 21:28:34 --> Model "Users_model" initialized
INFO - 2021-07-15 21:28:34 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:28:34 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:28:34 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:28:34 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:28:34 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:28:34 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:28:34 --> Database Driver Class Initialized
INFO - 2021-07-15 21:28:34 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:28:34 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:28:34 --> Controller Class Initialized
ERROR - 2021-07-15 21:28:34 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 21:28:34 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-15 21:28:34 --> Final output sent to browser
DEBUG - 2021-07-15 21:28:34 --> Total execution time: 0.2073
INFO - 2021-07-15 21:28:37 --> Config Class Initialized
INFO - 2021-07-15 21:28:37 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:28:37 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:28:37 --> Utf8 Class Initialized
INFO - 2021-07-15 21:28:37 --> URI Class Initialized
INFO - 2021-07-15 21:28:37 --> Router Class Initialized
INFO - 2021-07-15 21:28:37 --> Output Class Initialized
INFO - 2021-07-15 21:28:37 --> Security Class Initialized
DEBUG - 2021-07-15 21:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:28:37 --> Input Class Initialized
INFO - 2021-07-15 21:28:37 --> Language Class Initialized
INFO - 2021-07-15 21:28:37 --> Loader Class Initialized
INFO - 2021-07-15 21:28:37 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:28:37 --> Helper loaded: url_helper
INFO - 2021-07-15 21:28:37 --> Helper loaded: file_helper
INFO - 2021-07-15 21:28:37 --> Helper loaded: form_helper
INFO - 2021-07-15 21:28:37 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:28:37 --> Helper loaded: security_helper
INFO - 2021-07-15 21:28:37 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:28:37 --> Helper loaded: language_helper
INFO - 2021-07-15 21:28:37 --> Helper loaded: general_helper
INFO - 2021-07-15 21:28:37 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:28:37 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:28:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:28:37 --> Parser Class Initialized
INFO - 2021-07-15 21:28:37 --> Form Validation Class Initialized
INFO - 2021-07-15 21:28:37 --> Upload Class Initialized
INFO - 2021-07-15 21:28:37 --> Email Class Initialized
INFO - 2021-07-15 21:28:37 --> MY_Model class loaded
INFO - 2021-07-15 21:28:37 --> Model "Users_model" initialized
INFO - 2021-07-15 21:28:37 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:28:37 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:28:37 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:28:37 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:28:37 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:28:37 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:28:37 --> Database Driver Class Initialized
INFO - 2021-07-15 21:28:37 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:28:37 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:28:37 --> Controller Class Initialized
ERROR - 2021-07-15 21:28:37 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-15 21:28:37 --> Severity: error --> Exception: Call to a member function result() on null C:\wamp64\www\crm\application\views\car\car_list.php 45
INFO - 2021-07-15 21:28:40 --> Config Class Initialized
INFO - 2021-07-15 21:28:40 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:28:40 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:28:40 --> Utf8 Class Initialized
INFO - 2021-07-15 21:28:40 --> URI Class Initialized
INFO - 2021-07-15 21:28:40 --> Router Class Initialized
INFO - 2021-07-15 21:28:40 --> Output Class Initialized
INFO - 2021-07-15 21:28:40 --> Security Class Initialized
DEBUG - 2021-07-15 21:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:28:40 --> Input Class Initialized
INFO - 2021-07-15 21:28:40 --> Language Class Initialized
INFO - 2021-07-15 21:28:40 --> Loader Class Initialized
INFO - 2021-07-15 21:28:40 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:28:40 --> Helper loaded: url_helper
INFO - 2021-07-15 21:28:40 --> Helper loaded: file_helper
INFO - 2021-07-15 21:28:40 --> Helper loaded: form_helper
INFO - 2021-07-15 21:28:40 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:28:40 --> Helper loaded: security_helper
INFO - 2021-07-15 21:28:40 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:28:40 --> Helper loaded: language_helper
INFO - 2021-07-15 21:28:40 --> Helper loaded: general_helper
INFO - 2021-07-15 21:28:40 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:28:40 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:28:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:28:40 --> Parser Class Initialized
INFO - 2021-07-15 21:28:40 --> Form Validation Class Initialized
INFO - 2021-07-15 21:28:40 --> Upload Class Initialized
INFO - 2021-07-15 21:28:40 --> Email Class Initialized
INFO - 2021-07-15 21:28:40 --> MY_Model class loaded
INFO - 2021-07-15 21:28:40 --> Model "Users_model" initialized
INFO - 2021-07-15 21:28:40 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:28:40 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:28:40 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:28:40 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:28:40 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:28:40 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:28:40 --> Database Driver Class Initialized
INFO - 2021-07-15 21:28:40 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:28:40 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:28:40 --> Controller Class Initialized
ERROR - 2021-07-15 21:28:40 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-15 21:28:40 --> Severity: error --> Exception: Call to a member function result() on null C:\wamp64\www\crm\application\views\car\car_list.php 45
INFO - 2021-07-15 21:28:50 --> Config Class Initialized
INFO - 2021-07-15 21:28:50 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:28:50 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:28:50 --> Utf8 Class Initialized
INFO - 2021-07-15 21:28:50 --> URI Class Initialized
INFO - 2021-07-15 21:28:50 --> Router Class Initialized
INFO - 2021-07-15 21:28:50 --> Output Class Initialized
INFO - 2021-07-15 21:28:50 --> Security Class Initialized
DEBUG - 2021-07-15 21:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:28:50 --> Input Class Initialized
INFO - 2021-07-15 21:28:50 --> Language Class Initialized
INFO - 2021-07-15 21:28:50 --> Loader Class Initialized
INFO - 2021-07-15 21:28:50 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:28:50 --> Helper loaded: url_helper
INFO - 2021-07-15 21:28:50 --> Helper loaded: file_helper
INFO - 2021-07-15 21:28:50 --> Helper loaded: form_helper
INFO - 2021-07-15 21:28:50 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:28:50 --> Helper loaded: security_helper
INFO - 2021-07-15 21:28:50 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:28:50 --> Helper loaded: language_helper
INFO - 2021-07-15 21:28:50 --> Helper loaded: general_helper
INFO - 2021-07-15 21:28:50 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:28:50 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:28:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:28:50 --> Parser Class Initialized
INFO - 2021-07-15 21:28:50 --> Form Validation Class Initialized
INFO - 2021-07-15 21:28:50 --> Upload Class Initialized
INFO - 2021-07-15 21:28:50 --> Email Class Initialized
INFO - 2021-07-15 21:28:50 --> MY_Model class loaded
INFO - 2021-07-15 21:28:50 --> Model "Users_model" initialized
INFO - 2021-07-15 21:28:50 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:28:50 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:28:50 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:28:50 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:28:50 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:28:50 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:28:50 --> Database Driver Class Initialized
INFO - 2021-07-15 21:28:51 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:28:51 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:28:51 --> Controller Class Initialized
ERROR - 2021-07-15 21:28:51 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 21:28:51 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 21:28:51 --> Final output sent to browser
DEBUG - 2021-07-15 21:28:51 --> Total execution time: 0.1457
INFO - 2021-07-15 21:31:27 --> Config Class Initialized
INFO - 2021-07-15 21:31:27 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:31:27 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:31:27 --> Utf8 Class Initialized
INFO - 2021-07-15 21:31:27 --> URI Class Initialized
INFO - 2021-07-15 21:31:27 --> Router Class Initialized
INFO - 2021-07-15 21:31:27 --> Output Class Initialized
INFO - 2021-07-15 21:31:27 --> Security Class Initialized
DEBUG - 2021-07-15 21:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:31:27 --> Input Class Initialized
INFO - 2021-07-15 21:31:27 --> Language Class Initialized
INFO - 2021-07-15 21:31:27 --> Loader Class Initialized
INFO - 2021-07-15 21:31:27 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:31:27 --> Helper loaded: url_helper
INFO - 2021-07-15 21:31:27 --> Helper loaded: file_helper
INFO - 2021-07-15 21:31:27 --> Helper loaded: form_helper
INFO - 2021-07-15 21:31:27 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:31:27 --> Helper loaded: security_helper
INFO - 2021-07-15 21:31:27 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:31:27 --> Helper loaded: language_helper
INFO - 2021-07-15 21:31:27 --> Helper loaded: general_helper
INFO - 2021-07-15 21:31:27 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:31:27 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:31:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:31:27 --> Parser Class Initialized
INFO - 2021-07-15 21:31:27 --> Form Validation Class Initialized
INFO - 2021-07-15 21:31:27 --> Upload Class Initialized
INFO - 2021-07-15 21:31:27 --> Email Class Initialized
INFO - 2021-07-15 21:31:27 --> MY_Model class loaded
INFO - 2021-07-15 21:31:27 --> Model "Users_model" initialized
INFO - 2021-07-15 21:31:27 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:31:27 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:31:27 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:31:27 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:31:27 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:31:27 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:31:27 --> Database Driver Class Initialized
INFO - 2021-07-15 21:31:27 --> Model "Hesaplar_model" initialized
ERROR - 2021-07-15 21:31:27 --> Severity: error --> Exception: syntax error, unexpected '}' C:\wamp64\www\crm\application\models\Car_activity_model.php 72
INFO - 2021-07-15 21:31:37 --> Config Class Initialized
INFO - 2021-07-15 21:31:37 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:31:37 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:31:37 --> Utf8 Class Initialized
INFO - 2021-07-15 21:31:37 --> URI Class Initialized
INFO - 2021-07-15 21:31:37 --> Router Class Initialized
INFO - 2021-07-15 21:31:37 --> Output Class Initialized
INFO - 2021-07-15 21:31:37 --> Security Class Initialized
DEBUG - 2021-07-15 21:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:31:37 --> Input Class Initialized
INFO - 2021-07-15 21:31:37 --> Language Class Initialized
INFO - 2021-07-15 21:31:37 --> Loader Class Initialized
INFO - 2021-07-15 21:31:37 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:31:37 --> Helper loaded: url_helper
INFO - 2021-07-15 21:31:37 --> Helper loaded: file_helper
INFO - 2021-07-15 21:31:37 --> Helper loaded: form_helper
INFO - 2021-07-15 21:31:37 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:31:37 --> Helper loaded: security_helper
INFO - 2021-07-15 21:31:37 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:31:37 --> Helper loaded: language_helper
INFO - 2021-07-15 21:31:37 --> Helper loaded: general_helper
INFO - 2021-07-15 21:31:37 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:31:37 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:31:37 --> Parser Class Initialized
INFO - 2021-07-15 21:31:37 --> Form Validation Class Initialized
INFO - 2021-07-15 21:31:37 --> Upload Class Initialized
INFO - 2021-07-15 21:31:37 --> Email Class Initialized
INFO - 2021-07-15 21:31:37 --> MY_Model class loaded
INFO - 2021-07-15 21:31:37 --> Model "Users_model" initialized
INFO - 2021-07-15 21:31:37 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:31:37 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:31:37 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:31:37 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:31:37 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:31:37 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:31:37 --> Database Driver Class Initialized
INFO - 2021-07-15 21:31:37 --> Model "Hesaplar_model" initialized
ERROR - 2021-07-15 21:31:37 --> Severity: error --> Exception: syntax error, unexpected '}' C:\wamp64\www\crm\application\models\Car_activity_model.php 72
INFO - 2021-07-15 21:31:38 --> Config Class Initialized
INFO - 2021-07-15 21:31:38 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:31:38 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:31:38 --> Utf8 Class Initialized
INFO - 2021-07-15 21:31:38 --> URI Class Initialized
INFO - 2021-07-15 21:31:38 --> Router Class Initialized
INFO - 2021-07-15 21:31:38 --> Output Class Initialized
INFO - 2021-07-15 21:31:38 --> Security Class Initialized
DEBUG - 2021-07-15 21:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:31:38 --> Input Class Initialized
INFO - 2021-07-15 21:31:38 --> Language Class Initialized
INFO - 2021-07-15 21:31:38 --> Loader Class Initialized
INFO - 2021-07-15 21:31:38 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:31:38 --> Helper loaded: url_helper
INFO - 2021-07-15 21:31:38 --> Helper loaded: file_helper
INFO - 2021-07-15 21:31:38 --> Helper loaded: form_helper
INFO - 2021-07-15 21:31:38 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:31:38 --> Helper loaded: security_helper
INFO - 2021-07-15 21:31:38 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:31:38 --> Helper loaded: language_helper
INFO - 2021-07-15 21:31:38 --> Helper loaded: general_helper
INFO - 2021-07-15 21:31:38 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:31:38 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:31:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:31:38 --> Parser Class Initialized
INFO - 2021-07-15 21:31:38 --> Form Validation Class Initialized
INFO - 2021-07-15 21:31:38 --> Upload Class Initialized
INFO - 2021-07-15 21:31:38 --> Email Class Initialized
INFO - 2021-07-15 21:31:38 --> MY_Model class loaded
INFO - 2021-07-15 21:31:38 --> Model "Users_model" initialized
INFO - 2021-07-15 21:31:38 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:31:38 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:31:38 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:31:38 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:31:38 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:31:38 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:31:38 --> Database Driver Class Initialized
INFO - 2021-07-15 21:31:38 --> Model "Hesaplar_model" initialized
ERROR - 2021-07-15 21:31:38 --> Severity: error --> Exception: syntax error, unexpected '}' C:\wamp64\www\crm\application\models\Car_activity_model.php 72
INFO - 2021-07-15 21:31:39 --> Config Class Initialized
INFO - 2021-07-15 21:31:39 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:31:39 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:31:39 --> Utf8 Class Initialized
INFO - 2021-07-15 21:31:39 --> URI Class Initialized
INFO - 2021-07-15 21:31:39 --> Router Class Initialized
INFO - 2021-07-15 21:31:39 --> Output Class Initialized
INFO - 2021-07-15 21:31:39 --> Security Class Initialized
DEBUG - 2021-07-15 21:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:31:39 --> Input Class Initialized
INFO - 2021-07-15 21:31:39 --> Language Class Initialized
INFO - 2021-07-15 21:31:39 --> Loader Class Initialized
INFO - 2021-07-15 21:31:39 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:31:39 --> Helper loaded: url_helper
INFO - 2021-07-15 21:31:39 --> Helper loaded: file_helper
INFO - 2021-07-15 21:31:39 --> Helper loaded: form_helper
INFO - 2021-07-15 21:31:39 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:31:39 --> Helper loaded: security_helper
INFO - 2021-07-15 21:31:39 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:31:39 --> Helper loaded: language_helper
INFO - 2021-07-15 21:31:39 --> Helper loaded: general_helper
INFO - 2021-07-15 21:31:39 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:31:39 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:31:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:31:39 --> Parser Class Initialized
INFO - 2021-07-15 21:31:39 --> Form Validation Class Initialized
INFO - 2021-07-15 21:31:39 --> Upload Class Initialized
INFO - 2021-07-15 21:31:39 --> Email Class Initialized
INFO - 2021-07-15 21:31:39 --> MY_Model class loaded
INFO - 2021-07-15 21:31:39 --> Model "Users_model" initialized
INFO - 2021-07-15 21:31:39 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:31:39 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:31:39 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:31:39 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:31:39 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:31:39 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:31:39 --> Database Driver Class Initialized
INFO - 2021-07-15 21:31:39 --> Model "Hesaplar_model" initialized
ERROR - 2021-07-15 21:31:39 --> Severity: error --> Exception: syntax error, unexpected '}' C:\wamp64\www\crm\application\models\Car_activity_model.php 72
INFO - 2021-07-15 21:31:50 --> Config Class Initialized
INFO - 2021-07-15 21:31:50 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:31:50 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:31:50 --> Utf8 Class Initialized
INFO - 2021-07-15 21:31:50 --> URI Class Initialized
INFO - 2021-07-15 21:31:50 --> Router Class Initialized
INFO - 2021-07-15 21:31:50 --> Output Class Initialized
INFO - 2021-07-15 21:31:50 --> Security Class Initialized
DEBUG - 2021-07-15 21:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:31:50 --> Input Class Initialized
INFO - 2021-07-15 21:31:50 --> Language Class Initialized
INFO - 2021-07-15 21:31:50 --> Loader Class Initialized
INFO - 2021-07-15 21:31:50 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:31:50 --> Helper loaded: url_helper
INFO - 2021-07-15 21:31:50 --> Helper loaded: file_helper
INFO - 2021-07-15 21:31:50 --> Helper loaded: form_helper
INFO - 2021-07-15 21:31:50 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:31:50 --> Helper loaded: security_helper
INFO - 2021-07-15 21:31:50 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:31:50 --> Helper loaded: language_helper
INFO - 2021-07-15 21:31:50 --> Helper loaded: general_helper
INFO - 2021-07-15 21:31:50 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:31:50 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:31:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:31:50 --> Parser Class Initialized
INFO - 2021-07-15 21:31:50 --> Form Validation Class Initialized
INFO - 2021-07-15 21:31:50 --> Upload Class Initialized
INFO - 2021-07-15 21:31:50 --> Email Class Initialized
INFO - 2021-07-15 21:31:50 --> MY_Model class loaded
INFO - 2021-07-15 21:31:50 --> Model "Users_model" initialized
INFO - 2021-07-15 21:31:50 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:31:50 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:31:50 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:31:50 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:31:50 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:31:50 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:31:50 --> Database Driver Class Initialized
INFO - 2021-07-15 21:31:50 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:31:50 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:31:50 --> Controller Class Initialized
ERROR - 2021-07-15 21:31:50 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 21:31:50 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 21:31:50 --> Final output sent to browser
DEBUG - 2021-07-15 21:31:50 --> Total execution time: 0.1330
INFO - 2021-07-15 21:31:55 --> Config Class Initialized
INFO - 2021-07-15 21:31:55 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:31:55 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:31:55 --> Utf8 Class Initialized
INFO - 2021-07-15 21:31:55 --> URI Class Initialized
INFO - 2021-07-15 21:31:55 --> Router Class Initialized
INFO - 2021-07-15 21:31:55 --> Output Class Initialized
INFO - 2021-07-15 21:31:55 --> Security Class Initialized
DEBUG - 2021-07-15 21:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:31:55 --> Input Class Initialized
INFO - 2021-07-15 21:31:55 --> Language Class Initialized
INFO - 2021-07-15 21:31:55 --> Loader Class Initialized
INFO - 2021-07-15 21:31:55 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:31:55 --> Helper loaded: url_helper
INFO - 2021-07-15 21:31:55 --> Helper loaded: file_helper
INFO - 2021-07-15 21:31:55 --> Helper loaded: form_helper
INFO - 2021-07-15 21:31:55 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:31:55 --> Helper loaded: security_helper
INFO - 2021-07-15 21:31:55 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:31:55 --> Helper loaded: language_helper
INFO - 2021-07-15 21:31:55 --> Helper loaded: general_helper
INFO - 2021-07-15 21:31:55 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:31:55 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:31:55 --> Parser Class Initialized
INFO - 2021-07-15 21:31:55 --> Form Validation Class Initialized
INFO - 2021-07-15 21:31:55 --> Upload Class Initialized
INFO - 2021-07-15 21:31:55 --> Email Class Initialized
INFO - 2021-07-15 21:31:55 --> MY_Model class loaded
INFO - 2021-07-15 21:31:55 --> Model "Users_model" initialized
INFO - 2021-07-15 21:31:55 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:31:55 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:31:55 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:31:55 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:31:55 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:31:55 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:31:55 --> Database Driver Class Initialized
INFO - 2021-07-15 21:31:55 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:31:55 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:31:55 --> Controller Class Initialized
ERROR - 2021-07-15 21:31:55 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 21:31:55 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 21:31:55 --> Final output sent to browser
DEBUG - 2021-07-15 21:31:55 --> Total execution time: 0.1373
INFO - 2021-07-15 21:32:59 --> Config Class Initialized
INFO - 2021-07-15 21:32:59 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:32:59 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:32:59 --> Utf8 Class Initialized
INFO - 2021-07-15 21:32:59 --> URI Class Initialized
INFO - 2021-07-15 21:32:59 --> Router Class Initialized
INFO - 2021-07-15 21:32:59 --> Output Class Initialized
INFO - 2021-07-15 21:32:59 --> Security Class Initialized
DEBUG - 2021-07-15 21:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:32:59 --> Input Class Initialized
INFO - 2021-07-15 21:32:59 --> Language Class Initialized
INFO - 2021-07-15 21:32:59 --> Loader Class Initialized
INFO - 2021-07-15 21:32:59 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:32:59 --> Helper loaded: url_helper
INFO - 2021-07-15 21:32:59 --> Helper loaded: file_helper
INFO - 2021-07-15 21:32:59 --> Helper loaded: form_helper
INFO - 2021-07-15 21:32:59 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:32:59 --> Helper loaded: security_helper
INFO - 2021-07-15 21:32:59 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:32:59 --> Helper loaded: language_helper
INFO - 2021-07-15 21:32:59 --> Helper loaded: general_helper
INFO - 2021-07-15 21:32:59 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:32:59 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:32:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:32:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:32:59 --> Parser Class Initialized
INFO - 2021-07-15 21:32:59 --> Form Validation Class Initialized
INFO - 2021-07-15 21:32:59 --> Upload Class Initialized
INFO - 2021-07-15 21:32:59 --> Email Class Initialized
INFO - 2021-07-15 21:32:59 --> MY_Model class loaded
INFO - 2021-07-15 21:32:59 --> Model "Users_model" initialized
INFO - 2021-07-15 21:32:59 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:32:59 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:32:59 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:32:59 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:32:59 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:32:59 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:32:59 --> Database Driver Class Initialized
INFO - 2021-07-15 21:32:59 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:32:59 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:32:59 --> Controller Class Initialized
ERROR - 2021-07-15 21:32:59 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 21:32:59 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 21:32:59 --> Final output sent to browser
DEBUG - 2021-07-15 21:32:59 --> Total execution time: 0.5456
INFO - 2021-07-15 21:32:59 --> Config Class Initialized
INFO - 2021-07-15 21:32:59 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:32:59 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:32:59 --> Utf8 Class Initialized
INFO - 2021-07-15 21:32:59 --> URI Class Initialized
INFO - 2021-07-15 21:32:59 --> Router Class Initialized
INFO - 2021-07-15 21:32:59 --> Output Class Initialized
INFO - 2021-07-15 21:32:59 --> Security Class Initialized
DEBUG - 2021-07-15 21:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:32:59 --> Input Class Initialized
INFO - 2021-07-15 21:32:59 --> Language Class Initialized
INFO - 2021-07-15 21:32:59 --> Loader Class Initialized
INFO - 2021-07-15 21:32:59 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:32:59 --> Helper loaded: url_helper
INFO - 2021-07-15 21:32:59 --> Helper loaded: file_helper
INFO - 2021-07-15 21:32:59 --> Helper loaded: form_helper
INFO - 2021-07-15 21:32:59 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:32:59 --> Helper loaded: security_helper
INFO - 2021-07-15 21:32:59 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:32:59 --> Helper loaded: language_helper
INFO - 2021-07-15 21:32:59 --> Helper loaded: general_helper
INFO - 2021-07-15 21:32:59 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:32:59 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:32:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:32:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:32:59 --> Parser Class Initialized
INFO - 2021-07-15 21:32:59 --> Form Validation Class Initialized
INFO - 2021-07-15 21:32:59 --> Upload Class Initialized
INFO - 2021-07-15 21:32:59 --> Email Class Initialized
INFO - 2021-07-15 21:32:59 --> MY_Model class loaded
INFO - 2021-07-15 21:32:59 --> Model "Users_model" initialized
INFO - 2021-07-15 21:32:59 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:32:59 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:32:59 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:32:59 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:32:59 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:32:59 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:32:59 --> Database Driver Class Initialized
INFO - 2021-07-15 21:32:59 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:32:59 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:32:59 --> Controller Class Initialized
ERROR - 2021-07-15 21:32:59 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 21:32:59 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 21:32:59 --> Final output sent to browser
DEBUG - 2021-07-15 21:32:59 --> Total execution time: 0.0775
INFO - 2021-07-15 21:33:03 --> Config Class Initialized
INFO - 2021-07-15 21:33:03 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:33:03 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:33:03 --> Utf8 Class Initialized
INFO - 2021-07-15 21:33:03 --> URI Class Initialized
INFO - 2021-07-15 21:33:03 --> Router Class Initialized
INFO - 2021-07-15 21:33:03 --> Output Class Initialized
INFO - 2021-07-15 21:33:03 --> Security Class Initialized
DEBUG - 2021-07-15 21:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:33:03 --> Input Class Initialized
INFO - 2021-07-15 21:33:03 --> Language Class Initialized
INFO - 2021-07-15 21:33:03 --> Loader Class Initialized
INFO - 2021-07-15 21:33:03 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:33:03 --> Helper loaded: url_helper
INFO - 2021-07-15 21:33:03 --> Helper loaded: file_helper
INFO - 2021-07-15 21:33:03 --> Helper loaded: form_helper
INFO - 2021-07-15 21:33:03 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:33:03 --> Helper loaded: security_helper
INFO - 2021-07-15 21:33:03 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:33:03 --> Helper loaded: language_helper
INFO - 2021-07-15 21:33:03 --> Helper loaded: general_helper
INFO - 2021-07-15 21:33:03 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:33:03 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:33:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:33:03 --> Parser Class Initialized
INFO - 2021-07-15 21:33:03 --> Form Validation Class Initialized
INFO - 2021-07-15 21:33:03 --> Upload Class Initialized
INFO - 2021-07-15 21:33:03 --> Email Class Initialized
INFO - 2021-07-15 21:33:03 --> MY_Model class loaded
INFO - 2021-07-15 21:33:03 --> Model "Users_model" initialized
INFO - 2021-07-15 21:33:03 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:33:03 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:33:03 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:33:03 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:33:03 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:33:03 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:33:03 --> Database Driver Class Initialized
INFO - 2021-07-15 21:33:03 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:33:03 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:33:03 --> Controller Class Initialized
ERROR - 2021-07-15 21:33:03 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 21:33:03 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 21:33:03 --> Final output sent to browser
DEBUG - 2021-07-15 21:33:03 --> Total execution time: 0.1242
INFO - 2021-07-15 21:36:09 --> Config Class Initialized
INFO - 2021-07-15 21:36:09 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:36:09 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:36:09 --> Utf8 Class Initialized
INFO - 2021-07-15 21:36:09 --> URI Class Initialized
INFO - 2021-07-15 21:36:09 --> Router Class Initialized
INFO - 2021-07-15 21:36:09 --> Output Class Initialized
INFO - 2021-07-15 21:36:09 --> Security Class Initialized
DEBUG - 2021-07-15 21:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:36:09 --> Input Class Initialized
INFO - 2021-07-15 21:36:09 --> Language Class Initialized
INFO - 2021-07-15 21:36:09 --> Loader Class Initialized
INFO - 2021-07-15 21:36:09 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:36:09 --> Helper loaded: url_helper
INFO - 2021-07-15 21:36:09 --> Helper loaded: file_helper
INFO - 2021-07-15 21:36:09 --> Helper loaded: form_helper
INFO - 2021-07-15 21:36:09 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:36:09 --> Helper loaded: security_helper
INFO - 2021-07-15 21:36:09 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:36:09 --> Helper loaded: language_helper
INFO - 2021-07-15 21:36:09 --> Helper loaded: general_helper
INFO - 2021-07-15 21:36:09 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:36:09 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:36:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:36:09 --> Parser Class Initialized
INFO - 2021-07-15 21:36:09 --> Form Validation Class Initialized
INFO - 2021-07-15 21:36:09 --> Upload Class Initialized
INFO - 2021-07-15 21:36:09 --> Email Class Initialized
INFO - 2021-07-15 21:36:09 --> MY_Model class loaded
INFO - 2021-07-15 21:36:09 --> Model "Users_model" initialized
INFO - 2021-07-15 21:36:09 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:36:09 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:36:09 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:36:09 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:36:09 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:36:09 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:36:09 --> Database Driver Class Initialized
INFO - 2021-07-15 21:36:09 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:36:09 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:36:09 --> Controller Class Initialized
ERROR - 2021-07-15 21:36:09 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 21:36:09 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 21:36:09 --> Final output sent to browser
DEBUG - 2021-07-15 21:36:09 --> Total execution time: 0.1682
INFO - 2021-07-15 21:36:16 --> Config Class Initialized
INFO - 2021-07-15 21:36:16 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:36:16 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:36:16 --> Utf8 Class Initialized
INFO - 2021-07-15 21:36:16 --> URI Class Initialized
INFO - 2021-07-15 21:36:16 --> Router Class Initialized
INFO - 2021-07-15 21:36:16 --> Output Class Initialized
INFO - 2021-07-15 21:36:16 --> Security Class Initialized
DEBUG - 2021-07-15 21:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:36:16 --> Input Class Initialized
INFO - 2021-07-15 21:36:16 --> Language Class Initialized
INFO - 2021-07-15 21:36:16 --> Loader Class Initialized
INFO - 2021-07-15 21:36:16 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:36:16 --> Helper loaded: url_helper
INFO - 2021-07-15 21:36:16 --> Helper loaded: file_helper
INFO - 2021-07-15 21:36:16 --> Helper loaded: form_helper
INFO - 2021-07-15 21:36:16 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:36:16 --> Helper loaded: security_helper
INFO - 2021-07-15 21:36:16 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:36:16 --> Helper loaded: language_helper
INFO - 2021-07-15 21:36:16 --> Helper loaded: general_helper
INFO - 2021-07-15 21:36:16 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:36:16 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:36:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:36:16 --> Parser Class Initialized
INFO - 2021-07-15 21:36:16 --> Form Validation Class Initialized
INFO - 2021-07-15 21:36:16 --> Upload Class Initialized
INFO - 2021-07-15 21:36:16 --> Email Class Initialized
INFO - 2021-07-15 21:36:16 --> MY_Model class loaded
INFO - 2021-07-15 21:36:16 --> Model "Users_model" initialized
INFO - 2021-07-15 21:36:16 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:36:16 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:36:16 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:36:16 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:36:16 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:36:16 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:36:16 --> Database Driver Class Initialized
INFO - 2021-07-15 21:36:17 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:36:17 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:36:17 --> Controller Class Initialized
ERROR - 2021-07-15 21:36:17 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 21:36:17 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 21:36:17 --> Final output sent to browser
DEBUG - 2021-07-15 21:36:17 --> Total execution time: 0.1310
INFO - 2021-07-15 21:36:21 --> Config Class Initialized
INFO - 2021-07-15 21:36:21 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:36:21 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:36:21 --> Utf8 Class Initialized
INFO - 2021-07-15 21:36:21 --> URI Class Initialized
INFO - 2021-07-15 21:36:21 --> Router Class Initialized
INFO - 2021-07-15 21:36:21 --> Output Class Initialized
INFO - 2021-07-15 21:36:21 --> Security Class Initialized
DEBUG - 2021-07-15 21:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:36:21 --> Input Class Initialized
INFO - 2021-07-15 21:36:21 --> Language Class Initialized
INFO - 2021-07-15 21:36:21 --> Loader Class Initialized
INFO - 2021-07-15 21:36:21 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:36:21 --> Helper loaded: url_helper
INFO - 2021-07-15 21:36:21 --> Helper loaded: file_helper
INFO - 2021-07-15 21:36:21 --> Helper loaded: form_helper
INFO - 2021-07-15 21:36:21 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:36:21 --> Helper loaded: security_helper
INFO - 2021-07-15 21:36:21 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:36:21 --> Helper loaded: language_helper
INFO - 2021-07-15 21:36:21 --> Helper loaded: general_helper
INFO - 2021-07-15 21:36:21 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:36:21 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:36:21 --> Parser Class Initialized
INFO - 2021-07-15 21:36:21 --> Form Validation Class Initialized
INFO - 2021-07-15 21:36:21 --> Upload Class Initialized
INFO - 2021-07-15 21:36:21 --> Email Class Initialized
INFO - 2021-07-15 21:36:21 --> MY_Model class loaded
INFO - 2021-07-15 21:36:21 --> Model "Users_model" initialized
INFO - 2021-07-15 21:36:21 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:36:21 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:36:21 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:36:21 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:36:21 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:36:21 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:36:21 --> Database Driver Class Initialized
INFO - 2021-07-15 21:36:22 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:36:22 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:36:22 --> Controller Class Initialized
ERROR - 2021-07-15 21:36:22 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 21:36:22 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 21:36:22 --> Final output sent to browser
DEBUG - 2021-07-15 21:36:22 --> Total execution time: 0.1228
INFO - 2021-07-15 21:36:25 --> Config Class Initialized
INFO - 2021-07-15 21:36:25 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:36:25 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:36:25 --> Utf8 Class Initialized
INFO - 2021-07-15 21:36:25 --> URI Class Initialized
INFO - 2021-07-15 21:36:25 --> Router Class Initialized
INFO - 2021-07-15 21:36:25 --> Output Class Initialized
INFO - 2021-07-15 21:36:25 --> Security Class Initialized
DEBUG - 2021-07-15 21:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:36:25 --> Input Class Initialized
INFO - 2021-07-15 21:36:25 --> Language Class Initialized
INFO - 2021-07-15 21:36:25 --> Loader Class Initialized
INFO - 2021-07-15 21:36:25 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:36:25 --> Helper loaded: url_helper
INFO - 2021-07-15 21:36:25 --> Helper loaded: file_helper
INFO - 2021-07-15 21:36:25 --> Helper loaded: form_helper
INFO - 2021-07-15 21:36:25 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:36:25 --> Helper loaded: security_helper
INFO - 2021-07-15 21:36:25 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:36:25 --> Helper loaded: language_helper
INFO - 2021-07-15 21:36:25 --> Helper loaded: general_helper
INFO - 2021-07-15 21:36:25 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:36:25 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:36:25 --> Parser Class Initialized
INFO - 2021-07-15 21:36:25 --> Form Validation Class Initialized
INFO - 2021-07-15 21:36:25 --> Upload Class Initialized
INFO - 2021-07-15 21:36:25 --> Email Class Initialized
INFO - 2021-07-15 21:36:25 --> MY_Model class loaded
INFO - 2021-07-15 21:36:25 --> Model "Users_model" initialized
INFO - 2021-07-15 21:36:25 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:36:25 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:36:25 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:36:25 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:36:25 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:36:25 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:36:25 --> Database Driver Class Initialized
INFO - 2021-07-15 21:36:25 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:36:25 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:36:25 --> Controller Class Initialized
ERROR - 2021-07-15 21:36:25 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 21:36:25 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 21:36:25 --> Final output sent to browser
DEBUG - 2021-07-15 21:36:25 --> Total execution time: 0.0645
INFO - 2021-07-15 21:41:11 --> Config Class Initialized
INFO - 2021-07-15 21:41:11 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:41:11 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:41:11 --> Utf8 Class Initialized
INFO - 2021-07-15 21:41:11 --> URI Class Initialized
INFO - 2021-07-15 21:41:11 --> Router Class Initialized
INFO - 2021-07-15 21:41:11 --> Output Class Initialized
INFO - 2021-07-15 21:41:11 --> Security Class Initialized
DEBUG - 2021-07-15 21:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:41:11 --> Input Class Initialized
INFO - 2021-07-15 21:41:11 --> Language Class Initialized
ERROR - 2021-07-15 21:41:11 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) C:\wamp64\www\crm\application\controllers\Car.php 30
INFO - 2021-07-15 21:43:35 --> Config Class Initialized
INFO - 2021-07-15 21:43:35 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:43:35 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:43:35 --> Utf8 Class Initialized
INFO - 2021-07-15 21:43:35 --> URI Class Initialized
INFO - 2021-07-15 21:43:35 --> Router Class Initialized
INFO - 2021-07-15 21:43:35 --> Output Class Initialized
INFO - 2021-07-15 21:43:35 --> Security Class Initialized
DEBUG - 2021-07-15 21:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:43:35 --> Input Class Initialized
INFO - 2021-07-15 21:43:35 --> Language Class Initialized
ERROR - 2021-07-15 21:43:35 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) C:\wamp64\www\crm\application\controllers\Car.php 31
INFO - 2021-07-15 21:48:12 --> Config Class Initialized
INFO - 2021-07-15 21:48:12 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:48:12 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:48:12 --> Utf8 Class Initialized
INFO - 2021-07-15 21:48:12 --> URI Class Initialized
INFO - 2021-07-15 21:48:12 --> Router Class Initialized
INFO - 2021-07-15 21:48:12 --> Output Class Initialized
INFO - 2021-07-15 21:48:12 --> Security Class Initialized
DEBUG - 2021-07-15 21:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:48:12 --> Input Class Initialized
INFO - 2021-07-15 21:48:12 --> Language Class Initialized
INFO - 2021-07-15 21:48:12 --> Loader Class Initialized
INFO - 2021-07-15 21:48:12 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:48:12 --> Helper loaded: url_helper
INFO - 2021-07-15 21:48:12 --> Helper loaded: file_helper
INFO - 2021-07-15 21:48:12 --> Helper loaded: form_helper
INFO - 2021-07-15 21:48:12 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:48:12 --> Helper loaded: security_helper
INFO - 2021-07-15 21:48:12 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:48:12 --> Helper loaded: language_helper
INFO - 2021-07-15 21:48:12 --> Helper loaded: general_helper
INFO - 2021-07-15 21:48:12 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:48:12 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:48:12 --> Parser Class Initialized
INFO - 2021-07-15 21:48:12 --> Form Validation Class Initialized
INFO - 2021-07-15 21:48:12 --> Upload Class Initialized
INFO - 2021-07-15 21:48:12 --> Email Class Initialized
INFO - 2021-07-15 21:48:12 --> MY_Model class loaded
INFO - 2021-07-15 21:48:12 --> Model "Users_model" initialized
INFO - 2021-07-15 21:48:12 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:48:12 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:48:12 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:48:12 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:48:12 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:48:12 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:48:12 --> Database Driver Class Initialized
INFO - 2021-07-15 21:48:12 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:48:12 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:48:12 --> Controller Class Initialized
ERROR - 2021-07-15 21:48:12 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 21:48:13 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 21:48:13 --> Config Class Initialized
INFO - 2021-07-15 21:48:13 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:48:13 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:48:13 --> Utf8 Class Initialized
INFO - 2021-07-15 21:48:13 --> URI Class Initialized
INFO - 2021-07-15 21:48:13 --> Router Class Initialized
INFO - 2021-07-15 21:48:13 --> Output Class Initialized
INFO - 2021-07-15 21:48:13 --> Security Class Initialized
DEBUG - 2021-07-15 21:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:48:13 --> Input Class Initialized
INFO - 2021-07-15 21:48:13 --> Language Class Initialized
INFO - 2021-07-15 21:48:13 --> Loader Class Initialized
INFO - 2021-07-15 21:48:13 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:48:13 --> Helper loaded: url_helper
INFO - 2021-07-15 21:48:13 --> Helper loaded: file_helper
INFO - 2021-07-15 21:48:13 --> Helper loaded: form_helper
INFO - 2021-07-15 21:48:13 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:48:13 --> Helper loaded: security_helper
INFO - 2021-07-15 21:48:13 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:48:13 --> Helper loaded: language_helper
INFO - 2021-07-15 21:48:13 --> Helper loaded: general_helper
INFO - 2021-07-15 21:48:13 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:48:13 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:48:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:48:13 --> Parser Class Initialized
INFO - 2021-07-15 21:48:13 --> Form Validation Class Initialized
INFO - 2021-07-15 21:48:13 --> Upload Class Initialized
INFO - 2021-07-15 21:48:13 --> Email Class Initialized
INFO - 2021-07-15 21:48:13 --> MY_Model class loaded
INFO - 2021-07-15 21:48:13 --> Model "Users_model" initialized
INFO - 2021-07-15 21:48:13 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:48:13 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:48:13 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:48:13 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:48:13 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:48:13 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:48:13 --> Database Driver Class Initialized
INFO - 2021-07-15 21:48:13 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:48:13 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:48:13 --> Controller Class Initialized
ERROR - 2021-07-15 21:48:13 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 21:48:13 --> File loaded: C:\wamp64\www\crm\application\views\errors/html/error_403_permission.php
INFO - 2021-07-15 21:48:13 --> Final output sent to browser
DEBUG - 2021-07-15 21:48:13 --> Total execution time: 0.0611
INFO - 2021-07-15 21:48:21 --> Config Class Initialized
INFO - 2021-07-15 21:48:21 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:48:21 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:48:21 --> Utf8 Class Initialized
INFO - 2021-07-15 21:48:21 --> URI Class Initialized
INFO - 2021-07-15 21:48:21 --> Router Class Initialized
INFO - 2021-07-15 21:48:21 --> Output Class Initialized
INFO - 2021-07-15 21:48:21 --> Security Class Initialized
DEBUG - 2021-07-15 21:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:48:21 --> Input Class Initialized
INFO - 2021-07-15 21:48:21 --> Language Class Initialized
INFO - 2021-07-15 21:48:21 --> Loader Class Initialized
INFO - 2021-07-15 21:48:21 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:48:21 --> Helper loaded: url_helper
INFO - 2021-07-15 21:48:21 --> Helper loaded: file_helper
INFO - 2021-07-15 21:48:21 --> Helper loaded: form_helper
INFO - 2021-07-15 21:48:21 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:48:21 --> Helper loaded: security_helper
INFO - 2021-07-15 21:48:21 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:48:21 --> Helper loaded: language_helper
INFO - 2021-07-15 21:48:21 --> Helper loaded: general_helper
INFO - 2021-07-15 21:48:21 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:48:21 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:48:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:48:21 --> Parser Class Initialized
INFO - 2021-07-15 21:48:21 --> Form Validation Class Initialized
INFO - 2021-07-15 21:48:21 --> Upload Class Initialized
INFO - 2021-07-15 21:48:21 --> Email Class Initialized
INFO - 2021-07-15 21:48:21 --> MY_Model class loaded
INFO - 2021-07-15 21:48:21 --> Model "Users_model" initialized
INFO - 2021-07-15 21:48:21 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:48:21 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:48:21 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:48:21 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:48:21 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:48:21 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:48:21 --> Database Driver Class Initialized
INFO - 2021-07-15 21:48:21 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:48:21 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:48:21 --> Controller Class Initialized
ERROR - 2021-07-15 21:48:21 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 21:48:21 --> File loaded: C:\wamp64\www\crm\application\views\permissions/list.php
INFO - 2021-07-15 21:48:21 --> Final output sent to browser
DEBUG - 2021-07-15 21:48:21 --> Total execution time: 0.1812
INFO - 2021-07-15 21:48:24 --> Config Class Initialized
INFO - 2021-07-15 21:48:24 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:48:24 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:48:24 --> Utf8 Class Initialized
INFO - 2021-07-15 21:48:24 --> URI Class Initialized
INFO - 2021-07-15 21:48:24 --> Router Class Initialized
INFO - 2021-07-15 21:48:24 --> Output Class Initialized
INFO - 2021-07-15 21:48:24 --> Security Class Initialized
DEBUG - 2021-07-15 21:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:48:24 --> Input Class Initialized
INFO - 2021-07-15 21:48:24 --> Language Class Initialized
INFO - 2021-07-15 21:48:24 --> Loader Class Initialized
INFO - 2021-07-15 21:48:24 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:48:24 --> Helper loaded: url_helper
INFO - 2021-07-15 21:48:24 --> Helper loaded: file_helper
INFO - 2021-07-15 21:48:24 --> Helper loaded: form_helper
INFO - 2021-07-15 21:48:24 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:48:24 --> Helper loaded: security_helper
INFO - 2021-07-15 21:48:24 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:48:24 --> Helper loaded: language_helper
INFO - 2021-07-15 21:48:24 --> Helper loaded: general_helper
INFO - 2021-07-15 21:48:24 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:48:24 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:48:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:48:24 --> Parser Class Initialized
INFO - 2021-07-15 21:48:24 --> Form Validation Class Initialized
INFO - 2021-07-15 21:48:24 --> Upload Class Initialized
INFO - 2021-07-15 21:48:24 --> Email Class Initialized
INFO - 2021-07-15 21:48:24 --> MY_Model class loaded
INFO - 2021-07-15 21:48:24 --> Model "Users_model" initialized
INFO - 2021-07-15 21:48:24 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:48:24 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:48:24 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:48:24 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:48:24 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:48:24 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:48:24 --> Database Driver Class Initialized
INFO - 2021-07-15 21:48:24 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:48:24 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:48:24 --> Controller Class Initialized
ERROR - 2021-07-15 21:48:24 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 21:48:24 --> File loaded: C:\wamp64\www\crm\application\views\roles/list.php
INFO - 2021-07-15 21:48:24 --> Final output sent to browser
DEBUG - 2021-07-15 21:48:24 --> Total execution time: 0.0707
INFO - 2021-07-15 21:48:27 --> Config Class Initialized
INFO - 2021-07-15 21:48:27 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:48:27 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:48:27 --> Utf8 Class Initialized
INFO - 2021-07-15 21:48:27 --> URI Class Initialized
INFO - 2021-07-15 21:48:27 --> Router Class Initialized
INFO - 2021-07-15 21:48:27 --> Output Class Initialized
INFO - 2021-07-15 21:48:27 --> Security Class Initialized
DEBUG - 2021-07-15 21:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:48:27 --> Input Class Initialized
INFO - 2021-07-15 21:48:27 --> Language Class Initialized
INFO - 2021-07-15 21:48:27 --> Loader Class Initialized
INFO - 2021-07-15 21:48:27 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:48:27 --> Helper loaded: url_helper
INFO - 2021-07-15 21:48:27 --> Helper loaded: file_helper
INFO - 2021-07-15 21:48:27 --> Helper loaded: form_helper
INFO - 2021-07-15 21:48:27 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:48:27 --> Helper loaded: security_helper
INFO - 2021-07-15 21:48:27 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:48:27 --> Helper loaded: language_helper
INFO - 2021-07-15 21:48:27 --> Helper loaded: general_helper
INFO - 2021-07-15 21:48:27 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:48:27 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:48:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:48:27 --> Parser Class Initialized
INFO - 2021-07-15 21:48:27 --> Form Validation Class Initialized
INFO - 2021-07-15 21:48:27 --> Upload Class Initialized
INFO - 2021-07-15 21:48:27 --> Email Class Initialized
INFO - 2021-07-15 21:48:27 --> MY_Model class loaded
INFO - 2021-07-15 21:48:27 --> Model "Users_model" initialized
INFO - 2021-07-15 21:48:27 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:48:27 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:48:27 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:48:27 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:48:27 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:48:27 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:48:27 --> Database Driver Class Initialized
INFO - 2021-07-15 21:48:28 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:48:28 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:48:28 --> Controller Class Initialized
ERROR - 2021-07-15 21:48:28 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-15 21:48:28 --> Could not find the language line "edit_role"
ERROR - 2021-07-15 21:48:28 --> Could not find the language line "edit_role"
INFO - 2021-07-15 21:48:28 --> File loaded: C:\wamp64\www\crm\application\views\roles/edit.php
INFO - 2021-07-15 21:48:28 --> Final output sent to browser
DEBUG - 2021-07-15 21:48:28 --> Total execution time: 0.1269
INFO - 2021-07-15 21:48:33 --> Config Class Initialized
INFO - 2021-07-15 21:48:33 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:48:33 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:48:33 --> Utf8 Class Initialized
INFO - 2021-07-15 21:48:33 --> URI Class Initialized
INFO - 2021-07-15 21:48:33 --> Router Class Initialized
INFO - 2021-07-15 21:48:33 --> Output Class Initialized
INFO - 2021-07-15 21:48:33 --> Security Class Initialized
DEBUG - 2021-07-15 21:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:48:33 --> Input Class Initialized
INFO - 2021-07-15 21:48:33 --> Language Class Initialized
INFO - 2021-07-15 21:48:33 --> Loader Class Initialized
INFO - 2021-07-15 21:48:33 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:48:33 --> Helper loaded: url_helper
INFO - 2021-07-15 21:48:33 --> Helper loaded: file_helper
INFO - 2021-07-15 21:48:33 --> Helper loaded: form_helper
INFO - 2021-07-15 21:48:33 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:48:33 --> Helper loaded: security_helper
INFO - 2021-07-15 21:48:33 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:48:33 --> Helper loaded: language_helper
INFO - 2021-07-15 21:48:33 --> Helper loaded: general_helper
INFO - 2021-07-15 21:48:33 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:48:33 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:48:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:48:33 --> Parser Class Initialized
INFO - 2021-07-15 21:48:33 --> Form Validation Class Initialized
INFO - 2021-07-15 21:48:33 --> Upload Class Initialized
INFO - 2021-07-15 21:48:33 --> Email Class Initialized
INFO - 2021-07-15 21:48:33 --> MY_Model class loaded
INFO - 2021-07-15 21:48:33 --> Model "Users_model" initialized
INFO - 2021-07-15 21:48:33 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:48:33 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:48:33 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:48:33 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:48:33 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:48:33 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:48:33 --> Database Driver Class Initialized
INFO - 2021-07-15 21:48:34 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:48:34 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:48:34 --> Controller Class Initialized
INFO - 2021-07-15 21:48:34 --> Config Class Initialized
INFO - 2021-07-15 21:48:34 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:48:34 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:48:34 --> Utf8 Class Initialized
INFO - 2021-07-15 21:48:34 --> URI Class Initialized
INFO - 2021-07-15 21:48:34 --> Router Class Initialized
INFO - 2021-07-15 21:48:34 --> Output Class Initialized
INFO - 2021-07-15 21:48:34 --> Security Class Initialized
DEBUG - 2021-07-15 21:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:48:34 --> Input Class Initialized
INFO - 2021-07-15 21:48:34 --> Language Class Initialized
INFO - 2021-07-15 21:48:34 --> Loader Class Initialized
INFO - 2021-07-15 21:48:34 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:48:34 --> Helper loaded: url_helper
INFO - 2021-07-15 21:48:34 --> Helper loaded: file_helper
INFO - 2021-07-15 21:48:34 --> Helper loaded: form_helper
INFO - 2021-07-15 21:48:34 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:48:34 --> Helper loaded: security_helper
INFO - 2021-07-15 21:48:34 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:48:34 --> Helper loaded: language_helper
INFO - 2021-07-15 21:48:34 --> Helper loaded: general_helper
INFO - 2021-07-15 21:48:34 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:48:34 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:48:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:48:34 --> Parser Class Initialized
INFO - 2021-07-15 21:48:34 --> Form Validation Class Initialized
INFO - 2021-07-15 21:48:34 --> Upload Class Initialized
INFO - 2021-07-15 21:48:34 --> Email Class Initialized
INFO - 2021-07-15 21:48:34 --> MY_Model class loaded
INFO - 2021-07-15 21:48:34 --> Model "Users_model" initialized
INFO - 2021-07-15 21:48:34 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:48:34 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:48:34 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:48:34 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:48:34 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:48:34 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:48:34 --> Database Driver Class Initialized
INFO - 2021-07-15 21:48:34 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:48:34 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:48:34 --> Controller Class Initialized
ERROR - 2021-07-15 21:48:34 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 21:48:34 --> File loaded: C:\wamp64\www\crm\application\views\roles/list.php
INFO - 2021-07-15 21:48:34 --> Final output sent to browser
DEBUG - 2021-07-15 21:48:34 --> Total execution time: 0.0847
INFO - 2021-07-15 21:48:36 --> Config Class Initialized
INFO - 2021-07-15 21:48:36 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:48:36 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:48:36 --> Utf8 Class Initialized
INFO - 2021-07-15 21:48:36 --> URI Class Initialized
INFO - 2021-07-15 21:48:36 --> Router Class Initialized
INFO - 2021-07-15 21:48:36 --> Output Class Initialized
INFO - 2021-07-15 21:48:36 --> Security Class Initialized
DEBUG - 2021-07-15 21:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:48:36 --> Input Class Initialized
INFO - 2021-07-15 21:48:36 --> Language Class Initialized
INFO - 2021-07-15 21:48:36 --> Loader Class Initialized
INFO - 2021-07-15 21:48:36 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:48:36 --> Helper loaded: url_helper
INFO - 2021-07-15 21:48:36 --> Helper loaded: file_helper
INFO - 2021-07-15 21:48:36 --> Helper loaded: form_helper
INFO - 2021-07-15 21:48:36 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:48:36 --> Helper loaded: security_helper
INFO - 2021-07-15 21:48:36 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:48:36 --> Helper loaded: language_helper
INFO - 2021-07-15 21:48:36 --> Helper loaded: general_helper
INFO - 2021-07-15 21:48:36 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:48:36 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:48:36 --> Parser Class Initialized
INFO - 2021-07-15 21:48:36 --> Form Validation Class Initialized
INFO - 2021-07-15 21:48:36 --> Upload Class Initialized
INFO - 2021-07-15 21:48:36 --> Email Class Initialized
INFO - 2021-07-15 21:48:36 --> MY_Model class loaded
INFO - 2021-07-15 21:48:36 --> Model "Users_model" initialized
INFO - 2021-07-15 21:48:36 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:48:36 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:48:36 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:48:36 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:48:36 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:48:36 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:48:36 --> Database Driver Class Initialized
INFO - 2021-07-15 21:48:36 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:48:36 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:48:36 --> Controller Class Initialized
ERROR - 2021-07-15 21:48:36 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-15 21:48:36 --> Could not find the language line "edit_role"
ERROR - 2021-07-15 21:48:36 --> Could not find the language line "edit_role"
INFO - 2021-07-15 21:48:36 --> File loaded: C:\wamp64\www\crm\application\views\roles/edit.php
INFO - 2021-07-15 21:48:36 --> Final output sent to browser
DEBUG - 2021-07-15 21:48:36 --> Total execution time: 0.0651
INFO - 2021-07-15 21:48:40 --> Config Class Initialized
INFO - 2021-07-15 21:48:40 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:48:40 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:48:40 --> Utf8 Class Initialized
INFO - 2021-07-15 21:48:40 --> URI Class Initialized
INFO - 2021-07-15 21:48:40 --> Router Class Initialized
INFO - 2021-07-15 21:48:40 --> Output Class Initialized
INFO - 2021-07-15 21:48:40 --> Security Class Initialized
DEBUG - 2021-07-15 21:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:48:40 --> Input Class Initialized
INFO - 2021-07-15 21:48:40 --> Language Class Initialized
INFO - 2021-07-15 21:48:40 --> Loader Class Initialized
INFO - 2021-07-15 21:48:40 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:48:40 --> Helper loaded: url_helper
INFO - 2021-07-15 21:48:40 --> Helper loaded: file_helper
INFO - 2021-07-15 21:48:40 --> Helper loaded: form_helper
INFO - 2021-07-15 21:48:40 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:48:40 --> Helper loaded: security_helper
INFO - 2021-07-15 21:48:40 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:48:40 --> Helper loaded: language_helper
INFO - 2021-07-15 21:48:40 --> Helper loaded: general_helper
INFO - 2021-07-15 21:48:40 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:48:40 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:48:40 --> Parser Class Initialized
INFO - 2021-07-15 21:48:40 --> Form Validation Class Initialized
INFO - 2021-07-15 21:48:40 --> Upload Class Initialized
INFO - 2021-07-15 21:48:40 --> Email Class Initialized
INFO - 2021-07-15 21:48:40 --> MY_Model class loaded
INFO - 2021-07-15 21:48:40 --> Model "Users_model" initialized
INFO - 2021-07-15 21:48:40 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:48:40 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:48:40 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:48:40 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:48:40 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:48:40 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:48:40 --> Database Driver Class Initialized
INFO - 2021-07-15 21:48:40 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:48:40 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:48:40 --> Controller Class Initialized
INFO - 2021-07-15 21:48:40 --> Config Class Initialized
INFO - 2021-07-15 21:48:40 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:48:40 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:48:40 --> Utf8 Class Initialized
INFO - 2021-07-15 21:48:40 --> URI Class Initialized
INFO - 2021-07-15 21:48:40 --> Router Class Initialized
INFO - 2021-07-15 21:48:40 --> Output Class Initialized
INFO - 2021-07-15 21:48:40 --> Security Class Initialized
DEBUG - 2021-07-15 21:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:48:40 --> Input Class Initialized
INFO - 2021-07-15 21:48:40 --> Language Class Initialized
INFO - 2021-07-15 21:48:40 --> Loader Class Initialized
INFO - 2021-07-15 21:48:40 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:48:40 --> Helper loaded: url_helper
INFO - 2021-07-15 21:48:40 --> Helper loaded: file_helper
INFO - 2021-07-15 21:48:40 --> Helper loaded: form_helper
INFO - 2021-07-15 21:48:40 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:48:40 --> Helper loaded: security_helper
INFO - 2021-07-15 21:48:40 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:48:40 --> Helper loaded: language_helper
INFO - 2021-07-15 21:48:40 --> Helper loaded: general_helper
INFO - 2021-07-15 21:48:40 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:48:40 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:48:40 --> Parser Class Initialized
INFO - 2021-07-15 21:48:40 --> Form Validation Class Initialized
INFO - 2021-07-15 21:48:40 --> Upload Class Initialized
INFO - 2021-07-15 21:48:40 --> Email Class Initialized
INFO - 2021-07-15 21:48:40 --> MY_Model class loaded
INFO - 2021-07-15 21:48:40 --> Model "Users_model" initialized
INFO - 2021-07-15 21:48:40 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:48:40 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:48:40 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:48:40 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:48:40 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:48:40 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:48:40 --> Database Driver Class Initialized
INFO - 2021-07-15 21:48:40 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:48:40 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:48:40 --> Controller Class Initialized
ERROR - 2021-07-15 21:48:40 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 21:48:40 --> File loaded: C:\wamp64\www\crm\application\views\roles/list.php
INFO - 2021-07-15 21:48:40 --> Final output sent to browser
DEBUG - 2021-07-15 21:48:40 --> Total execution time: 0.0709
INFO - 2021-07-15 21:48:52 --> Config Class Initialized
INFO - 2021-07-15 21:48:52 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:48:52 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:48:52 --> Utf8 Class Initialized
INFO - 2021-07-15 21:48:52 --> URI Class Initialized
INFO - 2021-07-15 21:48:52 --> Router Class Initialized
INFO - 2021-07-15 21:48:52 --> Output Class Initialized
INFO - 2021-07-15 21:48:52 --> Security Class Initialized
DEBUG - 2021-07-15 21:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:48:52 --> Input Class Initialized
INFO - 2021-07-15 21:48:52 --> Language Class Initialized
INFO - 2021-07-15 21:48:52 --> Loader Class Initialized
INFO - 2021-07-15 21:48:52 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:48:52 --> Helper loaded: url_helper
INFO - 2021-07-15 21:48:52 --> Helper loaded: file_helper
INFO - 2021-07-15 21:48:52 --> Helper loaded: form_helper
INFO - 2021-07-15 21:48:52 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:48:52 --> Helper loaded: security_helper
INFO - 2021-07-15 21:48:52 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:48:52 --> Helper loaded: language_helper
INFO - 2021-07-15 21:48:52 --> Helper loaded: general_helper
INFO - 2021-07-15 21:48:52 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:48:52 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:48:52 --> Parser Class Initialized
INFO - 2021-07-15 21:48:52 --> Form Validation Class Initialized
INFO - 2021-07-15 21:48:52 --> Upload Class Initialized
INFO - 2021-07-15 21:48:52 --> Email Class Initialized
INFO - 2021-07-15 21:48:52 --> MY_Model class loaded
INFO - 2021-07-15 21:48:52 --> Model "Users_model" initialized
INFO - 2021-07-15 21:48:52 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:48:52 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:48:52 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:48:52 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:48:52 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:48:52 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:48:52 --> Database Driver Class Initialized
INFO - 2021-07-15 21:48:52 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:48:52 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:48:52 --> Controller Class Initialized
ERROR - 2021-07-15 21:48:52 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 21:48:52 --> File loaded: C:\wamp64\www\crm\application\views\users/list.php
INFO - 2021-07-15 21:48:52 --> Final output sent to browser
DEBUG - 2021-07-15 21:48:52 --> Total execution time: 0.2111
INFO - 2021-07-15 21:48:53 --> Config Class Initialized
INFO - 2021-07-15 21:48:53 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:48:53 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:48:53 --> Utf8 Class Initialized
INFO - 2021-07-15 21:48:53 --> URI Class Initialized
INFO - 2021-07-15 21:48:53 --> Router Class Initialized
INFO - 2021-07-15 21:48:53 --> Output Class Initialized
INFO - 2021-07-15 21:48:53 --> Config Class Initialized
INFO - 2021-07-15 21:48:53 --> Security Class Initialized
INFO - 2021-07-15 21:48:53 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-15 21:48:53 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:48:53 --> Input Class Initialized
INFO - 2021-07-15 21:48:53 --> Utf8 Class Initialized
INFO - 2021-07-15 21:48:53 --> Language Class Initialized
INFO - 2021-07-15 21:48:53 --> URI Class Initialized
INFO - 2021-07-15 21:48:53 --> Loader Class Initialized
INFO - 2021-07-15 21:48:53 --> Router Class Initialized
INFO - 2021-07-15 21:48:53 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:48:53 --> Output Class Initialized
INFO - 2021-07-15 21:48:53 --> Helper loaded: url_helper
INFO - 2021-07-15 21:48:53 --> Config Class Initialized
INFO - 2021-07-15 21:48:53 --> Security Class Initialized
INFO - 2021-07-15 21:48:53 --> Hooks Class Initialized
INFO - 2021-07-15 21:48:53 --> Helper loaded: file_helper
DEBUG - 2021-07-15 21:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-07-15 21:48:53 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:48:53 --> Input Class Initialized
INFO - 2021-07-15 21:48:53 --> Helper loaded: form_helper
INFO - 2021-07-15 21:48:53 --> Utf8 Class Initialized
INFO - 2021-07-15 21:48:53 --> Language Class Initialized
INFO - 2021-07-15 21:48:53 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:48:53 --> URI Class Initialized
INFO - 2021-07-15 21:48:53 --> Loader Class Initialized
INFO - 2021-07-15 21:48:53 --> Helper loaded: security_helper
INFO - 2021-07-15 21:48:53 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:48:53 --> Router Class Initialized
INFO - 2021-07-15 21:48:53 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:48:53 --> Helper loaded: language_helper
INFO - 2021-07-15 21:48:53 --> Output Class Initialized
INFO - 2021-07-15 21:48:53 --> Helper loaded: url_helper
INFO - 2021-07-15 21:48:53 --> Helper loaded: general_helper
INFO - 2021-07-15 21:48:53 --> Security Class Initialized
INFO - 2021-07-15 21:48:53 --> Helper loaded: file_helper
INFO - 2021-07-15 21:48:53 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:48:53 --> Config Class Initialized
DEBUG - 2021-07-15 21:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:48:53 --> Helper loaded: form_helper
INFO - 2021-07-15 21:48:53 --> Hooks Class Initialized
INFO - 2021-07-15 21:48:53 --> Input Class Initialized
INFO - 2021-07-15 21:48:53 --> Database Driver Class Initialized
INFO - 2021-07-15 21:48:53 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:48:53 --> Language Class Initialized
DEBUG - 2021-07-15 21:48:53 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:48:53 --> Utf8 Class Initialized
INFO - 2021-07-15 21:48:53 --> Helper loaded: security_helper
INFO - 2021-07-15 21:48:53 --> Loader Class Initialized
INFO - 2021-07-15 21:48:53 --> URI Class Initialized
INFO - 2021-07-15 21:48:53 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:48:53 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:48:53 --> Config Class Initialized
DEBUG - 2021-07-15 21:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:48:53 --> Helper loaded: language_helper
INFO - 2021-07-15 21:48:53 --> Router Class Initialized
INFO - 2021-07-15 21:48:53 --> Hooks Class Initialized
INFO - 2021-07-15 21:48:53 --> Helper loaded: url_helper
INFO - 2021-07-15 21:48:53 --> Helper loaded: general_helper
INFO - 2021-07-15 21:48:53 --> Output Class Initialized
INFO - 2021-07-15 21:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:48:53 --> Helper loaded: file_helper
DEBUG - 2021-07-15 21:48:53 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:48:53 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:48:53 --> Security Class Initialized
INFO - 2021-07-15 21:48:53 --> Utf8 Class Initialized
INFO - 2021-07-15 21:48:53 --> Parser Class Initialized
INFO - 2021-07-15 21:48:53 --> Helper loaded: form_helper
DEBUG - 2021-07-15 21:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:48:53 --> Database Driver Class Initialized
INFO - 2021-07-15 21:48:53 --> URI Class Initialized
INFO - 2021-07-15 21:48:53 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:48:53 --> Form Validation Class Initialized
INFO - 2021-07-15 21:48:53 --> Input Class Initialized
INFO - 2021-07-15 21:48:53 --> Config Class Initialized
INFO - 2021-07-15 21:48:53 --> Helper loaded: security_helper
INFO - 2021-07-15 21:48:53 --> Router Class Initialized
INFO - 2021-07-15 21:48:53 --> Language Class Initialized
INFO - 2021-07-15 21:48:53 --> Hooks Class Initialized
INFO - 2021-07-15 21:48:53 --> Upload Class Initialized
INFO - 2021-07-15 21:48:53 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:48:53 --> Output Class Initialized
INFO - 2021-07-15 21:48:53 --> Loader Class Initialized
DEBUG - 2021-07-15 21:48:53 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:48:53 --> Helper loaded: language_helper
INFO - 2021-07-15 21:48:53 --> Utf8 Class Initialized
DEBUG - 2021-07-15 21:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:48:53 --> Email Class Initialized
INFO - 2021-07-15 21:48:53 --> Security Class Initialized
INFO - 2021-07-15 21:48:53 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:48:53 --> Helper loaded: general_helper
INFO - 2021-07-15 21:48:53 --> URI Class Initialized
INFO - 2021-07-15 21:48:53 --> MY_Model class loaded
DEBUG - 2021-07-15 21:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:48:53 --> Helper loaded: url_helper
INFO - 2021-07-15 21:48:53 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:48:53 --> Model "Users_model" initialized
INFO - 2021-07-15 21:48:53 --> Input Class Initialized
INFO - 2021-07-15 21:48:53 --> Router Class Initialized
INFO - 2021-07-15 21:48:53 --> Helper loaded: file_helper
INFO - 2021-07-15 21:48:53 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:48:53 --> Database Driver Class Initialized
INFO - 2021-07-15 21:48:53 --> Language Class Initialized
INFO - 2021-07-15 21:48:53 --> Output Class Initialized
INFO - 2021-07-15 21:48:53 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:48:53 --> Helper loaded: form_helper
INFO - 2021-07-15 21:48:53 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:48:53 --> Loader Class Initialized
INFO - 2021-07-15 21:48:53 --> Security Class Initialized
INFO - 2021-07-15 21:48:53 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:48:53 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:48:53 --> Helper loaded: security_helper
INFO - 2021-07-15 21:48:53 --> Helper loaded: basic_helper
DEBUG - 2021-07-15 21:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:48:53 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:48:53 --> Input Class Initialized
INFO - 2021-07-15 21:48:53 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:48:53 --> Helper loaded: url_helper
INFO - 2021-07-15 21:48:53 --> Language Class Initialized
INFO - 2021-07-15 21:48:53 --> Database Driver Class Initialized
INFO - 2021-07-15 21:48:53 --> Helper loaded: language_helper
INFO - 2021-07-15 21:48:53 --> Helper loaded: file_helper
INFO - 2021-07-15 21:48:53 --> Loader Class Initialized
INFO - 2021-07-15 21:48:53 --> Helper loaded: general_helper
INFO - 2021-07-15 21:48:53 --> Helper loaded: form_helper
INFO - 2021-07-15 21:48:53 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:48:53 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:48:53 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:48:53 --> Helper loaded: url_helper
INFO - 2021-07-15 21:48:53 --> Helper loaded: security_helper
INFO - 2021-07-15 21:48:53 --> Helper loaded: file_helper
INFO - 2021-07-15 21:48:53 --> Database Driver Class Initialized
INFO - 2021-07-15 21:48:53 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:48:53 --> Helper loaded: form_helper
INFO - 2021-07-15 21:48:53 --> Helper loaded: language_helper
INFO - 2021-07-15 21:48:53 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:48:53 --> Helper loaded: general_helper
INFO - 2021-07-15 21:48:53 --> Helper loaded: security_helper
INFO - 2021-07-15 21:48:53 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:48:53 --> Helper loaded: directory_helper
DEBUG - 2021-07-15 21:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:48:53 --> Database Driver Class Initialized
INFO - 2021-07-15 21:48:53 --> Helper loaded: language_helper
INFO - 2021-07-15 21:48:53 --> Helper loaded: general_helper
DEBUG - 2021-07-15 21:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:48:53 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:48:53 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-07-15 21:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:48:53 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:48:53 --> Controller Class Initialized
INFO - 2021-07-15 21:48:53 --> Final output sent to browser
DEBUG - 2021-07-15 21:48:53 --> Total execution time: 0.0813
INFO - 2021-07-15 21:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:48:53 --> Parser Class Initialized
INFO - 2021-07-15 21:48:53 --> Form Validation Class Initialized
INFO - 2021-07-15 21:48:53 --> Upload Class Initialized
INFO - 2021-07-15 21:48:53 --> Email Class Initialized
INFO - 2021-07-15 21:48:53 --> MY_Model class loaded
INFO - 2021-07-15 21:48:53 --> Model "Users_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:48:53 --> Database Driver Class Initialized
INFO - 2021-07-15 21:48:53 --> Config Class Initialized
INFO - 2021-07-15 21:48:53 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:48:53 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:48:53 --> Utf8 Class Initialized
INFO - 2021-07-15 21:48:53 --> URI Class Initialized
INFO - 2021-07-15 21:48:53 --> Router Class Initialized
INFO - 2021-07-15 21:48:53 --> Output Class Initialized
INFO - 2021-07-15 21:48:53 --> Security Class Initialized
DEBUG - 2021-07-15 21:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:48:53 --> Input Class Initialized
INFO - 2021-07-15 21:48:53 --> Language Class Initialized
INFO - 2021-07-15 21:48:53 --> Loader Class Initialized
INFO - 2021-07-15 21:48:53 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:48:53 --> Helper loaded: url_helper
INFO - 2021-07-15 21:48:53 --> Helper loaded: file_helper
INFO - 2021-07-15 21:48:53 --> Helper loaded: form_helper
INFO - 2021-07-15 21:48:53 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:48:53 --> Helper loaded: security_helper
INFO - 2021-07-15 21:48:53 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:48:53 --> Helper loaded: language_helper
INFO - 2021-07-15 21:48:53 --> Helper loaded: general_helper
INFO - 2021-07-15 21:48:53 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:48:53 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:48:53 --> Database Driver Class Initialized
INFO - 2021-07-15 21:48:53 --> Controller Class Initialized
DEBUG - 2021-07-15 21:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:48:53 --> Final output sent to browser
DEBUG - 2021-07-15 21:48:53 --> Total execution time: 0.1073
INFO - 2021-07-15 21:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:48:53 --> Parser Class Initialized
INFO - 2021-07-15 21:48:53 --> Form Validation Class Initialized
INFO - 2021-07-15 21:48:53 --> Upload Class Initialized
INFO - 2021-07-15 21:48:53 --> Email Class Initialized
INFO - 2021-07-15 21:48:53 --> MY_Model class loaded
INFO - 2021-07-15 21:48:53 --> Model "Users_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:48:53 --> Config Class Initialized
INFO - 2021-07-15 21:48:53 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:48:53 --> Hooks Class Initialized
INFO - 2021-07-15 21:48:53 --> Model "Templates_model" initialized
DEBUG - 2021-07-15 21:48:53 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:48:53 --> Utf8 Class Initialized
INFO - 2021-07-15 21:48:53 --> Database Driver Class Initialized
INFO - 2021-07-15 21:48:53 --> URI Class Initialized
INFO - 2021-07-15 21:48:53 --> Router Class Initialized
INFO - 2021-07-15 21:48:53 --> Output Class Initialized
INFO - 2021-07-15 21:48:53 --> Security Class Initialized
DEBUG - 2021-07-15 21:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:48:53 --> Input Class Initialized
INFO - 2021-07-15 21:48:53 --> Language Class Initialized
INFO - 2021-07-15 21:48:53 --> Loader Class Initialized
INFO - 2021-07-15 21:48:53 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:48:53 --> Helper loaded: url_helper
INFO - 2021-07-15 21:48:53 --> Helper loaded: file_helper
INFO - 2021-07-15 21:48:53 --> Helper loaded: form_helper
INFO - 2021-07-15 21:48:53 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:48:53 --> Helper loaded: security_helper
INFO - 2021-07-15 21:48:53 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:48:53 --> Helper loaded: language_helper
INFO - 2021-07-15 21:48:53 --> Helper loaded: general_helper
INFO - 2021-07-15 21:48:53 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:48:53 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:48:53 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:48:53 --> Controller Class Initialized
INFO - 2021-07-15 21:48:53 --> Final output sent to browser
DEBUG - 2021-07-15 21:48:53 --> Total execution time: 0.1292
INFO - 2021-07-15 21:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:48:53 --> Parser Class Initialized
INFO - 2021-07-15 21:48:53 --> Form Validation Class Initialized
INFO - 2021-07-15 21:48:53 --> Upload Class Initialized
INFO - 2021-07-15 21:48:53 --> Email Class Initialized
INFO - 2021-07-15 21:48:53 --> MY_Model class loaded
INFO - 2021-07-15 21:48:53 --> Model "Users_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:48:53 --> Config Class Initialized
INFO - 2021-07-15 21:48:53 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:48:53 --> Hooks Class Initialized
INFO - 2021-07-15 21:48:53 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:48:53 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:48:53 --> Utf8 Class Initialized
INFO - 2021-07-15 21:48:53 --> URI Class Initialized
INFO - 2021-07-15 21:48:53 --> Router Class Initialized
INFO - 2021-07-15 21:48:53 --> Output Class Initialized
INFO - 2021-07-15 21:48:53 --> Security Class Initialized
DEBUG - 2021-07-15 21:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:48:53 --> Input Class Initialized
INFO - 2021-07-15 21:48:53 --> Language Class Initialized
INFO - 2021-07-15 21:48:53 --> Loader Class Initialized
INFO - 2021-07-15 21:48:53 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:48:53 --> Helper loaded: url_helper
INFO - 2021-07-15 21:48:53 --> Helper loaded: file_helper
INFO - 2021-07-15 21:48:53 --> Helper loaded: form_helper
INFO - 2021-07-15 21:48:53 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:48:53 --> Helper loaded: security_helper
INFO - 2021-07-15 21:48:53 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:48:53 --> Helper loaded: language_helper
INFO - 2021-07-15 21:48:53 --> Helper loaded: general_helper
INFO - 2021-07-15 21:48:53 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:48:53 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:48:53 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:48:53 --> Controller Class Initialized
INFO - 2021-07-15 21:48:53 --> Final output sent to browser
DEBUG - 2021-07-15 21:48:53 --> Total execution time: 0.1664
INFO - 2021-07-15 21:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:48:53 --> Parser Class Initialized
INFO - 2021-07-15 21:48:53 --> Form Validation Class Initialized
INFO - 2021-07-15 21:48:53 --> Upload Class Initialized
INFO - 2021-07-15 21:48:53 --> Email Class Initialized
INFO - 2021-07-15 21:48:53 --> MY_Model class loaded
INFO - 2021-07-15 21:48:53 --> Model "Users_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:48:53 --> Database Driver Class Initialized
INFO - 2021-07-15 21:48:53 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:48:53 --> Controller Class Initialized
INFO - 2021-07-15 21:48:53 --> Final output sent to browser
DEBUG - 2021-07-15 21:48:53 --> Total execution time: 0.1853
INFO - 2021-07-15 21:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:48:53 --> Parser Class Initialized
INFO - 2021-07-15 21:48:53 --> Form Validation Class Initialized
INFO - 2021-07-15 21:48:53 --> Upload Class Initialized
INFO - 2021-07-15 21:48:53 --> Email Class Initialized
INFO - 2021-07-15 21:48:53 --> MY_Model class loaded
INFO - 2021-07-15 21:48:53 --> Model "Users_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:48:53 --> Database Driver Class Initialized
INFO - 2021-07-15 21:48:53 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:48:53 --> Controller Class Initialized
INFO - 2021-07-15 21:48:53 --> Final output sent to browser
DEBUG - 2021-07-15 21:48:53 --> Total execution time: 0.2093
INFO - 2021-07-15 21:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:48:53 --> Parser Class Initialized
INFO - 2021-07-15 21:48:53 --> Form Validation Class Initialized
INFO - 2021-07-15 21:48:53 --> Upload Class Initialized
INFO - 2021-07-15 21:48:53 --> Email Class Initialized
INFO - 2021-07-15 21:48:53 --> MY_Model class loaded
INFO - 2021-07-15 21:48:53 --> Model "Users_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:48:53 --> Database Driver Class Initialized
INFO - 2021-07-15 21:48:53 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:48:53 --> Controller Class Initialized
INFO - 2021-07-15 21:48:53 --> Final output sent to browser
DEBUG - 2021-07-15 21:48:53 --> Total execution time: 0.1729
INFO - 2021-07-15 21:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:48:53 --> Parser Class Initialized
INFO - 2021-07-15 21:48:53 --> Form Validation Class Initialized
INFO - 2021-07-15 21:48:53 --> Upload Class Initialized
INFO - 2021-07-15 21:48:53 --> Email Class Initialized
INFO - 2021-07-15 21:48:53 --> MY_Model class loaded
INFO - 2021-07-15 21:48:53 --> Model "Users_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:48:53 --> Database Driver Class Initialized
INFO - 2021-07-15 21:48:53 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:48:53 --> Controller Class Initialized
INFO - 2021-07-15 21:48:53 --> Final output sent to browser
DEBUG - 2021-07-15 21:48:53 --> Total execution time: 0.1748
INFO - 2021-07-15 21:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:48:53 --> Parser Class Initialized
INFO - 2021-07-15 21:48:53 --> Form Validation Class Initialized
INFO - 2021-07-15 21:48:53 --> Upload Class Initialized
INFO - 2021-07-15 21:48:53 --> Email Class Initialized
INFO - 2021-07-15 21:48:53 --> MY_Model class loaded
INFO - 2021-07-15 21:48:53 --> Model "Users_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:48:53 --> Database Driver Class Initialized
INFO - 2021-07-15 21:48:53 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:48:53 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:48:53 --> Controller Class Initialized
INFO - 2021-07-15 21:48:53 --> Final output sent to browser
DEBUG - 2021-07-15 21:48:53 --> Total execution time: 0.1696
INFO - 2021-07-15 21:48:55 --> Config Class Initialized
INFO - 2021-07-15 21:48:55 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:48:55 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:48:55 --> Utf8 Class Initialized
INFO - 2021-07-15 21:48:55 --> URI Class Initialized
INFO - 2021-07-15 21:48:55 --> Router Class Initialized
INFO - 2021-07-15 21:48:55 --> Output Class Initialized
INFO - 2021-07-15 21:48:55 --> Security Class Initialized
DEBUG - 2021-07-15 21:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:48:55 --> Input Class Initialized
INFO - 2021-07-15 21:48:55 --> Language Class Initialized
INFO - 2021-07-15 21:48:55 --> Loader Class Initialized
INFO - 2021-07-15 21:48:55 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:48:55 --> Helper loaded: url_helper
INFO - 2021-07-15 21:48:55 --> Helper loaded: file_helper
INFO - 2021-07-15 21:48:55 --> Helper loaded: form_helper
INFO - 2021-07-15 21:48:55 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:48:55 --> Helper loaded: security_helper
INFO - 2021-07-15 21:48:55 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:48:55 --> Helper loaded: language_helper
INFO - 2021-07-15 21:48:55 --> Helper loaded: general_helper
INFO - 2021-07-15 21:48:55 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:48:55 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:48:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:48:55 --> Parser Class Initialized
INFO - 2021-07-15 21:48:55 --> Form Validation Class Initialized
INFO - 2021-07-15 21:48:55 --> Upload Class Initialized
INFO - 2021-07-15 21:48:55 --> Email Class Initialized
INFO - 2021-07-15 21:48:55 --> MY_Model class loaded
INFO - 2021-07-15 21:48:55 --> Model "Users_model" initialized
INFO - 2021-07-15 21:48:55 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:48:55 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:48:55 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:48:55 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:48:55 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:48:55 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:48:55 --> Database Driver Class Initialized
INFO - 2021-07-15 21:48:55 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:48:55 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:48:55 --> Controller Class Initialized
ERROR - 2021-07-15 21:48:55 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 21:48:55 --> File loaded: C:\wamp64\www\crm\application\views\permissions/list.php
INFO - 2021-07-15 21:48:55 --> Final output sent to browser
DEBUG - 2021-07-15 21:48:55 --> Total execution time: 0.1224
INFO - 2021-07-15 21:49:01 --> Config Class Initialized
INFO - 2021-07-15 21:49:01 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:49:01 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:49:01 --> Utf8 Class Initialized
INFO - 2021-07-15 21:49:01 --> URI Class Initialized
INFO - 2021-07-15 21:49:01 --> Router Class Initialized
INFO - 2021-07-15 21:49:01 --> Output Class Initialized
INFO - 2021-07-15 21:49:01 --> Security Class Initialized
DEBUG - 2021-07-15 21:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:49:01 --> Input Class Initialized
INFO - 2021-07-15 21:49:01 --> Language Class Initialized
INFO - 2021-07-15 21:49:01 --> Loader Class Initialized
INFO - 2021-07-15 21:49:01 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:49:01 --> Helper loaded: url_helper
INFO - 2021-07-15 21:49:01 --> Helper loaded: file_helper
INFO - 2021-07-15 21:49:01 --> Helper loaded: form_helper
INFO - 2021-07-15 21:49:01 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:49:01 --> Helper loaded: security_helper
INFO - 2021-07-15 21:49:01 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:49:01 --> Helper loaded: language_helper
INFO - 2021-07-15 21:49:01 --> Helper loaded: general_helper
INFO - 2021-07-15 21:49:01 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:49:01 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:49:01 --> Parser Class Initialized
INFO - 2021-07-15 21:49:01 --> Form Validation Class Initialized
INFO - 2021-07-15 21:49:01 --> Upload Class Initialized
INFO - 2021-07-15 21:49:01 --> Email Class Initialized
INFO - 2021-07-15 21:49:01 --> MY_Model class loaded
INFO - 2021-07-15 21:49:01 --> Model "Users_model" initialized
INFO - 2021-07-15 21:49:01 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:49:01 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:49:01 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:49:01 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:49:01 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:49:01 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:49:01 --> Database Driver Class Initialized
INFO - 2021-07-15 21:49:01 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:49:01 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:49:01 --> Controller Class Initialized
ERROR - 2021-07-15 21:49:01 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 21:49:01 --> File loaded: C:\wamp64\www\crm\application\views\roles/list.php
INFO - 2021-07-15 21:49:01 --> Final output sent to browser
DEBUG - 2021-07-15 21:49:01 --> Total execution time: 0.1702
INFO - 2021-07-15 21:49:07 --> Config Class Initialized
INFO - 2021-07-15 21:49:07 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:49:07 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:49:07 --> Utf8 Class Initialized
INFO - 2021-07-15 21:49:07 --> URI Class Initialized
INFO - 2021-07-15 21:49:07 --> Router Class Initialized
INFO - 2021-07-15 21:49:07 --> Output Class Initialized
INFO - 2021-07-15 21:49:07 --> Security Class Initialized
DEBUG - 2021-07-15 21:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:49:07 --> Input Class Initialized
INFO - 2021-07-15 21:49:07 --> Language Class Initialized
INFO - 2021-07-15 21:49:07 --> Loader Class Initialized
INFO - 2021-07-15 21:49:07 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:49:07 --> Helper loaded: url_helper
INFO - 2021-07-15 21:49:07 --> Helper loaded: file_helper
INFO - 2021-07-15 21:49:07 --> Helper loaded: form_helper
INFO - 2021-07-15 21:49:07 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:49:07 --> Helper loaded: security_helper
INFO - 2021-07-15 21:49:07 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:49:07 --> Helper loaded: language_helper
INFO - 2021-07-15 21:49:07 --> Helper loaded: general_helper
INFO - 2021-07-15 21:49:07 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:49:07 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:49:07 --> Parser Class Initialized
INFO - 2021-07-15 21:49:07 --> Form Validation Class Initialized
INFO - 2021-07-15 21:49:07 --> Upload Class Initialized
INFO - 2021-07-15 21:49:07 --> Email Class Initialized
INFO - 2021-07-15 21:49:07 --> MY_Model class loaded
INFO - 2021-07-15 21:49:07 --> Model "Users_model" initialized
INFO - 2021-07-15 21:49:07 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:49:07 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:49:07 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:49:07 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:49:07 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:49:07 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:49:07 --> Database Driver Class Initialized
INFO - 2021-07-15 21:49:08 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:49:08 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:49:08 --> Controller Class Initialized
ERROR - 2021-07-15 21:49:08 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 21:49:08 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 21:57:49 --> Config Class Initialized
INFO - 2021-07-15 21:57:49 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:57:49 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:57:49 --> Utf8 Class Initialized
INFO - 2021-07-15 21:57:49 --> URI Class Initialized
INFO - 2021-07-15 21:57:49 --> Router Class Initialized
INFO - 2021-07-15 21:57:49 --> Output Class Initialized
INFO - 2021-07-15 21:57:49 --> Security Class Initialized
DEBUG - 2021-07-15 21:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:57:49 --> Input Class Initialized
INFO - 2021-07-15 21:57:49 --> Language Class Initialized
ERROR - 2021-07-15 21:57:49 --> Severity: error --> Exception: syntax error, unexpected ']' C:\wamp64\www\crm\application\controllers\Car.php 41
INFO - 2021-07-15 21:57:50 --> Config Class Initialized
INFO - 2021-07-15 21:57:50 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:57:50 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:57:50 --> Utf8 Class Initialized
INFO - 2021-07-15 21:57:50 --> URI Class Initialized
INFO - 2021-07-15 21:57:50 --> Router Class Initialized
INFO - 2021-07-15 21:57:50 --> Output Class Initialized
INFO - 2021-07-15 21:57:50 --> Security Class Initialized
DEBUG - 2021-07-15 21:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:57:50 --> Input Class Initialized
INFO - 2021-07-15 21:57:50 --> Language Class Initialized
ERROR - 2021-07-15 21:57:50 --> Severity: error --> Exception: syntax error, unexpected ']' C:\wamp64\www\crm\application\controllers\Car.php 41
INFO - 2021-07-15 21:57:59 --> Config Class Initialized
INFO - 2021-07-15 21:57:59 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:57:59 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:57:59 --> Utf8 Class Initialized
INFO - 2021-07-15 21:57:59 --> URI Class Initialized
INFO - 2021-07-15 21:57:59 --> Router Class Initialized
INFO - 2021-07-15 21:57:59 --> Output Class Initialized
INFO - 2021-07-15 21:57:59 --> Security Class Initialized
DEBUG - 2021-07-15 21:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:57:59 --> Input Class Initialized
INFO - 2021-07-15 21:57:59 --> Language Class Initialized
INFO - 2021-07-15 21:57:59 --> Loader Class Initialized
INFO - 2021-07-15 21:57:59 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:57:59 --> Helper loaded: url_helper
INFO - 2021-07-15 21:57:59 --> Helper loaded: file_helper
INFO - 2021-07-15 21:57:59 --> Helper loaded: form_helper
INFO - 2021-07-15 21:57:59 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:57:59 --> Helper loaded: security_helper
INFO - 2021-07-15 21:57:59 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:57:59 --> Helper loaded: language_helper
INFO - 2021-07-15 21:57:59 --> Helper loaded: general_helper
INFO - 2021-07-15 21:57:59 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:57:59 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:57:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:57:59 --> Parser Class Initialized
INFO - 2021-07-15 21:57:59 --> Form Validation Class Initialized
INFO - 2021-07-15 21:57:59 --> Upload Class Initialized
INFO - 2021-07-15 21:57:59 --> Email Class Initialized
INFO - 2021-07-15 21:57:59 --> MY_Model class loaded
INFO - 2021-07-15 21:57:59 --> Model "Users_model" initialized
INFO - 2021-07-15 21:57:59 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:57:59 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:57:59 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:57:59 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:57:59 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:57:59 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:57:59 --> Database Driver Class Initialized
INFO - 2021-07-15 21:57:59 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:57:59 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:57:59 --> Controller Class Initialized
ERROR - 2021-07-15 21:57:59 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 21:57:59 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 21:58:08 --> Config Class Initialized
INFO - 2021-07-15 21:58:08 --> Hooks Class Initialized
DEBUG - 2021-07-15 21:58:08 --> UTF-8 Support Enabled
INFO - 2021-07-15 21:58:08 --> Utf8 Class Initialized
INFO - 2021-07-15 21:58:08 --> URI Class Initialized
INFO - 2021-07-15 21:58:08 --> Router Class Initialized
INFO - 2021-07-15 21:58:08 --> Output Class Initialized
INFO - 2021-07-15 21:58:08 --> Security Class Initialized
DEBUG - 2021-07-15 21:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 21:58:08 --> Input Class Initialized
INFO - 2021-07-15 21:58:08 --> Language Class Initialized
INFO - 2021-07-15 21:58:08 --> Loader Class Initialized
INFO - 2021-07-15 21:58:08 --> Helper loaded: basic_helper
INFO - 2021-07-15 21:58:08 --> Helper loaded: url_helper
INFO - 2021-07-15 21:58:08 --> Helper loaded: file_helper
INFO - 2021-07-15 21:58:08 --> Helper loaded: form_helper
INFO - 2021-07-15 21:58:08 --> Helper loaded: cookie_helper
INFO - 2021-07-15 21:58:08 --> Helper loaded: security_helper
INFO - 2021-07-15 21:58:08 --> Helper loaded: directory_helper
INFO - 2021-07-15 21:58:08 --> Helper loaded: language_helper
INFO - 2021-07-15 21:58:08 --> Helper loaded: general_helper
INFO - 2021-07-15 21:58:08 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 21:58:08 --> Database Driver Class Initialized
DEBUG - 2021-07-15 21:58:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 21:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 21:58:08 --> Parser Class Initialized
INFO - 2021-07-15 21:58:08 --> Form Validation Class Initialized
INFO - 2021-07-15 21:58:08 --> Upload Class Initialized
INFO - 2021-07-15 21:58:08 --> Email Class Initialized
INFO - 2021-07-15 21:58:08 --> MY_Model class loaded
INFO - 2021-07-15 21:58:08 --> Model "Users_model" initialized
INFO - 2021-07-15 21:58:08 --> Model "Settings_model" initialized
INFO - 2021-07-15 21:58:08 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 21:58:08 --> Model "Permissions_model" initialized
INFO - 2021-07-15 21:58:08 --> Model "Roles_model" initialized
INFO - 2021-07-15 21:58:08 --> Model "Activity_model" initialized
INFO - 2021-07-15 21:58:08 --> Model "Templates_model" initialized
INFO - 2021-07-15 21:58:08 --> Database Driver Class Initialized
INFO - 2021-07-15 21:58:08 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 21:58:08 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 21:58:08 --> Controller Class Initialized
ERROR - 2021-07-15 21:58:08 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 21:58:08 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 21:58:08 --> Final output sent to browser
DEBUG - 2021-07-15 21:58:08 --> Total execution time: 0.1290
INFO - 2021-07-15 23:26:11 --> Config Class Initialized
INFO - 2021-07-15 23:26:11 --> Hooks Class Initialized
DEBUG - 2021-07-15 23:26:11 --> UTF-8 Support Enabled
INFO - 2021-07-15 23:26:11 --> Utf8 Class Initialized
INFO - 2021-07-15 23:26:11 --> URI Class Initialized
INFO - 2021-07-15 23:26:11 --> Router Class Initialized
INFO - 2021-07-15 23:26:11 --> Output Class Initialized
INFO - 2021-07-15 23:26:11 --> Security Class Initialized
DEBUG - 2021-07-15 23:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 23:26:11 --> Input Class Initialized
INFO - 2021-07-15 23:26:11 --> Language Class Initialized
INFO - 2021-07-15 23:26:11 --> Loader Class Initialized
INFO - 2021-07-15 23:26:11 --> Helper loaded: basic_helper
INFO - 2021-07-15 23:26:11 --> Helper loaded: url_helper
INFO - 2021-07-15 23:26:11 --> Helper loaded: file_helper
INFO - 2021-07-15 23:26:11 --> Helper loaded: form_helper
INFO - 2021-07-15 23:26:11 --> Helper loaded: cookie_helper
INFO - 2021-07-15 23:26:11 --> Helper loaded: security_helper
INFO - 2021-07-15 23:26:11 --> Helper loaded: directory_helper
INFO - 2021-07-15 23:26:11 --> Helper loaded: language_helper
INFO - 2021-07-15 23:26:11 --> Helper loaded: general_helper
INFO - 2021-07-15 23:26:11 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 23:26:11 --> Database Driver Class Initialized
DEBUG - 2021-07-15 23:26:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 23:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 23:26:11 --> Parser Class Initialized
INFO - 2021-07-15 23:26:11 --> Form Validation Class Initialized
INFO - 2021-07-15 23:26:11 --> Upload Class Initialized
INFO - 2021-07-15 23:26:11 --> Email Class Initialized
INFO - 2021-07-15 23:26:11 --> MY_Model class loaded
INFO - 2021-07-15 23:26:11 --> Model "Users_model" initialized
INFO - 2021-07-15 23:26:11 --> Model "Settings_model" initialized
INFO - 2021-07-15 23:26:11 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 23:26:11 --> Model "Permissions_model" initialized
INFO - 2021-07-15 23:26:11 --> Model "Roles_model" initialized
INFO - 2021-07-15 23:26:11 --> Model "Activity_model" initialized
INFO - 2021-07-15 23:26:11 --> Model "Templates_model" initialized
INFO - 2021-07-15 23:26:11 --> Database Driver Class Initialized
INFO - 2021-07-15 23:26:11 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 23:26:11 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 23:26:11 --> Controller Class Initialized
ERROR - 2021-07-15 23:26:11 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-15 23:26:11 --> Severity: error --> Exception: Call to a member function result() on null C:\wamp64\www\crm\application\views\car\car_list.php 45
INFO - 2021-07-15 23:26:29 --> Config Class Initialized
INFO - 2021-07-15 23:26:29 --> Hooks Class Initialized
DEBUG - 2021-07-15 23:26:29 --> UTF-8 Support Enabled
INFO - 2021-07-15 23:26:29 --> Utf8 Class Initialized
INFO - 2021-07-15 23:26:29 --> URI Class Initialized
INFO - 2021-07-15 23:26:29 --> Router Class Initialized
INFO - 2021-07-15 23:26:29 --> Output Class Initialized
INFO - 2021-07-15 23:26:29 --> Security Class Initialized
DEBUG - 2021-07-15 23:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 23:26:29 --> Input Class Initialized
INFO - 2021-07-15 23:26:29 --> Language Class Initialized
INFO - 2021-07-15 23:26:29 --> Loader Class Initialized
INFO - 2021-07-15 23:26:29 --> Helper loaded: basic_helper
INFO - 2021-07-15 23:26:29 --> Helper loaded: url_helper
INFO - 2021-07-15 23:26:29 --> Helper loaded: file_helper
INFO - 2021-07-15 23:26:29 --> Helper loaded: form_helper
INFO - 2021-07-15 23:26:29 --> Helper loaded: cookie_helper
INFO - 2021-07-15 23:26:29 --> Helper loaded: security_helper
INFO - 2021-07-15 23:26:29 --> Helper loaded: directory_helper
INFO - 2021-07-15 23:26:29 --> Helper loaded: language_helper
INFO - 2021-07-15 23:26:29 --> Helper loaded: general_helper
INFO - 2021-07-15 23:26:29 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 23:26:29 --> Database Driver Class Initialized
DEBUG - 2021-07-15 23:26:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 23:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 23:26:29 --> Parser Class Initialized
INFO - 2021-07-15 23:26:29 --> Form Validation Class Initialized
INFO - 2021-07-15 23:26:29 --> Upload Class Initialized
INFO - 2021-07-15 23:26:29 --> Email Class Initialized
INFO - 2021-07-15 23:26:29 --> MY_Model class loaded
INFO - 2021-07-15 23:26:29 --> Model "Users_model" initialized
INFO - 2021-07-15 23:26:29 --> Model "Settings_model" initialized
INFO - 2021-07-15 23:26:29 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 23:26:29 --> Model "Permissions_model" initialized
INFO - 2021-07-15 23:26:29 --> Model "Roles_model" initialized
INFO - 2021-07-15 23:26:29 --> Model "Activity_model" initialized
INFO - 2021-07-15 23:26:29 --> Model "Templates_model" initialized
INFO - 2021-07-15 23:26:29 --> Database Driver Class Initialized
INFO - 2021-07-15 23:26:29 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 23:26:29 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 23:26:29 --> Controller Class Initialized
ERROR - 2021-07-15 23:26:29 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 23:26:29 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 23:26:29 --> Final output sent to browser
DEBUG - 2021-07-15 23:26:29 --> Total execution time: 0.1517
INFO - 2021-07-15 23:27:43 --> Config Class Initialized
INFO - 2021-07-15 23:27:43 --> Hooks Class Initialized
DEBUG - 2021-07-15 23:27:43 --> UTF-8 Support Enabled
INFO - 2021-07-15 23:27:43 --> Utf8 Class Initialized
INFO - 2021-07-15 23:27:43 --> URI Class Initialized
INFO - 2021-07-15 23:27:43 --> Router Class Initialized
INFO - 2021-07-15 23:27:43 --> Output Class Initialized
INFO - 2021-07-15 23:27:43 --> Security Class Initialized
DEBUG - 2021-07-15 23:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 23:27:43 --> Input Class Initialized
INFO - 2021-07-15 23:27:43 --> Language Class Initialized
INFO - 2021-07-15 23:27:43 --> Loader Class Initialized
INFO - 2021-07-15 23:27:43 --> Helper loaded: basic_helper
INFO - 2021-07-15 23:27:43 --> Helper loaded: url_helper
INFO - 2021-07-15 23:27:43 --> Helper loaded: file_helper
INFO - 2021-07-15 23:27:43 --> Helper loaded: form_helper
INFO - 2021-07-15 23:27:43 --> Helper loaded: cookie_helper
INFO - 2021-07-15 23:27:43 --> Helper loaded: security_helper
INFO - 2021-07-15 23:27:43 --> Helper loaded: directory_helper
INFO - 2021-07-15 23:27:43 --> Helper loaded: language_helper
INFO - 2021-07-15 23:27:43 --> Helper loaded: general_helper
INFO - 2021-07-15 23:27:43 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 23:27:43 --> Database Driver Class Initialized
DEBUG - 2021-07-15 23:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 23:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 23:27:43 --> Parser Class Initialized
INFO - 2021-07-15 23:27:43 --> Form Validation Class Initialized
INFO - 2021-07-15 23:27:43 --> Upload Class Initialized
INFO - 2021-07-15 23:27:43 --> Email Class Initialized
INFO - 2021-07-15 23:27:43 --> MY_Model class loaded
INFO - 2021-07-15 23:27:43 --> Model "Users_model" initialized
INFO - 2021-07-15 23:27:43 --> Model "Settings_model" initialized
INFO - 2021-07-15 23:27:43 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 23:27:43 --> Model "Permissions_model" initialized
INFO - 2021-07-15 23:27:43 --> Model "Roles_model" initialized
INFO - 2021-07-15 23:27:43 --> Model "Activity_model" initialized
INFO - 2021-07-15 23:27:43 --> Model "Templates_model" initialized
INFO - 2021-07-15 23:27:43 --> Database Driver Class Initialized
INFO - 2021-07-15 23:27:44 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 23:27:44 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 23:27:44 --> Controller Class Initialized
ERROR - 2021-07-15 23:27:44 --> Could not find the language line "sample_message_bro"
ERROR - 2021-07-15 23:27:44 --> Severity: Warning --> A non-numeric value encountered C:\wamp64\www\crm\application\views\car\car_list.php 48
ERROR - 2021-07-15 23:27:44 --> Severity: Warning --> A non-numeric value encountered C:\wamp64\www\crm\application\views\car\car_list.php 48
ERROR - 2021-07-15 23:27:44 --> Severity: Warning --> A non-numeric value encountered C:\wamp64\www\crm\application\views\car\car_list.php 48
ERROR - 2021-07-15 23:27:44 --> Severity: Warning --> A non-numeric value encountered C:\wamp64\www\crm\application\views\car\car_list.php 48
ERROR - 2021-07-15 23:27:44 --> Severity: Warning --> A non-numeric value encountered C:\wamp64\www\crm\application\views\car\car_list.php 48
ERROR - 2021-07-15 23:27:44 --> Severity: Warning --> A non-numeric value encountered C:\wamp64\www\crm\application\views\car\car_list.php 48
ERROR - 2021-07-15 23:27:44 --> Severity: Warning --> A non-numeric value encountered C:\wamp64\www\crm\application\views\car\car_list.php 48
ERROR - 2021-07-15 23:27:44 --> Severity: Warning --> A non-numeric value encountered C:\wamp64\www\crm\application\views\car\car_list.php 48
INFO - 2021-07-15 23:27:44 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 23:27:44 --> Final output sent to browser
DEBUG - 2021-07-15 23:27:44 --> Total execution time: 0.5445
INFO - 2021-07-15 23:28:00 --> Config Class Initialized
INFO - 2021-07-15 23:28:00 --> Hooks Class Initialized
DEBUG - 2021-07-15 23:28:00 --> UTF-8 Support Enabled
INFO - 2021-07-15 23:28:00 --> Utf8 Class Initialized
INFO - 2021-07-15 23:28:00 --> URI Class Initialized
INFO - 2021-07-15 23:28:00 --> Router Class Initialized
INFO - 2021-07-15 23:28:00 --> Output Class Initialized
INFO - 2021-07-15 23:28:00 --> Security Class Initialized
DEBUG - 2021-07-15 23:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 23:28:00 --> Input Class Initialized
INFO - 2021-07-15 23:28:00 --> Language Class Initialized
INFO - 2021-07-15 23:28:00 --> Loader Class Initialized
INFO - 2021-07-15 23:28:00 --> Helper loaded: basic_helper
INFO - 2021-07-15 23:28:00 --> Helper loaded: url_helper
INFO - 2021-07-15 23:28:00 --> Helper loaded: file_helper
INFO - 2021-07-15 23:28:00 --> Helper loaded: form_helper
INFO - 2021-07-15 23:28:00 --> Helper loaded: cookie_helper
INFO - 2021-07-15 23:28:00 --> Helper loaded: security_helper
INFO - 2021-07-15 23:28:00 --> Helper loaded: directory_helper
INFO - 2021-07-15 23:28:00 --> Helper loaded: language_helper
INFO - 2021-07-15 23:28:00 --> Helper loaded: general_helper
INFO - 2021-07-15 23:28:00 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 23:28:00 --> Database Driver Class Initialized
DEBUG - 2021-07-15 23:28:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 23:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 23:28:00 --> Parser Class Initialized
INFO - 2021-07-15 23:28:00 --> Form Validation Class Initialized
INFO - 2021-07-15 23:28:00 --> Upload Class Initialized
INFO - 2021-07-15 23:28:00 --> Email Class Initialized
INFO - 2021-07-15 23:28:00 --> MY_Model class loaded
INFO - 2021-07-15 23:28:00 --> Model "Users_model" initialized
INFO - 2021-07-15 23:28:00 --> Model "Settings_model" initialized
INFO - 2021-07-15 23:28:00 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 23:28:00 --> Model "Permissions_model" initialized
INFO - 2021-07-15 23:28:00 --> Model "Roles_model" initialized
INFO - 2021-07-15 23:28:00 --> Model "Activity_model" initialized
INFO - 2021-07-15 23:28:00 --> Model "Templates_model" initialized
INFO - 2021-07-15 23:28:00 --> Database Driver Class Initialized
INFO - 2021-07-15 23:28:00 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 23:28:00 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 23:28:00 --> Controller Class Initialized
ERROR - 2021-07-15 23:28:00 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 23:28:00 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 23:28:00 --> Final output sent to browser
DEBUG - 2021-07-15 23:28:00 --> Total execution time: 0.1668
INFO - 2021-07-15 23:28:23 --> Config Class Initialized
INFO - 2021-07-15 23:28:23 --> Hooks Class Initialized
DEBUG - 2021-07-15 23:28:23 --> UTF-8 Support Enabled
INFO - 2021-07-15 23:28:23 --> Utf8 Class Initialized
INFO - 2021-07-15 23:28:23 --> URI Class Initialized
INFO - 2021-07-15 23:28:23 --> Router Class Initialized
INFO - 2021-07-15 23:28:23 --> Output Class Initialized
INFO - 2021-07-15 23:28:23 --> Security Class Initialized
DEBUG - 2021-07-15 23:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 23:28:23 --> Input Class Initialized
INFO - 2021-07-15 23:28:23 --> Language Class Initialized
INFO - 2021-07-15 23:28:23 --> Loader Class Initialized
INFO - 2021-07-15 23:28:23 --> Helper loaded: basic_helper
INFO - 2021-07-15 23:28:23 --> Helper loaded: url_helper
INFO - 2021-07-15 23:28:23 --> Helper loaded: file_helper
INFO - 2021-07-15 23:28:23 --> Helper loaded: form_helper
INFO - 2021-07-15 23:28:23 --> Helper loaded: cookie_helper
INFO - 2021-07-15 23:28:23 --> Helper loaded: security_helper
INFO - 2021-07-15 23:28:23 --> Helper loaded: directory_helper
INFO - 2021-07-15 23:28:23 --> Helper loaded: language_helper
INFO - 2021-07-15 23:28:23 --> Helper loaded: general_helper
INFO - 2021-07-15 23:28:23 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 23:28:23 --> Database Driver Class Initialized
DEBUG - 2021-07-15 23:28:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 23:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 23:28:23 --> Parser Class Initialized
INFO - 2021-07-15 23:28:23 --> Form Validation Class Initialized
INFO - 2021-07-15 23:28:23 --> Upload Class Initialized
INFO - 2021-07-15 23:28:23 --> Email Class Initialized
INFO - 2021-07-15 23:28:23 --> MY_Model class loaded
INFO - 2021-07-15 23:28:23 --> Model "Users_model" initialized
INFO - 2021-07-15 23:28:23 --> Model "Settings_model" initialized
INFO - 2021-07-15 23:28:23 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 23:28:23 --> Model "Permissions_model" initialized
INFO - 2021-07-15 23:28:23 --> Model "Roles_model" initialized
INFO - 2021-07-15 23:28:23 --> Model "Activity_model" initialized
INFO - 2021-07-15 23:28:23 --> Model "Templates_model" initialized
INFO - 2021-07-15 23:28:23 --> Database Driver Class Initialized
INFO - 2021-07-15 23:28:23 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 23:28:23 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 23:28:23 --> Controller Class Initialized
ERROR - 2021-07-15 23:28:23 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 23:28:23 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 23:28:23 --> Final output sent to browser
DEBUG - 2021-07-15 23:28:23 --> Total execution time: 0.1989
INFO - 2021-07-15 23:28:31 --> Config Class Initialized
INFO - 2021-07-15 23:28:31 --> Hooks Class Initialized
DEBUG - 2021-07-15 23:28:31 --> UTF-8 Support Enabled
INFO - 2021-07-15 23:28:31 --> Utf8 Class Initialized
INFO - 2021-07-15 23:28:31 --> URI Class Initialized
INFO - 2021-07-15 23:28:31 --> Router Class Initialized
INFO - 2021-07-15 23:28:31 --> Output Class Initialized
INFO - 2021-07-15 23:28:31 --> Security Class Initialized
DEBUG - 2021-07-15 23:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 23:28:31 --> Input Class Initialized
INFO - 2021-07-15 23:28:31 --> Language Class Initialized
INFO - 2021-07-15 23:28:31 --> Loader Class Initialized
INFO - 2021-07-15 23:28:31 --> Helper loaded: basic_helper
INFO - 2021-07-15 23:28:31 --> Helper loaded: url_helper
INFO - 2021-07-15 23:28:31 --> Helper loaded: file_helper
INFO - 2021-07-15 23:28:31 --> Helper loaded: form_helper
INFO - 2021-07-15 23:28:31 --> Helper loaded: cookie_helper
INFO - 2021-07-15 23:28:31 --> Helper loaded: security_helper
INFO - 2021-07-15 23:28:31 --> Helper loaded: directory_helper
INFO - 2021-07-15 23:28:31 --> Helper loaded: language_helper
INFO - 2021-07-15 23:28:31 --> Helper loaded: general_helper
INFO - 2021-07-15 23:28:31 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 23:28:31 --> Database Driver Class Initialized
DEBUG - 2021-07-15 23:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 23:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 23:28:31 --> Parser Class Initialized
INFO - 2021-07-15 23:28:31 --> Form Validation Class Initialized
INFO - 2021-07-15 23:28:31 --> Upload Class Initialized
INFO - 2021-07-15 23:28:31 --> Email Class Initialized
INFO - 2021-07-15 23:28:31 --> MY_Model class loaded
INFO - 2021-07-15 23:28:31 --> Model "Users_model" initialized
INFO - 2021-07-15 23:28:31 --> Model "Settings_model" initialized
INFO - 2021-07-15 23:28:31 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 23:28:31 --> Model "Permissions_model" initialized
INFO - 2021-07-15 23:28:31 --> Model "Roles_model" initialized
INFO - 2021-07-15 23:28:31 --> Model "Activity_model" initialized
INFO - 2021-07-15 23:28:31 --> Model "Templates_model" initialized
INFO - 2021-07-15 23:28:31 --> Database Driver Class Initialized
INFO - 2021-07-15 23:28:32 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 23:28:32 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 23:28:32 --> Controller Class Initialized
ERROR - 2021-07-15 23:28:32 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 23:28:32 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 23:28:32 --> Final output sent to browser
DEBUG - 2021-07-15 23:28:32 --> Total execution time: 0.1390
INFO - 2021-07-15 23:31:24 --> Config Class Initialized
INFO - 2021-07-15 23:31:24 --> Hooks Class Initialized
DEBUG - 2021-07-15 23:31:24 --> UTF-8 Support Enabled
INFO - 2021-07-15 23:31:24 --> Utf8 Class Initialized
INFO - 2021-07-15 23:31:24 --> URI Class Initialized
INFO - 2021-07-15 23:31:24 --> Router Class Initialized
INFO - 2021-07-15 23:31:24 --> Output Class Initialized
INFO - 2021-07-15 23:31:24 --> Security Class Initialized
DEBUG - 2021-07-15 23:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 23:31:24 --> Input Class Initialized
INFO - 2021-07-15 23:31:24 --> Language Class Initialized
INFO - 2021-07-15 23:31:24 --> Loader Class Initialized
INFO - 2021-07-15 23:31:24 --> Helper loaded: basic_helper
INFO - 2021-07-15 23:31:24 --> Helper loaded: url_helper
INFO - 2021-07-15 23:31:24 --> Helper loaded: file_helper
INFO - 2021-07-15 23:31:24 --> Helper loaded: form_helper
INFO - 2021-07-15 23:31:24 --> Helper loaded: cookie_helper
INFO - 2021-07-15 23:31:24 --> Helper loaded: security_helper
INFO - 2021-07-15 23:31:24 --> Helper loaded: directory_helper
INFO - 2021-07-15 23:31:24 --> Helper loaded: language_helper
INFO - 2021-07-15 23:31:24 --> Helper loaded: general_helper
INFO - 2021-07-15 23:31:24 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 23:31:24 --> Database Driver Class Initialized
DEBUG - 2021-07-15 23:31:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 23:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 23:31:24 --> Parser Class Initialized
INFO - 2021-07-15 23:31:24 --> Form Validation Class Initialized
INFO - 2021-07-15 23:31:24 --> Upload Class Initialized
INFO - 2021-07-15 23:31:24 --> Email Class Initialized
INFO - 2021-07-15 23:31:24 --> MY_Model class loaded
INFO - 2021-07-15 23:31:24 --> Model "Users_model" initialized
INFO - 2021-07-15 23:31:24 --> Model "Settings_model" initialized
INFO - 2021-07-15 23:31:24 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 23:31:24 --> Model "Permissions_model" initialized
INFO - 2021-07-15 23:31:24 --> Model "Roles_model" initialized
INFO - 2021-07-15 23:31:24 --> Model "Activity_model" initialized
INFO - 2021-07-15 23:31:24 --> Model "Templates_model" initialized
INFO - 2021-07-15 23:31:24 --> Database Driver Class Initialized
INFO - 2021-07-15 23:31:24 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 23:31:24 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 23:31:24 --> Controller Class Initialized
ERROR - 2021-07-15 23:31:24 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 23:31:24 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 23:31:24 --> Final output sent to browser
DEBUG - 2021-07-15 23:31:24 --> Total execution time: 0.1545
INFO - 2021-07-15 23:31:58 --> Config Class Initialized
INFO - 2021-07-15 23:31:58 --> Hooks Class Initialized
DEBUG - 2021-07-15 23:31:58 --> UTF-8 Support Enabled
INFO - 2021-07-15 23:31:58 --> Utf8 Class Initialized
INFO - 2021-07-15 23:31:58 --> URI Class Initialized
INFO - 2021-07-15 23:31:58 --> Router Class Initialized
INFO - 2021-07-15 23:31:58 --> Output Class Initialized
INFO - 2021-07-15 23:31:58 --> Security Class Initialized
DEBUG - 2021-07-15 23:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 23:31:58 --> Input Class Initialized
INFO - 2021-07-15 23:31:58 --> Language Class Initialized
INFO - 2021-07-15 23:31:58 --> Loader Class Initialized
INFO - 2021-07-15 23:31:58 --> Helper loaded: basic_helper
INFO - 2021-07-15 23:31:58 --> Helper loaded: url_helper
INFO - 2021-07-15 23:31:58 --> Helper loaded: file_helper
INFO - 2021-07-15 23:31:58 --> Helper loaded: form_helper
INFO - 2021-07-15 23:31:58 --> Helper loaded: cookie_helper
INFO - 2021-07-15 23:31:58 --> Helper loaded: security_helper
INFO - 2021-07-15 23:31:58 --> Helper loaded: directory_helper
INFO - 2021-07-15 23:31:58 --> Helper loaded: language_helper
INFO - 2021-07-15 23:31:58 --> Helper loaded: general_helper
INFO - 2021-07-15 23:31:58 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 23:31:58 --> Database Driver Class Initialized
DEBUG - 2021-07-15 23:31:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 23:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 23:31:58 --> Parser Class Initialized
INFO - 2021-07-15 23:31:58 --> Form Validation Class Initialized
INFO - 2021-07-15 23:31:58 --> Upload Class Initialized
INFO - 2021-07-15 23:31:58 --> Email Class Initialized
INFO - 2021-07-15 23:31:58 --> MY_Model class loaded
INFO - 2021-07-15 23:31:58 --> Model "Users_model" initialized
INFO - 2021-07-15 23:31:58 --> Model "Settings_model" initialized
INFO - 2021-07-15 23:31:58 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 23:31:58 --> Model "Permissions_model" initialized
INFO - 2021-07-15 23:31:58 --> Model "Roles_model" initialized
INFO - 2021-07-15 23:31:58 --> Model "Activity_model" initialized
INFO - 2021-07-15 23:31:58 --> Model "Templates_model" initialized
INFO - 2021-07-15 23:31:58 --> Database Driver Class Initialized
INFO - 2021-07-15 23:31:59 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 23:31:59 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 23:31:59 --> Controller Class Initialized
ERROR - 2021-07-15 23:31:59 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 23:31:59 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 23:31:59 --> Final output sent to browser
DEBUG - 2021-07-15 23:31:59 --> Total execution time: 0.1580
INFO - 2021-07-15 23:32:27 --> Config Class Initialized
INFO - 2021-07-15 23:32:27 --> Hooks Class Initialized
DEBUG - 2021-07-15 23:32:27 --> UTF-8 Support Enabled
INFO - 2021-07-15 23:32:27 --> Utf8 Class Initialized
INFO - 2021-07-15 23:32:27 --> URI Class Initialized
INFO - 2021-07-15 23:32:27 --> Router Class Initialized
INFO - 2021-07-15 23:32:27 --> Output Class Initialized
INFO - 2021-07-15 23:32:27 --> Security Class Initialized
DEBUG - 2021-07-15 23:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 23:32:27 --> Input Class Initialized
INFO - 2021-07-15 23:32:27 --> Language Class Initialized
INFO - 2021-07-15 23:32:27 --> Loader Class Initialized
INFO - 2021-07-15 23:32:27 --> Helper loaded: basic_helper
INFO - 2021-07-15 23:32:27 --> Helper loaded: url_helper
INFO - 2021-07-15 23:32:27 --> Helper loaded: file_helper
INFO - 2021-07-15 23:32:27 --> Helper loaded: form_helper
INFO - 2021-07-15 23:32:27 --> Helper loaded: cookie_helper
INFO - 2021-07-15 23:32:27 --> Helper loaded: security_helper
INFO - 2021-07-15 23:32:27 --> Helper loaded: directory_helper
INFO - 2021-07-15 23:32:27 --> Helper loaded: language_helper
INFO - 2021-07-15 23:32:27 --> Helper loaded: general_helper
INFO - 2021-07-15 23:32:27 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 23:32:27 --> Database Driver Class Initialized
DEBUG - 2021-07-15 23:32:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 23:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 23:32:27 --> Parser Class Initialized
INFO - 2021-07-15 23:32:27 --> Form Validation Class Initialized
INFO - 2021-07-15 23:32:27 --> Upload Class Initialized
INFO - 2021-07-15 23:32:27 --> Email Class Initialized
INFO - 2021-07-15 23:32:27 --> MY_Model class loaded
INFO - 2021-07-15 23:32:27 --> Model "Users_model" initialized
INFO - 2021-07-15 23:32:27 --> Model "Settings_model" initialized
INFO - 2021-07-15 23:32:27 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 23:32:27 --> Model "Permissions_model" initialized
INFO - 2021-07-15 23:32:27 --> Model "Roles_model" initialized
INFO - 2021-07-15 23:32:27 --> Model "Activity_model" initialized
INFO - 2021-07-15 23:32:27 --> Model "Templates_model" initialized
INFO - 2021-07-15 23:32:27 --> Database Driver Class Initialized
INFO - 2021-07-15 23:32:27 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 23:32:27 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 23:32:27 --> Controller Class Initialized
ERROR - 2021-07-15 23:32:27 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 23:32:27 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 23:32:27 --> Final output sent to browser
DEBUG - 2021-07-15 23:32:27 --> Total execution time: 0.2651
INFO - 2021-07-15 23:32:34 --> Config Class Initialized
INFO - 2021-07-15 23:32:34 --> Hooks Class Initialized
DEBUG - 2021-07-15 23:32:34 --> UTF-8 Support Enabled
INFO - 2021-07-15 23:32:34 --> Utf8 Class Initialized
INFO - 2021-07-15 23:32:34 --> URI Class Initialized
INFO - 2021-07-15 23:32:34 --> Router Class Initialized
INFO - 2021-07-15 23:32:34 --> Output Class Initialized
INFO - 2021-07-15 23:32:34 --> Security Class Initialized
DEBUG - 2021-07-15 23:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 23:32:34 --> Input Class Initialized
INFO - 2021-07-15 23:32:34 --> Language Class Initialized
INFO - 2021-07-15 23:32:34 --> Loader Class Initialized
INFO - 2021-07-15 23:32:34 --> Helper loaded: basic_helper
INFO - 2021-07-15 23:32:34 --> Helper loaded: url_helper
INFO - 2021-07-15 23:32:34 --> Helper loaded: file_helper
INFO - 2021-07-15 23:32:34 --> Helper loaded: form_helper
INFO - 2021-07-15 23:32:34 --> Helper loaded: cookie_helper
INFO - 2021-07-15 23:32:34 --> Helper loaded: security_helper
INFO - 2021-07-15 23:32:34 --> Helper loaded: directory_helper
INFO - 2021-07-15 23:32:34 --> Helper loaded: language_helper
INFO - 2021-07-15 23:32:34 --> Helper loaded: general_helper
INFO - 2021-07-15 23:32:34 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 23:32:34 --> Database Driver Class Initialized
DEBUG - 2021-07-15 23:32:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 23:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 23:32:34 --> Parser Class Initialized
INFO - 2021-07-15 23:32:34 --> Form Validation Class Initialized
INFO - 2021-07-15 23:32:34 --> Upload Class Initialized
INFO - 2021-07-15 23:32:34 --> Email Class Initialized
INFO - 2021-07-15 23:32:34 --> MY_Model class loaded
INFO - 2021-07-15 23:32:34 --> Model "Users_model" initialized
INFO - 2021-07-15 23:32:34 --> Model "Settings_model" initialized
INFO - 2021-07-15 23:32:34 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 23:32:34 --> Model "Permissions_model" initialized
INFO - 2021-07-15 23:32:34 --> Model "Roles_model" initialized
INFO - 2021-07-15 23:32:34 --> Model "Activity_model" initialized
INFO - 2021-07-15 23:32:34 --> Model "Templates_model" initialized
INFO - 2021-07-15 23:32:34 --> Database Driver Class Initialized
INFO - 2021-07-15 23:32:34 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 23:32:34 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 23:32:34 --> Controller Class Initialized
ERROR - 2021-07-15 23:32:34 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 23:32:35 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 23:32:35 --> Final output sent to browser
DEBUG - 2021-07-15 23:32:35 --> Total execution time: 0.1831
INFO - 2021-07-15 23:32:48 --> Config Class Initialized
INFO - 2021-07-15 23:32:48 --> Hooks Class Initialized
DEBUG - 2021-07-15 23:32:48 --> UTF-8 Support Enabled
INFO - 2021-07-15 23:32:48 --> Utf8 Class Initialized
INFO - 2021-07-15 23:32:48 --> URI Class Initialized
INFO - 2021-07-15 23:32:48 --> Router Class Initialized
INFO - 2021-07-15 23:32:48 --> Output Class Initialized
INFO - 2021-07-15 23:32:48 --> Security Class Initialized
DEBUG - 2021-07-15 23:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 23:32:48 --> Input Class Initialized
INFO - 2021-07-15 23:32:48 --> Language Class Initialized
INFO - 2021-07-15 23:32:48 --> Loader Class Initialized
INFO - 2021-07-15 23:32:48 --> Helper loaded: basic_helper
INFO - 2021-07-15 23:32:48 --> Helper loaded: url_helper
INFO - 2021-07-15 23:32:48 --> Helper loaded: file_helper
INFO - 2021-07-15 23:32:48 --> Helper loaded: form_helper
INFO - 2021-07-15 23:32:48 --> Helper loaded: cookie_helper
INFO - 2021-07-15 23:32:48 --> Helper loaded: security_helper
INFO - 2021-07-15 23:32:48 --> Helper loaded: directory_helper
INFO - 2021-07-15 23:32:48 --> Helper loaded: language_helper
INFO - 2021-07-15 23:32:48 --> Helper loaded: general_helper
INFO - 2021-07-15 23:32:48 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 23:32:48 --> Database Driver Class Initialized
DEBUG - 2021-07-15 23:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 23:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 23:32:48 --> Parser Class Initialized
INFO - 2021-07-15 23:32:48 --> Form Validation Class Initialized
INFO - 2021-07-15 23:32:48 --> Upload Class Initialized
INFO - 2021-07-15 23:32:48 --> Email Class Initialized
INFO - 2021-07-15 23:32:48 --> MY_Model class loaded
INFO - 2021-07-15 23:32:48 --> Model "Users_model" initialized
INFO - 2021-07-15 23:32:48 --> Model "Settings_model" initialized
INFO - 2021-07-15 23:32:48 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 23:32:48 --> Model "Permissions_model" initialized
INFO - 2021-07-15 23:32:48 --> Model "Roles_model" initialized
INFO - 2021-07-15 23:32:48 --> Model "Activity_model" initialized
INFO - 2021-07-15 23:32:48 --> Model "Templates_model" initialized
INFO - 2021-07-15 23:32:48 --> Database Driver Class Initialized
INFO - 2021-07-15 23:32:49 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 23:32:49 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 23:32:49 --> Controller Class Initialized
ERROR - 2021-07-15 23:32:49 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 23:32:49 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 23:32:49 --> Final output sent to browser
DEBUG - 2021-07-15 23:32:49 --> Total execution time: 0.1946
INFO - 2021-07-15 23:33:11 --> Config Class Initialized
INFO - 2021-07-15 23:33:11 --> Hooks Class Initialized
DEBUG - 2021-07-15 23:33:11 --> UTF-8 Support Enabled
INFO - 2021-07-15 23:33:11 --> Utf8 Class Initialized
INFO - 2021-07-15 23:33:11 --> URI Class Initialized
INFO - 2021-07-15 23:33:11 --> Router Class Initialized
INFO - 2021-07-15 23:33:11 --> Output Class Initialized
INFO - 2021-07-15 23:33:11 --> Security Class Initialized
DEBUG - 2021-07-15 23:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 23:33:11 --> Input Class Initialized
INFO - 2021-07-15 23:33:11 --> Language Class Initialized
INFO - 2021-07-15 23:33:11 --> Loader Class Initialized
INFO - 2021-07-15 23:33:11 --> Helper loaded: basic_helper
INFO - 2021-07-15 23:33:11 --> Helper loaded: url_helper
INFO - 2021-07-15 23:33:11 --> Helper loaded: file_helper
INFO - 2021-07-15 23:33:11 --> Helper loaded: form_helper
INFO - 2021-07-15 23:33:11 --> Helper loaded: cookie_helper
INFO - 2021-07-15 23:33:11 --> Helper loaded: security_helper
INFO - 2021-07-15 23:33:11 --> Helper loaded: directory_helper
INFO - 2021-07-15 23:33:11 --> Helper loaded: language_helper
INFO - 2021-07-15 23:33:11 --> Helper loaded: general_helper
INFO - 2021-07-15 23:33:11 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 23:33:11 --> Database Driver Class Initialized
DEBUG - 2021-07-15 23:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 23:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 23:33:11 --> Parser Class Initialized
INFO - 2021-07-15 23:33:11 --> Form Validation Class Initialized
INFO - 2021-07-15 23:33:11 --> Upload Class Initialized
INFO - 2021-07-15 23:33:11 --> Email Class Initialized
INFO - 2021-07-15 23:33:11 --> MY_Model class loaded
INFO - 2021-07-15 23:33:11 --> Model "Users_model" initialized
INFO - 2021-07-15 23:33:11 --> Model "Settings_model" initialized
INFO - 2021-07-15 23:33:11 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 23:33:11 --> Model "Permissions_model" initialized
INFO - 2021-07-15 23:33:11 --> Model "Roles_model" initialized
INFO - 2021-07-15 23:33:11 --> Model "Activity_model" initialized
INFO - 2021-07-15 23:33:11 --> Model "Templates_model" initialized
INFO - 2021-07-15 23:33:11 --> Database Driver Class Initialized
INFO - 2021-07-15 23:33:11 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 23:33:11 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 23:33:11 --> Controller Class Initialized
ERROR - 2021-07-15 23:33:11 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 23:33:11 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 23:33:11 --> Final output sent to browser
DEBUG - 2021-07-15 23:33:11 --> Total execution time: 0.1245
INFO - 2021-07-15 23:36:18 --> Config Class Initialized
INFO - 2021-07-15 23:36:18 --> Hooks Class Initialized
DEBUG - 2021-07-15 23:36:18 --> UTF-8 Support Enabled
INFO - 2021-07-15 23:36:18 --> Utf8 Class Initialized
INFO - 2021-07-15 23:36:18 --> URI Class Initialized
INFO - 2021-07-15 23:36:18 --> Router Class Initialized
INFO - 2021-07-15 23:36:18 --> Output Class Initialized
INFO - 2021-07-15 23:36:18 --> Security Class Initialized
DEBUG - 2021-07-15 23:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 23:36:18 --> Input Class Initialized
INFO - 2021-07-15 23:36:18 --> Language Class Initialized
INFO - 2021-07-15 23:36:18 --> Loader Class Initialized
INFO - 2021-07-15 23:36:18 --> Helper loaded: basic_helper
INFO - 2021-07-15 23:36:18 --> Helper loaded: url_helper
INFO - 2021-07-15 23:36:18 --> Helper loaded: file_helper
INFO - 2021-07-15 23:36:18 --> Helper loaded: form_helper
INFO - 2021-07-15 23:36:18 --> Helper loaded: cookie_helper
INFO - 2021-07-15 23:36:18 --> Helper loaded: security_helper
INFO - 2021-07-15 23:36:18 --> Helper loaded: directory_helper
INFO - 2021-07-15 23:36:18 --> Helper loaded: language_helper
INFO - 2021-07-15 23:36:18 --> Helper loaded: general_helper
INFO - 2021-07-15 23:36:18 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 23:36:18 --> Database Driver Class Initialized
DEBUG - 2021-07-15 23:36:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 23:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 23:36:18 --> Parser Class Initialized
INFO - 2021-07-15 23:36:18 --> Form Validation Class Initialized
INFO - 2021-07-15 23:36:18 --> Upload Class Initialized
INFO - 2021-07-15 23:36:18 --> Email Class Initialized
INFO - 2021-07-15 23:36:18 --> MY_Model class loaded
INFO - 2021-07-15 23:36:18 --> Model "Users_model" initialized
INFO - 2021-07-15 23:36:18 --> Model "Settings_model" initialized
INFO - 2021-07-15 23:36:18 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 23:36:18 --> Model "Permissions_model" initialized
INFO - 2021-07-15 23:36:18 --> Model "Roles_model" initialized
INFO - 2021-07-15 23:36:18 --> Model "Activity_model" initialized
INFO - 2021-07-15 23:36:18 --> Model "Templates_model" initialized
INFO - 2021-07-15 23:36:18 --> Database Driver Class Initialized
INFO - 2021-07-15 23:36:18 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 23:36:18 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 23:36:18 --> Controller Class Initialized
ERROR - 2021-07-15 23:36:18 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 23:36:18 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 23:36:18 --> Final output sent to browser
DEBUG - 2021-07-15 23:36:18 --> Total execution time: 0.1394
INFO - 2021-07-15 23:36:25 --> Config Class Initialized
INFO - 2021-07-15 23:36:25 --> Hooks Class Initialized
DEBUG - 2021-07-15 23:36:25 --> UTF-8 Support Enabled
INFO - 2021-07-15 23:36:25 --> Utf8 Class Initialized
INFO - 2021-07-15 23:36:25 --> URI Class Initialized
INFO - 2021-07-15 23:36:25 --> Router Class Initialized
INFO - 2021-07-15 23:36:25 --> Output Class Initialized
INFO - 2021-07-15 23:36:25 --> Security Class Initialized
DEBUG - 2021-07-15 23:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 23:36:25 --> Input Class Initialized
INFO - 2021-07-15 23:36:25 --> Language Class Initialized
INFO - 2021-07-15 23:36:25 --> Loader Class Initialized
INFO - 2021-07-15 23:36:25 --> Helper loaded: basic_helper
INFO - 2021-07-15 23:36:25 --> Helper loaded: url_helper
INFO - 2021-07-15 23:36:25 --> Helper loaded: file_helper
INFO - 2021-07-15 23:36:25 --> Helper loaded: form_helper
INFO - 2021-07-15 23:36:25 --> Helper loaded: cookie_helper
INFO - 2021-07-15 23:36:25 --> Helper loaded: security_helper
INFO - 2021-07-15 23:36:25 --> Helper loaded: directory_helper
INFO - 2021-07-15 23:36:25 --> Helper loaded: language_helper
INFO - 2021-07-15 23:36:25 --> Helper loaded: general_helper
INFO - 2021-07-15 23:36:25 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 23:36:25 --> Database Driver Class Initialized
DEBUG - 2021-07-15 23:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 23:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 23:36:25 --> Parser Class Initialized
INFO - 2021-07-15 23:36:25 --> Form Validation Class Initialized
INFO - 2021-07-15 23:36:25 --> Upload Class Initialized
INFO - 2021-07-15 23:36:25 --> Email Class Initialized
INFO - 2021-07-15 23:36:25 --> MY_Model class loaded
INFO - 2021-07-15 23:36:25 --> Model "Users_model" initialized
INFO - 2021-07-15 23:36:25 --> Model "Settings_model" initialized
INFO - 2021-07-15 23:36:25 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 23:36:25 --> Model "Permissions_model" initialized
INFO - 2021-07-15 23:36:25 --> Model "Roles_model" initialized
INFO - 2021-07-15 23:36:25 --> Model "Activity_model" initialized
INFO - 2021-07-15 23:36:25 --> Model "Templates_model" initialized
INFO - 2021-07-15 23:36:25 --> Database Driver Class Initialized
INFO - 2021-07-15 23:36:25 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 23:36:25 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 23:36:25 --> Controller Class Initialized
ERROR - 2021-07-15 23:36:25 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 23:36:25 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 23:36:25 --> Final output sent to browser
DEBUG - 2021-07-15 23:36:25 --> Total execution time: 0.1552
INFO - 2021-07-15 23:41:04 --> Config Class Initialized
INFO - 2021-07-15 23:41:04 --> Hooks Class Initialized
DEBUG - 2021-07-15 23:41:04 --> UTF-8 Support Enabled
INFO - 2021-07-15 23:41:04 --> Utf8 Class Initialized
INFO - 2021-07-15 23:41:04 --> URI Class Initialized
INFO - 2021-07-15 23:41:04 --> Router Class Initialized
INFO - 2021-07-15 23:41:04 --> Output Class Initialized
INFO - 2021-07-15 23:41:04 --> Security Class Initialized
DEBUG - 2021-07-15 23:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 23:41:04 --> Input Class Initialized
INFO - 2021-07-15 23:41:04 --> Language Class Initialized
INFO - 2021-07-15 23:41:04 --> Loader Class Initialized
INFO - 2021-07-15 23:41:04 --> Helper loaded: basic_helper
INFO - 2021-07-15 23:41:04 --> Helper loaded: url_helper
INFO - 2021-07-15 23:41:04 --> Helper loaded: file_helper
INFO - 2021-07-15 23:41:04 --> Helper loaded: form_helper
INFO - 2021-07-15 23:41:04 --> Helper loaded: cookie_helper
INFO - 2021-07-15 23:41:04 --> Helper loaded: security_helper
INFO - 2021-07-15 23:41:04 --> Helper loaded: directory_helper
INFO - 2021-07-15 23:41:04 --> Helper loaded: language_helper
INFO - 2021-07-15 23:41:04 --> Helper loaded: general_helper
INFO - 2021-07-15 23:41:04 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 23:41:04 --> Database Driver Class Initialized
DEBUG - 2021-07-15 23:41:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 23:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 23:41:04 --> Parser Class Initialized
INFO - 2021-07-15 23:41:04 --> Form Validation Class Initialized
INFO - 2021-07-15 23:41:04 --> Upload Class Initialized
INFO - 2021-07-15 23:41:04 --> Email Class Initialized
INFO - 2021-07-15 23:41:04 --> MY_Model class loaded
INFO - 2021-07-15 23:41:04 --> Model "Users_model" initialized
INFO - 2021-07-15 23:41:04 --> Model "Settings_model" initialized
INFO - 2021-07-15 23:41:04 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 23:41:04 --> Model "Permissions_model" initialized
INFO - 2021-07-15 23:41:04 --> Model "Roles_model" initialized
INFO - 2021-07-15 23:41:04 --> Model "Activity_model" initialized
INFO - 2021-07-15 23:41:04 --> Model "Templates_model" initialized
INFO - 2021-07-15 23:41:04 --> Database Driver Class Initialized
INFO - 2021-07-15 23:41:04 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 23:41:04 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 23:41:04 --> Controller Class Initialized
ERROR - 2021-07-15 23:41:04 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 23:41:04 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 23:41:04 --> Final output sent to browser
DEBUG - 2021-07-15 23:41:04 --> Total execution time: 0.1493
INFO - 2021-07-15 23:41:05 --> Config Class Initialized
INFO - 2021-07-15 23:41:05 --> Hooks Class Initialized
DEBUG - 2021-07-15 23:41:05 --> UTF-8 Support Enabled
INFO - 2021-07-15 23:41:05 --> Utf8 Class Initialized
INFO - 2021-07-15 23:41:05 --> URI Class Initialized
INFO - 2021-07-15 23:41:05 --> Router Class Initialized
INFO - 2021-07-15 23:41:05 --> Output Class Initialized
INFO - 2021-07-15 23:41:05 --> Security Class Initialized
DEBUG - 2021-07-15 23:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 23:41:05 --> Input Class Initialized
INFO - 2021-07-15 23:41:05 --> Language Class Initialized
INFO - 2021-07-15 23:41:05 --> Loader Class Initialized
INFO - 2021-07-15 23:41:05 --> Helper loaded: basic_helper
INFO - 2021-07-15 23:41:05 --> Helper loaded: url_helper
INFO - 2021-07-15 23:41:05 --> Helper loaded: file_helper
INFO - 2021-07-15 23:41:05 --> Helper loaded: form_helper
INFO - 2021-07-15 23:41:05 --> Helper loaded: cookie_helper
INFO - 2021-07-15 23:41:05 --> Helper loaded: security_helper
INFO - 2021-07-15 23:41:05 --> Helper loaded: directory_helper
INFO - 2021-07-15 23:41:05 --> Helper loaded: language_helper
INFO - 2021-07-15 23:41:05 --> Helper loaded: general_helper
INFO - 2021-07-15 23:41:05 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 23:41:05 --> Database Driver Class Initialized
DEBUG - 2021-07-15 23:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 23:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 23:41:05 --> Parser Class Initialized
INFO - 2021-07-15 23:41:05 --> Form Validation Class Initialized
INFO - 2021-07-15 23:41:05 --> Upload Class Initialized
INFO - 2021-07-15 23:41:05 --> Email Class Initialized
INFO - 2021-07-15 23:41:05 --> MY_Model class loaded
INFO - 2021-07-15 23:41:05 --> Model "Users_model" initialized
INFO - 2021-07-15 23:41:05 --> Model "Settings_model" initialized
INFO - 2021-07-15 23:41:05 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 23:41:05 --> Model "Permissions_model" initialized
INFO - 2021-07-15 23:41:05 --> Model "Roles_model" initialized
INFO - 2021-07-15 23:41:05 --> Model "Activity_model" initialized
INFO - 2021-07-15 23:41:05 --> Model "Templates_model" initialized
INFO - 2021-07-15 23:41:05 --> Database Driver Class Initialized
INFO - 2021-07-15 23:41:05 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 23:41:05 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 23:41:05 --> Controller Class Initialized
ERROR - 2021-07-15 23:41:05 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 23:41:05 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 23:41:05 --> Final output sent to browser
DEBUG - 2021-07-15 23:41:05 --> Total execution time: 0.0603
INFO - 2021-07-15 23:41:11 --> Config Class Initialized
INFO - 2021-07-15 23:41:11 --> Hooks Class Initialized
DEBUG - 2021-07-15 23:41:11 --> UTF-8 Support Enabled
INFO - 2021-07-15 23:41:11 --> Utf8 Class Initialized
INFO - 2021-07-15 23:41:11 --> URI Class Initialized
INFO - 2021-07-15 23:41:11 --> Router Class Initialized
INFO - 2021-07-15 23:41:11 --> Output Class Initialized
INFO - 2021-07-15 23:41:11 --> Security Class Initialized
DEBUG - 2021-07-15 23:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 23:41:11 --> Input Class Initialized
INFO - 2021-07-15 23:41:11 --> Language Class Initialized
INFO - 2021-07-15 23:41:11 --> Loader Class Initialized
INFO - 2021-07-15 23:41:11 --> Helper loaded: basic_helper
INFO - 2021-07-15 23:41:11 --> Helper loaded: url_helper
INFO - 2021-07-15 23:41:11 --> Helper loaded: file_helper
INFO - 2021-07-15 23:41:11 --> Helper loaded: form_helper
INFO - 2021-07-15 23:41:11 --> Helper loaded: cookie_helper
INFO - 2021-07-15 23:41:11 --> Helper loaded: security_helper
INFO - 2021-07-15 23:41:11 --> Helper loaded: directory_helper
INFO - 2021-07-15 23:41:11 --> Helper loaded: language_helper
INFO - 2021-07-15 23:41:11 --> Helper loaded: general_helper
INFO - 2021-07-15 23:41:11 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 23:41:11 --> Database Driver Class Initialized
DEBUG - 2021-07-15 23:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 23:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 23:41:11 --> Parser Class Initialized
INFO - 2021-07-15 23:41:11 --> Form Validation Class Initialized
INFO - 2021-07-15 23:41:11 --> Upload Class Initialized
INFO - 2021-07-15 23:41:11 --> Email Class Initialized
INFO - 2021-07-15 23:41:11 --> MY_Model class loaded
INFO - 2021-07-15 23:41:11 --> Model "Users_model" initialized
INFO - 2021-07-15 23:41:11 --> Model "Settings_model" initialized
INFO - 2021-07-15 23:41:11 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 23:41:11 --> Model "Permissions_model" initialized
INFO - 2021-07-15 23:41:11 --> Model "Roles_model" initialized
INFO - 2021-07-15 23:41:11 --> Model "Activity_model" initialized
INFO - 2021-07-15 23:41:11 --> Model "Templates_model" initialized
INFO - 2021-07-15 23:41:11 --> Database Driver Class Initialized
INFO - 2021-07-15 23:41:11 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 23:41:11 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 23:41:11 --> Controller Class Initialized
ERROR - 2021-07-15 23:41:11 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 23:41:11 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 23:41:11 --> Final output sent to browser
DEBUG - 2021-07-15 23:41:11 --> Total execution time: 0.1336
INFO - 2021-07-15 23:41:40 --> Config Class Initialized
INFO - 2021-07-15 23:41:40 --> Hooks Class Initialized
DEBUG - 2021-07-15 23:41:40 --> UTF-8 Support Enabled
INFO - 2021-07-15 23:41:40 --> Utf8 Class Initialized
INFO - 2021-07-15 23:41:40 --> URI Class Initialized
INFO - 2021-07-15 23:41:40 --> Router Class Initialized
INFO - 2021-07-15 23:41:40 --> Output Class Initialized
INFO - 2021-07-15 23:41:40 --> Security Class Initialized
DEBUG - 2021-07-15 23:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 23:41:40 --> Input Class Initialized
INFO - 2021-07-15 23:41:40 --> Language Class Initialized
INFO - 2021-07-15 23:41:40 --> Loader Class Initialized
INFO - 2021-07-15 23:41:40 --> Helper loaded: basic_helper
INFO - 2021-07-15 23:41:40 --> Helper loaded: url_helper
INFO - 2021-07-15 23:41:40 --> Helper loaded: file_helper
INFO - 2021-07-15 23:41:40 --> Helper loaded: form_helper
INFO - 2021-07-15 23:41:40 --> Helper loaded: cookie_helper
INFO - 2021-07-15 23:41:40 --> Helper loaded: security_helper
INFO - 2021-07-15 23:41:40 --> Helper loaded: directory_helper
INFO - 2021-07-15 23:41:40 --> Helper loaded: language_helper
INFO - 2021-07-15 23:41:40 --> Helper loaded: general_helper
INFO - 2021-07-15 23:41:40 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 23:41:40 --> Database Driver Class Initialized
DEBUG - 2021-07-15 23:41:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 23:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 23:41:40 --> Parser Class Initialized
INFO - 2021-07-15 23:41:40 --> Form Validation Class Initialized
INFO - 2021-07-15 23:41:40 --> Upload Class Initialized
INFO - 2021-07-15 23:41:40 --> Email Class Initialized
INFO - 2021-07-15 23:41:40 --> MY_Model class loaded
INFO - 2021-07-15 23:41:40 --> Model "Users_model" initialized
INFO - 2021-07-15 23:41:40 --> Model "Settings_model" initialized
INFO - 2021-07-15 23:41:40 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 23:41:40 --> Model "Permissions_model" initialized
INFO - 2021-07-15 23:41:40 --> Model "Roles_model" initialized
INFO - 2021-07-15 23:41:40 --> Model "Activity_model" initialized
INFO - 2021-07-15 23:41:40 --> Model "Templates_model" initialized
INFO - 2021-07-15 23:41:40 --> Database Driver Class Initialized
INFO - 2021-07-15 23:41:40 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 23:41:40 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 23:41:40 --> Controller Class Initialized
ERROR - 2021-07-15 23:41:40 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 23:41:40 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 23:41:40 --> Final output sent to browser
DEBUG - 2021-07-15 23:41:40 --> Total execution time: 0.1379
INFO - 2021-07-15 23:41:44 --> Config Class Initialized
INFO - 2021-07-15 23:41:44 --> Hooks Class Initialized
DEBUG - 2021-07-15 23:41:44 --> UTF-8 Support Enabled
INFO - 2021-07-15 23:41:44 --> Utf8 Class Initialized
INFO - 2021-07-15 23:41:44 --> URI Class Initialized
INFO - 2021-07-15 23:41:44 --> Router Class Initialized
INFO - 2021-07-15 23:41:44 --> Output Class Initialized
INFO - 2021-07-15 23:41:44 --> Security Class Initialized
DEBUG - 2021-07-15 23:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 23:41:44 --> Input Class Initialized
INFO - 2021-07-15 23:41:44 --> Language Class Initialized
INFO - 2021-07-15 23:41:44 --> Loader Class Initialized
INFO - 2021-07-15 23:41:44 --> Helper loaded: basic_helper
INFO - 2021-07-15 23:41:44 --> Helper loaded: url_helper
INFO - 2021-07-15 23:41:44 --> Helper loaded: file_helper
INFO - 2021-07-15 23:41:44 --> Helper loaded: form_helper
INFO - 2021-07-15 23:41:44 --> Helper loaded: cookie_helper
INFO - 2021-07-15 23:41:44 --> Helper loaded: security_helper
INFO - 2021-07-15 23:41:44 --> Helper loaded: directory_helper
INFO - 2021-07-15 23:41:44 --> Helper loaded: language_helper
INFO - 2021-07-15 23:41:44 --> Helper loaded: general_helper
INFO - 2021-07-15 23:41:44 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 23:41:44 --> Database Driver Class Initialized
DEBUG - 2021-07-15 23:41:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 23:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 23:41:44 --> Parser Class Initialized
INFO - 2021-07-15 23:41:44 --> Form Validation Class Initialized
INFO - 2021-07-15 23:41:44 --> Upload Class Initialized
INFO - 2021-07-15 23:41:44 --> Email Class Initialized
INFO - 2021-07-15 23:41:44 --> MY_Model class loaded
INFO - 2021-07-15 23:41:44 --> Model "Users_model" initialized
INFO - 2021-07-15 23:41:44 --> Model "Settings_model" initialized
INFO - 2021-07-15 23:41:44 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 23:41:44 --> Model "Permissions_model" initialized
INFO - 2021-07-15 23:41:44 --> Model "Roles_model" initialized
INFO - 2021-07-15 23:41:44 --> Model "Activity_model" initialized
INFO - 2021-07-15 23:41:44 --> Model "Templates_model" initialized
INFO - 2021-07-15 23:41:44 --> Database Driver Class Initialized
INFO - 2021-07-15 23:41:44 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 23:41:44 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 23:41:44 --> Controller Class Initialized
ERROR - 2021-07-15 23:41:44 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 23:41:44 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 23:41:44 --> Final output sent to browser
DEBUG - 2021-07-15 23:41:44 --> Total execution time: 0.0645
INFO - 2021-07-15 23:42:13 --> Config Class Initialized
INFO - 2021-07-15 23:42:13 --> Hooks Class Initialized
DEBUG - 2021-07-15 23:42:13 --> UTF-8 Support Enabled
INFO - 2021-07-15 23:42:13 --> Utf8 Class Initialized
INFO - 2021-07-15 23:42:13 --> URI Class Initialized
INFO - 2021-07-15 23:42:13 --> Router Class Initialized
INFO - 2021-07-15 23:42:13 --> Output Class Initialized
INFO - 2021-07-15 23:42:13 --> Security Class Initialized
DEBUG - 2021-07-15 23:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 23:42:13 --> Input Class Initialized
INFO - 2021-07-15 23:42:13 --> Language Class Initialized
INFO - 2021-07-15 23:42:13 --> Loader Class Initialized
INFO - 2021-07-15 23:42:13 --> Helper loaded: basic_helper
INFO - 2021-07-15 23:42:13 --> Helper loaded: url_helper
INFO - 2021-07-15 23:42:13 --> Helper loaded: file_helper
INFO - 2021-07-15 23:42:13 --> Helper loaded: form_helper
INFO - 2021-07-15 23:42:13 --> Helper loaded: cookie_helper
INFO - 2021-07-15 23:42:13 --> Helper loaded: security_helper
INFO - 2021-07-15 23:42:13 --> Helper loaded: directory_helper
INFO - 2021-07-15 23:42:13 --> Helper loaded: language_helper
INFO - 2021-07-15 23:42:13 --> Helper loaded: general_helper
INFO - 2021-07-15 23:42:13 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 23:42:13 --> Database Driver Class Initialized
DEBUG - 2021-07-15 23:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 23:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 23:42:13 --> Parser Class Initialized
INFO - 2021-07-15 23:42:13 --> Form Validation Class Initialized
INFO - 2021-07-15 23:42:13 --> Upload Class Initialized
INFO - 2021-07-15 23:42:13 --> Email Class Initialized
INFO - 2021-07-15 23:42:13 --> MY_Model class loaded
INFO - 2021-07-15 23:42:13 --> Model "Users_model" initialized
INFO - 2021-07-15 23:42:13 --> Model "Settings_model" initialized
INFO - 2021-07-15 23:42:13 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 23:42:13 --> Model "Permissions_model" initialized
INFO - 2021-07-15 23:42:13 --> Model "Roles_model" initialized
INFO - 2021-07-15 23:42:13 --> Model "Activity_model" initialized
INFO - 2021-07-15 23:42:13 --> Model "Templates_model" initialized
INFO - 2021-07-15 23:42:13 --> Database Driver Class Initialized
INFO - 2021-07-15 23:42:13 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 23:42:13 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 23:42:13 --> Controller Class Initialized
ERROR - 2021-07-15 23:42:13 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 23:42:13 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 23:42:13 --> Final output sent to browser
DEBUG - 2021-07-15 23:42:13 --> Total execution time: 0.1227
INFO - 2021-07-15 23:43:32 --> Config Class Initialized
INFO - 2021-07-15 23:43:32 --> Hooks Class Initialized
DEBUG - 2021-07-15 23:43:32 --> UTF-8 Support Enabled
INFO - 2021-07-15 23:43:32 --> Utf8 Class Initialized
INFO - 2021-07-15 23:43:32 --> URI Class Initialized
INFO - 2021-07-15 23:43:32 --> Router Class Initialized
INFO - 2021-07-15 23:43:32 --> Output Class Initialized
INFO - 2021-07-15 23:43:32 --> Security Class Initialized
DEBUG - 2021-07-15 23:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 23:43:32 --> Input Class Initialized
INFO - 2021-07-15 23:43:32 --> Language Class Initialized
INFO - 2021-07-15 23:43:32 --> Loader Class Initialized
INFO - 2021-07-15 23:43:32 --> Helper loaded: basic_helper
INFO - 2021-07-15 23:43:32 --> Helper loaded: url_helper
INFO - 2021-07-15 23:43:32 --> Helper loaded: file_helper
INFO - 2021-07-15 23:43:32 --> Helper loaded: form_helper
INFO - 2021-07-15 23:43:32 --> Helper loaded: cookie_helper
INFO - 2021-07-15 23:43:32 --> Helper loaded: security_helper
INFO - 2021-07-15 23:43:32 --> Helper loaded: directory_helper
INFO - 2021-07-15 23:43:32 --> Helper loaded: language_helper
INFO - 2021-07-15 23:43:32 --> Helper loaded: general_helper
INFO - 2021-07-15 23:43:32 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 23:43:32 --> Database Driver Class Initialized
DEBUG - 2021-07-15 23:43:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 23:43:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 23:43:32 --> Parser Class Initialized
INFO - 2021-07-15 23:43:32 --> Form Validation Class Initialized
INFO - 2021-07-15 23:43:32 --> Upload Class Initialized
INFO - 2021-07-15 23:43:32 --> Email Class Initialized
INFO - 2021-07-15 23:43:32 --> MY_Model class loaded
INFO - 2021-07-15 23:43:32 --> Model "Users_model" initialized
INFO - 2021-07-15 23:43:32 --> Model "Settings_model" initialized
INFO - 2021-07-15 23:43:32 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 23:43:32 --> Model "Permissions_model" initialized
INFO - 2021-07-15 23:43:32 --> Model "Roles_model" initialized
INFO - 2021-07-15 23:43:32 --> Model "Activity_model" initialized
INFO - 2021-07-15 23:43:32 --> Model "Templates_model" initialized
INFO - 2021-07-15 23:43:32 --> Database Driver Class Initialized
INFO - 2021-07-15 23:43:33 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 23:43:33 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 23:43:33 --> Controller Class Initialized
ERROR - 2021-07-15 23:43:33 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 23:43:33 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 23:43:33 --> Final output sent to browser
DEBUG - 2021-07-15 23:43:33 --> Total execution time: 0.5333
INFO - 2021-07-15 23:43:36 --> Config Class Initialized
INFO - 2021-07-15 23:43:36 --> Hooks Class Initialized
DEBUG - 2021-07-15 23:43:36 --> UTF-8 Support Enabled
INFO - 2021-07-15 23:43:36 --> Utf8 Class Initialized
INFO - 2021-07-15 23:43:36 --> URI Class Initialized
INFO - 2021-07-15 23:43:36 --> Router Class Initialized
INFO - 2021-07-15 23:43:36 --> Output Class Initialized
INFO - 2021-07-15 23:43:36 --> Security Class Initialized
DEBUG - 2021-07-15 23:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 23:43:36 --> Input Class Initialized
INFO - 2021-07-15 23:43:36 --> Language Class Initialized
INFO - 2021-07-15 23:43:36 --> Loader Class Initialized
INFO - 2021-07-15 23:43:36 --> Helper loaded: basic_helper
INFO - 2021-07-15 23:43:36 --> Helper loaded: url_helper
INFO - 2021-07-15 23:43:36 --> Helper loaded: file_helper
INFO - 2021-07-15 23:43:36 --> Helper loaded: form_helper
INFO - 2021-07-15 23:43:36 --> Helper loaded: cookie_helper
INFO - 2021-07-15 23:43:36 --> Helper loaded: security_helper
INFO - 2021-07-15 23:43:36 --> Helper loaded: directory_helper
INFO - 2021-07-15 23:43:36 --> Helper loaded: language_helper
INFO - 2021-07-15 23:43:36 --> Helper loaded: general_helper
INFO - 2021-07-15 23:43:36 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 23:43:36 --> Database Driver Class Initialized
DEBUG - 2021-07-15 23:43:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 23:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 23:43:36 --> Parser Class Initialized
INFO - 2021-07-15 23:43:36 --> Form Validation Class Initialized
INFO - 2021-07-15 23:43:36 --> Upload Class Initialized
INFO - 2021-07-15 23:43:36 --> Email Class Initialized
INFO - 2021-07-15 23:43:36 --> MY_Model class loaded
INFO - 2021-07-15 23:43:36 --> Model "Users_model" initialized
INFO - 2021-07-15 23:43:36 --> Model "Settings_model" initialized
INFO - 2021-07-15 23:43:36 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 23:43:36 --> Model "Permissions_model" initialized
INFO - 2021-07-15 23:43:36 --> Model "Roles_model" initialized
INFO - 2021-07-15 23:43:36 --> Model "Activity_model" initialized
INFO - 2021-07-15 23:43:36 --> Model "Templates_model" initialized
INFO - 2021-07-15 23:43:36 --> Database Driver Class Initialized
INFO - 2021-07-15 23:43:36 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 23:43:36 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 23:43:36 --> Controller Class Initialized
ERROR - 2021-07-15 23:43:36 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 23:43:36 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 23:43:36 --> Final output sent to browser
DEBUG - 2021-07-15 23:43:36 --> Total execution time: 0.0738
INFO - 2021-07-15 23:43:41 --> Config Class Initialized
INFO - 2021-07-15 23:43:41 --> Hooks Class Initialized
DEBUG - 2021-07-15 23:43:41 --> UTF-8 Support Enabled
INFO - 2021-07-15 23:43:41 --> Utf8 Class Initialized
INFO - 2021-07-15 23:43:41 --> URI Class Initialized
INFO - 2021-07-15 23:43:41 --> Router Class Initialized
INFO - 2021-07-15 23:43:41 --> Output Class Initialized
INFO - 2021-07-15 23:43:41 --> Security Class Initialized
DEBUG - 2021-07-15 23:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 23:43:41 --> Input Class Initialized
INFO - 2021-07-15 23:43:41 --> Language Class Initialized
INFO - 2021-07-15 23:43:41 --> Loader Class Initialized
INFO - 2021-07-15 23:43:41 --> Helper loaded: basic_helper
INFO - 2021-07-15 23:43:41 --> Helper loaded: url_helper
INFO - 2021-07-15 23:43:41 --> Helper loaded: file_helper
INFO - 2021-07-15 23:43:41 --> Helper loaded: form_helper
INFO - 2021-07-15 23:43:41 --> Helper loaded: cookie_helper
INFO - 2021-07-15 23:43:41 --> Helper loaded: security_helper
INFO - 2021-07-15 23:43:41 --> Helper loaded: directory_helper
INFO - 2021-07-15 23:43:41 --> Helper loaded: language_helper
INFO - 2021-07-15 23:43:41 --> Helper loaded: general_helper
INFO - 2021-07-15 23:43:41 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 23:43:41 --> Database Driver Class Initialized
DEBUG - 2021-07-15 23:43:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 23:43:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 23:43:41 --> Parser Class Initialized
INFO - 2021-07-15 23:43:41 --> Form Validation Class Initialized
INFO - 2021-07-15 23:43:41 --> Upload Class Initialized
INFO - 2021-07-15 23:43:41 --> Email Class Initialized
INFO - 2021-07-15 23:43:41 --> MY_Model class loaded
INFO - 2021-07-15 23:43:41 --> Model "Users_model" initialized
INFO - 2021-07-15 23:43:41 --> Model "Settings_model" initialized
INFO - 2021-07-15 23:43:41 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 23:43:41 --> Model "Permissions_model" initialized
INFO - 2021-07-15 23:43:41 --> Model "Roles_model" initialized
INFO - 2021-07-15 23:43:41 --> Model "Activity_model" initialized
INFO - 2021-07-15 23:43:41 --> Model "Templates_model" initialized
INFO - 2021-07-15 23:43:41 --> Database Driver Class Initialized
INFO - 2021-07-15 23:43:41 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 23:43:41 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 23:43:41 --> Controller Class Initialized
ERROR - 2021-07-15 23:43:41 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 23:43:41 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 23:43:41 --> Final output sent to browser
DEBUG - 2021-07-15 23:43:41 --> Total execution time: 0.1420
INFO - 2021-07-15 23:44:12 --> Config Class Initialized
INFO - 2021-07-15 23:44:12 --> Hooks Class Initialized
DEBUG - 2021-07-15 23:44:12 --> UTF-8 Support Enabled
INFO - 2021-07-15 23:44:12 --> Utf8 Class Initialized
INFO - 2021-07-15 23:44:12 --> URI Class Initialized
INFO - 2021-07-15 23:44:12 --> Router Class Initialized
INFO - 2021-07-15 23:44:12 --> Output Class Initialized
INFO - 2021-07-15 23:44:12 --> Security Class Initialized
DEBUG - 2021-07-15 23:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 23:44:12 --> Input Class Initialized
INFO - 2021-07-15 23:44:12 --> Language Class Initialized
INFO - 2021-07-15 23:44:12 --> Loader Class Initialized
INFO - 2021-07-15 23:44:12 --> Helper loaded: basic_helper
INFO - 2021-07-15 23:44:12 --> Helper loaded: url_helper
INFO - 2021-07-15 23:44:12 --> Helper loaded: file_helper
INFO - 2021-07-15 23:44:12 --> Helper loaded: form_helper
INFO - 2021-07-15 23:44:12 --> Helper loaded: cookie_helper
INFO - 2021-07-15 23:44:12 --> Helper loaded: security_helper
INFO - 2021-07-15 23:44:12 --> Helper loaded: directory_helper
INFO - 2021-07-15 23:44:12 --> Helper loaded: language_helper
INFO - 2021-07-15 23:44:12 --> Helper loaded: general_helper
INFO - 2021-07-15 23:44:12 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 23:44:12 --> Database Driver Class Initialized
DEBUG - 2021-07-15 23:44:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 23:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 23:44:12 --> Parser Class Initialized
INFO - 2021-07-15 23:44:12 --> Form Validation Class Initialized
INFO - 2021-07-15 23:44:12 --> Upload Class Initialized
INFO - 2021-07-15 23:44:12 --> Email Class Initialized
INFO - 2021-07-15 23:44:12 --> MY_Model class loaded
INFO - 2021-07-15 23:44:12 --> Model "Users_model" initialized
INFO - 2021-07-15 23:44:12 --> Model "Settings_model" initialized
INFO - 2021-07-15 23:44:12 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 23:44:12 --> Model "Permissions_model" initialized
INFO - 2021-07-15 23:44:12 --> Model "Roles_model" initialized
INFO - 2021-07-15 23:44:12 --> Model "Activity_model" initialized
INFO - 2021-07-15 23:44:12 --> Model "Templates_model" initialized
INFO - 2021-07-15 23:44:12 --> Database Driver Class Initialized
INFO - 2021-07-15 23:44:12 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 23:44:12 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 23:44:12 --> Controller Class Initialized
ERROR - 2021-07-15 23:44:12 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 23:44:12 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 23:44:12 --> Final output sent to browser
DEBUG - 2021-07-15 23:44:12 --> Total execution time: 0.1250
INFO - 2021-07-15 23:47:49 --> Config Class Initialized
INFO - 2021-07-15 23:47:49 --> Hooks Class Initialized
DEBUG - 2021-07-15 23:47:49 --> UTF-8 Support Enabled
INFO - 2021-07-15 23:47:49 --> Utf8 Class Initialized
INFO - 2021-07-15 23:47:49 --> URI Class Initialized
INFO - 2021-07-15 23:47:49 --> Router Class Initialized
INFO - 2021-07-15 23:47:49 --> Output Class Initialized
INFO - 2021-07-15 23:47:49 --> Security Class Initialized
DEBUG - 2021-07-15 23:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 23:47:49 --> Input Class Initialized
INFO - 2021-07-15 23:47:49 --> Language Class Initialized
INFO - 2021-07-15 23:47:49 --> Loader Class Initialized
INFO - 2021-07-15 23:47:49 --> Helper loaded: basic_helper
INFO - 2021-07-15 23:47:49 --> Helper loaded: url_helper
INFO - 2021-07-15 23:47:49 --> Helper loaded: file_helper
INFO - 2021-07-15 23:47:49 --> Helper loaded: form_helper
INFO - 2021-07-15 23:47:49 --> Helper loaded: cookie_helper
INFO - 2021-07-15 23:47:49 --> Helper loaded: security_helper
INFO - 2021-07-15 23:47:49 --> Helper loaded: directory_helper
INFO - 2021-07-15 23:47:49 --> Helper loaded: language_helper
INFO - 2021-07-15 23:47:49 --> Helper loaded: general_helper
INFO - 2021-07-15 23:47:49 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 23:47:49 --> Database Driver Class Initialized
DEBUG - 2021-07-15 23:47:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 23:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 23:47:49 --> Parser Class Initialized
INFO - 2021-07-15 23:47:49 --> Form Validation Class Initialized
INFO - 2021-07-15 23:47:49 --> Upload Class Initialized
INFO - 2021-07-15 23:47:49 --> Email Class Initialized
INFO - 2021-07-15 23:47:49 --> MY_Model class loaded
INFO - 2021-07-15 23:47:49 --> Model "Users_model" initialized
INFO - 2021-07-15 23:47:49 --> Model "Settings_model" initialized
INFO - 2021-07-15 23:47:49 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 23:47:49 --> Model "Permissions_model" initialized
INFO - 2021-07-15 23:47:49 --> Model "Roles_model" initialized
INFO - 2021-07-15 23:47:49 --> Model "Activity_model" initialized
INFO - 2021-07-15 23:47:49 --> Model "Templates_model" initialized
INFO - 2021-07-15 23:47:49 --> Database Driver Class Initialized
INFO - 2021-07-15 23:47:49 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 23:47:49 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 23:47:49 --> Controller Class Initialized
ERROR - 2021-07-15 23:47:49 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 23:47:49 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 23:47:49 --> Final output sent to browser
DEBUG - 2021-07-15 23:47:49 --> Total execution time: 0.1256
INFO - 2021-07-15 23:48:01 --> Config Class Initialized
INFO - 2021-07-15 23:48:01 --> Hooks Class Initialized
DEBUG - 2021-07-15 23:48:01 --> UTF-8 Support Enabled
INFO - 2021-07-15 23:48:01 --> Utf8 Class Initialized
INFO - 2021-07-15 23:48:01 --> URI Class Initialized
INFO - 2021-07-15 23:48:01 --> Router Class Initialized
INFO - 2021-07-15 23:48:01 --> Output Class Initialized
INFO - 2021-07-15 23:48:01 --> Security Class Initialized
DEBUG - 2021-07-15 23:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 23:48:01 --> Input Class Initialized
INFO - 2021-07-15 23:48:01 --> Language Class Initialized
INFO - 2021-07-15 23:48:01 --> Loader Class Initialized
INFO - 2021-07-15 23:48:01 --> Helper loaded: basic_helper
INFO - 2021-07-15 23:48:01 --> Helper loaded: url_helper
INFO - 2021-07-15 23:48:01 --> Helper loaded: file_helper
INFO - 2021-07-15 23:48:01 --> Helper loaded: form_helper
INFO - 2021-07-15 23:48:01 --> Helper loaded: cookie_helper
INFO - 2021-07-15 23:48:01 --> Helper loaded: security_helper
INFO - 2021-07-15 23:48:01 --> Helper loaded: directory_helper
INFO - 2021-07-15 23:48:01 --> Helper loaded: language_helper
INFO - 2021-07-15 23:48:01 --> Helper loaded: general_helper
INFO - 2021-07-15 23:48:01 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 23:48:01 --> Database Driver Class Initialized
DEBUG - 2021-07-15 23:48:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 23:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 23:48:01 --> Parser Class Initialized
INFO - 2021-07-15 23:48:01 --> Form Validation Class Initialized
INFO - 2021-07-15 23:48:01 --> Upload Class Initialized
INFO - 2021-07-15 23:48:01 --> Email Class Initialized
INFO - 2021-07-15 23:48:01 --> MY_Model class loaded
INFO - 2021-07-15 23:48:01 --> Model "Users_model" initialized
INFO - 2021-07-15 23:48:01 --> Model "Settings_model" initialized
INFO - 2021-07-15 23:48:01 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 23:48:01 --> Model "Permissions_model" initialized
INFO - 2021-07-15 23:48:01 --> Model "Roles_model" initialized
INFO - 2021-07-15 23:48:01 --> Model "Activity_model" initialized
INFO - 2021-07-15 23:48:01 --> Model "Templates_model" initialized
INFO - 2021-07-15 23:48:01 --> Database Driver Class Initialized
INFO - 2021-07-15 23:48:01 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 23:48:01 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 23:48:01 --> Controller Class Initialized
ERROR - 2021-07-15 23:48:01 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 23:48:01 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 23:48:01 --> Final output sent to browser
DEBUG - 2021-07-15 23:48:01 --> Total execution time: 0.1345
INFO - 2021-07-15 23:51:53 --> Config Class Initialized
INFO - 2021-07-15 23:51:53 --> Hooks Class Initialized
DEBUG - 2021-07-15 23:51:53 --> UTF-8 Support Enabled
INFO - 2021-07-15 23:51:53 --> Utf8 Class Initialized
INFO - 2021-07-15 23:51:54 --> URI Class Initialized
INFO - 2021-07-15 23:51:54 --> Router Class Initialized
INFO - 2021-07-15 23:51:54 --> Output Class Initialized
INFO - 2021-07-15 23:51:54 --> Security Class Initialized
DEBUG - 2021-07-15 23:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-15 23:51:54 --> Input Class Initialized
INFO - 2021-07-15 23:51:54 --> Language Class Initialized
INFO - 2021-07-15 23:51:54 --> Loader Class Initialized
INFO - 2021-07-15 23:51:54 --> Helper loaded: basic_helper
INFO - 2021-07-15 23:51:54 --> Helper loaded: url_helper
INFO - 2021-07-15 23:51:54 --> Helper loaded: file_helper
INFO - 2021-07-15 23:51:54 --> Helper loaded: form_helper
INFO - 2021-07-15 23:51:54 --> Helper loaded: cookie_helper
INFO - 2021-07-15 23:51:54 --> Helper loaded: security_helper
INFO - 2021-07-15 23:51:54 --> Helper loaded: directory_helper
INFO - 2021-07-15 23:51:54 --> Helper loaded: language_helper
INFO - 2021-07-15 23:51:54 --> Helper loaded: general_helper
INFO - 2021-07-15 23:51:54 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-15 23:51:54 --> Database Driver Class Initialized
DEBUG - 2021-07-15 23:51:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-15 23:51:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-15 23:51:54 --> Parser Class Initialized
INFO - 2021-07-15 23:51:54 --> Form Validation Class Initialized
INFO - 2021-07-15 23:51:54 --> Upload Class Initialized
INFO - 2021-07-15 23:51:54 --> Email Class Initialized
INFO - 2021-07-15 23:51:54 --> MY_Model class loaded
INFO - 2021-07-15 23:51:54 --> Model "Users_model" initialized
INFO - 2021-07-15 23:51:54 --> Model "Settings_model" initialized
INFO - 2021-07-15 23:51:54 --> Model "Role_permissions_model" initialized
INFO - 2021-07-15 23:51:54 --> Model "Permissions_model" initialized
INFO - 2021-07-15 23:51:54 --> Model "Roles_model" initialized
INFO - 2021-07-15 23:51:54 --> Model "Activity_model" initialized
INFO - 2021-07-15 23:51:54 --> Model "Templates_model" initialized
INFO - 2021-07-15 23:51:54 --> Database Driver Class Initialized
INFO - 2021-07-15 23:51:54 --> Model "Hesaplar_model" initialized
INFO - 2021-07-15 23:51:54 --> Model "Car_activity_model" initialized
INFO - 2021-07-15 23:51:54 --> Controller Class Initialized
ERROR - 2021-07-15 23:51:54 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-15 23:51:54 --> File loaded: C:\wamp64\www\crm\application\views\car/car_list.php
INFO - 2021-07-15 23:51:54 --> Final output sent to browser
DEBUG - 2021-07-15 23:51:54 --> Total execution time: 0.5798
