<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-07-10 10:02:28 --> Config Class Initialized
INFO - 2021-07-10 10:02:28 --> Hooks Class Initialized
DEBUG - 2021-07-10 10:02:28 --> UTF-8 Support Enabled
INFO - 2021-07-10 10:02:28 --> Utf8 Class Initialized
INFO - 2021-07-10 10:02:28 --> URI Class Initialized
DEBUG - 2021-07-10 10:02:28 --> No URI present. Default controller set.
INFO - 2021-07-10 10:02:28 --> Router Class Initialized
INFO - 2021-07-10 10:02:28 --> Output Class Initialized
INFO - 2021-07-10 10:02:28 --> Security Class Initialized
DEBUG - 2021-07-10 10:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 10:02:28 --> Input Class Initialized
INFO - 2021-07-10 10:02:28 --> Language Class Initialized
INFO - 2021-07-10 10:02:28 --> Loader Class Initialized
INFO - 2021-07-10 10:02:28 --> Helper loaded: basic_helper
INFO - 2021-07-10 10:02:28 --> Helper loaded: url_helper
INFO - 2021-07-10 10:02:28 --> Helper loaded: file_helper
INFO - 2021-07-10 10:02:28 --> Helper loaded: form_helper
INFO - 2021-07-10 10:02:28 --> Helper loaded: cookie_helper
INFO - 2021-07-10 10:02:28 --> Helper loaded: security_helper
INFO - 2021-07-10 10:02:28 --> Helper loaded: directory_helper
INFO - 2021-07-10 10:02:28 --> Helper loaded: language_helper
INFO - 2021-07-10 10:02:28 --> Helper loaded: general_helper
INFO - 2021-07-10 10:02:28 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-10 10:02:28 --> Database Driver Class Initialized
DEBUG - 2021-07-10 10:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-10 10:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-10 10:02:28 --> Parser Class Initialized
INFO - 2021-07-10 10:02:28 --> Form Validation Class Initialized
INFO - 2021-07-10 10:02:28 --> Upload Class Initialized
INFO - 2021-07-10 10:02:28 --> Email Class Initialized
INFO - 2021-07-10 10:02:28 --> MY_Model class loaded
INFO - 2021-07-10 10:02:28 --> Model "Users_model" initialized
INFO - 2021-07-10 10:02:28 --> Model "Settings_model" initialized
INFO - 2021-07-10 10:02:28 --> Model "Role_permissions_model" initialized
INFO - 2021-07-10 10:02:28 --> Model "Permissions_model" initialized
INFO - 2021-07-10 10:02:28 --> Model "Roles_model" initialized
INFO - 2021-07-10 10:02:28 --> Model "Activity_model" initialized
INFO - 2021-07-10 10:02:28 --> Model "Templates_model" initialized
INFO - 2021-07-10 10:02:28 --> Database Driver Class Initialized
INFO - 2021-07-10 10:02:28 --> Model "Hesaplar_model" initialized
INFO - 2021-07-10 10:02:28 --> Controller Class Initialized
ERROR - 2021-07-10 10:02:28 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-10 10:02:28 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-10 10:02:28 --> Final output sent to browser
DEBUG - 2021-07-10 10:02:28 --> Total execution time: 0.1378
INFO - 2021-07-10 10:02:30 --> Config Class Initialized
INFO - 2021-07-10 10:02:30 --> Hooks Class Initialized
DEBUG - 2021-07-10 10:02:30 --> UTF-8 Support Enabled
INFO - 2021-07-10 10:02:30 --> Utf8 Class Initialized
INFO - 2021-07-10 10:02:30 --> URI Class Initialized
INFO - 2021-07-10 10:02:30 --> Router Class Initialized
INFO - 2021-07-10 10:02:30 --> Output Class Initialized
INFO - 2021-07-10 10:02:30 --> Security Class Initialized
DEBUG - 2021-07-10 10:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 10:02:30 --> Input Class Initialized
INFO - 2021-07-10 10:02:30 --> Language Class Initialized
ERROR - 2021-07-10 10:02:30 --> 404 Page Not Found: Faviconico/index
INFO - 2021-07-10 10:03:52 --> Config Class Initialized
INFO - 2021-07-10 10:03:52 --> Hooks Class Initialized
DEBUG - 2021-07-10 10:03:52 --> UTF-8 Support Enabled
INFO - 2021-07-10 10:03:52 --> Utf8 Class Initialized
INFO - 2021-07-10 10:03:52 --> URI Class Initialized
INFO - 2021-07-10 10:03:52 --> Router Class Initialized
INFO - 2021-07-10 10:03:52 --> Output Class Initialized
INFO - 2021-07-10 10:03:52 --> Security Class Initialized
DEBUG - 2021-07-10 10:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 10:03:52 --> Input Class Initialized
INFO - 2021-07-10 10:03:52 --> Language Class Initialized
INFO - 2021-07-10 10:03:52 --> Loader Class Initialized
INFO - 2021-07-10 10:03:52 --> Helper loaded: basic_helper
INFO - 2021-07-10 10:03:52 --> Helper loaded: url_helper
INFO - 2021-07-10 10:03:52 --> Helper loaded: file_helper
INFO - 2021-07-10 10:03:52 --> Helper loaded: form_helper
INFO - 2021-07-10 10:03:52 --> Helper loaded: cookie_helper
INFO - 2021-07-10 10:03:52 --> Helper loaded: security_helper
INFO - 2021-07-10 10:03:52 --> Helper loaded: directory_helper
INFO - 2021-07-10 10:03:52 --> Helper loaded: language_helper
INFO - 2021-07-10 10:03:52 --> Helper loaded: general_helper
INFO - 2021-07-10 10:03:52 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-10 10:03:52 --> Database Driver Class Initialized
DEBUG - 2021-07-10 10:03:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-10 10:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-10 10:03:52 --> Parser Class Initialized
INFO - 2021-07-10 10:03:52 --> Form Validation Class Initialized
INFO - 2021-07-10 10:03:52 --> Upload Class Initialized
INFO - 2021-07-10 10:03:52 --> Email Class Initialized
INFO - 2021-07-10 10:03:52 --> MY_Model class loaded
INFO - 2021-07-10 10:03:52 --> Model "Users_model" initialized
INFO - 2021-07-10 10:03:52 --> Model "Settings_model" initialized
INFO - 2021-07-10 10:03:52 --> Model "Role_permissions_model" initialized
INFO - 2021-07-10 10:03:52 --> Model "Permissions_model" initialized
INFO - 2021-07-10 10:03:52 --> Model "Roles_model" initialized
INFO - 2021-07-10 10:03:52 --> Model "Activity_model" initialized
INFO - 2021-07-10 10:03:52 --> Model "Templates_model" initialized
INFO - 2021-07-10 10:03:52 --> Database Driver Class Initialized
INFO - 2021-07-10 10:03:52 --> Model "Hesaplar_model" initialized
INFO - 2021-07-10 10:03:52 --> Controller Class Initialized
ERROR - 2021-07-10 10:03:52 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-10 10:03:52 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-10 10:03:52 --> Final output sent to browser
DEBUG - 2021-07-10 10:03:52 --> Total execution time: 0.7033
INFO - 2021-07-10 10:04:22 --> Config Class Initialized
INFO - 2021-07-10 10:04:22 --> Hooks Class Initialized
DEBUG - 2021-07-10 10:04:22 --> UTF-8 Support Enabled
INFO - 2021-07-10 10:04:22 --> Utf8 Class Initialized
INFO - 2021-07-10 10:04:22 --> URI Class Initialized
INFO - 2021-07-10 10:04:22 --> Router Class Initialized
INFO - 2021-07-10 10:04:22 --> Output Class Initialized
INFO - 2021-07-10 10:04:22 --> Security Class Initialized
DEBUG - 2021-07-10 10:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 10:04:22 --> Input Class Initialized
INFO - 2021-07-10 10:04:22 --> Language Class Initialized
INFO - 2021-07-10 10:04:22 --> Loader Class Initialized
INFO - 2021-07-10 10:04:22 --> Helper loaded: basic_helper
INFO - 2021-07-10 10:04:22 --> Helper loaded: url_helper
INFO - 2021-07-10 10:04:22 --> Helper loaded: file_helper
INFO - 2021-07-10 10:04:22 --> Helper loaded: form_helper
INFO - 2021-07-10 10:04:22 --> Helper loaded: cookie_helper
INFO - 2021-07-10 10:04:22 --> Helper loaded: security_helper
INFO - 2021-07-10 10:04:22 --> Helper loaded: directory_helper
INFO - 2021-07-10 10:04:22 --> Helper loaded: language_helper
INFO - 2021-07-10 10:04:22 --> Helper loaded: general_helper
INFO - 2021-07-10 10:04:22 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-10 10:04:22 --> Database Driver Class Initialized
DEBUG - 2021-07-10 10:04:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-10 10:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-10 10:04:22 --> Parser Class Initialized
INFO - 2021-07-10 10:04:22 --> Form Validation Class Initialized
INFO - 2021-07-10 10:04:22 --> Upload Class Initialized
INFO - 2021-07-10 10:04:22 --> Email Class Initialized
INFO - 2021-07-10 10:04:22 --> MY_Model class loaded
INFO - 2021-07-10 10:04:22 --> Model "Users_model" initialized
INFO - 2021-07-10 10:04:22 --> Model "Settings_model" initialized
INFO - 2021-07-10 10:04:22 --> Model "Role_permissions_model" initialized
INFO - 2021-07-10 10:04:22 --> Model "Permissions_model" initialized
INFO - 2021-07-10 10:04:22 --> Model "Roles_model" initialized
INFO - 2021-07-10 10:04:22 --> Model "Activity_model" initialized
INFO - 2021-07-10 10:04:22 --> Model "Templates_model" initialized
INFO - 2021-07-10 10:04:22 --> Database Driver Class Initialized
INFO - 2021-07-10 10:04:22 --> Model "Hesaplar_model" initialized
INFO - 2021-07-10 10:04:22 --> Controller Class Initialized
ERROR - 2021-07-10 10:04:22 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-10 10:04:22 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-10 10:04:22 --> Final output sent to browser
DEBUG - 2021-07-10 10:04:22 --> Total execution time: 0.1480
INFO - 2021-07-10 10:06:13 --> Config Class Initialized
INFO - 2021-07-10 10:06:13 --> Hooks Class Initialized
DEBUG - 2021-07-10 10:06:13 --> UTF-8 Support Enabled
INFO - 2021-07-10 10:06:13 --> Utf8 Class Initialized
INFO - 2021-07-10 10:06:13 --> URI Class Initialized
DEBUG - 2021-07-10 10:06:13 --> No URI present. Default controller set.
INFO - 2021-07-10 10:06:13 --> Router Class Initialized
INFO - 2021-07-10 10:06:13 --> Output Class Initialized
INFO - 2021-07-10 10:06:13 --> Security Class Initialized
DEBUG - 2021-07-10 10:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 10:06:13 --> Input Class Initialized
INFO - 2021-07-10 10:06:13 --> Language Class Initialized
INFO - 2021-07-10 10:06:13 --> Loader Class Initialized
INFO - 2021-07-10 10:06:13 --> Helper loaded: basic_helper
INFO - 2021-07-10 10:06:13 --> Helper loaded: url_helper
INFO - 2021-07-10 10:06:13 --> Helper loaded: file_helper
INFO - 2021-07-10 10:06:13 --> Helper loaded: form_helper
INFO - 2021-07-10 10:06:13 --> Helper loaded: cookie_helper
INFO - 2021-07-10 10:06:13 --> Helper loaded: security_helper
INFO - 2021-07-10 10:06:13 --> Helper loaded: directory_helper
INFO - 2021-07-10 10:06:13 --> Helper loaded: language_helper
INFO - 2021-07-10 10:06:13 --> Helper loaded: general_helper
INFO - 2021-07-10 10:06:13 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-10 10:06:13 --> Database Driver Class Initialized
DEBUG - 2021-07-10 10:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-10 10:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-10 10:06:13 --> Parser Class Initialized
INFO - 2021-07-10 10:06:13 --> Form Validation Class Initialized
INFO - 2021-07-10 10:06:13 --> Upload Class Initialized
INFO - 2021-07-10 10:06:13 --> Email Class Initialized
INFO - 2021-07-10 10:06:13 --> MY_Model class loaded
INFO - 2021-07-10 10:06:13 --> Model "Users_model" initialized
INFO - 2021-07-10 10:06:13 --> Model "Settings_model" initialized
INFO - 2021-07-10 10:06:13 --> Model "Role_permissions_model" initialized
INFO - 2021-07-10 10:06:13 --> Model "Permissions_model" initialized
INFO - 2021-07-10 10:06:13 --> Model "Roles_model" initialized
INFO - 2021-07-10 10:06:13 --> Model "Activity_model" initialized
INFO - 2021-07-10 10:06:13 --> Model "Templates_model" initialized
INFO - 2021-07-10 10:06:13 --> Database Driver Class Initialized
INFO - 2021-07-10 10:06:14 --> Model "Hesaplar_model" initialized
INFO - 2021-07-10 10:06:14 --> Controller Class Initialized
ERROR - 2021-07-10 10:06:14 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-10 10:06:14 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-10 10:06:14 --> Final output sent to browser
DEBUG - 2021-07-10 10:06:14 --> Total execution time: 0.5418
INFO - 2021-07-10 10:17:04 --> Config Class Initialized
INFO - 2021-07-10 10:17:04 --> Hooks Class Initialized
DEBUG - 2021-07-10 10:17:04 --> UTF-8 Support Enabled
INFO - 2021-07-10 10:17:04 --> Utf8 Class Initialized
INFO - 2021-07-10 10:17:04 --> URI Class Initialized
DEBUG - 2021-07-10 10:17:04 --> No URI present. Default controller set.
INFO - 2021-07-10 10:17:04 --> Router Class Initialized
INFO - 2021-07-10 10:17:04 --> Output Class Initialized
INFO - 2021-07-10 10:17:04 --> Security Class Initialized
DEBUG - 2021-07-10 10:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 10:17:04 --> Input Class Initialized
INFO - 2021-07-10 10:17:04 --> Language Class Initialized
INFO - 2021-07-10 10:17:04 --> Loader Class Initialized
INFO - 2021-07-10 10:17:04 --> Helper loaded: basic_helper
INFO - 2021-07-10 10:17:04 --> Helper loaded: url_helper
INFO - 2021-07-10 10:17:04 --> Helper loaded: file_helper
INFO - 2021-07-10 10:17:04 --> Helper loaded: form_helper
INFO - 2021-07-10 10:17:04 --> Helper loaded: cookie_helper
INFO - 2021-07-10 10:17:04 --> Helper loaded: security_helper
INFO - 2021-07-10 10:17:04 --> Helper loaded: directory_helper
INFO - 2021-07-10 10:17:04 --> Helper loaded: language_helper
INFO - 2021-07-10 10:17:04 --> Helper loaded: general_helper
INFO - 2021-07-10 10:17:04 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-10 10:17:04 --> Database Driver Class Initialized
DEBUG - 2021-07-10 10:17:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-10 10:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-10 10:17:04 --> Parser Class Initialized
INFO - 2021-07-10 10:17:04 --> Form Validation Class Initialized
INFO - 2021-07-10 10:17:04 --> Upload Class Initialized
INFO - 2021-07-10 10:17:04 --> Email Class Initialized
INFO - 2021-07-10 10:17:04 --> MY_Model class loaded
INFO - 2021-07-10 10:17:04 --> Model "Users_model" initialized
INFO - 2021-07-10 10:17:04 --> Model "Settings_model" initialized
INFO - 2021-07-10 10:17:04 --> Model "Role_permissions_model" initialized
INFO - 2021-07-10 10:17:04 --> Model "Permissions_model" initialized
INFO - 2021-07-10 10:17:04 --> Model "Roles_model" initialized
INFO - 2021-07-10 10:17:04 --> Model "Activity_model" initialized
INFO - 2021-07-10 10:17:04 --> Model "Templates_model" initialized
INFO - 2021-07-10 10:17:04 --> Database Driver Class Initialized
INFO - 2021-07-10 10:17:04 --> Model "Hesaplar_model" initialized
INFO - 2021-07-10 10:17:04 --> Controller Class Initialized
INFO - 2021-07-10 10:19:10 --> Config Class Initialized
INFO - 2021-07-10 10:19:10 --> Hooks Class Initialized
DEBUG - 2021-07-10 10:19:10 --> UTF-8 Support Enabled
INFO - 2021-07-10 10:19:10 --> Utf8 Class Initialized
INFO - 2021-07-10 10:19:10 --> URI Class Initialized
INFO - 2021-07-10 10:19:10 --> Router Class Initialized
INFO - 2021-07-10 10:19:10 --> Output Class Initialized
INFO - 2021-07-10 10:19:10 --> Security Class Initialized
DEBUG - 2021-07-10 10:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 10:19:10 --> Input Class Initialized
INFO - 2021-07-10 10:19:10 --> Language Class Initialized
INFO - 2021-07-10 10:19:10 --> Loader Class Initialized
INFO - 2021-07-10 10:19:10 --> Helper loaded: basic_helper
INFO - 2021-07-10 10:19:10 --> Helper loaded: url_helper
INFO - 2021-07-10 10:19:10 --> Helper loaded: file_helper
INFO - 2021-07-10 10:19:10 --> Helper loaded: form_helper
INFO - 2021-07-10 10:19:10 --> Helper loaded: cookie_helper
INFO - 2021-07-10 10:19:10 --> Helper loaded: security_helper
INFO - 2021-07-10 10:19:10 --> Helper loaded: directory_helper
INFO - 2021-07-10 10:19:10 --> Helper loaded: language_helper
INFO - 2021-07-10 10:19:10 --> Helper loaded: general_helper
INFO - 2021-07-10 10:19:10 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-10 10:19:10 --> Database Driver Class Initialized
DEBUG - 2021-07-10 10:19:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-10 10:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-10 10:19:10 --> Parser Class Initialized
INFO - 2021-07-10 10:19:10 --> Form Validation Class Initialized
INFO - 2021-07-10 10:19:10 --> Upload Class Initialized
INFO - 2021-07-10 10:19:10 --> Email Class Initialized
INFO - 2021-07-10 10:19:10 --> MY_Model class loaded
INFO - 2021-07-10 10:19:10 --> Model "Users_model" initialized
INFO - 2021-07-10 10:19:10 --> Model "Settings_model" initialized
INFO - 2021-07-10 10:19:10 --> Model "Role_permissions_model" initialized
INFO - 2021-07-10 10:19:10 --> Model "Permissions_model" initialized
INFO - 2021-07-10 10:19:10 --> Model "Roles_model" initialized
INFO - 2021-07-10 10:19:10 --> Model "Activity_model" initialized
INFO - 2021-07-10 10:19:10 --> Model "Templates_model" initialized
INFO - 2021-07-10 10:19:10 --> Database Driver Class Initialized
INFO - 2021-07-10 10:19:10 --> Model "Hesaplar_model" initialized
INFO - 2021-07-10 10:19:10 --> Controller Class Initialized
ERROR - 2021-07-10 10:19:10 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-10 10:19:10 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-10 10:19:10 --> Final output sent to browser
DEBUG - 2021-07-10 10:19:10 --> Total execution time: 0.6196
INFO - 2021-07-10 10:19:21 --> Config Class Initialized
INFO - 2021-07-10 10:19:21 --> Hooks Class Initialized
DEBUG - 2021-07-10 10:19:21 --> UTF-8 Support Enabled
INFO - 2021-07-10 10:19:21 --> Utf8 Class Initialized
INFO - 2021-07-10 10:19:21 --> URI Class Initialized
INFO - 2021-07-10 10:19:21 --> Router Class Initialized
INFO - 2021-07-10 10:19:21 --> Output Class Initialized
INFO - 2021-07-10 10:19:21 --> Security Class Initialized
DEBUG - 2021-07-10 10:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 10:19:21 --> Input Class Initialized
INFO - 2021-07-10 10:19:21 --> Language Class Initialized
INFO - 2021-07-10 10:19:21 --> Loader Class Initialized
INFO - 2021-07-10 10:19:21 --> Helper loaded: basic_helper
INFO - 2021-07-10 10:19:21 --> Helper loaded: url_helper
INFO - 2021-07-10 10:19:21 --> Helper loaded: file_helper
INFO - 2021-07-10 10:19:21 --> Helper loaded: form_helper
INFO - 2021-07-10 10:19:21 --> Helper loaded: cookie_helper
INFO - 2021-07-10 10:19:21 --> Helper loaded: security_helper
INFO - 2021-07-10 10:19:21 --> Helper loaded: directory_helper
INFO - 2021-07-10 10:19:21 --> Helper loaded: language_helper
INFO - 2021-07-10 10:19:21 --> Helper loaded: general_helper
INFO - 2021-07-10 10:19:21 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-10 10:19:21 --> Database Driver Class Initialized
DEBUG - 2021-07-10 10:19:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-10 10:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-10 10:19:21 --> Parser Class Initialized
INFO - 2021-07-10 10:19:21 --> Form Validation Class Initialized
INFO - 2021-07-10 10:19:21 --> Upload Class Initialized
INFO - 2021-07-10 10:19:21 --> Email Class Initialized
INFO - 2021-07-10 10:19:21 --> MY_Model class loaded
INFO - 2021-07-10 10:19:21 --> Model "Users_model" initialized
INFO - 2021-07-10 10:19:21 --> Model "Settings_model" initialized
INFO - 2021-07-10 10:19:21 --> Model "Role_permissions_model" initialized
INFO - 2021-07-10 10:19:21 --> Model "Permissions_model" initialized
INFO - 2021-07-10 10:19:21 --> Model "Roles_model" initialized
INFO - 2021-07-10 10:19:21 --> Model "Activity_model" initialized
INFO - 2021-07-10 10:19:21 --> Model "Templates_model" initialized
INFO - 2021-07-10 10:19:21 --> Database Driver Class Initialized
INFO - 2021-07-10 10:19:21 --> Model "Hesaplar_model" initialized
INFO - 2021-07-10 10:19:21 --> Controller Class Initialized
ERROR - 2021-07-10 10:19:21 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-10 10:19:21 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-10 10:19:21 --> Final output sent to browser
DEBUG - 2021-07-10 10:19:21 --> Total execution time: 0.1464
INFO - 2021-07-10 10:23:42 --> Config Class Initialized
INFO - 2021-07-10 10:23:42 --> Hooks Class Initialized
DEBUG - 2021-07-10 10:23:42 --> UTF-8 Support Enabled
INFO - 2021-07-10 10:23:42 --> Utf8 Class Initialized
INFO - 2021-07-10 10:23:42 --> URI Class Initialized
INFO - 2021-07-10 10:23:42 --> Router Class Initialized
INFO - 2021-07-10 10:23:42 --> Output Class Initialized
INFO - 2021-07-10 10:23:42 --> Security Class Initialized
DEBUG - 2021-07-10 10:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 10:23:42 --> Input Class Initialized
INFO - 2021-07-10 10:23:42 --> Language Class Initialized
INFO - 2021-07-10 10:23:42 --> Loader Class Initialized
INFO - 2021-07-10 10:23:42 --> Helper loaded: basic_helper
INFO - 2021-07-10 10:23:42 --> Helper loaded: url_helper
INFO - 2021-07-10 10:23:42 --> Helper loaded: file_helper
INFO - 2021-07-10 10:23:42 --> Helper loaded: form_helper
INFO - 2021-07-10 10:23:42 --> Helper loaded: cookie_helper
INFO - 2021-07-10 10:23:42 --> Helper loaded: security_helper
INFO - 2021-07-10 10:23:42 --> Helper loaded: directory_helper
INFO - 2021-07-10 10:23:42 --> Helper loaded: language_helper
INFO - 2021-07-10 10:23:42 --> Helper loaded: general_helper
INFO - 2021-07-10 10:23:42 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-10 10:23:42 --> Database Driver Class Initialized
DEBUG - 2021-07-10 10:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-10 10:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-10 10:23:42 --> Parser Class Initialized
INFO - 2021-07-10 10:23:42 --> Form Validation Class Initialized
INFO - 2021-07-10 10:23:42 --> Upload Class Initialized
INFO - 2021-07-10 10:23:42 --> Email Class Initialized
INFO - 2021-07-10 10:23:42 --> MY_Model class loaded
INFO - 2021-07-10 10:23:42 --> Model "Users_model" initialized
INFO - 2021-07-10 10:23:42 --> Model "Settings_model" initialized
INFO - 2021-07-10 10:23:42 --> Model "Role_permissions_model" initialized
INFO - 2021-07-10 10:23:42 --> Model "Permissions_model" initialized
INFO - 2021-07-10 10:23:42 --> Model "Roles_model" initialized
INFO - 2021-07-10 10:23:42 --> Model "Activity_model" initialized
INFO - 2021-07-10 10:23:42 --> Model "Templates_model" initialized
INFO - 2021-07-10 10:23:42 --> Database Driver Class Initialized
INFO - 2021-07-10 10:23:43 --> Model "Hesaplar_model" initialized
INFO - 2021-07-10 10:23:43 --> Controller Class Initialized
ERROR - 2021-07-10 10:23:43 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-10 10:23:43 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-10 10:23:43 --> Final output sent to browser
DEBUG - 2021-07-10 10:23:43 --> Total execution time: 0.6192
INFO - 2021-07-10 10:23:57 --> Config Class Initialized
INFO - 2021-07-10 10:23:57 --> Hooks Class Initialized
DEBUG - 2021-07-10 10:23:57 --> UTF-8 Support Enabled
INFO - 2021-07-10 10:23:57 --> Utf8 Class Initialized
INFO - 2021-07-10 10:23:57 --> URI Class Initialized
INFO - 2021-07-10 10:23:57 --> Router Class Initialized
INFO - 2021-07-10 10:23:57 --> Output Class Initialized
INFO - 2021-07-10 10:23:57 --> Security Class Initialized
DEBUG - 2021-07-10 10:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 10:23:57 --> Input Class Initialized
INFO - 2021-07-10 10:23:57 --> Language Class Initialized
INFO - 2021-07-10 10:23:57 --> Loader Class Initialized
INFO - 2021-07-10 10:23:57 --> Helper loaded: basic_helper
INFO - 2021-07-10 10:23:57 --> Helper loaded: url_helper
INFO - 2021-07-10 10:23:57 --> Helper loaded: file_helper
INFO - 2021-07-10 10:23:57 --> Helper loaded: form_helper
INFO - 2021-07-10 10:23:57 --> Helper loaded: cookie_helper
INFO - 2021-07-10 10:23:57 --> Helper loaded: security_helper
INFO - 2021-07-10 10:23:57 --> Helper loaded: directory_helper
INFO - 2021-07-10 10:23:57 --> Helper loaded: language_helper
INFO - 2021-07-10 10:23:57 --> Helper loaded: general_helper
INFO - 2021-07-10 10:23:57 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-10 10:23:57 --> Database Driver Class Initialized
DEBUG - 2021-07-10 10:23:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-10 10:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-10 10:23:57 --> Parser Class Initialized
INFO - 2021-07-10 10:23:57 --> Form Validation Class Initialized
INFO - 2021-07-10 10:23:57 --> Upload Class Initialized
INFO - 2021-07-10 10:23:57 --> Email Class Initialized
INFO - 2021-07-10 10:23:57 --> MY_Model class loaded
INFO - 2021-07-10 10:23:57 --> Model "Users_model" initialized
INFO - 2021-07-10 10:23:57 --> Model "Settings_model" initialized
INFO - 2021-07-10 10:23:57 --> Model "Role_permissions_model" initialized
INFO - 2021-07-10 10:23:57 --> Model "Permissions_model" initialized
INFO - 2021-07-10 10:23:57 --> Model "Roles_model" initialized
INFO - 2021-07-10 10:23:57 --> Model "Activity_model" initialized
INFO - 2021-07-10 10:23:57 --> Model "Templates_model" initialized
INFO - 2021-07-10 10:23:57 --> Database Driver Class Initialized
INFO - 2021-07-10 10:23:57 --> Model "Hesaplar_model" initialized
INFO - 2021-07-10 10:23:57 --> Controller Class Initialized
ERROR - 2021-07-10 10:23:57 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-10 10:23:57 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-10 10:23:57 --> Final output sent to browser
DEBUG - 2021-07-10 10:23:57 --> Total execution time: 0.1384
INFO - 2021-07-10 10:30:50 --> Config Class Initialized
INFO - 2021-07-10 10:30:50 --> Hooks Class Initialized
DEBUG - 2021-07-10 10:30:50 --> UTF-8 Support Enabled
INFO - 2021-07-10 10:30:50 --> Utf8 Class Initialized
INFO - 2021-07-10 10:30:50 --> URI Class Initialized
INFO - 2021-07-10 10:30:50 --> Router Class Initialized
INFO - 2021-07-10 10:30:50 --> Output Class Initialized
INFO - 2021-07-10 10:30:50 --> Security Class Initialized
DEBUG - 2021-07-10 10:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 10:30:50 --> Input Class Initialized
INFO - 2021-07-10 10:30:50 --> Language Class Initialized
INFO - 2021-07-10 10:30:50 --> Loader Class Initialized
INFO - 2021-07-10 10:30:50 --> Helper loaded: basic_helper
INFO - 2021-07-10 10:30:50 --> Helper loaded: url_helper
INFO - 2021-07-10 10:30:50 --> Helper loaded: file_helper
INFO - 2021-07-10 10:30:50 --> Helper loaded: form_helper
INFO - 2021-07-10 10:30:50 --> Helper loaded: cookie_helper
INFO - 2021-07-10 10:30:50 --> Helper loaded: security_helper
INFO - 2021-07-10 10:30:50 --> Helper loaded: directory_helper
INFO - 2021-07-10 10:30:50 --> Helper loaded: language_helper
INFO - 2021-07-10 10:30:50 --> Helper loaded: general_helper
INFO - 2021-07-10 10:30:50 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-10 10:30:50 --> Database Driver Class Initialized
DEBUG - 2021-07-10 10:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-10 10:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-10 10:30:50 --> Parser Class Initialized
INFO - 2021-07-10 10:30:50 --> Form Validation Class Initialized
INFO - 2021-07-10 10:30:50 --> Upload Class Initialized
INFO - 2021-07-10 10:30:50 --> Email Class Initialized
INFO - 2021-07-10 10:30:50 --> MY_Model class loaded
INFO - 2021-07-10 10:30:50 --> Model "Users_model" initialized
INFO - 2021-07-10 10:30:50 --> Model "Settings_model" initialized
INFO - 2021-07-10 10:30:50 --> Model "Role_permissions_model" initialized
INFO - 2021-07-10 10:30:50 --> Model "Permissions_model" initialized
INFO - 2021-07-10 10:30:50 --> Model "Roles_model" initialized
INFO - 2021-07-10 10:30:50 --> Model "Activity_model" initialized
INFO - 2021-07-10 10:30:50 --> Model "Templates_model" initialized
INFO - 2021-07-10 10:30:50 --> Database Driver Class Initialized
INFO - 2021-07-10 10:30:50 --> Model "Hesaplar_model" initialized
INFO - 2021-07-10 10:30:50 --> Controller Class Initialized
INFO - 2021-07-10 10:30:50 --> File loaded: C:\wamp64\www\crm\application\views\account/login.php
INFO - 2021-07-10 10:30:50 --> Final output sent to browser
DEBUG - 2021-07-10 10:30:50 --> Total execution time: 0.1216
INFO - 2021-07-10 10:30:50 --> Config Class Initialized
INFO - 2021-07-10 10:30:50 --> Hooks Class Initialized
DEBUG - 2021-07-10 10:30:50 --> UTF-8 Support Enabled
INFO - 2021-07-10 10:30:50 --> Utf8 Class Initialized
INFO - 2021-07-10 10:30:50 --> URI Class Initialized
INFO - 2021-07-10 10:30:50 --> Router Class Initialized
INFO - 2021-07-10 10:30:50 --> Output Class Initialized
INFO - 2021-07-10 10:30:50 --> Security Class Initialized
DEBUG - 2021-07-10 10:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 10:30:50 --> Input Class Initialized
INFO - 2021-07-10 10:30:50 --> Language Class Initialized
ERROR - 2021-07-10 10:30:50 --> 404 Page Not Found: Assets/jquery
INFO - 2021-07-10 10:30:50 --> Config Class Initialized
INFO - 2021-07-10 10:30:50 --> Hooks Class Initialized
DEBUG - 2021-07-10 10:30:50 --> UTF-8 Support Enabled
INFO - 2021-07-10 10:30:50 --> Utf8 Class Initialized
INFO - 2021-07-10 10:30:50 --> URI Class Initialized
INFO - 2021-07-10 10:30:50 --> Router Class Initialized
INFO - 2021-07-10 10:30:50 --> Output Class Initialized
INFO - 2021-07-10 10:30:50 --> Security Class Initialized
DEBUG - 2021-07-10 10:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 10:30:50 --> Input Class Initialized
INFO - 2021-07-10 10:30:50 --> Language Class Initialized
ERROR - 2021-07-10 10:30:50 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-10 10:30:51 --> Config Class Initialized
INFO - 2021-07-10 10:30:51 --> Hooks Class Initialized
DEBUG - 2021-07-10 10:30:51 --> UTF-8 Support Enabled
INFO - 2021-07-10 10:30:51 --> Utf8 Class Initialized
INFO - 2021-07-10 10:30:51 --> URI Class Initialized
INFO - 2021-07-10 10:30:51 --> Router Class Initialized
INFO - 2021-07-10 10:30:51 --> Output Class Initialized
INFO - 2021-07-10 10:30:51 --> Security Class Initialized
DEBUG - 2021-07-10 10:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 10:30:51 --> Input Class Initialized
INFO - 2021-07-10 10:30:51 --> Language Class Initialized
ERROR - 2021-07-10 10:30:51 --> 404 Page Not Found: Assets/bootstrap
INFO - 2021-07-10 10:30:51 --> Config Class Initialized
INFO - 2021-07-10 10:30:51 --> Hooks Class Initialized
DEBUG - 2021-07-10 10:30:51 --> UTF-8 Support Enabled
INFO - 2021-07-10 10:30:51 --> Utf8 Class Initialized
INFO - 2021-07-10 10:30:51 --> URI Class Initialized
INFO - 2021-07-10 10:30:51 --> Router Class Initialized
INFO - 2021-07-10 10:30:51 --> Output Class Initialized
INFO - 2021-07-10 10:30:51 --> Security Class Initialized
DEBUG - 2021-07-10 10:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 10:30:51 --> Input Class Initialized
INFO - 2021-07-10 10:30:51 --> Language Class Initialized
ERROR - 2021-07-10 10:30:51 --> 404 Page Not Found: Faviconico/index
INFO - 2021-07-10 10:30:54 --> Config Class Initialized
INFO - 2021-07-10 10:30:54 --> Hooks Class Initialized
DEBUG - 2021-07-10 10:30:54 --> UTF-8 Support Enabled
INFO - 2021-07-10 10:30:54 --> Utf8 Class Initialized
INFO - 2021-07-10 10:30:54 --> URI Class Initialized
INFO - 2021-07-10 10:30:54 --> Router Class Initialized
INFO - 2021-07-10 10:30:54 --> Output Class Initialized
INFO - 2021-07-10 10:30:54 --> Security Class Initialized
DEBUG - 2021-07-10 10:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 10:30:54 --> Input Class Initialized
INFO - 2021-07-10 10:30:54 --> Language Class Initialized
INFO - 2021-07-10 10:30:54 --> Loader Class Initialized
INFO - 2021-07-10 10:30:54 --> Helper loaded: basic_helper
INFO - 2021-07-10 10:30:54 --> Helper loaded: url_helper
INFO - 2021-07-10 10:30:54 --> Helper loaded: file_helper
INFO - 2021-07-10 10:30:54 --> Helper loaded: form_helper
INFO - 2021-07-10 10:30:54 --> Helper loaded: cookie_helper
INFO - 2021-07-10 10:30:54 --> Helper loaded: security_helper
INFO - 2021-07-10 10:30:54 --> Helper loaded: directory_helper
INFO - 2021-07-10 10:30:54 --> Helper loaded: language_helper
INFO - 2021-07-10 10:30:54 --> Helper loaded: general_helper
INFO - 2021-07-10 10:30:54 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-10 10:30:54 --> Database Driver Class Initialized
DEBUG - 2021-07-10 10:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-10 10:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-10 10:30:54 --> Parser Class Initialized
INFO - 2021-07-10 10:30:54 --> Form Validation Class Initialized
INFO - 2021-07-10 10:30:54 --> Upload Class Initialized
INFO - 2021-07-10 10:30:54 --> Email Class Initialized
INFO - 2021-07-10 10:30:54 --> MY_Model class loaded
INFO - 2021-07-10 10:30:54 --> Model "Users_model" initialized
INFO - 2021-07-10 10:30:54 --> Model "Settings_model" initialized
INFO - 2021-07-10 10:30:54 --> Model "Role_permissions_model" initialized
INFO - 2021-07-10 10:30:54 --> Model "Permissions_model" initialized
INFO - 2021-07-10 10:30:54 --> Model "Roles_model" initialized
INFO - 2021-07-10 10:30:54 --> Model "Activity_model" initialized
INFO - 2021-07-10 10:30:54 --> Model "Templates_model" initialized
INFO - 2021-07-10 10:30:54 --> Database Driver Class Initialized
INFO - 2021-07-10 10:30:54 --> Model "Hesaplar_model" initialized
INFO - 2021-07-10 10:30:54 --> Controller Class Initialized
DEBUG - 2021-07-10 10:30:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2021-07-10 10:30:54 --> Language file loaded: language/en/form_validation_lang.php
INFO - 2021-07-10 10:30:54 --> Config Class Initialized
INFO - 2021-07-10 10:30:54 --> Hooks Class Initialized
DEBUG - 2021-07-10 10:30:54 --> UTF-8 Support Enabled
INFO - 2021-07-10 10:30:54 --> Utf8 Class Initialized
INFO - 2021-07-10 10:30:54 --> URI Class Initialized
DEBUG - 2021-07-10 10:30:54 --> No URI present. Default controller set.
INFO - 2021-07-10 10:30:54 --> Router Class Initialized
INFO - 2021-07-10 10:30:54 --> Output Class Initialized
INFO - 2021-07-10 10:30:54 --> Security Class Initialized
DEBUG - 2021-07-10 10:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 10:30:54 --> Input Class Initialized
INFO - 2021-07-10 10:30:54 --> Language Class Initialized
INFO - 2021-07-10 10:30:54 --> Loader Class Initialized
INFO - 2021-07-10 10:30:54 --> Helper loaded: basic_helper
INFO - 2021-07-10 10:30:54 --> Helper loaded: url_helper
INFO - 2021-07-10 10:30:54 --> Helper loaded: file_helper
INFO - 2021-07-10 10:30:54 --> Helper loaded: form_helper
INFO - 2021-07-10 10:30:54 --> Helper loaded: cookie_helper
INFO - 2021-07-10 10:30:54 --> Helper loaded: security_helper
INFO - 2021-07-10 10:30:54 --> Helper loaded: directory_helper
INFO - 2021-07-10 10:30:54 --> Helper loaded: language_helper
INFO - 2021-07-10 10:30:54 --> Helper loaded: general_helper
INFO - 2021-07-10 10:30:54 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-10 10:30:54 --> Database Driver Class Initialized
DEBUG - 2021-07-10 10:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-10 10:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-10 10:30:54 --> Parser Class Initialized
INFO - 2021-07-10 10:30:54 --> Form Validation Class Initialized
INFO - 2021-07-10 10:30:54 --> Upload Class Initialized
INFO - 2021-07-10 10:30:54 --> Email Class Initialized
INFO - 2021-07-10 10:30:54 --> MY_Model class loaded
INFO - 2021-07-10 10:30:54 --> Model "Users_model" initialized
INFO - 2021-07-10 10:30:54 --> Model "Settings_model" initialized
INFO - 2021-07-10 10:30:54 --> Model "Role_permissions_model" initialized
INFO - 2021-07-10 10:30:54 --> Model "Permissions_model" initialized
INFO - 2021-07-10 10:30:54 --> Model "Roles_model" initialized
INFO - 2021-07-10 10:30:54 --> Model "Activity_model" initialized
INFO - 2021-07-10 10:30:54 --> Model "Templates_model" initialized
INFO - 2021-07-10 10:30:54 --> Database Driver Class Initialized
INFO - 2021-07-10 10:30:54 --> Model "Hesaplar_model" initialized
INFO - 2021-07-10 10:30:54 --> Controller Class Initialized
ERROR - 2021-07-10 10:30:54 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-10 10:30:54 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-10 10:30:54 --> Final output sent to browser
DEBUG - 2021-07-10 10:30:54 --> Total execution time: 0.0591
INFO - 2021-07-10 10:30:58 --> Config Class Initialized
INFO - 2021-07-10 10:30:58 --> Hooks Class Initialized
DEBUG - 2021-07-10 10:30:58 --> UTF-8 Support Enabled
INFO - 2021-07-10 10:30:58 --> Utf8 Class Initialized
INFO - 2021-07-10 10:30:58 --> URI Class Initialized
INFO - 2021-07-10 10:30:58 --> Router Class Initialized
INFO - 2021-07-10 10:30:58 --> Output Class Initialized
INFO - 2021-07-10 10:30:58 --> Security Class Initialized
DEBUG - 2021-07-10 10:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 10:30:58 --> Input Class Initialized
INFO - 2021-07-10 10:30:58 --> Language Class Initialized
INFO - 2021-07-10 10:30:58 --> Loader Class Initialized
INFO - 2021-07-10 10:30:58 --> Helper loaded: basic_helper
INFO - 2021-07-10 10:30:58 --> Helper loaded: url_helper
INFO - 2021-07-10 10:30:58 --> Helper loaded: file_helper
INFO - 2021-07-10 10:30:58 --> Helper loaded: form_helper
INFO - 2021-07-10 10:30:58 --> Helper loaded: cookie_helper
INFO - 2021-07-10 10:30:58 --> Helper loaded: security_helper
INFO - 2021-07-10 10:30:58 --> Helper loaded: directory_helper
INFO - 2021-07-10 10:30:58 --> Helper loaded: language_helper
INFO - 2021-07-10 10:30:58 --> Helper loaded: general_helper
INFO - 2021-07-10 10:30:58 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-10 10:30:58 --> Database Driver Class Initialized
DEBUG - 2021-07-10 10:30:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-10 10:30:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-10 10:30:58 --> Parser Class Initialized
INFO - 2021-07-10 10:30:58 --> Form Validation Class Initialized
INFO - 2021-07-10 10:30:58 --> Upload Class Initialized
INFO - 2021-07-10 10:30:58 --> Email Class Initialized
INFO - 2021-07-10 10:30:58 --> MY_Model class loaded
INFO - 2021-07-10 10:30:58 --> Model "Users_model" initialized
INFO - 2021-07-10 10:30:58 --> Model "Settings_model" initialized
INFO - 2021-07-10 10:30:58 --> Model "Role_permissions_model" initialized
INFO - 2021-07-10 10:30:58 --> Model "Permissions_model" initialized
INFO - 2021-07-10 10:30:58 --> Model "Roles_model" initialized
INFO - 2021-07-10 10:30:58 --> Model "Activity_model" initialized
INFO - 2021-07-10 10:30:58 --> Model "Templates_model" initialized
INFO - 2021-07-10 10:30:58 --> Database Driver Class Initialized
INFO - 2021-07-10 10:30:58 --> Model "Hesaplar_model" initialized
INFO - 2021-07-10 10:30:58 --> Controller Class Initialized
ERROR - 2021-07-10 10:30:58 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-10 10:30:58 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-10 10:30:58 --> Final output sent to browser
DEBUG - 2021-07-10 10:30:58 --> Total execution time: 0.1488
INFO - 2021-07-10 10:31:04 --> Config Class Initialized
INFO - 2021-07-10 10:31:04 --> Hooks Class Initialized
DEBUG - 2021-07-10 10:31:04 --> UTF-8 Support Enabled
INFO - 2021-07-10 10:31:04 --> Utf8 Class Initialized
INFO - 2021-07-10 10:31:04 --> URI Class Initialized
INFO - 2021-07-10 10:31:04 --> Router Class Initialized
INFO - 2021-07-10 10:31:04 --> Output Class Initialized
INFO - 2021-07-10 10:31:04 --> Security Class Initialized
DEBUG - 2021-07-10 10:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 10:31:04 --> Input Class Initialized
INFO - 2021-07-10 10:31:04 --> Language Class Initialized
INFO - 2021-07-10 10:31:04 --> Loader Class Initialized
INFO - 2021-07-10 10:31:04 --> Helper loaded: basic_helper
INFO - 2021-07-10 10:31:04 --> Helper loaded: url_helper
INFO - 2021-07-10 10:31:04 --> Helper loaded: file_helper
INFO - 2021-07-10 10:31:04 --> Helper loaded: form_helper
INFO - 2021-07-10 10:31:04 --> Helper loaded: cookie_helper
INFO - 2021-07-10 10:31:04 --> Helper loaded: security_helper
INFO - 2021-07-10 10:31:04 --> Helper loaded: directory_helper
INFO - 2021-07-10 10:31:04 --> Helper loaded: language_helper
INFO - 2021-07-10 10:31:04 --> Helper loaded: general_helper
INFO - 2021-07-10 10:31:04 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-10 10:31:04 --> Database Driver Class Initialized
DEBUG - 2021-07-10 10:31:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-10 10:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-10 10:31:04 --> Parser Class Initialized
INFO - 2021-07-10 10:31:04 --> Form Validation Class Initialized
INFO - 2021-07-10 10:31:04 --> Upload Class Initialized
INFO - 2021-07-10 10:31:04 --> Email Class Initialized
INFO - 2021-07-10 10:31:04 --> MY_Model class loaded
INFO - 2021-07-10 10:31:04 --> Model "Users_model" initialized
INFO - 2021-07-10 10:31:04 --> Model "Settings_model" initialized
INFO - 2021-07-10 10:31:04 --> Model "Role_permissions_model" initialized
INFO - 2021-07-10 10:31:04 --> Model "Permissions_model" initialized
INFO - 2021-07-10 10:31:04 --> Model "Roles_model" initialized
INFO - 2021-07-10 10:31:04 --> Model "Activity_model" initialized
INFO - 2021-07-10 10:31:04 --> Model "Templates_model" initialized
INFO - 2021-07-10 10:31:04 --> Database Driver Class Initialized
INFO - 2021-07-10 10:31:04 --> Model "Hesaplar_model" initialized
INFO - 2021-07-10 10:31:04 --> Controller Class Initialized
ERROR - 2021-07-10 10:31:04 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-10 10:31:04 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-10 10:31:04 --> Final output sent to browser
DEBUG - 2021-07-10 10:31:04 --> Total execution time: 0.2354
INFO - 2021-07-10 10:31:10 --> Config Class Initialized
INFO - 2021-07-10 10:31:10 --> Hooks Class Initialized
DEBUG - 2021-07-10 10:31:10 --> UTF-8 Support Enabled
INFO - 2021-07-10 10:31:10 --> Utf8 Class Initialized
INFO - 2021-07-10 10:31:10 --> URI Class Initialized
INFO - 2021-07-10 10:31:10 --> Router Class Initialized
INFO - 2021-07-10 10:31:10 --> Output Class Initialized
INFO - 2021-07-10 10:31:10 --> Security Class Initialized
DEBUG - 2021-07-10 10:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 10:31:10 --> Input Class Initialized
INFO - 2021-07-10 10:31:10 --> Language Class Initialized
INFO - 2021-07-10 10:31:10 --> Loader Class Initialized
INFO - 2021-07-10 10:31:10 --> Helper loaded: basic_helper
INFO - 2021-07-10 10:31:10 --> Helper loaded: url_helper
INFO - 2021-07-10 10:31:10 --> Helper loaded: file_helper
INFO - 2021-07-10 10:31:10 --> Helper loaded: form_helper
INFO - 2021-07-10 10:31:10 --> Helper loaded: cookie_helper
INFO - 2021-07-10 10:31:10 --> Helper loaded: security_helper
INFO - 2021-07-10 10:31:10 --> Helper loaded: directory_helper
INFO - 2021-07-10 10:31:10 --> Helper loaded: language_helper
INFO - 2021-07-10 10:31:10 --> Helper loaded: general_helper
INFO - 2021-07-10 10:31:10 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-10 10:31:10 --> Database Driver Class Initialized
DEBUG - 2021-07-10 10:31:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-10 10:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-10 10:31:10 --> Parser Class Initialized
INFO - 2021-07-10 10:31:10 --> Form Validation Class Initialized
INFO - 2021-07-10 10:31:10 --> Upload Class Initialized
INFO - 2021-07-10 10:31:10 --> Email Class Initialized
INFO - 2021-07-10 10:31:10 --> MY_Model class loaded
INFO - 2021-07-10 10:31:10 --> Model "Users_model" initialized
INFO - 2021-07-10 10:31:10 --> Model "Settings_model" initialized
INFO - 2021-07-10 10:31:10 --> Model "Role_permissions_model" initialized
INFO - 2021-07-10 10:31:10 --> Model "Permissions_model" initialized
INFO - 2021-07-10 10:31:10 --> Model "Roles_model" initialized
INFO - 2021-07-10 10:31:10 --> Model "Activity_model" initialized
INFO - 2021-07-10 10:31:10 --> Model "Templates_model" initialized
INFO - 2021-07-10 10:31:10 --> Database Driver Class Initialized
INFO - 2021-07-10 10:31:11 --> Model "Hesaplar_model" initialized
INFO - 2021-07-10 10:31:11 --> Controller Class Initialized
ERROR - 2021-07-10 10:31:11 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-10 10:31:11 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-10 10:31:11 --> Final output sent to browser
DEBUG - 2021-07-10 10:31:11 --> Total execution time: 0.1404
INFO - 2021-07-10 10:31:45 --> Config Class Initialized
INFO - 2021-07-10 10:31:45 --> Hooks Class Initialized
DEBUG - 2021-07-10 10:31:45 --> UTF-8 Support Enabled
INFO - 2021-07-10 10:31:45 --> Utf8 Class Initialized
INFO - 2021-07-10 10:31:45 --> URI Class Initialized
INFO - 2021-07-10 10:31:45 --> Router Class Initialized
INFO - 2021-07-10 10:31:45 --> Output Class Initialized
INFO - 2021-07-10 10:31:45 --> Security Class Initialized
DEBUG - 2021-07-10 10:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 10:31:45 --> Input Class Initialized
INFO - 2021-07-10 10:31:45 --> Language Class Initialized
INFO - 2021-07-10 10:31:45 --> Loader Class Initialized
INFO - 2021-07-10 10:31:45 --> Helper loaded: basic_helper
INFO - 2021-07-10 10:31:45 --> Helper loaded: url_helper
INFO - 2021-07-10 10:31:45 --> Helper loaded: file_helper
INFO - 2021-07-10 10:31:45 --> Helper loaded: form_helper
INFO - 2021-07-10 10:31:45 --> Helper loaded: cookie_helper
INFO - 2021-07-10 10:31:45 --> Helper loaded: security_helper
INFO - 2021-07-10 10:31:45 --> Helper loaded: directory_helper
INFO - 2021-07-10 10:31:45 --> Helper loaded: language_helper
INFO - 2021-07-10 10:31:45 --> Helper loaded: general_helper
INFO - 2021-07-10 10:31:45 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-10 10:31:45 --> Database Driver Class Initialized
DEBUG - 2021-07-10 10:31:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-10 10:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-10 10:31:45 --> Parser Class Initialized
INFO - 2021-07-10 10:31:45 --> Form Validation Class Initialized
INFO - 2021-07-10 10:31:45 --> Upload Class Initialized
INFO - 2021-07-10 10:31:45 --> Email Class Initialized
INFO - 2021-07-10 10:31:45 --> MY_Model class loaded
INFO - 2021-07-10 10:31:45 --> Model "Users_model" initialized
INFO - 2021-07-10 10:31:45 --> Model "Settings_model" initialized
INFO - 2021-07-10 10:31:45 --> Model "Role_permissions_model" initialized
INFO - 2021-07-10 10:31:45 --> Model "Permissions_model" initialized
INFO - 2021-07-10 10:31:45 --> Model "Roles_model" initialized
INFO - 2021-07-10 10:31:45 --> Model "Activity_model" initialized
INFO - 2021-07-10 10:31:45 --> Model "Templates_model" initialized
INFO - 2021-07-10 10:31:45 --> Database Driver Class Initialized
INFO - 2021-07-10 10:31:45 --> Model "Hesaplar_model" initialized
INFO - 2021-07-10 10:31:45 --> Controller Class Initialized
ERROR - 2021-07-10 10:31:45 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-10 10:31:45 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-10 10:31:45 --> Final output sent to browser
DEBUG - 2021-07-10 10:31:45 --> Total execution time: 0.1301
INFO - 2021-07-10 10:41:19 --> Config Class Initialized
INFO - 2021-07-10 10:41:19 --> Hooks Class Initialized
DEBUG - 2021-07-10 10:41:19 --> UTF-8 Support Enabled
INFO - 2021-07-10 10:41:19 --> Utf8 Class Initialized
INFO - 2021-07-10 10:41:19 --> URI Class Initialized
DEBUG - 2021-07-10 10:41:19 --> No URI present. Default controller set.
INFO - 2021-07-10 10:41:19 --> Router Class Initialized
INFO - 2021-07-10 10:41:19 --> Output Class Initialized
INFO - 2021-07-10 10:41:19 --> Security Class Initialized
DEBUG - 2021-07-10 10:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 10:41:19 --> Input Class Initialized
INFO - 2021-07-10 10:41:19 --> Language Class Initialized
INFO - 2021-07-10 10:41:19 --> Loader Class Initialized
INFO - 2021-07-10 10:41:19 --> Helper loaded: basic_helper
INFO - 2021-07-10 10:41:19 --> Helper loaded: url_helper
INFO - 2021-07-10 10:41:19 --> Helper loaded: file_helper
INFO - 2021-07-10 10:41:19 --> Helper loaded: form_helper
INFO - 2021-07-10 10:41:19 --> Helper loaded: cookie_helper
INFO - 2021-07-10 10:41:19 --> Helper loaded: security_helper
INFO - 2021-07-10 10:41:19 --> Helper loaded: directory_helper
INFO - 2021-07-10 10:41:19 --> Helper loaded: language_helper
INFO - 2021-07-10 10:41:19 --> Helper loaded: general_helper
INFO - 2021-07-10 10:41:19 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-10 10:41:19 --> Database Driver Class Initialized
DEBUG - 2021-07-10 10:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-10 10:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-10 10:41:19 --> Parser Class Initialized
INFO - 2021-07-10 10:41:19 --> Form Validation Class Initialized
INFO - 2021-07-10 10:41:19 --> Upload Class Initialized
INFO - 2021-07-10 10:41:19 --> Email Class Initialized
INFO - 2021-07-10 10:41:19 --> MY_Model class loaded
INFO - 2021-07-10 10:41:19 --> Model "Users_model" initialized
INFO - 2021-07-10 10:41:19 --> Model "Settings_model" initialized
INFO - 2021-07-10 10:41:19 --> Model "Role_permissions_model" initialized
INFO - 2021-07-10 10:41:19 --> Model "Permissions_model" initialized
INFO - 2021-07-10 10:41:19 --> Model "Roles_model" initialized
INFO - 2021-07-10 10:41:19 --> Model "Activity_model" initialized
INFO - 2021-07-10 10:41:19 --> Model "Templates_model" initialized
INFO - 2021-07-10 10:41:19 --> Database Driver Class Initialized
INFO - 2021-07-10 10:41:19 --> Model "Hesaplar_model" initialized
INFO - 2021-07-10 10:41:19 --> Controller Class Initialized
INFO - 2021-07-10 10:41:37 --> Config Class Initialized
INFO - 2021-07-10 10:41:37 --> Hooks Class Initialized
DEBUG - 2021-07-10 10:41:37 --> UTF-8 Support Enabled
INFO - 2021-07-10 10:41:37 --> Utf8 Class Initialized
INFO - 2021-07-10 10:41:37 --> URI Class Initialized
INFO - 2021-07-10 10:41:37 --> Router Class Initialized
INFO - 2021-07-10 10:41:37 --> Output Class Initialized
INFO - 2021-07-10 10:41:37 --> Security Class Initialized
DEBUG - 2021-07-10 10:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 10:41:37 --> Input Class Initialized
INFO - 2021-07-10 10:41:37 --> Language Class Initialized
ERROR - 2021-07-10 10:41:37 --> 404 Page Not Found: DevMgmt/DiscoveryTree.xml
INFO - 2021-07-10 10:41:39 --> Config Class Initialized
INFO - 2021-07-10 10:41:39 --> Hooks Class Initialized
DEBUG - 2021-07-10 10:41:39 --> UTF-8 Support Enabled
INFO - 2021-07-10 10:41:39 --> Utf8 Class Initialized
INFO - 2021-07-10 10:41:39 --> URI Class Initialized
INFO - 2021-07-10 10:41:39 --> Router Class Initialized
INFO - 2021-07-10 10:41:39 --> Output Class Initialized
INFO - 2021-07-10 10:41:39 --> Security Class Initialized
DEBUG - 2021-07-10 10:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 10:41:39 --> Input Class Initialized
INFO - 2021-07-10 10:41:39 --> Language Class Initialized
ERROR - 2021-07-10 10:41:39 --> 404 Page Not Found: DevMgmt/DiscoveryTree.xml
INFO - 2021-07-10 10:42:07 --> Config Class Initialized
INFO - 2021-07-10 10:42:07 --> Hooks Class Initialized
DEBUG - 2021-07-10 10:42:07 --> UTF-8 Support Enabled
INFO - 2021-07-10 10:42:07 --> Utf8 Class Initialized
INFO - 2021-07-10 10:42:07 --> URI Class Initialized
INFO - 2021-07-10 10:42:07 --> Router Class Initialized
INFO - 2021-07-10 10:42:07 --> Output Class Initialized
INFO - 2021-07-10 10:42:07 --> Security Class Initialized
DEBUG - 2021-07-10 10:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 10:42:07 --> Input Class Initialized
INFO - 2021-07-10 10:42:07 --> Language Class Initialized
INFO - 2021-07-10 10:42:07 --> Loader Class Initialized
INFO - 2021-07-10 10:42:07 --> Helper loaded: basic_helper
INFO - 2021-07-10 10:42:07 --> Helper loaded: url_helper
INFO - 2021-07-10 10:42:07 --> Helper loaded: file_helper
INFO - 2021-07-10 10:42:07 --> Helper loaded: form_helper
INFO - 2021-07-10 10:42:07 --> Helper loaded: cookie_helper
INFO - 2021-07-10 10:42:07 --> Helper loaded: security_helper
INFO - 2021-07-10 10:42:07 --> Helper loaded: directory_helper
INFO - 2021-07-10 10:42:07 --> Helper loaded: language_helper
INFO - 2021-07-10 10:42:07 --> Helper loaded: general_helper
INFO - 2021-07-10 10:42:07 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-10 10:42:07 --> Database Driver Class Initialized
DEBUG - 2021-07-10 10:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-10 10:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-10 10:42:07 --> Parser Class Initialized
INFO - 2021-07-10 10:42:07 --> Form Validation Class Initialized
INFO - 2021-07-10 10:42:07 --> Upload Class Initialized
INFO - 2021-07-10 10:42:07 --> Email Class Initialized
INFO - 2021-07-10 10:42:07 --> MY_Model class loaded
INFO - 2021-07-10 10:42:07 --> Model "Users_model" initialized
INFO - 2021-07-10 10:42:07 --> Model "Settings_model" initialized
INFO - 2021-07-10 10:42:07 --> Model "Role_permissions_model" initialized
INFO - 2021-07-10 10:42:07 --> Model "Permissions_model" initialized
INFO - 2021-07-10 10:42:07 --> Model "Roles_model" initialized
INFO - 2021-07-10 10:42:07 --> Model "Activity_model" initialized
INFO - 2021-07-10 10:42:07 --> Model "Templates_model" initialized
INFO - 2021-07-10 10:42:07 --> Database Driver Class Initialized
INFO - 2021-07-10 10:42:07 --> Model "Hesaplar_model" initialized
INFO - 2021-07-10 10:42:07 --> Controller Class Initialized
ERROR - 2021-07-10 10:42:07 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-10 10:42:07 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-10 10:42:07 --> Final output sent to browser
DEBUG - 2021-07-10 10:42:07 --> Total execution time: 0.1212
INFO - 2021-07-10 10:42:12 --> Config Class Initialized
INFO - 2021-07-10 10:42:12 --> Hooks Class Initialized
DEBUG - 2021-07-10 10:42:12 --> UTF-8 Support Enabled
INFO - 2021-07-10 10:42:12 --> Utf8 Class Initialized
INFO - 2021-07-10 10:42:12 --> URI Class Initialized
INFO - 2021-07-10 10:42:12 --> Router Class Initialized
INFO - 2021-07-10 10:42:12 --> Output Class Initialized
INFO - 2021-07-10 10:42:12 --> Security Class Initialized
DEBUG - 2021-07-10 10:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 10:42:12 --> Input Class Initialized
INFO - 2021-07-10 10:42:12 --> Language Class Initialized
INFO - 2021-07-10 10:42:12 --> Loader Class Initialized
INFO - 2021-07-10 10:42:12 --> Helper loaded: basic_helper
INFO - 2021-07-10 10:42:12 --> Helper loaded: url_helper
INFO - 2021-07-10 10:42:12 --> Helper loaded: file_helper
INFO - 2021-07-10 10:42:12 --> Helper loaded: form_helper
INFO - 2021-07-10 10:42:12 --> Helper loaded: cookie_helper
INFO - 2021-07-10 10:42:12 --> Helper loaded: security_helper
INFO - 2021-07-10 10:42:12 --> Helper loaded: directory_helper
INFO - 2021-07-10 10:42:12 --> Helper loaded: language_helper
INFO - 2021-07-10 10:42:12 --> Helper loaded: general_helper
INFO - 2021-07-10 10:42:12 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-10 10:42:12 --> Database Driver Class Initialized
DEBUG - 2021-07-10 10:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-10 10:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-10 10:42:12 --> Parser Class Initialized
INFO - 2021-07-10 10:42:12 --> Form Validation Class Initialized
INFO - 2021-07-10 10:42:12 --> Upload Class Initialized
INFO - 2021-07-10 10:42:12 --> Email Class Initialized
INFO - 2021-07-10 10:42:12 --> MY_Model class loaded
INFO - 2021-07-10 10:42:12 --> Model "Users_model" initialized
INFO - 2021-07-10 10:42:12 --> Model "Settings_model" initialized
INFO - 2021-07-10 10:42:12 --> Model "Role_permissions_model" initialized
INFO - 2021-07-10 10:42:12 --> Model "Permissions_model" initialized
INFO - 2021-07-10 10:42:12 --> Model "Roles_model" initialized
INFO - 2021-07-10 10:42:12 --> Model "Activity_model" initialized
INFO - 2021-07-10 10:42:12 --> Model "Templates_model" initialized
INFO - 2021-07-10 10:42:12 --> Database Driver Class Initialized
INFO - 2021-07-10 10:42:12 --> Model "Hesaplar_model" initialized
INFO - 2021-07-10 10:42:12 --> Controller Class Initialized
ERROR - 2021-07-10 10:42:12 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-10 10:42:12 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-10 10:42:12 --> Final output sent to browser
DEBUG - 2021-07-10 10:42:12 --> Total execution time: 0.1643
INFO - 2021-07-10 10:42:30 --> Config Class Initialized
INFO - 2021-07-10 10:42:30 --> Hooks Class Initialized
DEBUG - 2021-07-10 10:42:30 --> UTF-8 Support Enabled
INFO - 2021-07-10 10:42:30 --> Utf8 Class Initialized
INFO - 2021-07-10 10:42:30 --> URI Class Initialized
INFO - 2021-07-10 10:42:30 --> Router Class Initialized
INFO - 2021-07-10 10:42:30 --> Output Class Initialized
INFO - 2021-07-10 10:42:30 --> Security Class Initialized
DEBUG - 2021-07-10 10:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 10:42:30 --> Input Class Initialized
INFO - 2021-07-10 10:42:30 --> Language Class Initialized
INFO - 2021-07-10 10:42:30 --> Loader Class Initialized
INFO - 2021-07-10 10:42:30 --> Helper loaded: basic_helper
INFO - 2021-07-10 10:42:30 --> Helper loaded: url_helper
INFO - 2021-07-10 10:42:30 --> Helper loaded: file_helper
INFO - 2021-07-10 10:42:30 --> Helper loaded: form_helper
INFO - 2021-07-10 10:42:30 --> Helper loaded: cookie_helper
INFO - 2021-07-10 10:42:30 --> Helper loaded: security_helper
INFO - 2021-07-10 10:42:30 --> Helper loaded: directory_helper
INFO - 2021-07-10 10:42:30 --> Helper loaded: language_helper
INFO - 2021-07-10 10:42:30 --> Helper loaded: general_helper
INFO - 2021-07-10 10:42:30 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-10 10:42:30 --> Database Driver Class Initialized
DEBUG - 2021-07-10 10:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-10 10:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-10 10:42:30 --> Parser Class Initialized
INFO - 2021-07-10 10:42:30 --> Form Validation Class Initialized
INFO - 2021-07-10 10:42:30 --> Upload Class Initialized
INFO - 2021-07-10 10:42:30 --> Email Class Initialized
INFO - 2021-07-10 10:42:30 --> MY_Model class loaded
INFO - 2021-07-10 10:42:30 --> Model "Users_model" initialized
INFO - 2021-07-10 10:42:30 --> Model "Settings_model" initialized
INFO - 2021-07-10 10:42:30 --> Model "Role_permissions_model" initialized
INFO - 2021-07-10 10:42:30 --> Model "Permissions_model" initialized
INFO - 2021-07-10 10:42:30 --> Model "Roles_model" initialized
INFO - 2021-07-10 10:42:30 --> Model "Activity_model" initialized
INFO - 2021-07-10 10:42:30 --> Model "Templates_model" initialized
INFO - 2021-07-10 10:42:30 --> Database Driver Class Initialized
INFO - 2021-07-10 10:42:30 --> Model "Hesaplar_model" initialized
INFO - 2021-07-10 10:42:30 --> Controller Class Initialized
ERROR - 2021-07-10 10:42:30 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-10 10:42:30 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-10 10:42:30 --> Final output sent to browser
DEBUG - 2021-07-10 10:42:30 --> Total execution time: 0.1337
INFO - 2021-07-10 10:42:50 --> Config Class Initialized
INFO - 2021-07-10 10:42:50 --> Hooks Class Initialized
DEBUG - 2021-07-10 10:42:50 --> UTF-8 Support Enabled
INFO - 2021-07-10 10:42:50 --> Utf8 Class Initialized
INFO - 2021-07-10 10:42:50 --> URI Class Initialized
INFO - 2021-07-10 10:42:50 --> Router Class Initialized
INFO - 2021-07-10 10:42:50 --> Output Class Initialized
INFO - 2021-07-10 10:42:50 --> Security Class Initialized
DEBUG - 2021-07-10 10:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 10:42:50 --> Input Class Initialized
INFO - 2021-07-10 10:42:50 --> Language Class Initialized
ERROR - 2021-07-10 10:42:50 --> 404 Page Not Found: DevMgmt/DiscoveryTree.xml
INFO - 2021-07-10 10:44:43 --> Config Class Initialized
INFO - 2021-07-10 10:44:43 --> Hooks Class Initialized
DEBUG - 2021-07-10 10:44:43 --> UTF-8 Support Enabled
INFO - 2021-07-10 10:44:43 --> Utf8 Class Initialized
INFO - 2021-07-10 10:44:43 --> URI Class Initialized
INFO - 2021-07-10 10:44:43 --> Router Class Initialized
INFO - 2021-07-10 10:44:43 --> Output Class Initialized
INFO - 2021-07-10 10:44:43 --> Security Class Initialized
DEBUG - 2021-07-10 10:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 10:44:43 --> Input Class Initialized
INFO - 2021-07-10 10:44:43 --> Language Class Initialized
ERROR - 2021-07-10 10:44:43 --> 404 Page Not Found: DevMgmt/DiscoveryTree.xml
INFO - 2021-07-10 10:57:08 --> Config Class Initialized
INFO - 2021-07-10 10:57:08 --> Hooks Class Initialized
DEBUG - 2021-07-10 10:57:08 --> UTF-8 Support Enabled
INFO - 2021-07-10 10:57:08 --> Utf8 Class Initialized
INFO - 2021-07-10 10:57:08 --> URI Class Initialized
INFO - 2021-07-10 10:57:08 --> Router Class Initialized
INFO - 2021-07-10 10:57:08 --> Output Class Initialized
INFO - 2021-07-10 10:57:08 --> Security Class Initialized
DEBUG - 2021-07-10 10:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 10:57:08 --> Input Class Initialized
INFO - 2021-07-10 10:57:08 --> Language Class Initialized
INFO - 2021-07-10 10:57:08 --> Loader Class Initialized
INFO - 2021-07-10 10:57:08 --> Helper loaded: basic_helper
INFO - 2021-07-10 10:57:08 --> Helper loaded: url_helper
INFO - 2021-07-10 10:57:08 --> Helper loaded: file_helper
INFO - 2021-07-10 10:57:08 --> Helper loaded: form_helper
INFO - 2021-07-10 10:57:08 --> Helper loaded: cookie_helper
INFO - 2021-07-10 10:57:08 --> Helper loaded: security_helper
INFO - 2021-07-10 10:57:08 --> Helper loaded: directory_helper
INFO - 2021-07-10 10:57:08 --> Helper loaded: language_helper
INFO - 2021-07-10 10:57:08 --> Helper loaded: general_helper
INFO - 2021-07-10 10:57:08 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-10 10:57:08 --> Database Driver Class Initialized
DEBUG - 2021-07-10 10:57:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-10 10:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-10 10:57:08 --> Parser Class Initialized
INFO - 2021-07-10 10:57:08 --> Form Validation Class Initialized
INFO - 2021-07-10 10:57:08 --> Upload Class Initialized
INFO - 2021-07-10 10:57:08 --> Email Class Initialized
INFO - 2021-07-10 10:57:08 --> MY_Model class loaded
INFO - 2021-07-10 10:57:08 --> Model "Users_model" initialized
INFO - 2021-07-10 10:57:08 --> Model "Settings_model" initialized
INFO - 2021-07-10 10:57:08 --> Model "Role_permissions_model" initialized
INFO - 2021-07-10 10:57:08 --> Model "Permissions_model" initialized
INFO - 2021-07-10 10:57:08 --> Model "Roles_model" initialized
INFO - 2021-07-10 10:57:08 --> Model "Activity_model" initialized
INFO - 2021-07-10 10:57:08 --> Model "Templates_model" initialized
INFO - 2021-07-10 10:57:08 --> Database Driver Class Initialized
INFO - 2021-07-10 10:57:08 --> Model "Hesaplar_model" initialized
INFO - 2021-07-10 10:57:08 --> Controller Class Initialized
ERROR - 2021-07-10 10:57:08 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-10 10:57:08 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-10 10:57:08 --> Final output sent to browser
DEBUG - 2021-07-10 10:57:08 --> Total execution time: 0.1288
INFO - 2021-07-10 10:57:12 --> Config Class Initialized
INFO - 2021-07-10 10:57:12 --> Hooks Class Initialized
DEBUG - 2021-07-10 10:57:12 --> UTF-8 Support Enabled
INFO - 2021-07-10 10:57:12 --> Utf8 Class Initialized
INFO - 2021-07-10 10:57:12 --> URI Class Initialized
INFO - 2021-07-10 10:57:12 --> Router Class Initialized
INFO - 2021-07-10 10:57:12 --> Output Class Initialized
INFO - 2021-07-10 10:57:12 --> Security Class Initialized
DEBUG - 2021-07-10 10:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 10:57:12 --> Input Class Initialized
INFO - 2021-07-10 10:57:12 --> Language Class Initialized
INFO - 2021-07-10 10:57:12 --> Loader Class Initialized
INFO - 2021-07-10 10:57:12 --> Helper loaded: basic_helper
INFO - 2021-07-10 10:57:12 --> Helper loaded: url_helper
INFO - 2021-07-10 10:57:12 --> Helper loaded: file_helper
INFO - 2021-07-10 10:57:12 --> Helper loaded: form_helper
INFO - 2021-07-10 10:57:12 --> Helper loaded: cookie_helper
INFO - 2021-07-10 10:57:12 --> Helper loaded: security_helper
INFO - 2021-07-10 10:57:12 --> Helper loaded: directory_helper
INFO - 2021-07-10 10:57:12 --> Helper loaded: language_helper
INFO - 2021-07-10 10:57:12 --> Helper loaded: general_helper
INFO - 2021-07-10 10:57:12 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-10 10:57:12 --> Database Driver Class Initialized
DEBUG - 2021-07-10 10:57:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-10 10:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-10 10:57:12 --> Parser Class Initialized
INFO - 2021-07-10 10:57:12 --> Form Validation Class Initialized
INFO - 2021-07-10 10:57:12 --> Upload Class Initialized
INFO - 2021-07-10 10:57:12 --> Email Class Initialized
INFO - 2021-07-10 10:57:12 --> MY_Model class loaded
INFO - 2021-07-10 10:57:12 --> Model "Users_model" initialized
INFO - 2021-07-10 10:57:12 --> Model "Settings_model" initialized
INFO - 2021-07-10 10:57:12 --> Model "Role_permissions_model" initialized
INFO - 2021-07-10 10:57:12 --> Model "Permissions_model" initialized
INFO - 2021-07-10 10:57:12 --> Model "Roles_model" initialized
INFO - 2021-07-10 10:57:12 --> Model "Activity_model" initialized
INFO - 2021-07-10 10:57:12 --> Model "Templates_model" initialized
INFO - 2021-07-10 10:57:12 --> Database Driver Class Initialized
INFO - 2021-07-10 10:57:12 --> Model "Hesaplar_model" initialized
INFO - 2021-07-10 10:57:12 --> Controller Class Initialized
ERROR - 2021-07-10 10:57:12 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-10 10:57:13 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-10 10:57:13 --> Final output sent to browser
DEBUG - 2021-07-10 10:57:13 --> Total execution time: 0.1373
INFO - 2021-07-10 10:57:33 --> Config Class Initialized
INFO - 2021-07-10 10:57:33 --> Hooks Class Initialized
DEBUG - 2021-07-10 10:57:33 --> UTF-8 Support Enabled
INFO - 2021-07-10 10:57:33 --> Utf8 Class Initialized
INFO - 2021-07-10 10:57:33 --> URI Class Initialized
INFO - 2021-07-10 10:57:33 --> Router Class Initialized
INFO - 2021-07-10 10:57:33 --> Output Class Initialized
INFO - 2021-07-10 10:57:33 --> Security Class Initialized
DEBUG - 2021-07-10 10:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 10:57:33 --> Input Class Initialized
INFO - 2021-07-10 10:57:33 --> Language Class Initialized
INFO - 2021-07-10 10:57:33 --> Loader Class Initialized
INFO - 2021-07-10 10:57:33 --> Helper loaded: basic_helper
INFO - 2021-07-10 10:57:33 --> Helper loaded: url_helper
INFO - 2021-07-10 10:57:33 --> Helper loaded: file_helper
INFO - 2021-07-10 10:57:33 --> Helper loaded: form_helper
INFO - 2021-07-10 10:57:33 --> Helper loaded: cookie_helper
INFO - 2021-07-10 10:57:33 --> Helper loaded: security_helper
INFO - 2021-07-10 10:57:33 --> Helper loaded: directory_helper
INFO - 2021-07-10 10:57:33 --> Helper loaded: language_helper
INFO - 2021-07-10 10:57:33 --> Helper loaded: general_helper
INFO - 2021-07-10 10:57:33 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-10 10:57:33 --> Database Driver Class Initialized
DEBUG - 2021-07-10 10:57:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-10 10:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-10 10:57:33 --> Parser Class Initialized
INFO - 2021-07-10 10:57:33 --> Form Validation Class Initialized
INFO - 2021-07-10 10:57:33 --> Upload Class Initialized
INFO - 2021-07-10 10:57:33 --> Email Class Initialized
INFO - 2021-07-10 10:57:33 --> MY_Model class loaded
INFO - 2021-07-10 10:57:33 --> Model "Users_model" initialized
INFO - 2021-07-10 10:57:33 --> Model "Settings_model" initialized
INFO - 2021-07-10 10:57:33 --> Model "Role_permissions_model" initialized
INFO - 2021-07-10 10:57:33 --> Model "Permissions_model" initialized
INFO - 2021-07-10 10:57:33 --> Model "Roles_model" initialized
INFO - 2021-07-10 10:57:33 --> Model "Activity_model" initialized
INFO - 2021-07-10 10:57:33 --> Model "Templates_model" initialized
INFO - 2021-07-10 10:57:33 --> Database Driver Class Initialized
INFO - 2021-07-10 10:57:33 --> Model "Hesaplar_model" initialized
INFO - 2021-07-10 10:57:33 --> Controller Class Initialized
ERROR - 2021-07-10 10:57:33 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-10 10:57:33 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-10 10:57:33 --> Final output sent to browser
DEBUG - 2021-07-10 10:57:33 --> Total execution time: 0.1601
INFO - 2021-07-10 10:57:35 --> Config Class Initialized
INFO - 2021-07-10 10:57:35 --> Hooks Class Initialized
DEBUG - 2021-07-10 10:57:35 --> UTF-8 Support Enabled
INFO - 2021-07-10 10:57:35 --> Utf8 Class Initialized
INFO - 2021-07-10 10:57:35 --> URI Class Initialized
INFO - 2021-07-10 10:57:35 --> Router Class Initialized
INFO - 2021-07-10 10:57:35 --> Output Class Initialized
INFO - 2021-07-10 10:57:35 --> Security Class Initialized
DEBUG - 2021-07-10 10:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 10:57:35 --> Input Class Initialized
INFO - 2021-07-10 10:57:35 --> Language Class Initialized
INFO - 2021-07-10 10:57:35 --> Loader Class Initialized
INFO - 2021-07-10 10:57:35 --> Helper loaded: basic_helper
INFO - 2021-07-10 10:57:35 --> Helper loaded: url_helper
INFO - 2021-07-10 10:57:35 --> Helper loaded: file_helper
INFO - 2021-07-10 10:57:35 --> Helper loaded: form_helper
INFO - 2021-07-10 10:57:35 --> Helper loaded: cookie_helper
INFO - 2021-07-10 10:57:35 --> Helper loaded: security_helper
INFO - 2021-07-10 10:57:35 --> Helper loaded: directory_helper
INFO - 2021-07-10 10:57:35 --> Helper loaded: language_helper
INFO - 2021-07-10 10:57:35 --> Helper loaded: general_helper
INFO - 2021-07-10 10:57:35 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-10 10:57:35 --> Database Driver Class Initialized
DEBUG - 2021-07-10 10:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-10 10:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-10 10:57:35 --> Parser Class Initialized
INFO - 2021-07-10 10:57:35 --> Form Validation Class Initialized
INFO - 2021-07-10 10:57:35 --> Upload Class Initialized
INFO - 2021-07-10 10:57:35 --> Email Class Initialized
INFO - 2021-07-10 10:57:35 --> MY_Model class loaded
INFO - 2021-07-10 10:57:35 --> Model "Users_model" initialized
INFO - 2021-07-10 10:57:35 --> Model "Settings_model" initialized
INFO - 2021-07-10 10:57:35 --> Model "Role_permissions_model" initialized
INFO - 2021-07-10 10:57:35 --> Model "Permissions_model" initialized
INFO - 2021-07-10 10:57:35 --> Model "Roles_model" initialized
INFO - 2021-07-10 10:57:35 --> Model "Activity_model" initialized
INFO - 2021-07-10 10:57:35 --> Model "Templates_model" initialized
INFO - 2021-07-10 10:57:35 --> Database Driver Class Initialized
INFO - 2021-07-10 10:57:35 --> Model "Hesaplar_model" initialized
INFO - 2021-07-10 10:57:35 --> Controller Class Initialized
ERROR - 2021-07-10 10:57:35 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-10 10:57:35 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-10 10:57:35 --> Final output sent to browser
DEBUG - 2021-07-10 10:57:35 --> Total execution time: 0.0645
INFO - 2021-07-10 11:20:36 --> Config Class Initialized
INFO - 2021-07-10 11:20:36 --> Hooks Class Initialized
DEBUG - 2021-07-10 11:20:36 --> UTF-8 Support Enabled
INFO - 2021-07-10 11:20:36 --> Utf8 Class Initialized
INFO - 2021-07-10 11:20:36 --> URI Class Initialized
INFO - 2021-07-10 11:20:36 --> Router Class Initialized
INFO - 2021-07-10 11:20:36 --> Output Class Initialized
INFO - 2021-07-10 11:20:36 --> Security Class Initialized
DEBUG - 2021-07-10 11:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 11:20:36 --> Input Class Initialized
INFO - 2021-07-10 11:20:36 --> Language Class Initialized
ERROR - 2021-07-10 11:20:36 --> 404 Page Not Found: DevMgmt/DiscoveryTree.xml
INFO - 2021-07-10 11:21:14 --> Config Class Initialized
INFO - 2021-07-10 11:21:14 --> Hooks Class Initialized
DEBUG - 2021-07-10 11:21:14 --> UTF-8 Support Enabled
INFO - 2021-07-10 11:21:14 --> Utf8 Class Initialized
INFO - 2021-07-10 11:21:14 --> URI Class Initialized
INFO - 2021-07-10 11:21:14 --> Router Class Initialized
INFO - 2021-07-10 11:21:14 --> Output Class Initialized
INFO - 2021-07-10 11:21:14 --> Security Class Initialized
DEBUG - 2021-07-10 11:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 11:21:14 --> Input Class Initialized
INFO - 2021-07-10 11:21:14 --> Language Class Initialized
ERROR - 2021-07-10 11:21:14 --> 404 Page Not Found: DevMgmt/DiscoveryTree.xml
INFO - 2021-07-10 11:29:06 --> Config Class Initialized
INFO - 2021-07-10 11:29:06 --> Hooks Class Initialized
DEBUG - 2021-07-10 11:29:06 --> UTF-8 Support Enabled
INFO - 2021-07-10 11:29:06 --> Utf8 Class Initialized
INFO - 2021-07-10 11:29:06 --> URI Class Initialized
DEBUG - 2021-07-10 11:29:06 --> No URI present. Default controller set.
INFO - 2021-07-10 11:29:06 --> Router Class Initialized
INFO - 2021-07-10 11:29:06 --> Output Class Initialized
INFO - 2021-07-10 11:29:06 --> Security Class Initialized
DEBUG - 2021-07-10 11:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 11:29:06 --> Input Class Initialized
INFO - 2021-07-10 11:29:06 --> Language Class Initialized
INFO - 2021-07-10 11:29:06 --> Loader Class Initialized
INFO - 2021-07-10 11:29:06 --> Helper loaded: basic_helper
INFO - 2021-07-10 11:29:06 --> Helper loaded: url_helper
INFO - 2021-07-10 11:29:06 --> Helper loaded: file_helper
INFO - 2021-07-10 11:29:06 --> Helper loaded: form_helper
INFO - 2021-07-10 11:29:06 --> Helper loaded: cookie_helper
INFO - 2021-07-10 11:29:06 --> Helper loaded: security_helper
INFO - 2021-07-10 11:29:06 --> Helper loaded: directory_helper
INFO - 2021-07-10 11:29:06 --> Helper loaded: language_helper
INFO - 2021-07-10 11:29:06 --> Helper loaded: general_helper
INFO - 2021-07-10 11:29:06 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-10 11:29:06 --> Database Driver Class Initialized
DEBUG - 2021-07-10 11:29:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-10 11:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-10 11:29:06 --> Parser Class Initialized
INFO - 2021-07-10 11:29:06 --> Form Validation Class Initialized
INFO - 2021-07-10 11:29:06 --> Upload Class Initialized
INFO - 2021-07-10 11:29:06 --> Email Class Initialized
INFO - 2021-07-10 11:29:06 --> MY_Model class loaded
INFO - 2021-07-10 11:29:06 --> Model "Users_model" initialized
INFO - 2021-07-10 11:29:06 --> Model "Settings_model" initialized
INFO - 2021-07-10 11:29:06 --> Model "Role_permissions_model" initialized
INFO - 2021-07-10 11:29:06 --> Model "Permissions_model" initialized
INFO - 2021-07-10 11:29:06 --> Model "Roles_model" initialized
INFO - 2021-07-10 11:29:06 --> Model "Activity_model" initialized
INFO - 2021-07-10 11:29:06 --> Model "Templates_model" initialized
INFO - 2021-07-10 11:29:06 --> Database Driver Class Initialized
INFO - 2021-07-10 11:29:06 --> Model "Hesaplar_model" initialized
INFO - 2021-07-10 11:29:06 --> Controller Class Initialized
INFO - 2021-07-10 12:28:36 --> Config Class Initialized
INFO - 2021-07-10 12:28:36 --> Hooks Class Initialized
DEBUG - 2021-07-10 12:28:36 --> UTF-8 Support Enabled
INFO - 2021-07-10 12:28:36 --> Utf8 Class Initialized
INFO - 2021-07-10 12:28:36 --> URI Class Initialized
DEBUG - 2021-07-10 12:28:36 --> No URI present. Default controller set.
INFO - 2021-07-10 12:28:36 --> Router Class Initialized
INFO - 2021-07-10 12:28:36 --> Output Class Initialized
INFO - 2021-07-10 12:28:36 --> Security Class Initialized
DEBUG - 2021-07-10 12:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 12:28:36 --> Input Class Initialized
INFO - 2021-07-10 12:28:36 --> Language Class Initialized
INFO - 2021-07-10 12:28:36 --> Loader Class Initialized
INFO - 2021-07-10 12:28:36 --> Helper loaded: basic_helper
INFO - 2021-07-10 12:28:36 --> Helper loaded: url_helper
INFO - 2021-07-10 12:28:36 --> Helper loaded: file_helper
INFO - 2021-07-10 12:28:36 --> Helper loaded: form_helper
INFO - 2021-07-10 12:28:36 --> Helper loaded: cookie_helper
INFO - 2021-07-10 12:28:36 --> Helper loaded: security_helper
INFO - 2021-07-10 12:28:36 --> Helper loaded: directory_helper
INFO - 2021-07-10 12:28:36 --> Helper loaded: language_helper
INFO - 2021-07-10 12:28:36 --> Helper loaded: general_helper
INFO - 2021-07-10 12:28:36 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-10 12:28:36 --> Database Driver Class Initialized
DEBUG - 2021-07-10 12:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-10 12:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-10 12:28:36 --> Parser Class Initialized
INFO - 2021-07-10 12:28:36 --> Form Validation Class Initialized
INFO - 2021-07-10 12:28:36 --> Upload Class Initialized
INFO - 2021-07-10 12:28:36 --> Email Class Initialized
INFO - 2021-07-10 12:28:36 --> MY_Model class loaded
INFO - 2021-07-10 12:28:36 --> Model "Users_model" initialized
INFO - 2021-07-10 12:28:36 --> Model "Settings_model" initialized
INFO - 2021-07-10 12:28:36 --> Model "Role_permissions_model" initialized
INFO - 2021-07-10 12:28:36 --> Model "Permissions_model" initialized
INFO - 2021-07-10 12:28:36 --> Model "Roles_model" initialized
INFO - 2021-07-10 12:28:36 --> Model "Activity_model" initialized
INFO - 2021-07-10 12:28:36 --> Model "Templates_model" initialized
INFO - 2021-07-10 12:28:36 --> Database Driver Class Initialized
INFO - 2021-07-10 12:28:37 --> Model "Hesaplar_model" initialized
INFO - 2021-07-10 12:28:37 --> Controller Class Initialized
INFO - 2021-07-10 13:28:39 --> Config Class Initialized
INFO - 2021-07-10 13:28:39 --> Hooks Class Initialized
DEBUG - 2021-07-10 13:28:39 --> UTF-8 Support Enabled
INFO - 2021-07-10 13:28:39 --> Utf8 Class Initialized
INFO - 2021-07-10 13:28:39 --> URI Class Initialized
DEBUG - 2021-07-10 13:28:39 --> No URI present. Default controller set.
INFO - 2021-07-10 13:28:39 --> Router Class Initialized
INFO - 2021-07-10 13:28:39 --> Output Class Initialized
INFO - 2021-07-10 13:28:39 --> Security Class Initialized
DEBUG - 2021-07-10 13:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 13:28:39 --> Input Class Initialized
INFO - 2021-07-10 13:28:39 --> Language Class Initialized
INFO - 2021-07-10 13:28:39 --> Loader Class Initialized
INFO - 2021-07-10 13:28:39 --> Helper loaded: basic_helper
INFO - 2021-07-10 13:28:39 --> Helper loaded: url_helper
INFO - 2021-07-10 13:28:39 --> Helper loaded: file_helper
INFO - 2021-07-10 13:28:39 --> Helper loaded: form_helper
INFO - 2021-07-10 13:28:39 --> Helper loaded: cookie_helper
INFO - 2021-07-10 13:28:39 --> Helper loaded: security_helper
INFO - 2021-07-10 13:28:39 --> Helper loaded: directory_helper
INFO - 2021-07-10 13:28:39 --> Helper loaded: language_helper
INFO - 2021-07-10 13:28:39 --> Helper loaded: general_helper
INFO - 2021-07-10 13:28:39 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-10 13:28:39 --> Database Driver Class Initialized
DEBUG - 2021-07-10 13:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-10 13:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-10 13:28:39 --> Parser Class Initialized
INFO - 2021-07-10 13:28:39 --> Form Validation Class Initialized
INFO - 2021-07-10 13:28:39 --> Upload Class Initialized
INFO - 2021-07-10 13:28:39 --> Email Class Initialized
INFO - 2021-07-10 13:28:39 --> MY_Model class loaded
INFO - 2021-07-10 13:28:39 --> Model "Users_model" initialized
INFO - 2021-07-10 13:28:39 --> Model "Settings_model" initialized
INFO - 2021-07-10 13:28:39 --> Model "Role_permissions_model" initialized
INFO - 2021-07-10 13:28:39 --> Model "Permissions_model" initialized
INFO - 2021-07-10 13:28:39 --> Model "Roles_model" initialized
INFO - 2021-07-10 13:28:39 --> Model "Activity_model" initialized
INFO - 2021-07-10 13:28:39 --> Model "Templates_model" initialized
INFO - 2021-07-10 13:28:39 --> Database Driver Class Initialized
INFO - 2021-07-10 13:28:39 --> Model "Hesaplar_model" initialized
INFO - 2021-07-10 13:28:39 --> Controller Class Initialized
INFO - 2021-07-10 13:48:42 --> Config Class Initialized
INFO - 2021-07-10 13:48:42 --> Hooks Class Initialized
DEBUG - 2021-07-10 13:48:42 --> UTF-8 Support Enabled
INFO - 2021-07-10 13:48:42 --> Utf8 Class Initialized
INFO - 2021-07-10 13:48:42 --> URI Class Initialized
DEBUG - 2021-07-10 13:48:42 --> No URI present. Default controller set.
INFO - 2021-07-10 13:48:42 --> Router Class Initialized
INFO - 2021-07-10 13:48:42 --> Output Class Initialized
INFO - 2021-07-10 13:48:42 --> Security Class Initialized
DEBUG - 2021-07-10 13:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 13:48:42 --> Input Class Initialized
INFO - 2021-07-10 13:48:42 --> Language Class Initialized
INFO - 2021-07-10 13:48:42 --> Loader Class Initialized
INFO - 2021-07-10 13:48:42 --> Helper loaded: basic_helper
INFO - 2021-07-10 13:48:42 --> Helper loaded: url_helper
INFO - 2021-07-10 13:48:42 --> Helper loaded: file_helper
INFO - 2021-07-10 13:48:42 --> Helper loaded: form_helper
INFO - 2021-07-10 13:48:42 --> Helper loaded: cookie_helper
INFO - 2021-07-10 13:48:42 --> Helper loaded: security_helper
INFO - 2021-07-10 13:48:42 --> Helper loaded: directory_helper
INFO - 2021-07-10 13:48:42 --> Helper loaded: language_helper
INFO - 2021-07-10 13:48:42 --> Helper loaded: general_helper
INFO - 2021-07-10 13:48:42 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-10 13:48:42 --> Database Driver Class Initialized
DEBUG - 2021-07-10 13:48:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-10 13:48:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-10 13:48:42 --> Parser Class Initialized
INFO - 2021-07-10 13:48:42 --> Form Validation Class Initialized
INFO - 2021-07-10 13:48:42 --> Upload Class Initialized
INFO - 2021-07-10 13:48:42 --> Email Class Initialized
INFO - 2021-07-10 13:48:42 --> MY_Model class loaded
INFO - 2021-07-10 13:48:42 --> Model "Users_model" initialized
INFO - 2021-07-10 13:48:42 --> Model "Settings_model" initialized
INFO - 2021-07-10 13:48:42 --> Model "Role_permissions_model" initialized
INFO - 2021-07-10 13:48:42 --> Model "Permissions_model" initialized
INFO - 2021-07-10 13:48:42 --> Model "Roles_model" initialized
INFO - 2021-07-10 13:48:42 --> Model "Activity_model" initialized
INFO - 2021-07-10 13:48:42 --> Model "Templates_model" initialized
INFO - 2021-07-10 13:48:42 --> Database Driver Class Initialized
INFO - 2021-07-10 13:48:42 --> Model "Hesaplar_model" initialized
INFO - 2021-07-10 13:48:42 --> Controller Class Initialized
ERROR - 2021-07-10 13:48:42 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-10 13:48:42 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-10 13:48:42 --> Final output sent to browser
DEBUG - 2021-07-10 13:48:42 --> Total execution time: 0.1348
INFO - 2021-07-10 13:48:44 --> Config Class Initialized
INFO - 2021-07-10 13:48:44 --> Hooks Class Initialized
DEBUG - 2021-07-10 13:48:44 --> UTF-8 Support Enabled
INFO - 2021-07-10 13:48:44 --> Utf8 Class Initialized
INFO - 2021-07-10 13:48:44 --> URI Class Initialized
INFO - 2021-07-10 13:48:44 --> Router Class Initialized
INFO - 2021-07-10 13:48:44 --> Output Class Initialized
INFO - 2021-07-10 13:48:44 --> Security Class Initialized
DEBUG - 2021-07-10 13:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 13:48:44 --> Input Class Initialized
INFO - 2021-07-10 13:48:44 --> Language Class Initialized
INFO - 2021-07-10 13:48:44 --> Loader Class Initialized
INFO - 2021-07-10 13:48:44 --> Helper loaded: basic_helper
INFO - 2021-07-10 13:48:44 --> Helper loaded: url_helper
INFO - 2021-07-10 13:48:44 --> Helper loaded: file_helper
INFO - 2021-07-10 13:48:44 --> Helper loaded: form_helper
INFO - 2021-07-10 13:48:44 --> Helper loaded: cookie_helper
INFO - 2021-07-10 13:48:44 --> Helper loaded: security_helper
INFO - 2021-07-10 13:48:44 --> Helper loaded: directory_helper
INFO - 2021-07-10 13:48:44 --> Helper loaded: language_helper
INFO - 2021-07-10 13:48:44 --> Helper loaded: general_helper
INFO - 2021-07-10 13:48:44 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-10 13:48:44 --> Database Driver Class Initialized
DEBUG - 2021-07-10 13:48:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-10 13:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-10 13:48:44 --> Parser Class Initialized
INFO - 2021-07-10 13:48:44 --> Form Validation Class Initialized
INFO - 2021-07-10 13:48:44 --> Upload Class Initialized
INFO - 2021-07-10 13:48:44 --> Email Class Initialized
INFO - 2021-07-10 13:48:44 --> MY_Model class loaded
INFO - 2021-07-10 13:48:44 --> Model "Users_model" initialized
INFO - 2021-07-10 13:48:44 --> Model "Settings_model" initialized
INFO - 2021-07-10 13:48:44 --> Model "Role_permissions_model" initialized
INFO - 2021-07-10 13:48:44 --> Model "Permissions_model" initialized
INFO - 2021-07-10 13:48:44 --> Model "Roles_model" initialized
INFO - 2021-07-10 13:48:44 --> Model "Activity_model" initialized
INFO - 2021-07-10 13:48:44 --> Model "Templates_model" initialized
INFO - 2021-07-10 13:48:44 --> Database Driver Class Initialized
INFO - 2021-07-10 13:48:44 --> Model "Hesaplar_model" initialized
INFO - 2021-07-10 13:48:44 --> Controller Class Initialized
ERROR - 2021-07-10 13:48:44 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-10 13:48:44 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-10 13:48:44 --> Final output sent to browser
DEBUG - 2021-07-10 13:48:44 --> Total execution time: 0.1348
INFO - 2021-07-10 13:48:54 --> Config Class Initialized
INFO - 2021-07-10 13:48:54 --> Hooks Class Initialized
DEBUG - 2021-07-10 13:48:54 --> UTF-8 Support Enabled
INFO - 2021-07-10 13:48:54 --> Utf8 Class Initialized
INFO - 2021-07-10 13:48:54 --> URI Class Initialized
INFO - 2021-07-10 13:48:54 --> Router Class Initialized
INFO - 2021-07-10 13:48:54 --> Output Class Initialized
INFO - 2021-07-10 13:48:54 --> Security Class Initialized
DEBUG - 2021-07-10 13:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 13:48:54 --> Input Class Initialized
INFO - 2021-07-10 13:48:54 --> Language Class Initialized
INFO - 2021-07-10 13:48:54 --> Loader Class Initialized
INFO - 2021-07-10 13:48:54 --> Helper loaded: basic_helper
INFO - 2021-07-10 13:48:54 --> Helper loaded: url_helper
INFO - 2021-07-10 13:48:54 --> Helper loaded: file_helper
INFO - 2021-07-10 13:48:54 --> Helper loaded: form_helper
INFO - 2021-07-10 13:48:54 --> Helper loaded: cookie_helper
INFO - 2021-07-10 13:48:54 --> Helper loaded: security_helper
INFO - 2021-07-10 13:48:54 --> Helper loaded: directory_helper
INFO - 2021-07-10 13:48:54 --> Helper loaded: language_helper
INFO - 2021-07-10 13:48:54 --> Helper loaded: general_helper
INFO - 2021-07-10 13:48:54 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-10 13:48:54 --> Database Driver Class Initialized
DEBUG - 2021-07-10 13:48:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-10 13:48:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-10 13:48:54 --> Parser Class Initialized
INFO - 2021-07-10 13:48:54 --> Form Validation Class Initialized
INFO - 2021-07-10 13:48:54 --> Upload Class Initialized
INFO - 2021-07-10 13:48:54 --> Email Class Initialized
INFO - 2021-07-10 13:48:54 --> MY_Model class loaded
INFO - 2021-07-10 13:48:54 --> Model "Users_model" initialized
INFO - 2021-07-10 13:48:54 --> Model "Settings_model" initialized
INFO - 2021-07-10 13:48:54 --> Model "Role_permissions_model" initialized
INFO - 2021-07-10 13:48:54 --> Model "Permissions_model" initialized
INFO - 2021-07-10 13:48:54 --> Model "Roles_model" initialized
INFO - 2021-07-10 13:48:54 --> Model "Activity_model" initialized
INFO - 2021-07-10 13:48:54 --> Model "Templates_model" initialized
INFO - 2021-07-10 13:48:54 --> Database Driver Class Initialized
INFO - 2021-07-10 13:48:54 --> Model "Hesaplar_model" initialized
INFO - 2021-07-10 13:48:54 --> Controller Class Initialized
ERROR - 2021-07-10 13:48:54 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-10 13:48:54 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-10 13:48:54 --> Final output sent to browser
DEBUG - 2021-07-10 13:48:54 --> Total execution time: 0.1418
INFO - 2021-07-10 13:52:05 --> Config Class Initialized
INFO - 2021-07-10 13:52:05 --> Hooks Class Initialized
DEBUG - 2021-07-10 13:52:05 --> UTF-8 Support Enabled
INFO - 2021-07-10 13:52:05 --> Utf8 Class Initialized
INFO - 2021-07-10 13:52:05 --> URI Class Initialized
INFO - 2021-07-10 13:52:05 --> Router Class Initialized
INFO - 2021-07-10 13:52:05 --> Output Class Initialized
INFO - 2021-07-10 13:52:05 --> Security Class Initialized
DEBUG - 2021-07-10 13:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 13:52:05 --> Input Class Initialized
INFO - 2021-07-10 13:52:05 --> Language Class Initialized
INFO - 2021-07-10 13:52:05 --> Loader Class Initialized
INFO - 2021-07-10 13:52:05 --> Helper loaded: basic_helper
INFO - 2021-07-10 13:52:05 --> Helper loaded: url_helper
INFO - 2021-07-10 13:52:05 --> Helper loaded: file_helper
INFO - 2021-07-10 13:52:05 --> Helper loaded: form_helper
INFO - 2021-07-10 13:52:05 --> Helper loaded: cookie_helper
INFO - 2021-07-10 13:52:05 --> Helper loaded: security_helper
INFO - 2021-07-10 13:52:05 --> Helper loaded: directory_helper
INFO - 2021-07-10 13:52:05 --> Helper loaded: language_helper
INFO - 2021-07-10 13:52:05 --> Helper loaded: general_helper
INFO - 2021-07-10 13:52:05 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-10 13:52:05 --> Database Driver Class Initialized
DEBUG - 2021-07-10 13:52:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-10 13:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-10 13:52:05 --> Parser Class Initialized
INFO - 2021-07-10 13:52:05 --> Form Validation Class Initialized
INFO - 2021-07-10 13:52:05 --> Upload Class Initialized
INFO - 2021-07-10 13:52:05 --> Email Class Initialized
INFO - 2021-07-10 13:52:05 --> MY_Model class loaded
INFO - 2021-07-10 13:52:05 --> Model "Users_model" initialized
INFO - 2021-07-10 13:52:05 --> Model "Settings_model" initialized
INFO - 2021-07-10 13:52:05 --> Model "Role_permissions_model" initialized
INFO - 2021-07-10 13:52:05 --> Model "Permissions_model" initialized
INFO - 2021-07-10 13:52:05 --> Model "Roles_model" initialized
INFO - 2021-07-10 13:52:05 --> Model "Activity_model" initialized
INFO - 2021-07-10 13:52:05 --> Model "Templates_model" initialized
INFO - 2021-07-10 13:52:05 --> Database Driver Class Initialized
INFO - 2021-07-10 13:52:05 --> Model "Hesaplar_model" initialized
INFO - 2021-07-10 13:52:05 --> Controller Class Initialized
ERROR - 2021-07-10 13:52:05 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-10 13:52:05 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-10 13:52:05 --> Final output sent to browser
DEBUG - 2021-07-10 13:52:05 --> Total execution time: 0.6117
INFO - 2021-07-10 13:52:12 --> Config Class Initialized
INFO - 2021-07-10 13:52:12 --> Hooks Class Initialized
DEBUG - 2021-07-10 13:52:12 --> UTF-8 Support Enabled
INFO - 2021-07-10 13:52:12 --> Utf8 Class Initialized
INFO - 2021-07-10 13:52:12 --> URI Class Initialized
INFO - 2021-07-10 13:52:12 --> Router Class Initialized
INFO - 2021-07-10 13:52:12 --> Output Class Initialized
INFO - 2021-07-10 13:52:12 --> Security Class Initialized
DEBUG - 2021-07-10 13:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 13:52:12 --> Input Class Initialized
INFO - 2021-07-10 13:52:12 --> Language Class Initialized
INFO - 2021-07-10 13:52:12 --> Loader Class Initialized
INFO - 2021-07-10 13:52:12 --> Helper loaded: basic_helper
INFO - 2021-07-10 13:52:12 --> Helper loaded: url_helper
INFO - 2021-07-10 13:52:12 --> Helper loaded: file_helper
INFO - 2021-07-10 13:52:12 --> Helper loaded: form_helper
INFO - 2021-07-10 13:52:12 --> Helper loaded: cookie_helper
INFO - 2021-07-10 13:52:12 --> Helper loaded: security_helper
INFO - 2021-07-10 13:52:12 --> Helper loaded: directory_helper
INFO - 2021-07-10 13:52:12 --> Helper loaded: language_helper
INFO - 2021-07-10 13:52:12 --> Helper loaded: general_helper
INFO - 2021-07-10 13:52:12 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-10 13:52:12 --> Database Driver Class Initialized
DEBUG - 2021-07-10 13:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-10 13:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-10 13:52:12 --> Parser Class Initialized
INFO - 2021-07-10 13:52:12 --> Form Validation Class Initialized
INFO - 2021-07-10 13:52:12 --> Upload Class Initialized
INFO - 2021-07-10 13:52:12 --> Email Class Initialized
INFO - 2021-07-10 13:52:12 --> MY_Model class loaded
INFO - 2021-07-10 13:52:12 --> Model "Users_model" initialized
INFO - 2021-07-10 13:52:12 --> Model "Settings_model" initialized
INFO - 2021-07-10 13:52:12 --> Model "Role_permissions_model" initialized
INFO - 2021-07-10 13:52:12 --> Model "Permissions_model" initialized
INFO - 2021-07-10 13:52:12 --> Model "Roles_model" initialized
INFO - 2021-07-10 13:52:12 --> Model "Activity_model" initialized
INFO - 2021-07-10 13:52:12 --> Model "Templates_model" initialized
INFO - 2021-07-10 13:52:12 --> Database Driver Class Initialized
INFO - 2021-07-10 13:52:12 --> Model "Hesaplar_model" initialized
INFO - 2021-07-10 13:52:12 --> Controller Class Initialized
ERROR - 2021-07-10 13:52:12 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-10 13:52:12 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-10 13:52:12 --> Final output sent to browser
DEBUG - 2021-07-10 13:52:12 --> Total execution time: 0.1488
INFO - 2021-07-10 13:58:21 --> Config Class Initialized
INFO - 2021-07-10 13:58:21 --> Hooks Class Initialized
DEBUG - 2021-07-10 13:58:21 --> UTF-8 Support Enabled
INFO - 2021-07-10 13:58:21 --> Utf8 Class Initialized
INFO - 2021-07-10 13:58:21 --> URI Class Initialized
DEBUG - 2021-07-10 13:58:21 --> No URI present. Default controller set.
INFO - 2021-07-10 13:58:21 --> Router Class Initialized
INFO - 2021-07-10 13:58:21 --> Output Class Initialized
INFO - 2021-07-10 13:58:21 --> Security Class Initialized
DEBUG - 2021-07-10 13:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 13:58:21 --> Input Class Initialized
INFO - 2021-07-10 13:58:21 --> Language Class Initialized
INFO - 2021-07-10 13:58:21 --> Loader Class Initialized
INFO - 2021-07-10 13:58:21 --> Helper loaded: basic_helper
INFO - 2021-07-10 13:58:21 --> Helper loaded: url_helper
INFO - 2021-07-10 13:58:21 --> Helper loaded: file_helper
INFO - 2021-07-10 13:58:21 --> Helper loaded: form_helper
INFO - 2021-07-10 13:58:21 --> Helper loaded: cookie_helper
INFO - 2021-07-10 13:58:21 --> Helper loaded: security_helper
INFO - 2021-07-10 13:58:21 --> Helper loaded: directory_helper
INFO - 2021-07-10 13:58:21 --> Helper loaded: language_helper
INFO - 2021-07-10 13:58:21 --> Helper loaded: general_helper
INFO - 2021-07-10 13:58:21 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-10 13:58:21 --> Database Driver Class Initialized
DEBUG - 2021-07-10 13:58:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-10 13:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-10 13:58:21 --> Parser Class Initialized
INFO - 2021-07-10 13:58:21 --> Form Validation Class Initialized
INFO - 2021-07-10 13:58:21 --> Upload Class Initialized
INFO - 2021-07-10 13:58:21 --> Email Class Initialized
INFO - 2021-07-10 13:58:21 --> MY_Model class loaded
INFO - 2021-07-10 13:58:21 --> Model "Users_model" initialized
INFO - 2021-07-10 13:58:21 --> Model "Settings_model" initialized
INFO - 2021-07-10 13:58:21 --> Model "Role_permissions_model" initialized
INFO - 2021-07-10 13:58:21 --> Model "Permissions_model" initialized
INFO - 2021-07-10 13:58:21 --> Model "Roles_model" initialized
INFO - 2021-07-10 13:58:21 --> Model "Activity_model" initialized
INFO - 2021-07-10 13:58:21 --> Model "Templates_model" initialized
INFO - 2021-07-10 13:58:21 --> Database Driver Class Initialized
INFO - 2021-07-10 13:58:22 --> Model "Hesaplar_model" initialized
INFO - 2021-07-10 13:58:22 --> Controller Class Initialized
INFO - 2021-07-10 13:58:39 --> Config Class Initialized
INFO - 2021-07-10 13:58:39 --> Hooks Class Initialized
DEBUG - 2021-07-10 13:58:39 --> UTF-8 Support Enabled
INFO - 2021-07-10 13:58:39 --> Utf8 Class Initialized
INFO - 2021-07-10 13:58:39 --> URI Class Initialized
INFO - 2021-07-10 13:58:39 --> Router Class Initialized
INFO - 2021-07-10 13:58:39 --> Output Class Initialized
INFO - 2021-07-10 13:58:39 --> Security Class Initialized
DEBUG - 2021-07-10 13:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 13:58:39 --> Input Class Initialized
INFO - 2021-07-10 13:58:39 --> Language Class Initialized
ERROR - 2021-07-10 13:58:39 --> 404 Page Not Found: DevMgmt/DiscoveryTree.xml
INFO - 2021-07-10 13:58:39 --> Config Class Initialized
INFO - 2021-07-10 13:58:39 --> Hooks Class Initialized
DEBUG - 2021-07-10 13:58:39 --> UTF-8 Support Enabled
INFO - 2021-07-10 13:58:39 --> Utf8 Class Initialized
INFO - 2021-07-10 13:58:39 --> URI Class Initialized
INFO - 2021-07-10 13:58:39 --> Router Class Initialized
INFO - 2021-07-10 13:58:39 --> Output Class Initialized
INFO - 2021-07-10 13:58:39 --> Security Class Initialized
DEBUG - 2021-07-10 13:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 13:58:39 --> Input Class Initialized
INFO - 2021-07-10 13:58:39 --> Language Class Initialized
ERROR - 2021-07-10 13:58:39 --> 404 Page Not Found: DevMgmt/DiscoveryTree.xml
INFO - 2021-07-10 13:58:41 --> Config Class Initialized
INFO - 2021-07-10 13:58:41 --> Hooks Class Initialized
DEBUG - 2021-07-10 13:58:41 --> UTF-8 Support Enabled
INFO - 2021-07-10 13:58:41 --> Utf8 Class Initialized
INFO - 2021-07-10 13:58:41 --> URI Class Initialized
INFO - 2021-07-10 13:58:41 --> Router Class Initialized
INFO - 2021-07-10 13:58:41 --> Output Class Initialized
INFO - 2021-07-10 13:58:41 --> Security Class Initialized
DEBUG - 2021-07-10 13:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 13:58:41 --> Input Class Initialized
INFO - 2021-07-10 13:58:41 --> Language Class Initialized
ERROR - 2021-07-10 13:58:41 --> 404 Page Not Found: DevMgmt/DiscoveryTree.xml
INFO - 2021-07-10 14:01:56 --> Config Class Initialized
INFO - 2021-07-10 14:01:56 --> Hooks Class Initialized
DEBUG - 2021-07-10 14:01:56 --> UTF-8 Support Enabled
INFO - 2021-07-10 14:01:56 --> Utf8 Class Initialized
INFO - 2021-07-10 14:01:56 --> URI Class Initialized
INFO - 2021-07-10 14:01:56 --> Router Class Initialized
INFO - 2021-07-10 14:01:56 --> Output Class Initialized
INFO - 2021-07-10 14:01:56 --> Security Class Initialized
DEBUG - 2021-07-10 14:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 14:01:56 --> Input Class Initialized
INFO - 2021-07-10 14:01:56 --> Language Class Initialized
ERROR - 2021-07-10 14:01:56 --> 404 Page Not Found: DevMgmt/DiscoveryTree.xml
INFO - 2021-07-10 14:40:36 --> Config Class Initialized
INFO - 2021-07-10 14:40:36 --> Hooks Class Initialized
DEBUG - 2021-07-10 14:40:36 --> UTF-8 Support Enabled
INFO - 2021-07-10 14:40:36 --> Utf8 Class Initialized
INFO - 2021-07-10 14:40:36 --> URI Class Initialized
DEBUG - 2021-07-10 14:40:36 --> No URI present. Default controller set.
INFO - 2021-07-10 14:40:36 --> Router Class Initialized
INFO - 2021-07-10 14:40:36 --> Output Class Initialized
INFO - 2021-07-10 14:40:36 --> Security Class Initialized
DEBUG - 2021-07-10 14:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 14:40:36 --> Input Class Initialized
INFO - 2021-07-10 14:40:36 --> Language Class Initialized
INFO - 2021-07-10 14:40:36 --> Loader Class Initialized
INFO - 2021-07-10 14:40:36 --> Helper loaded: basic_helper
INFO - 2021-07-10 14:40:36 --> Helper loaded: url_helper
INFO - 2021-07-10 14:40:36 --> Helper loaded: file_helper
INFO - 2021-07-10 14:40:36 --> Helper loaded: form_helper
INFO - 2021-07-10 14:40:36 --> Helper loaded: cookie_helper
INFO - 2021-07-10 14:40:36 --> Helper loaded: security_helper
INFO - 2021-07-10 14:40:36 --> Helper loaded: directory_helper
INFO - 2021-07-10 14:40:36 --> Helper loaded: language_helper
INFO - 2021-07-10 14:40:36 --> Helper loaded: general_helper
INFO - 2021-07-10 14:40:36 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-10 14:40:36 --> Database Driver Class Initialized
DEBUG - 2021-07-10 14:40:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-10 14:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-10 14:40:36 --> Parser Class Initialized
INFO - 2021-07-10 14:40:36 --> Form Validation Class Initialized
INFO - 2021-07-10 14:40:36 --> Upload Class Initialized
INFO - 2021-07-10 14:40:36 --> Email Class Initialized
INFO - 2021-07-10 14:40:36 --> MY_Model class loaded
INFO - 2021-07-10 14:40:36 --> Model "Users_model" initialized
INFO - 2021-07-10 14:40:36 --> Model "Settings_model" initialized
INFO - 2021-07-10 14:40:36 --> Model "Role_permissions_model" initialized
INFO - 2021-07-10 14:40:36 --> Model "Permissions_model" initialized
INFO - 2021-07-10 14:40:36 --> Model "Roles_model" initialized
INFO - 2021-07-10 14:40:36 --> Model "Activity_model" initialized
INFO - 2021-07-10 14:40:36 --> Model "Templates_model" initialized
INFO - 2021-07-10 14:40:36 --> Database Driver Class Initialized
INFO - 2021-07-10 14:40:36 --> Model "Hesaplar_model" initialized
INFO - 2021-07-10 14:40:36 --> Controller Class Initialized
INFO - 2021-07-10 15:52:33 --> Config Class Initialized
INFO - 2021-07-10 15:52:33 --> Hooks Class Initialized
DEBUG - 2021-07-10 15:52:33 --> UTF-8 Support Enabled
INFO - 2021-07-10 15:52:33 --> Utf8 Class Initialized
INFO - 2021-07-10 15:52:33 --> URI Class Initialized
DEBUG - 2021-07-10 15:52:33 --> No URI present. Default controller set.
INFO - 2021-07-10 15:52:33 --> Router Class Initialized
INFO - 2021-07-10 15:52:33 --> Output Class Initialized
INFO - 2021-07-10 15:52:33 --> Security Class Initialized
DEBUG - 2021-07-10 15:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 15:52:33 --> Input Class Initialized
INFO - 2021-07-10 15:52:33 --> Language Class Initialized
INFO - 2021-07-10 15:52:33 --> Loader Class Initialized
INFO - 2021-07-10 15:52:33 --> Helper loaded: basic_helper
INFO - 2021-07-10 15:52:33 --> Helper loaded: url_helper
INFO - 2021-07-10 15:52:33 --> Helper loaded: file_helper
INFO - 2021-07-10 15:52:33 --> Helper loaded: form_helper
INFO - 2021-07-10 15:52:33 --> Helper loaded: cookie_helper
INFO - 2021-07-10 15:52:33 --> Helper loaded: security_helper
INFO - 2021-07-10 15:52:33 --> Helper loaded: directory_helper
INFO - 2021-07-10 15:52:33 --> Helper loaded: language_helper
INFO - 2021-07-10 15:52:33 --> Helper loaded: general_helper
INFO - 2021-07-10 15:52:33 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-10 15:52:33 --> Database Driver Class Initialized
DEBUG - 2021-07-10 15:52:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-10 15:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-10 15:52:33 --> Parser Class Initialized
INFO - 2021-07-10 15:52:33 --> Form Validation Class Initialized
INFO - 2021-07-10 15:52:33 --> Upload Class Initialized
INFO - 2021-07-10 15:52:33 --> Email Class Initialized
INFO - 2021-07-10 15:52:33 --> MY_Model class loaded
INFO - 2021-07-10 15:52:33 --> Model "Users_model" initialized
INFO - 2021-07-10 15:52:33 --> Model "Settings_model" initialized
INFO - 2021-07-10 15:52:33 --> Model "Role_permissions_model" initialized
INFO - 2021-07-10 15:52:33 --> Model "Permissions_model" initialized
INFO - 2021-07-10 15:52:33 --> Model "Roles_model" initialized
INFO - 2021-07-10 15:52:33 --> Model "Activity_model" initialized
INFO - 2021-07-10 15:52:33 --> Model "Templates_model" initialized
INFO - 2021-07-10 15:52:33 --> Database Driver Class Initialized
INFO - 2021-07-10 15:52:33 --> Model "Hesaplar_model" initialized
INFO - 2021-07-10 15:52:33 --> Controller Class Initialized
INFO - 2021-07-10 15:58:38 --> Config Class Initialized
INFO - 2021-07-10 15:58:38 --> Hooks Class Initialized
DEBUG - 2021-07-10 15:58:38 --> UTF-8 Support Enabled
INFO - 2021-07-10 15:58:38 --> Utf8 Class Initialized
INFO - 2021-07-10 15:58:38 --> URI Class Initialized
INFO - 2021-07-10 15:58:38 --> Router Class Initialized
INFO - 2021-07-10 15:58:38 --> Output Class Initialized
INFO - 2021-07-10 15:58:38 --> Security Class Initialized
DEBUG - 2021-07-10 15:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 15:58:38 --> Input Class Initialized
INFO - 2021-07-10 15:58:38 --> Language Class Initialized
ERROR - 2021-07-10 15:58:38 --> 404 Page Not Found: DevMgmt/DiscoveryTree.xml
INFO - 2021-07-10 16:12:56 --> Config Class Initialized
INFO - 2021-07-10 16:12:56 --> Hooks Class Initialized
DEBUG - 2021-07-10 16:12:56 --> UTF-8 Support Enabled
INFO - 2021-07-10 16:12:56 --> Utf8 Class Initialized
INFO - 2021-07-10 16:12:56 --> URI Class Initialized
DEBUG - 2021-07-10 16:12:56 --> No URI present. Default controller set.
INFO - 2021-07-10 16:12:56 --> Router Class Initialized
INFO - 2021-07-10 16:12:56 --> Output Class Initialized
INFO - 2021-07-10 16:12:56 --> Security Class Initialized
DEBUG - 2021-07-10 16:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 16:12:56 --> Input Class Initialized
INFO - 2021-07-10 16:12:56 --> Language Class Initialized
INFO - 2021-07-10 16:12:56 --> Loader Class Initialized
INFO - 2021-07-10 16:12:56 --> Helper loaded: basic_helper
INFO - 2021-07-10 16:12:56 --> Helper loaded: url_helper
INFO - 2021-07-10 16:12:56 --> Helper loaded: file_helper
INFO - 2021-07-10 16:12:56 --> Helper loaded: form_helper
INFO - 2021-07-10 16:12:56 --> Helper loaded: cookie_helper
INFO - 2021-07-10 16:12:56 --> Helper loaded: security_helper
INFO - 2021-07-10 16:12:56 --> Helper loaded: directory_helper
INFO - 2021-07-10 16:12:56 --> Helper loaded: language_helper
INFO - 2021-07-10 16:12:56 --> Helper loaded: general_helper
INFO - 2021-07-10 16:12:56 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-10 16:12:56 --> Database Driver Class Initialized
DEBUG - 2021-07-10 16:12:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-10 16:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-10 16:12:56 --> Parser Class Initialized
INFO - 2021-07-10 16:12:56 --> Form Validation Class Initialized
INFO - 2021-07-10 16:12:56 --> Upload Class Initialized
INFO - 2021-07-10 16:12:56 --> Email Class Initialized
INFO - 2021-07-10 16:12:56 --> MY_Model class loaded
INFO - 2021-07-10 16:12:56 --> Model "Users_model" initialized
INFO - 2021-07-10 16:12:56 --> Model "Settings_model" initialized
INFO - 2021-07-10 16:12:56 --> Model "Role_permissions_model" initialized
INFO - 2021-07-10 16:12:56 --> Model "Permissions_model" initialized
INFO - 2021-07-10 16:12:56 --> Model "Roles_model" initialized
INFO - 2021-07-10 16:12:56 --> Model "Activity_model" initialized
INFO - 2021-07-10 16:12:56 --> Model "Templates_model" initialized
INFO - 2021-07-10 16:12:56 --> Database Driver Class Initialized
INFO - 2021-07-10 16:12:56 --> Model "Hesaplar_model" initialized
INFO - 2021-07-10 16:12:56 --> Controller Class Initialized
ERROR - 2021-07-10 16:12:56 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-10 16:12:56 --> File loaded: C:\wamp64\www\crm\application\views\dashboard.php
INFO - 2021-07-10 16:12:56 --> Final output sent to browser
DEBUG - 2021-07-10 16:12:56 --> Total execution time: 0.1275
INFO - 2021-07-10 16:12:58 --> Config Class Initialized
INFO - 2021-07-10 16:12:58 --> Hooks Class Initialized
DEBUG - 2021-07-10 16:12:58 --> UTF-8 Support Enabled
INFO - 2021-07-10 16:12:58 --> Utf8 Class Initialized
INFO - 2021-07-10 16:12:58 --> URI Class Initialized
INFO - 2021-07-10 16:12:58 --> Router Class Initialized
INFO - 2021-07-10 16:12:58 --> Output Class Initialized
INFO - 2021-07-10 16:12:58 --> Security Class Initialized
DEBUG - 2021-07-10 16:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 16:12:58 --> Input Class Initialized
INFO - 2021-07-10 16:12:58 --> Language Class Initialized
INFO - 2021-07-10 16:12:58 --> Loader Class Initialized
INFO - 2021-07-10 16:12:58 --> Helper loaded: basic_helper
INFO - 2021-07-10 16:12:58 --> Helper loaded: url_helper
INFO - 2021-07-10 16:12:58 --> Helper loaded: file_helper
INFO - 2021-07-10 16:12:58 --> Helper loaded: form_helper
INFO - 2021-07-10 16:12:58 --> Helper loaded: cookie_helper
INFO - 2021-07-10 16:12:58 --> Helper loaded: security_helper
INFO - 2021-07-10 16:12:58 --> Helper loaded: directory_helper
INFO - 2021-07-10 16:12:58 --> Helper loaded: language_helper
INFO - 2021-07-10 16:12:58 --> Helper loaded: general_helper
INFO - 2021-07-10 16:12:58 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-10 16:12:58 --> Database Driver Class Initialized
DEBUG - 2021-07-10 16:12:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-10 16:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-10 16:12:58 --> Parser Class Initialized
INFO - 2021-07-10 16:12:58 --> Form Validation Class Initialized
INFO - 2021-07-10 16:12:58 --> Upload Class Initialized
INFO - 2021-07-10 16:12:58 --> Email Class Initialized
INFO - 2021-07-10 16:12:58 --> MY_Model class loaded
INFO - 2021-07-10 16:12:58 --> Model "Users_model" initialized
INFO - 2021-07-10 16:12:58 --> Model "Settings_model" initialized
INFO - 2021-07-10 16:12:58 --> Model "Role_permissions_model" initialized
INFO - 2021-07-10 16:12:58 --> Model "Permissions_model" initialized
INFO - 2021-07-10 16:12:58 --> Model "Roles_model" initialized
INFO - 2021-07-10 16:12:58 --> Model "Activity_model" initialized
INFO - 2021-07-10 16:12:58 --> Model "Templates_model" initialized
INFO - 2021-07-10 16:12:58 --> Database Driver Class Initialized
INFO - 2021-07-10 16:12:58 --> Model "Hesaplar_model" initialized
INFO - 2021-07-10 16:12:58 --> Controller Class Initialized
ERROR - 2021-07-10 16:12:58 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-10 16:12:58 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/raporlar.php
INFO - 2021-07-10 16:12:58 --> Final output sent to browser
DEBUG - 2021-07-10 16:12:58 --> Total execution time: 0.1387
INFO - 2021-07-10 16:13:06 --> Config Class Initialized
INFO - 2021-07-10 16:13:06 --> Hooks Class Initialized
DEBUG - 2021-07-10 16:13:06 --> UTF-8 Support Enabled
INFO - 2021-07-10 16:13:06 --> Utf8 Class Initialized
INFO - 2021-07-10 16:13:06 --> URI Class Initialized
INFO - 2021-07-10 16:13:06 --> Router Class Initialized
INFO - 2021-07-10 16:13:06 --> Output Class Initialized
INFO - 2021-07-10 16:13:06 --> Security Class Initialized
DEBUG - 2021-07-10 16:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 16:13:06 --> Input Class Initialized
INFO - 2021-07-10 16:13:06 --> Language Class Initialized
INFO - 2021-07-10 16:13:06 --> Loader Class Initialized
INFO - 2021-07-10 16:13:06 --> Helper loaded: basic_helper
INFO - 2021-07-10 16:13:06 --> Helper loaded: url_helper
INFO - 2021-07-10 16:13:06 --> Helper loaded: file_helper
INFO - 2021-07-10 16:13:06 --> Helper loaded: form_helper
INFO - 2021-07-10 16:13:06 --> Helper loaded: cookie_helper
INFO - 2021-07-10 16:13:06 --> Helper loaded: security_helper
INFO - 2021-07-10 16:13:06 --> Helper loaded: directory_helper
INFO - 2021-07-10 16:13:06 --> Helper loaded: language_helper
INFO - 2021-07-10 16:13:06 --> Helper loaded: general_helper
INFO - 2021-07-10 16:13:06 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-10 16:13:06 --> Database Driver Class Initialized
DEBUG - 2021-07-10 16:13:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-10 16:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-10 16:13:06 --> Parser Class Initialized
INFO - 2021-07-10 16:13:06 --> Form Validation Class Initialized
INFO - 2021-07-10 16:13:06 --> Upload Class Initialized
INFO - 2021-07-10 16:13:06 --> Email Class Initialized
INFO - 2021-07-10 16:13:06 --> MY_Model class loaded
INFO - 2021-07-10 16:13:06 --> Model "Users_model" initialized
INFO - 2021-07-10 16:13:06 --> Model "Settings_model" initialized
INFO - 2021-07-10 16:13:06 --> Model "Role_permissions_model" initialized
INFO - 2021-07-10 16:13:06 --> Model "Permissions_model" initialized
INFO - 2021-07-10 16:13:06 --> Model "Roles_model" initialized
INFO - 2021-07-10 16:13:06 --> Model "Activity_model" initialized
INFO - 2021-07-10 16:13:06 --> Model "Templates_model" initialized
INFO - 2021-07-10 16:13:06 --> Database Driver Class Initialized
INFO - 2021-07-10 16:13:06 --> Model "Hesaplar_model" initialized
INFO - 2021-07-10 16:13:06 --> Controller Class Initialized
ERROR - 2021-07-10 16:13:06 --> Could not find the language line "sample_message_bro"
INFO - 2021-07-10 16:13:06 --> File loaded: C:\wamp64\www\crm\application\views\hesaplar/not_ekle_view.php
INFO - 2021-07-10 16:13:06 --> Final output sent to browser
DEBUG - 2021-07-10 16:13:06 --> Total execution time: 0.1422
INFO - 2021-07-10 17:04:33 --> Config Class Initialized
INFO - 2021-07-10 17:04:33 --> Hooks Class Initialized
DEBUG - 2021-07-10 17:04:33 --> UTF-8 Support Enabled
INFO - 2021-07-10 17:04:33 --> Utf8 Class Initialized
INFO - 2021-07-10 17:04:33 --> URI Class Initialized
DEBUG - 2021-07-10 17:04:33 --> No URI present. Default controller set.
INFO - 2021-07-10 17:04:33 --> Router Class Initialized
INFO - 2021-07-10 17:04:33 --> Output Class Initialized
INFO - 2021-07-10 17:04:33 --> Security Class Initialized
DEBUG - 2021-07-10 17:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-10 17:04:33 --> Input Class Initialized
INFO - 2021-07-10 17:04:33 --> Language Class Initialized
INFO - 2021-07-10 17:04:33 --> Loader Class Initialized
INFO - 2021-07-10 17:04:33 --> Helper loaded: basic_helper
INFO - 2021-07-10 17:04:33 --> Helper loaded: url_helper
INFO - 2021-07-10 17:04:33 --> Helper loaded: file_helper
INFO - 2021-07-10 17:04:33 --> Helper loaded: form_helper
INFO - 2021-07-10 17:04:33 --> Helper loaded: cookie_helper
INFO - 2021-07-10 17:04:33 --> Helper loaded: security_helper
INFO - 2021-07-10 17:04:33 --> Helper loaded: directory_helper
INFO - 2021-07-10 17:04:33 --> Helper loaded: language_helper
INFO - 2021-07-10 17:04:33 --> Helper loaded: general_helper
INFO - 2021-07-10 17:04:33 --> Language file loaded: language/en/basic_lang.php
INFO - 2021-07-10 17:04:33 --> Database Driver Class Initialized
DEBUG - 2021-07-10 17:04:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-10 17:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-10 17:04:33 --> Parser Class Initialized
INFO - 2021-07-10 17:04:33 --> Form Validation Class Initialized
INFO - 2021-07-10 17:04:33 --> Upload Class Initialized
INFO - 2021-07-10 17:04:33 --> Email Class Initialized
INFO - 2021-07-10 17:04:33 --> MY_Model class loaded
INFO - 2021-07-10 17:04:33 --> Model "Users_model" initialized
INFO - 2021-07-10 17:04:33 --> Model "Settings_model" initialized
INFO - 2021-07-10 17:04:33 --> Model "Role_permissions_model" initialized
INFO - 2021-07-10 17:04:33 --> Model "Permissions_model" initialized
INFO - 2021-07-10 17:04:33 --> Model "Roles_model" initialized
INFO - 2021-07-10 17:04:33 --> Model "Activity_model" initialized
INFO - 2021-07-10 17:04:33 --> Model "Templates_model" initialized
INFO - 2021-07-10 17:04:33 --> Database Driver Class Initialized
INFO - 2021-07-10 17:04:33 --> Model "Hesaplar_model" initialized
INFO - 2021-07-10 17:04:33 --> Controller Class Initialized
